#!/usr/bin/env node
/**
 * Translation coverage report.
 *
 * en.json is the source of truth; every other locale may be partial and falls
 * back to English at runtime, so nothing here fails a build by default —
 * missing keys are a status report, not an error. Pass --strict to exit 1 when
 * a locale is incomplete (useful if you want a release to require 100%).
 *
 *   node scripts/i18n-check.mjs [--strict]
 */
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const I18N_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'i18n');
const strict = process.argv.includes('--strict');

const read = (file) => JSON.parse(readFileSync(join(I18N_DIR, file), 'utf8'));

/** Flatten to dotted leaf paths. Arrays count as a single translatable leaf. */
function leaves(value, prefix = '', out = []) {
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
    for (const [key, child] of Object.entries(value)) {
      leaves(child, prefix ? `${prefix}.${key}` : key, out);
    }
  } else {
    out.push(prefix);
  }
  return out;
}

const base = read('en.json');
const baseKeys = leaves(base);
const locales = readdirSync(I18N_DIR)
  .filter((f) => f.endsWith('.json') && f !== 'en.json')
  .sort();

console.log(`en.json — ${baseKeys.length} keys (source of truth)\n`);

let incomplete = 0;
for (const file of locales) {
  const keys = new Set(leaves(read(file)));
  const missing = baseKeys.filter((k) => !keys.has(k));
  const extra = [...keys].filter((k) => !baseKeys.includes(k));
  const done = baseKeys.length - missing.length;
  const pct = Math.round((done / baseKeys.length) * 100);

  console.log(`${file} — ${done}/${baseKeys.length} (${pct}%)`);
  if (missing.length) {
    incomplete++;
    console.log(`  missing (falls back to English):`);
    for (const key of missing) console.log(`    ${key}`);
  }
  if (extra.length) {
    console.log(`  unknown keys (typo, or left over from a removed feature):`);
    for (const key of extra) console.log(`    ${key}`);
  }
  console.log();
}

if (strict && incomplete) {
  console.error(`${incomplete} locale(s) incomplete — failing because --strict was passed.`);
  process.exit(1);
}
