# Island Survival

A 3D survival game that runs entirely in the browser, built with Three.js, Rapier physics and TypeScript on Vite.

**Play it: [forest.angelov.gr](https://forest.angelov.gr)**

You wash up on an island. Gather and craft, build a shelter, hunt wildlife, and survive the things that come out at night.

## Features

- **Survival loop.** Hunger, thirst and energy stats, resource harvesting, campfires, cooking, boiling water, and sleeping through the night.
- **The Backpack.** Inventory and crafting are one diegetic screen: your pack unrolls like a cloth with items as 3D objects on it, and you craft by dragging them into the circle. Rendered as a depth-cleared overlay, so nothing in the world can ever poke through it.
- **Building, in storeys.** Foundations, walls, doors, windows and roofs with snap placement, plus floors and stairs for a second floor. Storage chests with their own inventory, bed respawn points, repair and demolition. `B` opens a notebook listing every build piece and every crafting recipe.
- **Wildlife and combat.** Huntable animals, wolf packs, a craftable bow, a stone knife that doubles hide from skinning, hide armor, bandages, and a wooden shield you raise with right-click to block.
- **The Hollow Ones.** Nocturnal enemies that stalk you in the dark but fear fire — a lit torch carries that safety with you.
- **Quests and XP.** Goal tracking with levels that grant damage and stamina perks.
- **Raid nights.** Every fifth night enemies assault your base. Each structure type has its own HP, and you repair damage to keep the walls standing.
- **Honest simulation.** Enemies can't hit you through walls (line of sight checks), and harvested bushes regrow over time.
- **Saves.** Auto-save every 2 minutes to localStorage across 3 slots. Cloud saves are planned.
- **Audio.** Every sound is keyed to an id in SOUNDS.md and synthesized procedurally for now; dropping `public/assets/audio/<id>.ogg` into place swaps in the real recording with no code change. Ambience loops are the exception — they stay silent until recorded rather than hum synthetically forever.
- **English and Greek.** Switch language in Settings and the whole UI changes instantly, no reload. Each language is its own lazily-loaded chunk, and translations may be partial — anything missing falls back to English. See [TRANSLATING.md](TRANSLATING.md) to add one.

## Controls

| Key | Action |
| --- | --- |
| WASD / Mouse | Move / look |
| Shift / Space | Sprint / jump |
| E / Click | Gather, hit, interact |
| Right-click | Raise shield (block) |
| Tab | Backpack (inventory and crafting) |
| B | Build notebook (pieces and recipes) |
| R | Rotate ghost / sleep by a fire |
| Q | Cancel placement |
| X | Demolish |
| H / J | Help / quests and XP |
| 1-8 | Use, place or equip hotbar item |
| Esc | Cancel what's open — pause only when nothing is |
| F3 | Physics debug view |

## Running locally

```bash
pnpm install
pnpm dev            # open localhost:5173 and click to play
pnpm build          # typecheck + production build
pnpm i18n:check     # translation coverage per language
```

Deployed with Docker on [Coolify](https://coolify.io), auto-deploying from `main`.

## Project docs

- **PLAN.md** for the phased roadmap and task breakdown
- **LORE.md** for story, enemies and progression design
- **TRANSLATING.md** for adding a language
- **CLAUDE.md** for project context
