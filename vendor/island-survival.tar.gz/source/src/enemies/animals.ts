/**
 * Wildlife (PLAN Phase 5α): rabbits & deer (prey — flee), boars (neutral —
 * retaliate when hit), wolves (night pack hunters, afraid of campfires).
 *
 * AI is a small FSM (idle → wander → flee/chase → attack) with cheap
 * steering: animals walk on the analytic terrain surface and turn away from
 * steep slopes and water — no physics bodies, no navmesh (per PLAN).
 *
 * Animals are transient runtime entities, NOT saved in GameState: the
 * population repopulates deterministically-enough from spawn rules on load.
 * Loot and player damage still flow through the action bus.
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { ActionBus } from '../core/actions';
import { isNight } from '../core/GameState';
import type { System } from '../core/loop';
import type { Terrain } from '../world/terrain';
import type { Structures } from '../building/structures';
import { mulberry32 } from '../world/rng';
import { SKINNING_KNIFE, type ItemId } from '../survival/items';
import { HealthBar } from './healthBar';
import { disposeObject3D } from '../core/three-utils';

export type AnimalKind = 'rabbit' | 'deer' | 'boar' | 'wolf';
type AnimalState = 'idle' | 'wander' | 'flee' | 'chase' | 'dead';

interface AnimalDef {
  hp: number;
  walkSpeed: number;
  runSpeed: number;
  /** Prey: distance that triggers fleeing. Wolf: aggro radius. */
  triggerRadius: number;
  attackDamage: number;
  attackRange: number;
  attackCooldown: number;
  giveUpRange: number;
  loot: Array<{ itemId: ItemId; count: number }>;
  cap: number;
  nightOnly: boolean;
  /** Terrain band the kind spawns in (biotope). */
  spawnHeight: [number, number];
  /** Health bar hover height. */
  barHeight: number;
}

const DEFS: Record<AnimalKind, AnimalDef> = {
  rabbit: {
    hp: 12, walkSpeed: 1.3, runSpeed: 5.2, triggerRadius: 9,
    attackDamage: 0, attackRange: 0, attackCooldown: 0, giveUpRange: 0,
    loot: [{ itemId: 'meat_raw', count: 1 }],
    cap: 10, nightOnly: false, spawnHeight: [1.5, 12], barHeight: 0.75,
  },
  deer: {
    hp: 35, walkSpeed: 1.7, runSpeed: 6.6, triggerRadius: 13,
    attackDamage: 0, attackRange: 0, attackCooldown: 0, giveUpRange: 0,
    loot: [{ itemId: 'meat_raw', count: 2 }, { itemId: 'hide', count: 1 }],
    cap: 8, nightOnly: false, spawnHeight: [2.5, 20], barHeight: 2.0,
  },
  boar: {
    hp: 55, walkSpeed: 1.4, runSpeed: 6.0, triggerRadius: 0,
    attackDamage: 12, attackRange: 1.9, attackCooldown: 1.3, giveUpRange: 32,
    loot: [{ itemId: 'meat_raw', count: 2 }, { itemId: 'hide', count: 1 }],
    cap: 6, nightOnly: false, spawnHeight: [2.5, 22], barHeight: 1.2,
  },
  wolf: {
    hp: 40, walkSpeed: 1.9, runSpeed: 6.9, triggerRadius: 26,
    attackDamage: 9, attackRange: 1.8, attackCooldown: 1.1, giveUpRange: 45,
    loot: [{ itemId: 'meat_raw', count: 1 }, { itemId: 'hide', count: 1 }],
    cap: 3, nightOnly: true, spawnHeight: [2, 24], barHeight: 1.35,
  },
};

/** Wolves will not step closer than this to a campfire (LORE: fear of fire). */
const FIRE_FEAR_RADIUS = 8;
const PASSIVE_RESPAWN_INTERVAL = 45; // seconds between top-up attempts
const DEAD_DESPAWN_TIME = 1.8;

interface Animal {
  id: string;
  kind: AnimalKind;
  pos: THREE.Vector3;
  yaw: number;
  hp: number;
  state: AnimalState;
  stateTimer: number;
  attackTimer: number;
  flashTimer: number;
  deadTimer: number;
  moving: boolean;
  bobPhase: number;
  mesh: THREE.Group;
  flashMats: THREE.MeshStandardMaterial[];
  healthBar: HealthBar;
}

function buildAnimalMesh(kind: AnimalKind): { group: THREE.Group; mats: THREE.MeshStandardMaterial[] } {
  const mats: THREE.MeshStandardMaterial[] = [];
  const mat = (color: number) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: 1, flatShading: true });
    mats.push(m);
    return m;
  };
  const g = new THREE.Group();
  const add = (geo: THREE.BufferGeometry, m: THREE.MeshStandardMaterial, x: number, y: number, z: number) => {
    const mesh = new THREE.Mesh(geo, m);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    g.add(mesh);
    return mesh;
  };

  switch (kind) {
    case 'rabbit': {
      const fur = mat(0xb08d63);
      add(new THREE.SphereGeometry(0.16, 6, 5).scale(1.3, 1, 1), fur, 0, 0.16, 0);
      add(new THREE.SphereGeometry(0.1, 6, 5), fur, 0.2, 0.24, 0);
      add(new THREE.BoxGeometry(0.03, 0.16, 0.05), fur, 0.24, 0.38, 0.04);
      add(new THREE.BoxGeometry(0.03, 0.16, 0.05), fur, 0.24, 0.38, -0.04);
      break;
    }
    case 'deer': {
      const fur = mat(0xa8815a);
      add(new THREE.BoxGeometry(0.95, 0.5, 0.42), fur, 0, 0.85, 0);
      for (const [x, z] of [[-0.35, -0.14], [0.35, -0.14], [-0.35, 0.14], [0.35, 0.14]]) {
        add(new THREE.BoxGeometry(0.09, 0.65, 0.09), fur, x, 0.32, z);
      }
      const neck = add(new THREE.BoxGeometry(0.16, 0.5, 0.16), fur, 0.5, 1.25, 0);
      neck.rotation.z = -0.5;
      add(new THREE.BoxGeometry(0.3, 0.16, 0.16), fur, 0.68, 1.5, 0);
      const antler = mat(0x6b4a2b);
      add(new THREE.BoxGeometry(0.04, 0.22, 0.04), antler, 0.62, 1.68, 0.07);
      add(new THREE.BoxGeometry(0.04, 0.22, 0.04), antler, 0.62, 1.68, -0.07);
      break;
    }
    case 'boar': {
      const fur = mat(0x5a4633);
      add(new THREE.BoxGeometry(0.9, 0.52, 0.48), fur, 0, 0.48, 0);
      for (const [x, z] of [[-0.3, -0.15], [0.3, -0.15], [-0.3, 0.15], [0.3, 0.15]]) {
        add(new THREE.BoxGeometry(0.1, 0.35, 0.1), fur, x, 0.17, z);
      }
      add(new THREE.BoxGeometry(0.3, 0.32, 0.34), fur, 0.55, 0.45, 0);
      add(new THREE.BoxGeometry(0.12, 0.12, 0.14), mat(0x8f7a68), 0.74, 0.38, 0);
      break;
    }
    case 'wolf': {
      const fur = mat(0x8a8f96);
      add(new THREE.BoxGeometry(0.85, 0.42, 0.36), fur, 0, 0.62, 0);
      for (const [x, z] of [[-0.3, -0.12], [0.3, -0.12], [-0.3, 0.12], [0.3, 0.12]]) {
        add(new THREE.BoxGeometry(0.08, 0.45, 0.08), fur, x, 0.22, z);
      }
      add(new THREE.BoxGeometry(0.28, 0.24, 0.24), fur, 0.52, 0.72, 0);
      add(new THREE.BoxGeometry(0.16, 0.1, 0.12), fur, 0.7, 0.66, 0);
      const tail = add(new THREE.BoxGeometry(0.35, 0.09, 0.09), fur, -0.52, 0.72, 0);
      tail.rotation.z = 0.4;
      add(new THREE.BoxGeometry(0.05, 0.09, 0.05), fur, 0.44, 0.9, 0.08);
      add(new THREE.BoxGeometry(0.05, 0.09, 0.05), fur, 0.44, 0.9, -0.08);
      break;
    }
  }
  return { group: g, mats };
}

export class AnimalSystem implements System {
  readonly group = new THREE.Group();
  onPlayerHit: (() => void) | null = null;
  onKill: ((kind: AnimalKind) => void) | null = null;
  /** Mobile firelight (the player's lit torch), or null. Set by main. */
  litTorch: { x: number; z: number } | null = null;
  /** Shield check: given the attacker's position, is this hit blocked? Set by main. */
  playerBlock: ((x: number, z: number) => boolean) | null = null;
  onBlocked: (() => void) | null = null;

  private animals = new Map<string, Animal>();
  private nextId = 0;
  private rand: () => number;
  private respawnTimer = 0;
  private tmp = new THREE.Vector3();

  constructor(
    private terrain: Terrain,
    private structures: Structures,
    private bus: ActionBus,
    seed: number,
    private rapier: typeof RAPIER,
    private physicsWorld: RAPIER.World,
  ) {
    this.rand = mulberry32(seed ^ 0x3010f);
    // Initial population, away from the player's start.
    for (const kind of ['rabbit', 'deer', 'boar'] as AnimalKind[]) {
      for (let i = 0; i < DEFS[kind].cap; i++) this.trySpawn(kind, 25, 240);
    }
  }

  /** Fixed-timestep AI. */
  update(dt: number): void {
    const [px, , pz] = this.bus.state.player.pos;
    const night = isNight(this.bus.state);

    this.respawnTimer += dt;
    if (this.respawnTimer >= PASSIVE_RESPAWN_INTERVAL) {
      this.respawnTimer = 0;
      this.topUpPopulation(night);
    }

    for (const animal of this.animals.values()) {
      const def = DEFS[animal.kind];
      animal.stateTimer -= dt;
      animal.attackTimer = Math.max(0, animal.attackTimer - dt);

      if (animal.state === 'dead') {
        animal.deadTimer -= dt;
        if (animal.deadTimer <= 0) this.despawn(animal.id);
        continue;
      }

      // Wolves melt away at dawn.
      if (def.nightOnly && !night) {
        this.kill(animal, false);
        continue;
      }

      const distToPlayer = Math.hypot(animal.pos.x - px, animal.pos.z - pz);
      this.think(animal, def, distToPlayer, px, pz);
      this.move(animal, def, dt, px, pz);
    }
  }

  /** Per render frame: sync meshes, bob, flash, health bars, death sink. */
  updateVisual(dt: number, camera: THREE.Camera): void {
    for (const animal of this.animals.values()) {
      animal.healthBar.update(dt, camera);
      const mesh = animal.mesh;
      mesh.position.copy(animal.pos);
      if (animal.state === 'dead') {
        mesh.rotation.z += dt * 2.2 * (mesh.rotation.z < 1.4 ? 1 : 0);
        mesh.position.y = animal.pos.y - (DEAD_DESPAWN_TIME - animal.deadTimer) * 0.15;
      } else if (animal.moving) {
        animal.bobPhase += dt * (animal.state === 'flee' || animal.state === 'chase' ? 14 : 7);
        mesh.position.y = animal.pos.y + Math.abs(Math.sin(animal.bobPhase)) * 0.07;
      }
      let dy = animal.yaw - mesh.rotation.y;
      dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      mesh.rotation.y += dy * Math.min(1, dt * 8);

      if (animal.flashTimer > 0) {
        animal.flashTimer -= dt;
        const k = Math.max(0, animal.flashTimer / 0.25);
        for (const m of animal.flashMats) m.emissive.setRGB(k * 0.8, 0, 0);
      }
    }
  }

  /** Best living animal in the aim cone, for the interaction raycast. */
  findTarget(eye: THREE.Vector3, dir: THREE.Vector3, range = 3.2): { id: string; kind: AnimalKind } | null {
    let best: Animal | null = null;
    let bestDist = range;
    for (const animal of this.animals.values()) {
      if (animal.state === 'dead') continue;
      this.tmp.copy(animal.pos).setY(animal.pos.y + 0.5).sub(eye);
      const dist = this.tmp.length();
      if (dist > bestDist) continue;
      this.tmp.normalize();
      if (this.tmp.dot(dir) < 0.9) continue;
      best = animal;
      bestDist = dist;
    }
    return best ? { id: best.id, kind: best.kind } : null;
  }

  /** Nearest living animal within `radius` of a point (arrow impacts). */
  hitTest(point: THREE.Vector3, radius: number): string | null {
    for (const animal of this.animals.values()) {
      if (animal.state === 'dead') continue;
      this.tmp.copy(animal.pos);
      this.tmp.y += 0.5;
      if (this.tmp.distanceTo(point) < radius) return animal.id;
    }
    return null;
  }

  /** Horizontal probe: a solid collider (wall, tree trunk) within a step ahead. */
  /** Distance to the nearest firelight — placed campfires or the held torch. */
  private fireDistance(x: number, z: number): number {
    let d = this.structures.nearestDistance(x, z, ['campfire']);
    if (this.litTorch) d = Math.min(d, Math.hypot(x - this.litTorch.x, z - this.litTorch.z));
    return d;
  }

  private solidAhead(pos: THREE.Vector3, yaw: number): boolean {
    const ray = new this.rapier.Ray(
      { x: pos.x, y: pos.y + 0.55, z: pos.z },
      { x: Math.sin(yaw), y: 0, z: Math.cos(yaw) },
    );
    return (
      this.physicsWorld.castRay(ray, 0.9, true, this.rapier.QueryFilterFlags.EXCLUDE_SENSORS) !== null
    );
  }

  /** Nothing solid (wall, tree, terrain) between attacker and player. */
  private hasLineOfSight(from: THREE.Vector3, px: number, py: number, pz: number): boolean {
    const dist = Math.hypot(px - from.x, py - from.y, pz - from.z);
    if (dist < 0.5) return true;
    this.tmp.set((px - from.x) / dist, (py - from.y) / dist, (pz - from.z) / dist);
    const ray = new this.rapier.Ray(
      { x: from.x, y: from.y + 0.6, z: from.z },
      { x: this.tmp.x, y: this.tmp.y, z: this.tmp.z },
    );
    return this.physicsWorld.castRay(ray, dist - 0.45, true) === null;
  }

  damage(id: string, amount: number): void {
    const animal = this.animals.get(id);
    if (!animal || animal.state === 'dead') return;
    animal.hp -= amount;
    animal.flashTimer = 0.25;
    animal.healthBar.ping(animal.hp / DEFS[animal.kind].hp);
    if (animal.hp <= 0) {
      this.kill(animal, true);
      return;
    }
    // Hit reaction: shove away from the player.
    const [px, , pz] = this.bus.state.player.pos;
    this.tmp.set(animal.pos.x - px, 0, animal.pos.z - pz);
    if (this.tmp.lengthSq() > 0) {
      this.tmp.normalize().multiplyScalar(0.6);
      animal.pos.x += this.tmp.x;
      animal.pos.z += this.tmp.z;
      animal.pos.y = this.terrain.heightAt(animal.pos.x, animal.pos.z);
    }
    // Prey bolts; boars and wolves turn on you.
    animal.state = DEFS[animal.kind].attackDamage > 0 ? 'chase' : 'flee';
    animal.stateTimer = 6;
  }

  private kill(animal: Animal, withLoot: boolean): void {
    animal.state = 'dead';
    animal.deadTimer = DEAD_DESPAWN_TIME;
    if (!withLoot) {
      animal.deadTimer = 0.4; // dawn despawn: quick fade, no loot
      return;
    }
    const skinning = this.bus.state.player.equippedWeapon === SKINNING_KNIFE;
    for (const drop of DEFS[animal.kind].loot) {
      // A stone knife in hand doubles the hide yield (skinning).
      const count = drop.itemId === 'hide' && skinning ? drop.count * 2 : drop.count;
      this.bus.dispatch({ type: 'ADD_ITEM', itemId: drop.itemId, count });
    }
    this.onKill?.(animal.kind);
  }

  // ---------- AI ----------

  private think(animal: Animal, def: AnimalDef, distToPlayer: number, px: number, pz: number): void {
    switch (animal.state) {
      case 'idle':
      case 'wander':
        if (def.attackDamage === 0 && distToPlayer < def.triggerRadius) {
          animal.state = 'flee';
          animal.stateTimer = 4;
        } else if (animal.kind === 'wolf' && distToPlayer < def.triggerRadius) {
          animal.state = 'chase';
          animal.stateTimer = 10;
        } else if (animal.stateTimer <= 0) {
          animal.state = animal.state === 'idle' ? 'wander' : 'idle';
          animal.stateTimer = 2 + this.rand() * 4;
          if (animal.state === 'wander') animal.yaw = this.rand() * Math.PI * 2;
        }
        break;

      case 'flee':
        animal.yaw = Math.atan2(animal.pos.x - px, animal.pos.z - pz);
        if (distToPlayer > def.triggerRadius * 2.5 && animal.stateTimer <= 0) {
          animal.state = 'idle';
          animal.stateTimer = 1 + this.rand() * 2;
        }
        break;

      case 'chase': {
        if (distToPlayer > def.giveUpRange || (animal.stateTimer <= 0 && distToPlayer > 12)) {
          animal.state = 'wander';
          animal.stateTimer = 3;
          break;
        }
        animal.yaw = Math.atan2(px - animal.pos.x, pz - animal.pos.z);
        if (distToPlayer < def.attackRange && animal.attackTimer === 0) {
          // No biting through walls: a solid obstacle between blocks the hit.
          const py = this.bus.state.player.pos[1] + 0.6;
          if (this.hasLineOfSight(animal.pos, px, py, pz)) {
            animal.attackTimer = def.attackCooldown;
            if (this.playerBlock?.(animal.pos.x, animal.pos.z)) {
              this.onBlocked?.();
            } else {
              this.bus.dispatch({ type: 'HURT_PLAYER', amount: def.attackDamage });
              this.onPlayerHit?.();
            }
          }
        }
        break;
      }
    }
  }

  private move(animal: Animal, def: AnimalDef, dt: number, px: number, pz: number): void {
    let speed = 0;
    if (animal.state === 'wander') speed = def.walkSpeed;
    else if (animal.state === 'flee') speed = def.runSpeed;
    else if (animal.state === 'chase') {
      const dist = Math.hypot(animal.pos.x - px, animal.pos.z - pz);
      speed = dist > def.attackRange * 0.85 ? def.runSpeed : 0;
    }
    animal.moving = speed > 0;
    if (speed === 0) return;

    // yaw convention: forward = (sin(yaw), cos(yaw)) — matches Math.atan2(dx, dz).
    let stepX = Math.sin(animal.yaw) * speed * dt;
    let stepZ = Math.cos(animal.yaw) * speed * dt;
    const nx = animal.pos.x + stepX * 8; // probe ahead
    const nz = animal.pos.z + stepZ * 8;

    // Slope/water avoidance, solid obstacles (walls, trees — animals must
    // not phase through geometry), and wolves refuse to approach campfires.
    const blocked =
      this.terrain.slopeAt(nx, nz) > 0.75 ||
      this.terrain.heightAt(nx, nz) < 0.6 ||
      this.solidAhead(animal.pos, animal.yaw) ||
      (animal.kind === 'wolf' && this.fireDistance(nx, nz) < FIRE_FEAR_RADIUS);
    if (blocked) {
      if (animal.state === 'chase') {
        animal.moving = false; // wolf pacing at the firelight's edge
        return;
      }
      animal.yaw += (this.rand() > 0.5 ? 1 : -1) * (Math.PI / 2 + this.rand());
      stepX = Math.sin(animal.yaw) * speed * dt;
      stepZ = Math.cos(animal.yaw) * speed * dt;
    }

    animal.pos.x += stepX;
    animal.pos.z += stepZ;
    animal.pos.y = this.terrain.heightAt(animal.pos.x, animal.pos.z);
  }

  // ---------- spawning ----------

  private topUpPopulation(night: boolean): void {
    for (const kind of Object.keys(DEFS) as AnimalKind[]) {
      const def = DEFS[kind];
      if (def.nightOnly && !night) continue;
      const alive = [...this.animals.values()].filter(
        (a) => a.kind === kind && a.state !== 'dead',
      ).length;
      if (alive < def.cap) {
        // Wolves materialize closer, out of sight; prey far away.
        if (def.nightOnly) this.trySpawn(kind, 30, 55);
        else this.trySpawn(kind, 60, 130);
      }
    }
  }

  private trySpawn(kind: AnimalKind, minDist: number, maxDist: number): void {
    const def = DEFS[kind];
    const [px, , pz] = this.bus.state.player.pos;
    for (let attempt = 0; attempt < 12; attempt++) {
      const angle = this.rand() * Math.PI * 2;
      const dist = minDist + this.rand() * (maxDist - minDist);
      const x = px + Math.sin(angle) * dist;
      const z = pz + Math.cos(angle) * dist;
      const h = this.terrain.heightAt(x, z);
      if (h < def.spawnHeight[0] || h > def.spawnHeight[1]) continue;
      if (this.terrain.slopeAt(x, z) > 0.6) continue;
      const { group, mats } = buildAnimalMesh(kind);
      const healthBar = new HealthBar();
      healthBar.group.position.y = def.barHeight;
      group.add(healthBar.group);
      const animal: Animal = {
        id: `${kind}_${this.nextId++}`,
        kind,
        pos: new THREE.Vector3(x, h, z),
        yaw: this.rand() * Math.PI * 2,
        hp: def.hp,
        state: 'idle',
        stateTimer: this.rand() * 3,
        attackTimer: 0,
        flashTimer: 0,
        deadTimer: 0,
        moving: false,
        bobPhase: 0,
        mesh: group,
        flashMats: mats,
        healthBar,
      };
      group.position.copy(animal.pos);
      this.group.add(group);
      this.animals.set(animal.id, animal);
      return;
    }
  }

  private despawn(id: string): void {
    const animal = this.animals.get(id);
    if (!animal) return;
    this.group.remove(animal.mesh);
    // Frees the animal's geometries/materials AND its child health bar —
    // otherwise every dawn wolf-cull and every hunt leaks GPU memory.
    disposeObject3D(animal.mesh);
    this.animals.delete(id);
  }
}
