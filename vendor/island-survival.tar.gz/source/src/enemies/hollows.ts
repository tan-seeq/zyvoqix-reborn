/**
 * Οι «Κούφιοι» — Hollow Ones (PLAN Phase 5β, LORE.md).
 *
 * Night-only horrors that emerge from cave mouths and behave nothing like
 * wildlife: they STALK first — holding a ring at the edge of vision, circling
 * slowly, freezing when you look straight at them; stare too long and they
 * dissolve, repositioning somewhere you are not watching. They only close in
 * when they feel bold (escalation) or when you stray far from firelight, and
 * they never step within the glow of a campfire.
 *
 * Escalation (LORE: «κάθε finding δυναμώνει το σήμα»): the number active at
 * night and their boldness scale with collected lore findings (Phase 6 will
 * start feeding those; today findings = 0 → a single stalker, timid).
 *
 * Hollows are transient runtime entities like wildlife; damage to the player
 * flows through the action bus. They drop nothing — they dissolve.
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { ActionBus } from '../core/actions';
import { isNight, RAID_NIGHT_INTERVAL } from '../core/GameState';
import type { System } from '../core/loop';
import type { Terrain } from '../world/terrain';
import type { Structures } from '../building/structures';
import type { CaveMouths } from '../world/caves';
import { mulberry32 } from '../world/rng';
import { HealthBar } from './healthBar';
import { disposeObject3D } from '../core/three-utils';

type HollowState = 'emerge' | 'stalk' | 'approach' | 'frozen' | 'smash' | 'dissolve';

const HP = 70;
const STALK_SPEED = 2.0;
const APPROACH_SPEED = 3.6;
const ATTACK_RANGE = 1.9;
const ATTACK_DAMAGE = 14;
const ATTACK_COOLDOWN = 1.4;
const FIRE_FEAR_RADIUS = 9;
const STALK_RING_MIN = 15;
const STALK_RING_MAX = 24;
const WATCH_DOT = 0.94;
const WATCH_DISSOLVE_SECONDS = 1.6;
const DISSOLVE_SECONDS = 0.6;
const MAX_ACTIVE = 4;

interface Hollow {
  id: string;
  pos: THREE.Vector3;
  yaw: number;
  hp: number;
  state: HollowState;
  stateTimer: number;
  attackTimer: number;
  watchedTimer: number;
  flashTimer: number;
  /** dissolve bookkeeping: fade out, then either despawn or reposition. */
  dissolveTimer: number;
  repositionAfterDissolve: boolean;
  circleDir: 1 | -1;
  /** Raid-night spawns skip stalking and go for the base. */
  raider: boolean;
  /** Structure currently being smashed (raid / blocked path). */
  targetStructureId: string | null;
  moving: boolean;
  swayPhase: number;
  mesh: THREE.Group;
  mats: THREE.MeshStandardMaterial[];
  healthBar: HealthBar;
}

function buildHollowMesh(): { group: THREE.Group; mats: THREE.MeshStandardMaterial[] } {
  const mats: THREE.MeshStandardMaterial[] = [];
  const mat = (color: number) => {
    const m = new THREE.MeshStandardMaterial({
      color,
      roughness: 0.95,
      flatShading: true,
      transparent: true, // for dissolve fades
    });
    mats.push(m);
    return m;
  };
  const g = new THREE.Group();
  const pale = mat(0xcfd3cc);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.85, 0.24), pale);
  torso.position.set(0, 1.15, 0);
  torso.rotation.x = 0.22; // hunched
  torso.castShadow = true;

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 7, 6), pale);
  head.position.set(0, 1.72, 0.12);
  head.scale.set(0.9, 1.15, 0.95);
  head.castShadow = true;

  const socketMat = mat(0x14161a);
  for (const sx of [-0.06, 0.06]) {
    const socket = new THREE.Mesh(new THREE.SphereGeometry(0.028, 5, 4), socketMat);
    socket.position.set(sx, 1.74, 0.25);
    g.add(socket);
  }

  for (const sx of [-0.26, 0.26]) {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.95, 5), pale);
    arm.position.set(sx, 1.0, 0.08);
    arm.rotation.x = 0.15;
    arm.castShadow = true;
    g.add(arm);
  }
  for (const sx of [-0.11, 0.11]) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.8, 5), pale);
    leg.position.set(sx, 0.4, 0);
    leg.castShadow = true;
    g.add(leg);
  }

  g.add(torso, head);
  return { group: g, mats };
}

export class HollowSystem implements System {
  readonly group = new THREE.Group();
  onPlayerHit: (() => void) | null = null;
  /** Fired once per night, when the first stalker takes position. */
  onFirstStalk: (() => void) | null = null;
  /** Fired at nightfall of a raid night. */
  onRaidStart: (() => void) | null = null;
  /** Fired when the player fells one (not on dawn dissolves). */
  onKill: (() => void) | null = null;
  /** Mobile firelight (the player's lit torch), or null. Set by main. */
  litTorch: { x: number; z: number } | null = null;
  /** Shield check: given the attacker's position, is this hit blocked? Set by main. */
  playerBlock: ((x: number, z: number) => boolean) | null = null;
  onBlocked: (() => void) | null = null;

  private hollows = new Map<string, Hollow>();
  private nextId = 0;
  private rand: () => number;
  private spawnTimer = 0;
  private stalkNotifiedTonight = false;
  private wasNight = false;
  private tmp = new THREE.Vector3();

  constructor(
    private terrain: Terrain,
    private structures: Structures,
    private caves: CaveMouths,
    private bus: ActionBus,
    seed: number,
    private rapier: typeof RAPIER,
    private physicsWorld: RAPIER.World,
  ) {
    this.rand = mulberry32(seed ^ 0x4011);
  }

  update(dt: number): void {
    const night = isNight(this.bus.state);
    if (night && !this.wasNight) {
      this.stalkNotifiedTonight = false;
      // Raid night: every Nth day, if the player has built anything.
      if (
        this.bus.state.day % RAID_NIGHT_INTERVAL === 0 &&
        this.bus.state.world.placedObjects.length > 0
      ) {
        const findings = this.bus.state.lore.collectedFindings.length;
        const raiders = Math.min(MAX_ACTIVE, 2 + Math.floor(findings / 2));
        const [rx, , rz] = this.bus.state.player.pos;
        for (let i = 0; i < raiders; i++) this.spawn(rx, rz, true);
        this.onRaidStart?.();
      }
    }
    this.wasNight = night;

    const [px, , pz] = this.bus.state.player.pos;

    if (!night) {
      for (const h of this.hollows.values()) {
        if (h.state !== 'dissolve') this.startDissolve(h, false);
      }
    } else {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = 8 + this.rand() * 10;
        const active = [...this.hollows.values()].filter((h) => h.state !== 'dissolve').length;
        if (active < this.desiredCount()) this.spawn(px, pz);
      }
    }

    for (const h of this.hollows.values()) {
      h.stateTimer -= dt;
      h.attackTimer = Math.max(0, h.attackTimer - dt);

      if (h.state === 'dissolve') {
        h.dissolveTimer -= dt;
        if (h.dissolveTimer <= 0) {
          if (h.repositionAfterDissolve && isNight(this.bus.state)) this.reposition(h, px, pz);
          else this.despawn(h.id);
        }
        continue;
      }

      this.think(h, dt, px, pz);
    }
  }

  updateVisual(dt: number, camera: THREE.Camera): void {
    for (const h of this.hollows.values()) {
      const mesh = h.mesh;
      mesh.position.copy(h.pos);
      h.swayPhase += dt * (h.moving ? 5 : 1.2);
      mesh.rotation.z = Math.sin(h.swayPhase) * 0.05; // uncanny idle sway
      let dy = h.yaw - mesh.rotation.y;
      dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      mesh.rotation.y += dy * Math.min(1, dt * 6);

      if (h.state === 'dissolve') {
        const k = Math.max(0, h.dissolveTimer / DISSOLVE_SECONDS);
        for (const m of h.mats) m.opacity = k;
      } else if (h.flashTimer > 0) {
        h.flashTimer -= dt;
        const k = Math.max(0, h.flashTimer / 0.25);
        for (const m of h.mats) m.emissive.setRGB(k * 0.7, 0, 0);
      }
      h.healthBar.update(dt, camera);
    }
  }

  /** Nearest living hollow within `radius` of a point (arrow impacts). */
  hitTest(point: THREE.Vector3, radius: number): string | null {
    for (const h of this.hollows.values()) {
      if (h.state === 'dissolve') continue;
      this.tmp.copy(h.pos);
      this.tmp.y += 1.1;
      if (this.tmp.distanceTo(point) < radius) return h.id;
    }
    return null;
  }

  findTarget(eye: THREE.Vector3, dir: THREE.Vector3, range = 3.2): { id: string } | null {
    let best: Hollow | null = null;
    let bestDist = range;
    for (const h of this.hollows.values()) {
      if (h.state === 'dissolve') continue;
      this.tmp.copy(h.pos).setY(h.pos.y + 1.1).sub(eye);
      const dist = this.tmp.length();
      if (dist > bestDist) continue;
      this.tmp.normalize();
      if (this.tmp.dot(dir) < 0.9) continue;
      best = h;
      bestDist = dist;
    }
    return best ? { id: best.id } : null;
  }

  damage(id: string, amount: number, fromX: number, fromZ: number): void {
    const h = this.hollows.get(id);
    if (!h || h.state === 'dissolve') return;
    h.hp -= amount;
    h.flashTimer = 0.25;
    h.healthBar.ping(h.hp / HP);
    if (h.hp <= 0) {
      this.onKill?.();
      this.startDissolve(h, false);
      return;
    }
    // Knockback + it stops pretending: straight to approach.
    const kb = this.tmp.set(h.pos.x - fromX, 0, h.pos.z - fromZ);
    if (kb.lengthSq() > 0) {
      kb.normalize().multiplyScalar(0.7);
      h.pos.x += kb.x;
      h.pos.z += kb.z;
      h.pos.y = this.terrain.heightAt(h.pos.x, h.pos.z);
    }
    h.state = 'approach';
    h.stateTimer = 20;
  }

  // ---------- AI ----------

  private desiredCount(): number {
    const findings = this.bus.state.lore.collectedFindings.length;
    return Math.min(MAX_ACTIVE, 1 + Math.floor(findings / 2));
  }

  /** Boldness 0..1 — scales with lore findings (the signal strengthens). */
  private boldness(): number {
    return Math.min(1, this.bus.state.lore.collectedFindings.length / 6);
  }

  private think(h: Hollow, dt: number, px: number, pz: number): void {
    const dist = Math.hypot(h.pos.x - px, h.pos.z - pz);
    const playerYaw = this.bus.state.player.yaw;
    // Is the player looking straight at this hollow?
    const toH = this.tmp.set(h.pos.x - px, 0, h.pos.z - pz).normalize();
    const watched = dist < 40 && toH.dot(new THREE.Vector3(-Math.sin(playerYaw), 0, -Math.cos(playerYaw))) > WATCH_DOT;

    switch (h.state) {
      case 'emerge':
        h.yaw = Math.atan2(px - h.pos.x, pz - h.pos.z);
        this.step(h, h.raider ? APPROACH_SPEED : STALK_SPEED, dt);
        if (h.raider && dist < 45) {
          // Raiders go straight for the base.
          const target = this.structures.nearestStructureTo(px, pz, 45);
          if (target) {
            h.targetStructureId = target;
            h.state = 'smash';
          } else {
            h.state = 'approach';
            h.stateTimer = 60;
          }
          break;
        }
        if (dist < STALK_RING_MAX + 3) {
          h.state = 'stalk';
          h.stateTimer = (8 + this.rand() * 12) * (1 - this.boldness() * 0.6);
          if (!this.stalkNotifiedTonight) {
            this.stalkNotifiedTonight = true;
            this.onFirstStalk?.();
          }
        }
        break;

      case 'stalk': {
        if (watched) {
          h.state = 'frozen';
          h.watchedTimer = 0;
          break;
        }
        // Hold the ring: circle tangentially, drift to stay inside 15-24m.
        const tangent = Math.atan2(px - h.pos.x, pz - h.pos.z) + (Math.PI / 2) * h.circleDir;
        let drift = 0;
        if (dist > STALK_RING_MAX) drift = 0.5;
        else if (dist < STALK_RING_MIN) drift = -0.5;
        h.yaw = tangent + drift * h.circleDir;
        this.step(h, STALK_SPEED, dt);

        const playerNearFire =
          this.fireDistance(px, pz) < 12;
        if (h.stateTimer <= 0 && !playerNearFire) {
          h.state = 'approach';
          h.stateTimer = 25;
        } else if (h.stateTimer <= 0) {
          h.stateTimer = 6 + this.rand() * 8; // player in the light: keep waiting
          h.circleDir = this.rand() > 0.5 ? 1 : -1;
        }
        break;
      }

      case 'frozen':
        h.moving = false;
        h.yaw = Math.atan2(px - h.pos.x, pz - h.pos.z); // faces you, motionless
        if (!watched) {
          h.state = 'stalk';
          h.stateTimer = Math.max(2, h.stateTimer);
          break;
        }
        h.watchedTimer += dt;
        if (h.watchedTimer > WATCH_DISSOLVE_SECONDS) this.startDissolve(h, true);
        break;

      case 'approach': {
        h.yaw = Math.atan2(px - h.pos.x, pz - h.pos.z);
        if (h.stateTimer <= 0 && dist > 14) {
          h.state = 'stalk';
          h.stateTimer = 6 + this.rand() * 8;
          break;
        }
        if (dist < ATTACK_RANGE) {
          h.moving = false;
          if (h.attackTimer === 0) {
            const blocker = this.lineOfSightBlocker(h, px, pz);
            if (blocker === null) {
              h.attackTimer = ATTACK_COOLDOWN;
              if (this.playerBlock?.(h.pos.x, h.pos.z)) {
                this.onBlocked?.();
              } else {
                this.bus.dispatch({ type: 'HURT_PLAYER', amount: ATTACK_DAMAGE });
                this.onPlayerHit?.();
              }
            } else if (blocker) {
              // A wall stands between it and you — it turns on the wall.
              h.targetStructureId = blocker;
              h.state = 'smash';
            }
          }
        } else {
          this.step(h, APPROACH_SPEED, dt);
        }
        break;
      }

      case 'smash': {
        const targetPos = h.targetStructureId
          ? this.structures.positionOf(h.targetStructureId)
          : undefined;
        if (!targetPos) {
          // Destroyed (or demolished) — pick the next piece of the base, else the player.
          h.targetStructureId = this.structures.nearestStructureTo(h.pos.x, h.pos.z, 30);
          if (!h.targetStructureId) {
            h.state = 'approach';
            h.stateTimer = 30;
          }
          break;
        }
        const sd = Math.hypot(h.pos.x - targetPos.x, h.pos.z - targetPos.z);
        h.yaw = Math.atan2(targetPos.x - h.pos.x, targetPos.z - h.pos.z);
        if (sd < 2.4) {
          h.moving = false;
          if (h.attackTimer === 0) {
            h.attackTimer = ATTACK_COOLDOWN;
            this.bus.dispatch({
              type: 'DAMAGE_STRUCTURE', objectId: h.targetStructureId!, damage: 10,
            });
          }
        } else {
          this.step(h, APPROACH_SPEED, dt);
        }
        break;
      }
    }
  }

  /** Distance to the nearest firelight — placed campfires or the held torch. */
  private fireDistance(x: number, z: number): number {
    let d = this.structures.nearestDistance(x, z, ['campfire']);
    if (this.litTorch) d = Math.min(d, Math.hypot(x - this.litTorch.x, z - this.litTorch.z));
    return d;
  }

  /**
   * null = clear shot; a structure id = that structure blocks the hit;
   * '' = blocked by something unbreakable (terrain, tree).
   */
  private lineOfSightBlocker(h: Hollow, px: number, pz: number): string | null {
    const py = this.bus.state.player.pos[1] + 0.6;
    const from = { x: h.pos.x, y: h.pos.y + 1.2, z: h.pos.z };
    const dist = Math.hypot(px - from.x, py - from.y, pz - from.z);
    if (dist < 0.5) return null;
    const dir = { x: (px - from.x) / dist, y: (py - from.y) / dist, z: (pz - from.z) / dist };
    const hit = this.physicsWorld.castRay(new this.rapier.Ray(from, dir), dist - 0.45, true);
    if (!hit) return null;
    return this.structures.structureIdByColliderHandle(hit.collider.handle) ?? '';
  }

  /** Move forward along yaw with slope/water/fire/solid-obstacle avoidance. */
  private step(h: Hollow, speed: number, dt: number): void {
    let stepX = Math.sin(h.yaw) * speed * dt;
    let stepZ = Math.cos(h.yaw) * speed * dt;
    const nx = h.pos.x + stepX * 8;
    const nz = h.pos.z + stepZ * 8;

    // A wall in the way? It does not walk through — it turns on the wall.
    const wallRay = new this.rapier.Ray(
      { x: h.pos.x, y: h.pos.y + 1.0, z: h.pos.z },
      { x: Math.sin(h.yaw), y: 0, z: Math.cos(h.yaw) },
    );
    const solidHit = this.physicsWorld.castRay(
      wallRay, 0.9, true, this.rapier.QueryFilterFlags.EXCLUDE_SENSORS,
    );
    if (solidHit) {
      const structureId = this.structures.structureIdByColliderHandle(solidHit.collider.handle);
      if (structureId && h.state !== 'smash') {
        h.targetStructureId = structureId;
        h.state = 'smash';
        return;
      }
      h.moving = false;
      if (h.state !== 'smash') {
        h.yaw += (this.rand() > 0.5 ? 1 : -1) * (Math.PI / 2 + this.rand());
      }
      return;
    }

    const blocked =
      this.terrain.slopeAt(nx, nz) > 0.8 ||
      this.terrain.heightAt(nx, nz) < 0.6 ||
      this.fireDistance(nx, nz) < FIRE_FEAR_RADIUS;
    if (blocked) {
      if (h.state === 'approach') {
        h.moving = false; // pacing at the edge of the firelight
        return;
      }
      h.yaw += (this.rand() > 0.5 ? 1 : -1) * (Math.PI / 2 + this.rand());
      stepX = Math.sin(h.yaw) * speed * dt;
      stepZ = Math.cos(h.yaw) * speed * dt;
    }
    h.moving = true;
    h.pos.x += stepX;
    h.pos.z += stepZ;
    h.pos.y = this.terrain.heightAt(h.pos.x, h.pos.z);
  }

  // ---------- lifecycle ----------

  private spawn(px: number, pz: number, raider = false): void {
    // LORE: they come out of the cave mouths; raiders and cave-less areas
    // use the dark treeline instead.
    const cave = raider ? null : this.caves.nearestBeyond(px, pz, 25, 140);
    let x: number;
    let z: number;
    if (cave) {
      x = cave.x + (this.rand() - 0.5) * 4;
      z = cave.z + (this.rand() - 0.5) * 4;
    } else {
      const angle = this.rand() * Math.PI * 2;
      const dist = raider ? 28 + this.rand() * 10 : 35 + this.rand() * 15;
      x = px + Math.sin(angle) * dist;
      z = pz + Math.cos(angle) * dist;
    }
    const h = this.terrain.heightAt(x, z);
    if (h < 1 || this.terrain.slopeAt(x, z) > 0.7) return; // retry next window

    const { group, mats } = buildHollowMesh();
    const healthBar = new HealthBar();
    healthBar.group.position.y = 2.15;
    group.add(healthBar.group);

    const hollow: Hollow = {
      id: `hollow_${this.nextId++}`,
      pos: new THREE.Vector3(x, h, z),
      yaw: 0,
      hp: HP,
      state: 'emerge',
      stateTimer: 0,
      attackTimer: 0,
      watchedTimer: 0,
      flashTimer: 0,
      dissolveTimer: 0,
      repositionAfterDissolve: false,
      circleDir: this.rand() > 0.5 ? 1 : -1,
      raider,
      targetStructureId: null,
      moving: false,
      swayPhase: this.rand() * 10,
      mesh: group,
      mats,
      healthBar,
    };
    group.position.copy(hollow.pos);
    this.group.add(group);
    this.hollows.set(hollow.id, hollow);
  }

  private startDissolve(h: Hollow, reposition: boolean): void {
    h.state = 'dissolve';
    h.dissolveTimer = DISSOLVE_SECONDS;
    h.repositionAfterDissolve = reposition;
    h.moving = false;
  }

  private reposition(h: Hollow, px: number, pz: number): void {
    // Reappear on the stalk ring, well out of the player's current view cone
    // (facing direction is (-sin(yaw), -cos(yaw)), so "behind" is yaw + π...
    // in the (sin, cos) spawn convention below that IS the yaw angle itself).
    const behind = this.bus.state.player.yaw;
    const angle = behind + (this.rand() - 0.5) * 2.2;
    const dist = STALK_RING_MIN + this.rand() * (STALK_RING_MAX - STALK_RING_MIN);
    const x = px + Math.sin(angle) * dist;
    const z = pz + Math.cos(angle) * dist;
    if (this.terrain.heightAt(x, z) < 1) {
      this.despawn(h.id);
      return;
    }
    h.pos.set(x, this.terrain.heightAt(x, z), z);
    h.state = 'stalk';
    h.stateTimer = 5 + this.rand() * 8;
    h.watchedTimer = 0;
    h.hp = Math.min(HP, h.hp + 10); // it comes back a little... restored
    for (const m of h.mats) m.opacity = 1;
  }

  private despawn(id: string): void {
    const h = this.hollows.get(id);
    if (!h) return;
    this.group.remove(h.mesh);
    // reposition() reuses the mesh; only a real despawn frees it (+ its child
    // health bar). Dawn dissolves and kills route here every night.
    disposeObject3D(h.mesh);
    this.hollows.delete(id);
  }
}
