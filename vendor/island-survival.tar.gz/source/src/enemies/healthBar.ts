/**
 * Tiny floating health bar for enemies: shows for a few seconds after a hit,
 * billboarded toward the camera each frame.
 */
import * as THREE from 'three';

const WIDTH = 0.6;
const HEIGHT = 0.07;
const SHOW_SECONDS = 3;

export class HealthBar {
  readonly group = new THREE.Group();
  private fg: THREE.Mesh;
  private timer = 0;

  constructor() {
    const bg = new THREE.Mesh(
      new THREE.PlaneGeometry(WIDTH, HEIGHT),
      new THREE.MeshBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.7, depthWrite: false }),
    );
    this.fg = new THREE.Mesh(
      new THREE.PlaneGeometry(WIDTH, HEIGHT * 0.7),
      new THREE.MeshBasicMaterial({ color: 0xd4544a, transparent: true, opacity: 0.95, depthWrite: false }),
    );
    this.fg.position.z = 0.002;
    this.group.add(bg, this.fg);
    this.group.visible = false;
    this.group.renderOrder = 5;
  }

  /** Update the fill fraction and (re)show the bar. */
  ping(fraction: number): void {
    const f = Math.max(0.001, Math.min(1, fraction));
    this.fg.scale.x = f;
    this.fg.position.x = -((1 - f) * WIDTH) / 2;
    this.timer = SHOW_SECONDS;
    this.group.visible = true;
  }

  update(dt: number, camera: THREE.Camera): void {
    if (!this.group.visible) return;
    this.timer -= dt;
    if (this.timer <= 0) {
      this.group.visible = false;
      return;
    }
    this.group.quaternion.copy(camera.quaternion);
  }
}
