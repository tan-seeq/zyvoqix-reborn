/**
 * Structural building pieces (PLAN Phase 3): definitions, resource costs,
 * low-poly wooden meshes, and collider layouts. Grid unit is 3×3m
 * (foundation footprint), walls are 3m wide × 2.6m tall.
 */
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { ItemId } from '../survival/items';

export type BuildType =
  | 'foundation' | 'wall' | 'wall_door' | 'wall_window' | 'roof' | 'floor' | 'stairs'
  | 'chest' | 'bed';

export const GRID = 3; // foundation edge length
export const FOUNDATION_TOP = 0.3;
export const WALL_HEIGHT = 2.6;
/** Walking surface of a roof slab above the piece's base (collider top). */
export const ROOF_TOP = 0.14;
/** Floor deck walking surface above its base — kept equal to ROOF_TOP so
 *  floors and roofs form one continuous storey surface. */
export const FLOOR_TOP = ROOF_TOP;
/**
 * Stairs top out flush with the WALL top — nothing pokes above the wall
 * line. The remaining ROOF_TOP (0.14) onto the neighbouring roof slab is
 * absorbed by the controller's autostep.
 */
export const STAIR_RISE = WALL_HEIGHT;
const STAIR_STEPS = 7; // 0.39m per step — under the controller's 0.45 autostep

export interface BuildDef {
  type: BuildType;
  cost: Array<{ itemId: ItemId; count: number }>;
}

export const BUILD_DEFS: BuildDef[] = [
  { type: 'foundation', cost: [{ itemId: 'log', count: 4 }] },
  { type: 'wall', cost: [{ itemId: 'log', count: 3 }] },
  { type: 'wall_door', cost: [{ itemId: 'log', count: 3 }] },
  { type: 'wall_window', cost: [{ itemId: 'log', count: 3 }] },
  { type: 'roof', cost: [{ itemId: 'log', count: 3 }, { itemId: 'stick', count: 2 }] },
  { type: 'floor', cost: [{ itemId: 'log', count: 3 }, { itemId: 'stick', count: 2 }] },
  { type: 'stairs', cost: [{ itemId: 'log', count: 3 }, { itemId: 'stick', count: 2 }] },
  { type: 'chest', cost: [{ itemId: 'log', count: 2 }, { itemId: 'rope', count: 1 }] },
  { type: 'bed', cost: [{ itemId: 'log', count: 2 }, { itemId: 'fiber', count: 4 }] },
];

export function buildDefFor(type: BuildType): BuildDef {
  return BUILD_DEFS.find((d) => d.type === type)!;
}

/** Raid HP per structure type (destroyed when damage reaches it). */
export const STRUCTURE_HP: Record<string, number> = {
  foundation: 200,
  wall: 120,
  wall_door: 110,
  wall_window: 110,
  roof: 100,
  floor: 120,
  stairs: 100,
  chest: 60,
  bed: 60,
  campfire: 50,
};

/** Axis-aligned local collider boxes; rotated by the piece's rotY at spawn. */
export interface ColliderBox {
  half: [number, number, number];
  offset: [number, number, number];
}

export const PIECE_COLLIDERS: Record<BuildType, ColliderBox[]> = {
  foundation: [{ half: [1.5, 0.15, 1.5], offset: [0, 0.15, 0] }],
  wall: [{ half: [1.5, 1.3, 0.09], offset: [0, 1.3, 0] }],
  wall_door: [
    { half: [0.5, 1.3, 0.09], offset: [-1.0, 1.3, 0] },
    { half: [0.5, 1.3, 0.09], offset: [1.0, 1.3, 0] },
    { half: [0.5, 0.25, 0.09], offset: [0, 2.35, 0] },
  ],
  wall_window: [
    { half: [1.5, 0.525, 0.09], offset: [0, 0.525, 0] },
    { half: [1.5, 0.3, 0.09], offset: [0, 2.3, 0] },
    { half: [0.525, 0.45, 0.09], offset: [-0.975, 1.5, 0] },
    { half: [0.525, 0.45, 0.09], offset: [0.975, 1.5, 0] },
  ],
  roof: [{ half: [1.6, 0.07, 1.6], offset: [0, 0.07, 0] }],
  floor: [{ half: [1.5, 0.07, 1.5], offset: [0, 0.07, 0] }],
  stairs: stairTreads(),
  chest: [{ half: [0.45, 0.35, 0.3], offset: [0, 0.35, 0] }],
  bed: [{ half: [0.55, 0.25, 1.05], offset: [0, 0.25, 0] }],
};

/**
 * Stair treads ascend from the -z edge to the +z edge of the cell, each
 * riser small enough for the character controller's autostep — climbing
 * needs no special player logic, the steps are just terraced ground.
 */
function stairTreads(): ColliderBox[] {
  const boxes: ColliderBox[] = [];
  const depth = GRID / STAIR_STEPS;
  for (let i = 0; i < STAIR_STEPS; i++) {
    boxes.push({
      half: [0.75, 0.045, depth / 2],
      offset: [0, ((i + 1) * STAIR_RISE) / STAIR_STEPS - 0.045, -GRID / 2 + (i + 0.5) * depth],
    });
  }
  return boxes;
}

const WOOD = 0x8a6a42;
const WOOD_DARK = 0x6b4a2b;

function box(w: number, h: number, d: number, x: number, y: number, z: number, color = WOOD): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({ color, roughness: 1, flatShading: true }),
  );
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

/**
 * One MeshStandardMaterial per distinct piece color, shared across EVERY
 * placed structure so the renderer batches them — and never disposed
 * (app-lifetime, like the vegetation instance materials). disposeObject3D
 * skips anything registered here, so demolishing a piece frees its merged
 * geometry without touching these.
 */
const pieceMaterials = new Map<number, THREE.MeshStandardMaterial>();
export const PIECE_SHARED_MATERIALS = new Set<THREE.Material>();

function sharedPieceMaterial(hex: number): THREE.MeshStandardMaterial {
  let m = pieceMaterials.get(hex);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color: hex, roughness: 1, flatShading: true });
    pieceMaterials.set(hex, m);
    PIECE_SHARED_MATERIALS.add(m);
  }
  return m;
}

/**
 * Collapse a group of per-box meshes into ONE merged mesh per distinct color.
 * A wall goes from ~10 meshes/10 materials to 2 meshes/2 shared materials, so
 * a placed piece costs ~2 draw calls in each of the main and shadow passes
 * instead of 10–16. Each box's local transform is baked into the merged
 * geometry — no per-box node survives to runtime.
 */
function mergeByColor(src: THREE.Group): THREE.Group {
  const byColor = new Map<number, THREE.BufferGeometry[]>();
  src.updateMatrixWorld(true);
  src.traverse((n) => {
    if (!(n instanceof THREE.Mesh)) return;
    const hex = (n.material as THREE.MeshStandardMaterial).color.getHex();
    // Bake the box's transform, then normalize to non-indexed so mixed
    // geometries always merge (mirrors world/vegetation colorize()).
    const g = n.geometry.clone().applyMatrix4(n.matrixWorld).toNonIndexed();
    const list = byColor.get(hex);
    if (list) list.push(g);
    else byColor.set(hex, [g]);
  });

  const out = new THREE.Group();
  for (const [hex, geos] of byColor) {
    const merged = mergeGeometries(geos, false);
    for (const g of geos) g.dispose();
    if (!merged) continue;
    const mesh = new THREE.Mesh(merged, sharedPieceMaterial(hex));
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    out.add(mesh);
  }

  // Free the throwaway per-box geometries/materials we merged from.
  src.traverse((n) => {
    if (n instanceof THREE.Mesh) {
      n.geometry.dispose();
      (n.material as THREE.Material).dispose();
    }
  });
  return out;
}

/** Piece origin: center of the footprint at its BASE (ground/platform level). */
export function buildPieceMesh(type: BuildType): THREE.Group {
  const g = new THREE.Group();
  switch (type) {
    case 'foundation': {
      for (let i = 0; i < 5; i++) {
        g.add(box(3, 0.1, 0.55, 0, 0.25, -1.2 + i * 0.6));
      }
      g.add(box(3, 0.16, 0.22, 0, 0.1, -1.25, WOOD_DARK));
      g.add(box(3, 0.16, 0.22, 0, 0.1, 1.25, WOOD_DARK));
      for (const [x, z] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]]) {
        g.add(box(0.22, 0.8, 0.22, x, -0.2, z, WOOD_DARK));
      }
      break;
    }
    case 'wall': {
      g.add(framePost(-1.42), framePost(1.42), topBeam());
      for (let i = 0; i < 7; i++) {
        g.add(box(0.38, 2.45, 0.08, -1.2 + i * 0.4, 1.25, 0));
      }
      break;
    }
    case 'wall_door': {
      g.add(framePost(-1.42), framePost(1.42), topBeam());
      g.add(box(0.95, 2.45, 0.08, -0.98, 1.25, 0));
      g.add(box(0.95, 2.45, 0.08, 0.98, 1.25, 0));
      g.add(box(1.0, 0.4, 0.08, 0, 2.3, 0)); // lintel over the 1m opening
      g.add(box(0.08, 2.1, 0.12, -0.5, 1.05, 0, WOOD_DARK)); // door jambs
      g.add(box(0.08, 2.1, 0.12, 0.5, 1.05, 0, WOOD_DARK));
      break;
    }
    case 'wall_window': {
      g.add(framePost(-1.42), framePost(1.42), topBeam());
      g.add(box(2.85, 1.05, 0.08, 0, 0.525, 0)); // below sill
      g.add(box(2.85, 0.6, 0.08, 0, 2.3, 0)); // above header
      g.add(box(1.0, 0.9, 0.08, -0.95, 1.5, 0)); // left of window
      g.add(box(1.0, 0.9, 0.08, 0.95, 1.5, 0)); // right of window
      g.add(box(0.95, 0.07, 0.14, 0, 1.03, 0, WOOD_DARK)); // sill
      break;
    }
    case 'roof': {
      g.add(box(3.2, 0.12, 3.2, 0, 0.08, 0));
      g.add(box(3.2, 0.14, 0.24, 0, -0.04, -1.1, WOOD_DARK));
      g.add(box(3.2, 0.14, 0.24, 0, -0.04, 1.1, WOOD_DARK));
      break;
    }
    case 'floor': {
      // Plank deck: walking surface flush at FLOOR_TOP, joists framing below.
      for (let i = 0; i < 5; i++) {
        g.add(box(3, 0.1, 0.55, 0, FLOOR_TOP - 0.05, -1.2 + i * 0.6));
      }
      g.add(box(3, 0.1, 0.16, 0, 0.04, -1.42, WOOD_DARK));
      g.add(box(3, 0.1, 0.16, 0, 0.04, 1.42, WOOD_DARK));
      g.add(box(0.16, 0.1, 3, -1.42, 0.04, 0, WOOD_DARK));
      g.add(box(0.16, 0.1, 3, 1.42, 0.04, 0, WOOD_DARK));
      break;
    }
    case 'stairs': {
      const depth = GRID / STAIR_STEPS;
      const rise = STAIR_RISE / STAIR_STEPS;
      for (let i = 0; i < STAIR_STEPS; i++) {
        const y = (i + 1) * rise;
        const z = -GRID / 2 + (i + 0.5) * depth;
        g.add(box(1.5, 0.09, depth, 0, y - 0.045, z)); // tread
        g.add(box(1.4, rise, 0.06, 0, y - rise / 2, z - depth / 2 + 0.03, WOOD_DARK)); // riser
      }
      // Sloped side stringers carrying the treads.
      const slope = Math.atan2(STAIR_RISE, GRID);
      const len = Math.hypot(STAIR_RISE, GRID) + 0.2;
      for (const x of [-0.72, 0.72]) {
        const s = box(0.1, 0.14, len, x, STAIR_RISE / 2 - 0.12, 0, WOOD_DARK);
        s.rotation.x = -slope;
        g.add(s);
      }
      break;
    }
    case 'chest': {
      g.add(box(0.9, 0.5, 0.6, 0, 0.25, 0));
      g.add(box(0.94, 0.14, 0.64, 0, 0.57, 0, WOOD_DARK)); // lid
      g.add(box(0.06, 0.52, 0.62, -0.3, 0.26, 0, WOOD_DARK)); // bands
      g.add(box(0.06, 0.52, 0.62, 0.3, 0.26, 0, WOOD_DARK));
      g.add(box(0.1, 0.12, 0.05, 0, 0.42, 0.31, 0x3a3a3a)); // latch
      break;
    }
    case 'bed': {
      g.add(box(1.1, 0.18, 2.1, 0, 0.25, 0, WOOD_DARK)); // frame
      for (const [x, z] of [[-0.5, -1.0], [0.5, -1.0], [-0.5, 1.0], [0.5, 1.0]]) {
        g.add(box(0.12, 0.34, 0.12, x, 0.17, z, WOOD_DARK));
      }
      const mattress = box(1.0, 0.14, 1.95, 0, 0.41, 0, 0xc9bfa5);
      g.add(mattress);
      g.add(box(0.85, 0.12, 0.4, 0, 0.5, -0.75, 0xe8e0cc)); // pillow
      break;
    }
  }
  return mergeByColor(g);

  function framePost(x: number): THREE.Mesh {
    return box(0.16, 2.6, 0.16, x, 1.3, 0, WOOD_DARK);
  }
  function topBeam(): THREE.Mesh {
    return box(3, 0.16, 0.16, 0, 2.52, 0, WOOD_DARK);
  }
}
