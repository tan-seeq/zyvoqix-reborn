/**
 * Placed structures: builds meshes + colliders from GameState.world
 * .placedObjects, keeps a handle→id map for interaction raycasts, and
 * reacts to actions (PLACE_OBJECT/BUILD add, DEMOLISH remove, TOGGLE_DOOR
 * swings the leaf and toggles its collider). Never mutates state itself.
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { ActionBus } from '../core/actions';
import type { PlacedObject, PlacedObjectType } from '../core/GameState';
import { buildPieceMesh, PIECE_COLLIDERS, PIECE_SHARED_MATERIALS, type BuildType } from './pieces';
import { disposeObject3D } from '../core/three-utils';

const DOOR_OPEN_ANGLE = -1.9; // ~110°, swings inward

interface DoorParts {
  leaf: THREE.Object3D;
  colliderHandle: number | null;
  targetAngle: number;
}

interface StructureInstance {
  id: string;
  type: PlacedObjectType;
  pos: THREE.Vector3;
  group: THREE.Group;
  colliderHandles: number[];
  door?: DoorParts;
  fire?: { flames: THREE.Mesh[]; light: THREE.PointLight; flickerSeed: number };
  rotY: number;
}

/**
 * Low-poly campfire: stone ring + log teepee + two crossed flame cones.
 * `ghost` builds the untextured preview variant for the placement system.
 */
export function buildCampfireMesh(ghost = false): THREE.Group {
  const g = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0x8b8578, roughness: 1, flatShading: true });
  const logMat = new THREE.MeshStandardMaterial({ color: 0x5c3f24, roughness: 1, flatShading: true });

  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    const stone = new THREE.Mesh(new THREE.IcosahedronGeometry(0.11, 0), stoneMat);
    stone.position.set(Math.cos(a) * 0.5, 0.06, Math.sin(a) * 0.5);
    stone.rotation.y = a * 2.3;
    g.add(stone);
  }
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.4;
    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.55, 6), logMat);
    log.position.set(Math.cos(a) * 0.13, 0.24, Math.sin(a) * 0.13);
    log.rotation.set(Math.sin(a) * 0.6, 0, Math.cos(a) * 0.6);
    log.castShadow = !ghost;
    g.add(log);
  }

  if (!ghost) {
    const flameMat = new THREE.MeshStandardMaterial({
      color: 0xff8c2a,
      emissive: 0xff6a00,
      emissiveIntensity: 1.6,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
    });
    const innerMat = flameMat.clone();
    innerMat.color.setHex(0xffd45c);
    innerMat.emissive.setHex(0xffb400);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.55, 6), flameMat);
    flame.position.y = 0.5;
    flame.name = 'flame';
    const inner = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.38, 6), innerMat);
    inner.position.y = 0.45;
    inner.name = 'flame';
    g.add(flame, inner);
  }
  return g;
}

/** The swinging door leaf, hinged on the left jamb of a wall_door. */
function buildDoorLeaf(): THREE.Group {
  const hinge = new THREE.Group();
  hinge.position.set(-0.5, 0, 0);
  const plankMat = new THREE.MeshStandardMaterial({ color: 0x7a5535, roughness: 1, flatShading: true });
  const leafMesh = new THREE.Mesh(new THREE.BoxGeometry(0.96, 2.05, 0.07), plankMat);
  leafMesh.position.set(0.48, 1.075, 0);
  leafMesh.castShadow = true;
  const handle = new THREE.Mesh(
    new THREE.SphereGeometry(0.045, 6, 5),
    new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.5 }),
  );
  handle.position.set(0.82, 1.05, 0.08);
  hinge.add(leafMesh, handle);
  hinge.name = 'door-leaf';
  return hinge;
}

export class Structures {
  readonly group = new THREE.Group();
  private structures = new Map<string, StructureInstance>();
  /** Structures bucketed by type, so nearestDistance scans only campfires/beds
   *  (a handful) instead of every wall/foundation each render frame. */
  private byType = new Map<PlacedObjectType, Set<StructureInstance>>();
  private handleToId = new Map<number, string>();
  private time = 0;

  constructor(
    private rapier: typeof RAPIER,
    private physicsWorld: RAPIER.World,
    private bus: ActionBus,
  ) {
    for (const obj of bus.state.world.placedObjects) this.add(obj);
    bus.subscribe((action, state) => {
      if (action.type === 'PLACE_OBJECT' || action.type === 'BUILD') {
        const newest = state.world.placedObjects[state.world.placedObjects.length - 1];
        if (newest && !this.structures.has(newest.id)) this.add(newest);
      } else if (action.type === 'TOGGLE_DOOR') {
        this.applyDoorState(action.objectId);
      } else if (action.type === 'DEMOLISH' || action.type === 'DAMAGE_STRUCTURE') {
        // The reducer may refuse (unknown id, non-empty chest) or the damage
        // may not be lethal — only tear down visuals when the object is
        // really gone from the state.
        if (!state.world.placedObjects.some((o) => o.id === action.objectId)) {
          this.remove(action.objectId);
        }
      }
    });
  }

  structureIdByColliderHandle(handle: number): string | undefined {
    return this.handleToId.get(handle);
  }

  typeOf(id: string): PlacedObjectType | undefined {
    return this.structures.get(id)?.type;
  }

  positionOf(id: string): THREE.Vector3 | undefined {
    return this.structures.get(id)?.pos;
  }

  /** Nearest structure of any type to (x, z) within maxDist, or null. */
  nearestStructureTo(x: number, z: number, maxDist: number): string | null {
    let best: string | null = null;
    let bestD = maxDist;
    for (const s of this.structures.values()) {
      const d = Math.hypot(x - s.pos.x, z - s.pos.z);
      if (d < bestD) {
        best = s.id;
        bestD = d;
      }
    }
    return best;
  }

  /** Distance from (x, z) to the nearest structure of the given types. */
  nearestDistance(x: number, z: number, types: PlacedObjectType[]): number {
    let best = Infinity;
    for (const t of types) {
      const bucket = this.byType.get(t);
      if (!bucket) continue;
      for (const s of bucket) best = Math.min(best, Math.hypot(x - s.pos.x, z - s.pos.z));
    }
    return best;
  }

  /** Register in the id map and the per-type bucket. */
  private index(inst: StructureInstance): void {
    this.structures.set(inst.id, inst);
    let bucket = this.byType.get(inst.type);
    if (!bucket) {
      bucket = new Set();
      this.byType.set(inst.type, bucket);
    }
    bucket.add(inst);
  }

  /** Per render frame: fire flicker + door swing animation. */
  updateVisual(dt: number): void {
    this.time += dt;
    for (const s of this.structures.values()) {
      if (s.fire) {
        const flicker =
          Math.sin(this.time * 9 + s.fire.flickerSeed) * 0.5 +
          Math.sin(this.time * 23 + s.fire.flickerSeed * 2) * 0.5;
        s.fire.light.intensity = 7 + flicker * 1.6;
        for (const flame of s.fire.flames) flame.scale.setScalar(1 + flicker * 0.07);
      }
      if (s.door) {
        const diff = s.door.targetAngle - s.door.leaf.rotation.y;
        if (Math.abs(diff) > 0.001) {
          s.door.leaf.rotation.y += diff * Math.min(1, dt * 7);
        }
      }
    }
  }

  private add(obj: PlacedObject): void {
    if (obj.type === 'campfire') this.addCampfire(obj);
    else this.addPiece(obj);
    // Restore persisted door state (instant, no swing animation on load).
    const inst = this.structures.get(obj.id);
    if (inst?.door && this.bus.state.world.doorOpen[obj.id]) {
      this.applyDoorState(obj.id);
      inst.door.leaf.rotation.y = inst.door.targetAngle;
    }
  }

  private remove(id: string): void {
    const inst = this.structures.get(id);
    if (!inst) return;
    this.group.remove(inst.group);
    // Free this piece's merged geometry (per-instance) + the door leaf /
    // campfire per-instance materials, but keep the app-lifetime shared
    // piece materials that every other structure still references.
    disposeObject3D(inst.group, PIECE_SHARED_MATERIALS);
    const handles = [...inst.colliderHandles];
    if (inst.door?.colliderHandle !== null && inst.door?.colliderHandle !== undefined) {
      handles.push(inst.door.colliderHandle);
    }
    for (const handle of handles) {
      const collider = this.physicsWorld.getCollider(handle);
      if (collider) this.physicsWorld.removeCollider(collider, false);
      this.handleToId.delete(handle);
    }
    this.structures.delete(id);
    this.byType.get(inst.type)?.delete(inst);
  }

  private applyDoorState(id: string): void {
    const inst = this.structures.get(id);
    if (!inst?.door) return;
    const open = !!this.bus.state.world.doorOpen[id];
    inst.door.targetAngle = open ? DOOR_OPEN_ANGLE : 0;
    if (open && inst.door.colliderHandle !== null) {
      const collider = this.physicsWorld.getCollider(inst.door.colliderHandle);
      if (collider) this.physicsWorld.removeCollider(collider, false);
      this.handleToId.delete(inst.door.colliderHandle);
      inst.door.colliderHandle = null;
    } else if (!open && inst.door.colliderHandle === null) {
      inst.door.colliderHandle = this.createBoxCollider(
        inst, [0.5, 1.05, 0.05], [0, 1.05, 0],
      );
    }
  }

  private addCampfire(obj: PlacedObject): void {
    const mesh = buildCampfireMesh();
    mesh.position.set(obj.pos[0], obj.pos[1], obj.pos[2]);
    mesh.rotation.y = obj.rotY;
    this.group.add(mesh);

    const light = new THREE.PointLight(0xff9a3c, 7, 14);
    light.position.set(0, 0.9, 0);
    mesh.add(light);

    const inst: StructureInstance = {
      id: obj.id,
      type: 'campfire',
      pos: new THREE.Vector3(...obj.pos),
      group: mesh,
      colliderHandles: [],
      rotY: obj.rotY,
      fire: {
        flames: mesh.children.filter((c): c is THREE.Mesh => c.name === 'flame'),
        light,
        flickerSeed: this.structures.size * 2.7,
      },
    };
    this.index(inst);
    inst.colliderHandles.push(
      this.createCollider(
        obj.id,
        this.rapier.ColliderDesc.cylinder(0.2, 0.55).setTranslation(obj.pos[0], obj.pos[1] + 0.2, obj.pos[2]),
      ),
    );
  }

  private addPiece(obj: PlacedObject): void {
    const type = obj.type as BuildType;
    const mesh = buildPieceMesh(type);
    mesh.position.set(obj.pos[0], obj.pos[1], obj.pos[2]);
    mesh.rotation.y = obj.rotY;
    this.group.add(mesh);

    const inst: StructureInstance = {
      id: obj.id,
      type: obj.type,
      pos: new THREE.Vector3(...obj.pos),
      group: mesh,
      colliderHandles: [],
      rotY: obj.rotY,
    };
    this.index(inst);

    for (const boxDef of PIECE_COLLIDERS[type]) {
      inst.colliderHandles.push(this.createBoxCollider(inst, boxDef.half, boxDef.offset));
    }

    if (type === 'wall_door') {
      const leaf = buildDoorLeaf();
      mesh.add(leaf);
      inst.door = {
        leaf,
        colliderHandle: this.createBoxCollider(inst, [0.5, 1.05, 0.05], [0, 1.05, 0]),
        targetAngle: 0,
      };
    }
  }

  private createBoxCollider(
    inst: StructureInstance,
    half: [number, number, number] | readonly number[],
    offset: [number, number, number] | readonly number[],
  ): number {
    const sin = Math.sin(inst.rotY);
    const cos = Math.cos(inst.rotY);
    const [ox, oy, oz] = offset;
    const wx = inst.pos.x + ox * cos + oz * sin;
    const wz = inst.pos.z - ox * sin + oz * cos;
    return this.createCollider(
      inst.id,
      this.rapier.ColliderDesc.cuboid(half[0], half[1], half[2])
        .setTranslation(wx, inst.pos.y + oy, wz)
        .setRotation({ x: 0, y: Math.sin(inst.rotY / 2), z: 0, w: Math.cos(inst.rotY / 2) }),
    );
  }

  private createCollider(id: string, desc: RAPIER.ColliderDesc): number {
    const collider = this.physicsWorld.createCollider(desc);
    this.handleToId.set(collider.handle, id);
    return collider.handle;
  }
}
