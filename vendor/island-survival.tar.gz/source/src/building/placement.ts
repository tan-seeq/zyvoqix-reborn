/**
 * Placement system (PLAN Phase 3): the build menu (B) offers structural
 * pieces built directly from resources; a ghost preview shows where the
 * piece will land — green = valid, red = invalid/unaffordable.
 *
 * Socket snapping:
 *  - foundations snap edge-to-edge to existing foundations (same height),
 *    or place freely on flat ground (R rotates by 90°)
 *  - walls (plain/door/window) snap onto the nearest PLATFORM edge, where a
 *    platform is a foundation top OR a roof top — that one rule makes upper
 *    storeys chain for free (roof = next floor)
 *  - roofs cap a platform at wall height; stairs fill a platform cell and
 *    climb one storey (leave the stair cell unroofed, step off onto the
 *    NEIGHBOURING roof)
 *  - when floors overlap in 2D, candidates prefer the storey nearest the
 *    player's feet — aiming from the 2nd floor builds on the 2nd floor
 * Campfire-kit placement (from the hotbar) rides the same ghost pipeline.
 *
 * E/click confirms (BUILD or PLACE_OBJECT actions — cost validated in the
 * reducer), Q cancels, chain-building keeps the ghost active.
 */
import * as THREE from 'three';
import type { ActionBus } from '../core/actions';
import type { Input } from '../core/input';
import type { System } from '../core/loop';
import type { Terrain } from '../world/terrain';
import type { PlayerController } from '../player/controller';
import type { PlacedObject } from '../core/GameState';
import type { ItemId } from '../survival/items';
import { canAfford } from '../survival/crafting';
import { buildCampfireMesh } from './structures';
import {
  BUILD_DEFS, buildDefFor, buildPieceMesh, FLOOR_TOP, FOUNDATION_TOP, GRID, ROOF_TOP, WALL_HEIGHT,
  type BuildType,
} from './pieces';

const PLACE_DISTANCE = 4;
const SNAP_RANGE = 2.3;
const MAX_SLOPE = 0.4;
const MIN_HEIGHT = 0.5;

const WALL_TYPES: ReadonlyArray<PlacedObject['type']> = ['wall', 'wall_door', 'wall_window'];

export interface PlacementHudInfo {
  kind: 'menu' | 'ghost';
  buildType: BuildType | 'campfire';
  valid: boolean;
  affordable: boolean;
}

interface GhostTransform {
  x: number;
  y: number;
  z: number;
  rotY: number;
  valid: boolean;
}

/** A surface you can build on: foundation top or roof top (= next floor). */
interface Platform {
  x: number;
  y: number; // walking-surface height
  z: number;
  rotY: number;
}

export class PlacementSystem implements System {
  menuOpen = false;
  active = false;

  private buildType: BuildType | null = null;
  private kitItem: ItemId | null = null;
  private ghost: THREE.Group | null = null;
  private ghostCache = new Map<string, { group: THREE.Group; mats: THREE.MeshStandardMaterial[] }>();
  private valid = false;
  private affordable = true;
  private freeRotSteps = 0;

  constructor(
    private scene: THREE.Scene,
    private terrain: Terrain,
    private player: PlayerController,
    private input: Input,
    private bus: ActionBus,
  ) {}

  /** True while placement owns E/click/R/digit input (menu or ghost). */
  get isBusy(): boolean {
    return this.active || this.menuOpen;
  }

  hudInfo(): PlacementHudInfo | null {
    if (this.menuOpen) return { kind: 'menu', buildType: 'foundation', valid: true, affordable: true };
    if (this.active) {
      return {
        kind: 'ghost',
        buildType: this.buildType ?? 'campfire',
        valid: this.valid,
        affordable: this.affordable,
      };
    }
    return null;
  }

  /** Hotbar route: place a kit item (campfire). */
  begin(kitItem: ItemId): void {
    this.cancel();
    this.kitItem = kitItem;
    this.active = true;
    this.showGhost('campfire');
  }

  beginBuild(type: BuildType): void {
    this.cancel();
    this.buildType = type;
    this.active = true;
    this.freeRotSteps = 0;
    this.showGhost(type);
  }

  cancel(): void {
    this.active = false;
    this.menuOpen = false;
    this.buildType = null;
    this.kitItem = null;
    if (this.ghost) {
      this.scene.remove(this.ghost);
      this.ghost = null;
    }
  }

  update(_dt: number): void {
    if (!this.input.pointerLocked) {
      this.cancel();
      return;
    }

    if (this.input.consumeKey('KeyB')) {
      if (this.isBusy) this.cancel();
      else this.menuOpen = true;
      return;
    }

    if (this.menuOpen) {
      for (let i = 0; i < BUILD_DEFS.length; i++) {
        if (this.input.consumeKey(`Digit${i + 1}`)) {
          this.beginBuild(BUILD_DEFS[i].type);
          return;
        }
      }
      if (this.input.consumeKey('KeyQ') || this.input.consumeKey('Escape')) this.cancel();
      this.input.consumeClick();
      return;
    }

    if (!this.active) return;

    if (this.input.consumeKey('KeyQ')) {
      this.cancel();
      return;
    }
    if (this.input.consumeKey('KeyR')) this.freeRotSteps++;

    const t = this.buildType ? this.computeBuildGhost(this.buildType) : this.computeCampfireGhost();
    this.valid = t.valid;
    this.affordable = this.buildType
      ? canAfford(this.bus.state, buildDefFor(this.buildType).cost)
      : true;

    if (this.ghost) {
      this.ghost.position.set(t.x, t.y, t.z);
      this.ghost.rotation.y = t.rotY;
      const ok = this.valid && this.affordable;
      const entry = this.ghostCache.get(this.buildType ?? 'campfire');
      if (entry) for (const m of entry.mats) m.color.setHex(ok ? 0x3fae5a : 0xc0392b);
    }

    const confirm = this.input.consumeClick() || this.input.consumeKey('KeyE');
    if (!confirm || !this.valid || !this.affordable) return;

    if (this.buildType) {
      this.bus.dispatch({
        type: 'BUILD', buildType: this.buildType, pos: [t.x, t.y, t.z], rotY: t.rotY,
      });
      // Chain-building: ghost stays up while resources last.
      if (!canAfford(this.bus.state, buildDefFor(this.buildType).cost)) this.cancel();
    } else if (this.kitItem) {
      this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: this.kitItem, count: 1 });
      this.bus.dispatch({ type: 'PLACE_OBJECT', objectType: 'campfire', pos: [t.x, t.y, t.z], rotY: t.rotY });
      this.cancel();
    }
  }

  // ---------- ghost transforms ----------

  private targetPoint(): { tx: number; tz: number } {
    const [px, , pz] = this.bus.state.player.pos;
    const yaw = this.player.yaw;
    return { tx: px - Math.sin(yaw) * PLACE_DISTANCE, tz: pz - Math.cos(yaw) * PLACE_DISTANCE };
  }

  private foundations(): PlacedObject[] {
    return this.bus.state.world.placedObjects.filter((o) => o.type === 'foundation');
  }

  private platforms(): Platform[] {
    const list: Platform[] = [];
    for (const o of this.bus.state.world.placedObjects) {
      if (o.type === 'foundation') {
        list.push({ x: o.pos[0], y: o.pos[1] + FOUNDATION_TOP, z: o.pos[2], rotY: o.rotY });
      } else if (o.type === 'roof') {
        list.push({ x: o.pos[0], y: o.pos[1] + ROOF_TOP, z: o.pos[2], rotY: o.rotY });
      } else if (o.type === 'floor') {
        list.push({ x: o.pos[0], y: o.pos[1] + FLOOR_TOP, z: o.pos[2], rotY: o.rotY });
      }
    }
    return list;
  }

  /**
   * Overlapping storeys tie on 2D distance — bias toward the floor the
   * player is standing on so aiming from upstairs builds upstairs.
   */
  private storeyBias(platformY: number): number {
    return Math.abs(platformY - this.bus.state.player.pos[1]) * 0.6;
  }

  private computeCampfireGhost(): GhostTransform {
    const { tx, tz } = this.targetPoint();
    const y = this.terrain.heightAt(tx, tz);
    const valid = y > MIN_HEIGHT && this.terrain.slopeAt(tx, tz) < MAX_SLOPE;
    return { x: tx, y, z: tz, rotY: this.player.yaw, valid };
  }

  private computeBuildGhost(type: BuildType): GhostTransform {
    const { tx, tz } = this.targetPoint();
    switch (type) {
      case 'foundation':
        return this.foundationGhost(tx, tz);
      case 'wall':
      case 'wall_door':
      case 'wall_window':
        return this.wallGhost(tx, tz);
      case 'roof':
        return this.roofGhost(tx, tz);
      case 'floor':
        return this.floorGhost(tx, tz);
      case 'stairs':
        return this.stairsGhost(tx, tz);
      case 'chest':
      case 'bed':
        return this.furnitureGhost(type, tx, tz);
    }
  }

  /** Chest/bed: sit on a platform (any storey) when one is underneath, else on flat ground. */
  private furnitureGhost(type: 'chest' | 'bed', tx: number, tz: number): GhostTransform {
    const rotY = this.player.yaw + (this.freeRotSteps % 4) * (Math.PI / 2);
    const radius = type === 'bed' ? 1.4 : 0.9;
    const crowdedAt = (y: number) => this.bus.state.world.placedObjects.some(
      (o) => (o.type === 'chest' || o.type === 'bed' || o.type === 'campfire') &&
        Math.hypot(o.pos[0] - tx, o.pos[2] - tz) < radius && Math.abs(o.pos[1] - y) < 1.5,
    );
    let best: Platform | null = null;
    let bestScore = Infinity;
    for (const p of this.platforms()) {
      const d = Math.hypot(tx - p.x, tz - p.z);
      if (d >= GRID / 2) continue;
      const score = d + this.storeyBias(p.y);
      if (score < bestScore) {
        best = p;
        bestScore = score;
      }
    }
    if (best) return { x: tx, y: best.y, z: tz, rotY, valid: !crowdedAt(best.y) };
    const y = this.terrain.heightAt(tx, tz);
    const valid = !crowdedAt(y) && y > MIN_HEIGHT && this.terrain.slopeAt(tx, tz) < MAX_SLOPE;
    return { x: tx, y, z: tz, rotY, valid };
  }

  private foundationGhost(tx: number, tz: number): GhostTransform {
    // Prefer snapping to a free edge of an existing foundation.
    let best: GhostTransform | null = null;
    let bestD = SNAP_RANGE;
    for (const f of this.foundations()) {
      for (let k = 0; k < 4; k++) {
        const a = f.rotY + (k * Math.PI) / 2;
        const cx = f.pos[0] + Math.sin(a) * GRID;
        const cz = f.pos[2] + Math.cos(a) * GRID;
        const d = Math.hypot(tx - cx, tz - cz);
        if (d < bestD && !this.occupied('foundation', cx, cz, 1.5)) {
          best = { x: cx, y: f.pos[1], z: cz, rotY: f.rotY, valid: true };
          bestD = d;
        }
      }
    }
    if (best) return best;

    // Free placement on flat-enough ground: base sits on the highest corner.
    const rotY = (this.freeRotSteps % 4) * (Math.PI / 2);
    let y = this.terrain.heightAt(tx, tz);
    for (const [dx, dz] of [[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]]) {
      y = Math.max(y, this.terrain.heightAt(tx + dx, tz + dz));
    }
    const valid =
      this.terrain.heightAt(tx, tz) > MIN_HEIGHT &&
      this.terrain.slopeAt(tx, tz) < MAX_SLOPE &&
      !this.occupied('foundation', tx, tz, 2.9);
    return { x: tx, y: y + 0.02, z: tz, rotY, valid };
  }

  private wallGhost(tx: number, tz: number): GhostTransform {
    let best: GhostTransform | null = null;
    let bestScore = Infinity;
    for (const p of this.platforms()) {
      for (let k = 0; k < 4; k++) {
        const a = p.rotY + (k * Math.PI) / 2;
        const mx = p.x + Math.sin(a) * (GRID / 2);
        const mz = p.z + Math.cos(a) * (GRID / 2);
        const d = Math.hypot(tx - mx, tz - mz);
        const score = d + this.storeyBias(p.y);
        if (d < SNAP_RANGE && score < bestScore && !this.wallOccupied(mx, mz, p.y)) {
          best = { x: mx, y: p.y, z: mz, rotY: a, valid: true };
          bestScore = score;
        }
      }
    }
    if (best) return best;
    // No socket in range — show an invalid ghost at the aim point.
    return { x: tx, y: this.terrain.heightAt(tx, tz), z: tz, rotY: this.player.yaw, valid: false };
  }

  private roofGhost(tx: number, tz: number): GhostTransform {
    let best: GhostTransform | null = null;
    let bestScore = Infinity;
    for (const p of this.platforms()) {
      const d = Math.hypot(tx - p.x, tz - p.z);
      const y = p.y + WALL_HEIGHT;
      const score = d + this.storeyBias(p.y);
      if (d < SNAP_RANGE + 1 && score < bestScore && !this.occupied('roof', p.x, p.z, 1.5, y)) {
        best = { x: p.x, y, z: p.z, rotY: p.rotY, valid: true };
        bestScore = score;
      }
    }
    if (best) return best;
    return { x: tx, y: this.terrain.heightAt(tx, tz) + 2.5, z: tz, rotY: 0, valid: false };
  }

  /**
   * Floor deck — the upper storey. Two snaps, nearest to the aim point wins:
   *  (a) a storey UP, centered over any platform below (floor on top of walls),
   *  (b) edge-to-edge with an existing elevated floor/roof at the same height,
   *      to widen the storey or cantilever out past the walls beneath.
   */
  private floorGhost(tx: number, tz: number): GhostTransform {
    let best: GhostTransform | null = null;
    let bestScore = Infinity;

    for (const p of this.platforms()) {
      const d = Math.hypot(tx - p.x, tz - p.z);
      const y = p.y + WALL_HEIGHT;
      const score = d + this.storeyBias(p.y);
      if (d < SNAP_RANGE + 1 && score < bestScore && !this.deckAt(p.x, p.z, y)) {
        best = { x: p.x, y, z: p.z, rotY: p.rotY, valid: true };
        bestScore = score;
      }
    }

    for (const o of this.bus.state.world.placedObjects) {
      if (o.type !== 'floor' && o.type !== 'roof') continue;
      for (let k = 0; k < 4; k++) {
        const a = o.rotY + (k * Math.PI) / 2;
        const cx = o.pos[0] + Math.sin(a) * GRID;
        const cz = o.pos[2] + Math.cos(a) * GRID;
        const d = Math.hypot(tx - cx, tz - cz);
        const score = d + this.storeyBias(o.pos[1]);
        if (d < SNAP_RANGE && score < bestScore && !this.deckAt(cx, cz, o.pos[1])) {
          best = { x: cx, y: o.pos[1], z: cz, rotY: o.rotY, valid: true };
          bestScore = score;
        }
      }
    }

    if (best) return best;
    return { x: tx, y: this.terrain.heightAt(tx, tz) + 2.5, z: tz, rotY: 0, valid: false };
  }

  /** A floor or roof already occupies the cell at (x, z) near height y. */
  private deckAt(x: number, z: number, y: number): boolean {
    return this.bus.state.world.placedObjects.some(
      (o) => (o.type === 'floor' || o.type === 'roof') &&
        Math.hypot(o.pos[0] - x, o.pos[2] - z) < 1.5 && Math.abs(o.pos[1] - y) < 1,
    );
  }

  /** Stairs fill a platform cell, base at its surface, climbing one storey. */
  private stairsGhost(tx: number, tz: number): GhostTransform {
    let best: GhostTransform | null = null;
    let bestScore = Infinity;
    for (const p of this.platforms()) {
      const d = Math.hypot(tx - p.x, tz - p.z);
      const score = d + this.storeyBias(p.y);
      if (d < SNAP_RANGE + 1 && score < bestScore && !this.occupied('stairs', p.x, p.z, 1.5, p.y)) {
        const rotY = p.rotY + (this.freeRotSteps % 4) * (Math.PI / 2);
        best = { x: p.x, y: p.y, z: p.z, rotY, valid: true };
        bestScore = score;
      }
    }
    if (best) return best;
    return { x: tx, y: this.terrain.heightAt(tx, tz), z: tz, rotY: this.player.yaw, valid: false };
  }

  /** Same-type occupancy at a 2D spot; y (when given) restricts to that storey. */
  private occupied(type: PlacedObject['type'], x: number, z: number, radius: number, y?: number): boolean {
    return this.bus.state.world.placedObjects.some(
      (o) => o.type === type && Math.hypot(o.pos[0] - x, o.pos[2] - z) < radius &&
        (y === undefined || Math.abs(o.pos[1] - y) < 1),
    );
  }

  private wallOccupied(x: number, z: number, y: number): boolean {
    return this.bus.state.world.placedObjects.some(
      (o) => WALL_TYPES.includes(o.type) && Math.hypot(o.pos[0] - x, o.pos[2] - z) < 0.5 &&
        Math.abs(o.pos[1] - y) < 1,
    );
  }

  // ---------- ghost visuals ----------

  private showGhost(key: BuildType | 'campfire'): void {
    let entry = this.ghostCache.get(key);
    if (!entry) {
      const group = key === 'campfire' ? buildCampfireMesh(true) : buildPieceMesh(key);
      const mats: THREE.MeshStandardMaterial[] = [];
      group.traverse((n) => {
        if (n instanceof THREE.Mesh) {
          const m = (n.material as THREE.MeshStandardMaterial).clone();
          m.transparent = true;
          m.opacity = 0.5;
          m.depthWrite = false;
          n.material = m;
          n.castShadow = false;
          mats.push(m);
        }
      });
      entry = { group, mats };
      this.ghostCache.set(key, entry);
    }
    this.ghost = entry.group;
    this.scene.add(this.ghost);
  }
}
