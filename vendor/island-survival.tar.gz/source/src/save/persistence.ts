/**
 * Save persistence, stage 1: localStorage (PLAN Phase 4). The Supabase cloud
 * layer will reuse the same envelope format later.
 *
 * Format: an envelope { version, savedAt, state } where `state` is the whole
 * serializable GameState. `version` is the SAVE schema version; on load,
 * MIGRATIONS upgrade older envelopes step by step so old saves never break,
 * and withDefaults() backfills any fields added since the save was written.
 *
 * Slot layout: slot 1 is the auto-save (2-minute timer + tab close),
 * slots 2-3 are manual.
 */
import type { GameState } from '../core/GameState';
import { createInitialState } from '../core/GameState';

export const SAVE_VERSION = 1;
export const SLOT_COUNT = 3;
export const AUTOSAVE_SLOT = 1;

const SLOT_KEY = (slot: number) => `island-survival:save:${slot}`;
const ACTIVE_KEY = 'island-survival:active-slot';

interface SaveEnvelope {
  version: number;
  savedAt: string;
  state: GameState;
}

/** Each entry upgrades version N → N+1. Added alongside schema changes. */
type Migration = (data: Record<string, unknown>) => Record<string, unknown>;
const MIGRATIONS: Record<number, Migration> = {};

export interface SaveMeta {
  slot: number;
  day: number;
  savedAt: string;
}

// ---------- pure encode/decode (unit-testable, no browser APIs) ----------

export function encodeSave(state: GameState, savedAt = new Date().toISOString()): string {
  return JSON.stringify({ version: SAVE_VERSION, savedAt, state } satisfies SaveEnvelope);
}

export function decodeSave(json: string): { state: GameState; savedAt: string } | null {
  try {
    const env = JSON.parse(json) as SaveEnvelope;
    if (!env || typeof env !== 'object' || typeof env.version !== 'number' || !env.state) return null;
    if (env.version > SAVE_VERSION) return null; // save from a newer build
    let data = env.state as unknown as Record<string, unknown>;
    for (let v = env.version; v < SAVE_VERSION; v++) {
      const migrate = MIGRATIONS[v];
      if (!migrate) return null;
      data = migrate(data);
    }
    return { state: withDefaults(data), savedAt: env.savedAt ?? '' };
  } catch {
    return null;
  }
}

/** Backfill fields that didn't exist when the save was written. */
function withDefaults(data: Record<string, unknown>): GameState {
  const d = data as Partial<GameState>;
  const base = createInitialState(typeof d.seed === 'number' ? d.seed : 1987);
  return {
    ...base,
    ...d,
    version: base.version,
    player: { ...base.player, ...d.player },
    survival: { ...base.survival, ...d.survival },
    world: { ...base.world, ...d.world },
    inventory: d.inventory ?? base.inventory,
  };
}

// ---------- localStorage layer ----------

/**
 * Persist to a slot. Returns false instead of throwing on a localStorage
 * failure (quota exceeded, private-mode denial) — the autosave runs inside
 * the render loop, so an uncaught throw here would halt the whole game.
 * Callers that can surface UI feedback check the return value.
 */
export function saveToSlot(state: GameState, slot: number): boolean {
  try {
    localStorage.setItem(SLOT_KEY(slot), encodeSave(state));
    localStorage.setItem(ACTIVE_KEY, String(slot));
    return true;
  } catch (err) {
    console.error('saveToSlot failed', err);
    return false;
  }
}

export function loadSlot(slot: number): { state: GameState; savedAt: string } | null {
  const json = localStorage.getItem(SLOT_KEY(slot));
  return json ? decodeSave(json) : null;
}

export function deleteSlot(slot: number): void {
  localStorage.removeItem(SLOT_KEY(slot));
}

export function listSaves(): Array<SaveMeta | null> {
  const out: Array<SaveMeta | null> = [];
  for (let slot = 1; slot <= SLOT_COUNT; slot++) {
    const loaded = loadSlot(slot);
    out.push(loaded ? { slot, day: loaded.state.day, savedAt: loaded.savedAt } : null);
  }
  return out;
}

/** Slot to continue from on boot (last saved/loaded), or null for a fresh game. */
export function loadActive(): { slot: number; state: GameState } | null {
  const raw = localStorage.getItem(ACTIVE_KEY);
  if (!raw) return null;
  const slot = Number(raw);
  if (!Number.isInteger(slot) || slot < 1 || slot > SLOT_COUNT) return null;
  const loaded = loadSlot(slot);
  return loaded ? { slot, state: loaded.state } : null;
}

export function setActiveSlot(slot: number): void {
  localStorage.setItem(ACTIVE_KEY, String(slot));
}

export function clearActiveSlot(): void {
  localStorage.removeItem(ACTIVE_KEY);
}
