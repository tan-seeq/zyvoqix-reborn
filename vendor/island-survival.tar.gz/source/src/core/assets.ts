/**
 * GLB asset loading utility (GLTFLoader + Draco), wired to a loading screen
 * callback. Models land in public/assets/models/<pack>/ — see PLAN.md §Assets.
 * No models are shipped yet (Phase 1 uses procedural placeholders), but the
 * pipeline is ready.
 */
import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';

export class AssetLoader {
  readonly manager = new THREE.LoadingManager();
  private gltfLoader: GLTFLoader;
  private cache = new Map<string, GLTF>();

  constructor(onProgress?: (loaded: number, total: number) => void) {
    if (onProgress) {
      this.manager.onProgress = (_url, loaded, total) => onProgress(loaded, total);
    }
    this.gltfLoader = new GLTFLoader(this.manager);
  }

  async loadModel(url: string): Promise<GLTF> {
    const cached = this.cache.get(url);
    if (cached) return cached;
    const gltf = await this.gltfLoader.loadAsync(url);
    this.cache.set(url, gltf);
    return gltf;
  }
}
