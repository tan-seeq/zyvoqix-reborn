/**
 * Three.js resource helpers.
 *
 * Three never frees GPU buffers/programs when you remove a mesh from a scene —
 * the JS wrapper is garbage-collected but the underlying GL geometry/material
 * leaks until context loss unless you explicitly .dispose() them. Every
 * removal path (structure demolish, enemy despawn, arrow expiry, backpack
 * rebuild, viewmodel swap) must route through disposeObject3D or it leaks.
 */
import * as THREE from 'three';

/**
 * Dispose every geometry and material under `root`. Materials listed in
 * `keep` are left alone — pass shared/cached materials (piece materials,
 * the backpack ghost material) so instances that reuse them don't tear down
 * a material still in use elsewhere. Geometries are always per-instance here,
 * so they are always disposed.
 */
export function disposeObject3D(root: THREE.Object3D, keep?: Set<THREE.Material>): void {
  root.traverse((n) => {
    const mesh = n as Partial<THREE.Mesh>;
    mesh.geometry?.dispose?.();
    const mat = mesh.material;
    if (Array.isArray(mat)) {
      for (const m of mat) if (!keep?.has(m)) m.dispose();
    } else if (mat && !keep?.has(mat)) {
      mat.dispose();
    }
  });
}
