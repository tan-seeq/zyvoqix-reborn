/**
 * Fixed-timestep game loop (CLAUDE.md: logic at 30 Hz, rendering at display
 * rate). Systems update deterministically; the render callback receives an
 * interpolation alpha for smoothing between logic ticks.
 */
export interface System {
  update(dt: number): void;
}

const LOGIC_HZ = 30;
const LOGIC_DT = 1 / LOGIC_HZ;
const MAX_FRAME_TIME = 0.25;

export class GameLoop {
  paused = false;
  private systems: System[] = [];
  private accumulator = 0;
  private lastTime = -1;

  constructor(
    private setAnimationLoop: (cb: (timeMs: number) => void) => void,
    private onRender: (renderDt: number, alpha: number) => void,
  ) {}

  addSystem(system: System): void {
    this.systems.push(system);
  }

  start(): void {
    this.setAnimationLoop((timeMs) => this.frame(timeMs / 1000));
  }

  private frame(time: number): void {
    if (this.lastTime < 0) this.lastTime = time;
    let frameDt = Math.min(time - this.lastTime, MAX_FRAME_TIME);
    this.lastTime = time;

    if (this.paused) {
      this.onRender(0, 1);
      return;
    }

    this.accumulator += frameDt;
    while (this.accumulator >= LOGIC_DT) {
      for (const system of this.systems) system.update(LOGIC_DT);
      this.accumulator -= LOGIC_DT;
    }

    this.onRender(frameDt, this.accumulator / LOGIC_DT);
  }
}
