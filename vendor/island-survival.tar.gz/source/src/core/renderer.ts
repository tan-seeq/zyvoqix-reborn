/**
 * Renderer bootstrap: WebGPURenderer, which transparently falls back to
 * WebGL2 when WebGPU is unavailable (three/webgpu handles the detection).
 */
import * as THREE from 'three';
import { WebGPURenderer } from 'three/webgpu';

export interface RendererHandle {
  renderer: WebGPURenderer;
  /** 'webgpu' | 'webgl' — shown in the dev HUD. */
  backend: string;
}

export async function createRenderer(container: HTMLElement): Promise<RendererHandle> {
  const renderer = new WebGPURenderer({ antialias: true });
  await renderer.init();

  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  container.appendChild(renderer.domElement);

  const backend = (renderer.backend as { isWebGPUBackend?: boolean }).isWebGPUBackend ? 'webgpu' : 'webgl';
  return { renderer, backend };
}
