/**
 * Day/night cycle (PLAN.md: 20 real minutes = 1 in-game day).
 * Advances GameState time via the action bus (fixed timestep), and drives
 * sun/moon lights, sky & fog color, and star visibility per render frame.
 *
 * timeOfDay mapping: 0 = 06:00, 0.25 = noon, 0.5 = 18:00, 0.75 = midnight.
 */
import * as THREE from 'three';
import type { ActionBus } from './actions';
import type { System } from './loop';
import { mulberry32 } from '../world/rng';

const SKY_DAY = new THREE.Color(0x7ec2ec);
const SKY_DUSK = new THREE.Color(0xe8905c);
const SKY_NIGHT = new THREE.Color(0x0b1226);
const FOG_DAY = new THREE.Color(0xbcd9ec);
const FOG_NIGHT = new THREE.Color(0x0d1524);

const SUN_DISTANCE = 400;

export class DayNightCycle implements System {
  /** Settings master switch — combined with daylight in updateVisual. */
  shadowsEnabled = true;

  private sun: THREE.DirectionalLight;
  private moon: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private stars: THREE.Points;
  private starsMat: THREE.PointsMaterial;
  private sunDisc: THREE.Mesh;
  private moonDisc: THREE.Mesh;
  private skyColor = new THREE.Color();
  private fogColor = new THREE.Color();

  constructor(
    private scene: THREE.Scene,
    private bus: ActionBus,
    seed: number,
  ) {
    this.sun = new THREE.DirectionalLight(0xfff2cc, 2.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const cam = this.sun.shadow.camera;
    cam.left = -70;
    cam.right = 70;
    cam.top = 70;
    cam.bottom = -70;
    cam.near = 50;
    cam.far = 700;
    this.sun.shadow.bias = -0.0005;
    scene.add(this.sun, this.sun.target);

    this.moon = new THREE.DirectionalLight(0x8fa8d0, 0.0);
    scene.add(this.moon, this.moon.target);

    this.hemi = new THREE.HemisphereLight(0xbcd8f0, 0x3d5a3a, 0.6);
    scene.add(this.hemi);

    this.stars = this.buildStars(seed);
    this.starsMat = this.stars.material as THREE.PointsMaterial;
    scene.add(this.stars);

    // Visible celestial discs (the lights alone gave an empty sky).
    this.sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(24, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff3c0, fog: false }),
    );
    this.moonDisc = new THREE.Mesh(
      new THREE.SphereGeometry(15, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xe8edf5, fog: false }),
    );
    this.sunDisc.frustumCulled = false;
    this.moonDisc.frustumCulled = false;
    scene.add(this.sunDisc, this.moonDisc);

    scene.background = this.skyColor;
    scene.fog = new THREE.Fog(this.fogColor, 60, 420);
  }

  /** Fixed-timestep: advance the clock through the action bus. */
  update(dt: number): void {
    this.bus.dispatch({ type: 'ADVANCE_TIME', dt });
  }

  /** In-game clock, e.g. "14:30". */
  get clockText(): string {
    const hours = (6 + this.bus.state.timeOfDay * 24) % 24;
    const h = Math.floor(hours);
    const m = Math.floor((hours - h) * 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  /** Per render frame: position lights and blend sky colors. */
  updateVisual(playerPos: THREE.Vector3): void {
    const t = this.bus.state.timeOfDay;
    const sunAngle = t * Math.PI * 2; // 0 = sunrise (east horizon)
    const sunDir = new THREE.Vector3(Math.cos(sunAngle), Math.sin(sunAngle), 0.35).normalize();
    const moonDir = sunDir.clone().negate();

    const sunElev = sunDir.y; // -1..1
    const daylight = THREE.MathUtils.smoothstep(sunElev, -0.08, 0.25);
    const duskBand = Math.max(0, 1 - Math.abs(sunElev) / 0.28) * (sunElev > -0.15 ? 1 : 0);
    const night = 1 - daylight;

    this.sun.position.copy(playerPos).addScaledVector(sunDir, SUN_DISTANCE);
    this.sun.target.position.copy(playerPos);
    this.sun.intensity = 2.6 * daylight;
    this.sun.color.setHex(0xfff2cc).lerp(new THREE.Color(0xff9a55), duskBand);
    this.sun.castShadow = this.shadowsEnabled && daylight > 0.02;

    this.moon.position.copy(playerPos).addScaledVector(moonDir, SUN_DISTANCE);
    this.moon.target.position.copy(playerPos);
    this.moon.intensity = 0.35 * night * Math.max(0, moonDir.y);

    this.hemi.intensity = 0.15 + 0.5 * daylight;

    this.skyColor.copy(SKY_NIGHT).lerp(SKY_DAY, daylight).lerp(SKY_DUSK, duskBand * 0.7);
    this.fogColor.copy(FOG_NIGHT).lerp(FOG_DAY, daylight).lerp(SKY_DUSK, duskBand * 0.5);
    const fog = this.scene.fog as THREE.Fog;
    fog.color.copy(this.fogColor);

    this.starsMat.opacity = Math.max(0, night - 0.25) / 0.75;
    this.stars.visible = this.starsMat.opacity > 0.01;
    this.stars.position.copy(playerPos);

    // Sun & moon discs ride the same directions as their lights.
    this.sunDisc.position.copy(playerPos).addScaledVector(sunDir, 750);
    this.sunDisc.visible = sunElev > -0.06;
    (this.sunDisc.material as THREE.MeshBasicMaterial).color
      .setHex(0xfff3c0)
      .lerp(new THREE.Color(0xff8c4a), duskBand);
    this.moonDisc.position.copy(playerPos).addScaledVector(moonDir, 750);
    this.moonDisc.visible = moonDir.y > -0.06;
  }

  private buildStars(seed: number): THREE.Points {
    const rand = mulberry32(seed ^ 0x57a5);
    const count = 900;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      // Random points on the upper hemisphere of a big dome.
      const theta = rand() * Math.PI * 2;
      const y = 0.08 + rand() * 0.92;
      const r = Math.sqrt(1 - y * y);
      positions[i * 3] = Math.cos(theta) * r * 800;
      positions[i * 3 + 1] = y * 800;
      positions[i * 3 + 2] = Math.sin(theta) * r * 800;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xdfe8ff,
      size: 1.6,
      sizeAttenuation: false,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      fog: false,
    });
    const points = new THREE.Points(geo, mat);
    points.frustumCulled = false;
    return points;
  }
}
