/**
 * Keyboard + pointer-lock mouse input. Systems poll key state per tick;
 * mouse deltas accumulate and are consumed once per render frame.
 */
export class Input {
  private keys = new Set<string>();
  private mouseDX = 0;
  private mouseDY = 0;
  private clicked = false;
  private clickedUnlocked = false;
  private rightClickedUnlocked = false;
  /** Cursor position in client px — used by the Σακίδιο's hover raycast. */
  cursorX = 0;
  cursorY = 0;
  /** True while the right mouse button is held — shield block. */
  rightHeld = false;
  pointerLocked = false;
  onLockChange: ((locked: boolean) => void) | null = null;

  constructor(private lockTarget: HTMLElement) {
    window.addEventListener('keydown', (e) => {
      if (e.code === 'F3' || e.code === 'Tab') e.preventDefault();
      this.keys.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => {
      this.keys.clear();
      this.rightHeld = false;
    });

    document.addEventListener('mousedown', (e) => {
      if (e.button === 0) {
        if (this.pointerLocked) this.clicked = true;
        else this.clickedUnlocked = true;
      } else if (e.button === 2) {
        this.rightHeld = true;
        if (!this.pointerLocked) this.rightClickedUnlocked = true;
      }
    });
    document.addEventListener('mouseup', (e) => {
      if (e.button === 2) this.rightHeld = false;
    });
    document.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('mousemove', (e) => {
      this.cursorX = e.clientX;
      this.cursorY = e.clientY;
      if (!this.pointerLocked) return;
      this.mouseDX += e.movementX;
      this.mouseDY += e.movementY;
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === this.lockTarget;
      if (!this.pointerLocked) this.keys.clear();
      this.onLockChange?.(this.pointerLocked);
    });
  }

  requestPointerLock(): void {
    this.lockTarget.requestPointerLock();
  }

  isDown(code: string): boolean {
    return this.keys.has(code);
  }

  /** Returns accumulated mouse movement since last call and resets it. */
  consumeMouseDelta(): { dx: number; dy: number } {
    const d = { dx: this.mouseDX, dy: this.mouseDY };
    this.mouseDX = 0;
    this.mouseDY = 0;
    return d;
  }

  /** One-shot left-click check (only registered while pointer-locked). */
  consumeClick(): boolean {
    const c = this.clicked;
    this.clicked = false;
    return c;
  }

  /** One-shot left-click check for UNLOCKED cursor mode (Σακίδιο). */
  consumeUnlockedClick(): boolean {
    const c = this.clickedUnlocked;
    this.clickedUnlocked = false;
    return c;
  }

  /** One-shot right-click check for UNLOCKED cursor mode (drop items). */
  consumeUnlockedRightClick(): boolean {
    const c = this.rightClickedUnlocked;
    this.rightClickedUnlocked = false;
    return c;
  }

  /** One-shot key press check with automatic clearing (for toggles). */
  consumeKey(code: string): boolean {
    if (this.keys.has(code)) {
      this.keys.delete(code);
      return true;
    }
    return false;
  }
}
