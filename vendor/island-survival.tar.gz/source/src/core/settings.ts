/**
 * Player settings (PLAN Phase 7 item, pulled forward with the game shell):
 * persisted in localStorage separately from game saves — they belong to the
 * device/player, not the playthrough.
 */
import type { LocalePreference } from '../i18n';

export interface Settings {
  /** Mouse look multiplier (0.5–2). */
  sensitivity: number;
  /** Camera field of view in degrees (60–90). */
  fov: number;
  shadows: boolean;
  /** Render resolution scale (0.75 = performance, 1 = normal). */
  pixelRatio: number;
  /** Master audio volume (0–1). */
  volume: number;
  /** UI language; 'auto' follows the browser. */
  language: LocalePreference;
}

export const DEFAULT_SETTINGS: Settings = {
  sensitivity: 1,
  fov: 72,
  shadows: true,
  pixelRatio: 1,
  volume: 0.8,
  language: 'auto',
};

const KEY = 'island-survival:settings';

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<Settings>) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: Settings): void {
  localStorage.setItem(KEY, JSON.stringify(settings));
}
