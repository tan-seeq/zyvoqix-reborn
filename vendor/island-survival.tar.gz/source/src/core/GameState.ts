/**
 * Central serializable game state. Everything that must survive a save/load
 * lives here — never Three.js or Rapier objects. Meshes and colliders are
 * recreated from this state (+ the world seed) on load.
 */
import type { ItemId } from '../survival/items';

export interface PlayerState {
  pos: [number, number, number];
  yaw: number;
  pitch: number;
  /** Weapon toggled active from the hotbar; null = auto-best when attacking. */
  equippedWeapon: ItemId | null;
}

export interface SurvivalStats {
  /** All 0–100. At 0 hunger/thirst, health starts draining. */
  health: number;
  hunger: number;
  thirst: number;
  energy: number;
}

export interface InventorySlot {
  itemId: ItemId;
  count: number;
}

export type PlacedObjectType =
  | 'campfire'
  | 'foundation'
  | 'wall'
  | 'wall_door'
  | 'wall_window'
  | 'roof'
  | 'floor'
  | 'stairs'
  | 'chest'
  | 'bed';

export interface PlacedObject {
  id: string;
  type: PlacedObjectType;
  pos: [number, number, number];
  rotY: number;
}

export interface WorldState {
  /** IDs of world objects (trees/rocks/bushes) that no longer exist. */
  removedObjectIds: string[];
  /** Accumulated harvest damage per object ID (partial chops). */
  objectDamage: Record<string, number>;
  /** Player-built structures (campfires now; Phase 3 buildings later). */
  placedObjects: PlacedObject[];
  /** Monotonic counter so placed-object IDs stay unique across removals. */
  nextPlacedId: number;
  /** Open/closed state per wall_door ID (absent = closed). */
  doorOpen: Record<string, boolean>;
  /** Chest contents per chest ID. */
  containers: Record<string, InventorySlot[]>;
  /** Accumulated raid damage per placed-structure ID. */
  structureDamage: Record<string, number>;
  /** Day a bush was harvested — bushes regrow BUSH_REGROW_DAYS later. */
  removedAtDay: Record<string, number>;
}

export interface ProgressState {
  /** XP toward the NEXT level (resets on level-up). */
  xp: number;
  level: number;
  /** Lifetime event counters (trees chopped, kills...) — quests read these. */
  counters: Record<string, number>;
  completedQuests: string[];
}

export interface LoreState {
  /** Finding IDs the player has collected (Phase 6). Drives Hollow One escalation. */
  collectedFindings: string[];
}

export interface GameState {
  version: 1;
  seed: number;
  /** Days survived, starting at 1. */
  day: number;
  /** 0..1 — 0 = 06:00 (sunrise), 0.25 = noon, 0.5 = 18:00, 0.75 = midnight. */
  timeOfDay: number;
  player: PlayerState;
  /** Respawn point (beach), set once at world creation. */
  spawn: [number, number, number];
  survival: SurvivalStats;
  /** Hotbar-sized inventory for Phase 2 v1 (the Σακίδιο expands this later). */
  inventory: InventorySlot[];
  world: WorldState;
  lore: LoreState;
  progress: ProgressState;
}

/** Total bag capacity (materials & everything — shown on the Σακίδιο cloth). */
export const INVENTORY_SLOTS = 24;
/** Hotbar slots — a FILTERED view of the bag: only usable items claim one. */
export const HOTBAR_SLOTS = 8;
export const CONTAINER_SLOTS = 12;

export function createInitialState(seed: number): GameState {
  return {
    version: 1,
    seed,
    day: 1,
    timeOfDay: 0.08, // early morning
    player: { pos: [0, 5, 0], yaw: 0, pitch: 0, equippedWeapon: null },
    spawn: [0, 5, 0],
    survival: { health: 100, hunger: 90, thirst: 85, energy: 100 },
    inventory: [],
    world: {
      removedObjectIds: [],
      objectDamage: {},
      placedObjects: [],
      nextPlacedId: 1,
      doorOpen: {},
      containers: {},
      structureDamage: {},
      removedAtDay: {},
    },
    lore: { collectedFindings: [] },
    progress: { xp: 0, level: 1, counters: { day: 1 }, completedQuests: [] },
  };
}

/** Night begins ~19:10 (timeOfDay 0 = 06:00). Sleep & Hollow Ones key off this. */
export const NIGHT_START = 0.54;

/** Harvested bushes regrow after this many days (fiber/berries stay renewable). */
export const BUSH_REGROW_DAYS = 3;

/** Every Nth night is a raid night — the Hollow Ones attack the base. */
export const RAID_NIGHT_INTERVAL = 5;

export function isNight(state: GameState): boolean {
  return state.timeOfDay >= NIGHT_START;
}
