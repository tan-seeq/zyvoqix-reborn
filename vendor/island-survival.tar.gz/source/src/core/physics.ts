/**
 * Rapier bootstrap (async WASM load) + debug wireframe rendering (F3).
 */
import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';

export async function initPhysics(): Promise<{ rapier: typeof RAPIER; world: RAPIER.World }> {
  await RAPIER.init();
  const world = new RAPIER.World({ x: 0, y: -9.81, z: 0 });
  return { rapier: RAPIER, world };
}

/** Renders Rapier's debug wireframes as line segments; toggled with F3. */
export class PhysicsDebugRenderer {
  enabled = false;
  private lines: THREE.LineSegments;

  constructor(scene: THREE.Scene, private world: RAPIER.World) {
    this.lines = new THREE.LineSegments(
      new THREE.BufferGeometry(),
      new THREE.LineBasicMaterial({ vertexColors: true }),
    );
    this.lines.frustumCulled = false;
    this.lines.visible = false;
    scene.add(this.lines);
  }

  toggle(): void {
    this.enabled = !this.enabled;
    this.lines.visible = this.enabled;
  }

  update(): void {
    if (!this.enabled) return;
    const { vertices, colors } = this.world.debugRender();
    this.lines.geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    this.lines.geometry.setAttribute('color', new THREE.BufferAttribute(colors, 4));
  }
}
