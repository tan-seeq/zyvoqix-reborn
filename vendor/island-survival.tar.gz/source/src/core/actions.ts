/**
 * Every world mutation flows through an Action applied by the reducer below.
 * Rendering/physics systems subscribe and react — they never mutate GameState
 * directly. This is the seam where a future co-op server plugs in (PLAN.md
 * Phase 8): the same actions get serialized over the network unchanged.
 */
import type { GameState, InventorySlot, PlacedObjectType } from './GameState';
import { CONTAINER_SLOTS, INVENTORY_SLOTS, NIGHT_START } from './GameState';
import { ITEM_DEFS, armorDamageFactor, type ItemId } from '../survival/items';
import { RECIPES, canAfford, countItem } from '../survival/crafting';
import { isEquippable } from '../survival/items';
import { MAX_LEVEL, QUESTS, sprintDrainFactor, xpForNextLevel } from '../survival/quests';
import { BUILD_DEFS, buildDefFor, STRUCTURE_HP, type BuildType } from '../building/pieces';
import { BUSH_REGROW_DAYS } from './GameState';

export type Action =
  | { type: 'REMOVE_WORLD_OBJECT'; objectId: string }
  | { type: 'DAMAGE_WORLD_OBJECT'; objectId: string; damage: number }
  | { type: 'SET_PLAYER_TRANSFORM'; pos: [number, number, number]; yaw: number; pitch: number }
  | { type: 'ADVANCE_TIME'; dt: number }
  | { type: 'ADD_ITEM'; itemId: ItemId; count: number }
  | { type: 'REMOVE_ITEM'; itemId: ItemId; count: number }
  | { type: 'MODIFY_STATS'; health?: number; hunger?: number; thirst?: number; energy?: number }
  | { type: 'HURT_PLAYER'; amount: number }
  | { type: 'EQUIP'; itemId: ItemId | null }
  | { type: 'STATS_TICK'; dt: number; sprinting: boolean }
  | { type: 'CRAFT'; recipeId: string }
  | { type: 'PLACE_OBJECT'; objectType: PlacedObjectType; pos: [number, number, number]; rotY: number }
  | { type: 'BUILD'; buildType: BuildType; pos: [number, number, number]; rotY: number }
  | { type: 'TOGGLE_DOOR'; objectId: string }
  | { type: 'DEMOLISH'; objectId: string }
  | { type: 'DAMAGE_STRUCTURE'; objectId: string; damage: number }
  | { type: 'REPAIR_STRUCTURE'; objectId: string }
  | { type: 'SET_SPAWN'; pos: [number, number, number] }
  | { type: 'STORE_ITEM'; containerId: string; itemId: ItemId; count: number }
  | { type: 'TAKE_ITEM'; containerId: string; itemId: ItemId; count: number }
  | { type: 'SLEEP' }
  | { type: 'RECORD_KILL'; kind: string }
  | { type: 'RESPAWN' };

/** Real seconds per full in-game day (PLAN.md: 20 minutes). */
export const DAY_LENGTH_SECONDS = 20 * 60;

// Stat decay per real second (thirst faster than hunger — PLAN.md Phase 2).
const THIRST_RATE = 100 / (1.6 * DAY_LENGTH_SECONDS); // empty in ~1.6 game days
const HUNGER_RATE = 100 / (2.6 * DAY_LENGTH_SECONDS);
const ENERGY_SPRINT_DRAIN = 100 / 170; // ~3 min of continuous sprinting
const ENERGY_REGEN = 100 / 420;
const STARVATION_DAMAGE = 1.3; // health/s per depleted stat
const HEALTH_REGEN = 0.6; // health/s when well fed & hydrated

/**
 * Clear a stale equip when the last unit of the held item leaves the bag
 * (dropped, stored in a chest...). Without this the viewmodel keeps showing
 * — and weaponDamage() keeps using — an item the player no longer owns.
 */
function unequipIfGone(state: GameState): void {
  const eq = state.player.equippedWeapon;
  if (eq && !state.inventory.some((s) => s.itemId === eq && s.count > 0)) {
    state.player.equippedWeapon = null;
  }
}

function clamp01to100(v: number): number {
  return Math.min(100, Math.max(0, v));
}

/**
 * Stack `count` of an item into a slot list. ONE slot per item type — the
 * def's `stack` is the total carry cap. Returns the un-fitted leftover.
 */
function addToSlots(slots: InventorySlot[], itemId: ItemId, count: number, maxSlots: number): number {
  const def = ITEM_DEFS[itemId];
  let slot = slots.find((s) => s.itemId === itemId);
  if (!slot) {
    if (slots.length >= maxSlots) return count;
    slot = { itemId, count: 0 };
    slots.push(slot);
  }
  const take = Math.min(def.stack - slot.count, count);
  slot.count += take;
  if (slot.count === 0) slots.splice(slots.indexOf(slot), 1);
  return count - take;
}

/** Bring back bushes harvested ≥ BUSH_REGROW_DAYS ago (fiber/berries renew). */
function regrowBushes(state: GameState): void {
  for (const [id, day] of Object.entries(state.world.removedAtDay)) {
    if (state.day - day < BUSH_REGROW_DAYS) continue;
    const idx = state.world.removedObjectIds.indexOf(id);
    if (idx !== -1) state.world.removedObjectIds.splice(idx, 1);
    delete state.world.removedAtDay[id];
  }
}

/** Shared teardown for destroyed/demolished structures. */
function deleteStructureRecords(state: GameState, objectId: string): void {
  delete state.world.doorOpen[objectId];
  delete state.world.containers[objectId];
  delete state.world.structureDamage[objectId];
}

/** Remove up to `count` of an item from a slot list. Returns how many were removed. */
function removeFromSlots(slots: InventorySlot[], itemId: ItemId, count: number): number {
  let remaining = count;
  for (let i = slots.length - 1; i >= 0 && remaining > 0; i--) {
    const slot = slots[i];
    if (slot.itemId !== itemId) continue;
    const take = Math.min(slot.count, remaining);
    slot.count -= take;
    remaining -= take;
    if (slot.count === 0) slots.splice(i, 1);
  }
  return count - remaining;
}

export function applyAction(state: GameState, action: Action): void {
  switch (action.type) {
    case 'REMOVE_WORLD_OBJECT':
      if (!state.world.removedObjectIds.includes(action.objectId)) {
        state.world.removedObjectIds.push(action.objectId);
      }
      delete state.world.objectDamage[action.objectId];
      // Bushes are renewable — remember when they were harvested.
      if (action.objectId.startsWith('bush_')) {
        state.world.removedAtDay[action.objectId] = state.day;
      }
      break;

    case 'DAMAGE_WORLD_OBJECT':
      state.world.objectDamage[action.objectId] =
        (state.world.objectDamage[action.objectId] ?? 0) + action.damage;
      break;

    case 'SET_PLAYER_TRANSFORM':
      state.player.pos = action.pos;
      state.player.yaw = action.yaw;
      state.player.pitch = action.pitch;
      break;

    case 'ADVANCE_TIME': {
      state.timeOfDay += action.dt / DAY_LENGTH_SECONDS;
      while (state.timeOfDay >= 1) {
        state.timeOfDay -= 1;
        state.day += 1;
        regrowBushes(state);
      }
      break;
    }

    case 'ADD_ITEM':
      // Overflow beyond the slot cap is discarded for now (the Σακίδιο will surface this).
      addToSlots(state.inventory, action.itemId, action.count, INVENTORY_SLOTS);
      break;

    case 'REMOVE_ITEM':
      removeFromSlots(state.inventory, action.itemId, action.count);
      unequipIfGone(state);
      break;

    case 'STORE_ITEM': {
      const container = (state.world.containers[action.containerId] ??= []);
      const moved = removeFromSlots(state.inventory, action.itemId, action.count);
      const leftover = addToSlots(container, action.itemId, moved, CONTAINER_SLOTS);
      if (leftover > 0) addToSlots(state.inventory, action.itemId, leftover, INVENTORY_SLOTS);
      unequipIfGone(state);
      break;
    }

    case 'TAKE_ITEM': {
      const container = state.world.containers[action.containerId];
      if (!container) break;
      const moved = removeFromSlots(container, action.itemId, action.count);
      const leftover = addToSlots(state.inventory, action.itemId, moved, INVENTORY_SLOTS);
      if (leftover > 0) addToSlots(container, action.itemId, leftover, CONTAINER_SLOTS);
      break;
    }

    case 'EQUIP':
      // null unequips; otherwise it must be an equippable the player carries
      // (weapons + torch — the hotbar dispatches via the same isEquippable).
      if (action.itemId === null) state.player.equippedWeapon = null;
      else if (isEquippable(action.itemId) && countItem(state, action.itemId) > 0) {
        state.player.equippedWeapon = action.itemId;
      }
      break;

    case 'TOGGLE_DOOR':
      state.world.doorOpen[action.objectId] = !state.world.doorOpen[action.objectId];
      break;

    case 'SET_SPAWN':
      state.spawn = action.pos;
      break;

    case 'DAMAGE_STRUCTURE': {
      const obj = state.world.placedObjects.find((o) => o.id === action.objectId);
      if (!obj) break;
      const total = (state.world.structureDamage[obj.id] ?? 0) + action.damage;
      const maxHp = STRUCTURE_HP[obj.type] ?? 100;
      if (total < maxHp) {
        state.world.structureDamage[obj.id] = total;
        break;
      }
      // Destroyed: no refund, chest contents are lost to the raid.
      state.world.placedObjects.splice(state.world.placedObjects.indexOf(obj), 1);
      deleteStructureRecords(state, obj.id);
      break;
    }

    case 'REPAIR_STRUCTURE': {
      const obj = state.world.placedObjects.find((o) => o.id === action.objectId);
      if (!obj || !(state.world.structureDamage[obj.id] > 0)) break;
      if (countItem(state, 'log') < 1) break;
      applyAction(state, { type: 'REMOVE_ITEM', itemId: 'log', count: 1 });
      delete state.world.structureDamage[obj.id];
      break;
    }

    case 'DEMOLISH': {
      const idx = state.world.placedObjects.findIndex((o) => o.id === action.objectId);
      if (idx === -1) break;
      const obj = state.world.placedObjects[idx];
      // A chest must be emptied first — its contents would be lost.
      if (obj.type === 'chest' && (state.world.containers[obj.id]?.length ?? 0) > 0) return;
      state.world.placedObjects.splice(idx, 1);
      deleteStructureRecords(state, obj.id);
      // Refund half the build cost (campfires burn their kit — no refund).
      const def = BUILD_DEFS.find((d) => d.type === obj.type);
      if (def) {
        for (const c of def.cost) {
          const refund = Math.floor(c.count / 2);
          if (refund > 0) addToSlots(state.inventory, c.itemId, refund, INVENTORY_SLOTS);
        }
      }
      break;
    }

    case 'MODIFY_STATS': {
      const s = state.survival;
      s.health = clamp01to100(s.health + (action.health ?? 0));
      s.hunger = clamp01to100(s.hunger + (action.hunger ?? 0));
      s.thirst = clamp01to100(s.thirst + (action.thirst ?? 0));
      s.energy = clamp01to100(s.energy + (action.energy ?? 0));
      break;
    }

    case 'HURT_PLAYER': {
      // Single choke point for enemy damage, so armor applies here only —
      // never to sickness, starvation, or healing (those use MODIFY_STATS).
      const s = state.survival;
      s.health = clamp01to100(s.health - action.amount * armorDamageFactor(state.inventory));
      break;
    }

    case 'STATS_TICK': {
      const s = state.survival;
      const dt = action.dt;
      s.hunger = clamp01to100(s.hunger - HUNGER_RATE * dt);
      s.thirst = clamp01to100(s.thirst - THIRST_RATE * dt);
      s.energy = clamp01to100(
        s.energy +
          (action.sprinting
            ? -ENERGY_SPRINT_DRAIN * sprintDrainFactor(state.progress.level)
            : ENERGY_REGEN) * dt,
      );
      let healthDelta = 0;
      if (s.hunger <= 0) healthDelta -= STARVATION_DAMAGE * dt;
      if (s.thirst <= 0) healthDelta -= STARVATION_DAMAGE * dt;
      if (healthDelta === 0 && s.hunger > 60 && s.thirst > 60 && s.health < 100) {
        healthDelta = HEALTH_REGEN * dt;
      }
      s.health = clamp01to100(s.health + healthDelta);
      break;
    }

    case 'CRAFT': {
      const recipe = RECIPES.find((r) => r.id === action.recipeId);
      if (!recipe) break;
      // Validate first — a stale/duplicated action must not half-apply.
      for (const ing of recipe.ingredients) {
        if (countItem(state, ing.itemId) < ing.count) return;
      }
      for (const ing of recipe.ingredients) {
        applyAction(state, { type: 'REMOVE_ITEM', itemId: ing.itemId, count: ing.count });
      }
      applyAction(state, { type: 'ADD_ITEM', itemId: recipe.result.itemId, count: recipe.result.count });
      break;
    }

    case 'PLACE_OBJECT': {
      const id = `${action.objectType}_p${state.world.nextPlacedId++}`;
      state.world.placedObjects.push({ id, type: action.objectType, pos: action.pos, rotY: action.rotY });
      break;
    }

    case 'BUILD': {
      // Validate cost first — a stale action must not half-apply.
      const def = buildDefFor(action.buildType);
      if (!canAfford(state, def.cost)) return;
      for (const c of def.cost) {
        applyAction(state, { type: 'REMOVE_ITEM', itemId: c.itemId, count: c.count });
      }
      applyAction(state, {
        type: 'PLACE_OBJECT', objectType: action.buildType, pos: action.pos, rotY: action.rotY,
      });
      break;
    }

    case 'SLEEP': {
      // Only valid at night; sleeping always crosses midnight → next morning.
      if (state.timeOfDay < NIGHT_START) break;
      state.day += 1;
      regrowBushes(state);
      state.timeOfDay = 0.021; // ~06:30
      const s = state.survival;
      s.energy = 100;
      s.hunger = Math.max(5, s.hunger - 8);
      s.thirst = Math.max(5, s.thirst - 10);
      break;
    }

    case 'RECORD_KILL':
      break; // handled entirely by trackProgress below

    case 'RESPAWN': {
      // Death penalty: wake up on the beach, half of every stack gone.
      state.player.pos = [...state.spawn];
      state.survival = { health: 60, hunger: 55, thirst: 55, energy: 70 };
      state.inventory = state.inventory
        .map((slot) => ({ ...slot, count: Math.floor(slot.count / 2) }))
        .filter((slot) => slot.count > 0);
      break;
    }
  }

  trackProgress(state, action);
}

function bump(state: GameState, counter: string, amount = 1): void {
  state.progress.counters[counter] = (state.progress.counters[counter] ?? 0) + amount;
}

/**
 * Quests & XP: derive progress from the actions that already describe every
 * world event, then award XP for newly completed quests and roll levels.
 * Runs at the end of every applyAction (including nested ones like CRAFT's
 * internal item moves — intended: those ARE crafting/collecting events).
 */
function trackProgress(state: GameState, action: Action): void {
  switch (action.type) {
    case 'REMOVE_WORLD_OBJECT':
      if (action.objectId.startsWith('tree_')) bump(state, 'tree');
      else if (action.objectId.startsWith('rock_')) bump(state, 'rock');
      else if (action.objectId.startsWith('bush_')) bump(state, 'bush');
      break;
    case 'BUILD':
      bump(state, 'build');
      break;
    case 'CRAFT':
      bump(state, 'craft');
      break;
    case 'PLACE_OBJECT':
      if (action.objectType === 'campfire') bump(state, 'campfire');
      break;
    case 'ADD_ITEM':
      bump(state, 'items', action.count);
      if (action.itemId === 'meat_cooked') bump(state, 'cook');
      break;
    case 'RECORD_KILL':
      bump(state, 'kill_any');
      bump(state, `kill_${action.kind}`);
      break;
  }
  // Day high-water mark for the survive quests.
  if (state.day > (state.progress.counters.day ?? 1)) state.progress.counters.day = state.day;

  for (const quest of QUESTS) {
    if (state.progress.completedQuests.includes(quest.id)) continue;
    if ((state.progress.counters[quest.counter] ?? 0) >= quest.target) {
      state.progress.completedQuests.push(quest.id);
      state.progress.xp += quest.xp;
    }
  }
  while (
    state.progress.level < MAX_LEVEL &&
    state.progress.xp >= xpForNextLevel(state.progress.level)
  ) {
    state.progress.xp -= xpForNextLevel(state.progress.level);
    state.progress.level += 1;
  }
}

export type ActionListener = (action: Action, state: GameState) => void;

export class ActionBus {
  private listeners: ActionListener[] = [];

  constructor(readonly state: GameState) {}

  dispatch(action: Action): void {
    applyAction(this.state, action);
    for (const listener of this.listeners) listener(action, this.state);
  }

  subscribe(listener: ActionListener): void {
    this.listeners.push(listener);
  }
}
