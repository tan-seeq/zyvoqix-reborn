/**
 * Audio system (SOUNDS.md): every sound has an ID matching a filename in
 * `public/assets/audio/<id>.ogg`. If the file exists it is used; until the
 * custom recordings land, a PROCEDURAL placeholder is synthesized per ID so
 * the game is never silent. Variants (`<id>_1.ogg`...) are picked randomly
 * when present. Master volume lives in Settings.
 *
 * One-shots: play(id). Loops: setLoop(id, on, volume) — idempotent per frame.
 */

export type SoundId =
  // ambience & fire
  | 'amb_waves' | 'amb_day_cicadas' | 'amb_night' | 'campfire_loop' | 'torch_loop' | 'fire_light'
  // player
  | 'step_grass' | 'hurt' | 'death' | 'eat' | 'drink' | 'sleep' | 'morning' | 'bandage_use'
  // harvesting & combat
  | 'chop_wood' | 'tree_fall' | 'hit_stone' | 'bush_rustle' | 'pickup' | 'swing'
  | 'bow_release' | 'shield_block' | 'animal_die' | 'wolf_howl'
  // backpack & crafting
  | 'backpack_open' | 'backpack_close' | 'craft_done'
  // building
  | 'build_place' | 'door_open' | 'door_close' | 'chest_open' | 'chest_close'
  | 'repair' | 'structure_hit' | 'structure_break' | 'demolish'
  // hollows & story beats
  | 'hollow_whisper' | 'hollow_dissolve' | 'raid_start';

const AUDIO_BASE = './assets/audio';
// This release ships procedural audio only; no optional recording requests.
const SHIPPED_RECORDINGS: string[] = [];
/**
 * Ambience loops are the one place a synthetic placeholder hurts more than it
 * helps: they play CONSTANTLY, so any artificial hiss/buzz becomes the sound of
 * the game. These ids stay SILENT until a real recording exists in
 * `public/assets/audio/` — then they fade in automatically. One-shots keep
 * their placeholders (short, informative, and never repeat for minutes).
 */
const FILE_ONLY_LOOPS = new Set<SoundId>(['amb_waves', 'amb_day_cicadas', 'amb_night']);
/** Seconds to fade a loop in/out — abrupt starts/stops read as bugs. */
const LOOP_FADE = 1.5;
/** Minimum ms between two plays of the SAME id (burst loot → one pickup). */
const REPLAY_GUARD_MS = 90;

export class AudioSystem {
  private ctx = new AudioContext();
  private master = this.ctx.createGain();
  private files = new Map<string, AudioBuffer[] | 'missing' | 'loading'>();
  private synths = new Map<string, AudioBuffer>();
  private loops = new Map<string, { src: AudioBufferSourceNode; gain: GainNode; id: SoundId }>();
  private lastPlay = new Map<string, number>();

  constructor(volume: number) {
    this.master.gain.value = volume;
    this.master.connect(this.ctx.destination);
    // Browsers start the context suspended until a user gesture.
    const resume = () => {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
    };
    window.addEventListener('pointerdown', resume);
    window.addEventListener('keydown', resume);
  }

  setVolume(v: number): void {
    this.master.gain.value = v;
  }

  play(id: SoundId, volume = 1, rate = 1): void {
    const now = performance.now();
    if (now - (this.lastPlay.get(id) ?? -1e9) < REPLAY_GUARD_MS) return;
    this.lastPlay.set(id, now);
    const buf = this.bufferFor(id);
    if (!buf) return;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate * (0.94 + Math.random() * 0.12);
    const gain = this.ctx.createGain();
    gain.gain.value = volume;
    src.connect(gain).connect(this.master);
    src.start();
  }

  /** Idempotent loop control — call every frame with the desired state. */
  setLoop(id: SoundId, on: boolean, volume = 1): void {
    const running = this.loops.get(id);
    if (!on) {
      if (running) this.stopLoop(id, running);
      return;
    }
    if (running) {
      // Ramp rather than jump: volume changes mid-loop (fire distance) glide.
      running.gain.gain.cancelScheduledValues(this.ctx.currentTime);
      running.gain.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + 0.25);
      return;
    }
    const buf = this.bufferFor(id, FILE_ONLY_LOOPS.has(id));
    if (!buf) return; // ambience with no recording yet — stay silent
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + LOOP_FADE);
    src.connect(gain).connect(this.master);
    src.start();
    this.loops.set(id, { src, gain, id });
  }

  /** Fade a loop out and free it; the map entry goes immediately. */
  private stopLoop(id: SoundId, running: { src: AudioBufferSourceNode; gain: GainNode }): void {
    const t = this.ctx.currentTime;
    running.gain.gain.cancelScheduledValues(t);
    running.gain.gain.setValueAtTime(running.gain.gain.value, t);
    running.gain.gain.linearRampToValueAtTime(0, t + LOOP_FADE);
    running.src.stop(t + LOOP_FADE + 0.05);
    this.loops.delete(id);
  }

  // ---------- buffer resolution: file → synth fallback ----------

  private bufferFor(id: SoundId, fileOnly = false): AudioBuffer | null {
    const state = this.files.get(id);
    if (Array.isArray(state) && state.length > 0) {
      return state[Math.floor(Math.random() * state.length)];
    }
    if (state === undefined) this.tryLoadFiles(id); // kick off once, play synth now
    if (fileOnly) return null;
    let synth = this.synths.get(id);
    if (!synth) {
      synth = this.synthesize(id);
      this.synths.set(id, synth);
    }
    return synth;
  }

  private async tryLoadFiles(id: SoundId): Promise<void> {
    this.files.set(id, 'loading');
    const found: AudioBuffer[] = [];
    for (const name of SHIPPED_RECORDINGS.filter(name => name === id || name.startsWith(`${id}_`))) {
      try {
        const res = await fetch(`${AUDIO_BASE}/${name}.ogg`);
        if (!res.ok) continue;
        const type = res.headers.get('content-type') ?? '';
        if (type.includes('text/html')) continue; // SPA fallback page, not audio
        found.push(await this.ctx.decodeAudioData(await res.arrayBuffer()));
      } catch {
        /* missing or undecodable — fall through to synth */
      }
    }
    this.files.set(id, found.length > 0 ? found : 'missing');
    // Hot-swap: a loop already running on its synth placeholder restarts on
    // the real recording — always-on loops (waves) would otherwise never
    // pick the file up.
    const running = this.loops.get(id);
    if (found.length > 0 && running) {
      const volume = running.gain.gain.value;
      this.stopLoop(id, running); // crossfades: old fades out while the file fades in
      this.setLoop(id, true, volume);
    }
  }

  // ---------- procedural placeholders ----------

  private synthesize(id: SoundId): AudioBuffer {
    switch (id) {
      // loops
      case 'amb_waves': return this.noiseLoop(6, 0.16, 400, (t) => 0.55 + 0.45 * Math.sin(t * 0.9));
      case 'amb_day_cicadas': return this.cicadas();
      case 'amb_night': return this.crickets();
      case 'campfire_loop': return this.crackle(4, 0.5);
      case 'torch_loop': return this.crackle(3, 0.35);
      // impacts & materials
      case 'chop_wood': return this.thud(0.09, 900, 0.5);
      case 'hit_stone': return this.thud(0.07, 1800, 0.4);
      case 'build_place': return this.thud(0.22, 300, 0.8);
      case 'repair': return this.thud(0.1, 700, 0.5);
      case 'structure_hit': return this.thud(0.25, 200, 0.9);
      case 'structure_break': return this.noiseBurst(0.6, 500, 0.8);
      case 'demolish': return this.noiseBurst(0.45, 700, 0.6);
      case 'tree_fall': return this.noiseBurst(0.9, 250, 0.9);
      case 'shield_block': return this.thud(0.12, 500, 0.7);
      // soft / cloth / foliage
      case 'bush_rustle': return this.noiseBurst(0.25, 3000, 0.35);
      case 'backpack_open': return this.noiseBurst(0.3, 2200, 0.3);
      case 'backpack_close': return this.noiseBurst(0.22, 1800, 0.3);
      case 'step_grass': return this.noiseBurst(0.09, 1400, 0.22);
      case 'bandage_use': return this.noiseBurst(0.35, 2600, 0.3);
      case 'sleep': return this.noiseBurst(0.5, 900, 0.25);
      // whooshes
      case 'swing': return this.whoosh(0.18);
      case 'bow_release': return this.whoosh(0.12);
      case 'hollow_dissolve': return this.whoosh(0.7);
      // tonal blips & stings
      case 'pickup': return this.blip([720, 990], 0.08);
      case 'craft_done': return this.blip([520, 660, 880], 0.1);
      case 'morning': return this.blip([660, 880, 1100], 0.14);
      case 'eat': return this.noiseBurst(0.3, 1100, 0.3);
      case 'drink': return this.blip([300, 260, 300], 0.1);
      case 'fire_light': return this.noiseBurst(0.4, 1600, 0.4);
      // doors & chests (creaks)
      case 'door_open': return this.creak(0.4, 160, 220);
      case 'door_close': return this.creak(0.28, 220, 140);
      case 'chest_open': return this.creak(0.3, 180, 240);
      case 'chest_close': return this.thud(0.12, 400, 0.5);
      // voices & creatures
      case 'hurt': return this.moan(0.25, 180, 0.5);
      case 'death': return this.moan(0.9, 140, 0.7);
      case 'animal_die': return this.moan(0.4, 220, 0.5);
      case 'wolf_howl': return this.howl();
      case 'hollow_whisper': return this.whisper(1.6);
      case 'raid_start': return this.drone(1.8, 55);
    }
  }

  private makeBuffer(dur: number, fill: (t: number, i: number) => number): AudioBuffer {
    const rate = this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, Math.max(1, Math.floor(dur * rate)), rate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = fill(i / rate, i);
    return buf;
  }

  /** One-pole lowpassed noise burst with exponential decay. */
  private noiseBurst(dur: number, cutoff: number, vol: number): AudioBuffer {
    let lp = 0;
    const k = Math.min(1, (cutoff * 2 * Math.PI) / this.ctx.sampleRate);
    return this.makeBuffer(dur, (t) => {
      lp += k * ((Math.random() * 2 - 1) - lp);
      return lp * vol * Math.exp(-3.5 * (t / dur));
    });
  }

  /** Punchy hit: noise attack + descending sine body. */
  private thud(dur: number, cutoff: number, vol: number): AudioBuffer {
    let lp = 0;
    const k = Math.min(1, (cutoff * 2 * Math.PI) / this.ctx.sampleRate);
    return this.makeBuffer(dur, (t) => {
      lp += k * ((Math.random() * 2 - 1) - lp);
      const body = Math.sin(2 * Math.PI * (90 + 60 * (1 - t / dur)) * t) * 0.5;
      return (lp + body) * vol * Math.exp(-14 * t);
    });
  }

  private whoosh(dur: number): AudioBuffer {
    let lp = 0;
    return this.makeBuffer(dur, (t) => {
      const env = Math.sin((Math.PI * t) / dur);
      const k = 0.05 + 0.25 * env;
      lp += k * ((Math.random() * 2 - 1) - lp);
      return lp * env * 0.5;
    });
  }

  /** Short ascending tone sequence (positive feedback blip). */
  private blip(freqs: number[], noteDur: number): AudioBuffer {
    const dur = freqs.length * noteDur;
    return this.makeBuffer(dur, (t) => {
      const i = Math.min(freqs.length - 1, Math.floor(t / noteDur));
      const local = t - i * noteDur;
      const env = Math.exp(-9 * local) * Math.min(1, local * 200);
      return Math.sin(2 * Math.PI * freqs[i] * t) * env * 0.3;
    });
  }

  private creak(dur: number, from: number, to: number): AudioBuffer {
    return this.makeBuffer(dur, (t) => {
      const f = from + (to - from) * (t / dur) + Math.sin(t * 90) * 14;
      const saw = 2 * ((t * f) % 1) - 1;
      return saw * 0.16 * Math.sin((Math.PI * t) / dur);
    });
  }

  private moan(dur: number, freq: number, vol: number): AudioBuffer {
    return this.makeBuffer(dur, (t) => {
      const vib = Math.sin(t * 30) * 8;
      const env = Math.sin((Math.PI * t) / dur);
      const tone = Math.sin(2 * Math.PI * (freq - 40 * (t / dur) + vib) * t);
      return (tone * 0.7 + (Math.random() * 2 - 1) * 0.12) * env * vol * 0.4;
    });
  }

  private howl(): AudioBuffer {
    const dur = 1.8;
    return this.makeBuffer(dur, (t) => {
      const p = t / dur;
      const f = 300 + 240 * Math.sin(Math.PI * Math.min(1, p * 1.3));
      const env = Math.sin(Math.PI * p) ** 1.5;
      return Math.sin(2 * Math.PI * f * t) * env * 0.22;
    });
  }

  private whisper(dur: number): AudioBuffer {
    let lp = 0;
    return this.makeBuffer(dur, (t) => {
      const breath = 0.4 + 0.6 * Math.abs(Math.sin(t * 3.1) * Math.sin(t * 1.7));
      lp += 0.35 * ((Math.random() * 2 - 1) - lp);
      return lp * breath * 0.22 * Math.sin((Math.PI * t) / dur);
    });
  }

  private drone(dur: number, freq: number): AudioBuffer {
    return this.makeBuffer(dur, (t) => {
      const env = Math.sin((Math.PI * t) / dur);
      return (Math.sin(2 * Math.PI * freq * t) + Math.sin(2 * Math.PI * (freq * 1.02) * t)) * env * 0.25;
    });
  }

  /** Seamless-ish noise loop with a slow amplitude LFO (waves, wind). */
  private noiseLoop(dur: number, vol: number, cutoff: number, lfo: (t: number) => number): AudioBuffer {
    let lp = 0;
    const k = Math.min(1, (cutoff * 2 * Math.PI) / this.ctx.sampleRate);
    return this.makeBuffer(dur, (t) => {
      lp += k * ((Math.random() * 2 - 1) - lp);
      const edge = Math.min(1, Math.min(t, dur - t) * 4); // fade loop seam
      return lp * vol * lfo(t) * edge;
    });
  }

  /** Daytime: dense high-frequency pulsing (placeholder cicadas). */
  private cicadas(): AudioBuffer {
    return this.makeBuffer(5, (t) => {
      const pulse = 0.5 + 0.5 * Math.sin(2 * Math.PI * 24 * t);
      const carrier = (Math.random() * 2 - 1) * 0.5 + Math.sin(2 * Math.PI * 4200 * t) * 0.5;
      const edge = Math.min(1, Math.min(t, 5 - t) * 4);
      return carrier * pulse * 0.045 * edge;
    });
  }

  /** Night: sparse cricket chirps over near-silence. */
  private crickets(): AudioBuffer {
    return this.makeBuffer(6, (t) => {
      const cycle = t % 1.5;
      const chirp = cycle < 0.35 ? Math.abs(Math.sin(2 * Math.PI * 22 * cycle)) : 0;
      const edge = Math.min(1, Math.min(t, 6 - t) * 4);
      return Math.sin(2 * Math.PI * 3400 * t) * chirp * 0.05 * edge;
    });
  }

  /** Fire: lowpassed noise bed + random pops. */
  private crackle(dur: number, vol: number): AudioBuffer {
    let lp = 0;
    let pop = 0;
    return this.makeBuffer(dur, (t) => {
      lp += 0.04 * ((Math.random() * 2 - 1) - lp);
      if (Math.random() < 0.0004) pop = 1;
      pop *= 0.994;
      const edge = Math.min(1, Math.min(t, dur - t) * 4);
      return (lp * 0.8 + (Math.random() * 2 - 1) * pop * 0.5) * vol * 0.3 * edge;
    });
  }
}
