/**
 * Localization runtime.
 *
 * English is both the default and the fallback: `en.json` ships in the main
 * bundle, and every other locale is a lazily imported chunk that gets
 * deep-merged over it. A translation may therefore cover any subset of the
 * keys — whatever it omits renders in English instead of coming out blank.
 *
 * `STRINGS` is a live ES-module binding pointing at ONE pre-merged plain
 * object, so call sites stay `STRINGS.prompts.tree` — a direct property access
 * that V8 inline-caches. That is deliberate: `hud.ts` rebuilds its interaction
 * prompt every frame and reads `STRINGS` ~16 times per update, so a
 * `t('prompts.tree')` style path-walking lookup would allocate ~1000 throwaway
 * arrays a second and go megamorphic for no benefit. The merge happens once,
 * at locale load.
 */
import en from './en.json';
import type { ItemId } from '../survival/items';
import type { AnimalKind } from '../enemies/animals';
import type { BuildType } from '../building/pieces';
import type { QuestId } from '../survival/quests';

/** The shape of a complete locale — derived from English, the source of truth. */
export type Strings = typeof en;

/** A translation may fill in any subset; the rest falls back to English. */
export type Translation = DeepPartial<Strings>;
type DeepPartial<T> = T extends readonly unknown[]
  ? T
  : T extends object
    ? { [K in keyof T]?: DeepPartial<T[K]> }
    : T;

export const LOCALES = {
  en: { name: 'English', tag: 'en' },
  el: { name: 'Ελληνικά', tag: 'el-GR' },
} as const;

export type LocaleId = keyof typeof LOCALES;
/** 'auto' follows the browser; anything else pins the language. */
export type LocalePreference = LocaleId | 'auto';

/**
 * Translations are dynamic imports so Vite code-splits each into its own
 * chunk — a player only downloads the language they actually play in. English
 * needs no chunk (it is already the base), but it still goes through an async
 * loader so that EVERY setLocale path yields before notifying listeners:
 * subscribers rebuild DOM, and the language <select> must not have the panel
 * torn out from under it while its own change handler is still running.
 */
const LOADERS: Record<LocaleId, () => Promise<Translation>> = {
  en: async () => ({}),
  el: async () => (await import('./el.json')).default,
};

export let STRINGS: Strings = en;
export let currentLocale: LocaleId = 'en';

const listeners = new Set<() => void>();

/** Register a callback for UI that bakes strings into DOM at construction. */
export function onLocaleChange(fn: () => void): void {
  listeners.add(fn);
}

export async function setLocale(id: LocaleId): Promise<void> {
  let next: Strings = en;
  try {
    const translation = await LOADERS[id]();
    // Explicit type argument: DeepPartial is homomorphic, so TS would other-
    // wise reverse-infer T from the translation and hand back a partial.
    if (id !== 'en') next = deepMerge<Strings>(en, translation);
  } catch (err) {
    console.error(`Locale "${id}" failed to load — staying on English.`, err);
    id = 'en';
  }
  STRINGS = next;
  currentLocale = id;
  document.documentElement.lang = LOCALES[id].tag;
  for (const fn of listeners) fn();
}

/** Resolve a stored preference ('auto' consults the browser) to a real locale. */
export function resolveLocale(pref: LocalePreference): LocaleId {
  if (pref !== 'auto') return pref;
  for (const lang of navigator.languages ?? [navigator.language]) {
    const base = lang.toLowerCase().split('-')[0];
    if (base in LOCALES) return base as LocaleId;
  }
  return 'en';
}

/** BCP-47 tag of the active locale — for Intl / toLocaleString. */
export function localeTag(): string {
  return LOCALES[currentLocale].tag;
}

/** Fill `{name}` placeholders. Keeps word order translatable for numbers. */
export function format(template: string, params: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (match, key: string) =>
    key in params ? String(params[key]) : match,
  );
}

/**
 * Recursively overlay a translation on the English base. Arrays are replaced
 * wholesale rather than merged element-wise — half-translated lists would
 * interleave two languages in one paragraph.
 */
function deepMerge<T>(base: T, override: DeepPartial<T>): T {
  if (override == null || typeof override !== 'object') return base;
  const out = { ...(base as Record<string, unknown>) };
  for (const [key, value] of Object.entries(override as Record<string, unknown>)) {
    if (value == null) continue;
    const baseValue = out[key];
    const mergeable =
      baseValue != null &&
      typeof baseValue === 'object' &&
      !Array.isArray(baseValue) &&
      typeof value === 'object' &&
      !Array.isArray(value);
    out[key] = mergeable ? deepMerge(baseValue, value as never) : value;
  }
  return out as T;
}

// --- Compile-time completeness guards -------------------------------------
// en.json is the source of truth, so it must name every id the game can
// render. Adding an item/animal/build piece/quest without a display name is a
// build error here rather than a blank label at runtime. (Translations are
// intentionally exempt — they fall back to English.)
type Assert<T extends true> = T;
export type _ItemsCovered = Assert<Strings['items'] extends Record<ItemId, string> ? true : false>;
export type _AnimalsCovered = Assert<
  Strings['animals'] extends Record<AnimalKind, string> ? true : false
>;
export type _PiecesCovered = Assert<
  Strings['build']['pieces'] extends Record<BuildType, string> ? true : false
>;
export type _QuestsCovered = Assert<
  Strings['quests']['defs'] extends Record<QuestId, { title: string; desc: string }> ? true : false
>;
