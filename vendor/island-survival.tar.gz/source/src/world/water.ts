/**
 * Sea + lake surfaces. The sea is a large plane at y = 0 with cheap CPU-side
 * sine waves (low vertex count, updated per render frame); the lake is a flat
 * disc at the terrain's carved lake level.
 */
import * as THREE from 'three';
import { SEA_LEVEL } from './terrain';
import type { Terrain } from './terrain';

const SEA_SPAN = 2400;
const SEA_SEGMENTS = 72;

export class Water {
  readonly group = new THREE.Group();
  private seaGeo: THREE.PlaneGeometry;
  private time = 0;

  constructor(terrain: Terrain) {
    this.seaGeo = new THREE.PlaneGeometry(SEA_SPAN, SEA_SPAN, SEA_SEGMENTS, SEA_SEGMENTS);
    this.seaGeo.rotateX(-Math.PI / 2);

    const seaMat = new THREE.MeshStandardMaterial({
      color: 0x2f7ea6,
      transparent: true,
      opacity: 0.82,
      roughness: 0.25,
      metalness: 0.05,
    });
    const sea = new THREE.Mesh(this.seaGeo, seaMat);
    sea.position.y = SEA_LEVEL;
    sea.name = 'sea';
    this.group.add(sea);

    const lakeMat = new THREE.MeshStandardMaterial({
      color: 0x3a86a8,
      transparent: true,
      opacity: 0.8,
      roughness: 0.2,
    });
    const lake = new THREE.Mesh(new THREE.CircleGeometry(terrain.lakeRadius, 40), lakeMat);
    lake.rotation.x = -Math.PI / 2;
    lake.position.set(terrain.lakeCenter.x, terrain.lakeLevel, terrain.lakeCenter.y);
    lake.name = 'lake';
    this.group.add(lake);
  }

  /**
   * Called per render frame — animates gentle sea swell. Normals come from
   * the analytic wave derivatives (computeVertexNormals over the whole grid
   * every frame was the single biggest CPU cost in the render loop).
   */
  updateVisual(dt: number): void {
    this.time += dt;
    const pos = this.seaGeo.attributes.position as THREE.BufferAttribute;
    const nor = this.seaGeo.attributes.normal as THREE.BufferAttribute;
    const t = this.time;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const phaseX = x * 0.02 + t * 0.9;
      const phaseZ = z * 0.025 + t * 0.7;
      pos.setY(i, Math.sin(phaseX) * 0.22 + Math.cos(phaseZ) * 0.18);
      // normal ∝ (-∂y/∂x, 1, -∂y/∂z); slopes are tiny so it is already ~unit.
      nor.setXYZ(i, -0.0044 * Math.cos(phaseX), 1, 0.0045 * Math.sin(phaseZ));
    }
    pos.needsUpdate = true;
    nor.needsUpdate = true;
  }
}
