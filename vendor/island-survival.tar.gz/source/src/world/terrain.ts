/**
 * Procedural island terrain: simplex-fbm heightmap with radial falloff so the
 * island sinks below sea level (y = 0) at the edges, plus one carved lake.
 * The analytic heightAt() is the single source of truth — the render mesh,
 * the Rapier trimesh collider, and vegetation placement all sample it, so
 * they can never disagree.
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import { SimplexNoise2D } from './noise';
import { mulberry32 } from './rng';

export const ISLAND_SIZE = 600;
export const SEA_LEVEL = 0;
const SEGMENTS = 200;
const ISLAND_RADIUS = ISLAND_SIZE / 2;

const COLOR_SAND = new THREE.Color(0xd9c58f);
const COLOR_GRASS = new THREE.Color(0x5f9c4a);
const COLOR_DRY_GRASS = new THREE.Color(0x8faa50);
const COLOR_ROCK = new THREE.Color(0x8d8579);

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

export class Terrain {
  readonly mesh: THREE.Mesh;
  readonly lakeCenter: THREE.Vector2;
  readonly lakeRadius = 26;
  /** Water surface height of the lake. */
  readonly lakeLevel = 0.9;

  private noise: SimplexNoise2D;
  private detailNoise: SimplexNoise2D;

  constructor(seed: number) {
    this.noise = new SimplexNoise2D(seed);
    this.detailNoise = new SimplexNoise2D(seed ^ 0x51ab3e);

    // Lake position is seed-derived: somewhere mid-island, away from the center peak.
    const rand = mulberry32(seed ^ 0xa11ce);
    const lakeAngle = rand() * Math.PI * 2;
    const lakeDist = ISLAND_RADIUS * (0.3 + rand() * 0.15);
    this.lakeCenter = new THREE.Vector2(Math.cos(lakeAngle) * lakeDist, Math.sin(lakeAngle) * lakeDist);

    this.mesh = this.buildMesh();
  }

  /** Analytic terrain height at world (x, z). */
  heightAt(x: number, z: number): number {
    const r = Math.hypot(x, z) / ISLAND_RADIUS;

    const base = this.noise.fbm(x * 0.004, z * 0.004, 4);
    const detail = this.detailNoise.fbm(x * 0.02, z * 0.02, 3);
    let h = base * 16 + detail * 2.2 + 9;

    // Central highland where the ΙΡΙΣ station will eventually sit.
    const peak = Math.exp(-(x * x + z * z) / (110 * 110));
    h += peak * 20;

    // Radial falloff: sink below sea level toward the rim.
    const mask = 1 - smoothstep(0.55, 0.98, r);
    h = h * mask - 14 * smoothstep(0.78, 1.05, r);

    // Carve the lake basin.
    const lakeDist = Math.hypot(x - this.lakeCenter.x, z - this.lakeCenter.y);
    const lakeInfluence = 1 - smoothstep(0.35, 1, lakeDist / this.lakeRadius);
    h = h * (1 - lakeInfluence) + (this.lakeLevel - 3.2) * lakeInfluence;

    return h;
  }

  /** Approximate slope (0 = flat, 1 = 45°) via finite differences. */
  slopeAt(x: number, z: number): number {
    const e = 1.5;
    const dx = (this.heightAt(x + e, z) - this.heightAt(x - e, z)) / (2 * e);
    const dz = (this.heightAt(x, z + e) - this.heightAt(x, z - e)) / (2 * e);
    return Math.hypot(dx, dz);
  }

  private buildMesh(): THREE.Mesh {
    const geo = new THREE.PlaneGeometry(ISLAND_SIZE, ISLAND_SIZE, SEGMENTS, SEGMENTS);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const tint = new THREE.Color();

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = this.heightAt(x, z);
      pos.setY(i, h);

      const slope = this.slopeAt(x, z);
      // Sand near the waterline, grass inland, rock on slopes and peaks.
      tint.copy(COLOR_SAND);
      const grassMix = smoothstep(1.6, 3.2, h);
      const dryMix = smoothstep(0.3, 0.75, this.detailNoise.noise(x * 0.01, z * 0.01));
      const grass = COLOR_GRASS.clone().lerp(COLOR_DRY_GRASS, dryMix);
      tint.lerp(grass, grassMix);
      const rockMix = Math.max(smoothstep(0.55, 0.9, slope), smoothstep(24, 34, h));
      tint.lerp(COLOR_ROCK, rockMix);

      colors[i * 3] = tint.r;
      colors[i * 3 + 1] = tint.g;
      colors[i * 3 + 2] = tint.b;
    }

    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    mesh.name = 'terrain';
    return mesh;
  }

  /** Static trimesh collider matching the render geometry exactly. */
  createCollider(rapier: typeof RAPIER, world: RAPIER.World): void {
    const geo = this.mesh.geometry;
    const vertices = new Float32Array((geo.attributes.position as THREE.BufferAttribute).array);
    const indices = new Uint32Array(geo.index!.array);
    world.createCollider(rapier.ColliderDesc.trimesh(vertices, indices));
  }

  /** A walkable spawn point on the beach, deterministic for the seed. */
  findBeachSpawn(): THREE.Vector3 {
    for (let angle = 0; angle < Math.PI * 2; angle += 0.05) {
      for (let d = ISLAND_RADIUS * 0.95; d > ISLAND_RADIUS * 0.4; d -= 4) {
        const x = Math.cos(angle) * d;
        const z = Math.sin(angle) * d;
        const h = this.heightAt(x, z);
        if (h > 0.8 && h < 1.8 && this.slopeAt(x, z) < 0.3) {
          return new THREE.Vector3(x, h + 1.2, z);
        }
      }
    }
    return new THREE.Vector3(0, this.heightAt(0, 0) + 1.2, 0);
  }
}
