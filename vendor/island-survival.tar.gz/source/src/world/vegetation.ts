/**
 * Seed-based procedural scattering of trees, rocks and bushes.
 * - InstancedMesh per object type (performance: a handful of draw calls total).
 * - Every instance has a stable string ID (`tree_0412`) so saves can record
 *   "this tree was chopped" as a world diff (CLAUDE.md conventions).
 * - Placeholder low-poly geometry for now; swapped for Quaternius GLBs later
 *   without touching the placement logic.
 */
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type RAPIER from '@dimforge/rapier3d-compat';
import { mulberry32 } from './rng';
import type { Terrain } from './terrain';

export type WorldObjectKind = 'tree' | 'rock' | 'bush';

export interface WorldObject {
  id: string;
  kind: WorldObjectKind;
  position: THREE.Vector3;
  rotationY: number;
  scale: number;
  /** Which InstancedMesh + slot renders this object. */
  meshIndex: number;
  instanceIndex: number;
  colliderHandle: number | null;
  removed: boolean;
}

const TREE_COUNT = 1100;
const ROCK_COUNT = 320;
const BUSH_COUNT = 380;
const ISLAND_SCATTER_RADIUS = 270;

function colorize(geoIn: THREE.BufferGeometry, color: THREE.Color): THREE.BufferGeometry {
  // mergeGeometries refuses to mix indexed (cylinder/cone) with non-indexed
  // (icosahedron) geometry — normalize everything to non-indexed.
  const geo = geoIn.index ? geoIn.toNonIndexed() : geoIn;
  const count = geo.attributes.position.count;
  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return geo;
}

/** Pine-like tree: trunk + two stacked cones, merged into one geometry. */
function buildPineGeometry(): THREE.BufferGeometry {
  const trunk = colorize(new THREE.CylinderGeometry(0.22, 0.38, 3.2, 6).translate(0, 1.6, 0), new THREE.Color(0x6b4a2b));
  const lower = colorize(new THREE.ConeGeometry(2.0, 3.4, 7).translate(0, 4.2, 0), new THREE.Color(0x2e6b34));
  const upper = colorize(new THREE.ConeGeometry(1.3, 2.6, 7).translate(0, 6.3, 0), new THREE.Color(0x35793c));
  return mergeGeometries([trunk, lower, upper]);
}

/** Olive-like tree: short gnarled trunk + blobby crown. */
function buildOliveGeometry(): THREE.BufferGeometry {
  const trunk = colorize(new THREE.CylinderGeometry(0.28, 0.42, 2.2, 6).translate(0, 1.1, 0), new THREE.Color(0x7a5c39));
  const crown = colorize(new THREE.IcosahedronGeometry(1.9, 1).scale(1, 0.72, 1).translate(0, 3.1, 0), new THREE.Color(0x6f8f4f));
  const crown2 = colorize(new THREE.IcosahedronGeometry(1.1, 1).translate(0.9, 3.7, 0.4), new THREE.Color(0x7d9b58));
  return mergeGeometries([trunk, crown, crown2]);
}

function buildRockGeometry(): THREE.BufferGeometry {
  return colorize(new THREE.IcosahedronGeometry(1, 0).scale(1, 0.7, 1.15), new THREE.Color(0x8b8578));
}

function buildBushGeometry(): THREE.BufferGeometry {
  return colorize(new THREE.IcosahedronGeometry(0.75, 1).scale(1, 0.75, 1), new THREE.Color(0x4c7a3d));
}

export class Vegetation {
  readonly group = new THREE.Group();
  readonly objects = new Map<string, WorldObject>();

  private meshes: THREE.InstancedMesh[] = [];
  private zeroMatrix = new THREE.Matrix4().makeScale(0, 0, 0);
  private handleToId = new Map<number, string>();

  constructor(
    seed: number,
    terrain: Terrain,
    private rapier: typeof RAPIER,
    private physicsWorld: RAPIER.World,
  ) {
    const rand = mulberry32(seed ^ 0x7ee5);
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, flatShading: true });

    const pineGeo = buildPineGeometry();
    const oliveGeo = buildOliveGeometry();
    const rockGeo = buildRockGeometry();
    const bushGeo = buildBushGeometry();

    // Deterministic placement: sample candidate spots, keep the valid ones.
    const trees: Array<{ pos: THREE.Vector3; olive: boolean }> = [];
    const rocks: THREE.Vector3[] = [];
    const bushes: THREE.Vector3[] = [];

    const isNearLake = (x: number, z: number) =>
      Math.hypot(x - terrain.lakeCenter.x, z - terrain.lakeCenter.y) < terrain.lakeRadius + 4;

    let guard = 0;
    while (trees.length < TREE_COUNT && guard++ < TREE_COUNT * 12) {
      const x = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const z = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const h = terrain.heightAt(x, z);
      if (h < 2.4 || h > 26 || terrain.slopeAt(x, z) > 0.5 || isNearLake(x, z)) continue;
      // Olives near the coast, pines higher up.
      trees.push({ pos: new THREE.Vector3(x, h, z), olive: h < 7 ? rand() < 0.7 : rand() < 0.15 });
    }
    guard = 0;
    while (rocks.length < ROCK_COUNT && guard++ < ROCK_COUNT * 12) {
      const x = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const z = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const h = terrain.heightAt(x, z);
      if (h < 1 || terrain.slopeAt(x, z) > 0.8 || isNearLake(x, z)) continue;
      rocks.push(new THREE.Vector3(x, h, z));
    }
    guard = 0;
    while (bushes.length < BUSH_COUNT && guard++ < BUSH_COUNT * 12) {
      const x = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const z = (rand() * 2 - 1) * ISLAND_SCATTER_RADIUS;
      const h = terrain.heightAt(x, z);
      if (h < 1.6 || h > 20 || terrain.slopeAt(x, z) > 0.55 || isNearLake(x, z)) continue;
      bushes.push(new THREE.Vector3(x, h, z));
    }

    const pines = trees.filter((t) => !t.olive);
    const olives = trees.filter((t) => t.olive);

    const pineMesh = this.createInstancedMesh(pineGeo, mat, pines.length, true);
    const oliveMesh = this.createInstancedMesh(oliveGeo, mat, olives.length, true);
    const rockMesh = this.createInstancedMesh(rockGeo, mat, rocks.length, true);
    const bushMesh = this.createInstancedMesh(bushGeo, mat, bushes.length, false);

    // IDs are assigned in deterministic placement order.
    let treeId = 0;
    for (const [meshIndex, list] of [pines, olives].entries()) {
      const mesh = meshIndex === 0 ? pineMesh : oliveMesh;
      list.forEach((t, i) => {
        const scale = 0.8 + rand() * 0.6;
        const rotY = rand() * Math.PI * 2;
        const id = `tree_${String(treeId++).padStart(4, '0')}`;
        this.setInstance(mesh, i, t.pos, rotY, scale);
        this.register({
          id, kind: 'tree', position: t.pos, rotationY: rotY, scale,
          meshIndex: this.meshes.indexOf(mesh), instanceIndex: i,
          colliderHandle: this.createTrunkCollider(t.pos, scale), removed: false,
        });
      });
    }
    rocks.forEach((pos, i) => {
      const scale = 0.5 + rand() * 1.3;
      const rotY = rand() * Math.PI * 2;
      const id = `rock_${String(i).padStart(4, '0')}`;
      this.setInstance(rockMesh, i, pos, rotY, scale);
      // Big rocks block movement; small ones get a sensor so they are still
      // raycast-harvestable without tripping the character controller.
      this.register({
        id, kind: 'rock', position: pos, rotationY: rotY, scale,
        meshIndex: this.meshes.indexOf(rockMesh), instanceIndex: i,
        colliderHandle: this.createRockCollider(pos, scale, scale <= 0.8), removed: false,
      });
    });
    bushes.forEach((pos, i) => {
      const scale = 0.7 + rand() * 0.8;
      const rotY = rand() * Math.PI * 2;
      const id = `bush_${String(i).padStart(4, '0')}`;
      this.setInstance(bushMesh, i, pos, rotY, scale);
      this.register({
        id, kind: 'bush', position: pos, rotationY: rotY, scale,
        meshIndex: this.meshes.indexOf(bushMesh), instanceIndex: i,
        colliderHandle: this.createBushSensor(pos, scale), removed: false,
      });
    });

    for (const mesh of this.meshes) {
      mesh.instanceMatrix.needsUpdate = true;
      mesh.computeBoundingSphere();
    }
  }

  /** Apply a saved world diff: hide every object recorded as removed. */
  applyRemovedIds(removedIds: string[]): void {
    for (const id of removedIds) this.removeObject(id);
  }

  removeObject(id: string): void {
    const obj = this.objects.get(id);
    if (!obj || obj.removed) return;
    obj.removed = true;
    const mesh = this.meshes[obj.meshIndex];
    mesh.setMatrixAt(obj.instanceIndex, this.zeroMatrix);
    mesh.instanceMatrix.needsUpdate = true;
    if (obj.colliderHandle !== null) {
      const collider = this.physicsWorld.getCollider(obj.colliderHandle);
      if (collider) this.physicsWorld.removeCollider(collider, false);
      this.handleToId.delete(obj.colliderHandle);
      obj.colliderHandle = null;
    }
  }

  /**
   * Restore objects whose IDs left the removed list (bush regrowth):
   * re-show the instance and recreate its collider.
   */
  syncRegrown(removedIds: string[]): void {
    const removedSet = new Set(removedIds);
    for (const obj of this.objects.values()) {
      if (!obj.removed || removedSet.has(obj.id)) continue;
      obj.removed = false;
      const mesh = this.meshes[obj.meshIndex];
      this.setInstance(mesh, obj.instanceIndex, obj.position, obj.rotationY, obj.scale);
      mesh.instanceMatrix.needsUpdate = true;
      if (obj.kind === 'tree') obj.colliderHandle = this.createTrunkCollider(obj.position, obj.scale);
      else if (obj.kind === 'rock') obj.colliderHandle = this.createRockCollider(obj.position, obj.scale, obj.scale <= 0.8);
      else obj.colliderHandle = this.createBushSensor(obj.position, obj.scale);
      this.handleToId.set(obj.colliderHandle, obj.id);
    }
  }

  /** Look up the world object a Rapier raycast hit. */
  objectByColliderHandle(handle: number): WorldObject | undefined {
    const id = this.handleToId.get(handle);
    return id ? this.objects.get(id) : undefined;
  }

  private register(obj: WorldObject): void {
    this.objects.set(obj.id, obj);
    if (obj.colliderHandle !== null) this.handleToId.set(obj.colliderHandle, obj.id);
  }

  private createInstancedMesh(
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    count: number,
    castShadow: boolean,
  ): THREE.InstancedMesh {
    const mesh = new THREE.InstancedMesh(geo, mat, Math.max(count, 1));
    mesh.castShadow = castShadow;
    mesh.receiveShadow = true;
    this.meshes.push(mesh);
    this.group.add(mesh);
    return mesh;
  }

  private setInstance(mesh: THREE.InstancedMesh, index: number, pos: THREE.Vector3, rotY: number, scale: number): void {
    const m = new THREE.Matrix4()
      .makeRotationY(rotY)
      .scale(new THREE.Vector3(scale, scale, scale))
      .setPosition(pos.x, pos.y, pos.z);
    mesh.setMatrixAt(index, m);
  }

  private createTrunkCollider(pos: THREE.Vector3, scale: number): number {
    const desc = this.rapier.ColliderDesc.cylinder(2.2 * scale, 0.35 * scale)
      .setTranslation(pos.x, pos.y + 2.2 * scale, pos.z);
    return this.physicsWorld.createCollider(desc).handle;
  }

  private createRockCollider(pos: THREE.Vector3, scale: number, sensor: boolean): number {
    const desc = this.rapier.ColliderDesc.ball(0.85 * scale)
      .setTranslation(pos.x, pos.y + 0.3 * scale, pos.z)
      .setSensor(sensor);
    return this.physicsWorld.createCollider(desc).handle;
  }

  private createBushSensor(pos: THREE.Vector3, scale: number): number {
    const desc = this.rapier.ColliderDesc.ball(0.8 * scale)
      .setTranslation(pos.x, pos.y + 0.5 * scale, pos.z)
      .setSensor(true);
    return this.physicsWorld.createCollider(desc).handle;
  }
}
