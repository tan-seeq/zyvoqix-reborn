/**
 * Cave mouths (στόμια σπηλιών): seeded landmark props on the island's higher
 * ground. For now they are entrances-as-set-dressing — a rock crescent around
 * a dark opening you cannot enter (a collider blocks it). Phase 6 turns them
 * into real cave locations; Phase 5β uses them as Hollow One spawn anchors
 * (LORE: «βγαίνουν μόνο νύχτα, από στόμια σπηλιών»).
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import { mulberry32 } from './rng';
import type { Terrain } from './terrain';

const CAVE_COUNT = 3;

export class CaveMouths {
  readonly group = new THREE.Group();
  readonly positions: THREE.Vector3[] = [];

  constructor(
    terrain: Terrain,
    rapier: typeof RAPIER,
    physicsWorld: RAPIER.World,
    seed: number,
  ) {
    const rand = mulberry32(seed ^ 0xca7e5);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x6f6a60, roughness: 1, flatShading: true });
    const darkMat = new THREE.MeshBasicMaterial({ color: 0x050608 });

    let attempts = 0;
    while (this.positions.length < CAVE_COUNT && attempts++ < 200) {
      const angle = rand() * Math.PI * 2;
      const dist = 90 + rand() * 110;
      const x = Math.sin(angle) * dist;
      const z = Math.cos(angle) * dist;
      const h = terrain.heightAt(x, z);
      const slope = terrain.slopeAt(x, z);
      if (h < 6 || h > 24 || slope < 0.15 || slope > 0.6) continue;
      // Keep the mouths spread apart.
      if (this.positions.some((p) => Math.hypot(p.x - x, p.z - z) < 80)) continue;

      const pos = new THREE.Vector3(x, h, z);
      this.positions.push(pos);

      // Face downhill so the opening looks out of the hillside.
      const e = 1.5;
      const dhx = terrain.heightAt(x + e, z) - terrain.heightAt(x - e, z);
      const dhz = terrain.heightAt(x, z + e) - terrain.heightAt(x, z - e);
      const facing = Math.atan2(-dhx, -dhz);

      const mouth = new THREE.Group();
      mouth.position.copy(pos);
      mouth.rotation.y = facing;

      // Dark opening.
      const opening = new THREE.Mesh(new THREE.CircleGeometry(1.35, 12), darkMat);
      opening.position.set(0, 1.2, 0);
      mouth.add(opening);

      // Rock crescent around it.
      for (let i = 0; i < 6; i++) {
        const a = (i / 5 - 0.5) * Math.PI * 1.1;
        const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9 + rand() * 0.7, 0), rockMat);
        rock.position.set(Math.sin(a) * 1.9, 0.4 + Math.abs(Math.cos(a)) * 1.3, -0.35 - Math.cos(a) * 0.25);
        rock.rotation.set(rand() * 3, rand() * 3, rand() * 3);
        rock.castShadow = true;
        rock.receiveShadow = true;
        mouth.add(rock);
      }

      this.group.add(mouth);

      // Block the opening (world-space rotated cuboid just behind the disc).
      physicsWorld.createCollider(
        rapier.ColliderDesc.cuboid(1.6, 1.8, 0.4)
          .setTranslation(x - Math.sin(facing) * 0.5, h + 1.4, z - Math.cos(facing) * 0.5)
          .setRotation({ x: 0, y: Math.sin(facing / 2), z: 0, w: Math.cos(facing / 2) }),
      );
    }
  }

  /** Spawn anchor: mouth nearest to (x, z) but at least minDist away, else null. */
  nearestBeyond(x: number, z: number, minDist: number, maxDist: number): THREE.Vector3 | null {
    let best: THREE.Vector3 | null = null;
    let bestD = maxDist;
    for (const p of this.positions) {
      const d = Math.hypot(p.x - x, p.z - z);
      if (d >= minDist && d <= bestD) {
        best = p;
        bestD = d;
      }
    }
    return best;
  }
}
