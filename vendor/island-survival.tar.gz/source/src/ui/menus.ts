/**
 * Game shell overlays: title screen (with cinematic island orbit behind it),
 * intro text on a fresh game, settings panel (persisted device settings),
 * and the death screen. The pause menu stays in hud.ts — these are the
 * screens that frame it into an actual game.
 *
 * Like the HUD, every overlay is built from a template so a language change
 * can rebuild it in place; `applyLocale` restores which screens were open.
 */
import { saveSettings, type Settings } from '../core/settings';
import {
  LOCALES, STRINGS, onLocaleChange, resolveLocale, setLocale, type LocaleId, type LocalePreference,
} from '../i18n';

export class Menus {
  onPlay: (() => void) | null = null;
  onNewGame: (() => void) | null = null;

  private titleEl!: HTMLElement;
  private introEl!: HTMLElement;
  private deathEl!: HTMLElement;
  private settingsEl!: HTMLElement;
  private introDone: (() => void) | null = null;
  private deathRespawn: (() => void) | null = null;
  /** Retained so a locale rebuild can restore these screens verbatim. */
  private hasSave = false;
  private deathDay = 0;

  constructor(
    private settings: Settings,
    private applySettings: (s: Settings) => void,
  ) {
    this.build();
    onLocaleChange(() => this.applyLocale());
  }

  private applyLocale(): void {
    const open = {
      title: !this.titleEl.classList.contains('hidden'),
      intro: !this.introEl.classList.contains('hidden'),
      death: !this.deathEl.classList.contains('hidden'),
      settings: !this.settingsEl.classList.contains('hidden'),
    };
    for (const el of [this.titleEl, this.introEl, this.deathEl, this.settingsEl]) el.remove();
    this.build();
    if (open.title) this.showTitle(this.hasSave);
    if (open.intro) this.introEl.classList.remove('hidden');
    if (open.death) {
      this.deathEl.querySelector('#death-day')!.textContent =
        `${STRINGS.menu.deathSurvived} ${this.deathDay}`;
      this.deathEl.classList.remove('hidden');
    }
    if (open.settings) this.settingsEl.classList.remove('hidden');
  }

  private build(): void {
    const settings = this.settings;
    this.titleEl = this.mount(`
      <div id="title-screen" class="menu-overlay hidden">
        <h1 class="game-title">ISLAND SURVIVAL</h1>
        <p class="game-subtitle">${STRINGS.menu.subtitle}</p>
        <div class="menu-buttons">
          <button id="title-continue">${STRINGS.menu.continue}</button>
          <button id="title-new">${STRINGS.menu.newGame}</button>
          <button id="title-settings">${STRINGS.menu.settings}</button>
        </div>
      </div>`);
    this.introEl = this.mount(`
      <div id="intro-screen" class="menu-overlay hidden">
        <div class="intro-text">
          ${STRINGS.menu.introLines.map((l, i) => `<p style="animation-delay:${i * 1.1}s">${l}</p>`).join('')}
        </div>
        <p class="menu-hint intro-hint">${STRINGS.menu.introContinue}</p>
      </div>`);
    this.deathEl = this.mount(`
      <div id="death-screen" class="menu-overlay hidden">
        <h1 class="death-title">${STRINGS.menu.death}</h1>
        <p id="death-day" class="game-subtitle"></p>
        <div class="menu-buttons"><button id="death-respawn">${STRINGS.menu.respawn}</button></div>
      </div>`);
    this.settingsEl = this.mount(`
      <div id="settings-panel" class="menu-overlay hidden">
        <h2>${STRINGS.menu.settings}</h2>
        <div class="settings-rows">
          <label>${STRINGS.menu.language}
            <select id="set-lang">
              <option value="auto" ${settings.language === 'auto' ? 'selected' : ''}>${STRINGS.menu.languageAuto}</option>
              ${Object.entries(LOCALES)
                .map(
                  ([id, meta]) =>
                    `<option value="${id}" ${settings.language === id ? 'selected' : ''}>${meta.name}</option>`,
                )
                .join('')}
            </select>
          </label>
          <label>${STRINGS.menu.sensitivity}
            <input id="set-sens" type="range" min="0.5" max="2" step="0.05" value="${settings.sensitivity}">
            <span id="set-sens-v"></span>
          </label>
          <label>${STRINGS.menu.fov}
            <input id="set-fov" type="range" min="60" max="90" step="1" value="${settings.fov}">
            <span id="set-fov-v"></span>
          </label>
          <label>${STRINGS.menu.shadows}
            <input id="set-shadows" type="checkbox" ${settings.shadows ? 'checked' : ''}>
          </label>
          <label>${STRINGS.menu.resolution}
            <select id="set-res">
              <option value="0.75" ${settings.pixelRatio === 0.75 ? 'selected' : ''}>${STRINGS.menu.resolutionLow}</option>
              <option value="1" ${settings.pixelRatio === 1 ? 'selected' : ''}>${STRINGS.menu.resolutionNormal}</option>
            </select>
          </label>
          <label>${STRINGS.menu.volume}
            <input id="set-vol" type="range" min="0" max="1" step="0.05" value="${settings.volume}">
            <span id="set-vol-v"></span>
          </label>
        </div>
        <div class="menu-buttons"><button id="settings-close">${STRINGS.menu.close}</button></div>
      </div>`);

    this.titleEl.querySelector('#title-continue')!.addEventListener('click', () => this.onPlay?.());
    this.titleEl.querySelector('#title-new')!.addEventListener('click', () => this.onNewGame?.());
    this.titleEl.querySelector('#title-settings')!.addEventListener('click', () => this.toggleSettings());
    this.introEl.addEventListener('click', () => {
      this.introEl.classList.add('hidden');
      this.introDone?.();
    });
    this.deathEl.querySelector('#death-respawn')!.addEventListener('click', () => {
      this.deathEl.classList.add('hidden');
      this.deathRespawn?.();
    });
    this.settingsEl.querySelector('#settings-close')!.addEventListener('click', () => this.toggleSettings());
    this.bindSettingInputs();
  }

  get anyOpen(): boolean {
    return [this.titleEl, this.introEl, this.deathEl, this.settingsEl].some(
      (el) => !el.classList.contains('hidden'),
    );
  }

  /** Title/intro run the slow island-orbit camera. */
  get cinematic(): boolean {
    return (
      !this.titleEl.classList.contains('hidden') || !this.introEl.classList.contains('hidden')
    );
  }

  showTitle(hasSave: boolean): void {
    this.hasSave = hasSave;
    (this.titleEl.querySelector('#title-continue') as HTMLElement).style.display = hasSave
      ? ''
      : 'none';
    this.titleEl.classList.remove('hidden');
  }

  hideTitle(): void {
    this.titleEl.classList.add('hidden');
  }

  showIntro(onDone: () => void): void {
    this.introDone = onDone;
    this.introEl.classList.remove('hidden');
  }

  showDeath(day: number, onRespawn: () => void): void {
    this.deathDay = day;
    this.deathRespawn = onRespawn;
    this.deathEl.querySelector('#death-day')!.textContent = `${STRINGS.menu.deathSurvived} ${day}`;
    this.deathEl.classList.remove('hidden');
  }

  toggleSettings(): void {
    this.settingsEl.classList.toggle('hidden');
  }

  private bindSettingInputs(): void {
    const lang = this.settingsEl.querySelector('#set-lang') as HTMLSelectElement;
    const sens = this.settingsEl.querySelector('#set-sens') as HTMLInputElement;
    const sensV = this.settingsEl.querySelector('#set-sens-v') as HTMLElement;
    const fov = this.settingsEl.querySelector('#set-fov') as HTMLInputElement;
    const fovV = this.settingsEl.querySelector('#set-fov-v') as HTMLElement;
    const shadows = this.settingsEl.querySelector('#set-shadows') as HTMLInputElement;
    const res = this.settingsEl.querySelector('#set-res') as HTMLSelectElement;
    const vol = this.settingsEl.querySelector('#set-vol') as HTMLInputElement;
    const volV = this.settingsEl.querySelector('#set-vol-v') as HTMLElement;

    const refresh = () => {
      sensV.textContent = `${Math.round(this.settings.sensitivity * 100)}%`;
      fovV.textContent = `${this.settings.fov}°`;
      volV.textContent = `${Math.round(this.settings.volume * 100)}%`;
    };
    const commit = () => {
      saveSettings(this.settings);
      this.applySettings(this.settings);
      refresh();
    };
    // Language is the one setting that rebuilds these panels; setLocale always
    // yields first, so this handler is long gone by the time that happens.
    lang.addEventListener('change', () => {
      this.settings.language = lang.value as LocalePreference;
      saveSettings(this.settings);
      void setLocale(resolveLocale(this.settings.language) as LocaleId);
    });
    sens.addEventListener('input', () => {
      this.settings.sensitivity = Number(sens.value);
      commit();
    });
    fov.addEventListener('input', () => {
      this.settings.fov = Number(fov.value);
      commit();
    });
    shadows.addEventListener('change', () => {
      this.settings.shadows = shadows.checked;
      commit();
    });
    vol.addEventListener('input', () => {
      this.settings.volume = Number(vol.value);
      commit();
    });
    res.addEventListener('change', () => {
      this.settings.pixelRatio = Number(res.value);
      commit();
    });
    refresh();
  }

  private mount(html: string): HTMLElement {
    const wrap = document.createElement('div');
    wrap.innerHTML = html;
    const el = wrap.firstElementChild as HTMLElement;
    document.body.appendChild(el);
    return el;
  }
}
