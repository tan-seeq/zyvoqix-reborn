/**
 * Chest transfer panel (αποθήκη): two columns — chest contents and player
 * inventory. Clicking a stack moves the whole stack to the other side
 * (STORE_ITEM / TAKE_ITEM actions). Opens with a free cursor like the
 * Σακίδιο; E/Esc closes and main re-locks the pointer.
 */
import type { ActionBus } from '../core/actions';
import { CONTAINER_SLOTS, INVENTORY_SLOTS, type InventorySlot } from '../core/GameState';
import { STRINGS } from '../i18n';

export class ChestPanel {
  isOpen = false;
  onClose: (() => void) | null = null;

  private chestId: string | null = null;

  /** For main to auto-close the panel if a raid destroys this chest. */
  get currentChestId(): string | null {
    return this.chestId;
  }
  private el: HTMLElement;

  constructor(private bus: ActionBus) {
    this.el = document.createElement('div');
    this.el.id = 'chest-panel';
    this.el.classList.add('hidden');
    document.body.appendChild(this.el);
    this.el.addEventListener('click', (e) => {
      const row = (e.target as HTMLElement).closest<HTMLElement>('.chest-row');
      if (!row || !this.chestId) return;
      const { side, item, count } = row.dataset;
      if (!side || !item || !count) return;
      const transfer = {
        containerId: this.chestId,
        itemId: item as InventorySlot['itemId'],
        count: Number(count),
      };
      this.bus.dispatch(
        side === 'chest' ? { type: 'TAKE_ITEM', ...transfer } : { type: 'STORE_ITEM', ...transfer },
      );
      this.render();
    });
  }

  open(chestId: string): void {
    this.chestId = chestId;
    this.isOpen = true;
    this.render();
    this.el.classList.remove('hidden');
    document.exitPointerLock();
  }

  close(): void {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.chestId = null;
    this.el.classList.add('hidden');
    this.onClose?.();
  }

  private render(): void {
    if (!this.chestId) return;
    const chest = this.bus.state.world.containers[this.chestId] ?? [];
    const inv = this.bus.state.inventory;
    this.el.innerHTML = `
      <div class="chest-cols">
        ${this.column('chest', STRINGS.chest.title, chest, CONTAINER_SLOTS)}
        ${this.column('inv', STRINGS.chest.inventory, inv, INVENTORY_SLOTS)}
      </div>
      <div class="menu-hint">${STRINGS.chest.hint}</div>`;
  }

  private column(side: string, title: string, slots: InventorySlot[], max: number): string {
    const rows = slots.length
      ? slots
          .map(
            (s) => `
            <div class="chest-row" data-side="${side}" data-item="${s.itemId}" data-count="${s.count}">
              <span>${STRINGS.items[s.itemId]}</span><span>×${s.count}</span>
            </div>`,
          )
          .join('')
      : `<div class="chest-empty">${STRINGS.chest.empty}</div>`;
    return `
      <div class="chest-col">
        <h3>${title} <small>${slots.length}/${max}</small></h3>
        ${rows}
      </div>`;
  }
}
