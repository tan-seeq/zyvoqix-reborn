/**
 * «Το Σακίδιο» — the game's signature inventory/crafting UI (PLAN Phase 2).
 *
 * Tab spreads the backpack as a cloth on the ground in front of the player.
 * The cloth lives in its OWN overlay scene, rendered after the world with the
 * depth buffer cleared (main.ts) — same trick as first-person viewmodels — so
 * a boulder or trunk standing where the cloth lands can never draw through
 * it. The camera, pitch tween and cursor raycasts are shared with the world,
 * so it still *reads* as laid out on the ground. Pointer lock is released so
 * a real cursor can pick the 3D item piles:
 *   - click a pile        → one unit glides into the crafting circle
 *   - click a center item → it glides back to its pile
 *   - exact recipe match  → a gear appears; clicking it crafts
 *   - partial match       → ghost silhouettes hint the missing ingredients
 *
 * The cloth is a VIEW of GameState.inventory: placing items in the center
 * changes nothing in the state — only CRAFT mutates it (action bus).
 */
import * as THREE from 'three';
import type { ActionBus } from '../core/actions';
import type { Input } from '../core/input';
import type { Terrain } from '../world/terrain';
import type { PlayerController } from '../player/controller';
import type { ItemId } from '../survival/items';
import { matchRecipe, findHint, type Recipe } from '../survival/crafting';
import { buildItemUnit, pilePlacement } from './itemMeshes';
import { STRINGS } from '../i18n';
import { disposeObject3D } from '../core/three-utils';

interface Tween {
  t: number;
  dur: number;
  apply: (k: number) => void;
  onDone?: () => void;
}

interface Pick {
  type: 'stack' | 'center' | 'gear';
  itemId?: ItemId;
}

const CLOTH_W = 2.6;
const CLOTH_H = 1.9;
const CLOTH_DISTANCE = 2.1;
const MAX_VISIBLE_UNITS = 6;
const MAX_CENTER_ITEMS = 6;
const CENTER_RADIUS = 0.16;
/** Narrower FOV while the cloth is open — leaning in over the backpack. */
const OPEN_FOV = 58;

/**
 * Every item type owns a PERMANENT spot on the cloth (muscle memory — the
 * axe is always right, the logs always top-left), spaced ≥0.5m so piles
 * never overlap. Grouped: materials top, storage left, tools/weapons right
 * and inner, food & water bottom. The center stays free for crafting.
 */
const ITEM_ANCHORS: Partial<Record<ItemId, [number, number]>> = {
  // materials — top row
  log: [-1.0, -0.72],
  stick: [-0.5, -0.72],
  stone: [0, -0.72],
  fiber: [0.5, -0.72],
  rope: [1.0, -0.72],
  // storage/misc — left column
  hide: [-1.05, -0.25],
  campfire_kit: [-1.05, 0.25],
  // tools & weapons — inner ring + right column
  axe_stone: [-0.55, -0.3],
  club_wood: [0.55, -0.3],
  bow_wood: [-0.55, 0.3],
  arrow: [0.55, 0.3],
  container_empty: [1.05, -0.25],
  container_water: [1.05, 0.25],
  // food & drink — bottom row
  container_boiled: [-1.0, 0.72],
  berries: [-0.5, 0.72],
  meat_raw: [0, 0.72],
  meat_cooked: [0.5, 0.72],
};

/** Spare spots for future item types not yet in ITEM_ANCHORS. */
const SPARE_ANCHORS: Array<[number, number]> = [
  [1.0, 0.72], [-1.05, -0.72], [1.05, -0.72], [-1.05, 0.72], [1.05, 0.72],
];

const easeOut = (k: number) => 1 - (1 - k) ** 3;

export class BackpackView {
  isOpen = false;

  /**
   * Rendered as a second pass over the world with depth cleared (see
   * main.ts render loop) — world geometry can never occlude the cloth.
   * Lights here replace the sun/hemi it lost by leaving the main scene,
   * which also makes the backpack equally readable at night.
   */
  readonly overlayScene = new THREE.Scene();

  private root = new THREE.Group();
  private itemsGroup = new THREE.Group();
  private centerGroup = new THREE.Group();
  private ghostGroup = new THREE.Group();
  private gear: THREE.Group;
  private stacks = new Map<ItemId, THREE.Group>();
  private anchorIndex = new Map<ItemId, number>();
  private centerUnits: Array<{ itemId: ItemId; mesh: THREE.Group }> = [];
  private matched: Recipe | null = null;
  private tweens: Tween[] = [];
  private savedPitch = 0;
  private savedFov = 72;
  private cameraRef: THREE.PerspectiveCamera | null = null;
  private raycaster = new THREE.Raycaster();
  private pointerNdc = new THREE.Vector2();
  private tooltip: HTMLElement;
  private hovered: THREE.Group | null = null;
  private ghostMat = new THREE.MeshStandardMaterial({
    color: 0xdddddd,
    transparent: true,
    opacity: 0.22,
    depthWrite: false,
  });
  /** Shared material to spare when disposing ghost silhouettes. */
  private ghostKeep = new Set<THREE.Material>([this.ghostMat]);

  constructor(
    private terrain: Terrain,
    private player: PlayerController,
    private input: Input,
    private bus: ActionBus,
  ) {
    this.root.add(this.buildCloth(), this.itemsGroup, this.centerGroup, this.ghostGroup);

    this.gear = this.buildGear();
    this.gear.visible = false;
    this.root.add(this.gear);

    const light = new THREE.PointLight(0xffdcae, 8, 5);
    light.position.set(0, 1.1, 0.3);
    this.root.add(light);

    // Overlay lighting: steady dusk-lantern mood at any hour of the day.
    this.overlayScene.add(new THREE.HemisphereLight(0xe8f0fa, 0x59492f, 0.9));
    const key = new THREE.DirectionalLight(0xfff2dd, 1.3);
    key.position.set(0.5, 1, 0.6);
    this.overlayScene.add(key);

    this.tooltip = document.createElement('div');
    this.tooltip.id = 'bp-tooltip';
    document.body.appendChild(this.tooltip);
  }

  toggle(camera: THREE.PerspectiveCamera): void {
    if (this.isOpen) this.close(true);
    else this.open(camera);
  }

  open(camera: THREE.PerspectiveCamera): void {
    if (this.isOpen) return;
    this.isOpen = true;

    // Lay the cloth on the ground in front of the player.
    const [px, , pz] = this.bus.state.player.pos;
    const yaw = this.player.yaw;
    const cx = px - Math.sin(yaw) * CLOTH_DISTANCE;
    const cz = pz - Math.cos(yaw) * CLOTH_DISTANCE;
    let ground = this.terrain.heightAt(cx, cz);
    for (const [dx, dz] of [[-1.3, -0.95], [1.3, -0.95], [-1.3, 0.95], [1.3, 0.95]]) {
      ground = Math.max(ground, this.terrain.heightAt(cx + dx, cz + dz));
    }
    this.root.position.set(cx, ground + 0.03, cz);
    this.root.rotation.y = yaw;
    this.overlayScene.add(this.root);
    // The overlay only renders after this frame's raycast — refresh matrices
    // now so first-frame cursor picks don't hit stale transforms.
    this.root.updateMatrixWorld(true);

    this.clearCenter();
    this.rebuildStacks();
    this.refreshCraftState();

    document.exitPointerLock();

    // Ease the view down toward the cloth; restore on close.
    this.savedPitch = this.player.pitch;
    const targetPitch = -Math.atan2(camera.position.y - this.root.position.y, CLOTH_DISTANCE);
    this.tweenPitch(targetPitch);

    // Lean in: narrower FOV makes the cloth fill the screen while open.
    this.cameraRef = camera;
    this.savedFov = camera.fov;
    this.tweenFov(camera, OPEN_FOV);

    this.root.scale.setScalar(0.85);
    this.tweens.push({
      t: 0, dur: 0.25,
      apply: (k) => this.root.scale.setScalar(0.85 + 0.15 * k),
    });
  }

  close(relock: boolean): void {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.overlayScene.remove(this.root);
    // Free every backpack mesh so nothing lingers on the GPU while it's shut;
    // open() rebuilds the piles from state.
    for (const g of this.stacks.values()) disposeObject3D(g, this.ghostKeep);
    this.stacks.clear();
    this.itemsGroup.clear();
    this.disposeAndClear(this.centerGroup);
    this.centerUnits = [];
    this.disposeAndClear(this.ghostGroup);
    this.tooltip.style.display = 'none';
    this.setHovered(null);
    this.tweenPitch(this.savedPitch);
    if (this.cameraRef) this.tweenFov(this.cameraRef, this.savedFov);
    if (relock) this.input.requestPointerLock();
  }

  /** Called every render frame (tweens run even while closed, for the pitch ease-back). */
  update(renderDt: number, camera: THREE.PerspectiveCamera): void {
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      tw.t += renderDt;
      const k = Math.min(1, tw.t / tw.dur);
      tw.apply(easeOut(k));
      if (k >= 1) {
        this.tweens.splice(i, 1);
        tw.onDone?.();
      }
    }
    if (!this.isOpen) return;

    this.gear.rotation.y += renderDt * 0.9;

    const pick = this.raycastCursor(camera);
    this.updateTooltip(pick);

    if (this.input.consumeUnlockedClick() && pick) {
      if (pick.obj.userData.pick.type === 'stack') this.moveToCenter(pick.obj.userData.pick.itemId);
      else if (pick.obj.userData.pick.type === 'center') this.returnFromCenter(pick.obj);
      else if (pick.obj.userData.pick.type === 'gear') this.craft();
    }

    // Right-click a pile: drop 1 (Shift: the whole pile). Discards for now —
    // ground-item pickups arrive with the asset pass.
    if (this.input.consumeUnlockedRightClick() && pick) {
      const data = pick.obj.userData.pick as Pick;
      if (data.type === 'stack' && data.itemId) {
        const all = this.input.isDown('ShiftLeft') || this.input.isDown('ShiftRight');
        const count = all ? this.availableCount(data.itemId) : 1;
        if (count > 0) {
          this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: data.itemId, count });
          this.rebuildStacks();
          this.refreshCraftState();
        }
      }
    }
  }

  // ---------- interaction ----------

  private raycastCursor(camera: THREE.PerspectiveCamera): { obj: THREE.Group } | null {
    this.pointerNdc.set(
      (this.input.cursorX / window.innerWidth) * 2 - 1,
      -(this.input.cursorY / window.innerHeight) * 2 + 1,
    );
    this.raycaster.setFromCamera(this.pointerNdc, camera);
    const hits = this.raycaster.intersectObject(this.root, true);
    for (const hit of hits) {
      let node: THREE.Object3D | null = hit.object;
      while (node && node !== this.root) {
        if ((node.userData.pick as Pick | undefined)) {
          this.setHovered(node as THREE.Group);
          return { obj: node as THREE.Group };
        }
        node = node.parent;
      }
    }
    this.setHovered(null);
    return null;
  }

  private setHovered(obj: THREE.Group | null): void {
    if (this.hovered === obj) return;
    if (this.hovered) this.hovered.scale.setScalar(1);
    this.hovered = obj;
    if (obj) obj.scale.setScalar(1.09);
  }

  private updateTooltip(pick: { obj: THREE.Group } | null): void {
    if (!pick) {
      this.tooltip.style.display = 'none';
      return;
    }
    const data = pick.obj.userData.pick as Pick;
    let text = '';
    if (data.type === 'stack' && data.itemId) {
      text = `${STRINGS.items[data.itemId]} ×${this.availableCount(data.itemId)} — ${STRINGS.backpack.dropHint}`;
    } else if (data.type === 'center' && data.itemId) {
      text = `${STRINGS.items[data.itemId]} — ${STRINGS.backpack.clickToReturn}`;
    } else if (data.type === 'gear' && this.matched) {
      text = `${STRINGS.backpack.craft} ${STRINGS.items[this.matched.result.itemId]}`;
    }
    this.tooltip.textContent = text;
    this.tooltip.style.display = 'block';
    this.tooltip.style.left = `${this.input.cursorX + 14}px`;
    this.tooltip.style.top = `${this.input.cursorY + 12}px`;
  }

  private moveToCenter(itemId: ItemId | undefined): void {
    if (!itemId || this.centerUnits.length >= MAX_CENTER_ITEMS) return;
    if (this.availableCount(itemId) <= 0) return;

    const stack = this.stacks.get(itemId);
    const unit = buildItemUnit(itemId);
    unit.userData.pick = { type: 'center', itemId } satisfies Pick;
    unit.position.copy(stack ? stack.position : new THREE.Vector3());
    unit.position.y += 0.05;
    this.centerGroup.add(unit);
    this.centerUnits.push({ itemId, mesh: unit });

    this.rebuildStacks();
    this.layoutCenter();
    this.refreshCraftState();
  }

  private returnFromCenter(mesh: THREE.Group): void {
    const idx = this.centerUnits.findIndex((u) => u.mesh === mesh);
    if (idx === -1) return;
    const { itemId } = this.centerUnits[idx];
    this.centerUnits.splice(idx, 1);
    delete mesh.userData.pick; // no longer clickable mid-flight

    const anchor = this.anchorFor(itemId);
    this.tweenPos(mesh, new THREE.Vector3(anchor[0], 0.02, anchor[1]), 0.3, () => {
      disposeObject3D(mesh);
      this.centerGroup.remove(mesh);
      this.rebuildStacks();
    });
    this.layoutCenter();
    this.refreshCraftState();
  }

  private craft(): void {
    const recipe = this.matched;
    if (!recipe) return;
    this.bus.dispatch({ type: 'CRAFT', recipeId: recipe.id });

    // Ingredients shrink away, the result pops in the circle, then joins its pile.
    for (const { mesh } of this.centerUnits) {
      this.tweens.push({
        t: 0, dur: 0.22,
        apply: (k) => mesh.scale.setScalar(1 - k),
        onDone: () => { disposeObject3D(mesh); this.centerGroup.remove(mesh); },
      });
    }
    this.centerUnits = [];
    this.rebuildStacks();
    this.refreshCraftState();

    const result = buildItemUnit(recipe.result.itemId);
    result.position.set(0, 0.05, 0);
    result.scale.setScalar(0.01);
    this.centerGroup.add(result);
    this.tweens.push({
      t: 0, dur: 0.35,
      apply: (k) => result.scale.setScalar(0.01 + 1.14 * k - 0.15 * k * k),
    });
    this.tweens.push({
      t: 0, dur: 1.1,
      apply: () => {},
      onDone: () => {
        disposeObject3D(result);
        this.centerGroup.remove(result);
        this.rebuildStacks();
      },
    });
  }

  // ---------- view building ----------

  /** Units of an item still on its pile (inventory minus what sits in the center). */
  private availableCount(itemId: ItemId): number {
    let count = 0;
    for (const slot of this.bus.state.inventory) if (slot.itemId === itemId) count += slot.count;
    for (const u of this.centerUnits) if (u.itemId === itemId) count--;
    return count;
  }

  private rebuildStacks(): void {
    // Dispose the old pile meshes — this runs on every open/click/drop/craft,
    // so skipping it was the game's fastest interactive GPU leak.
    for (const g of this.stacks.values()) {
      disposeObject3D(g, this.ghostKeep);
      this.itemsGroup.remove(g);
    }
    this.stacks.clear();
    if (this.hovered && !this.centerUnits.some((u) => u.mesh === this.hovered)) this.setHovered(null);

    const seen: ItemId[] = [];
    for (const slot of this.bus.state.inventory) {
      if (!seen.includes(slot.itemId)) seen.push(slot.itemId);
    }
    for (const itemId of seen) {
      const count = this.availableCount(itemId);
      if (count <= 0) continue;
      const [ax, az] = this.anchorFor(itemId);
      const group = new THREE.Group();
      group.userData.pick = { type: 'stack', itemId } satisfies Pick;
      group.position.set(ax, 0.02, az);
      for (let i = 0; i < Math.min(count, MAX_VISIBLE_UNITS); i++) {
        const unit = buildItemUnit(itemId);
        const p = pilePlacement(itemId, i);
        unit.position.set(p.x, p.y, p.z);
        unit.rotation.y = p.rotY;
        group.add(unit);
      }
      this.itemsGroup.add(group);
      this.stacks.set(itemId, group);
    }
  }

  private layoutCenter(): void {
    this.centerUnits.forEach(({ mesh }, i) => {
      const a = (i / MAX_CENTER_ITEMS) * Math.PI * 2 - Math.PI / 2;
      const target = new THREE.Vector3(
        Math.cos(a) * CENTER_RADIUS * (this.centerUnits.length > 1 ? 1 : 0),
        0.02,
        Math.sin(a) * CENTER_RADIUS * (this.centerUnits.length > 1 ? 1 : 0),
      );
      this.tweenPos(mesh, target, 0.3);
    });
  }

  /** Dispose a group's item meshes (sparing the shared ghost material) then detach them. */
  private disposeAndClear(group: THREE.Group): void {
    for (const c of group.children) disposeObject3D(c, this.ghostKeep);
    group.clear();
  }

  private refreshCraftState(): void {
    const ids = this.centerUnits.map((u) => u.itemId);
    this.matched = matchRecipe(ids);
    this.gear.visible = this.matched !== null;

    this.disposeAndClear(this.ghostGroup);
    if (!this.matched) {
      const hint = findHint(ids);
      if (hint) {
        hint.missing.slice(0, MAX_CENTER_ITEMS - ids.length).forEach((itemId, j) => {
          const ghost = buildItemUnit(itemId);
          ghost.traverse((n) => {
            if (n instanceof THREE.Mesh) n.material = this.ghostMat;
          });
          const i = ids.length + j;
          const a = (i / MAX_CENTER_ITEMS) * Math.PI * 2 - Math.PI / 2;
          ghost.position.set(Math.cos(a) * CENTER_RADIUS, 0.02, Math.sin(a) * CENTER_RADIUS);
          this.ghostGroup.add(ghost);
        });
      }
    }
  }

  private buildCloth(): THREE.Group {
    const cloth = new THREE.Group();

    const geo = new THREE.PlaneGeometry(CLOTH_W, CLOTH_H, 12, 9);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      // Slight rumple so it reads as fabric, not a board (cosmetic randomness).
      pos.setY(i, Math.random() * 0.012);
    }
    geo.computeVertexNormals();
    const base = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({ color: 0x7a5a3a, roughness: 1, side: THREE.DoubleSide }),
    );
    base.receiveShadow = true;
    cloth.add(base);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(CENTER_RADIUS + 0.045, CENTER_RADIUS + 0.06, 40),
      new THREE.MeshStandardMaterial({ color: 0x3f2f1f, transparent: true, opacity: 0.85 }),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.018;
    cloth.add(ring);

    return cloth;
  }

  private buildGear(): THREE.Group {
    const g = new THREE.Group();
    const metal = new THREE.MeshStandardMaterial({
      color: 0xc9a227,
      roughness: 0.4,
      metalness: 0.6,
      emissive: 0x4a3a08,
    });
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.024, 12), metal);
    g.add(disc);
    for (let i = 0; i < 8; i++) {
      const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.022, 0.022), metal);
      const a = (i / 8) * Math.PI * 2;
      tooth.position.set(Math.cos(a) * 0.068, 0, Math.sin(a) * 0.068);
      tooth.rotation.y = -a;
      g.add(tooth);
    }
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.03, 8),
      new THREE.MeshStandardMaterial({ color: 0x3a2f10, roughness: 0.6 }));
    g.add(hub);
    g.position.set(0, 0.06, CENTER_RADIUS + 0.19);
    g.userData.pick = { type: 'gear' } satisfies Pick;
    return g;
  }

  // ---------- tween helpers ----------

  private tweenPos(obj: THREE.Object3D, to: THREE.Vector3, dur: number, onDone?: () => void): void {
    const from = obj.position.clone();
    this.tweens.push({ t: 0, dur, apply: (k) => obj.position.lerpVectors(from, to, k), onDone });
  }

  private tweenPitch(to: number): void {
    const from = this.player.pitch;
    this.tweens.push({ t: 0, dur: 0.35, apply: (k) => (this.player.pitch = from + (to - from) * k) });
  }

  private tweenFov(camera: THREE.PerspectiveCamera, to: number): void {
    const from = camera.fov;
    this.tweens.push({
      t: 0,
      dur: 0.35,
      apply: (k) => {
        camera.fov = from + (to - from) * k;
        camera.updateProjectionMatrix();
      },
    });
  }

  /** Permanent per-item spot; unknown future items fall back to spare slots. */
  private anchorFor(itemId: ItemId): [number, number] {
    const fixed = ITEM_ANCHORS[itemId];
    if (fixed) return fixed;
    if (!this.anchorIndex.has(itemId)) {
      this.anchorIndex.set(itemId, this.anchorIndex.size % SPARE_ANCHORS.length);
    }
    return SPARE_ANCHORS[this.anchorIndex.get(itemId)!];
  }

  private clearCenter(): void {
    this.disposeAndClear(this.centerGroup);
    this.centerUnits = [];
    this.matched = null;
    this.gear.visible = false;
    this.disposeAndClear(this.ghostGroup);
  }
}
