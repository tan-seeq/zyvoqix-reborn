/**
 * Στόχοι/Αποστολές overlay (J): level + XP bar + perk summary, active quests
 * with progress, completed quests. Grows into the full journal in Phase 6.
 */
import type { GameState } from '../core/GameState';
import { meleeBonus, QUESTS, sprintDrainFactor, xpForNextLevel, MAX_LEVEL } from '../survival/quests';
import { STRINGS } from '../i18n';

export class QuestsPanel {
  private el: HTMLElement;

  constructor() {
    this.el = document.createElement('div');
    this.el.id = 'quests-menu';
    this.el.classList.add('hidden');
    document.body.appendChild(this.el);
  }

  get isOpen(): boolean {
    return !this.el.classList.contains('hidden');
  }

  close(): void {
    this.el.classList.add('hidden');
  }

  toggle(state: GameState): void {
    if (this.isOpen) {
      this.el.classList.add('hidden');
      return;
    }
    this.render(state);
    this.el.classList.remove('hidden');
  }

  private render(state: GameState): void {
    const p = state.progress;
    const next = p.level >= MAX_LEVEL ? null : xpForNextLevel(p.level);
    const dmg = Math.round((meleeBonus(p.level) - 1) * 100);
    const stam = Math.round((1 - sprintDrainFactor(p.level)) * 100);

    const active = QUESTS.filter((q) => !p.completedQuests.includes(q.id));
    const done = QUESTS.filter((q) => p.completedQuests.includes(q.id));

    this.el.innerHTML = `
      <h2>${STRINGS.quests.title}</h2>
      <div class="xp-header">
        <span>${STRINGS.quests.level} ${p.level}${p.level >= MAX_LEVEL ? ' (max)' : ''}</span>
        <div class="xp-bar"><div class="xp-fill" style="width:${next ? Math.min(100, (p.xp / next) * 100) : 100}%"></div></div>
        <span>${next ? `${p.xp}/${next} XP` : ''}</span>
      </div>
      <p class="menu-hint">${STRINGS.quests.perks}: +${dmg}% ${STRINGS.quests.perkDamage} · −${stam}% ${STRINGS.quests.perkStamina}</p>
      <h3>${STRINGS.quests.active}</h3>
      <div class="quest-rows">
        ${active
          .map((q) => {
            const cur = Math.min(q.target, p.counters[q.counter] ?? 0);
            const def = STRINGS.quests.defs[q.id];
            return `
            <div class="quest-row">
              <span class="q-name">${def.title}</span>
              <span class="q-desc">${def.desc}</span>
              <span class="q-progress">${cur}/${q.target}</span>
              <span class="q-xp">+${q.xp} XP</span>
            </div>`;
          })
          .join('')}
      </div>
      ${done.length ? `<h3>${STRINGS.quests.completed}</h3>
      <div class="quest-rows done">
        ${done.map((q) => {
          const def = STRINGS.quests.defs[q.id];
          return `<div class="quest-row"><span class="q-name">✓ ${def.title}</span><span class="q-desc">${def.desc}</span><span></span><span class="q-xp">+${q.xp} XP</span></div>`;
        }).join('')}
      </div>` : ''}
      <div class="menu-hint">${STRINGS.quests.closeHint}</div>`;
  }
}
