/**
 * HUD overlay: crosshair, stats bars, 8-slot hotbar, interaction prompt,
 * in-game clock, dev stats (FPS/backend), and the pause menu shown whenever
 * pointer lock is released.
 *
 * The whole overlay is built from `template()` so a language change can
 * rebuild it in place (`applyLocale`) — the notebook, help and pause screens
 * bake their strings into markup once rather than re-rendering per frame.
 * Everything the per-frame `update()` touches is cached in `bind()`: the HUD
 * runs at display rate, so it must never walk the DOM to find an element.
 */
import type { GameState } from '../core/GameState';
import { HOTBAR_SLOTS, isNight } from '../core/GameState';
import { xpForNextLevel, MAX_LEVEL } from '../survival/quests';
import { getHotbarStacks } from '../survival/crafting';
import type { InteractionTarget } from '../player/interaction';
import type { PlacementHudInfo } from '../building/placement';
import { BUILD_DEFS, buildDefFor } from '../building/pieces';
import { canAfford, countItem, RECIPES } from '../survival/crafting';
import { ITEM_DEFS, armorDamageFactor } from '../survival/items';
import { AUTOSAVE_SLOT, listSaves } from '../save/persistence';
import { STRINGS, localeTag, onLocaleChange } from '../i18n';

const STAT_KEYS = ['health', 'hunger', 'thirst', 'energy'] as const;
const CHIP_KEYS = ['regen', 'hungry', 'thirsty', 'tired', 'night', 'fire', 'armor'] as const;
type ChipKey = (typeof CHIP_KEYS)[number];

export class Hud {
  onResume: (() => void) | null = null;
  /** Set by main after each render: live renderer stats for the dev line. */
  perf: { calls: number; triangles: number } | null = null;
  onOpenSettings: (() => void) | null = null;
  onMainMenu: (() => void) | null = null;
  onSaveSlot: ((slot: number) => void) | null = null;
  onLoadSlot: ((slot: number) => void) | null = null;
  onDeleteSlot: ((slot: number) => void) | null = null;
  onNewGame: (() => void) | null = null;

  private hudEl: HTMLElement;
  // Cached in bind() so the per-frame HUD update never re-walks the DOM.
  private devStats!: HTMLElement;
  private clock!: HTMLElement;
  private pauseMenu!: HTMLElement;
  private buildMenu!: HTMLElement;
  private helpMenu!: HTMLElement;
  private prompt!: HTMLElement;
  private toast!: HTMLElement;
  private saveRows!: HTMLElement;
  private pickupFeed!: HTMLElement;
  private damageVignette!: HTMLElement;
  private sleepFadeEl!: HTMLElement;
  private levelNum!: HTMLElement;
  private xpFill!: HTMLElement;
  private statFills = new Map<string, HTMLElement>();
  private chips = new Map<ChipKey, HTMLElement>();
  private hotbarSlots: HTMLElement[] = [];
  private hotbarNames: HTMLElement[] = [];
  private hotbarCounts: HTMLElement[] = [];
  private compassLabels: HTMLElement[] = [];
  private buildRows: { el: HTMLElement; type: string }[] = [];
  /** Last string written to #prompt — skips a DOM write on unchanged frames. */
  private lastPromptText = '';
  private frames = 0;
  private fpsTimer = 0;
  private toastTimer = 0;
  private backend: string;

  constructor(root: HTMLElement, backend: string) {
    this.backend = backend;
    this.hudEl = document.createElement('div');
    this.hudEl.id = 'hud';
    root.appendChild(this.hudEl);
    this.build();
    onLocaleChange(() => this.applyLocale());
  }

  /** Rebuild the markup in the active language, preserving what was open. */
  private applyLocale(): void {
    const paused = !this.pauseMenu.classList.contains('hidden');
    const helpOpen = this.helpOpen;
    this.build();
    this.pauseMenu.classList.toggle('hidden', !paused);
    this.helpMenu.classList.toggle('hidden', !helpOpen);
    if (paused) this.refreshSaves();
    // The prompt is dirty-checked; force the next frame to repaint it.
    this.lastPromptText = '';
    this.toastTimer = 0;
  }

  private build(): void {
    this.hudEl.innerHTML = this.template();
    this.bind();
  }

  private template(): string {
    return `
      <div id="crosshair"></div>
      <div id="dev-stats"></div>
      <div id="clock"></div>
      <div id="compass"><div class="c-caret">▾</div>${STRINGS.compass
        .map((label, i) => `<span class="c-label" data-deg="${i * 45}">${label}</span>`)
        .join('')}</div>
      <div id="status-chips">
        <span class="chip chip-good" data-chip="regen" title="${STRINGS.chips.regen}">✚</span>
        <span class="chip" data-chip="hungry" title="${STRINGS.chips.hungry}">🍖</span>
        <span class="chip" data-chip="thirsty" title="${STRINGS.chips.thirsty}">💧</span>
        <span class="chip" data-chip="tired" title="${STRINGS.chips.tired}">⚡</span>
        <span class="chip" data-chip="night" title="${STRINGS.chips.night}">🌙</span>
        <span class="chip chip-good" data-chip="fire" title="${STRINGS.chips.fire}">🔥</span>
        <span class="chip chip-good" data-chip="armor" title="${STRINGS.chips.armor}">🛡</span>
      </div>
      <div id="level-badge">
        <span id="level-num">1</span>
        <div id="xp-mini"><div id="xp-mini-fill"></div></div>
      </div>
      <div id="prompt"></div>
      <div id="toast"></div>
      <div id="sleep-fade"></div>
      <div id="damage-vignette"></div>
      <div id="pickup-feed"></div>
      <div id="stats-bars">
        ${STAT_KEYS.map(
          (key) => `
          <div class="stat-row">
            <span class="stat-label">${STRINGS.stats[key]}</span>
            <div class="stat-bar"><div class="stat-fill stat-${key}" data-stat="${key}"></div></div>
          </div>`,
        ).join('')}
      </div>
      <div id="hotbar">
        ${Array.from({ length: HOTBAR_SLOTS }, (_, i) => `
          <div class="hotbar-slot"><span class="slot-key">${i + 1}</span><span class="slot-name"></span><span class="slot-count"></span></div>`).join('')}
      </div>
      <div id="build-menu" class="hidden">
        <h2>${STRINGS.build.title}</h2>
        <div class="nb-pages">
          <div class="nb-page">
            <h3>${STRINGS.build.buildsPage}</h3>
            <div id="build-rows">
              ${BUILD_DEFS.map(
                (d, i) => `
                <div class="build-row" data-type="${d.type}">
                  <kbd>${i + 1}</kbd>
                  <span class="b-name">${STRINGS.build.pieces[d.type]}</span>
                  <span class="b-cost">${d.cost.map((c) => `${c.count}× ${STRINGS.items[c.itemId]}`).join(', ')}</span>
                </div>`,
              ).join('')}
            </div>
            <div class="menu-hint">${STRINGS.build.stairsHint}</div>
          </div>
          <div class="nb-page">
            <h3>${STRINGS.build.recipesPage}</h3>
            <div class="nb-recipes">
              ${RECIPES.map(
                (r) => `
                <div class="nb-recipe-row">
                  <span class="b-name">${STRINGS.items[r.result.itemId]}${r.result.count > 1 ? ` ×${r.result.count}` : ''}</span>
                  <span class="b-cost">${r.ingredients.map((i) => `${i.count}× ${STRINGS.items[i.itemId]}`).join(' + ')}</span>
                </div>`,
              ).join('')}
            </div>
            <div class="menu-hint">${STRINGS.build.recipesHint}</div>
          </div>
        </div>
        <div class="menu-hint nb-close">${STRINGS.build.menuHint}</div>
      </div>
      <div id="help-menu" class="hidden">
        <h2>${STRINGS.help.title}</h2>
        <h3>${STRINGS.help.recipes}</h3>
        <div class="help-grid">
          ${RECIPES.map(
            (r) => `
            <span>${STRINGS.items[r.result.itemId]}</span>
            <span>${r.ingredients.map((i) => `${i.count}× ${STRINGS.items[i.itemId]}`).join(' + ')}</span>`,
          ).join('')}
        </div>
        <h3>${STRINGS.help.building}</h3>
        <div class="help-grid">
          ${BUILD_DEFS.map(
            (d) => `
            <span>${STRINGS.build.pieces[d.type]}</span>
            <span>${d.cost.map((c) => `${c.count}× ${STRINGS.items[c.itemId]}`).join(' + ')}</span>`,
          ).join('')}
        </div>
        <h3>${STRINGS.help.sources}</h3>
        <div class="help-lines">
          ${STRINGS.help.sourceLines.map((l) => `<div>${l}</div>`).join('')}
        </div>
        <div class="menu-hint">${STRINGS.help.closeHint}</div>
      </div>
      <div id="pause-menu">
        <h1>${STRINGS.paused}</h1>
        <button id="resume-btn">${STRINGS.resume}</button>
        <div class="pause-row">
          <button id="pause-settings-btn">${STRINGS.menu.settings}</button>
          <button id="pause-mainmenu-btn">${STRINGS.menu.mainMenu}</button>
        </div>
        <div>
          <div id="controls-list">
            ${STRINGS.controls.map(([key, label]) => `<kbd>${key}</kbd><span>${label}</span>`).join('')}
          </div>
        </div>
        <div id="saves">
          <h3>${STRINGS.saves.title}</h3>
          <div id="save-rows"></div>
          <button id="new-game-btn">${STRINGS.saves.newGame}</button>
        </div>
      </div>`;
  }

  private bind(): void {
    const hud = this.hudEl;
    this.devStats = hud.querySelector('#dev-stats')!;
    this.clock = hud.querySelector('#clock')!;
    this.pauseMenu = hud.querySelector('#pause-menu')!;
    this.buildMenu = hud.querySelector('#build-menu')!;
    this.helpMenu = hud.querySelector('#help-menu')!;
    this.prompt = hud.querySelector('#prompt')!;
    this.toast = hud.querySelector('#toast')!;
    this.saveRows = hud.querySelector('#save-rows')!;
    this.pickupFeed = hud.querySelector('#pickup-feed')!;
    this.damageVignette = hud.querySelector('#damage-vignette')!;
    this.sleepFadeEl = hud.querySelector('#sleep-fade')!;
    this.levelNum = hud.querySelector('#level-num')!;
    this.xpFill = hud.querySelector('#xp-mini-fill')!;

    this.statFills.clear();
    for (const el of hud.querySelectorAll<HTMLElement>('.stat-fill')) {
      this.statFills.set(el.dataset.stat!, el);
    }
    this.chips.clear();
    for (const el of hud.querySelectorAll<HTMLElement>('.chip')) {
      this.chips.set(el.dataset.chip as ChipKey, el);
    }
    this.hotbarSlots = [...hud.querySelectorAll<HTMLElement>('.hotbar-slot')];
    this.hotbarNames = this.hotbarSlots.map((s) => s.querySelector<HTMLElement>('.slot-name')!);
    this.hotbarCounts = this.hotbarSlots.map((s) => s.querySelector<HTMLElement>('.slot-count')!);
    this.compassLabels = [...hud.querySelectorAll<HTMLElement>('#compass .c-label')];
    this.buildRows = [...hud.querySelectorAll<HTMLElement>('.build-row')].map((el) => ({
      el,
      type: el.dataset.type!,
    }));
    this.devStats.textContent = `— fps · ${this.backend}`;

    hud.querySelector('#resume-btn')!.addEventListener('click', () => this.onResume?.());
    hud.querySelector('#pause-settings-btn')!.addEventListener('click', () => this.onOpenSettings?.());
    hud.querySelector('#pause-mainmenu-btn')!.addEventListener('click', () => this.onMainMenu?.());
    hud.querySelector('#new-game-btn')!.addEventListener('click', () => this.onNewGame?.());
    this.saveRows.addEventListener('click', (e) => {
      const btn = (e.target as HTMLElement).closest<HTMLElement>('button[data-act]');
      if (!btn) return;
      const slot = Number(btn.closest<HTMLElement>('.save-row')!.dataset.slot);
      if (btn.dataset.act === 'save') this.onSaveSlot?.(slot);
      else if (btn.dataset.act === 'load') this.onLoadSlot?.(slot);
      else if (btn.dataset.act === 'del') this.onDeleteSlot?.(slot);
    });
  }

  setPaused(paused: boolean): void {
    this.pauseMenu.classList.toggle('hidden', !paused);
    if (paused) this.refreshSaves();
  }

  refreshSaves(): void {
    const tag = localeTag();
    this.saveRows.innerHTML = listSaves()
      .map((meta, i) => {
        const slot = i + 1;
        const auto = slot === AUTOSAVE_SLOT ? ` ${STRINGS.saves.autoLabel}` : '';
        const label = meta
          ? `${STRINGS.saves.day} ${meta.day} — ${meta.savedAt ? new Date(meta.savedAt).toLocaleString(tag) : ''}`
          : STRINGS.saves.empty;
        return `
          <div class="save-row" data-slot="${slot}">
            <span class="save-label">${STRINGS.saves.slot} ${slot}${auto}: ${label}</span>
            <span class="save-actions">
              <button data-act="save">${STRINGS.saves.save}</button>
              <button data-act="load" ${meta ? '' : 'disabled'}>${STRINGS.saves.load}</button>
              <button data-act="del" ${meta ? '' : 'disabled'}>${STRINGS.saves.del}</button>
            </span>
          </div>`;
      })
      .join('');
  }

  /** Transient center-screen message (death, warnings). */
  showToast(text: string): void {
    this.toast.textContent = text;
    this.toastTimer = 4;
  }

  /** H toggles the recipes/materials help overlay. */
  toggleHelp(): void {
    this.helpMenu.classList.toggle('hidden');
  }

  get helpOpen(): boolean {
    return !this.helpMenu.classList.contains('hidden');
  }

  closeHelp(): void {
    this.helpMenu.classList.add('hidden');
  }

  private lastPickup: { itemId: string; count: number; el: HTMLElement; at: number } | null = null;

  /** "+2 Stone" feed above the hotbar — rapid same-item gains merge into one line. */
  pushPickup(itemId: string, label: string, count: number): void {
    const now = performance.now();
    if (this.lastPickup && this.lastPickup.itemId === itemId && now - this.lastPickup.at < 1800 && this.lastPickup.el.isConnected) {
      this.lastPickup.count += count;
      this.lastPickup.at = now;
      this.lastPickup.el.textContent = `+${this.lastPickup.count} ${label}`;
      this.lastPickup.el.classList.remove('pickup-entry');
      void this.lastPickup.el.offsetWidth; // restart the fade animation
      this.lastPickup.el.classList.add('pickup-entry');
      return;
    }
    const el = document.createElement('div');
    el.className = 'pickup-entry';
    el.textContent = `+${count} ${label}`;
    this.pickupFeed.appendChild(el);
    this.lastPickup = { itemId, count, el, at: now };
    while (this.pickupFeed.children.length > 5) this.pickupFeed.firstChild!.remove();
    setTimeout(() => el.remove(), 2600);
  }

  /** Red edge flash when the player takes a hit. */
  damageFlash(): void {
    const el = this.damageVignette;
    el.classList.remove('active');
    // restart the CSS animation
    void el.offsetWidth;
    el.classList.add('active');
  }

  /** Quick black fade for sleeping through the night. */
  sleepFade(): void {
    const el = this.sleepFadeEl;
    el.classList.add('active');
    setTimeout(() => el.classList.remove('active'), 900);
  }

  update(
    renderDt: number,
    clockText: string,
    state: GameState,
    target: InteractionTarget,
    canSleep = false,
    placement: PlacementHudInfo | null = null,
    nearFire = false,
  ): void {
    this.frames++;
    this.fpsTimer += renderDt;
    if (this.fpsTimer >= 0.5) {
      const fps = Math.round(this.frames / this.fpsTimer);
      const ms = ((this.fpsTimer / this.frames) * 1000).toFixed(1);
      this.frames = 0;
      this.fpsTimer = 0;
      let line = `${fps} fps · ${ms}ms · ${this.backend}`;
      if (this.perf) {
        line += ` · ${this.perf.calls} calls · ${Math.round(this.perf.triangles / 1000)}k tris`;
      }
      this.devStats.textContent = line;
    }
    const night = isNight(state);
    this.damageVignette.classList.toggle('low', state.survival.health < 20);
    this.clock.textContent = `${night ? '🌙' : '☀️'} ${STRINGS.day} ${state.day} — ${clockText}`;
    this.renderCompass(state.player.yaw);
    this.renderChips(state, night, nearFire);
    this.renderLevel(state);

    for (const key of STAT_KEYS) {
      const el = this.statFills.get(key)!;
      const value = state.survival[key];
      el.style.width = `${value}%`;
      el.classList.toggle('stat-low', value < 20);
    }

    const hotbar = getHotbarStacks(state);
    for (let i = 0; i < this.hotbarSlots.length; i++) {
      const slotEl = this.hotbarSlots[i];
      const slot = hotbar[i];
      slotEl.classList.toggle('filled', !!slot);
      slotEl.classList.toggle('consumable', !!slot && !!ITEM_DEFS[slot.itemId].consumable);
      slotEl.classList.toggle('equipped', !!slot && slot.itemId === state.player.equippedWeapon);
      this.hotbarNames[i].textContent = slot ? STRINGS.items[slot.itemId] : '';
      this.hotbarCounts[i].textContent = slot ? `×${slot.count}` : '';
    }

    const promptText = this.promptText(target, canSleep, placement, state);
    if (promptText !== this.lastPromptText) {
      this.prompt.textContent = promptText;
      this.lastPromptText = promptText;
    }
    this.updateBuildMenu(placement?.kind === 'menu', state);

    if (this.toastTimer > 0) {
      this.toastTimer -= renderDt;
      this.toast.style.opacity = String(Math.min(1, this.toastTimer / 1.5));
    }
  }

  /** Sliding cardinal tape driven by the player's heading. */
  private renderCompass(yaw: number): void {
    const heading = (((-yaw * 180) / Math.PI) % 360 + 360) % 360;
    const pxPerDeg = 1.5;
    for (const el of this.compassLabels) {
      const deg = Number(el.dataset.deg);
      const rel = ((deg - heading + 540) % 360) - 180; // -180..180
      el.style.transform = `translateX(${rel * pxPerDeg}px)`;
      el.style.opacity = Math.abs(rel) > 75 ? '0' : String(1 - Math.abs(rel) / 90);
    }
  }

  /** Status/buff chips: light up only when relevant. */
  private renderChips(state: GameState, night: boolean, nearFire: boolean): void {
    const s = state.survival;
    const set = (key: ChipKey, on: boolean, critical = false) => {
      const el = this.chips.get(key)!;
      el.classList.toggle('active', on);
      el.classList.toggle('critical', on && critical);
    };
    set('regen', s.hunger > 60 && s.thirst > 60 && s.health < 100);
    set('hungry', s.hunger < 20, s.hunger <= 0);
    set('thirsty', s.thirst < 20, s.thirst <= 0);
    set('tired', s.energy < 10, s.energy <= 2);
    set('night', night);
    set('fire', nearFire);
    set('armor', armorDamageFactor(state.inventory) < 1);
  }

  private renderLevel(state: GameState): void {
    const p = state.progress;
    this.levelNum.textContent = String(p.level);
    const next = p.level >= MAX_LEVEL ? null : xpForNextLevel(p.level);
    this.xpFill.style.width = next ? `${Math.min(100, (p.xp / next) * 100)}%` : '100%';
  }

  private updateBuildMenu(open: boolean, state: GameState): void {
    this.buildMenu.classList.toggle('hidden', !open);
    if (!open) return;
    for (const row of this.buildRows) {
      const def = BUILD_DEFS.find((d) => d.type === row.type)!;
      row.el.classList.toggle('unaffordable', !canAfford(state, def.cost));
    }
  }

  private promptText(
    target: InteractionTarget,
    canSleep: boolean,
    placement: PlacementHudInfo | null,
    state?: GameState,
  ): string {
    if (placement?.kind === 'menu') return '';
    if (placement?.kind === 'ghost') {
      if (placement.buildType === 'campfire') return STRINGS.prompts.place;
      const def = buildDefFor(placement.buildType);
      const cost = def.cost.map((c) => `${c.count}× ${STRINGS.items[c.itemId]}`).join(', ');
      let text = `${STRINGS.build.pieces[placement.buildType]} · ${STRINGS.build.cost} ${cost} · ${STRINGS.build.ghostControls}`;
      if (!placement.affordable) text += ` — ${STRINGS.build.missingMaterials}`;
      else if (!placement.valid && placement.buildType !== 'foundation') {
        text += ` — ${STRINGS.build.needsSocket}`;
      }
      return text;
    }
    if (!target) {
      if (canSleep) return STRINGS.prompts.sleep;
      if (state?.player.equippedWeapon === 'bow_wood') {
        return `${STRINGS.prompts.arrows} ×${countItem(state, 'arrow')} · ${STRINGS.prompts.shoot}`;
      }
      return '';
    }
    switch (target.kind) {
      case 'drink':
        return `E — ${STRINGS.prompts.drink}`;
      case 'fill':
        return `E — ${STRINGS.prompts.fill}`;
      case 'campfire':
        if (target.canBoil) return `E — ${STRINGS.prompts.boil} · ${STRINGS.prompts.demolish}`;
        if (target.canCook) return `E — ${STRINGS.prompts.cook} · ${STRINGS.prompts.demolish}`;
        return canSleep ? STRINGS.prompts.sleep : `${STRINGS.prompts.campfire} · ${STRINGS.prompts.demolish}`;
      case 'animal':
        return `E/${STRINGS.keys.click} — ${STRINGS.prompts.attack} ${STRINGS.animals[target.animal]}`;
      case 'hollow':
        return `E/${STRINGS.keys.click} — ${STRINGS.prompts.attack} ${STRINGS.hollow}`;
      case 'door':
        return `E — ${target.open ? STRINGS.prompts.doorClose : STRINGS.prompts.doorOpen} · ${STRINGS.prompts.demolish}`;
      case 'chest':
        return `E — ${STRINGS.prompts.chest} · ${STRINGS.prompts.demolish}`;
      case 'bed':
        return `E — ${STRINGS.prompts.bed} · ${STRINGS.prompts.demolish}`;
      case 'piece':
        if (target.damaged) return `E — ${STRINGS.prompts.repair} · ${STRINGS.prompts.demolish}`;
        return STRINGS.prompts.demolish;
      case 'harvest': {
        if (target.missingItem) return `${STRINGS.prompts.hold} ${STRINGS.items[target.missingItem]}`;
        const progress = target.hp > 1 ? ` (${target.hits}/${target.hp})` : '';
        return `E — ${STRINGS.prompts[target.objectKind]}${progress}`;
      }
    }
  }
}
