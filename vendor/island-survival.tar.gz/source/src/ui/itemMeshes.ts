/**
 * Small low-poly 3D representations of inventory items for the Σακίδιο cloth.
 * Each call returns a fresh group (~unit scale in meters, sitting on y=0),
 * plus pile placement patterns so stacks read as piles, not grids.
 */
import * as THREE from 'three';
import type { ItemId } from '../survival/items';

function mat(color: number, opts: { rough?: number; metal?: number } = {}): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: opts.rough ?? 0.9,
    metalness: opts.metal ?? 0,
    flatShading: true,
  });
}

export function buildItemUnit(itemId: ItemId): THREE.Group {
  const g = new THREE.Group();
  switch (itemId) {
    case 'log': {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.4, 7), mat(0x6b4a2b));
      log.rotation.z = Math.PI / 2;
      log.position.y = 0.05;
      g.add(log);
      break;
    }
    case 'stick': {
      const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.017, 0.34, 5), mat(0x8a6a42));
      stick.rotation.z = Math.PI / 2;
      stick.position.y = 0.017;
      g.add(stick);
      break;
    }
    case 'stone': {
      const stone = new THREE.Mesh(new THREE.IcosahedronGeometry(0.055, 0), mat(0x8b8578));
      stone.scale.set(1, 0.75, 1.15);
      stone.position.y = 0.04;
      g.add(stone);
      break;
    }
    case 'berries': {
      const m = mat(0x8e3b6b, { rough: 0.6 });
      const offsets: Array<[number, number, number]> = [
        [0, 0.025, 0], [0.04, 0.025, 0.02], [-0.03, 0.025, 0.03], [0.01, 0.06, 0.02],
      ];
      for (const [x, y, z] of offsets) {
        const b = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 5), m);
        b.position.set(x, y, z);
        g.add(b);
      }
      break;
    }
    case 'fiber': {
      const coil = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.012, 5, 10), mat(0xc9b46a));
      coil.rotation.x = -Math.PI / 2;
      coil.position.y = 0.012;
      g.add(coil);
      break;
    }
    case 'rope': {
      const coil = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.022, 6, 12), mat(0xa98653));
      coil.rotation.x = -Math.PI / 2;
      coil.position.y = 0.022;
      g.add(coil);
      break;
    }
    case 'campfire_kit': {
      const s1 = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.016, 0.26, 5), mat(0x8a6a42));
      s1.rotation.set(0, 0, Math.PI / 2 - 0.3);
      s1.position.y = 0.03;
      const s2 = s1.clone();
      s2.rotation.set(0.4, 1.2, Math.PI / 2 + 0.2);
      g.add(s1, s2);
      const stoneM = mat(0x8b8578);
      for (const [x, z] of [[0.05, 0.04], [-0.05, 0.02], [0, -0.05]]) {
        const st = new THREE.Mesh(new THREE.IcosahedronGeometry(0.032, 0), stoneM);
        st.position.set(x, 0.025, z);
        g.add(st);
      }
      break;
    }
    case 'container_empty':
    case 'container_water':
    case 'container_boiled': {
      const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.036, 0.075, 8, 1, true), mat(0x7a5c39));
      cup.material.side = THREE.DoubleSide;
      cup.position.y = 0.04;
      const bottom = new THREE.Mesh(new THREE.CircleGeometry(0.036, 8), mat(0x6b4a2b));
      bottom.rotation.x = -Math.PI / 2;
      bottom.position.y = 0.004;
      g.add(cup, bottom);
      if (itemId !== 'container_empty') {
        const water = new THREE.Mesh(
          new THREE.CircleGeometry(0.042, 8),
          mat(itemId === 'container_water' ? 0x3a86a8 : 0x7fc4de, { rough: 0.2 }),
        );
        water.rotation.x = -Math.PI / 2;
        water.position.y = 0.068;
        g.add(water);
      }
      break;
    }
    case 'bow_wood': {
      const bow = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.014, 5, 10, Math.PI), mat(0x7a5c39));
      bow.rotation.set(-Math.PI / 2, 0, 0.4);
      bow.position.y = 0.02;
      g.add(bow);
      const string = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.31, 3), mat(0xd8cfae));
      string.rotation.set(Math.PI / 2, 0, 0.4 + Math.PI / 2);
      string.position.y = 0.02;
      g.add(string);
      break;
    }
    case 'arrow': {
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.3, 4), mat(0x8a6a42));
      shaft.rotation.z = Math.PI / 2;
      shaft.position.y = 0.01;
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.016, 0.05, 4), mat(0x8b8578));
      tip.rotation.z = -Math.PI / 2;
      tip.position.set(0.17, 0.01, 0);
      g.add(shaft, tip);
      break;
    }
    case 'axe_stone': {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.02, 0.38, 6), mat(0x7a5c39));
      handle.rotation.z = Math.PI / 2 - 0.35;
      handle.position.y = 0.03;
      g.add(handle);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.11, 0.03), mat(0x8b8578));
      head.position.set(0.15, 0.09, 0);
      head.rotation.z = -0.35;
      g.add(head);
      const wrap = new THREE.Mesh(new THREE.TorusGeometry(0.028, 0.008, 5, 8), mat(0xa98653));
      wrap.position.set(0.14, 0.06, 0);
      wrap.rotation.y = Math.PI / 2;
      g.add(wrap);
      break;
    }
    case 'bandage': {
      const roll = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.07, 10), mat(0xf3ece0, { rough: 0.8 }));
      roll.rotation.x = Math.PI / 2;
      roll.position.y = 0.05;
      g.add(roll);
      const crossM = mat(0xc0392b, { rough: 0.6 });
      g.add(new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.016, 0.012), crossM).translateY(0.05).translateZ(0.036));
      const v = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.05, 0.012), crossM);
      v.position.set(0, 0.05, 0.036);
      g.add(v);
      break;
    }
    case 'hide_vest': {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.26, 0.08), mat(0x6f4a2c));
      body.position.y = 0.14;
      g.add(body);
      for (const x of [-0.07, 0.07]) {
        const strap = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.28, 0.09), mat(0x4f3420));
        strap.position.set(x, 0.14, 0);
        g.add(strap);
      }
      break;
    }
    case 'hide_helmet': {
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), mat(0x6f4a2c));
      cap.scale.set(1, 0.85, 1);
      cap.position.y = 0.03;
      g.add(cap);
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.014, 6, 14), mat(0x4f3420));
      band.rotation.x = -Math.PI / 2;
      band.position.y = 0.035;
      g.add(band);
      break;
    }
    case 'torch': {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.02, 0.28, 6), mat(0x6b4a2b));
      handle.rotation.z = Math.PI / 2;
      handle.position.set(-0.06, 0.03, 0);
      g.add(handle);
      const head = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.028, 0.08, 6), mat(0x4f3420));
      head.rotation.z = Math.PI / 2;
      head.position.set(0.12, 0.03, 0);
      g.add(head);
      const flameMat = new THREE.MeshStandardMaterial({
        color: 0xff8c2a, emissive: 0xff6a00, emissiveIntensity: 1.8,
        transparent: true, opacity: 0.9, depthWrite: false,
      });
      const flame = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.17, 6), flameMat);
      flame.rotation.z = -Math.PI / 2;
      flame.position.set(0.23, 0.03, 0);
      flame.name = 'flame';
      g.add(flame);
      const innerMat = flameMat.clone();
      innerMat.color.setHex(0xffd45c);
      const inner = new THREE.Mesh(new THREE.ConeGeometry(0.028, 0.1, 6), innerMat);
      inner.rotation.z = -Math.PI / 2;
      inner.position.set(0.2, 0.03, 0);
      g.add(inner);
      break;
    }
    case 'shield_wood': {
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.02, 12), mat(0x7a5c39));
      disc.position.y = 0.02;
      g.add(disc);
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.105, 0.012, 6, 14), mat(0x4f3420));
      rim.rotation.x = -Math.PI / 2;
      rim.position.y = 0.025;
      g.add(rim);
      const boss = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), mat(0x8b8578));
      boss.position.y = 0.04;
      boss.scale.y = 0.6;
      g.add(boss);
      break;
    }
    case 'knife_stone': {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.017, 0.16, 6), mat(0x7a5c39));
      handle.rotation.z = Math.PI / 2;
      handle.position.set(-0.08, 0.02, 0);
      g.add(handle);
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.2, 4), mat(0x8b8578));
      blade.rotation.z = -Math.PI / 2;
      blade.scale.set(1, 1, 0.4); // flatten into a blade
      blade.position.set(0.1, 0.02, 0);
      g.add(blade);
      const wrap = new THREE.Mesh(new THREE.TorusGeometry(0.02, 0.006, 5, 8), mat(0xa98653));
      wrap.rotation.y = Math.PI / 2;
      wrap.position.set(-0.02, 0.02, 0);
      g.add(wrap);
      break;
    }
  }
  return g;
}

/** Where the i-th visible unit of a stack sits (cloth-local offsets). */
export function pilePlacement(itemId: ItemId, i: number): { x: number; y: number; z: number; rotY: number } {
  if (itemId === 'log') {
    // Two neat layers of logs.
    if (i < 3) return { x: 0, y: 0, z: (i - 1) * 0.115, rotY: 0 };
    return { x: 0, y: 0.095, z: (i - 3.5) * 0.115, rotY: 0 };
  }
  if (itemId === 'stick') {
    return { x: 0, y: i * 0.012, z: (i % 3 - 1) * 0.045, rotY: (i * 37) % 10 * 0.06 - 0.3 };
  }
  // Loose cluster on a golden-angle spiral for everything else.
  const r = 0.055 * Math.sqrt(i);
  const a = i * 2.4;
  return { x: Math.cos(a) * r, y: 0, z: Math.sin(a) * r, rotY: i * 1.7 };
}
