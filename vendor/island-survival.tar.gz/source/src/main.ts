/**
 * Island Survival — bootstrap.
 * Wires core (renderer/physics/loop/input), world (terrain/water/vegetation),
 * player and UI together. Gameplay logic runs at a fixed 30 Hz on GameState
 * via actions; rendering runs at display rate (CLAUDE.md architecture).
 */
import * as THREE from 'three';
import './ui/styles.css';
import { createRenderer } from './core/renderer';
import { initPhysics, PhysicsDebugRenderer } from './core/physics';
import { GameLoop } from './core/loop';
import { Input } from './core/input';
import { ActionBus } from './core/actions';
import { createInitialState, isNight } from './core/GameState';
import { DayNightCycle } from './core/daynight';
import { Terrain } from './world/terrain';
import { Water } from './world/water';
import { Vegetation } from './world/vegetation';
import { PlayerController } from './player/controller';
import { InteractionSystem } from './player/interaction';
import { ArrowSystem } from './player/archery';
import { Viewmodel } from './player/viewmodel';
import { TorchSystem } from './player/torch';
import { QuestsPanel } from './ui/questsPanel';
import { QUESTS } from './survival/quests';
import { StatsSystem } from './survival/stats';
import { Structures } from './building/structures';
import { PlacementSystem } from './building/placement';
import { AnimalSystem } from './enemies/animals';
import { HollowSystem } from './enemies/hollows';
import { CaveMouths } from './world/caves';
import { BackpackView } from './ui/backpack';
import { ChestPanel } from './ui/chestPanel';
import { Hud } from './ui/hud';
import { Menus } from './ui/menus';
import { loadSettings, type Settings } from './core/settings';
import { STRINGS, resolveLocale, setLocale } from './i18n';
import { hasItem } from './survival/crafting';
import { BLOCK_ENERGY_COST } from './survival/items';
import { AudioSystem } from './core/audio';
import {
  AUTOSAVE_SLOT, clearActiveSlot, deleteSlot, loadActive, saveToSlot, setActiveSlot,
} from './save/persistence';

const DEFAULT_SEED = 1987; // the year the island vanished from the maps (LORE.md)

const loadingEl = document.getElementById('loading')!;
const loadingText = document.getElementById('loading-text')!;

function setLoading(text: string): void {
  loadingText.textContent = text;
}

async function main(): Promise<void> {
  const app = document.getElementById('app')!;

  // Language first: everything below reads STRINGS, and a non-English locale
  // is a lazily fetched chunk that must land before the first label renders.
  const settings = loadSettings();
  await setLocale(resolveLocale(settings.language));

  setLoading(STRINGS.loading);
  const { renderer, backend } = await createRenderer(app);

  setLoading(STRINGS.loadingPhysics);
  const { rapier, world: physicsWorld } = await initPhysics();
  physicsWorld.timestep = 1 / 30;

  setLoading(STRINGS.loadingWorld);
  // Continue from the last active save slot, or start fresh.
  const loaded = loadActive();
  const state = loaded?.state ?? createInitialState(DEFAULT_SEED);
  const isFresh = !loaded;
  const bus = new ActionBus(state);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.1, 1600);
  camera.rotation.order = 'YXZ';

  const terrain = new Terrain(state.seed);
  scene.add(terrain.mesh);
  terrain.createCollider(rapier, physicsWorld);

  const water = new Water(terrain);
  scene.add(water.group);

  const vegetation = new Vegetation(state.seed, terrain, rapier, physicsWorld);
  scene.add(vegetation.group);
  vegetation.applyRemovedIds(state.world.removedObjectIds);
  bus.subscribe((action) => {
    if (action.type === 'REMOVE_WORLD_OBJECT') vegetation.removeObject(action.objectId);
  });

  const dayNight = new DayNightCycle(scene, bus, state.seed);

  const input = new Input(renderer.domElement);
  if (isFresh) {
    const spawn = terrain.findBeachSpawn();
    state.spawn = [spawn.x, spawn.y, spawn.z];
    state.player.pos = [spawn.x, spawn.y, spawn.z];
    state.player.yaw = Math.atan2(spawn.x, spawn.z); // face the island center
  }
  const player = new PlayerController(
    rapier, physicsWorld, input, bus, new THREE.Vector3(...state.player.pos),
  );

  const structures = new Structures(rapier, physicsWorld, bus);
  scene.add(structures.group);

  const animals = new AnimalSystem(terrain, structures, bus, state.seed, rapier, physicsWorld);
  scene.add(animals.group);

  const caves = new CaveMouths(terrain, rapier, physicsWorld, state.seed);
  scene.add(caves.group);
  const hollows = new HollowSystem(
    terrain, structures, caves, bus, state.seed, rapier, physicsWorld,
  );
  scene.add(hollows.group);

  const archery = new ArrowSystem(terrain, animals, hollows);
  scene.add(archery.group);

  const interaction = new InteractionSystem(
    rapier, physicsWorld, vegetation, structures, animals, hollows, archery,
    terrain, player, input, bus,
  );
  const stats = new StatsSystem(bus, player);
  const placement = new PlacementSystem(scene, terrain, player, input, bus);

  const hud = new Hud(document.body, backend);
  const physicsDebug = new PhysicsDebugRenderer(scene, physicsWorld);
  const backpack = new BackpackView(terrain, player, input, bus);
  const chestPanel = new ChestPanel(bus);
  chestPanel.onClose = () => {
    input.requestPointerLock();
    audio.play('chest_close');
  };

  // ---- Game shell: settings + title/intro/death screens ----
  const audio = new AudioSystem(settings.volume);
  const applySettings = (s: Settings) => {
    player.sensitivity = s.sensitivity;
    camera.fov = s.fov;
    camera.updateProjectionMatrix();
    dayNight.shadowsEnabled = s.shadows;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2) * s.pixelRatio);
    audio.setVolume(s.volume);
  };
  const menus = new Menus(settings, applySettings);
  applySettings(settings);

  // ---- Quests/XP + first-person viewmodel ----
  scene.add(camera); // the held item is a child of the camera
  const viewmodel = new Viewmodel(camera);
  const torch = new TorchSystem(camera, bus);
  const questsPanel = new QuestsPanel();
  interaction.onSwing = () => {
    viewmodel.swing();
    audio.play(state.player.equippedWeapon === 'bow_wood' ? 'bow_release' : 'swing', 0.6);
  };
  animals.onKill = (kind) => {
    bus.dispatch({ type: 'RECORD_KILL', kind });
    hud.showToast(`${STRINGS.animals[kind]} — ${STRINGS.toasts.kill.toLowerCase()}`);
    audio.play('animal_die', 0.7);
  };
  hollows.onKill = () => {
    bus.dispatch({ type: 'RECORD_KILL', kind: 'hollow' });
    audio.play('hollow_dissolve');
  };
  // Quest completion & level-up toasts: compare progress after every action.
  let questCount = state.progress.completedQuests.length;
  let knownLevel = state.progress.level;
  bus.subscribe(() => {
    while (questCount < state.progress.completedQuests.length) {
      const id = state.progress.completedQuests[questCount++];
      const quest = QUESTS.find((q) => q.id === id);
      if (quest) {
        const title = STRINGS.quests.defs[quest.id].title;
        hud.showToast(`✓ ${STRINGS.quests.questDone} ${title} (+${quest.xp} XP)`);
      }
    }
    if (state.progress.level > knownLevel) {
      knownLevel = state.progress.level;
      hud.showToast(`★ ${STRINGS.quests.levelUp} ${knownLevel}!`);
    }
  });

  stats.onDeath = () => {
    // Any open modal dies with you.
    backpack.close(false);
    chestPanel.close();
    placement.cancel();
    player.teleport(new THREE.Vector3(...state.spawn));
    document.exitPointerLock();
    menus.showDeath(state.day, () => input.requestPointerLock());
  };
  interaction.onNotify = (msg) => hud.showToast(msg);
  interaction.onPlaceRequest = (kit) => placement.begin(kit);
  interaction.onOpenChest = (chestId) => {
    chestPanel.open(chestId);
    audio.play('chest_open');
  };
  animals.onPlayerHit = () => hud.damageFlash();
  hollows.onPlayerHit = () => hud.damageFlash();

  // ---- Audio pass: action-driven one-shots (SOUNDS.md ids) ----
  bus.subscribe((action, s) => {
    switch (action.type) {
      case 'ADD_ITEM': audio.play('pickup', 0.7); break;
      case 'TAKE_ITEM':
      case 'STORE_ITEM': audio.play('pickup', 0.4); break;
      case 'CRAFT': audio.play('craft_done'); break;
      case 'BUILD': audio.play('build_place'); break;
      case 'PLACE_OBJECT':
        audio.play(action.objectType === 'campfire' ? 'fire_light' : 'build_place');
        break;
      case 'TOGGLE_DOOR':
        audio.play(s.world.doorOpen[action.objectId] ? 'door_open' : 'door_close');
        break;
      case 'DEMOLISH': audio.play('demolish'); break;
      case 'REPAIR_STRUCTURE': audio.play('repair'); break;
      case 'DAMAGE_STRUCTURE':
        audio.play(
          s.world.placedObjects.some((o) => o.id === action.objectId)
            ? 'structure_hit' : 'structure_break',
        );
        break;
      case 'DAMAGE_WORLD_OBJECT':
        audio.play(action.objectId.startsWith('tree') ? 'chop_wood' : 'hit_stone');
        break;
      case 'REMOVE_WORLD_OBJECT':
        audio.play(
          action.objectId.startsWith('tree') ? 'tree_fall'
            : action.objectId.startsWith('bush') ? 'bush_rustle' : 'hit_stone',
        );
        break;
      case 'HURT_PLAYER': audio.play('hurt'); break;
      case 'RESPAWN': audio.play('death'); break;
      case 'SLEEP': audio.play('morning'); break;
      case 'MODIFY_STATS':
        // Hotbar consumption feedback (heals/food/drink come through here).
        if ((action.health ?? 0) > 10) audio.play('bandage_use');
        else if ((action.hunger ?? 0) > 5) audio.play('eat');
        else if ((action.thirst ?? 0) > 10) audio.play('drink');
        break;
    }
  });
  // Wooden shield: hold RIGHT mouse to raise. A hit from the front cone is
  // absorbed at an energy cost instead of dealing damage.
  const tryBlock = (ex: number, ez: number): boolean => {
    if (!input.rightHeld || !input.pointerLocked) return false;
    if (!hasItem(state, 'shield_wood') || state.survival.energy < BLOCK_ENERGY_COST) return false;
    const dx = ex - state.player.pos[0];
    const dz = ez - state.player.pos[2];
    const dist = Math.hypot(dx, dz) || 1;
    // Player forward is (-sin yaw, -cos yaw); only frontal (~150°) hits block.
    const facing = (-Math.sin(state.player.yaw) * dx - Math.cos(state.player.yaw) * dz) / dist;
    if (facing < 0.25) return false;
    bus.dispatch({ type: 'MODIFY_STATS', energy: -BLOCK_ENERGY_COST });
    return true;
  };
  animals.playerBlock = tryBlock;
  hollows.playerBlock = tryBlock;
  animals.onBlocked = () => {
    hud.showToast(STRINGS.toasts.blocked);
    audio.play('shield_block');
  };
  hollows.onBlocked = () => {
    hud.showToast(STRINGS.toasts.blocked);
    audio.play('shield_block');
  };
  hollows.onFirstStalk = () => {
    hud.showToast(STRINGS.toasts.stalked);
    audio.play('hollow_whisper', 0.9);
  };
  hollows.onRaidStart = () => {
    hud.showToast(STRINGS.toasts.raid);
    audio.play('raid_start');
  };
  // Bush regrowth: re-show restored vegetation when the day rolls over.
  let lastDay = state.day;
  bus.subscribe(() => {
    if (state.day !== lastDay) {
      lastDay = state.day;
      vegetation.syncRegrown(state.world.removedObjectIds);
    }
  });
  // Every item gain in the game is an ADD_ITEM — one hook feeds the pickup log.
  bus.subscribe((action) => {
    if (action.type === 'ADD_ITEM') {
      hud.pushPickup(action.itemId, STRINGS.items[action.itemId], action.count);
    }
  });
  interaction.isCaptured = () => placement.isBusy;
  interaction.onSleep = () => {
    hud.sleepFade();
    hud.showToast(STRINGS.toasts.morning);
  };

  // ---- Saves (Phase 4, localStorage stage) ----
  let playedSeconds = 0;
  let autosaveTimer = 0;
  let wasNight = false;
  let stepTimer = 0;
  hud.onSaveSlot = (slot) => {
    const ok = saveToSlot(state, slot);
    hud.showToast(ok ? STRINGS.saves.saved : STRINGS.saves.saveFailed);
    hud.refreshSaves();
  };
  hud.onLoadSlot = (slot) => {
    if (window.confirm(STRINGS.saves.confirmLoad)) {
      setActiveSlot(slot);
      window.location.reload();
    }
  };
  hud.onDeleteSlot = (slot) => {
    deleteSlot(slot);
    hud.refreshSaves();
  };
  hud.onNewGame = () => {
    if (window.confirm(STRINGS.saves.confirmNew)) {
      clearActiveSlot();
      window.location.reload();
    }
  };
  // Don't clobber the autosave slot from a fresh game the player abandoned
  // immediately — only persist once they have actually played a bit.
  window.addEventListener('beforeunload', () => {
    if (!isFresh || playedSeconds > 60) saveToSlot(state, AUTOSAVE_SLOT);
  });

  const eyePos = new THREE.Vector3();
  let menuOrbit = 0;
  const loop = new GameLoop(
    (cb) => renderer.setAnimationLoop(cb),
    (renderDt, alpha) => {
      if (menus.cinematic) {
        // Title/intro: slow cinematic orbit high above the island.
        menuOrbit += renderDt;
        const a = menuOrbit * 0.04;
        camera.position.set(Math.sin(a) * 110, 52, Math.cos(a) * 110);
        camera.lookAt(0, 10, 0);
      } else {
        if (input.pointerLocked) player.applyLook();
        camera.rotation.y = player.yaw;
        camera.rotation.x = player.pitch;
        camera.position.copy(player.getEyePosition(alpha, eyePos));
      }

      water.updateVisual(renderDt);
      dayNight.updateVisual(camera.position);
      structures.updateVisual(renderDt);
      animals.updateVisual(renderDt, camera);
      hollows.updateVisual(renderDt, camera);
      physicsDebug.update();

      // Held torch: burn fuel, drive the light, and expose it to the enemy
      // fire-fear as a mobile firelight at the player's position.
      torch.update(renderDt);
      const torchFire = torch.lit ? { x: state.player.pos[0], z: state.player.pos[2] } : null;
      animals.litTorch = torchFire;
      hollows.litTorch = torchFire;

      const nearFire =
        torch.lit ||
        structures.nearestDistance(state.player.pos[0], state.player.pos[2], ['campfire']) < 9;

      // Ambience & fire loops (idempotent per frame) + footsteps + nightfall howl.
      const night = isNight(state);
      const inGame = !menus.cinematic && !loop.paused;
      audio.setLoop('amb_waves', inGame, 0.5);
      audio.setLoop('amb_day_cicadas', inGame && !night, 0.6);
      audio.setLoop('amb_night', inGame && night, 0.7);
      audio.setLoop('campfire_loop', inGame && nearFire && !torch.lit, 0.8);
      audio.setLoop('torch_loop', inGame && torch.lit, 0.6);
      if (inGame && night && !wasNight) audio.play('wolf_howl', 0.5);
      wasNight = night;
      const moving =
        input.pointerLocked &&
        (input.isDown('KeyW') || input.isDown('KeyA') || input.isDown('KeyS') || input.isDown('KeyD'));
      stepTimer -= renderDt;
      if (moving && stepTimer <= 0) {
        audio.play('step_grass', 0.45);
        stepTimer = player.isSprinting ? 0.3 : 0.45;
      }
      if (!moving) stepTimer = Math.max(stepTimer, 0.12);
      hud.update(
        renderDt, dayNight.clockText, state, interaction.target,
        interaction.canSleep, placement.hudInfo(), nearFire,
      );

      if (input.consumeKey('F3')) physicsDebug.toggle();
      if (input.consumeKey('KeyH')) hud.toggleHelp();
      if (input.consumeKey('KeyJ')) questsPanel.toggle(state);

      viewmodel.setItem(state.player.equippedWeapon);
      viewmodel.update(
        renderDt,
        input.pointerLocked &&
          (input.isDown('KeyW') || input.isDown('KeyA') || input.isDown('KeyS') || input.isDown('KeyD')),
      );

      if (!loop.paused) {
        playedSeconds += renderDt;
        autosaveTimer += renderDt;
        if (autosaveTimer >= 120) {
          autosaveTimer = 0;
          saveToSlot(state, AUTOSAVE_SLOT);
          hud.showToast(STRINGS.saves.autoSaved);
        }
      }
      // Tab only toggles in-game or inside the Σακίδιο — not at the pause menu.
      if (input.consumeKey('Tab') && (input.pointerLocked || backpack.isOpen)) {
        backpack.toggle(camera);
        audio.play(backpack.isOpen ? 'backpack_open' : 'backpack_close', 0.7);
      }
      if (backpack.isOpen && input.consumeKey('Escape')) {
        backpack.close(true);
        audio.play('backpack_close', 0.7);
      }
      if (chestPanel.isOpen && (input.consumeKey('Escape') || input.consumeKey('KeyE'))) {
        chestPanel.close();
      }
      // The chest might be destroyed (raid) while its panel is open.
      if (
        chestPanel.isOpen &&
        chestPanel.currentChestId &&
        !state.world.placedObjects.some((o) => o.id === chestPanel.currentChestId)
      ) {
        chestPanel.close();
      }
      backpack.update(renderDt, camera);

      renderer.render(scene, camera);

      // Live renderer stats for the dev HUD (WebGPU and WebGL name them
      // differently). Read before the overlay pass resets the counters.
      const info = renderer.info as unknown as {
        render?: { drawCalls?: number; calls?: number; triangles?: number };
      };
      hud.perf = {
        calls: info.render?.drawCalls ?? info.render?.calls ?? 0,
        triangles: info.render?.triangles ?? 0,
      };

      // Σακίδιο overlay pass: same camera, depth cleared, so the cloth draws
      // over any world geometry (the classic viewmodel/UI-layer technique).
      if (backpack.isOpen) {
        renderer.autoClear = false;
        renderer.clearDepth();
        renderer.render(backpack.overlayScene, camera);
        renderer.autoClear = true;
      }
    },
  );
  loop.addSystem(player);
  loop.addSystem({ update: () => physicsWorld.step() });
  loop.addSystem(placement); // before interaction: owns E/click while placing
  loop.addSystem(interaction);
  loop.addSystem(animals);
  loop.addSystem(hollows);
  loop.addSystem(archery);
  loop.addSystem(stats);
  loop.addSystem(dayNight);

  // Pause is tied to pointer lock: Esc releases the lock → menu appears.
  // Exception: the Σακίδιο needs a free cursor while the game keeps running.
  input.onLockChange = (locked) => {
    if (!locked) {
      // Player feedback: Esc should CANCEL whatever is active — the pause
      // menu only appears when nothing was open. (Esc always drops pointer
      // lock at browser level; a click resumes, as with the Σακίδιο.)
      const hadActivity = placement.isBusy || hud.helpOpen || questsPanel.isOpen;
      if (placement.isBusy) placement.cancel();
      hud.closeHelp();
      questsPanel.close();
      if (hadActivity || backpack.isOpen || chestPanel.isOpen || menus.anyOpen) return;
    }
    loop.paused = !locked;
    hud.setPaused(!locked);
  };
  hud.onResume = () => input.requestPointerLock();
  hud.onOpenSettings = () => menus.toggleSettings();
  hud.onMainMenu = () => {
    if (!isFresh || playedSeconds > 60) saveToSlot(state, AUTOSAVE_SLOT);
    window.location.reload();
  };
  const startPlay = () => {
    menus.hideTitle();
    if (isFresh && playedSeconds < 1) menus.showIntro(() => input.requestPointerLock());
    else input.requestPointerLock();
  };
  menus.onPlay = startPlay;
  menus.onNewGame = () => {
    if (!isFresh) {
      if (!window.confirm(STRINGS.saves.confirmNew)) return;
      clearActiveSlot();
      window.location.reload();
      return;
    }
    startPlay();
  };
  renderer.domElement.addEventListener('click', () => {
    if (!input.pointerLocked && !backpack.isOpen && !chestPanel.isOpen && !menus.anyOpen) {
      input.requestPointerLock();
    }
  });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // Boot into the title screen over the cinematic island orbit.
  loop.paused = true;
  hud.setPaused(false);
  menus.showTitle(!isFresh);
  loop.start();
  loadingEl.classList.add('hidden');
  setTimeout(() => loadingEl.remove(), 600); // gone for good after the fade
}

main().catch((err) => {
  console.error('Boot failed:', err);
  setLoading(`${STRINGS.bootFailed} ${err instanceof Error ? err.message : String(err)}`);
});
