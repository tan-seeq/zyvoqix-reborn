/**
 * First-person player: Rapier kinematic character controller (capsule),
 * WASD + sprint + jump at fixed timestep, mouse look at render rate.
 * Visual camera position interpolates between the last two logic ticks.
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { Input } from '../core/input';
import type { ActionBus } from '../core/actions';
import type { System } from '../core/loop';

const WALK_SPEED = 4.4;
const RUN_SPEED = 7.2;
const JUMP_VELOCITY = 6.8;
const GRAVITY = -18;
const EYE_HEIGHT = 0.72; // offset from capsule center (center ≈ 0.95m above feet)
const CAPSULE_HALF_HEIGHT = 0.6;
const CAPSULE_RADIUS = 0.35;
const MOUSE_SENSITIVITY = 0.0022;
const MAX_PITCH = Math.PI / 2 - 0.05;

export class PlayerController implements System {
  yaw = 0;
  pitch = 0;
  /** True while actually running (moving + Shift + energy left) — drains energy. */
  isSprinting = false;
  /** Mouse-look multiplier from the settings menu. */
  sensitivity = 1;

  /** Public so raycasts (interaction) can exclude the player's own body. */
  readonly body: RAPIER.RigidBody;
  private collider: RAPIER.Collider;
  private controller: RAPIER.KinematicCharacterController;
  private velocityY = 0;
  private grounded = false;
  private prevPos = new THREE.Vector3();
  private currPos = new THREE.Vector3();

  constructor(
    rapier: typeof RAPIER,
    private world: RAPIER.World,
    private input: Input,
    private bus: ActionBus,
    spawn: THREE.Vector3,
  ) {
    this.body = world.createRigidBody(
      rapier.RigidBodyDesc.kinematicPositionBased().setTranslation(spawn.x, spawn.y, spawn.z),
    );
    this.collider = world.createCollider(
      rapier.ColliderDesc.capsule(CAPSULE_HALF_HEIGHT, CAPSULE_RADIUS),
      this.body,
    );
    this.controller = world.createCharacterController(0.06);
    this.controller.enableAutostep(0.45, 0.25, true);
    this.controller.enableSnapToGround(0.35);
    this.controller.setMaxSlopeClimbAngle((55 * Math.PI) / 180);
    this.controller.setApplyImpulsesToDynamicBodies(false);

    this.prevPos.copy(spawn);
    this.currPos.copy(spawn);
    const [x, y, z] = bus.state.player.pos;
    if (x !== 0 || y !== 5 || z !== 0) {
      // Restored state overrides the fresh spawn.
      this.teleport(new THREE.Vector3(x, y, z));
    }
    this.yaw = bus.state.player.yaw;
    this.pitch = bus.state.player.pitch;
  }

  /** Fixed-timestep movement. */
  update(dt: number): void {
    const input = this.input;
    // Movement input only while pointer-locked — with a free cursor (Σακίδιο,
    // pause) gravity still applies but keys are ignored.
    const locked = input.pointerLocked;
    let forward = 0;
    let strafe = 0;
    if (locked && input.isDown('KeyW')) forward += 1;
    if (locked && input.isDown('KeyS')) forward -= 1;
    if (locked && input.isDown('KeyD')) strafe += 1;
    if (locked && input.isDown('KeyA')) strafe -= 1;

    const wantSprint = input.isDown('ShiftLeft') || input.isDown('ShiftRight');
    const canSprint = this.bus.state.survival.energy > 2;
    const speed = wantSprint && canSprint ? RUN_SPEED : WALK_SPEED;
    const move = new THREE.Vector3(strafe, 0, -forward);
    this.isSprinting = wantSprint && canSprint && move.lengthSq() > 0;
    if (move.lengthSq() > 0) {
      move.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw).multiplyScalar(speed * dt);
    }

    if (locked && this.grounded && input.isDown('Space')) {
      this.velocityY = JUMP_VELOCITY;
      this.grounded = false;
    }
    this.velocityY += GRAVITY * dt;
    move.y = this.velocityY * dt;

    this.controller.computeColliderMovement(this.collider, { x: move.x, y: move.y, z: move.z });
    const corrected = this.controller.computedMovement();
    this.grounded = this.controller.computedGrounded();
    if (this.grounded && this.velocityY < 0) this.velocityY = 0;

    const pos = this.body.translation();
    const next = { x: pos.x + corrected.x, y: pos.y + corrected.y, z: pos.z + corrected.z };
    this.body.setNextKinematicTranslation(next);

    this.prevPos.copy(this.currPos);
    this.currPos.set(next.x, next.y, next.z);

    this.bus.dispatch({
      type: 'SET_PLAYER_TRANSFORM',
      pos: [next.x, next.y, next.z],
      yaw: this.yaw,
      pitch: this.pitch,
    });
  }

  /** Render-rate mouse look. */
  applyLook(): void {
    const { dx, dy } = this.input.consumeMouseDelta();
    const factor = MOUSE_SENSITIVITY * this.sensitivity;
    this.yaw -= dx * factor;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * factor, -MAX_PITCH, MAX_PITCH);
  }

  /** Interpolated eye position for the camera (alpha ∈ [0,1] between ticks). */
  getEyePosition(alpha: number, out: THREE.Vector3): THREE.Vector3 {
    out.lerpVectors(this.prevPos, this.currPos, alpha);
    out.y += EYE_HEIGHT;
    return out;
  }

  teleport(pos: THREE.Vector3): void {
    this.body.setTranslation({ x: pos.x, y: pos.y, z: pos.z }, true);
    this.prevPos.copy(pos);
    this.currPos.copy(pos);
    this.velocityY = 0;
  }

  /** Keep unused param warnings away — world reserved for future queries (water, raycasts). */
  get physicsWorld(): RAPIER.World {
    return this.world;
  }
}
