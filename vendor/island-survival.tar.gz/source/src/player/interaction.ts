/**
 * Interaction system (fixed timestep): raycast from the eyes into the world.
 * E or left-click harvests the targeted tree/rock/bush (multi-hit for trees
 * and rocks), or drinks from the lake when standing at its shore.
 * Number keys 1-8 consume the matching hotbar slot (berries etc).
 */
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { ActionBus } from '../core/actions';
import { isNight } from '../core/GameState';
import type { System } from '../core/loop';
import type { Input } from '../core/input';
import type { Terrain } from '../world/terrain';
import type { Vegetation, WorldObjectKind } from '../world/vegetation';
import type { Structures } from '../building/structures';
import type { AnimalSystem, AnimalKind } from '../enemies/animals';
import type { HollowSystem } from '../enemies/hollows';
import type { PlayerController } from './controller';
import {
  BARE_HANDS_DAMAGE, HARVEST_RULES, ITEM_DEFS, WEAPON_DAMAGE, isEquippable, type ItemId,
} from '../survival/items';
import { countItem, getHotbarStacks, hasItem } from '../survival/crafting';
import { meleeBonus } from '../survival/quests';
import type { ArrowSystem } from './archery';
import { STRINGS } from '../i18n';

const REACH = 3.6;
const HIT_COOLDOWN = 0.45;
const DRINK_THIRST = 30;
const RAW_WATER_SICK_CHANCE = 0.3;
const SICK_HEALTH_HIT = -8;
const SLEEP_FIRE_RADIUS = 6;

export type InteractionTarget =
  | {
      kind: 'harvest';
      objectKind: WorldObjectKind;
      objectId: string;
      hits: number;
      hp: number;
      /** Set when a required tool (e.g. axe for trees) is not in the inventory. */
      missingItem?: ItemId;
    }
  | { kind: 'drink' }
  | { kind: 'fill' }
  | { kind: 'campfire'; id: string; canBoil: boolean; canCook: boolean }
  | { kind: 'animal'; id: string; animal: AnimalKind }
  | { kind: 'hollow'; id: string }
  | { kind: 'door'; id: string; open: boolean }
  | { kind: 'chest'; id: string }
  | { kind: 'bed'; id: string }
  /** Plain structural piece (wall/foundation/roof) — repair/demolish. */
  | { kind: 'piece'; id: string; damaged: boolean }
  | null;

export class InteractionSystem implements System {
  /** What the crosshair is pointing at — read by the HUD for the prompt. */
  target: InteractionTarget = null;
  /** True when sleeping is possible right now (night + near a campfire). */
  canSleep = false;

  onNotify: ((text: string) => void) | null = null;
  onSleep: (() => void) | null = null;
  /** E on a chest opens the transfer panel (set by main). */
  onOpenChest: ((chestId: string) => void) | null = null;
  /** Fired on every melee hit / bow shot — drives the viewmodel swing. */
  onSwing: (() => void) | null = null;
  /** Hotbar key on a placeable item starts placement mode (set by main). */
  onPlaceRequest: ((kitItem: ItemId) => void) | null = null;
  /** Another system (placement) owns the E/click input right now. */
  isCaptured: (() => boolean) | null = null;

  private cooldown = 0;
  private eye = new THREE.Vector3();
  private dir = new THREE.Vector3();

  constructor(
    private rapier: typeof RAPIER,
    private physicsWorld: RAPIER.World,
    private vegetation: Vegetation,
    private structures: Structures,
    private animals: AnimalSystem,
    private hollows: HollowSystem,
    private archery: ArrowSystem,
    private terrain: Terrain,
    private player: PlayerController,
    private input: Input,
    private bus: ActionBus,
  ) {}

  update(dt: number): void {
    // Inert while the cursor is free (Σακίδιο / pause) or while the placement
    // ghost owns the input — no targeting, no hotbar, stale presses dropped.
    if (!this.input.pointerLocked || this.isCaptured?.()) {
      this.target = null;
      this.canSleep = false;
      this.input.consumeClick();
      this.input.consumeKey('KeyE');
      this.input.consumeKey('KeyR');
      this.input.consumeKey('KeyX');
      return;
    }

    this.cooldown = Math.max(0, this.cooldown - dt);
    this.target = this.findTarget();

    const [px, , pz] = this.bus.state.player.pos;
    this.canSleep =
      isNight(this.bus.state) &&
      this.structures.nearestDistance(px, pz, ['campfire', 'bed']) < SLEEP_FIRE_RADIUS;

    // Consume both every tick so neither stays queued while the other fires.
    const clickPressed = this.input.consumeClick();
    const keyPressed = this.input.consumeKey('KeyE');

    // With the bow equipped, click looses an arrow; E stays melee/interact.
    const bowEquipped = this.bus.state.player.equippedWeapon === 'bow_wood';
    if (bowEquipped && clickPressed && this.cooldown === 0) {
      if (countItem(this.bus.state, 'arrow') > 0) {
        this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: 'arrow', count: 1 });
        this.archery.shoot(this.eye.clone(), this.dir.clone());
        this.onSwing?.();
        this.cooldown = 0.75;
      } else {
        this.onNotify?.(STRINGS.toasts.noArrows);
        this.cooldown = 0.4;
      }
    }

    const pressed = keyPressed || (clickPressed && !bowEquipped);
    if (pressed && this.cooldown === 0 && this.target) {
      this.act(this.target);
    }

    if (this.canSleep && this.input.consumeKey('KeyR')) {
      this.bus.dispatch({ type: 'SLEEP' });
      this.onSleep?.();
    }

    if (this.input.consumeKey('KeyX') && this.cooldown === 0 && this.target) {
      this.demolish(this.target);
    }

    this.consumeHotbarKeys();
  }

  private demolish(target: NonNullable<InteractionTarget>): void {
    if (!('id' in target)) return;
    if (target.kind === 'chest' && (this.bus.state.world.containers[target.id]?.length ?? 0) > 0) {
      this.onNotify?.(STRINGS.toasts.chestNotEmpty);
      return;
    }
    this.bus.dispatch({ type: 'DEMOLISH', objectId: target.id });
    this.cooldown = HIT_COOLDOWN;
  }

  private act(target: NonNullable<InteractionTarget>): void {
    switch (target.kind) {
      case 'harvest':
        if (target.missingItem) return;
        this.harvest(target.objectId, target.objectKind);
        this.onSwing?.();
        break;
      case 'drink':
        this.drink();
        break;
      case 'fill':
        this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: 'container_empty', count: 1 });
        this.bus.dispatch({ type: 'ADD_ITEM', itemId: 'container_water', count: 1 });
        break;
      case 'campfire':
        if (target.canBoil) {
          this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: 'container_water', count: 1 });
          this.bus.dispatch({ type: 'ADD_ITEM', itemId: 'container_boiled', count: 1 });
          this.onNotify?.(STRINGS.toasts.boiled);
        } else if (target.canCook) {
          this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: 'meat_raw', count: 1 });
          this.bus.dispatch({ type: 'ADD_ITEM', itemId: 'meat_cooked', count: 1 });
          this.onNotify?.(STRINGS.toasts.cooked);
        } else {
          return;
        }
        break;
      case 'animal':
        this.animals.damage(target.id, this.weaponDamage());
        this.onSwing?.();
        break;
      case 'hollow': {
        const [px, , pz] = this.bus.state.player.pos;
        this.hollows.damage(target.id, this.weaponDamage(), px, pz);
        this.onSwing?.();
        break;
      }
      case 'door':
        this.bus.dispatch({ type: 'TOGGLE_DOOR', objectId: target.id });
        break;
      case 'chest':
        this.onOpenChest?.(target.id);
        break;
      case 'bed': {
        const [px, py, pz] = this.bus.state.player.pos;
        this.bus.dispatch({ type: 'SET_SPAWN', pos: [px, py, pz] });
        this.onNotify?.(STRINGS.toasts.spawnSet);
        break;
      }
      case 'piece':
        if (!target.damaged) return; // X demolishes; E only repairs
        if (countItem(this.bus.state, 'log') < 1) {
          this.onNotify?.(`${STRINGS.prompts.need} ${STRINGS.items.log}`);
          return;
        }
        this.bus.dispatch({ type: 'REPAIR_STRUCTURE', objectId: target.id });
        this.onNotify?.(STRINGS.toasts.repaired);
        break;
    }
    this.cooldown = HIT_COOLDOWN;
  }

  private findTarget(): InteractionTarget {
    this.player.getEyePosition(1, this.eye);
    this.dir.set(
      -Math.sin(this.player.yaw) * Math.cos(this.player.pitch),
      Math.sin(this.player.pitch),
      -Math.cos(this.player.yaw) * Math.cos(this.player.pitch),
    );

    const ray = new this.rapier.Ray(this.eye, this.dir);
    const hit = this.physicsWorld.castRay(
      ray, REACH, true, undefined, undefined, undefined, this.player.body,
    );
    if (hit) {
      const obj = this.vegetation.objectByColliderHandle(hit.collider.handle);
      if (obj && !obj.removed) {
        const rule = HARVEST_RULES[obj.kind];
        // The required tool must be HELD (equipped), not just in the bag.
        const missing =
          rule.requiresItem && this.bus.state.player.equippedWeapon !== rule.requiresItem
            ? rule.requiresItem
            : undefined;
        return {
          kind: 'harvest',
          objectKind: obj.kind,
          objectId: obj.id,
          hits: this.bus.state.world.objectDamage[obj.id] ?? 0,
          hp: rule.hp,
          missingItem: missing,
        };
      }
      const structureId = this.structures.structureIdByColliderHandle(hit.collider.handle);
      if (structureId) {
        switch (this.structures.typeOf(structureId)) {
          case 'campfire':
            return {
              kind: 'campfire',
              id: structureId,
              canBoil: hasItem(this.bus.state, 'container_water'),
              canCook: hasItem(this.bus.state, 'meat_raw'),
            };
          case 'wall_door':
            return { kind: 'door', id: structureId, open: !!this.bus.state.world.doorOpen[structureId] };
          case 'chest':
            return { kind: 'chest', id: structureId };
          case 'bed':
            return { kind: 'bed', id: structureId };
          default:
            return {
              kind: 'piece',
              id: structureId,
              damaged: (this.bus.state.world.structureDamage[structureId] ?? 0) > 0,
            };
        }
      }
    }

    // No static object in reach — a Hollow One or animal in the aim cone?
    const hollow = this.hollows.findTarget(this.eye, this.dir);
    if (hollow) return { kind: 'hollow', id: hollow.id };
    const animal = this.animals.findTarget(this.eye, this.dir);
    if (animal) return { kind: 'animal', id: animal.id, animal: animal.kind };

    // Drinkable fresh water nearby? (Sea is salt water.)
    const [px, , pz] = this.bus.state.player.pos;
    const lakeDist = Math.hypot(px - this.terrain.lakeCenter.x, pz - this.terrain.lakeCenter.y);
    if (lakeDist < this.terrain.lakeRadius + 2.5 && this.player.pitch < -0.25) {
      // An empty container takes priority over risky hand-drinking.
      if (hasItem(this.bus.state, 'container_empty')) return { kind: 'fill' };
      return { kind: 'drink' };
    }
    return null;
  }

  private harvest(objectId: string, kind: WorldObjectKind): void {
    this.bus.dispatch({ type: 'DAMAGE_WORLD_OBJECT', objectId, damage: 1 });
    const rule = HARVEST_RULES[kind];
    if ((this.bus.state.world.objectDamage[objectId] ?? 0) >= rule.hp) {
      for (const drop of rule.loot) {
        this.bus.dispatch({ type: 'ADD_ITEM', itemId: drop.itemId, count: drop.count });
      }
      this.bus.dispatch({ type: 'REMOVE_WORLD_OBJECT', objectId });
    }
  }

  private weaponDamage(): number {
    // You hit with what you HOLD: only the equipped weapon counts (bare
    // hands otherwise), scaled by the level perk.
    const equipped = this.bus.state.player.equippedWeapon;
    const w =
      equipped && hasItem(this.bus.state, equipped)
        ? WEAPON_DAMAGE.find((e) => e.itemId === equipped)
        : undefined;
    const base = w ? w.damage : BARE_HANDS_DAMAGE;
    return Math.round(base * meleeBonus(this.bus.state.progress.level));
  }

  private drink(): void {
    // Raw lake water quenches, but bare-hands drinking risks sickness —
    // the boiled-container route is the safe one. (Client-side roll for now;
    // an authoritative server would own this in co-op.)
    this.bus.dispatch({ type: 'MODIFY_STATS', thirst: DRINK_THIRST });
    if (Math.random() < RAW_WATER_SICK_CHANCE) {
      this.bus.dispatch({ type: 'MODIFY_STATS', health: SICK_HEALTH_HIT });
      this.onNotify?.(STRINGS.toasts.sick);
    }
  }

  private consumeHotbarKeys(): void {
    const hotbar = getHotbarStacks(this.bus.state);
    for (let i = 0; i < 8; i++) {
      if (!this.input.consumeKey(`Digit${i + 1}`)) continue;
      const slot = hotbar[i];
      if (!slot) continue;
      const def = ITEM_DEFS[slot.itemId];
      if (def.placeable) {
        this.onPlaceRequest?.(slot.itemId);
        continue;
      }
      if (isEquippable(slot.itemId)) {
        // Toggle equip, with confirmation of what's now in hand.
        const next = this.bus.state.player.equippedWeapon === slot.itemId ? null : slot.itemId;
        this.bus.dispatch({ type: 'EQUIP', itemId: next });
        this.onNotify?.(
          next ? `${STRINGS.toasts.holding} ${STRINGS.items[next]}` : STRINGS.toasts.handsEmpty,
        );
        continue;
      }
      const c = def.consumable;
      if (!c) continue;
      this.bus.dispatch({
        type: 'MODIFY_STATS',
        hunger: c.hunger ?? 0,
        thirst: c.thirst ?? 0,
        energy: c.energy ?? 0,
        health: c.health ?? 0,
      });
      this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: slot.itemId, count: 1 });
      if (c.returnsItem) this.bus.dispatch({ type: 'ADD_ITEM', itemId: c.returnsItem, count: 1 });
      if (c.sickChance && Math.random() < c.sickChance) {
        this.bus.dispatch({ type: 'MODIFY_STATS', health: SICK_HEALTH_HIT });
        this.onNotify?.(STRINGS.toasts.sick);
      }
    }
  }
}
