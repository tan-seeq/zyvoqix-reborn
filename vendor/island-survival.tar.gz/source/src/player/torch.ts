/**
 * Held torch: a warm point light that rides the camera while a torch is the
 * equipped item, plus fuel burn-down. While lit it also counts as a mobile
 * fire source — the enemy systems read `lit` and treat the player's position
 * as firelight (wolves and Hollow Ones keep their distance, and it lets you
 * carry that safety into the dark of the caves).
 *
 * v1 keeps fuel as runtime state (resets when you re-light) rather than
 * per-item durability in the save — a torch simply burns ~2 minutes, then the
 * next one in the bag lights automatically until you run out.
 */
import * as THREE from 'three';
import type { ActionBus } from '../core/actions';
import { countItem } from '../survival/crafting';

const TORCH_FUEL = 120; // seconds one torch burns

export class TorchSystem {
  /** True while a lit torch is in hand — read by main + enemy fire-fear. */
  lit = false;

  private light = new THREE.PointLight(0xffa64d, 0, 12, 1.8);
  private fuel = TORCH_FUEL;
  private time = 0;

  constructor(camera: THREE.Camera, private bus: ActionBus) {
    this.light.position.set(0.4, -0.2, -0.5); // by the held torch, lower-right
    camera.add(this.light);
  }

  /** Per render frame. */
  update(dt: number): void {
    const holding = this.bus.state.player.equippedWeapon === 'torch';

    if (holding && countItem(this.bus.state, 'torch') > 0) {
      this.fuel -= dt;
      if (this.fuel <= 0) {
        // Current torch burns away; light the next one, or unequip if last.
        this.bus.dispatch({ type: 'REMOVE_ITEM', itemId: 'torch', count: 1 });
        this.fuel = TORCH_FUEL;
        if (countItem(this.bus.state, 'torch') === 0) {
          this.bus.dispatch({ type: 'EQUIP', itemId: null });
        }
      }
    } else {
      this.fuel = TORCH_FUEL; // full again next time one is lit
    }

    this.lit =
      this.bus.state.player.equippedWeapon === 'torch' &&
      countItem(this.bus.state, 'torch') > 0;

    this.time += dt;
    if (this.lit) {
      const flicker = Math.sin(this.time * 11) * 0.5 + Math.sin(this.time * 27) * 0.5;
      this.light.intensity = 9 + flicker * 2;
    } else {
      this.light.intensity = 0;
    }
  }
}
