/**
 * Bow & arrows (PLAN Phase 5β): simple ballistic projectiles at fixed
 * timestep — gravity arc, hit tests against animals/hollows, stick into the
 * terrain briefly on a miss. No arrow recovery yet (Phase 7 note).
 */
import * as THREE from 'three';
import type { System } from '../core/loop';
import type { Terrain } from '../world/terrain';
import type { AnimalSystem } from '../enemies/animals';
import type { HollowSystem } from '../enemies/hollows';
import { ARROW_SPEED, BOW_DAMAGE } from '../survival/items';

const GRAVITY = 6.5; // gentler than real for a pleasant arc
const MAX_LIFE = 3;
const STUCK_SECONDS = 6;

interface Arrow {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  mesh: THREE.Group;
  life: number;
  stuckTimer: number;
}

// Every arrow is identical, so share one geometry+material set for all of
// them (baked into +Z orientation). Bounded GPU footprint regardless of how
// many arrows fly, and nothing to dispose when one expires.
const ARROW_SHAFT_GEO = new THREE.CylinderGeometry(0.012, 0.012, 0.6, 4).rotateX(Math.PI / 2);
const ARROW_TIP_GEO = new THREE.ConeGeometry(0.025, 0.08, 4).rotateX(Math.PI / 2).translate(0, 0, 0.34);
const ARROW_SHAFT_MAT = new THREE.MeshStandardMaterial({ color: 0x8a6a42, roughness: 1 });
const ARROW_TIP_MAT = new THREE.MeshStandardMaterial({ color: 0x8b8578, roughness: 0.8 });

function buildArrowMesh(): THREE.Group {
  const g = new THREE.Group();
  g.add(new THREE.Mesh(ARROW_SHAFT_GEO, ARROW_SHAFT_MAT), new THREE.Mesh(ARROW_TIP_GEO, ARROW_TIP_MAT));
  return g;
}

export class ArrowSystem implements System {
  readonly group = new THREE.Group();
  private arrows: Arrow[] = [];
  private forward = new THREE.Vector3(0, 0, 1);

  constructor(
    private terrain: Terrain,
    private animals: AnimalSystem,
    private hollows: HollowSystem,
  ) {}

  shoot(origin: THREE.Vector3, dir: THREE.Vector3): void {
    const mesh = buildArrowMesh();
    const arrow: Arrow = {
      pos: origin.clone().addScaledVector(dir, 0.5),
      vel: dir.clone().multiplyScalar(ARROW_SPEED),
      mesh,
      life: MAX_LIFE,
      stuckTimer: 0,
    };
    mesh.position.copy(arrow.pos);
    this.group.add(mesh);
    this.arrows.push(arrow);
  }

  update(dt: number): void {
    for (let i = this.arrows.length - 1; i >= 0; i--) {
      const arrow = this.arrows[i];

      if (arrow.stuckTimer > 0) {
        arrow.stuckTimer -= dt;
        if (arrow.stuckTimer <= 0) this.remove(i);
        continue;
      }

      arrow.vel.y -= GRAVITY * dt;
      arrow.pos.addScaledVector(arrow.vel, dt);
      arrow.life -= dt;
      arrow.mesh.position.copy(arrow.pos);
      arrow.mesh.quaternion.setFromUnitVectors(this.forward, arrow.vel.clone().normalize());

      const hollowHit = this.hollows.hitTest(arrow.pos, 0.8);
      if (hollowHit) {
        this.hollows.damage(hollowHit, BOW_DAMAGE, arrow.pos.x, arrow.pos.z);
        this.remove(i);
        continue;
      }
      const animalHit = this.animals.hitTest(arrow.pos, 0.7);
      if (animalHit) {
        this.animals.damage(animalHit, BOW_DAMAGE);
        this.remove(i);
        continue;
      }

      if (arrow.pos.y <= this.terrain.heightAt(arrow.pos.x, arrow.pos.z) + 0.03) {
        arrow.stuckTimer = STUCK_SECONDS; // stays planted in the ground a while
        continue;
      }
      if (arrow.life <= 0) this.remove(i);
    }
  }

  private remove(index: number): void {
    this.group.remove(this.arrows[index].mesh);
    this.arrows.splice(index, 1);
  }
}
