/**
 * First-person held-item view: the equipped weapon/tool rendered as a child
 * of the camera (lower right), with walk bob and a swing animation on every
 * hit/shot. Reuses the Σακίδιο item builders so the thing in your hand is
 * the same object you see on the cloth. (Phase 7's full version adds arms
 * and per-weapon poses; this is the playable v1.)
 */
import * as THREE from 'three';
import { buildItemUnit } from '../ui/itemMeshes';
import { disposeObject3D } from '../core/three-utils';
import type { ItemId } from '../survival/items';

const REST_POS = new THREE.Vector3(0.38, -0.34, -0.62);
const SWING_SECONDS = 0.28;

export class Viewmodel {
  private holder = new THREE.Group();
  private root = new THREE.Group();
  private current: ItemId | null = null;
  private swingT = 1; // >= 1 means idle
  private bobPhase = 0;

  constructor(camera: THREE.Camera) {
    this.root.position.copy(REST_POS);
    this.root.add(this.holder);
    camera.add(this.root);
  }

  setItem(itemId: ItemId | null): void {
    if (itemId === this.current) return;
    this.current = itemId;
    // Free the previously held item before swapping (fires only on real
    // weapon changes since we early-return above when unchanged).
    for (const child of this.holder.children) disposeObject3D(child);
    this.holder.clear();
    if (!itemId) return;
    const mesh = buildItemUnit(itemId);
    mesh.scale.setScalar(1.7);
    // Grip orientation: handle toward the hand, head up-forward.
    mesh.rotation.set(0.15, Math.PI / 2 + 0.35, 0.1);
    mesh.traverse((n) => {
      n.frustumCulled = false;
      if (n instanceof THREE.Mesh) n.castShadow = false;
    });
    this.holder.add(mesh);
  }

  swing(): void {
    this.swingT = 0;
  }

  update(dt: number, moving: boolean): void {
    if (this.swingT < 1) {
      this.swingT = Math.min(1, this.swingT + dt / SWING_SECONDS);
      const k = Math.sin(this.swingT * Math.PI);
      this.holder.rotation.x = -k * 1.25;
      this.holder.position.z = -k * 0.28;
      this.holder.position.y = -k * 0.08;
    } else {
      // ease back to rest
      this.holder.rotation.x *= 0.75;
      this.holder.position.multiplyScalar(0.75);
    }
    this.bobPhase += dt * (moving ? 9 : 2.2);
    this.root.position.y = REST_POS.y + Math.sin(this.bobPhase) * (moving ? 0.016 : 0.005);
    this.root.position.x = REST_POS.x + Math.cos(this.bobPhase * 0.5) * (moving ? 0.008 : 0.002);
  }
}
