/**
 * Item definitions (data only — display names live in the locale files, i18n/).
 * Phase 2 v1: raw materials + berries. Tools arrive with crafting.
 */
export type ItemId =
  | 'log' | 'stick' | 'stone' | 'berries' | 'fiber' | 'rope' | 'axe_stone'
  | 'campfire_kit' | 'container_empty' | 'container_water' | 'container_boiled'
  | 'meat_raw' | 'meat_cooked' | 'hide' | 'club_wood' | 'bow_wood' | 'arrow'
  | 'bandage' | 'hide_vest' | 'hide_helmet' | 'knife_stone' | 'torch' | 'shield_wood';

export interface ItemDef {
  id: ItemId;
  /** Max units per inventory slot. */
  stack: number;
  /** If set, the item can be consumed from the hotbar (number keys). */
  consumable?: {
    hunger?: number;
    thirst?: number;
    energy?: number;
    /** Restores health (bandage). */
    health?: number;
    /** Probability of getting sick (health hit) — raw lake water. */
    sickChance?: number;
    /** Item left behind after consuming (drained container). */
    returnsItem?: ItemId;
  };
  /** Hotbar key starts placement mode for this structure instead of consuming. */
  placeable?: 'campfire';
  /**
   * Passive armor: incoming enemy damage is multiplied by this factor while
   * the item is carried (0.75 = −25%). Factors of different pieces stack
   * multiplicatively. Not equipped explicitly yet — carrying = wearing (v1).
   */
  armor?: { damageFactor: number };
}

// `stack` is the TOTAL carry cap per item type — each type occupies exactly
// one inventory slot (one pile on the Σακίδιο, one hotbar entry).
export const ITEM_DEFS: Record<ItemId, ItemDef> = {
  log: { id: 'log', stack: 30 },
  stick: { id: 'stick', stack: 60 },
  stone: { id: 'stone', stack: 60 },
  berries: { id: 'berries', stack: 20, consumable: { hunger: 14, thirst: 3 } },
  fiber: { id: 'fiber', stack: 60 },
  rope: { id: 'rope', stack: 20 },
  axe_stone: { id: 'axe_stone', stack: 1 },
  campfire_kit: { id: 'campfire_kit', stack: 3, placeable: 'campfire' },
  container_empty: { id: 'container_empty', stack: 3 },
  container_water: {
    id: 'container_water',
    stack: 3,
    consumable: { thirst: 35, sickChance: 0.3, returnsItem: 'container_empty' },
  },
  container_boiled: {
    id: 'container_boiled',
    stack: 3,
    consumable: { thirst: 65, returnsItem: 'container_empty' },
  },
  meat_raw: { id: 'meat_raw', stack: 12, consumable: { hunger: 10, sickChance: 0.35 } },
  meat_cooked: { id: 'meat_cooked', stack: 12, consumable: { hunger: 38 } },
  hide: { id: 'hide', stack: 20 },
  club_wood: { id: 'club_wood', stack: 1 },
  bow_wood: { id: 'bow_wood', stack: 1 },
  arrow: { id: 'arrow', stack: 30 },
  bandage: { id: 'bandage', stack: 5, consumable: { health: 35 } },
  hide_vest: { id: 'hide_vest', stack: 1, armor: { damageFactor: 0.75 } },
  hide_helmet: { id: 'hide_helmet', stack: 1, armor: { damageFactor: 0.9 } },
  knife_stone: { id: 'knife_stone', stack: 1 },
  torch: { id: 'torch', stack: 5 },
  shield_wood: { id: 'shield_wood', stack: 1 },
};

/** Energy spent to absorb one enemy hit with the wooden shield raised. */
export const BLOCK_ENERGY_COST = 6;

/** Weapon whose skinning bonus doubles hide dropped from a kill. */
export const SKINNING_KNIFE: ItemId = 'knife_stone';

/**
 * Combined incoming-damage multiplier from all armor pieces carried (each
 * distinct piece counts once; multiples don't stack extra). 1 = no armor.
 */
export function armorDamageFactor(inventory: Array<{ itemId: ItemId; count: number }>): number {
  const worn = new Set<ItemId>();
  for (const slot of inventory) {
    if (slot.count > 0 && ITEM_DEFS[slot.itemId].armor) worn.add(slot.itemId);
  }
  let factor = 1;
  for (const id of worn) factor *= ITEM_DEFS[id].armor!.damageFactor;
  return factor;
}

export const BOW_DAMAGE = 26;
export const ARROW_SPEED = 30;

/** Melee damage by best weapon in inventory (checked in this order). */
export const WEAPON_DAMAGE: Array<{ itemId: ItemId; damage: number }> = [
  { itemId: 'axe_stone', damage: 30 },
  { itemId: 'club_wood', damage: 20 },
  { itemId: 'knife_stone', damage: 14 },
];
export const BARE_HANDS_DAMAGE = 8;

/** Equippable weapons: melee list + the bow (ranged, handled separately). */
export function isWeapon(itemId: ItemId): boolean {
  return itemId === 'bow_wood' || WEAPON_DAMAGE.some((w) => w.itemId === itemId);
}

/** Held in-hand via the hotbar: weapons + the torch (light tool, no combat role). */
export function isEquippable(itemId: ItemId): boolean {
  return isWeapon(itemId) || itemId === 'torch';
}

/**
 * Only usable items occupy hotbar slots: consumables, placeables, weapons.
 * Raw materials (logs, stones, fiber, hide...) live in the bag alone.
 */
export function isHotbarItem(itemId: ItemId): boolean {
  const def = ITEM_DEFS[itemId];
  return !!def.consumable || !!def.placeable || isEquippable(itemId);
}

export interface HarvestRule {
  /** Hits needed before the object breaks and drops loot. */
  hp: number;
  loot: Array<{ itemId: ItemId; count: number }>;
  /** Tool that must be somewhere in the inventory to harvest this. */
  requiresItem?: ItemId;
}

/** What each world-object kind yields when harvested (LORE/PLAN Phase 2). */
export const HARVEST_RULES: Record<'tree' | 'rock' | 'bush', HarvestRule> = {
  tree: {
    hp: 4,
    loot: [{ itemId: 'log', count: 4 }, { itemId: 'stick', count: 2 }],
    requiresItem: 'axe_stone',
  },
  rock: { hp: 3, loot: [{ itemId: 'stone', count: 2 }] },
  bush: {
    hp: 1,
    loot: [{ itemId: 'stick', count: 2 }, { itemId: 'berries', count: 2 }, { itemId: 'fiber', count: 2 }],
  },
};
