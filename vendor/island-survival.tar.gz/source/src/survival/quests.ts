/**
 * Quests & XP (PLAN Phase 6.5): objective definitions with progress counters
 * that the reducer fills from ordinary actions — chop/build/craft/kill/survive.
 * Completing a quest awards XP; levels grant small permanent perks (melee
 * damage, sprint stamina). Counters, XP and level all live in GameState, so
 * progress saves and syncs like everything else.
 */

/** What a quest counts. Filled by trackProgress() in the reducer. */
export type CounterId =
  | 'tree' | 'rock' | 'bush'
  | 'build' | 'craft' | 'cook' | 'campfire'
  | 'items'
  | 'kill_any' | 'kill_wolf' | 'kill_hollow'
  | 'day';

/**
 * Stable save-facing quest ids. Titles and descriptions are display data and
 * live in the locale files (`i18n/en.json` → `quests.defs`), keyed by these
 * ids — the completeness guard in `i18n/index.ts` fails the build if one is
 * added here without a name.
 */
export type QuestId =
  | 'lumber1' | 'lumber2' | 'lumber3'
  | 'miner1' | 'gather1' | 'collect1'
  | 'builder1' | 'crafter1' | 'cook1' | 'fire1'
  | 'hunter1' | 'wolf1' | 'hollow1'
  | 'survive1' | 'survive2' | 'survive3';

export interface QuestDef {
  id: QuestId;
  counter: CounterId;
  target: number;
  xp: number;
}

export const QUESTS: QuestDef[] = [
  { id: 'lumber1', counter: 'tree', target: 10, xp: 50 },
  { id: 'lumber2', counter: 'tree', target: 50, xp: 150 },
  { id: 'lumber3', counter: 'tree', target: 100, xp: 300 },
  { id: 'miner1', counter: 'rock', target: 25, xp: 80 },
  { id: 'gather1', counter: 'bush', target: 30, xp: 80 },
  { id: 'collect1', counter: 'items', target: 200, xp: 100 },
  { id: 'builder1', counter: 'build', target: 10, xp: 80 },
  { id: 'crafter1', counter: 'craft', target: 10, xp: 60 },
  { id: 'cook1', counter: 'cook', target: 5, xp: 50 },
  { id: 'fire1', counter: 'campfire', target: 3, xp: 40 },
  { id: 'hunter1', counter: 'kill_any', target: 5, xp: 60 },
  { id: 'wolf1', counter: 'kill_wolf', target: 3, xp: 80 },
  { id: 'hollow1', counter: 'kill_hollow', target: 1, xp: 100 },
  { id: 'survive1', counter: 'day', target: 3, xp: 60 },
  { id: 'survive2', counter: 'day', target: 7, xp: 150 },
  { id: 'survive3', counter: 'day', target: 15, xp: 300 },
];

export const MAX_LEVEL = 10;

/** XP needed to advance FROM the given level to the next. */
export function xpForNextLevel(level: number): number {
  return 100 + (level - 1) * 75;
}

/** Melee damage multiplier from level perks (+5% per level). */
export function meleeBonus(level: number): number {
  return 1 + 0.05 * (level - 1);
}

/** Sprint energy drain multiplier from level perks (−4% per level). */
export function sprintDrainFactor(level: number): number {
  return Math.max(0.6, 1 - 0.04 * (level - 1));
}
