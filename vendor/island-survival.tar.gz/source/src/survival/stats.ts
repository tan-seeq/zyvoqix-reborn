/**
 * Survival stats system: ticks hunger/thirst/energy decay through the action
 * bus at fixed timestep and triggers respawn on death.
 */
import type { ActionBus } from '../core/actions';
import type { System } from '../core/loop';
import type { PlayerController } from '../player/controller';

export class StatsSystem implements System {
  /** Set by main when a respawn happens so systems can react (teleport etc). */
  onDeath: (() => void) | null = null;

  constructor(
    private bus: ActionBus,
    private player: PlayerController,
  ) {}

  update(dt: number): void {
    this.bus.dispatch({ type: 'STATS_TICK', dt, sprinting: this.player.isSprinting });
    if (this.bus.state.survival.health <= 0) {
      this.bus.dispatch({ type: 'RESPAWN' });
      this.onDeath?.();
    }
  }
}
