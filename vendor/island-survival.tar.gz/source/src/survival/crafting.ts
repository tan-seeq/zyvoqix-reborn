/**
 * Recipe definitions + matching for the Σακίδιο crafting cloth.
 * A recipe crafts when the items placed in the cloth's center form EXACTLY
 * its ingredient multiset. Partial (subset) placements produce hints.
 */
import type { GameState, InventorySlot } from '../core/GameState';
import { HOTBAR_SLOTS } from '../core/GameState';
import { isHotbarItem, type ItemId } from './items';

export interface Recipe {
  id: string;
  ingredients: Array<{ itemId: ItemId; count: number }>;
  result: { itemId: ItemId; count: number };
}

/** v1 recipes (PLAN Phase 2). Δάδα/ρόπαλο/ψητό follow with combat & hunting. */
export const RECIPES: Recipe[] = [
  {
    id: 'rope',
    ingredients: [{ itemId: 'fiber', count: 3 }],
    result: { itemId: 'rope', count: 1 },
  },
  {
    id: 'axe_stone',
    ingredients: [
      { itemId: 'stick', count: 1 },
      { itemId: 'stone', count: 1 },
      { itemId: 'rope', count: 1 },
    ],
    result: { itemId: 'axe_stone', count: 1 },
  },
  {
    id: 'campfire_kit',
    ingredients: [
      { itemId: 'stick', count: 3 },
      { itemId: 'stone', count: 3 },
    ],
    result: { itemId: 'campfire_kit', count: 1 },
  },
  {
    id: 'container',
    ingredients: [
      { itemId: 'log', count: 1 },
      { itemId: 'rope', count: 1 },
    ],
    result: { itemId: 'container_empty', count: 1 },
  },
  {
    id: 'club_wood',
    ingredients: [
      { itemId: 'log', count: 1 },
      { itemId: 'fiber', count: 3 },
    ],
    result: { itemId: 'club_wood', count: 1 },
  },
  {
    id: 'bow_wood',
    ingredients: [
      { itemId: 'stick', count: 2 },
      { itemId: 'rope', count: 2 },
    ],
    result: { itemId: 'bow_wood', count: 1 },
  },
  {
    id: 'arrows',
    ingredients: [
      { itemId: 'stick', count: 1 },
      { itemId: 'stone', count: 1 },
      { itemId: 'fiber', count: 1 },
    ],
    result: { itemId: 'arrow', count: 3 },
  },
  {
    id: 'bandage',
    ingredients: [
      { itemId: 'fiber', count: 3 },
      { itemId: 'hide', count: 1 },
    ],
    result: { itemId: 'bandage', count: 1 },
  },
  {
    id: 'hide_vest',
    ingredients: [
      { itemId: 'hide', count: 4 },
      { itemId: 'rope', count: 2 },
    ],
    result: { itemId: 'hide_vest', count: 1 },
  },
  {
    id: 'hide_helmet',
    ingredients: [
      { itemId: 'hide', count: 2 },
      { itemId: 'rope', count: 1 },
    ],
    result: { itemId: 'hide_helmet', count: 1 },
  },
  {
    id: 'knife_stone',
    ingredients: [
      { itemId: 'stick', count: 1 },
      { itemId: 'stone', count: 2 },
    ],
    result: { itemId: 'knife_stone', count: 1 },
  },
  {
    id: 'torch',
    ingredients: [
      { itemId: 'stick', count: 1 },
      { itemId: 'fiber', count: 2 },
    ],
    result: { itemId: 'torch', count: 1 },
  },
  {
    id: 'shield_wood',
    ingredients: [
      { itemId: 'log', count: 2 },
      { itemId: 'hide', count: 1 },
    ],
    result: { itemId: 'shield_wood', count: 1 },
  },
];

function toCounts(items: ItemId[]): Map<ItemId, number> {
  const counts = new Map<ItemId, number>();
  for (const id of items) counts.set(id, (counts.get(id) ?? 0) + 1);
  return counts;
}

/** Exact multiset match → the recipe that crafts, else null. */
export function matchRecipe(centerItems: ItemId[]): Recipe | null {
  const counts = toCounts(centerItems);
  outer: for (const recipe of RECIPES) {
    if (recipe.ingredients.length !== counts.size) continue;
    for (const ing of recipe.ingredients) {
      if (counts.get(ing.itemId) !== ing.count) continue outer;
    }
    return recipe;
  }
  return null;
}

/**
 * Recipe hint (PLAN: quality-of-life the Forest lacked): if the center items
 * are a proper subset of some recipe, return what is still missing.
 */
export function findHint(centerItems: ItemId[]): { recipe: Recipe; missing: ItemId[] } | null {
  if (centerItems.length === 0) return null;
  const counts = toCounts(centerItems);
  outer: for (const recipe of RECIPES) {
    const missing: ItemId[] = [];
    for (const [id, n] of counts) {
      const ing = recipe.ingredients.find((i) => i.itemId === id);
      if (!ing || n > ing.count) continue outer;
    }
    for (const ing of recipe.ingredients) {
      const have = counts.get(ing.itemId) ?? 0;
      for (let i = have; i < ing.count; i++) missing.push(ing.itemId);
    }
    if (missing.length > 0) return { recipe, missing };
  }
  return null;
}

/** The hotbar view: first usable stacks from the bag, in bag order. */
export function getHotbarStacks(state: GameState): InventorySlot[] {
  return state.inventory.filter((slot) => isHotbarItem(slot.itemId)).slice(0, HOTBAR_SLOTS);
}

export function canAfford(state: GameState, cost: Array<{ itemId: ItemId; count: number }>): boolean {
  return cost.every((c) => countItem(state, c.itemId) >= c.count);
}

export function countItem(state: GameState, itemId: ItemId): number {
  return state.inventory.reduce((sum, slot) => (slot.itemId === itemId ? sum + slot.count : sum), 0);
}

export function hasItem(state: GameState, itemId: ItemId): boolean {
  return countItem(state, itemId) > 0;
}
