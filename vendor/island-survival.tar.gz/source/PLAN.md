# PLAN.md — Roadmap ανά φάση

Κάθε φάση τελειώνει με κάτι **παίξιμο**. Τσεκάρουμε τα boxes καθώς ολοκληρώνονται.

---

## Φάση 0 — Setup ✅ (μερικώς έτοιμο στο scaffold)
- [x] Vite + TypeScript project
- [x] Minimal Three.js scene (έδαφος, φως, ουρανός) — `src/main.ts`
- [x] Renderer upgrade σε WebGPURenderer με WebGL fallback — `src/core/renderer.ts` (το backend φαίνεται στο dev HUD)
- [x] Rapier init (async WASM load) + debug wireframe toggle (F3) — `src/core/physics.ts`
- [x] Asset loader utility (GLTFLoader + DRACOLoader, με loading screen) — `src/core/assets.ts` (έτοιμο, αχρησιμοποίητο μέχρι να μπουν GLB)
- [ ] Κατέβασμα asset packs (βλ. §Assets παρακάτω) στο `public/assets/` — προς το παρόν procedural low-poly placeholders

## Φάση 1 — Ο κόσμος
Στόχος: περπατάς σε ένα όμορφο νησί με μέρα/νύχτα.
- [x] **Terrain**: heightmap από simplex noise (~600x600m νησί), χρωματισμός ανά ύψος (άμμος→γρασίδι→βράχος), Rapier collider — `src/world/terrain.ts` (trimesh αντί heightfield: ταυτίζεται 1:1 με το render mesh· + λίμνη + κεντρικό ύψωμα για τον μελλοντικό Σταθμό ΙΡΙΣ)
- [x] **First-person controller**: WASD + mouse look (Pointer Lock), Rapier kinematic character controller, τρέξιμο (Shift), άλμα, βαρύτητα — `src/player/controller.ts` (fixed 30Hz logic + interpolated camera)
- [x] **Νερό**: θάλασσα γύρω από το νησί (animated plane) + 1 λίμνη στο εσωτερικό — `src/world/water.ts` (ποτάμι: αργότερα αν χρειαστεί)
- [x] **Βλάστηση**: ~1100 δέντρα (πεύκα/ελιές) + 320 πέτρες + 380 θάμνοι με InstancedMesh, seed-based, κάθε instance με σταθερό ID (`tree_0412`) + collider — `src/world/vegetation.ts`
- [x] **Day/night cycle**: 20 λεπτά = 1 μέρα. Ήλιος/φεγγάρι, χρώματα ουρανού/fog, αστέρια τη νύχτα, ρολόι στο HUD — `src/core/daynight.ts`
- [x] **Ατμόσφαιρα**: fog ✅ + **audio pass ✅** — `src/core/audio.ts`: WebAudio με ΠΡΟΣΩΡΙΝΟΥΣ procedural ήχους ανά id του SOUNDS.md (κύματα/τζιτζίκια/γρύλοι loops, βήματα, κόψιμο, craft, χτίσιμο, πόρτες, μάχη, ασπίδα, Κούφιοι, raid sting, ουρλιαχτό λύκου στη νύχτωση, φωτιά/δάδα crackle). Αρχείο `public/assets/audio/<id>.ogg` (+`_1..3` variants) αντικαθιστά ΑΥΤΟΜΑΤΑ το συνθετικό — έτοιμο για τις custom ηχογραφήσεις (hot-swap ακόμα και σε loop που ήδη παίζει). Ένταση ήχου στις Ρυθμίσεις (persisted). **Ambience = file-only**: κύματα/τζιτζίκια/γρύλοι μένουν σιωπηλά μέχρι τις πραγματικές ηχογραφήσεις — το συνθετικό ακουγόταν σαν μόνιμο βουητό. Όλα τα loops: fade in/out 1.5s
- [x] Pause menu (Esc/pointer lock) + FPS counter & renderer backend (dev) — `src/ui/hud.ts`

## Φάση 2 — Survival loop
Στόχος: πείνα/δίψα/ενέργεια σε πιέζουν, μαζεύεις resources για να ζήσεις.
- [x] **Stats system**: hunger, thirst, energy, health (0-100). Δίψα πιο γρήγορα από πείνα· ενέργεια πέφτει με τρέξιμο (και το μπλοκάρει στο 0)· στο 0 πείνα/δίψα → πέφτει health· regen όταν χορτάτος — `src/survival/stats.ts` + reducer στο `src/core/actions.ts`
- [x] **HUD**: μπάρες stats (με pulse όταν <20), ώρα ημέρας, hotbar 8 θέσεων — `src/ui/hud.ts`
- [x] **Harvesting**: raycast interaction (E ή click) — `src/player/interaction.ts`. Δέντρο 4 χτυπήματα → logs+sticks (απαιτεί πέτρινο τσεκούρι ✅), πέτρες → stone, θάμνοι → sticks+berries+ίνες. ⚠️ Εκκρεμούν: τρέμουλο/particles/πτώση δέντρου
- [x] **Inventory — «Το Σακίδιο» (signature feature)**: με Tab απλώνεται σαν πανί στο έδαφος μπροστά σου (διηγητικά, μέσα στην κύρια σκηνή — όχι ξεχωριστό overlay, βγήκε απλούστερο και ίδιο οπτικά), items ως πραγματικά 3D αντικείμενα σε στοίβες/σωρούς ανά τύπο, hover → highlight + tooltip όνομα/ποσότητα, με φωτάκι για τη νύχτα — `src/ui/backpack.ts`, `src/ui/itemMeshes.ts`
- [x] **Crafting πάνω στο πανί (visual, στυλ Forest)**: click σε item → γλιστράει στον κύκλο στο κέντρο· ακριβές match συνταγής → εμφανίζεται περιστρεφόμενο **γρανάζι** → click = craft (τα υλικά σβήνουν, το αποτέλεσμα κάνει pop και πάει στη στοίβα του)· click σε item του κέντρου → γυρνάει πίσω. Συνταγές v1: σχοινί (3 ίνες), πέτρινο τσεκούρι (κλαδί+πέτρα+σχοινί), φωτιά (3 κλαδιά+3 πέτρες), δοχείο (κορμός+σχοινί) — `src/survival/crafting.ts`. ⚠️ Εκκρεμούν όσες θέλουν κυνήγι/combat: ψητό κρέας/ψάρι, δάδα, ρόπαλο
- [x] **Recipe hints**: με σωστό-αλλά-ελλιπές υλικό στο κέντρο, αχνά «φαντάσματα» των items που λείπουν εμφανίζονται στον κύκλο
- [x] **Φαγητό/νερό**: berries ✅, πόσιμο από λίμνη με τα χέρια ✅ (30% ρίσκο αρρώστιας −8 υγεία), δοχείο → γέμισμα στη λίμνη → βράσιμο στη φωτιά (E) → καθαρό νερό ✅. Η φωτιά τοποθετείται από το hotbar (ghost preview πράσινο/κόκκινο, E τοποθέτηση, Q άκυρο) — `src/building/placement.ts`, `src/building/structures.ts`. Μαγείρεμα κρέατος στη φωτιά ✅ (Φάση 5α) — ψάρεμα: backlog
- [x] **Ύπνος**: τη νύχτα κοντά σε αναμμένη φωτιά → R → ξυπνάς 06:30 με γεμάτη ενέργεια (μικρό κόστος πείνας/δίψας). Κρεβάτι/καταφύγιο: Φάση 3
- [x] **Θάνατος & respawn**: στην παραλία, χάνεις τα μισά από κάθε stack

## Φάση 3 — Building
Στόχος: χτίζεις τη βάση σου.
- [x] **Placement system**: μενού χτισίματος (B, επιλογή 1-5 με κόστη), ghost preview (πράσινο=ok, κόκκινο=άκυρο/χωρίς υλικά), rotation (R, σε ελεύθερο θεμέλιο), E/κλικ χτίζει (BUILD action με validation κόστους στον reducer), chain-building όσο φτάνουν τα υλικά — `src/building/placement.ts`
- [x] **Δομικά**: foundation (4 κορμοί), τοίχος / με πόρτα / με παράθυρο (3 κορμοί), σκεπή (3 κορμοί + 2 κλαδιά), **πάτωμα/όροφος (3 κορμοί + 2 κλαδιά)**, σκάλα (3 κορμοί + 2 κλαδιά) — socket snapping: θεμέλια ακμή-σε-ακμή, τοίχοι/σκεπές/πατώματα/σκάλες σε ΟΠΟΙΑ πλατφόρμα (θεμέλιο / σκεπή / πάτωμα = επόμενος όροφος → πολυώροφα ✅), προτίμηση στον όροφο που πατάει ο παίκτης — `src/building/pieces.ts`. **Πάτωμα** = επίπεδο plank deck· κουμπώνει (α) πάνω από τοίχους έναν όροφο ψηλότερα ή (β) ακμή-σε-ακμή με υπάρχον πάτωμα/σκεπή ίδιου ύψους (φαρδαίνει τον όροφο / πρόβολος). Σκάλα = 7 σκαλιά-terraces κάτω από το autostep 0.45 του controller (κανένα ειδικό physics). Το B ανοίγει «Σημειωματάριο» δύο σελίδων: Κτίσματα (επιλογή 1-9) + ΟΛΕΣ οι συνταγές του Σακιδίου ως αναφορά
- [x] **Λειτουργικά**: πόρτα ανοίγει/κλείνει με Ε (animated φύλλο, ο collider μπαίνει/βγαίνει, το state σώζεται) · αποθήκη-κιβώτιο (2 κορμοί+σχοινί) με δικό της inventory 12 θέσεων, E → panel μεταφοράς στοίβων · κρεβάτι (2 κορμοί+4 ίνες): E ορίζει respawn point, μετράει και ως σημείο ύπνου (R τη νύχτα). ⚠️ Campfire upgrade + ξηραντήριο: με το κυνήγι (Φάση 5)
- [x] **Καταστροφή/επισκευή** κτισμάτων — γκρέμισμα ✅ (X, επιστροφή μισών υλικών, κιβώτια αδειάζουν πρώτα) · επισκευή ✅ (E σε χτυπημένο κτίσμα, 1 κορμός — Φάση 5 raids)

## Φάση 4 — Accounts & Cloud saves
Στόχος: το progress σώζεται στον λογαριασμό του παίκτη.
- [x] **Serialization**: πλήρες `GameState` → JSON envelope `{version, savedAt, state}` με migration scaffold + backfill defaults για πεδία που προστέθηκαν μετά την αποθήκευση — `src/save/persistence.ts` (lore flags: θα μπουν στο state με τη Φάση 6)
- [x] **LocalStorage saves**: auto-save κάθε 2' + στο κλείσιμο tab (θέση 1 = αυτόματη), manual save/load/delete σε 3 slots από το pause menu, «Νέο παιχνίδι», auto-continue από το τελευταίο ενεργό slot στο boot
- [ ] **Supabase setup**: project, auth (email/password + Google), πίνακας `saves` (user_id, slot, state jsonb, updated_at), Row Level Security ώστε καθένας να βλέπει μόνο τα δικά του
- [ ] **Sync**: login screen, upload/download saves, conflict resolution (νεότερο κερδίζει, με προειδοποίηση)

## Φάση 5 — Enemies & Combat
### 5α — Wildlife
- [x] Ελάφια & κουνέλια: wander, φεύγουν όταν πλησιάζεις → κυνήγι για ωμό κρέας/δέρμα — `src/enemies/animals.ts`
- [x] Αγριογούρουνα: ουδέτερα, γυρνούν και επιτίθενται αν τα χτυπήσεις (12 dmg)
- [x] Λύκοι: μόνο νύχτα, αγέλη έως 3, κυνηγούν σε ακτίνα 26m, **φοβούνται τις φωτιές** (δεν πλησιάζουν <8m — LORE mechanic έτοιμο για τους Hollow Ones), λιώνουν την αυγή
- [x] AI: FSM (Idle → Wander → Flee/Chase → Attack), steering με αποφυγή απότομων κλίσεων/νερού (probe μπροστά, όχι navmesh)
- [x] Spawning ανά βιότοπο (ζώνες ύψους) + respawn top-up κάθε 45s μέχρι το cap, μακριά από τον παίκτη. Τα ζώα είναι transient (δεν σώζονται· επαναγεμίζουν στο load)
### 5β — Combat & Hollow Ones
- [x] Melee combat: τσεκούρι(30)/ρόπαλο(20)/χέρια(8), hit flash + knockback, floating health bars εχθρών. **Τόξο+βέλη**: τόξο (2 κλαδιά+2 σχοινιά), βέλη ×3 (κλαδί+πέτρα+ίνα) — equip το τόξο, κλικ ρίχνει με βολή-καμπύλη (`src/player/archery.ts`), E παραμένει melee. Οι επιθέσεις εχθρών ελέγχουν πλέον **line-of-sight** — δεν δαγκώνουν μέσα από τοίχους
- [x] **Hollow Ones** — `src/enemies/hollows.ts`: spawn **μόνο νύχτα** από στόμια σπηλιών (3 seeded landmarks στα υψώματα — `src/world/caves.ts`· γίνονται πραγματικές σπηλιές στη Φάση 6), φοβούνται τη φωτιά (<9m), **stalk συμπεριφορά**: κρατούν δαχτυλίδι 15-24m και κυκλώνουν· αν τους κοιτάξεις παγώνουν· αν επιμείνεις >1.6s διαλύονται και επανεμφανίζονται εκτός οπτικού πεδίου· επιτίθενται (14 dmg) όταν τολμήσουν ή σε πιάσουν μακριά από φως· διαλύονται την αυγή, δεν αφήνουν loot. Toast «Τα τζιτζίκια σώπασαν...» στο πρώτο stalk της νύχτας
- [x] **Escalation**: πλήθος (1→4) και τόλμη κλιμακώνουν με τα lore findings — το scaffold διαβάζει `state.lore.collectedFindings` (μπήκε στο GameState· η Φάση 6 θα το τροφοδοτεί)
- [x] **Raid nights** κάθε 5η μέρα (αν έχεις χτίσει): 2+ Κούφιοι-raiders πάνε κατευθείαν για τη βάση και σπάνε κτίσματα (10 dmg/χτύπημα, HP ανά τύπο: τοίχος 120, θεμέλιο 200...)· και εκτός raid, Κούφιος μπλοκαρισμένος από τοίχο γυρνά και τον σπάει. Οι φωτιές κοντά στους τοίχους τους κρατούν μακριά (fire-fear = άμυνα). **Επισκευή**: E σε χτυπημένο κτίσμα (1 κορμός). Bonus fix: οι θάμνοι ξαναφυτρώνουν 3 μέρες μετά το μάζεμα (ανανεώσιμες ίνες/μούρα)

## Φάση 6 — Lore & Story
- [ ] **Findings system**: σημειώσεις, κασέτες (με ήχο ή text), αντικείμενα — pickup → journal screen (J) με συλλογή/χάρτη προόδου
- [ ] **Τοποθεσίες**: ναυάγιο (start), 3 ερευνητικά outposts, κεντρικός σταθμός "Σταθμός ΙΡΙΣ", 2 σπηλιές, bunker φινάλε — χειροποίητη τοποθέτηση πάνω στο procedural terrain
- [ ] **Progression flags**: findings ξεκλειδώνουν πόρτες/κωδικούς → επόμενη τοποθεσία
- [ ] **Φινάλε**: επισκευή ραδιοπομπού (χρειάζεται 3 εξαρτήματα από τις 3 τοποθεσίες) → επιλογή τέλους (βλ. LORE.md)
- [ ] Ήχοι/μουσική για tension (βλ. SOUNDS.md — custom ηχογραφήσεις) — intro cutscene κειμένου ✅ (μπήκε με το game shell: 4 γραμμές lore με σταδιακό fade σε νέο παιχνίδι)

## Φάση 6.5 — Progression & Εξοπλισμός (design mapping — προς απόφαση)
Ιδέες παίκτη (XP, ασπίδες κ.λπ.) χαρτογραφημένες σε υλοποιήσιμα κομμάτια:
- [x] **Πανοπλία από δέρματα (v1)**: δερμάτινο γιλέκο (4 δέρματα+2 σχοινιά, −25% damage), κράνος (2 δέρματα+1 σχοινί, −10%) — craft στο Σακίδιο. Η ζημιά εχθρών περνά πλέον από νέο action `HURT_PLAYER` → ο reducer εφαρμόζει `armorDamageFactor(inventory)` (πολλαπλασιαστικά, μία φορά ανά κομμάτι)· ΔΕΝ επηρεάζει αρρώστια/λιμοκτονία/θεραπεία (μένουν MODIFY_STATS). Chip 🛡 στο HUD όταν φοράς. **v1 = passive όσο το κρατάς** (δίνει επιτέλους χρήση στο δέρμα)· ⚠️ εκκρεμούν: ρητά equip slots + durability. — `items.ts`, `actions.ts`, `crafting.ts`
- [x] **Επίδεσμος (θεραπεία)**: 3 ίνες + 1 δέρμα → +35 υγεία (consumable από hotbar· καλύπτει και το instant damage της αρρώστιας, που δεν είναι πια dead-end) — `items.ts`, `crafting.ts`
- [x] **Πέτρινο μαχαίρι**: 1 κλαδί + 2 πέτρες (multiset ξεχωριστό από βέλη/τσεκούρι) → melee 14 + **skinning**: διπλασιάζει το δέρμα από kill όταν το κρατάς (`animals.ts kill()` ελέγχει `SKINNING_KNIFE`). Κλείνει τον βρόχο: κυνήγι με μαχαίρι → περισσότερο δέρμα → πανοπλία/επίδεσμοι — `items.ts`, `crafting.ts`
- [x] **Δάδα (torch)**: 1 κλαδί + 2 ίνες. Equip από hotbar (νέο `isEquippable` = όπλα + δάδα)· `TorchSystem` (`player/torch.ts`) = point light στην κάμερα + flicker + καύση ~120s (σβήνει → ανάβει την επόμενη ή unequip). **Φορητή πηγή φωτιάς**: οι εχθροί το διαβάζουν μέσω `litTorch` → νέο `fireDistance()` σε λύκους/Κούφιους (fire-fear ακολουθεί τον παίκτη)· ανάβει και το 🔥 chip. Κλειδί για τις σπηλιές της Φάσης 6. ⚠️ v1: fuel = runtime state (όχι per-item durability στο save)
- [x] **Ασπίδα (ξύλινη, v1)**: 2 κορμοί+1 δέρμα — με την ασπίδα στο σακίδιο, **κράτα ΔΕΞΙ κλικ** = block: χτύπημα από το μπροστινό τόξο (~150°) μηδενίζεται με κόστος 6 ενέργεια (αν δεν φτάνει η ενέργεια, περνάει). `input.rightHeld` + callback `playerBlock(ex,ez)` στα enemy systems, toast σε απόκρουση. ⚠️ εκκρεμούν: durability, viewmodel off-hand. Bonus fixes ίδιου pass: EQUIP reducer δεχόταν μόνο isWeapon → η δάδα δεν άναβε ποτέ (fixed → isEquippable)· drop/αποθήκευση του τελευταίου equipped item άφηνε stale equip (unequipIfGone στον reducer)· **Esc = πάντα cancel/κλείσιμο του ενεργού** (ghost/βοήθεια/στόχοι/notebook) — το pause menu ανοίγει μόνο όταν δεν είναι κάτι ανοιχτό
- [ ] **Tool tiers**: πέτρινο → **μεταλλικό** τσεκούρι/μαχαίρι από salvage (μεταλλικά κομμάτια ως loot στα lore locations της Φάσης 6 — δένει progression με εξερεύνηση)
- [x] **Quests + XP + levels (v1)** — `src/survival/quests.ts`: 16 στόχοι (κόψε 10/50/100 δέντρα, σκότωσε λύκους/Κούφιο, επιβίωσε 3/7/15 μέρες, χτίσε/craft/ψήσε...) με counters που γεμίζουν ΜΕΣΑ στον reducer από τα υπάρχοντα actions → σώζονται στο save. XP → επίπεδα (max 10) με perks: +5% ζημιά melee & −4% κόπωση sprint ανά επίπεδο. Toasts σε ολοκλήρωση/level-up, επίπεδο στο ρολόι του HUD
- [x] **Σελίδα στόχων (J)** — `src/ui/questsPanel.ts`: επίπεδο + XP bar + perks, ενεργοί στόχοι με πρόοδο x/y, ολοκληρωμένοι (γίνεται tab του journal στη Φάση 6)
- [x] **Hold-to-use** (αίτημα παίκτη): χτυπάς με ό,τι ΚΡΑΤΑΣ — τα δέντρα κόβονται μόνο με το τσεκούρι equipped (όχι απλώς στο σακίδιο)· το prompt λέει «Κράτα: Πέτρινο τσεκούρι»
- [x] **First-person viewmodel (v1)** — `src/player/viewmodel.ts`: βλέπεις το equipped όπλο/εργαλείο στο χέρι (κάτω-δεξιά), με walk bob και swing animation σε κάθε χτύπημα/βολή. Full arms/poses: Φάση 7

## Φάση 7 — Polish (backlog)
- [x] **Localization (αγγλικά πρώτα, ανοιχτό σε μεταφράσεις)** — `src/i18n/`: το `en.json` έγινε η πηγή αλήθειας και το fallback· τα ελληνικά (`el.json`) είναι πλήρης μετάφραση (196/196) και φορτώνονται lazily ως ξεχωριστό chunk (11 kB) — ο αγγλόφωνος παίκτης δεν τα κατεβάζει ποτέ. Κάθε νέα γλώσσα = ΕΝΑ json + 2 γραμμές registry (`TRANSLATING.md`), και επιτρέπεται να είναι μερική (deep-merge πάνω στα αγγλικά ανά key). Αλλαγή γλώσσας από τις Ρυθμίσεις είναι **άμεση, χωρίς reload** (Hud/Menus ξαναχτίζονται μέσω `onLocaleChange`), persisted, με auto-detect από τον browser στο πρώτο boot. Τα quest titles/descs βγήκαν από το `quests.ts` (data-only πλέον, με `QuestId`) και μπήκαν στα locales. Compile-time guards: λείπει όνομα για item/animal/build piece/quest στο `en.json` → σπάει το build· `pnpm i18n:check` δείχνει κάλυψη ανά γλώσσα
- [ ] Full equip system: ορατό όπλο/εργαλείο στο χέρι + animations (v1 υπάρχει ήδη: 24-slot σακίδιο, hotbar μόνο με χρησιμοποιήσιμα — φαγώσιμα/όπλα/τοποθετήσιμα — και toggle-equip όπλου από το πλήκτρο του με highlight· ο EQUIP περνά από τον reducer)
- [ ] Καιρός (βροχή → πέφτει θερμοκρασία), εποχές
- [ ] Ψάρεμα, καλλιέργειες
- [ ] Gamepad support, touch controls για tablet/κινητό — settings menu ✅ (ευαισθησία/FOV/σκιές/ανάλυση, persisted, από title & pause· ήχος μπαίνει με το audio pass). Game shell ✅: title screen με cinematic orbit, intro κειμένου, death screen, «Κεντρικό μενού»
- [~] Optimization pass — μετρήσιμο πλέον από το dev HUD (fps · ms · draw calls · tris). Στόχοι: <500 calls σε WebGL, <5ms render JS.
  - [x] (1) **merge τα κουτιά κάθε δομικού piece σε 1-2 meshes με κοινά materials** — `pieces.ts mergeByColor()`: τοίχος 10→2 meshes, θεμέλιο 11→2, σκάλα 16→2· τα materials είναι module-level shared ανά χρώμα (batching). Ήταν η αιτία του build-lag. `PIECE_SHARED_MATERIALS` για να μη γίνονται dispose.
  - [x] **Resource lifecycle**: `core/three-utils.ts disposeObject3D()` σε ΟΛΑ τα removal paths (δομές demolish/raid, ζώα/Κούφιοι despawn, βέλη, viewmodel swap, Σακίδιο rebuild) — έκλεισε τα GPU leaks (πριν: κανένα `.dispose()` πουθενά). Βέλη = shared geo/mat.
  - [x] **Per-frame scans**: `structures.byType` bucket → `nearestDistance` (nearFire/canSleep) σκανάρει μόνο φωτιές/κρεβάτια, όχι όλες τις δομές· HUD element-ref caching (compass/hotbar querySelector μία φορά). Autosave `saveToSlot` σε try/catch (δεν παγώνει το render loop σε quota error).
  - [x] **HUD per-frame DOM (i18n pass)**: το `update()` έκανε ακόμα ~11 `getElementById` ανά frame (chips ×7, `level-num`, `xp-mini-fill`, `damage-vignette`, `build-menu`) παρά το σχόλιο ότι τα refs είναι cached — τώρα μπαίνουν όλα στο `bind()`. Επίσης το `#prompt` γράφεται μόνο όταν αλλάζει το κείμενο (dirty-check): το string εξακολουθεί να χτίζεται κάθε frame, αλλά κόβεται το DOM write + layout invalidation ενώ κοιτάς το ίδιο δέντρο.
  - [ ] (2) merge σώματα ζώων/Κούφιων σε 1 geometry το καθένα (κινούνται ολόσωμα — δωρεάν), (3) LOD βλάστησης, (4) στα GLB imports να διατηρηθεί το instancing (InstancedMesh), texture atlases, chunked terrain. Επόμενο: InstancedMesh ανά piece-type αν το dev HUD δείξει >500 calls σε μεγάλη βάση.

## Φάση 8 — Multiplayer Co-op (μελλοντικό, αλλά προετοιμασμένο)
Στόχος: 2-4 φίλοι στο ίδιο νησί.
- [ ] **Server**: Node.js authoritative server με Colyseus (ή custom WebSocket) — ο server κρατά το έργο-αλήθειας GameState, οι clients στέλνουν actions
- [ ] **Sync**: player positions/animations με interpolation, world events (κόψιμο, χτίσιμο, pickups) ως broadcast actions, shared day/night clock
- [ ] **Co-op mechanics**: κοινά κτίσματα/αποθήκες, revive αναίσθητου συμπαίκτη, split του lore (όποιος βρει finding το βλέπουν όλοι στο journal)
- [ ] **Hosting**: invite με room code, το save ανήκει στον host (Supabase)
- [ ] Hollow Ones scaling με αριθμό παικτών

> **Προετοιμασία από τώρα (ισχύει από τη Φάση 1!)**: βλ. CLAUDE.md §Multiplayer-ready αρχιτεκτονική.

---

## Assets (όλα CC0 — δωρεάν και για εμπορική χρήση)

| Πηγή | Τι παίρνουμε | URL |
|---|---|---|
| Quaternius — Ultimate Nature Pack | δέντρα, πέτρες, θάμνοι, γρασίδι, λουλούδια | https://quaternius.com |
| Quaternius — Animals/Ultimate Animated Animals | ελάφι, λύκος, αγριογούρουνο, κουνέλι (με animations) | https://quaternius.com |
| Quaternius — Monsters Pack | βάση για Hollow Ones (θα τα κάνουμε retexture σκούρα/χλωμά) | https://quaternius.com |
| Kenney — Survival Kit | εργαλεία, φωτιά, κιβώτια, σκηνή, building pieces | https://kenney.nl/assets/survival-kit |
| Kenney — Audio packs | UI sounds, footsteps, impacts | https://kenney.nl/assets?q=audio |
| ambientCG | terrain textures (grass, rock, sand) αν χρειαστούν | https://ambientcg.com |
| Poly Pizza | συμπληρωματικά μοντέλα (ναυάγιο, ραδιοπομπός, κασέτες) | https://poly.pizza |

Οδηγία: τα GLB μπαίνουν σε `public/assets/models/<pack>/`, με `CREDITS.md` που καταγράφει πηγή/άδεια. Προτίμηση σε Draco-compressed εκδόσεις όπου υπάρχουν.
