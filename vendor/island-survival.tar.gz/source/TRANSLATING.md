# Translating Island Survival

The game ships in **English** and **Greek**. Adding another language means
writing one JSON file — no TypeScript, no build step knowledge required.

## How it works

`src/i18n/en.json` is the source of truth. Every other locale is a **partial
overlay** on top of it: at runtime your file is deep-merged over English, so
any key you leave out simply renders in English instead of coming out blank.
That means you can ship a 40%-done translation and the game stays fully
playable — then fill in the rest whenever you like.

Each language is a separate lazily-loaded chunk, so players only download the
one they actually play in.

## Adding a language

1. **Copy the English file** to a new one named after the language's
   [ISO 639-1 code](https://en.wikipedia.org/wiki/List_of_ISO_639_language_codes):

   ```bash
   cp src/i18n/en.json src/i18n/de.json
   ```

2. **Translate the values.** Only ever change the text on the right of the
   colon. Never change a key (the part on the left) — that's what the code
   looks up.

   ```jsonc
   "prompts": {
     "tree": "Baum fällen",     // ✅ translate the value
     "rock": "Break the rock"   // ✅ fine to leave — falls back to English
   }
   ```

3. **Register it** in `src/i18n/index.ts` — two lines:

   ```ts
   export const LOCALES = {
     en: { name: 'English', tag: 'en' },
     el: { name: 'Ελληνικά', tag: 'el-GR' },
     de: { name: 'Deutsch', tag: 'de-DE' },     // ← add this
   } as const;

   const LOADERS: Record<LocaleId, () => Promise<Translation>> = {
     en: async () => ({}),
     el: async () => (await import('./el.json')).default,
     de: async () => (await import('./de.json')).default,   // ← and this
   };
   ```

   `name` is what appears in the Settings dropdown — write it in the language
   itself ("Deutsch", not "German"). `tag` is the BCP-47 tag used for date
   formatting.

4. **Check your coverage:**

   ```bash
   pnpm i18n:check
   ```

   ```
   en.json — 196 keys (source of truth)

   de.json — 174/196 (89%)
     missing (falls back to English):
       help.sourceLines
       toasts.stalked
   ```

   It also flags keys that don't exist in English — usually a typo.

5. **Try it:** `pnpm dev`, then Settings → Language.

## Things worth knowing

**Key names stay in English.** `WASD`, `Shift`, `Tab`, `E`, `F3` are the same
on every keyboard. Translate the words around them, not the keys:

```jsonc
"ghostControls": "E/Klick — Bauen · R — Drehen · Q — Abbrechen"
```

**Arrays are all-or-nothing.** `controls`, `compass`, `menu.introLines` and
`help.sourceLines` are replaced as a whole rather than merged line by line —
a half-translated list would mix two languages in one paragraph. Translate
every entry, or leave the array out entirely.

**`compass` must stay in clockwise order** starting from North: N, NE, E, SE,
S, SW, W, NW. The code derives each label's bearing from its position.

**The intro is prose, not UI.** `menu.introLines` is the game's opening
narration. Translate it for tone and rhythm, not word by word.

**Some keys are load-bearing** and the build will fail if English is missing
one (translations are exempt): every id under `items`, `animals`,
`build.pieces`, and `quests.defs`. If you add a new item to the game, TypeScript
will make you name it in `en.json` before it compiles.

**Watch the length.** The HUD prompt is a single line and the hotbar slots are
narrow. If a translation is much longer than the English, check it in-game.

## Reviewing the Greek

`el.json` is maintained at full parity by the project author. If something
reads awkwardly, open an issue rather than a silent rewrite — some of it is
deliberate voice.
