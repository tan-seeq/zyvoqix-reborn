import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const bundlePath = path.join(REPO_ROOT, 'assets/index-C9rd31_W.js');
let src = fs.readFileSync(bundlePath, 'utf8');

const targetStart = 'const U=(_.kind==="shell"?18:_.kind==="floatisland"||_.kind==="waterfall"?24:_.kind==="wreck"?23:8)*b,G=["wreck","rocks","waterfall","floatisland"].includes(_.kind),H=y(M,_.lateral,U,G);if(H)if(_.kind==="beacon"){';
const targetEnd = 'M.count=b,M.instanceMatrix.needsUpdate=!0,M.computeBoundingSphere(),M.castShadow=t.shadows,e.add(M)}';

const startIdx = src.indexOf(targetStart);
if (startIdx === -1) {
  console.error("Target start not found!");
  process.exit(1);
}

// BUG FIX: prima endIdx = indexOf(...) + len trasformava -1 in un indice positivo,
// aggirando la guardia e troncando il bundle. Ora si verifica indexOf esplicitamente.
const endMatch = src.indexOf(targetEnd, startIdx);
if (endMatch === -1) {
  console.error("Target end not found!");
  process.exit(1);
}
const endIdx = endMatch + targetEnd.length;

const replacement = `const _customKinds=["temple_colonnade","radar_tower","giant_redwood","stadium_jumbotron","mine_headframe","ice_shard_monolith","cyber_skyscraper","lava_chimney","hell_obelisk","stargate_ring","kraken_tentacle","bioluminescent_shroom","cloud_palace","storm_pylon","sky_needle","vortex_funnel","abyssal_trident","acropolis_rotunda","dragon_ribcage","prism_pyramid","smelter_forge","tachyon_gate","singularity_collider","omega_monument"];
const _isFloatOrWide=["wreck","rocks","waterfall","floatisland",..._customKinds].includes(_.kind);
const U=(_isFloatOrWide?22:_.kind==="shell"?18:8)*b,H=y(M,_.lateral,U,_isFloatOrWide);
if(H)if(_.kind==="beacon"){p(new xe(2.2*b,5*b,39*b,8),o,H.clone().add(new T(0,19.5*b,0))),p(new xe(5*b,4*b,2*b,8),r,H.clone().add(new T(0,37*b,0)));const z=new le;z.position.copy(H).y+=42*b,z.add(new Zt(new hi(3.4*b),c));const B=new Zt(new Wn(13*b,95*b,20,1,!0),D);B.rotation.z=Math.PI/2,B.position.x=47.5*b,z.add(B),e.add(z),v.push(z),p(new Wn(6*b,6*b,8),r,H.clone().add(new T(0,49*b,0)))}
else if(_.kind==="shell"){const z=[];for(let B=0;B<=150;B++){const k=B/150*Math.PI*5,st=1+B/150*12;z.push(new T(Math.cos(k)*st,Math.sin(k)*st+15,B/150*6))}p(new Ts(new ys(z),150,2.4,8,!1),o,H,new T(b,b,b));for(let B=0;B<14;B++){const k=B/14*Math.PI*2;p(new hi(1.5),r,H.clone().add(new T(Math.cos(k)*14,15+Math.sin(k)*14,5)),new T(1,2,1))}}
else if(_.kind==="floatisland"){const z=H.clone();z.y=Math.max(H.y+45,50)+b*9;for(let B=0;B<4;B++){const k=(13-B*2.7)*b,st=z.clone().add(new T(Math.sin(B*2)*b,-B*4*b-2*b,Math.cos(B)*b));p(new xe(k,k*.78,4.5*b,9),B%2?o:i,st)}p(new xe(14*b,13*b,1.3*b,9),a,z),p(new xe(14.3*b,13.3*b,.65*b,9),o,z.clone().add(new T(0,-.8*b,0)));for(let B=0;B<13;B++){const k=B/13*Math.PI*2,st=(3+n()*8)*b,at=z.clone().add(new T(Math.cos(k)*12.5*b,-st/2,Math.sin(k)*12.5*b));if(p(new xe(.28*b,.06*b,st,4),a,at,void 0,new Pe(.12*Math.sin(k),0,.12*Math.cos(k))),B%4===0){const ft=z.clone().add(new T(Math.cos(k)*19*b,(-5-n()*5)*b,Math.sin(k)*19*b));p(new _n(2.5*b,0),i,ft,new T(1.2,.7,1))}}for(let B=0;B<5;B++){const k=z.clone().add(new T((n()-.5)*14*b,2.5*b,(n()-.5)*14*b));p(new _n(2.7*b,1),a,k,new T(1,.7+n(),1)),B===0&&p(new hi(2*b),c,k.add(new T(0,4*b,0)),new T(.6,2,.6))}}
else if(_.kind==="waterfall"){const z=Math.max(H.y+26*b,f.pos.y+16),B=Math.max(cn,H.y-14),k=z-B;for(let ft=0;ft<4;ft++)p(new xe((12-ft)*b,(13-ft)*b,k/4+1,7),ft%2?i:a,new T(H.x,B+k*(ft+.5)/4,H.z-7*b),new T(1,1,.55));const st=new Zt(new mi(13*b,k,1,8),x);st.position.set(H.x,B+k/2,H.z),e.add(st);const at=new Zt(new mi(29*b,16*b),S);at.position.set(H.x,B+2,H.z+1),e.add(at),g.push({object:at,y:at.position.y,phase:n()*6,amplitude:.6})}
else if(_.kind==="wreck"){H.y=cn+1;const z=new $n(1,16,8,0,Math.PI*2,Math.PI/2,Math.PI/2);p(z,l,H,new T(7*b,8*b,17*b),new Pe(0,0,.13)),p(new He(11*b,.7*b,25*b),l,H.clone().add(new T(0,-.3*b,0)));for(const st of[-1,1]){p(new He(.55*b,.65*b,24*b),o,H.clone().add(new T(st*5.7*b,1.2*b,0)));for(let at=-3;at<=3;at++)p(new He(.35*b,2*b,.35*b),o,H.clone().add(new T(st*5.7*b,.2*b,at*3.4*b)))}p(new He(7*b,4*b,6*b),r,H.clone().add(new T(0,2*b,8*b))),p(new xe(.3*b,.6*b,25*b,6),l,H.clone().add(new T(0,12*b,-2*b)),void 0,new Pe(0,0,-.12)),p(new He(13*b,.5*b,.5*b),o,H.clone().add(new T(1.7*b,17*b,-2*b)));const B=new Ia;B.moveTo(-5,0),B.lineTo(5,0),B.lineTo(3,-4),B.lineTo(4,-7),B.lineTo(-4,-9),B.closePath();const k=new Lr(B,{depth:.12,bevelEnabled:!1});p(k,o,H.clone().add(new T(1.7*b,16.5*b,-2*b)),new T(b,b,b))}
else if(_.kind==="temple_colonnade"){p(new He(22*b,2*b,10*b),r,H.clone().add(new T(0,1*b,0)));for(let K=-2;K<=2;K++){const colPos=H.clone().add(new T(K*4.4*b,8.5*b,0));p(new xe(.9*b,1.1*b,13*b,8),r,colPos);p(new He(2.4*b,.8*b,2.4*b),o,colPos.clone().add(new T(0,6.8*b,0)))}p(new He(24*b,2.2*b,4.5*b),r,H.clone().add(new T(0,16*b,0)));p(new He(18*b,1.8*b,3.5*b),o,H.clone().add(new T(0,17.8*b,0)));p(new hi(2.2*b),c,H.clone().add(new T(0,7*b,0)),new T(.8,1.6,.8))}
else if(_.kind==="radar_tower"){p(new xe(3.2*b,6*b,26*b,4),l,H.clone().add(new T(0,13*b,0)));p(new xe(6.5*b,5*b,5*b,8),o,H.clone().add(new T(0,28*b,0)));p(new xe(.4*b,.8*b,16*b,6),l,H.clone().add(new T(0,38*b,0)));p(new $n(4*b,8,8,0,Math.PI*2,0,Math.PI*.5),l,H.clone().add(new T(0,34*b,2*b)),void 0,new Pe(.5,0,0));p(new hi(1.4*b),c,H.clone().add(new T(0,47*b,0)))}
else if(_.kind==="giant_redwood"){p(new xe(2.4*b,4.8*b,44*b,8),r,H.clone().add(new T(0,22*b,0)));for(let K=0;K<4;K++)p(new Wn((9.5-K*1.8)*b,8.5*b,7),a,H.clone().add(new T(0,(26+K*7)*b,0)));p(new _n(1.8*b,0),o,H.clone().add(new T(1.5*b,6*b,1.2*b)));p(new hi(1.1*b),c,H.clone().add(new T(0,50*b,0)),new T(.6,1.4,.6))}
else if(_.kind==="stadium_jumbotron"){for(const st of[-1,1])p(new xe(1.2*b,1.5*b,25*b,6),l,H.clone().add(new T(st*8*b,12.5*b,0)));p(new He(22*b,1.4*b,2*b),l,H.clone().add(new T(0,14*b,0)));p(new He(18*b,9.5*b,1.5*b),o,H.clone().add(new T(0,24*b,0)),void 0,new Pe(-.12,0,0));p(new He(17*b,8.5*b,.35*b),c,H.clone().add(new T(0,24*b,.8*b)),void 0,new Pe(-.12,0,0));p(new He(19*b,1.2*b,3*b),h,H.clone().add(new T(0,29.5*b,-.4*b)))}
else if(_.kind==="mine_headframe"){p(new xe(2.8*b,6.5*b,30*b,4),l,H.clone().add(new T(0,15*b,0)));p(new Xn(3.2*b,.4*b,6,12),o,H.clone().add(new T(0,30*b,0)),void 0,new Pe(0,Math.PI/2,0));p(new He(11*b,7*b,9*b),i,H.clone().add(new T(0,3.5*b,0)));p(new He(4*b,1.8*b,13*b),r,H.clone().add(new T(0,4*b,5*b)),void 0,new Pe(.35,0,0));p(new hi(1.4*b),c,H.clone().add(new T(0,33*b,0)))}
else if(_.kind==="ice_shard_monolith"){p(new xe(1.2*b,4.2*b,36*b,6),o,H.clone().add(new T(0,18*b,0)),void 0,new Pe(.08,0,.08));for(let K=0;K<4;K++){const ang=K*Math.PI/2;p(new xe(.5*b,1.8*b,(16+K*3)*b,5),h,H.clone().add(new T(Math.cos(ang)*5*b,(8+K*1.5)*b,Math.sin(ang)*5*b)),void 0,new Pe(.15*Math.cos(ang),0,.15*Math.sin(ang)))}p(new hi(2.6*b),c,H.clone().add(new T(0,14*b,0)));p(new _n(3.5*b,0),r,H.clone().add(new T(0,2*b,0)))}
else if(_.kind==="cyber_skyscraper"){p(new xe(5.2*b,7.5*b,52*b,6),l,H.clone().add(new T(0,26*b,0)));for(let fl=0;fl<5;fl++)p(new xe((5.5-fl*.4)*b,(5.5-fl*.4)*b,1.1*b,6),c,H.clone().add(new T(0,(10+fl*9)*b,0)));p(new xe(.6*b,1.2*b,18*b,4),o,H.clone().add(new T(0,60*b,0)));p(new Xn(4*b,.35*b,4,12),c,H.clone().add(new T(0,54*b,0)),void 0,new Pe(Math.PI/2,0,0))}
else if(_.kind==="lava_chimney"){p(new xe(2.4*b,6.2*b,24*b,7),i,H.clone().add(new T(0,12*b,0)));for(let f=0;f<3;f++){const ang=f*Math.PI*2/3;p(new xe(.6*b,1.1*b,11*b,4),c,H.clone().add(new T(Math.cos(ang)*3*b,9*b,Math.sin(ang)*3*b)))}p(new xe(3*b,2.2*b,2*b,8),r,H.clone().add(new T(0,24*b,0)));p(new $n(2.1*b,8,6),c,H.clone().add(new T(0,24*b,0)));p(new _n(2*b,0),i,H.clone().add(new T(2*b,1*b,1.5*b)))}
else if(_.kind==="hell_obelisk"){p(new He(13*b,3*b,13*b),i,H.clone().add(new T(0,1.5*b,0)));p(new xe(1.1*b,3.6*b,40*b,4),r,H.clone().add(new T(0,21*b,0)));for(let g=0;g<4;g++){const ang=g*Math.PI/2;p(new He(1.3*b,2.4*b,4*b),c,H.clone().add(new T(Math.cos(ang)*2.2*b,(12+g*6)*b,Math.sin(ang)*2.2*b)))}p(new hi(2.4*b),c,H.clone().add(new T(0,44*b,0)))}
else if(_.kind==="stargate_ring"){p(new Xn(11*b,1.6*b,8,20),l,H.clone().add(new T(0,14*b,0)),void 0,new Pe(0,0,Math.PI/2));for(let ch=0;ch<8;ch++){const ang=ch*Math.PI/4;p(new He(2.2*b,3*b,1.8*b),o,H.clone().add(new T(Math.cos(ang)*11*b,14*b+Math.sin(ang)*11*b,0)))}p(new xe(9.5*b,9.5*b,.35*b,16),c,H.clone().add(new T(0,14*b,0)),void 0,new Pe(0,0,Math.PI/2));p(new xe(1.8*b,3.2*b,14*b,6),r,H.clone().add(new T(0,7*b,0)))}
else if(_.kind==="kraken_tentacle"){for(let sc=0;sc<5;sc++){const tH=(3.6-sc*.5)*b,bH=(4-sc*.5)*b;p(new xe(tH,bH,6*b,7),a,H.clone().add(new T(Math.sin(sc*.6)*4*b,(3+sc*5.5)*b,0)),void 0,new Pe(0,0,sc*.14));p(new $n(.85*b,6,6),c,H.clone().add(new T(Math.sin(sc*.6)*4*b+1.8*b,(3+sc*5.5)*b,0)))}p(new Wn(1.6*b,5.5*b,6),a,H.clone().add(new T(9*b,30*b,0)),void 0,new Pe(0,0,.8));p(new _n(1.6*b,0),o,H.clone().add(new T(-1.5*b,2*b,1.2*b)))}
else if(_.kind==="bioluminescent_shroom"){p(new xe(1.6*b,3*b,20*b,8),r,H.clone().add(new T(0,10*b,0)));p(new $n(7.5*b,12,6,0,Math.PI*2,0,Math.PI*.48),a,H.clone().add(new T(0,21*b,0)));for(let nod=0;nod<6;nod++){const ang=nod*Math.PI/3;p(new hi(1.1*b),c,H.clone().add(new T(Math.cos(ang)*4.5*b,22*b,Math.sin(ang)*4.5*b)))}p(new hi(.8*b),c,H.clone().add(new T(0,15*b,2.5*b)))}
else if(_.kind==="cloud_palace"){const cP=H.clone().add(new T(0,35*b,0));for(let cl=0;cl<3;cl++)p(new $n((5.5+cl*1.8)*b,8,6),r,cP.clone().add(new T((cl-1)*5*b,-2*b,0)));p(new xe(3.8*b,4.2*b,9*b,8),o,cP.clone().add(new T(0,4.5*b,0)));p(new $n(4.5*b,10,8,0,Math.PI*2,0,Math.PI*.5),h,cP.clone().add(new T(0,9*b,0)));p(new hi(1.8*b),c,cP.clone().add(new T(0,4*b,0)));p(new He(.35*b,8*b,1.8*b),a,cP.clone().add(new T(3*b,0,0)))}
else if(_.kind==="storm_pylon"){p(new He(9*b,5*b,9*b),l,H.clone().add(new T(0,2.5*b,0)));p(new xe(1.4*b,3.8*b,34*b,4),l,H.clone().add(new T(0,20*b,0)));for(let tc=0;tc<3;tc++)p(new Xn((3.5-tc*.5)*b,.4*b,6,12),o,H.clone().add(new T(0,(24+tc*5)*b,0)),void 0,new Pe(Math.PI/2,0,0));p(new hi(2.3*b),c,H.clone().add(new T(0,39*b,0)));p(new xe(.2*b,.2*b,20*b,4),h,H.clone().add(new T(2.5*b,12*b,2.5*b)))}
else if(_.kind==="sky_needle"){p(new xe(2*b,5.2*b,45*b,6),l,H.clone().add(new T(0,22.5*b,0)));p(new xe(10*b,8.5*b,3.2*b,12),o,H.clone().add(new T(0,36*b,0)));p(new xe(10.2*b,8.7*b,.9*b,12),c,H.clone().add(new T(0,36*b,0)));p(new Wn(1.4*b,20*b,6),h,H.clone().add(new T(0,48*b,0)))}
else if(_.kind==="vortex_funnel"){for(let vf=0;vf<4;vf++)p(new Xn((9-vf*1.3)*b,.55*b,6,14),o,H.clone().add(new T(0,(8+vf*7)*b,0)),void 0,new Pe(Math.PI/2,0,0));p(new Wn(6.5*b,28*b,8),c,H.clone().add(new T(0,16*b,0)),void 0,new Pe(Math.PI,0,0));for(let sp=0;sp<3;sp++){const ang=sp*Math.PI*2/3;p(new xe(.9*b,1.8*b,15*b,5),l,H.clone().add(new T(Math.cos(ang)*8*b,7.5*b,Math.sin(ang)*8*b)))}p(new hi(1.5*b),c,H.clone().add(new T(0,32*b,0)))}
else if(_.kind==="abyssal_trident"){p(new xe(6.5*b,7.5*b,3.5*b,6),i,H.clone().add(new T(0,1.7*b,0)));p(new xe(1.1*b,1.5*b,32*b,8),o,H.clone().add(new T(0,18*b,0)));for(const tine of[-1,0,1])p(new Wn(1.1*b,11*b,5),h,H.clone().add(new T(tine*3.2*b,36*b,0)));p(new He(7.5*b,1.2*b,1.8*b),o,H.clone().add(new T(0,31*b,0)));p(new $n(2.3*b,10,8),c,H.clone().add(new T(0,34*b,0)))}
else if(_.kind==="acropolis_rotunda"){for(let st=0;st<3;st++)p(new xe((11-st*1.1)*b,(11-st*1.1)*b,1.1*b,12),r,H.clone().add(new T(0,(st+.5)*1.1*b,0)));for(let c=0;c<8;c++){const ang=c*Math.PI/4;p(new xe(.8*b,1*b,11*b,8),r,H.clone().add(new T(Math.cos(ang)*8.5*b,8.8*b,Math.sin(ang)*8.5*b)))}p(new xe(9.6*b,9.6*b,1.6*b,12),o,H.clone().add(new T(0,15*b,0)));p(new $n(9.2*b,12,8,0,Math.PI*2,0,Math.PI*.5),r,H.clone().add(new T(0,15.8*b,0)));p(new hi(2*b),c,H.clone().add(new T(0,6*b,0)))}
else if(_.kind==="dragon_ribcage"){p(new He(2.8*b,2.8*b,34*b),r,H.clone().add(new T(0,9*b,0)));for(let rc=0;rc<5;rc++)for(const s of[-1,1])p(new xe(.6*b,1.1*b,(13-rc*1.1)*b,5),i,H.clone().add(new T(s*4.5*b,5*b,(rc-2)*6*b)),void 0,new Pe(0,0,s*.45));p(new He(6.5*b,4.5*b,8*b),o,H.clone().add(new T(0,10*b,18*b)));p(new hi(1.9*b),c,H.clone().add(new T(0,7*b,0)))}
else if(_.kind==="prism_pyramid"){for(let pl=0;pl<4;pl++)p(new He((20-pl*4.2)*b,2.8*b,(20-pl*4.2)*b),o,H.clone().add(new T(0,(pl*2.8+1.4)*b,0)));p(new Wn(4.5*b,6.5*b,4),h,H.clone().add(new T(0,14.5*b,0)),void 0,new Pe(0,Math.PI/4,0));for(let j=0;j<4;j++){const ang=j*Math.PI/2;p(new hi(1.4*b),c,H.clone().add(new T(Math.cos(ang)*3.5*b,18*b,Math.sin(ang)*3.5*b)))}p(new He(.9*b,11*b,.9*b),c,H.clone().add(new T(0,7*b,7*b)))}
else if(_.kind==="smelter_forge"){p(new xe(7.5*b,10*b,20*b,8),l,H.clone().add(new T(0,10*b,0)));p(new He(3.8*b,1.8*b,15*b),c,H.clone().add(new T(0,2*b,8*b)));for(const st of[-1,1])p(new xe(1.6*b,2*b,22*b,6),o,H.clone().add(new T(st*5*b,18*b,-2*b)));p(new Xn(7*b,.55*b,6,12),c,H.clone().add(new T(0,14*b,0)),void 0,new Pe(Math.PI/2,0,0));p(new He(15*b,1.8*b,2.6*b),l,H.clone().add(new T(0,21*b,0)))}
else if(_.kind==="tachyon_gate"){for(const s of[-1,1])p(new xe(2*b,3.5*b,35*b,6),l,H.clone().add(new T(s*8.5*b,17.5*b,0)),void 0,new Pe(0,0,s*-.12));p(new He(20*b,2.8*b,3.8*b),o,H.clone().add(new T(0,34*b,0)));for(let k=-2;k<=2;k++)p(new hi(1.3*b),c,H.clone().add(new T(k*3.5*b,30*b,0)));p(new Xn(5*b,.38*b,6,16),c,H.clone().add(new T(0,18*b,0)),void 0,new Pe(0,Math.PI/2,0))}
else if(_.kind==="singularity_collider"){p(new Xn(15*b,2.2*b,8,24),l,H.clone().add(new T(0,18*b,0)),void 0,new Pe(.3,0,Math.PI/2));for(let sb=0;sb<4;sb++){const ang=sb*Math.PI/2;p(new He(3.5*b,12*b,5*b),i,H.clone().add(new T(Math.cos(ang)*11*b,8*b,Math.sin(ang)*11*b)))}p(new $n(3.8*b,12,8),c,H.clone().add(new T(0,18*b,0)));for(let a=0;a<3;a++)p(new xe(.28*b,.28*b,20*b,4),h,H.clone().add(new T((a-1)*3*b,18*b,0)),void 0,new Pe(0,0,a*.5))}
else if(_.kind==="omega_monument"){for(let pod=0;pod<3;pod++)p(new xe((13-pod*2.2)*b,(14-pod*2.2)*b,2.8*b,8),o,H.clone().add(new T(0,(pod*2.8+1.4)*b,0)));p(new Xn(8.5*b,1.6*b,6,16),h,H.clone().add(new T(0,18*b,0)),void 0,new Pe(0,0,Math.PI/2));p(new Wn(2.8*b,16*b,6),c,H.clone().add(new T(0,16*b,0)));for(let br=0;br<4;br++){const ang=br*Math.PI/2;p(new xe(1.1*b,1.5*b,4.5*b,6),l,H.clone().add(new T(Math.cos(ang)*8*b,9*b,Math.sin(ang)*8*b)));p(new hi(1.3*b),c,H.clone().add(new T(Math.cos(ang)*8*b,12*b,Math.sin(ang)*8*b)))}p(new xe(.35*b,.35*b,55*b,4),c,H.clone().add(new T(0,35*b,0)))}
else for(let z=0;z<Math.ceil(25*t.sceneryDensity);z++){const B=H.clone().add(new T((n()-.5)*13*b,0,(n()-.5)*13*b));B.y=s.surfaceHeight(B.x,B.z);const k=_.kind==="flora_cluster";!m(B.x,B.z,4*b)||k&&B.y<cn+1||(k?p(new Wn(.9*b,6*b,5),z%2?c:r,B.add(new T(0,3*b,0)),new T(1,.5+n(),1)):p(new _n(2*b),i,B,new T(1+n(),.7+n(),1+n())))}}
const R=[.1,.24,.41,.81,.96],C=Math.floor(210*t.sceneryDensity);
const _cupGeos=[
  [new _n(1,0),new _n(1,1),new Wn(.45,3,5)],
  [new Wn(.8,4,6),new _n(1.1,1),new He(1.2,2.5,1.2)],
  [new xe(.6,1.4,3,6),new hi(1.2),new _n(1.3,0)],
  [new $n(1.5,8,6),new Wn(.6,3.5,5),new hi(1.1)],
  [new xe(.7,.9,4,6),new _n(1.2,0),new hi(1.2)],
  [new hi(1.3),new He(1.1,1.1,1.1),new _n(1.2,1)]
];
const _cupCols=[
  [3771509,2390383,7645824,6520721],
  [2251816,5453860,10936878,15783326],
  [1839122,5377556,16729088,16759552],
  [5337738,11259875,13738997,16777215],
  [2373685,5324902,12427494,15783326],
  [854054,4530557,8192255,16711935]
];
const I=_cupGeos[curCup]||_cupGeos[0],$=_cupCols[curCup]||_cupCols[0];
for(let _=0;_<3;_++){const M=new yr(I[_],_===0?i:h,C);let b=0;for(let U=0;U<C*3&&b<C;U++){const G=U%R.length,H=s.sampleAtS((R[G]+(n()-.5)*.022)*s.totalLength),z=n()<.18,B=z?3+n()*4:.45+n()*1.25,k=(H.halfWidth+13+B*2+n()*(z?110:30))*(G%2?1:-1),st=H.pos.x+H.right.x*k,at=H.pos.z+H.right.z*k;if(!m(st,at,B*2))continue;const ft=s.surfaceHeight(st,at);_!==0&&ft<cn+1||(u.position.set(st,ft+(_===0?.3:B),at),u.scale.set(B,B*(_===1?.6:.8+n()*.3),B),u.rotation.set(0,n()*Math.PI*2,0),u.updateMatrix(),M.setMatrixAt(b,u.matrix),M.setColorAt(b,new Gt($[_===0?3:Math.floor(n()*3)])),b++)}M.count=b,M.instanceMatrix.needsUpdate=!0,M.computeBoundingSphere(),M.castShadow=t.shadows,e.add(M)}`;

src = src.substring(0, startIdx) + replacement + src.substring(endIdx);
fs.writeFileSync(bundlePath, src, 'utf8');
console.log('Successfully updated Kg landmarks in ' + bundlePath);
