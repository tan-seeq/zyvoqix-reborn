groundUV = uv;
