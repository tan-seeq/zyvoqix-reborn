import { BrowserRouter, Route, Routes } from "react-router-dom";

import GamePage from "./pages/GamePage";
import HelpPage from "./pages/HelpPage";

export default function App() {
    return (
        <BrowserRouter basename={import.meta.env.BASE_URL}>
            <Routes>
                <Route path="/" element={<GamePage />} />
                <Route path="/help" element={<HelpPage />} />
            </Routes>
        </BrowserRouter>
    );
}
