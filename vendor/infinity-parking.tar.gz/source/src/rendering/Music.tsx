import { useEffect, useRef } from "react";

const MUSIC_VOLUME = 1.0;
const FX_VOLUME = 0.05;

const TRACKS = ["./music/Hot Swing.mp3", "./music/George Street Shuffle.mp3"];

interface MusicProps {
    playing: boolean;
    soundFX: boolean;
}

interface WindowWithWebkitAudioContext extends Window {
    webkitAudioContext?: typeof AudioContext;
}

export function Music({ playing, soundFX }: MusicProps) {
    const audioContextRef = useRef<AudioContext | null>(null);

    const bgMusicRef = useRef<HTMLAudioElement | null>(null);
    const fxMusicRef = useRef<HTMLAudioElement | null>(null);

    const currentTrackIndexRef = useRef<number>(-1);
    const playingRef = useRef(playing);

    useEffect(() => {
        playingRef.current = playing;
    }, [playing]);

    useEffect(() => {
        if (TRACKS.length === 0) return;

        const AudioContextClass =
            window.AudioContext || (window as WindowWithWebkitAudioContext).webkitAudioContext;

        const ctx = new AudioContextClass();
        audioContextRef.current = ctx;

        // --- MUSIC ---
        const initialIndex = Math.floor(Math.random() * TRACKS.length);
        currentTrackIndexRef.current = initialIndex;

        const bgAudio = new Audio(TRACKS[initialIndex]);
        bgMusicRef.current = bgAudio;

        const musicSource = ctx.createMediaElementSource(bgAudio);
        const musicGain = ctx.createGain();

        musicGain.gain.value = MUSIC_VOLUME;
        musicSource.connect(musicGain).connect(ctx.destination);

        const handleTrackEnded = () => {
            if (TRACKS.length === 0) return;

            let nextIndex = Math.floor(Math.random() * TRACKS.length);
            if (TRACKS.length > 1 && nextIndex === currentTrackIndexRef.current) {
                nextIndex = (nextIndex + 1) % TRACKS.length;
            }

            currentTrackIndexRef.current = nextIndex;
            bgAudio.src = TRACKS[nextIndex];

            if (playingRef.current) {
                bgAudio.play().catch(console.error);
            }
        };

        bgAudio.addEventListener("ended", handleTrackEnded);

        // --- FX ---
        const fxAudio = new Audio(
            "./sounds/freesound_community-ambiance-exterieur-ville-34870.mp3"
        );
        fxAudio.loop = true;
        fxMusicRef.current = fxAudio;

        const fxSource = ctx.createMediaElementSource(fxAudio);
        const fxGain = ctx.createGain();

        fxGain.gain.value = FX_VOLUME;
        fxSource.connect(fxGain).connect(ctx.destination);

        return () => {
            bgAudio.removeEventListener("ended", handleTrackEnded);
            bgAudio.pause();
            fxAudio.pause();
            ctx.close();
        };
    }, []);

    useEffect(() => {
        const ctx = audioContextRef.current;
        const music = bgMusicRef.current;
        const fx = fxMusicRef.current;

        if (!ctx || !music || !fx) return;

        if (playing) {
            if (ctx.state === "suspended") {
                ctx.resume();
            }
            music.play().catch(console.error);
        } else {
            music.pause();
        }

        if (soundFX) {
            if (ctx.state === "suspended") {
                ctx.resume();
            }
            fx.play().catch(console.error);
        } else {
            fx.pause();
        }
    }, [playing, soundFX]);

    return null;
}
