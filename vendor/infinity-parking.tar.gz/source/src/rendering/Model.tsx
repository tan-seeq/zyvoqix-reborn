import { memo, useMemo } from "react";

import type { ThreeEvent } from "@react-three/fiber";
import * as THREE from "three";
import { Group, type Object3DEventMap } from "three";

interface ModelProps {
    model: Group<Object3DEventMap>;
    x: number;
    z: number;
    y?: number;
    rotationY: number;
    onClick?: (event: ThreeEvent<MouseEvent>) => void;
    isClickable?: boolean;
}

const globalTexture = new THREE.TextureLoader().load("./models/citybits_texture.png");
globalTexture.colorSpace = THREE.SRGBColorSpace;
globalTexture.flipY = false;

export default memo(function Model({
    model,
    x,
    z,
    y = 0,
    rotationY,
    onClick,
    isClickable = false,
}: ModelProps) {
    const clonedModel = useMemo(() => {
        if (!model) return null;
        const clone = model.clone();

        clone.traverse((child) => {
            if ((child as THREE.Mesh).isMesh && (child as THREE.Mesh).material !== undefined) {
                const mesh = child as THREE.Mesh;

                mesh.material = new THREE.MeshStandardMaterial({
                    map: globalTexture,
                    roughness: 1,
                    metalness: 0,
                });
            }
        });

        return clone;
    }, [model]);

    if (!model || !clonedModel) return null;

    return (
        <primitive
            object={clonedModel}
            position={[x, y, z]}
            rotation={[0, rotationY, 0]}
            onClick={
                isClickable
                    ? onClick
                    : (event: ThreeEvent<MouseEvent>) => {
                          event.stopPropagation();
                      }
            }
            onPointerOver={(e: ThreeEvent<PointerEvent>) => {
                e.stopPropagation();
                document.body.style.cursor = isClickable ? "pointer" : "auto";
            }}
            onPointerOut={(e: ThreeEvent<PointerEvent>) => {
                e.stopPropagation();
                document.body.style.cursor = "auto";
            }}
        />
    );
});
