import { Environment } from "@react-three/drei";

interface LightProps {
    isNight?: boolean;
}

export function Light({ isNight = false }: LightProps) {
    const config = isNight
        ? {
              background: "#0b0e14",

              sunColor: "#88aaff",
              sunIntensity: 0.8,
              sunPosition: [10, 30, -10] as [number, number, number],

              hemiSky: "#1d263b",
              hemiGround: "#080c15",
              hemiIntensity: 0.4,

              ambientColor: "#151c28",
              ambientIntensity: 0.3,

              envIntensity: 0.05,
              envPreset: "night" as const,
          }
        : {
              background: "#78b7f5",

              sunColor: "#ffda9e",
              sunIntensity: 3.2,
              sunPosition: [30, 35, 20] as [number, number, number],

              hemiSky: "#93cbff",
              hemiGround: "#8a6243",
              hemiIntensity: 0.8,

              ambientColor: "#ffe8d1",
              ambientIntensity: 0.4,

              envIntensity: 0.3,
              envPreset: "sunset" as const,
          };

    return (
        <>
            <color attach="background" args={[config.background]} />

            <directionalLight
                castShadow
                intensity={config.sunIntensity}
                color={config.sunColor}
                position={config.sunPosition}
                shadow-mapSize={[2048, 2048]}
                shadow-bias={-0.0002}
                shadow-camera-left={-35}
                shadow-camera-right={35}
                shadow-camera-top={35}
                shadow-camera-bottom={-35}
            />

            <hemisphereLight
                color={config.hemiSky}
                groundColor={config.hemiGround}
                intensity={config.hemiIntensity}
            />

            <ambientLight color={config.ambientColor} intensity={config.ambientIntensity} />

            <Environment preset={config.envPreset} environmentIntensity={config.envIntensity} />
        </>
    );
}
