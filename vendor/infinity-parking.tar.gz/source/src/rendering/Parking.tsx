import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";

import { useGLTF } from "@react-three/drei";
import { Group, type Object3DEventMap } from "three";

import { useGameStore } from "../store/useGameStore";
import {
    type Waypoint,
    findExitPath,
    findParkingBounds,
    offsetPathToLane,
} from "../utils/exitPath";
import { type Car, type LevelData } from "../utils/levelGenerator";
import DraggableCar from "./DraggableCar";
import Model from "./Model";

interface ParkingProps {
    parkingMap: LevelData;
    cityMap: string[][];

    width: number;
    height: number;
    tileSize: number;
    cellSize: number;

    isInteractive?: boolean;

    onCarExit?: (carId: string) => void;
    onLevelComplete?: () => void;
}

export const Parking = memo(function Parking({
    parkingMap,
    cityMap,

    width,
    height,
    tileSize,
    cellSize,

    isInteractive = true,

    onCarExit,
    onLevelComplete,
}: ParkingProps) {
    const { scene: modelObstacleA } = useGLTF("./models/box_A.gltf");
    const { scene: modelObstacleB } = useGLTF("./models/bush.gltf");
    const { scene: modelObstacleC } = useGLTF("./models/dumpster.gltf");
    const { scene: modelObstacleD } = useGLTF("./models/firehydrant.gltf");
    const { scene: modelObstacleE } = useGLTF("./models/bench.gltf");

    const { scene: modelCarA } = useGLTF("./models/car_hatchback.gltf");
    const { scene: modelCarB } = useGLTF("./models/car_police.gltf");
    const { scene: modelCarC } = useGLTF("./models/car_sedan.gltf");
    const { scene: modelCarD } = useGLTF("./models/car_stationwagon.gltf");
    const { scene: modelCarE } = useGLTF("./models/car_taxi.gltf");

    const cols = width * 4;
    const rows = height * 4;
    const centerOffsetCols = (cols - 1) / 2;
    const centerOffsetRows = (rows - 1) / 2;

    const parkingBounds = useMemo(() => findParkingBounds(cityMap), [cityMap]);

    const resetLevelTrigger = useGameStore((state) => state.resetLevel);
    const setCarsLeft = useGameStore((state) => state.setCarsLeft);

    const [cars, setCars] = useState<Car[]>(parkingMap.cars);
    const [exitPaths, setExitPaths] = useState<Record<string, Waypoint[]>>({});

    const completedRef = useRef(false);

    useEffect(() => {
        if (resetLevelTrigger > 0) {
            setCars(parkingMap.cars);
            setExitPaths({});
            completedRef.current = false;
        }
    }, [resetLevelTrigger, parkingMap.cars]);

    useEffect(() => {
        const remaining = cars.filter((c) => !exitPaths[c.id]).length;
        setCarsLeft(remaining);

        if (remaining === 0 && cars.length > 0 && !completedRef.current) {
            completedRef.current = true;
            queueMicrotask(() => onLevelComplete?.());
        }
    }, [cars, exitPaths, setCarsLeft, onLevelComplete]);

    const handleCarMove = useCallback((carId: string, newX: number, newY: number) => {
        setCars((prevCars) =>
            prevCars.map((c) => (c.id === carId ? { ...c, x: newX, y: newY } : c))
        );
    }, []);

    const handleCarExit = useCallback(
        (carId: string) => {
            setCars((prevCars) => prevCars.filter((c) => c.id !== carId));
            onCarExit?.(carId);
        },
        [onCarExit]
    );

    const handleCarExitStart = useCallback(
        (carId: string, newX: number, newY: number) => {
            const car = cars.find((c) => c.id === carId);

            if (!car || !parkingBounds) {
                handleCarExit(carId);
                return;
            }

            const isVertical = car.dir === "N" || car.dir === "S";
            let startRow: number;
            let startCol: number;

            if (isVertical) {
                const cityCol = parkingBounds.minCol + Math.floor(car.x / 4);
                startCol = Math.max(parkingBounds.minCol, Math.min(parkingBounds.maxCol, cityCol));
                startRow = newY < 0 ? parkingBounds.minRow - 1 : parkingBounds.maxRow + 1;
            } else {
                const cityRow = parkingBounds.minRow + Math.floor(car.y / 4);
                startRow = Math.max(parkingBounds.minRow, Math.min(parkingBounds.maxRow, cityRow));
                startCol = newX < 0 ? parkingBounds.minCol - 1 : parkingBounds.maxCol + 1;
            }

            const LANE_OFFSET = -(tileSize / 4) * 0.6;
            const path = findExitPath(cityMap, startRow, startCol, tileSize);

            if (!path) {
                handleCarExit(carId);
                return;
            }

            const lanedPath = offsetPathToLane(path, LANE_OFFSET);
            setExitPaths((prev) => ({ ...prev, [carId]: lanedPath }));
        },
        [cars, cityMap, parkingBounds, tileSize, handleCarExit]
    );

    const handleExitComplete = useCallback(
        (carId: string) => {
            setExitPaths((prev) => {
                const rest = { ...prev };
                delete rest[carId];
                return rest;
            });
            handleCarExit(carId);
        },
        [handleCarExit]
    );

    const activeCars = useMemo(() => cars.filter((c) => !exitPaths[c.id]), [cars, exitPaths]);

    const CAR_MODELS: Record<number, Group<Object3DEventMap>> = useMemo(
        () => ({
            1: modelCarA,
            2: modelCarB || modelCarA,
            3: modelCarC || modelCarA,
            4: modelCarD || modelCarA,
            5: modelCarE || modelCarA,
        }),
        [modelCarA, modelCarB, modelCarC, modelCarD, modelCarE]
    );

    const OBSTACLE_MODELS: Record<number, Group<Object3DEventMap>> = useMemo(
        () => ({
            1: modelObstacleA,
            2: modelObstacleB || modelObstacleA,
            3: modelObstacleC || modelObstacleA,
            4: modelObstacleD || modelObstacleA,
            5: modelObstacleE || modelObstacleA,
        }),
        [modelObstacleA, modelObstacleB, modelObstacleC, modelObstacleD, modelObstacleE]
    );

    return (
        <group>
            {parkingMap.obstacles.map((obs) => {
                const obsModel = OBSTACLE_MODELS[obs.style] || modelObstacleA;

                const posX = (obs.y - centerOffsetRows) * cellSize;
                const posZ = (obs.x - centerOffsetCols) * cellSize;

                let rotationY = 0;
                if (obs.dir === "N") rotationY = -Math.PI / 2;
                if (obs.dir === "S") rotationY = Math.PI / 2;
                if (obs.dir === "E") rotationY = 0;
                if (obs.dir === "W") rotationY = Math.PI;

                return (
                    <Model
                        key={`obstacle-${obs.x}-${obs.y}`}
                        model={obsModel}
                        x={posX}
                        z={posZ}
                        y={0.1}
                        rotationY={rotationY}
                    />
                );
            })}

            {cars.map((car) => {
                const carModel = CAR_MODELS[car.style] || modelCarA;

                let rotationY = 0;
                if (car.dir === "N") rotationY = -Math.PI / 2;
                if (car.dir === "S") rotationY = Math.PI / 2;
                if (car.dir === "E") rotationY = 0;
                if (car.dir === "W") rotationY = Math.PI;

                const getBasePosition = (cx: number, cy: number) => {
                    let tx = cx;
                    let ty = cy;
                    if (car.dir === "N") ty++;
                    else if (car.dir === "S") ty--;
                    else if (car.dir === "E") tx--;
                    else if (car.dir === "W") tx++;

                    const midX = (cy + ty) / 2;
                    const midZ = (cx + tx) / 2;
                    return {
                        x: (midX - centerOffsetRows) * cellSize,
                        z: (midZ - centerOffsetCols) * cellSize,
                    };
                };

                const basePos = getBasePosition(car.x, car.y);

                return isInteractive ? (
                    <DraggableCar
                        key={`car-${car.id}`}
                        car={car}
                        carModel={carModel}
                        rotationY={rotationY}
                        cols={cols}
                        rows={rows}
                        basePos={basePos}
                        obstacles={parkingMap.obstacles}
                        allCars={activeCars}
                        onMove={handleCarMove}
                        exitPath={exitPaths[car.id]}
                        resetSignal={resetLevelTrigger}
                        onExitStart={handleCarExitStart}
                        onExitComplete={handleExitComplete}
                    />
                ) : (
                    <group position={[basePos.x, 0, basePos.z]} key={`car-static-${car.id}`}>
                        <Model
                            model={carModel}
                            x={0}
                            z={0}
                            y={0.155}
                            rotationY={rotationY}
                            isClickable={false}
                        />
                    </group>
                );
            })}
        </group>
    );
});

useGLTF.preload("./models/box_A.gltf");
useGLTF.preload("./models/bush.gltf");
useGLTF.preload("./models/dumpster.gltf");
useGLTF.preload("./models/firehydrant.gltf");
useGLTF.preload("./models/bench.gltf");

useGLTF.preload("./models/car_hatchback.gltf");
useGLTF.preload("./models/car_police.gltf");
useGLTF.preload("./models/car_sedan.gltf");
useGLTF.preload("./models/car_stationwagon.gltf");
useGLTF.preload("./models/car_taxi.gltf");
