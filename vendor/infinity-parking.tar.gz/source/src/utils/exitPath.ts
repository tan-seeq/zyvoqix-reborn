export type Waypoint = { x: number; z: number };

export function findExitPath(
    map: string[][],
    startRow: number,
    startCol: number,
    tileSize: number,
    initialDir?: { dr: number; dc: number }
): Waypoint[] | null {
    const rows = map.length;
    const cols = map[0]?.length ?? 0;
    const rowOffset = (rows - 1) / 2;
    const colOffset = (cols - 1) / 2;

    const isRoad = (r: number, c: number) => map[r]?.[c] === "R";
    const dirs = [
        { dr: -1, dc: 0 },
        { dr: 1, dc: 0 },
        { dr: 0, dc: -1 },
        { dr: 0, dc: 1 },
    ];

    const initialCells: Array<{ r: number; c: number }> = [];
    if (isRoad(startRow, startCol)) {
        initialCells.push({ r: startRow, c: startCol });
    } else {
        for (const d of dirs) {
            const nr = startRow + d.dr;
            const nc = startCol + d.dc;
            if (isRoad(nr, nc)) initialCells.push({ r: nr, c: nc });
        }
    }
    if (initialCells.length === 0) return null;

    // 0-1 BFS : coût 0 pour continuer tout droit, coût 1 pour tourner.
    // Ça garde la voiture sur la trajectoire par laquelle elle est sortie
    // au lieu de la faire ressortir par le chemin le plus court en cases.
    const nodeKey = (r: number, c: number, dirIdx: number) => `${r},${c},${dirIdx}`;
    const dist = new Map<string, number>();
    const cameFrom = new Map<string, string | null>();
    const nodeInfo = new Map<string, { r: number; c: number; dirIdx: number }>();
    const deque: string[] = [];

    let defaultDirIdx = 0;
    if (initialDir) {
        const idx = dirs.findIndex((d) => d.dr === initialDir.dr && d.dc === initialDir.dc);
        if (idx !== -1) defaultDirIdx = idx;
    }

    for (const cell of initialCells) {
        const k = nodeKey(cell.r, cell.c, defaultDirIdx);
        if (!dist.has(k)) {
            dist.set(k, 0);
            cameFrom.set(k, null);
            nodeInfo.set(k, { r: cell.r, c: cell.c, dirIdx: defaultDirIdx });
            deque.push(k);
        }
    }

    let goal: string | null = null;

    while (deque.length > 0) {
        const k = deque.shift()!;
        const info = nodeInfo.get(k)!;
        const d = dist.get(k)!;

        const isBorder = info.r <= 0 || info.r >= rows - 1 || info.c <= 0 || info.c >= cols - 1;
        if (isBorder) {
            goal = k;
            break;
        }

        for (let i = 0; i < dirs.length; i++) {
            const dd = dirs[i];
            const nr = info.r + dd.dr;
            const nc = info.c + dd.dc;
            if (!isRoad(nr, nc)) continue;

            const cost = i === info.dirIdx ? 0 : 1;
            const nk = nodeKey(nr, nc, i);
            const nd = d + cost;

            if (!dist.has(nk) || nd < dist.get(nk)!) {
                dist.set(nk, nd);
                cameFrom.set(nk, k);
                nodeInfo.set(nk, { r: nr, c: nc, dirIdx: i });
                if (cost === 0) deque.unshift(nk);
                else deque.push(nk);
            }
        }
    }

    if (!goal) return null;

    const path: Array<{ r: number; c: number }> = [];
    let cur: string | null = goal;
    while (cur) {
        const info = nodeInfo.get(cur)!;
        path.unshift({ r: info.r, c: info.c });
        cur = cameFrom.get(cur)!;
    }

    return path.map((cell) => ({
        x: (cell.r - rowOffset) * tileSize,
        z: (cell.c - colOffset) * tileSize,
    }));
}

export function findParkingBounds(
    cityMap: string[][]
): { minRow: number; maxRow: number; minCol: number; maxCol: number } | null {
    let minRow = Infinity,
        maxRow = -Infinity,
        minCol = Infinity,
        maxCol = -Infinity;

    for (let r = 0; r < cityMap.length; r++) {
        for (let c = 0; c < cityMap[r].length; c++) {
            if (cityMap[r][c] === "P") {
                if (r < minRow) minRow = r;
                if (r > maxRow) maxRow = r;
                if (c < minCol) minCol = c;
                if (c > maxCol) maxCol = c;
            }
        }
    }

    if (minRow === Infinity) return null;
    return { minRow, maxRow, minCol, maxCol };
}

export function worldToCell(
    worldX: number,
    worldZ: number,
    tileSize: number,
    rows: number,
    cols: number
): { row: number; col: number } {
    const rowOffset = (rows - 1) / 2;
    const colOffset = (cols - 1) / 2;

    return {
        row: Math.round(worldX / tileSize + rowOffset),
        col: Math.round(worldZ / tileSize + colOffset),
    };
}

export function offsetPathToLane(path: Waypoint[], laneOffset: number): Waypoint[] {
    if (path.length < 2) return path;

    return path.map((p, i) => {
        const prev = path[i - 1] ?? path[i];
        const next = path[i + 1] ?? path[i];

        const dirX = next.x - prev.x;
        const dirZ = next.z - prev.z;
        const len = Math.hypot(dirX, dirZ) || 1;

        const perpX = dirZ / len;
        const perpZ = -dirX / len;

        return {
            x: p.x + perpX * laneOffset,
            z: p.z + perpZ * laneOffset,
        };
    });
}
