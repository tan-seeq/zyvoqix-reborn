const MIN_DIFFICULTY = 1.0;
const MAX_DIFFICULTY = 6.0;
const DIFFICULTY_SATURATION_K = 80;
const DIFFICULTY_MULTIPLIER = 5.0;

const MIN_MAP_SIZE = 2;
const MAX_MAP_SIZE = 4;

const WIDTH_SATURATION_K = 70;
const WIDTH_SEED_OFFSET = 101;

const HEIGHT_SATURATION_K = 95;
const HEIGHT_SEED_OFFSET = 307;

const NOISE_BASE_AMPLITUDE = 0.4;
const NOISE_GROWTH_FACTOR = 0.9;

const SEC_PER_CAR_3 = 1;
const SEC_PER_CAR_2 = 1.75;
const MIN_THREE_STARS = 20;
const MIN_TWO_STARS = 40;
const DIFFICULTY_STAR_FACTOR = 0.15;

function clamp(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, value));
}

function seededRandom(seed: number): number {
    let state = seed >>> 0;
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function saturating(level: number, k: number): number {
    return 1 - Math.exp(-level / k);
}

export function getDifficultyForLevel(level: number): number {
    const t = saturating(level, DIFFICULTY_SATURATION_K);
    const raw = MIN_DIFFICULTY + DIFFICULTY_MULTIPLIER * t;
    return clamp(Math.round(raw * 10) / 10, MIN_DIFFICULTY, MAX_DIFFICULTY);
}

function sizeForAxis(
    level: number,
    k: number,
    seedOffset: number,
    minSize: number,
    maxSize: number
): number {
    const t = saturating(level, k);
    const base = minSize + t * (maxSize - minSize);

    const noiseAmplitude = NOISE_BASE_AMPLITUDE + t * NOISE_GROWTH_FACTOR;

    const r = seededRandom(level * 31 + seedOffset);
    const noise = (r - 0.5) * 2 * noiseAmplitude;

    return clamp(Math.round(base + noise), minSize, maxSize);
}

export function getMapSizeForLevel(level: number): { width: number; height: number } {
    const width = sizeForAxis(
        level,
        WIDTH_SATURATION_K,
        WIDTH_SEED_OFFSET,
        MIN_MAP_SIZE,
        MAX_MAP_SIZE
    );
    const height = sizeForAxis(
        level,
        HEIGHT_SATURATION_K,
        HEIGHT_SEED_OFFSET,
        MIN_MAP_SIZE,
        MAX_MAP_SIZE
    );

    return { width, height };
}

export function getStarThresholds(
    numCars: number,
    difficulty: number
): { threeStars: number; twoStars: number } {
    const difficultyFactor = 1 + (difficulty - MIN_DIFFICULTY) * DIFFICULTY_STAR_FACTOR;

    const threeStars = Math.max(
        MIN_THREE_STARS,
        Math.round(numCars * SEC_PER_CAR_3 * difficultyFactor)
    );
    const twoStars = Math.max(
        MIN_TWO_STARS,
        Math.round(numCars * SEC_PER_CAR_2 * difficultyFactor)
    );

    return { threeStars, twoStars };
}
