export type Direction = "N" | "S" | "E" | "W";

export interface Car {
    id: string;
    dir: Direction;
    x: number;
    y: number;
    style: number;
}

export interface Obstacle {
    x: number;
    y: number;
    style: number;
    dir: Direction;
}

export interface LevelData {
    cars: Car[];
    obstacles: Obstacle[];
}

export class LevelGenerator {
    private sizeWidth: number;
    private sizeHeight: number;
    private difficulty: number;
    private random: () => number;
    private levelData: LevelData;

    private grid!: boolean[][];

    constructor(width: number, height: number, seed: number, difficulty: number) {
        this.sizeWidth = width;
        this.sizeHeight = height;
        this.difficulty = difficulty;
        this.random = this.randomGenerator(seed);
        this.levelData = { cars: [], obstacles: [] };
    }

    private getCarCells(x: number, y: number, dir: Direction) {
        let tx = x;
        let ty = y;
        if (dir === "N") ty++;
        if (dir === "S") ty--;
        if (dir === "E") tx--;
        if (dir === "W") tx++;
        return { fx: x, fy: y, bx: tx, by: ty };
    }

    private isFree(x: number, y: number, cols: number, rows: number): boolean {
        if (x < 0 || x >= cols || y < 0 || y >= rows) return false;
        return !this.grid[y][x];
    }

    public generateParking(): LevelData {
        if (this.levelData.cars.length > 0 || this.levelData.obstacles.length > 0)
            return this.levelData;

        const cols = this.sizeWidth * 4;
        const rows = this.sizeHeight * 4;
        const totalCells = cols * rows;

        // 1. Initialization of the collision grid (false = empty, true = busy)
        this.grid = Array.from({ length: rows }, () => Array(cols).fill(false));

        const safeDifficulty = Math.min(this.difficulty, 6);
        const densityFactor = 0.25 + safeDifficulty * 0.08;
        const targetCars = Math.floor((totalCells * densityFactor) / 2);
        const numObstacles = Math.floor(totalCells * (0.02 * this.difficulty));

        const cars: Car[] = [];
        const obstacles: Obstacle[] = [];
        const dirs: Direction[] = ["N", "S", "E", "W"];

        // 2. Placement of obstacles
        let obsPlaced = 0;
        let fails = 0;
        while (obsPlaced < numObstacles && fails < 200) {
            const x = Math.floor(this.random() * cols);
            const y = Math.floor(this.random() * rows);

            if (!this.grid[y][x]) {
                this.grid[y][x] = true;
                obstacles.push({
                    x,
                    y,
                    style: Math.floor(this.random() * 5) + 1,
                    dir: dirs[Math.floor(this.random() * 4)],
                });
                obsPlaced++;
            } else {
                fails++;
            }
        }

        //3. Placement of cars in “Reverse”
        fails = 0;
        while (cars.length < targetCars && fails < 1500) {
            const dir = dirs[Math.floor(this.random() * 4)];
            let startX = 0,
                startY = 0;
            let dx = 0,
                dy = 0;

            if (dir === "N") {
                startX = Math.floor(this.random() * cols);
                startY = 0;
                dy = 1;
            } else if (dir === "S") {
                startX = Math.floor(this.random() * cols);
                startY = rows - 1;
                dy = -1;
            } else if (dir === "W") {
                startX = 0;
                startY = Math.floor(this.random() * rows);
                dx = 1;
            } else if (dir === "E") {
                startX = cols - 1;
                startY = Math.floor(this.random() * rows);
                dx = -1;
            }

            const startCells = this.getCarCells(startX, startY, dir);
            if (
                !this.isFree(startCells.fx, startCells.fy, cols, rows) ||
                !this.isFree(startCells.bx, startCells.by, cols, rows)
            ) {
                fails++;
                continue;
            }

            let maxDepth = 0;
            let currentX = startX;
            let currentY = startY;

            while (true) {
                const nextX = currentX + dx;
                const nextY = currentY + dy;
                const nextCells = this.getCarCells(nextX, nextY, dir);

                if (
                    !this.isFree(nextCells.fx, nextCells.fy, cols, rows) ||
                    !this.isFree(nextCells.bx, nextCells.by, cols, rows)
                ) {
                    break;
                }

                currentX = nextX;
                currentY = nextY;
                maxDepth++;
            }

            const depthFactor = Math.sqrt(this.random());
            const chosenDepth = Math.floor(depthFactor * (maxDepth + 1));

            const finalX = startX + dx * Math.min(chosenDepth, maxDepth);
            const finalY = startY + dy * Math.min(chosenDepth, maxDepth);
            const finalCells = this.getCarCells(finalX, finalY, dir);

            const styleWeights = {
                1: 10,
                2: 3,
                3: 10,
                4: 10,
                5: 10,
            };

            const totalWeight = Object.values(styleWeights).reduce((sum, w) => sum + w, 0);
            let randomRoll = this.random() * totalWeight;
            let chosenStyle = 1;

            for (const [style, weight] of Object.entries(styleWeights)) {
                randomRoll -= weight;
                if (randomRoll <= 0) {
                    chosenStyle = Number(style);
                    break;
                }
            }

            this.grid[finalCells.fy][finalCells.fx] = true;
            this.grid[finalCells.by][finalCells.bx] = true;

            cars.push({
                id: `car-${cars.length}`,
                dir,
                x: finalX,
                y: finalY,
                style: chosenStyle,
            });

            fails = 0;
        }

        this.levelData = { cars, obstacles };
        return this.levelData;
    }

    private randomGenerator(seed: number): () => number {
        let state = seed >>> 0;
        return function () {
            state = (state + 0x6d2b79f5) >>> 0;
            let t = state;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
}
