import { useState } from "react";

import { useGameStore } from "../store/useGameStore";
import { useSettingStore } from "../store/useSettingStore";
import PopUp from "./PopUp";

export default function Setting({ onBack }: { onBack: () => void }) {
    const music = useSettingStore((state) => state.music);
    const soundFX = useSettingStore((state) => state.soundFX);
    const debugMode = useSettingStore((state) => state.debugMode);
    const easyMode = useSettingStore((state) => state.easyMode);

    const actions = useSettingStore((state) => state.actions);
    const clearProgress = useGameStore((state) => state.clearProgress);

    const [isPopUpOpen, setIsPopUpOpen] = useState(false);

    const handleReset = () => {
        clearProgress();
        setIsPopUpOpen(false);
    };

    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                position: "relative",
                display: "flex",
                alignItems: "flex-start",
                pointerEvents: "auto",
            }}
        >
            <div
                className="menu-container"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    height: "500px",
                    width: "400px",
                    maxWidth: "400px",
                    padding: "32px",
                    alignItems: "stretch",
                    justifyContent: "flex-start",
                    gap: "14px",
                }}
            >
                <h1 style={{ fontSize: "40px", lineHeight: "40px" }}>Settings</h1>

                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                    }}
                >
                    <button
                        className={music ? "primary" : "secondary"}
                        style={{
                            padding: "12px 14px",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            fontSize: "16px",
                        }}
                        onClick={() => actions.setMusic(!music)}
                    >
                        <span>Music</span>
                        <span style={{ opacity: 0.7 }}>{music ? "On" : "Off"}</span>
                    </button>
                    <button
                        className={soundFX ? "primary" : "secondary"}
                        style={{
                            padding: "12px 14px",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            fontSize: "16px",
                        }}
                        onClick={() => actions.setSoundFX(!soundFX)}
                    >
                        <span>Sound FX</span>
                        <span style={{ opacity: 0.7 }}>{soundFX ? "On" : "Off"}</span>
                    </button>
                    <button
                        className={easyMode ? "primary" : "secondary"}
                        style={{
                            padding: "12px 14px",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            fontSize: "16px",
                        }}
                        onClick={() => actions.setEasyMode(!easyMode)}
                    >
                        <span>Easy Mode</span>
                        <span style={{ opacity: 0.7 }}>{easyMode ? "On" : "Off"}</span>
                    </button>
                    <button
                        className={debugMode ? "primary" : "secondary"}
                        style={{
                            padding: "12px 14px",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            fontSize: "16px",
                        }}
                        onClick={() => actions.setDebugMode(!debugMode)}
                    >
                        <span>Debug Mode</span>
                        <span style={{ opacity: 0.7 }}>{debugMode ? "On" : "Off"}</span>
                    </button>

                    <button
                        className="danger"
                        style={{
                            padding: "12px 14px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            fontSize: "16px",
                            textAlign: "center",
                            marginTop: "20px",
                        }}
                        onClick={() => setIsPopUpOpen(true)}
                    >
                        <span>Reset Progress</span>
                    </button>
                </div>
            </div>

            <button
                title="Back"
                className="game-container element-not-selectable"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, calc(-50% - 310px))",
                    width: "120px",
                    height: "42px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    pointerEvents: "auto",
                }}
                onClick={onBack}
            >
                Back
            </button>

            {isPopUpOpen && (
                <PopUp
                    title="Reset Progress"
                    message="Are you sure you want to reset your progress?"
                    onYes={handleReset}
                    onNo={() => setIsPopUpOpen(false)}
                />
            )}
        </div>
    );
}
