import { useState } from "react";

import { useGameStore } from "../store/useGameStore";

export default function Level({
    onBack,
    onNavigate,
}: {
    onBack: () => void;
    onNavigate: (target: number) => void;
}) {
    const unlockedLevel = useGameStore((state) => state.unlockedLevel);
    const levelStars = useGameStore((state) => state.levelStars);

    const [currentPage, setCurrentPage] = useState(
        unlockedLevel > 20 ? Math.floor((unlockedLevel - 1) / 20) + 1 : 1
    );

    const totalStars = Object.values(levelStars).reduce((accumulator, currentStars) => {
        return accumulator + currentStars;
    }, 0);

    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                position: "relative",
                display: "flex",
                alignItems: "flex-start",
                pointerEvents: "auto",
            }}
        >
            <div
                className="menu-container"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    height: "500px",
                    width: "400px",
                    maxWidth: "400px",
                    padding: "32px 32px 10px 32px",
                    alignItems: "stretch",
                    justifyContent: "space-between",
                    gap: "14px",
                }}
            >
                <div key={currentPage} className="level-page">
                    {[...Array(5)].map((_, row) => (
                        <div key={row} style={{ display: "flex", gap: "14px", height: "100%" }}>
                            {[...Array(4)].map((_, col) => {
                                const currentLevel = col + 1 + row * 4 + (currentPage - 1) * 20;

                                const isLevelUnlocked = currentLevel <= unlockedLevel;
                                const starsCount = levelStars[currentLevel] || 0;

                                return (
                                    <button
                                        key={col}
                                        title={`${!isLevelUnlocked ? "[Locked]" : ""} Level ${currentLevel}`}
                                        className="tertiary element-not-selectable"
                                        style={{
                                            height: "100%",
                                            borderRadius: "var(--radius-md)",
                                            flexDirection: "column",
                                            gap: "0",
                                            backgroundColor: !isLevelUnlocked
                                                ? "#575a60"
                                                : undefined,
                                            border: !isLevelUnlocked
                                                ? "4px solid #8e8989"
                                                : undefined,
                                            cursor: isLevelUnlocked ? "pointer" : "default",
                                        }}
                                        disabled={!isLevelUnlocked}
                                        onClick={() => onNavigate(currentLevel)}
                                    >
                                        {isLevelUnlocked ? (
                                            <>
                                                <div
                                                    style={{
                                                        display: "flex",
                                                        flexDirection: "row",
                                                        alignItems: "center",
                                                        justifyContent: "space-between",
                                                        gap: "2px",
                                                    }}
                                                >
                                                    {[...Array(3)].map((_, starIndex) => (
                                                        <img
                                                            key={starIndex}
                                                            src="./ui/star.svg"
                                                            alt="Star"
                                                            style={{
                                                                width: "14px",
                                                                height: "14px",
                                                                display: "inline-block",
                                                                filter:
                                                                    starIndex < starsCount
                                                                        ? "brightness(0) saturate(100%) invert(74%) sepia(69%) saturate(757%) hue-rotate(359deg) brightness(107%) contrast(105%)"
                                                                        : "brightness(0) saturate(100%) invert(87%) sepia(0%) saturate(977%) hue-rotate(281deg) brightness(93%) contrast(83%)",
                                                            }}
                                                        />
                                                    ))}
                                                </div>
                                                <span
                                                    style={{
                                                        lineHeight: "40px",
                                                    }}
                                                >
                                                    {currentLevel}
                                                </span>
                                            </>
                                        ) : (
                                            <img
                                                src="./ui/lock.svg"
                                                alt="Level Locked"
                                                style={{
                                                    width: "44px",
                                                    height: "44px",
                                                    display: "inline-block",
                                                    opacity: "0.5",
                                                }}
                                            />
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                    ))}

                    <span
                        className="element-not-selectable"
                        style={{
                            opacity: "0.8",
                        }}
                    >
                        Page {currentPage} of
                        <img
                            src="./ui/infinite.svg"
                            alt="Infinite"
                            style={{
                                width: "20px",
                                height: "20px",
                                display: "inline-block",
                                marginLeft: "4px",
                                translate: "0px -1px",
                            }}
                        />
                    </span>
                </div>
            </div>
            <div
                className="menu-container"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, calc(-50% + 310px))",
                    height: "70px",
                    width: "400px",
                    maxWidth: "400px",
                    alignItems: "stretch",
                    justifyContent: "center",
                    gap: "0px",
                }}
            >
                <div>
                    Level Unlocked: {unlockedLevel} /
                    <img
                        src="./ui/infinite.svg"
                        alt="Infinite"
                        style={{
                            width: "20px",
                            height: "20px",
                            display: "inline-block",
                            marginLeft: "4px",
                            translate: "0px -1px",
                        }}
                    />
                </div>
                <div>
                    Total Stars: {totalStars} / {unlockedLevel * 3}
                </div>
            </div>

            {currentPage > 1 && (
                <button
                    title="Previous Page"
                    className="game-container"
                    style={{
                        width: "42px",
                        height: "42px",
                        top: "50%",
                        left: "50%",
                        position: "absolute",
                        transform: "translate(calc(-50% - 235px), -50%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        pointerEvents: "auto",
                        backgroundColor: "var(--secondary-color)",
                    }}
                    onClick={() => setCurrentPage(currentPage - 1)}
                >
                    <img
                        draggable="false"
                        className="element-not-selectable"
                        src="./ui/chevron.svg"
                        alt="Previous Page"
                        style={{
                            width: "70%",
                            height: "70%",
                            rotate: "180deg",
                        }}
                    />
                </button>
            )}
            <button
                title="Next Page"
                className="game-container"
                style={{
                    width: "42px",
                    height: "42px",
                    top: "50%",
                    left: "50%",
                    position: "absolute",
                    transform: "translate(calc(-50% + 235px), -50%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    pointerEvents: "auto",
                    backgroundColor: "var(--secondary-color)",
                }}
                onClick={() => setCurrentPage(currentPage + 1)}
            >
                <img
                    draggable="false"
                    className="element-not-selectable"
                    src="./ui/chevron.svg"
                    alt="Next Page"
                    style={{
                        width: "70%",
                        height: "70%",
                    }}
                />
            </button>

            <button
                title="Back"
                className="game-container element-not-selectable"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, calc(-50% - 310px))",
                    width: "120px",
                    height: "42px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    pointerEvents: "auto",
                }}
                onClick={onBack}
            >
                Back
            </button>
        </div>
    );
}
