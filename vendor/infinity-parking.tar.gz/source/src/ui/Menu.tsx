import { Link } from "react-router-dom";

export default function Menu({
    onNavigate,
}: {
    onNavigate: (target: "levels" | "settings" | "games") => void;
}) {
    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                position: "relative",
                display: "flex",
                alignItems: "flex-start",
                pointerEvents: "auto",
            }}
        >
            <div
                className="menu-container"
                style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    height: "500px",
                    width: "375px",
                    padding: "32px",
                }}
            >
                <h1 style={{ fontSize: "56px", marginBottom: "20px", lineHeight: "52px" }}>
                    Infinity Parking
                </h1>

                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        flexWrap: "nowrap",
                        gap: "20px",
                        width: "100%",
                    }}
                >
                    <div
                        style={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            flexWrap: "nowrap",
                            gap: "20px",
                            width: "100%",
                        }}
                    >
                        <button
                            title="Play"
                            className="primary element-not-selectable"
                            onClick={() => onNavigate("games")}
                        >
                            <img src="./ui/play.svg" alt="Play" style={{ width: "44px" }} />
                            <span>Play</span>
                        </button>
                        <button
                            title="Levels"
                            className="secondary element-not-selectable"
                            onClick={() => onNavigate("levels")}
                        >
                            <img src="./ui/levels.svg" alt="Levels" style={{ width: "34px" }} />
                            <span>Levels</span>
                        </button>
                        <button
                            title="Coming Soon"
                            className="secondary element-not-selectable"
                            onClick={() => {}}
                            disabled={true}
                            style={{
                                opacity: 0.5,
                                pointerEvents: "none",
                            }}
                        >
                            {/* <img src="./ui/settings.svg" alt="Settings" style={{ width: "34px" }} /> */}
                            <span>Coming Soon</span>
                        </button>
                    </div>

                    <div
                        style={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            flexWrap: "nowrap",
                            width: "100%",
                            justifyContent: "space-between",
                            gap: "12px",
                        }}
                    >
                        {/* <button
                            title="Trophies"
                            className="secondary element-not-selectable"
                            onClick={() => {}}
                            style={{
                                width: "100%",
                                minWidth: "50px",
                                height: "50px",
                                minHeight: "50px",
                                maxHeight: "50px",
                            }}
                        >
                            <img src="./ui/trophy.svg" alt="Trophy" style={{ width: "34px" }} />
                        </button> */}

                        {/* <button
                            title="Share"
                            className="secondary element-not-selectable"
                            onClick={() => {}}
                            style={{
                                width: "100%",
                                minWidth: "50px",
                                maxWidth: "50px",
                                minHeight: "50px",
                                maxHeight: "50px",
                            }}
                        >
                            <img
                                src="./ui/share-social.svg"
                                alt="Share"
                                style={{ width: "34px" }}
                            />
                        </button> */}

                        <button
                            title="Options"
                            className="secondary element-not-selectable"
                            onClick={() => onNavigate("settings")}
                            style={{
                                width: "100%",
                                minWidth: "50px",
                                height: "50px",
                                minHeight: "50px",
                                maxHeight: "50px",
                            }}
                        >
                            <img src="./ui/settings.svg" alt="Settings" style={{ width: "25px" }} />
                        </button>

                        <Link
                            to="/help"
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Help"
                            className="link secondary element-not-selectable"
                            style={{
                                width: "100%",
                                minWidth: "50px",
                                height: "50px",
                                minHeight: "50px",
                                maxHeight: "50px",
                            }}
                        >
                            <img src="./ui/help.svg" alt="Help" style={{ width: "30px" }} />
                        </Link>

                        <button
                            title="Github"
                            className="secondary element-not-selectable"
                            onClick={() =>
                                window.open(
                                    "https://github.com/CapyBlaze/Infinity-Parking",
                                    "_blank"
                                )
                            }
                            style={{
                                width: "100%",
                                minWidth: "50px",
                                height: "50px",
                                minHeight: "50px",
                                maxHeight: "50px",
                            }}
                        >
                            <img src="./ui/github.svg" alt="Github" style={{ width: "30px" }} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
