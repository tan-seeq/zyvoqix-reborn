export default function PopUp({
    title,
    message,
    onYes,
    onNo,
}: {
    title: string;
    message: string;
    onYes: () => void;
    onNo: () => void;
}) {
    return (
        <div
            className="menu-container"
            style={{
                position: "absolute",
                zIndex: 100,
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                backgroundColor: "var(--tertiary-color)",
                padding: "20px",
                pointerEvents: "auto",
                maxWidth: "360px",
            }}
        >
            <div>
                <h2
                    style={{
                        fontSize: "24px",
                    }}
                >
                    {title}
                </h2>
                <p
                    style={{
                        textTransform: "none",
                        fontSize: "16px",
                    }}
                >
                    {message}
                </p>
                <div
                    style={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: "25px",
                        marginTop: "20px",
                    }}
                >
                    <button className="small" onClick={onYes}>
                        Yes
                    </button>
                    <button className="small" onClick={onNo}>
                        No
                    </button>
                </div>
            </div>
        </div>
    );
}
