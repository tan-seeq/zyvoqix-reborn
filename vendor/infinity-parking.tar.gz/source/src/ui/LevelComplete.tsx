export default function LevelComplete({
    level,
    stars,
    time,
    onMenu,
    onNextLevel,
    onResetLevel,
}: {
    level: number;
    stars: number;
    time: number;
    onMenu: () => void;
    onNextLevel: () => void;
    onResetLevel: () => void;
}) {
    return (
        <div
            className="menu-container"
            style={{
                position: "absolute",
                zIndex: 100,
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                height: "460px",
                width: "375px",
                maxWidth: "375px",
                padding: "32px",
                pointerEvents: "auto",
            }}
        >
            <h1
                className="element-not-selectable"
                style={{
                    fontSize: "40px",
                    marginBottom: "6px",
                    lineHeight: "40px",
                    textAlign: "center",
                }}
            >
                Level {level} Complete!
            </h1>
            <div
                className="element-not-selectable"
                style={{
                    textAlign: "center",
                    opacity: 0.8,
                    fontSize: "20px",
                    height: "30px",
                }}
            >
                {Math.floor(time / 60)
                    .toString()
                    .padStart(2, "0")}
                :{(time % 60).toString().padStart(2, "0")}
            </div>

            <div
                className="element-not-selectable"
                style={{
                    display: "flex",
                    justifyContent: "center",
                    gap: "10px",
                    marginBottom: "12px",
                }}
            >
                {[...Array(3)].map((_, i) => (
                    <img
                        key={i}
                        src="./ui/star.svg"
                        alt="Star"
                        style={{
                            width: "52px",
                            height: "52px",
                            filter:
                                i < stars
                                    ? "brightness(0) saturate(100%) invert(74%) sepia(69%) saturate(757%) hue-rotate(359deg) brightness(107%) contrast(105%)"
                                    : "brightness(0) saturate(100%) invert(87%) sepia(0%) saturate(977%) hue-rotate(281deg) brightness(93%) contrast(83%)",
                        }}
                    />
                ))}
            </div>

            <div
                style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    flexWrap: "nowrap",
                    gap: "20px",
                    width: "100%",
                    marginTop: "auto",
                }}
            >
                <div
                    style={{
                        width: "100%",
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "space-between",
                        gap: "10px",
                    }}
                >
                    <button
                        title="Next Level"
                        className="primary element-not-selectable"
                        onClick={onNextLevel}
                        style={{
                            fontSize: "26px",
                        }}
                    >
                        <img src="./ui/play.svg" alt="Next Level" style={{ width: "36px" }} />
                        <span>Next Level</span>
                    </button>
                    <button
                        title="Reset Level"
                        className="primary element-not-selectable"
                        onClick={onResetLevel}
                        style={{
                            width: "60px",
                            minWidth: "60px",
                            maxWidth: "60px",
                        }}
                    >
                        <img src="./ui/reload.svg" alt="Reset Level" style={{ width: "36px" }} />
                    </button>
                </div>
                <button title="Menu" className="secondary element-not-selectable" onClick={onMenu}>
                    <img src="./ui/home.svg" alt="Menu" style={{ width: "34px" }} />
                    <span>Menu</span>
                </button>
            </div>
        </div>
    );
}
