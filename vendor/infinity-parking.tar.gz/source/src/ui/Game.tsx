import { useState } from "react";

import { useGameStore } from "../store/useGameStore";
import PopUp from "./PopUp";
import Setting from "./Setting";

const GOLD_FILTER =
    "brightness(0) saturate(100%) invert(74%) sepia(69%) saturate(757%) hue-rotate(359deg) brightness(107%) contrast(105%)";
const GREY_FILTER =
    "brightness(0) saturate(100%) invert(87%) sepia(0%) saturate(977%) hue-rotate(281deg) brightness(93%) contrast(83%)";

interface GameProps {
    onNavigate: (target: "main") => void;
    starThresholds: { threeStars: number; twoStars: number };
}

export default function Game({ onNavigate, starThresholds }: GameProps) {
    const rotation = useGameStore((state) => state.cameraRotation);
    const setRotation = useGameStore((state) => state.setCameraRotation);
    const triggerResetLevel = useGameStore((state) => state.triggerResetLevel);

    const carsLeft = useGameStore((state) => state.carsLeft);

    const level = useGameStore((state) => state.level);
    const levelName = useGameStore((state) => state.levelName);

    const time = useGameStore((state) => state.time);
    const startTimer = useGameStore((state) => state.startTimer);
    const stopTimer = useGameStore((state) => state.stopTimer);

    const [showSettings, setShowSettings] = useState(false);
    const [showMenu, setShowMenu] = useState(false);

    const { threeStars, twoStars } = starThresholds;

    const liveStars = time <= threeStars ? 3 : time <= twoStars ? 2 : 1;

    let segmentStart = 0;
    let segmentEnd = threeStars;
    if (liveStars === 2) {
        segmentStart = threeStars;
        segmentEnd = twoStars;
    } else if (liveStars === 1) {
        segmentStart = twoStars;
        segmentEnd = twoStars;
    }

    const segmentDuration = Math.max(1, segmentEnd - segmentStart);
    const elapsedInSegment = Math.min(segmentDuration, Math.max(0, time - segmentStart));
    const remainingFraction = liveStars === 1 ? 1 : 1 - elapsedInSegment / segmentDuration;

    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                position: "absolute",
                top: 0,
                left: 0,
                pointerEvents: "none",
                display: "flex",
                alignItems: "flex-start",
            }}
        >
            <div
                style={{
                    position: "absolute",
                    left: "10px",
                    top: "10px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                    alignItems: "flex-start",
                }}
            >
                <div
                    className="game-container"
                    style={{
                        width: "fit-content",
                        height: "fit-content",
                        padding: "5px",
                        textTransform: "uppercase",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "flex-start",
                    }}
                >
                    <h1 style={{ fontSize: "22px" }}>
                        Level {level}: {levelName}
                    </h1>
                </div>

                <div
                    className="game-container"
                    style={{
                        width: "fit-content",
                        height: "fit-content",
                        display: "flex",
                        flexDirection: "column",
                        gap: "5px",
                        padding: "5px",
                    }}
                >
                    <div
                        style={{
                            display: "flex",
                            alignItems: "center",
                            flexDirection: "row",
                            flexWrap: "nowrap",
                            gap: "8px",
                        }}
                    >
                        {[...Array(3)].map((_, starIndex) => (
                            <img
                                key={starIndex}
                                src="./ui/star.svg"
                                alt="Star"
                                style={{
                                    width: "32px",
                                    height: "32px",
                                    display: "inline-block",
                                    transition: "filter 0.3s ease",
                                    filter: starIndex < liveStars ? GOLD_FILTER : GREY_FILTER,
                                }}
                            />
                        ))}
                    </div>

                    {liveStars > 1 && (
                        <div
                            style={{
                                width: "100%",
                                height: "5px",
                                borderRadius: "3px",
                                overflow: "hidden",
                                backgroundColor: "rgba(0,0,0,0.15)",
                            }}
                        >
                            <div
                                style={{
                                    width: `${remainingFraction * 100}%`,
                                    height: "100%",
                                    borderRadius: "3px",
                                    backgroundColor: "#ffdf80",
                                    transition: "width 1s linear",
                                }}
                            />
                        </div>
                    )}
                </div>
            </div>

            <div
                style={{
                    position: "absolute",
                    bottom: "20px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    pointerEvents: "auto",
                    padding: "0 14px",
                    boxSizing: "border-box",
                }}
            >
                <input
                    className="element-not-selectable slider-camera"
                    type="range"
                    style={{
                        width: "300px",
                        cursor: "pointer",
                    }}
                    min={0}
                    max={360}
                    value={rotation}
                    onChange={(e) => setRotation(Number(e.target.value))}
                />
            </div>

            <div
                style={{
                    position: "absolute",
                    right: "10px",
                    top: "10px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "8px",
                    alignItems: "flex-end",
                }}
            >
                <div
                    style={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        gap: "8px",
                    }}
                >
                    <div
                        className="game-container"
                        style={{
                            width: "fit-content",
                            height: "fit-content",
                            padding: "5px",
                            textTransform: "uppercase",
                            minWidth: "71px",
                            textAlign: "center",
                        }}
                    >
                        <h1 style={{ fontSize: "18px" }}>
                            {showSettings || showMenu
                                ? "Paused"
                                : Math.floor(time / 60)
                                      .toString()
                                      .padStart(2, "0") +
                                  ":" +
                                  (time % 60).toString().padStart(2, "0")}
                        </h1>
                    </div>
                    <div
                        className="game-container"
                        style={{
                            width: "fit-content",
                            height: "fit-content",
                            padding: "5px",
                            textTransform: "uppercase",
                            minWidth: "145px",
                            textAlign: "center",
                        }}
                    >
                        <h1 style={{ fontSize: "18px" }}>Cars Left: {carsLeft}</h1>
                    </div>
                </div>
                <div
                    style={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        gap: "8px",
                    }}
                >
                    <button
                        title="Home"
                        className="game-container"
                        style={{
                            width: "42px",
                            height: "42px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            cursor: "pointer",
                            pointerEvents: "auto",
                        }}
                        onClick={() => {
                            stopTimer();
                            setShowMenu(true);
                        }}
                    >
                        <img
                            draggable="false"
                            className="element-not-selectable"
                            src="./ui/home.svg"
                            alt="Home"
                            style={{ width: "60%", height: "60%" }}
                        />
                    </button>
                    <button
                        title="Reset Level"
                        className="game-container"
                        style={{
                            width: "42px",
                            height: "42px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            cursor: "pointer",
                            pointerEvents: "auto",
                        }}
                        onClick={triggerResetLevel}
                    >
                        <img
                            draggable="false"
                            className="element-not-selectable"
                            src="./ui/reload.svg"
                            alt="Repeat"
                            style={{ width: "60%", height: "60%" }}
                        />
                    </button>
                    <button
                        title="Settings"
                        className="game-container"
                        style={{
                            width: "42px",
                            height: "42px",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            cursor: "pointer",
                            pointerEvents: "auto",
                        }}
                        onClick={() => {
                            stopTimer();
                            setShowSettings(true);
                        }}
                    >
                        <img
                            draggable="false"
                            className="element-not-selectable"
                            src="./ui/settings.svg"
                            alt="Settings"
                            style={{ width: "60%", height: "60%" }}
                        />
                    </button>
                </div>
            </div>

            {(showMenu || showSettings) && (
                <div
                    style={{
                        width: "100vw",
                        height: "100vh",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        backgroundColor: "rgba(0, 0, 0, 0.5)",
                        pointerEvents: "auto",
                    }}
                />
            )}

            {showSettings && (
                <Setting
                    onBack={() => {
                        startTimer();
                        setShowSettings(false);
                    }}
                />
            )}

            {showMenu && (
                <PopUp
                    title="Main Menu"
                    message="Are you sure you want to return to the main menu?"
                    onYes={() => onNavigate("main")}
                    onNo={() => {
                        startTimer();
                        setShowMenu(false);
                    }}
                />
            )}
        </div>
    );
}
