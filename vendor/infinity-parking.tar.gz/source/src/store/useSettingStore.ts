import { create } from "zustand";
import { persist } from "zustand/middleware";

interface SettingState {
    music: boolean;
    soundFX: boolean;
    debugMode: boolean;
    easyMode: boolean;

    actions: {
        setMusic: (enabled: boolean) => void;
        setSoundFX: (enabled: boolean) => void;
        setDebugMode: (enabled: boolean) => void;
        setEasyMode: (enabled: boolean) => void;
    };
}

export const useSettingStore = create<SettingState>()(
    persist(
        (set) => ({
            music: true,
            soundFX: true,
            debugMode: false,
            easyMode: true,

            actions: {
                setMusic: (enabled: boolean) => set({ music: enabled }),
                setSoundFX: (enabled: boolean) => set({ soundFX: enabled }),
                setDebugMode: (enabled: boolean) => set({ debugMode: enabled }),
                setEasyMode: (enabled: boolean) => set({ easyMode: enabled }),
            },
        }),
        {
            name: "infinity-parking-save-settings",
            partialize: (state) => ({
                music: state.music,
                soundFX: state.soundFX,
                debugMode: state.debugMode,
                easyMode: state.easyMode,
            }),
        }
    )
);
