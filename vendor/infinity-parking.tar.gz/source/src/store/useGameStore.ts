import { create } from "zustand";
import { persist } from "zustand/middleware";

interface GameState {
    level: number;
    levelName: string;
    starsEarned: number;
    setLevel: (level: number, levelName: string, starsEarned: number) => void;

    unlockedLevel: number;
    levelStars: Record<number, number>;
    completeLevel: (level: number, stars: number) => void;

    time: number;
    isTimerRunning: boolean;
    incrementTime: () => void;
    startTimer: () => void;
    stopTimer: () => void;
    resetTimer: () => void;

    resetLevel: number;
    triggerResetLevel: () => void;
    cameraRotation: number;
    setCameraRotation: (angle: number) => void;

    carsLeft: number;
    setCarsLeft: (count: number) => void;

    clearProgress: () => void;
}

export const useGameStore = create<GameState>()(
    persist(
        (set) => ({
            level: 1,
            levelName: "Parking Lot",
            starsEarned: 0,
            setLevel: (level, levelName, starsEarned) => set({ level, levelName, starsEarned }),

            unlockedLevel: 1,
            levelStars: {},
            completeLevel: (level, stars) =>
                set((state) => ({
                    levelStars: {
                        ...state.levelStars,
                        [level]: Math.max(state.levelStars[level] ?? 0, stars),
                    },
                    unlockedLevel: Math.max(state.unlockedLevel, level + 1),
                    level,
                })),

            time: 0,
            isTimerRunning: false,
            incrementTime: () =>
                set((state) => ({ time: Math.min(Math.max(state.time + 1, 0), 60 * 99 - 1) })),
            startTimer: () => set({ isTimerRunning: true }),
            stopTimer: () => set({ isTimerRunning: false }),
            resetTimer: () => set({ time: 0 }),

            resetLevel: 0,
            triggerResetLevel: () =>
                set((state) => ({
                    resetLevel: state.resetLevel + 1,
                    cameraRotation: 180,
                    time: 0,
                })),
            cameraRotation: 180,
            setCameraRotation: (angle) => set({ cameraRotation: angle }),

            carsLeft: 0,
            setCarsLeft: (count) => set({ carsLeft: count }),

            clearProgress: () =>
                set({
                    unlockedLevel: 1,
                    levelStars: {},
                    level: 1,
                    starsEarned: 0,
                    time: 0,
                }),
        }),
        {
            name: "infinity-parking-save",
            partialize: (state) => ({
                unlockedLevel: state.unlockedLevel,
                levelStars: state.levelStars,
            }),
        }
    )
);
