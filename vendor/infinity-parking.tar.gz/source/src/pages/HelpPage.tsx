import { useEffect } from "react";
import { Link } from "react-router-dom";

const sections = [
    {
        title: "Goal",
        text: "Free every trapped car from the parking lot by driving it out through the streets. Clear all cars to complete the level.",
    },
    {
        title: "Controls",
        text: "Drag a car along its axis to move it. Cars can only slide forward or backward, never sideways, so pay attention to the direction they're facing.",
    },
    {
        title: "Exit a Car",
        text: "Clear the path in front of a car, then keep dragging it until it reaches the road. Once it's on the street, it will drive off on its own.",
    },
    {
        title: "Obstacles",
        text: "Some tiles are blocked by props like bushes, benches or fire hydrants. Cars can't pass through them, so you'll need to move other cars out of the way first.",
    },
    {
        title: "Stars",
        text: "Clear a level fast to earn up to 3 stars. The timer starts as soon as the level loads, so take a moment to plan your moves before dragging.",
    },
    {
        title: "Endless Levels",
        text: "Every parking lot is procedurally generated. There is no final level — the layout changes each time and the difficulty keeps rising the further you go.",
    },
    {
        title: "Reset & Menu",
        text: "Stuck on a layout? Use the reset button to regenerate the same level from scratch, or head back to the main menu at any time from the pause options.",
    },
];

export default function HelpPage() {
    useEffect(() => {
        document.title = "Infinity Parking | Help";
    }, []);

    return (
        <div
            style={{
                minHeight: "100vh",
                position: "relative",
                pointerEvents: "auto",
                backgroundColor: "var(--tertiary-color)",
            }}
        >
            <div
                style={{
                    position: "sticky",
                    top: 0,
                    zIndex: 10,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "20px 0",
                    backgroundColor: "var(--tertiary-color)",
                }}
            >
                <Link
                    to="/"
                    title="Back"
                    className="game-container element-not-selectable"
                    style={{
                        position: "absolute",
                        left: "30px",
                        width: "120px",
                        height: "42px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        pointerEvents: "auto",
                        textDecoration: "none",
                    }}
                >
                    Back
                </Link>

                <h1
                    style={{
                        fontFamily: "Quicksand, sans-serif",
                        fontWeight: "bold",
                        fontSize: "56px",
                        marginBottom: "20px",
                        lineHeight: "52px",
                        textTransform: "uppercase",
                    }}
                >
                    Infinity Parking
                </h1>
            </div>

            <div
                style={{
                    maxWidth: "720px",
                    margin: "0 auto",
                    padding: "20px 24px 80px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "28px",
                }}
            >
                {sections.map((section, index) => (
                    <section
                        key={section.title}
                        className="menu-container"
                        style={{
                            alignItems: "flex-start",
                            padding: "24px 28px",
                            gap: "8px",
                        }}
                    >
                        <div
                            style={{
                                display: "flex",
                                alignItems: "flex-end",
                                flexDirection: "row",
                                justifyContent: "flex-start",
                                gap: "8px",
                            }}
                        >
                            <h2 style={{ fontSize: "24px", lineHeight: "26px" }}>
                                {section.title}
                            </h2>

                            <span
                                className="element-not-selectable"
                                style={{
                                    fontSize: "13px",
                                    opacity: 0.5,
                                }}
                            >
                                {String(index + 1).padStart(2, "0")}
                            </span>
                        </div>
                        <p
                            style={{
                                textTransform: "none",
                                fontSize: "16px",
                                lineHeight: "24px",
                                opacity: 0.85,
                                margin: 0,
                                textAlign: "left",
                            }}
                        >
                            {section.text}
                        </p>
                    </section>
                ))}

                <span
                    className="element-not-selectable"
                    style={{
                        opacity: 0.3,
                        textAlign: "center",
                        fontFamily: "Quicksand, sans-serif",
                        fontWeight: "bold",
                        fontSize: "20px",
                        marginBottom: "20px",
                        lineHeight: "52px",
                        textTransform: "uppercase",
                    }}
                >
                    Coded by{" "}
                    <a
                        href="https://github.com/CapyBlaze"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        CapyBlaze
                    </a>
                </span>
            </div>
        </div>
    );
}
