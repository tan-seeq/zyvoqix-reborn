import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { Canvas } from "@react-three/fiber";
import { Perf } from "r3f-perf";
import * as THREE from "three";

import { Camera } from "../rendering/Camera";
import { City } from "../rendering/City";
import { Light } from "../rendering/Light";
import { Music } from "../rendering/Music";
import { Parking } from "../rendering/Parking";
import { useGameStore } from "../store/useGameStore";
import { useSettingStore } from "../store/useSettingStore";
import Game from "../ui/Game";
import Level from "../ui/Level";
import LevelComplete from "../ui/LevelComplete";
import Menu from "../ui/Menu";
import Setting from "../ui/Setting";
import { CityMap } from "../utils/cityMap";
import {
    getDifficultyForLevel,
    getMapSizeForLevel,
    getStarThresholds,
} from "../utils/levelConfig";
import { LevelGenerator } from "../utils/levelGenerator";

const BORDER_SIZE = 10;
const TILE_SIZE = 2;
const CELL_SIZE = TILE_SIZE / 4;

const IS_NIGHT = false;
const CURTAIN_DURATION_ANIMATION = 1000;

export default function GamePage() {
    const isTimerRunning = useGameStore((state) => state.isTimerRunning);
    const incrementTime = useGameStore((state) => state.incrementTime);
    const startTimer = useGameStore((state) => state.startTimer);

    const setLevel = useGameStore((state) => state.setLevel);
    const triggerResetLevel = useGameStore((state) => state.triggerResetLevel);
    const stopTimer = useGameStore((state) => state.stopTimer);
    const time = useGameStore((state) => state.time);
    const levelStars = useGameStore((state) => state.levelStars);
    const completeLevel = useGameStore((state) => state.completeLevel);

    const [showLevelComplete, setShowLevelComplete] = useState(false);

    const music = useSettingStore((state) => state.music);
    const soundFX = useSettingStore((state) => state.soundFX);
    const debugMode = useSettingStore((state) => state.debugMode);

    const currentLevel = useGameStore((state) => state.level);
    const unlockedLevel = useGameStore((state) => state.unlockedLevel);
    const [curtainState, setCurtainState] = useState<"idle" | "closing" | "opening">("idle");
    const transitionTimeouts = useRef<ReturnType<typeof setTimeout>[]>([]);

    const { width: PARKING_SIZE_WIDTH, height: PARKING_SIZE_HEIGHT } = useMemo(
        () => getMapSizeForLevel(currentLevel),
        [currentLevel]
    );
    const DIFFICULTY = useMemo(() => getDifficultyForLevel(currentLevel), [currentLevel]);

    const cityMap = useMemo(() => {
        const cityMap = new CityMap(
            BORDER_SIZE,
            PARKING_SIZE_WIDTH,
            PARKING_SIZE_HEIGHT,
            currentLevel
        );
        return cityMap.generateCityMap();
    }, [currentLevel, PARKING_SIZE_HEIGHT, PARKING_SIZE_WIDTH]);

    const parkingMap = useMemo(() => {
        const parkingGen = new LevelGenerator(
            PARKING_SIZE_WIDTH,
            PARKING_SIZE_HEIGHT,
            currentLevel,
            DIFFICULTY
        );
        return parkingGen.generateParking();
    }, [currentLevel, PARKING_SIZE_HEIGHT, PARKING_SIZE_WIDTH, DIFFICULTY]);

    const starThresholds = useMemo(
        () => getStarThresholds(parkingMap.cars.length, DIFFICULTY),
        [parkingMap.cars.length, DIFFICULTY]
    );

    const [currentMenu, setCurrentMenu] = useState<"main" | "levels" | "settings" | "games">(
        "main"
    );

    const [playingMusic, setPlayingMusic] = useState(false);

    useEffect(() => {
        const timeoutsToClear = transitionTimeouts.current;

        return () => {
            if (timeoutsToClear) timeoutsToClear.forEach(clearTimeout);
        };
    }, []);

    const launchGame = useCallback(
        (level: number) => {
            if (curtainState !== "idle") return;

            setCurtainState("closing");
            const closeTimeout = setTimeout(() => {
                setLevel(level, "Parking Lot", levelStars[level] ?? 0);
                setCurrentMenu("games");
                triggerResetLevel();
                setShowLevelComplete(false);
                setCurtainState("opening");
                startTimer();

                const openTimeout = setTimeout(
                    () => setCurtainState("idle"),
                    CURTAIN_DURATION_ANIMATION
                );
                transitionTimeouts.current.push(openTimeout);
            }, CURTAIN_DURATION_ANIMATION);

            transitionTimeouts.current.push(closeTimeout);
        },
        [curtainState, setLevel, levelStars, triggerResetLevel, startTimer]
    );

    const handleLevelComplete = useCallback(() => {
        stopTimer();
        const elapsed = useGameStore.getState().time;
        const numCars = parkingMap.cars.length;

        const { threeStars, twoStars } = getStarThresholds(numCars, DIFFICULTY);
        const stars = elapsed <= threeStars ? 3 : elapsed <= twoStars ? 2 : 1;

        completeLevel(currentLevel, stars);

        const bestStars = useGameStore.getState().levelStars[currentLevel] ?? stars;
        setLevel(currentLevel, "Parking Lot", bestStars);

        setShowLevelComplete(true);
    }, [currentLevel, stopTimer, completeLevel, setLevel, parkingMap.cars.length, DIFFICULTY]);

    useEffect(() => {
        startTimer();
    }, [startTimer]);

    useEffect(() => {
        let interval: number;

        if (isTimerRunning) {
            interval = setInterval(() => {
                incrementTime();
            }, 1000);
        }

        return () => clearInterval(interval);
    }, [isTimerRunning, incrementTime]);

    const handleGlobalClick = (event: React.MouseEvent<HTMLDivElement>) => {
        const target = event.target as HTMLElement;
        const button = target.closest("button");

        if (button) setPlayingMusic(true);
    };

    return (
        <div
            style={{ width: "100vw", height: "100vh", position: "relative" }}
            onClick={handleGlobalClick}
        >
            <div
                style={{
                    width: "100vw",
                    height: "100vh",
                    position: "absolute",
                    top: 0,
                    left: 0,
                    zIndex: 1,
                }}
            >
                <Music playing={music && playingMusic} soundFX={soundFX} />

                <Canvas shadows={{ type: THREE.PCFShadowMap }}>
                    {debugMode && <Perf position="bottom-left" />}

                    <Camera
                        width={PARKING_SIZE_WIDTH}
                        height={PARKING_SIZE_HEIGHT}
                        autoRotate={!(currentMenu === "games")}
                    />
                    <Light isNight={IS_NIGHT} />

                    <City cityMap={cityMap} isNight={IS_NIGHT} />

                    <Parking
                        key={currentLevel}
                        parkingMap={parkingMap}
                        cityMap={cityMap}

                        width={PARKING_SIZE_WIDTH}
                        height={PARKING_SIZE_HEIGHT}
                        tileSize={TILE_SIZE}
                        cellSize={CELL_SIZE}

                        isInteractive={currentMenu === "games"}
                        onLevelComplete={handleLevelComplete}
                    />
                </Canvas>

                {!(currentMenu === "games") && (
                    <div
                        style={{
                            width: "100vw",
                            height: "100vh",
                            position: "absolute",
                            top: 0,
                            left: 0,
                            backgroundColor: "rgba(0, 0, 0, 0.5)",
                        }}
                    />
                )}

                <div
                    className="menu-viewport"
                    style={{
                        zIndex: currentMenu === "games" ? -1 : 2,
                    }}
                >
                    <div
                        className={`menu-slider ${
                            currentMenu === "levels"
                                ? "slide-to-levels"
                                : currentMenu === "settings"
                                  ? "slide-to-settings"
                                  : ""
                        }`}
                    >
                        <div className="menu-screen">
                            <Menu
                                onNavigate={(target) => {
                                    if (target === "games") {
                                        launchGame(unlockedLevel);
                                        return;
                                    }

                                    setCurrentMenu(target);
                                }}
                            />
                        </div>

                        <div className="menu-screen">
                            {currentMenu === "levels" ? (
                                <Level
                                    onBack={() => setCurrentMenu("main")}
                                    onNavigate={launchGame}
                                />
                            ) : (
                                <Setting onBack={() => setCurrentMenu("main")} />
                            )}
                        </div>
                    </div>
                </div>

                {currentMenu === "games" && (
                    <Game
                        starThresholds={starThresholds}
                        onNavigate={(target) => {
                            if (target === "main") triggerResetLevel();
                            setCurrentMenu(target);
                        }}
                    />
                )}

                {currentMenu === "games" && showLevelComplete && (
                    <>
                        <div
                            style={{
                                width: "100vw",
                                height: "100vh",
                                position: "absolute",
                                top: 0,
                                left: 0,
                                backgroundColor: "rgba(0, 0, 0, 0.5)",
                                zIndex: 99,
                            }}
                        />
                        <LevelComplete
                            level={currentLevel}
                            stars={levelStars[currentLevel] ?? 0}
                            time={time}
                            onMenu={() => {
                                setShowLevelComplete(false);
                                triggerResetLevel();
                                setCurrentMenu("main");
                            }}
                            onNextLevel={() => {
                                setShowLevelComplete(false);
                                launchGame(currentLevel + 1);
                            }}
                            onResetLevel={() => {
                                setShowLevelComplete(false);
                                triggerResetLevel();
                                startTimer();
                            }}
                        />
                    </>
                )}

                <div
                    className={`level-curtain ${
                        curtainState === "idle" ? "" : `level-curtain--${curtainState}`
                    }`}
                    aria-hidden="true"
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "#616161",
                        fontSize: "60px",
                        textTransform: "uppercase",
                        fontWeight: "bold",
                        pointerEvents: "none",
                    }}
                >
                    Infinity Parking
                </div>
            </div>
        </div>
    );
}
