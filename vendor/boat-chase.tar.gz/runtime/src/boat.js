// Boat Chase: Player Boat with Hydrodynamics, Fake-Grip Drift, Tangential Deflection & Stunt Combo Engine
import * as THREE from '../lib/three.module.js';
import { CONFIG } from './config.js';
import { soundManager } from './audio.js';

export class PlayerBoat {
  constructor(scene, world) {
    this.scene = scene;
    this.world = world;

    // Transform & Physics state
    this.position = new THREE.Vector3(0, 0, 0);
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.rotation = 0; // heading in radians
    this.speed = 0;
    this.radius = 4.8;

    // Arcade Steering & Dynamics
    this.yawVelocity = 0;
    this.smoothedSteer = 0;
    this.smoothedThrottle = 0;
    this.visualRoll = 0;
    this.visualPitch = 0;

    // Airborne / Stunt state
    this.isAirborne = false;
    this.verticalVelocity = 0;
    this.airTime = 0;
    this.peakJumpHeight = 0;
    this.airborneRollAccum = 0;
    this.didBarrelRoll = false;
    this.stuntsPerformed = 0;

    // Drift state
    this.driftTimer = 0;
    this.wasDrifting = false;

    // Combo Pressure Engine
    this.comboCount = 0;
    this.comboMultiplier = 1.0;
    this.comboTimer = 0;
    this.pendingComboScore = 0;
    this.factionManager = null;
    this.currentRamp = null;

    // Stats
    this.health = CONFIG.PLAYER.MAX_HEALTH;
    this.maxHealth = CONFIG.PLAYER.MAX_HEALTH;
    this.boost = CONFIG.PLAYER.MAX_BOOST;
    this.maxBoost = CONFIG.PLAYER.MAX_BOOST;
    this.isBoosting = false;
    this.score = 0;
    this.wantedLevel = 1; // 1 to 5 stars
    this.wantedPoints = 0;
    this.alive = true;
    this.timeSinceDamage = 0;
    this.propellerFouledTimer = 0;

    // Harpoon Slingshot Drift Cable
    this.isGrappling = false;
    this.grappleAnchor = null;
    this.grappleDistance = 0;
    this.grappleTimer = 0;
    this.cableMesh = null;
    this.anchorReticle = null;
    this.nearestAnchor = null;

    // Nanite Energy Shield & Dynamic Neon Underglow
    this.naniteShieldTimer = 0;
    this.shieldFlashTimer = 0;
    this.underglowMesh = null;
    this.underglowLight = null;
    this.shieldWire = null;
    this.shieldInner = null;
    this.railgunAmmo = 0;
    this.empAmmo = 0;

    // Smuggler's Retractable Hydrofoil Speed Wings
    this.hydrofoilDeployed = false;
    this.hydrofoilExtension = 0; // 0 = fully retracted, 1 = fully deployed
    this.hydrofoilFlightTime = 0;
    this.didFoilStunt = false;
    this.hydrofoilMeshGroup = null;

    // Build 3D Boat Mesh & Particle Wake Emitters
    this.mesh = this._createBoatMesh();
    this.scene.add(this.mesh);

    this.wakeParticles = [];
    this._initWakePool();
    this._initGrappleVisuals();
  }

  _createBoatMesh() {
    const group = new THREE.Group();

    // 1. Sunwake Terracotta Runabout Hull
    const hullShape = new THREE.Shape();
    hullShape.moveTo(0, 7.6);    // Sharp bow point
    hullShape.lineTo(2.5, 3.8);  // Mid-hull flare
    hullShape.lineTo(2.35, -5.6);// Stern starboard
    hullShape.lineTo(-2.35, -5.6);// Stern port
    hullShape.lineTo(-2.5, 3.8);
    hullShape.closePath();

    const extrudeSettings = { depth: 2.2, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.45, bevelThickness: 0.5 };
    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.rotateX(Math.PI / 2);

    // Warm sun-kissed terracotta / coral orange fiberglass
    const hullMat = new THREE.MeshStandardMaterial({
      color: 0xeb5937,
      roughness: 0.32,
      metalness: 0.22
    });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 1.0;
    hull.castShadow = true;
    group.add(hull);

    // 2. White / Cream Gunwale Cap Trim
    const gunwaleShape = new THREE.Shape();
    gunwaleShape.moveTo(0, 7.75);
    gunwaleShape.lineTo(2.65, 3.9);
    gunwaleShape.lineTo(2.48, -5.75);
    gunwaleShape.lineTo(-2.48, -5.75);
    gunwaleShape.lineTo(-2.65, 3.9);
    gunwaleShape.closePath();

    const gunwaleHole = new THREE.Path();
    gunwaleHole.moveTo(0, 6.8);
    gunwaleHole.lineTo(-2.0, 3.4);
    gunwaleHole.lineTo(-1.85, -5.1);
    gunwaleHole.lineTo(1.85, -5.1);
    gunwaleHole.lineTo(2.0, 3.4);
    gunwaleHole.closePath();
    gunwaleShape.holes.push(gunwaleHole);

    const gunwaleGeo = new THREE.ExtrudeGeometry(gunwaleShape, { depth: 0.4, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.15, bevelThickness: 0.2 });
    gunwaleGeo.rotateX(Math.PI / 2);
    const gunwaleMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc, // Crisp cream white deck rail
      roughness: 0.25,
      metalness: 0.15
    });
    const gunwale = new THREE.Mesh(gunwaleGeo, gunwaleMat);
    gunwale.position.y = 2.15;
    group.add(gunwale);

    // 3. Cockpit Teak Wooden Deck
    const deckGeo = new THREE.BoxGeometry(3.6, 0.4, 8.4);
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x92400e, // Warm marine teak wood
      roughness: 0.55,
      metalness: 0.1
    });
    const deck = new THREE.Mesh(deckGeo, deckMat);
    deck.position.set(0, 1.25, -0.6);
    group.add(deck);

    // 4. Dual Upholstered Captain & Passenger Bucket Seats
    const seatMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Warm saddle leather
      roughness: 0.65,
      metalness: 0.15
    });
    const seatFrameMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });

    [-0.85, 0.85].forEach(xOff => {
      const cushion = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.4, 1.3), seatMat);
      cushion.position.set(xOff, 1.65, -0.9);
      group.add(cushion);

      const backrest = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.1, 0.35), seatMat);
      backrest.position.set(xOff, 2.3, -1.5);
      backrest.rotation.x = -0.15;
      group.add(backrest);

      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 0.55, 8), seatFrameMat);
      base.position.set(xOff, 1.3, -0.9);
      group.add(base);
    });

    // 5. Helm Steering Console & Chrome Steering Wheel
    const consoleGeo = new THREE.BoxGeometry(3.4, 1.2, 1.6);
    const consoleMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.4 });
    const helmConsole = new THREE.Mesh(consoleGeo, consoleMat);
    helmConsole.position.set(0, 2.0, 1.1);
    group.add(helmConsole);

    const wheelGroup = new THREE.Group();
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.95, roughness: 0.15 });
    const wheelRim = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 8, 16), rimMat);
    wheelGroup.add(wheelRim);
    const spoke1 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.84, 6), rimMat);
    wheelGroup.add(spoke1);
    const spoke2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.84, 6), rimMat);
    spoke2.rotation.z = Math.PI / 2;
    wheelGroup.add(spoke2);
    wheelGroup.position.set(0.85, 2.45, 0.9);
    wheelGroup.rotation.x = -0.65;
    group.add(wheelGroup);
    this.steeringWheelMesh = wheelGroup;

    // 6. Stainless Steel Framed Wrap-Around Windshield
    const windshieldGeo = new THREE.BoxGeometry(3.5, 1.05, 1.6);
    const windshieldMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.55,
      roughness: 0.1,
      metalness: 0.9
    });
    const windshield = new THREE.Mesh(windshieldGeo, windshieldMat);
    windshield.position.set(0, 2.7, 1.3);
    windshield.rotation.x = -0.4;
    group.add(windshield);

    const railMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.95, roughness: 0.1 });
    const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.6, 8), railMat);
    rail.rotateZ(Math.PI / 2);
    rail.position.set(0, 3.25, 1.1);
    group.add(rail);

    // 7. Vintage Brass Nautical Lantern (Warm Golden Amber Glow)
    const lanternGroup = new THREE.Group();
    const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.3 });
    const lBase = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 0.2, 8), brassMat);
    lanternGroup.add(lBase);

    const lGlass = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.45, 8), new THREE.MeshBasicMaterial({ color: 0xfef08a, transparent: true, opacity: 0.95 }));
    lGlass.position.y = 0.28;
    lanternGroup.add(lGlass);

    const lCap = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.22, 8), brassMat);
    lCap.position.y = 0.58;
    lanternGroup.add(lCap);

    lanternGroup.position.set(1.95, 2.35, 1.8);
    group.add(lanternGroup);

    this.lanternLight = new THREE.PointLight(0xfbbf24, 1.8, 16);
    this.lanternLight.position.set(1.95, 2.65, 1.8);
    group.add(this.lanternLight);

    // 8. Transom-Mounted Modern Outboard Motor
    const motorMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.85, roughness: 0.25 });
    const outboardGroup = new THREE.Group();
    
    const cowl = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.9, 1.5), motorMat);
    cowl.position.set(0, 1.4, -0.3);
    outboardGroup.add(cowl);

    const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.18, 1.52), new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.5 }));
    stripe.position.set(0, 1.4, -0.3);
    outboardGroup.add(stripe);

    const midLeg = new THREE.Mesh(new THREE.BoxGeometry(0.45, 1.6, 0.75), motorMat);
    midLeg.position.set(0, -0.2, -0.3);
    outboardGroup.add(midLeg);

    const skeg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.8, 0.9), motorMat);
    skeg.position.set(0, -1.1, -0.35);
    outboardGroup.add(skeg);

    const glowGeo = new THREE.CylinderGeometry(0.35, 0.45, 0.6, 8);
    glowGeo.rotateX(Math.PI / 2);
    const glowMat = new THREE.MeshBasicMaterial({ color: 0x00d2d3, transparent: true, opacity: 0.85 });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    glow.position.set(0, 0.7, -1.2);
    glow.name = 'exhaust_center';
    outboardGroup.add(glow);

    outboardGroup.position.set(0, 1.0, -5.6);
    group.add(outboardGroup);
    this.outboardMotorMesh = outboardGroup;

    // 7. Dynamic Neon Underglow Projector (Glows on sea surface)
    const underglowCanvas = document.createElement('canvas');
    underglowCanvas.width = 128;
    underglowCanvas.height = 128;
    const uCtx = underglowCanvas.getContext('2d');
    const uGrad = uCtx.createRadialGradient(64, 64, 6, 64, 64, 62);
    uGrad.addColorStop(0, 'rgba(0, 242, 254, 0.95)');
    uGrad.addColorStop(0.35, 'rgba(0, 210, 255, 0.65)');
    uGrad.addColorStop(0.7, 'rgba(0, 114, 255, 0.3)');
    uGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    uCtx.fillStyle = uGrad;
    uCtx.fillRect(0, 0, 128, 128);
    const underglowTexture = new THREE.CanvasTexture(underglowCanvas);

    const underglowGeo = new THREE.PlaneGeometry(8.5, 15.0);
    underglowGeo.rotateX(-Math.PI / 2);
    const underglowMat = new THREE.MeshBasicMaterial({
      map: underglowTexture,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    this.underglowMesh = new THREE.Mesh(underglowGeo, underglowMat);
    this.underglowMesh.position.y = -0.05;
    group.add(this.underglowMesh);

    // Dynamic point light for hull & water surface illumination
    this.underglowLight = new THREE.PointLight(0x00f2fe, 1.8, 14);
    this.underglowLight.position.set(0, 0.3, 0);
    group.add(this.underglowLight);

    // 8. Nanite Energy Shield Forcefield
    const shieldGeo = new THREE.IcosahedronGeometry(5.4, 2);
    const shieldWireMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending
    });
    this.shieldWire = new THREE.Mesh(shieldGeo, shieldWireMat);
    group.add(this.shieldWire);

    const shieldInnerMat = new THREE.MeshBasicMaterial({
      color: 0x0284c7,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    this.shieldInner = new THREE.Mesh(shieldGeo, shieldInnerMat);
    this.shieldInner.scale.set(0.96, 0.96, 0.96);
    group.add(this.shieldInner);

    // 9. Smuggler's Hydrofoil Speed Wing Assembly (Retractable T-Foils)
    const foilGroup = new THREE.Group();
    const foilMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.35,
      metalness: 0.85
    });
    const wingletMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });

    // Bow T-Foil (Vertical carbon strut + swept foil blade + cyan winglets)
    const strutGeo = new THREE.BoxGeometry(0.25, 1.6, 0.45);
    const strutFwd = new THREE.Mesh(strutGeo, foilMat);
    strutFwd.position.set(0, -0.6, 3.2);
    foilGroup.add(strutFwd);

    const bladeFwd = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.14, 0.7), foilMat);
    bladeFwd.position.set(0, -1.35, 3.2);
    foilGroup.add(bladeFwd);

    const wingletGeo = new THREE.BoxGeometry(0.12, 0.5, 0.6);
    const wLeft = new THREE.Mesh(wingletGeo, wingletMat);
    wLeft.position.set(-2.6, -1.15, 3.2);
    foilGroup.add(wLeft);
    const wRight = new THREE.Mesh(wingletGeo, wingletMat);
    wRight.position.set(2.6, -1.15, 3.2);
    foilGroup.add(wRight);

    // Stern T-Foil
    const strutAft = new THREE.Mesh(strutGeo, foilMat);
    strutAft.position.set(0, -0.6, -3.8);
    foilGroup.add(strutAft);

    const bladeAft = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.14, 0.7), foilMat);
    bladeAft.position.set(0, -1.35, -3.8);
    foilGroup.add(bladeAft);

    this.hydrofoilMeshGroup = foilGroup;
    group.add(foilGroup);

    return group;
  }

  _initWakePool() {
    const wakeGeo = new THREE.PlaneGeometry(1.8, 1.8);
    wakeGeo.rotateX(-Math.PI / 2);
    const wakeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.7,
      depthWrite: false
    });

    for (let i = 0; i < 180; i++) {
      const p = new THREE.Mesh(wakeGeo, wakeMat.clone());
      p.visible = false;
      this.scene.add(p);
      this.wakeParticles.push({
        mesh: p,
        velocity: new THREE.Vector3(0, 0, 0),
        life: 0,
        maxLife: 1.0,
        scale: 1,
        alpha: 0.8
      });
    }
  }

  emitWake(dt) {
    if (Math.abs(this.speed) < 3 || this.isAirborne) return;

    const cos = Math.cos(this.rotation);
    const sin = Math.sin(this.rotation);
    const speedFactor = Math.min(1.8, Math.abs(this.speed) / CONFIG.PLAYER.MAX_SPEED);

    // 1. Sunwake Bow Wave Spray: flares outward laterally from port and starboard bow
    if (Math.abs(this.speed) > 12) {
      for (const side of [-2.1, 2.1]) {
        const p = this.wakeParticles.find(w => !w.mesh.visible);
        if (p) {
          const bowFwd = 4.2;
          const bx = this.position.x + sin * bowFwd + cos * side;
          const bz = this.position.z + cos * bowFwd - sin * side;

          p.mesh.position.set(bx, 0.4 + this.world.getWaveHeight(bx, bz), bz);
          // Flare outwards laterally
          p.velocity.set(cos * Math.sign(side) * (4 + speedFactor * 8), 1.2 + Math.random() * 1.5, -sin * Math.sign(side) * (4 + speedFactor * 8));
          p.mesh.visible = true;
          p.life = 0;
          p.maxLife = 0.55 + Math.random() * 0.25;
          p.scale = 0.6 + speedFactor * 1.2;
          p.mesh.scale.set(p.scale, p.scale, p.scale);
        }
      }
    }

    // 2. Transom Stern Motor Wash & Churn
    for (const side of [-0.9, 0.9]) {
      const p = this.wakeParticles.find(w => !w.mesh.visible);
      if (p) {
        const sternBack = -5.8;
        const wx = this.position.x + sin * sternBack + cos * side;
        const wz = this.position.z + cos * sternBack - sin * side;

        p.mesh.position.set(wx, 0.2 + this.world.getWaveHeight(wx, wz), wz);
        p.velocity.set((Math.random() - 0.5) * 2, 0.2, (Math.random() - 0.5) * 2);
        p.mesh.visible = true;
        p.life = 0;
        p.maxLife = 0.95 + Math.random() * 0.4;
        p.scale = 1.1 + speedFactor * 2.0;
        p.mesh.scale.set(p.scale, p.scale, p.scale);
        p.mesh.rotation.y = this.rotation + (Math.random() - 0.5) * 0.5;
      }
    }
  }

  _initGrappleVisuals() {
    // High-voltage glowing grapple cable line
    const cableGeo = new THREE.BufferGeometry();
    cableGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
    const cableMat = new THREE.LineBasicMaterial({
      color: 0x00f2fe,
      linewidth: 3,
      transparent: true,
      opacity: 0.95
    });
    this.cableMesh = new THREE.Line(cableGeo, cableMat);
    this.cableMesh.frustumCulled = false;
    this.cableMesh.visible = false;
    this.scene.add(this.cableMesh);

    // Anchor targeting reticle ring
    const reticleGeo = new THREE.RingGeometry(1.6, 2.4, 16);
    reticleGeo.rotateX(-Math.PI / 2);
    const reticleMat = new THREE.MeshBasicMaterial({
      color: 0x00f2fe,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85
    });
    this.anchorReticle = new THREE.Mesh(reticleGeo, reticleMat);
    this.anchorReticle.visible = false;
    this.scene.add(this.anchorReticle);
  }

  // NitroCity Stunt Combo System
  triggerStunt(stuntName, basePoints, forceMultiplier = null) {
    this.stuntsPerformed++;
    this.comboCount++;
    if (forceMultiplier !== null) {
      this.comboMultiplier = forceMultiplier;
      this.comboCount = Math.max(this.comboCount, Math.round((forceMultiplier - 1.0) / 0.5 + 1));
    } else {
      this.comboMultiplier = Math.min(5.0, 1.0 + 0.5 * (this.comboCount - 1));
    }
    this.comboTimer = 3.2; // 3.2s pressure window to chain another stunt!

    const awarded = Math.round(basePoints * this.comboMultiplier);
    this.pendingComboScore += basePoints;
    this.score += awarded;

    soundManager.playComboBonus(this.comboMultiplier);

    // Animated Stunt HUD Banner
    const stuntPopup = document.getElementById('stunt-banner');
    if (stuntPopup) {
      const title = stuntPopup.querySelector('.stunt-title');
      const sub = stuntPopup.querySelector('.stunt-sub');
      if (title) title.innerText = `⭐ ${stuntName}`;
      if (sub) sub.innerText = `+${awarded} PTS (${this.comboMultiplier.toFixed(1)}x COMBO!)`;

      stuntPopup.classList.remove('show');
      void stuntPopup.offsetWidth; // Force CSS reflow for instant re-pop
      stuntPopup.classList.add('show');
    }

    this.updateComboHUD();
  }

  updateComboHUD() {
    const comboDisplay = document.getElementById('combo-meter');
    if (comboDisplay) {
      if (this.comboCount > 1 && this.comboTimer > 0) {
        comboDisplay.style.opacity = '1';
        comboDisplay.innerText = `${this.comboMultiplier.toFixed(1)}x COMBO (${this.comboTimer.toFixed(1)}s)`;
      } else {
        comboDisplay.style.opacity = '0';
      }
    }
  }

  addWanted(amount = 1) {
    this.wantedLevel = Math.min(5, Math.max(1, this.wantedLevel + amount));
    if (this.factionManager && this.factionManager.onWantedLevelChanged) {
      this.factionManager.onWantedLevelChanged(this.wantedLevel);
    }
  }

  update(dt, input) {
    if (!this.alive) return;

    // Frame-rate normalization factor k (1.0 at 60fps, 0.5 at 120fps, 2.0 at 30fps)
    const k = Math.min(Math.max((dt || 0.016) * 60, 0.2), 2.0);
    const damp = (a, b, rate) => a + (b - a) * (1 - Math.pow(Math.max(0, 1 - rate), k));

    // 1. Boost Logic
    this.isBoosting = input.boost && this.boost > 5 && input.throttle > 0;
    if (this.isBoosting) {
      this.boost = Math.max(0, this.boost - CONFIG.PLAYER.BOOST_DRAIN * dt);
    } else {
      this.boost = Math.min(this.maxBoost, this.boost + CONFIG.PLAYER.BOOST_RECHARGE * dt);
    }

    // 2. Input Smoothing (Snappy attack, swift release)
    this.smoothedThrottle = damp(this.smoothedThrottle, input.throttle, input.throttle === 0 ? 0.32 : 0.18);
    this.smoothedSteer = damp(this.smoothedSteer, input.steer, input.steer === 0 ? 0.38 : 0.22);

    // 3. Fake-Grip Arcade Steering Model (Car Tire Physics on Water)
    const fwd = new THREE.Vector3(Math.sin(this.rotation), 0, Math.cos(this.rotation));
    const right = new THREE.Vector3(Math.cos(this.rotation), 0, -Math.sin(this.rotation));

    let vF = this.velocity.dot(fwd);
    let vR = this.velocity.dot(right);

    // Lateral grip slide decay (Exponential decay over k)
    const isDrifting = input.drift;
    const grip = isDrifting ? 0.88 : 0.982;
    vR *= Math.pow(grip, k);

    // Smuggler's Hydrofoil Speed Wings Deployment
    const foilDeploySpeed = (CONFIG.HYDROFOIL && CONFIG.HYDROFOIL.deploySpeed) || 28;
    const shouldDeployFoil = (Math.abs(vF) >= foilDeploySpeed && input.throttle > 0) || this.isBoosting;
    const prevExtension = this.hydrofoilExtension;
    this.hydrofoilExtension = damp(this.hydrofoilExtension, shouldDeployFoil ? 1.0 : 0.0, shouldDeployFoil ? 0.08 : 0.06);
    this.hydrofoilDeployed = this.hydrofoilExtension > 0.45;

    if (prevExtension < 0.35 && this.hydrofoilExtension >= 0.35) {
      soundManager.playHydrofoilWhoosh();
    }

    if (this.hydrofoilMeshGroup) {
      this.hydrofoilMeshGroup.position.y = -this.hydrofoilExtension * 0.45;
    }

    // Forward throttle acceleration
    let targetMaxSpeed = CONFIG.PLAYER.MAX_SPEED * (this.isBoosting ? CONFIG.PLAYER.BOOST_MULTIPLIER : 1.0);
    if (this.hydrofoilExtension > 0.3) {
      targetMaxSpeed += ((CONFIG.HYDROFOIL && CONFIG.HYDROFOIL.speedBonus) || 14) * this.hydrofoilExtension;
    }
    if (this.propellerFouledTimer > 0) {
      this.propellerFouledTimer -= dt;
      targetMaxSpeed *= 0.50; // Propeller fouled speed penalty
    }

    const targetVF = this.smoothedThrottle > 0
      ? this.smoothedThrottle * targetMaxSpeed
      : (this.smoothedThrottle < 0 ? this.smoothedThrottle * CONFIG.PLAYER.REVERSE_SPEED : 0);

    const accelRate = this.isBoosting ? 0.065 : (this.smoothedThrottle !== 0 ? 0.045 : 0.020);
    vF = damp(vF, targetVF, accelRate);

    // Drift boost flick & power slide reward
    if (this.wasDrifting && !isDrifting && this.driftTimer > 0.6) {
      // Clean power-drift release gives an instant kick of forward speed!
      vF = Math.min(targetMaxSpeed * 1.15, vF + 5.5);
      this.triggerStunt('POWER DRIFT BOOST!', 350);
      soundManager.playAlertPing();
    }
    this.wasDrifting = isDrifting;

    if (isDrifting && Math.abs(vF) > 28) {
      this.driftTimer += dt;
      if (this.driftTimer > 1.3 && Math.random() < 0.05) {
        this.triggerStunt('HIGH SPEED WAKE DRIFT', 200);
      }
    } else {
      this.driftTimer = 0;
    }

    // Rudder authority: agile, balanced turning to BOTH sides at all speeds and especially during boost!
    const speedRatio = Math.min(Math.max(0.35, Math.abs(vF) / (CONFIG.PLAYER.MAX_SPEED * 0.50)), 1.0);
    let authority = Math.sin(speedRatio * Math.PI * 0.5);
    authority *= (this.smoothedThrottle > 0 ? 1.35 : 1.0);

    // Boost steering agility bonus: allows carving sharp turns to left and right while boosting!
    const boostTurnBonus = this.isBoosting ? 1.45 : 1.0;
    const turnRate = CONFIG.PLAYER.TURN_SPEED * (isDrifting ? 1.65 : 1.0) * boostTurnBonus;

    this.yawVelocity += this.smoothedSteer * turnRate * authority * k * 0.45;
    this.yawVelocity *= Math.pow(0.80, k);
    this.rotation -= this.yawVelocity * dt;

    // Direct velocity redirection while boosting: converts forward thrust directly into the turned direction
    if (this.isBoosting && Math.abs(this.smoothedSteer) > 0.05) {
      this.velocity.applyAxisAngle(new THREE.Vector3(0, 1, 0), -this.yawVelocity * dt * 0.65);
    }

    // Animate cockpit steering wheel and transom outboard motor
    if (this.steeringWheelMesh) {
      this.steeringWheelMesh.rotation.z = -this.smoothedSteer * 1.6;
    }
    if (this.outboardMotorMesh) {
      this.outboardMotorMesh.rotation.y = this.smoothedSteer * 0.55;
    }

    // Anchor detection for HUD & grapple reticle
    const nearestAnchor = this.world.getNearestGrappleAnchor(this.position.x, this.position.z, this.rotation, 78);
    this.nearestAnchor = nearestAnchor;

    const grapplePrompt = document.getElementById('grapple-prompt');

    if (nearestAnchor && !this.isGrappling) {
      this.anchorReticle.position.set(nearestAnchor.x, nearestAnchor.y + 0.5, nearestAnchor.z);
      const pulse = 1.0 + Math.sin(this.world.waterTime * 10) * 0.22;
      this.anchorReticle.scale.set(pulse, pulse, pulse);
      this.anchorReticle.visible = true;
      if (grapplePrompt) grapplePrompt.style.opacity = '1';
    } else if (!this.isGrappling) {
      this.anchorReticle.visible = false;
      if (grapplePrompt) grapplePrompt.style.opacity = '0';
    }

    // Harpoon Slingshot Drift Cable State Machine
    const wantsGrapple = !!input.grapple;

    if (wantsGrapple && !this.isGrappling && nearestAnchor) {
      this.isGrappling = true;
      this.grappleAnchor = { x: nearestAnchor.x, y: nearestAnchor.y, z: nearestAnchor.z };
      this.grappleDistance = Math.max(16, Math.hypot(this.position.x - nearestAnchor.x, this.position.z - nearestAnchor.z));
      this.grappleTimer = 0;
      this.cableMesh.visible = true;
      soundManager.playHarpoonLaunch();
      if (grapplePrompt) grapplePrompt.innerText = '⚓ TETHER ENGAGED - RELEASE [F] FOR SLINGSHOT!';
    } else if (this.isGrappling) {
      if (!wantsGrapple) {
        // RELEASE -> Apex Slingshot Boost!
        if (this.grappleTimer > 0.24 && Math.abs(vF) > 20) {
          vF = Math.min(targetMaxSpeed * 1.35, vF + 8.5);
          this.triggerStunt('HARPOON APEX SLINGSHOT!', 550);
          soundManager.playHarpoonSlingshot();
          if (window.game && window.game.addTrauma) window.game.addTrauma(0.32);
        }
        this.isGrappling = false;
        this.cableMesh.visible = false;
        this.grappleAnchor = null;
        if (grapplePrompt) grapplePrompt.innerText = '[F] HARPOON DRIFT CABLE';
      } else {
        // TETHER ACTIVE: Centripetal tension & hairpin drift torque
        this.grappleTimer += dt;
        const toAncX = this.grappleAnchor.x - this.position.x;
        const toAncZ = this.grappleAnchor.z - this.position.z;
        const curDist = Math.hypot(toAncX, toAncZ);

        if (curDist > 92) {
          // Tension break!
          this.isGrappling = false;
          this.cableMesh.visible = false;
          this.grappleAnchor = null;
          if (grapplePrompt) grapplePrompt.innerText = '[F] HARPOON DRIFT CABLE';
        } else {
          const dirX = toAncX / curDist;
          const dirZ = toAncZ / curDist;

          // Inward centripetal pull to stay in orbital slingshot
          const tensionForce = Math.max(0, curDist - this.grappleDistance) * 4.2 + 50;
          this.velocity.x += dirX * tensionForce * dt;
          this.velocity.z += dirZ * tensionForce * dt;

          // Tangential whip rotation
          const cross = fwd.x * dirZ - fwd.z * dirX;
          this.yawVelocity += (cross > 0 ? -1 : 1) * 3.6 * dt;

          // Inward hull lean into the turn
          this.visualRoll = damp(this.visualRoll, (cross > 0 ? 0.52 : -0.52), 0.25);

          // Update 3D cable vertices
          const posAttr = this.cableMesh.geometry.attributes.position;
          posAttr.setXYZ(0, this.position.x + fwd.x * 5.2, this.position.y + 1.8, this.position.z + fwd.z * 5.2);
          posAttr.setXYZ(1, this.grappleAnchor.x, this.grappleAnchor.y, this.grappleAnchor.z);
          posAttr.needsUpdate = true;

          // Keep anchor reticle active on tethered point
          this.anchorReticle.position.set(this.grappleAnchor.x, this.grappleAnchor.y + 0.3, this.grappleAnchor.z);
          this.anchorReticle.visible = true;
        }
      }
    }

    // Reconstruct velocity from forward and lateral components
    if (!this.isGrappling) {
      this.velocity.copy(fwd).multiplyScalar(vF).addScaledVector(right, vR);
    } else {
      const projectedVF = this.velocity.dot(fwd);
      vF = Math.max(vF, projectedVF);
    }
    this.speed = vF;

    // 4. Stunt Ramps (Gated on forward approach angle)
    if (!this.isAirborne) {
      const ramp = this.world.checkRamp(this.position.x, this.position.z, this.rotation);
      if (ramp && vF > 26) {
        this.isAirborne = true;
        const rampBoost = ramp.isCarrierRamp ? 1.85 : (ramp.isShipwreckRamp ? 1.55 : (ramp.isRunwayRamp ? 1.48 : (ramp.isFreighterRamp ? 1.42 : (ramp.isOilRigRamp ? 1.55 : 1.1))));
        this.verticalVelocity = CONFIG.RAMP_LAUNCH_FORCE * (vF / CONFIG.PLAYER.MAX_SPEED) * rampBoost;
        this.airTime = 0;
        this.peakJumpHeight = 0;
        this.airborneRollAccum = 0;
        this.didBarrelRoll = false;
        this.currentRamp = ramp;
        soundManager.playSplash();
        soundManager.playAlertPing();
      }

      // 4b. Hydraulic Wake-Jumping & Slipstream Drafting off nearby boats
      if (this.factionManager && vF > 26) {
        for (const enemy of this.factionManager.enemies) {
          if (!enemy.alive) continue;
          const dx = this.position.x - enemy.position.x;
          const dz = this.position.z - enemy.position.z;
          const distSq = dx * dx + dz * dz;
          if (distSq < 44 * 44 && distSq > 12 * 12) {
            const efwdX = Math.sin(enemy.rotation);
            const efwdZ = Math.cos(enemy.rotation);
            // Behind enemy boat stern wash check
            const sternDot = dx * (-efwdX) + dz * (-efwdZ);
            if (sternDot > 6) {
              const crossProduct = Math.abs(fwd.x * (-efwdZ) - fwd.z * (-efwdX));
              if (crossProduct > 0.62) {
                // Crossing turbulent stern wash perpendicular -> Dynamic Wake Launch!
                this.isAirborne = true;
                this.verticalVelocity = 36 * (vF / CONFIG.PLAYER.MAX_SPEED);
                this.airTime = 0;
                this.peakJumpHeight = 0;
                this.airborneRollAccum = 0;
                this.didBarrelRoll = false;
                soundManager.playSplash();
                this.triggerStunt('WAKE SURF SLINGSHOT!', 600);
                break;
              } else if (fwd.dot(new THREE.Vector3(efwdX, 0, efwdZ)) > 0.84) {
                // Direct slipstream drafting in wake corridor -> Acceleration boost!
                vF = Math.min(targetMaxSpeed * 1.20, vF + 0.85 * k);
              }
            }
          }
        }
      }

      // 4c. Tropical Squall Swell Launch
      if (this.world.isSquallActive && vF > 30) {
        const wave = this.world.getWaveHeight(this.position.x, this.position.z);
        if (wave > 1.45 && !this.isAirborne) {
          this.isAirborne = true;
          this.verticalVelocity = 34 * (vF / CONFIG.PLAYER.MAX_SPEED);
          this.airTime = 0;
          this.peakJumpHeight = 0;
          this.airborneRollAccum = 0;
          this.didBarrelRoll = false;
          soundManager.playSplash();
          this.triggerStunt('🌊 SQUALL SWELL LAUNCH!', 400);
        }
      }

      // 4d. Rogue Tidal Wave Surf Launch!
      if (this.world.rogueWave && this.world.rogueWave.active && vF > 20 && !this.isAirborne) {
        const rw = this.world.rogueWave;
        const dx = this.position.x - rw.x;
        const dz = this.position.z - rw.z;
        const nx = Math.sin(rw.angle);
        const nz = Math.cos(rw.angle);
        const alongDist = dx * nx + dz * nz;
        const perpDist = Math.abs(dx * (-nz) + dz * nx);
        if (Math.abs(alongDist) < 18 && perpDist < rw.width * 0.5) {
          this.isAirborne = true;
          this.verticalVelocity = 40 * (CONFIG.ROGUE_WAVE.launchBoost || 2.2) * Math.max(0.55, vF / CONFIG.PLAYER.MAX_SPEED);
          this.airTime = 0;
          this.peakJumpHeight = 0;
          this.airborneRollAccum = 0;
          this.didBarrelRoll = false;
          this.currentRamp = { isRogueWave: true };
          soundManager.playRampLaunch();
          soundManager.playRogueWaveSurge();
          this.triggerStunt('🌊 50-FOOT ROGUE WAVE SURF LAUNCH! +1400 PTS', CONFIG.ROGUE_WAVE.stuntScore || 1400, 4.5);
          if (window.game && window.game.addTrauma) window.game.addTrauma(0.65);
        }
      }
    }

    // 5. Airborne Physics & Barrel Roll Detection
    if (this.isAirborne) {
      this.airTime += dt;
      this.verticalVelocity -= 48 * dt; // Gravity
      this.position.y += this.verticalVelocity * dt;
      this.peakJumpHeight = Math.max(this.peakJumpHeight, this.position.y);

      // Stable mid-air attitude: boat stays upright and balanced, zero flipping
      this.visualRoll = THREE.MathUtils.clamp(this.visualRoll + this.smoothedSteer * dt * 0.1, -0.045, 0.045);
      if (this.airTime > 0.8 && !this.didBarrelRoll) {
        this.didBarrelRoll = true;
        this.triggerStunt('✈️ LEVEL WING AEROBATIC AIR!', 650);
      }

      if (this.position.y <= 0) {
        // Safe Water Touchdown!
        this.position.y = 0;
        this.isAirborne = false;
        this.verticalVelocity = 0;

        soundManager.playSplash();
        if (window.game && window.game.addTrauma) window.game.addTrauma(0.35);

        if (this.currentRamp && this.currentRamp.isFreighterRamp) {
          this.triggerStunt('CONTAINER FREIGHTER FLIGHT!', 950);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isDrawbridge) {
          this.triggerStunt('🌉 DRAWBRIDGE CHASM JUMP!', 850);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isOilRigRamp) {
          this.triggerStunt('✈️ OIL RIG CATWALK FLIGHT!', 1100, 5.0);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isCarrierRamp) {
          this.triggerStunt('🚀 SUPERCARRIER FLIGHT DECK LAUNCH!', 1600, 5.0);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isRunwayRamp) {
          this.triggerStunt('🛫 WATER RUNWAY TAKEOFF!', 900, 4.0);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isRogueWave) {
          this.triggerStunt('🌊 TITANIC SURF TOUCHDOWN!', 600, 3.5);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isShipwreckRamp) {
          this.triggerStunt('🏴‍☠️ SUNKEN GALLEON MAST JUMP! +1100 PTS', CONFIG.SUNKEN_GALLEON.stuntScore || 1100, 4.5);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isWaterspout) {
          this.triggerStunt('🌪️ CYCLONE SLINGSHOT TOUCHDOWN!', 550, 3.5);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isCasinoFountainRamp) {
          this.triggerStunt('🎰 CASINO FOUNTAIN LAUNCH! +1150 PTS', (CONFIG.CASINO && CONFIG.CASINO.stuntScore) || 1150, 4.5);
          this.currentRamp = null;
        } else if (this.currentRamp && this.currentRamp.isCasinoHelipadRamp) {
          this.triggerStunt('🚁 CASINO HELIPAD ROOF VAULT! +1300 PTS', 1300, 5.0);
          this.currentRamp = null;
        } else if (this.airTime > 0.60) {
          const airScore = Math.round(this.airTime * 350 + this.peakJumpHeight * 25);
          this.triggerStunt('MEGA AIR LAUNCH!', airScore);
        }

        this.peakJumpHeight = 0;
        this.airborneRollAccum = 0;
        this.didBarrelRoll = false;
      }
    } else {
      // Water level bobbing & wave carving
      const wave = this.world.getWaveHeight(this.position.x, this.position.z);
      const foilLift = this.hydrofoilExtension * ((CONFIG.HYDROFOIL && CONFIG.HYDROFOIL.liftHeight) || 0.85);
      this.position.y = damp(this.position.y, wave + foilLift, 0.16);

      // Ultra-stable non-tipping hull roll: rock-solid upright stability (GTA 6 / Sunwake arcade handling)
      const targetRoll = this.smoothedSteer * 0.035; // Max ~2.0 degrees subtle stable lean
      this.visualRoll = damp(this.visualRoll, targetRoll, 0.22);
      this.visualRoll = THREE.MathUtils.clamp(this.visualRoll, -0.045, 0.045); // strictly non-tipping!

      // Gentle pitch: slight bow rise on acceleration, rock-solid stable
      const targetPitch = Math.min(0.065, (vF / (CONFIG.PLAYER.MAX_SPEED * 1.5)) * 0.065);
      this.visualPitch = damp(this.visualPitch, targetPitch, 0.18);

      // Hydrofoil Wing-Flight Stunt Tracker
      if (this.hydrofoilExtension > 0.75 && Math.abs(vF) > 30) {
        this.hydrofoilFlightTime += dt;
        if (this.hydrofoilFlightTime >= 3.0 && !this.didFoilStunt) {
          this.didFoilStunt = true;
          this.triggerStunt('🪽 HYDROFOIL WING-FLIGHT! +700 PTS', (CONFIG.HYDROFOIL && CONFIG.HYDROFOIL.stuntScore) || 700, 4.0);
        }
      } else {
        this.hydrofoilFlightTime = 0;
        if (this.hydrofoilExtension < 0.25) {
          this.didFoilStunt = false;
        }
      }
    }

    // Advance position
    this.position.x += this.velocity.x * dt;
    this.position.z += this.velocity.z * dt;

    // 6. Destructible Obstacle Smashes (Crates, Barrels, Buoys)
    const destructible = this.world.checkDestructibles(this.position.x, this.position.z, this.radius);
    if (destructible) {
      soundManager.playThud();
      if (destructible.isExplosive) {
        soundManager.playExplosion(0.65, 0.55);
        this.takeDamage(16);
        if (window.game && window.game.addTrauma) window.game.addTrauma(0.55);
      } else {
        if (window.game && window.game.addTrauma) window.game.addTrauma(0.24);
      }
      this.triggerStunt(`SMASH: ${destructible.name}!`, destructible.score);
    }

    // 6b. Police Canal Roadblock Smash
    const roadblock = this.world.checkRoadblocks(this.position.x, this.position.z, this.radius, Math.abs(vF));
    if (roadblock) {
      soundManager.playRoadblockSmash();
      if (window.game && window.game.addTrauma) window.game.addTrauma(0.48);
      if (Math.abs(vF) > 30 || this.isBoosting) {
        this.triggerStunt('💥 ROADBLOCK SMASH: RAMMING SPEED!', 700);
        vF = Math.min(targetMaxSpeed * 1.25, vF + 4.0);
      } else {
        this.triggerStunt('ROADBLOCK BUSTED!', 500);
        vF *= 0.82;
      }
      this.takeDamage(8);
    }

    // 6c. Breachable Fortress Sea Gate Check
    const seaGateHit = this.world.checkSeaGate(this.position.x, this.position.z, this.radius, Math.abs(vF), this.isBoosting);
    if (seaGateHit) {
      if (seaGateHit.breached) {
        vF = Math.min(targetMaxSpeed * 1.3, vF + 6.0);
        this.takeDamage(10);
      } else {
        soundManager.playThud();
        if (seaGateHit.collider) {
          this._resolveDeflection(seaGateHit.collider, dt, k);
        }
      }
    }

    // 6d. Floating Coast Guard Spike Net Check
    const spikeNetHit = this.world.checkSpikeNets(this.position.x, this.position.z, this.radius, Math.abs(vF), this.isBoosting);
    if (spikeNetHit) {
      if (spikeNetHit.severed) {
        soundManager.playRoadblockSmash();
        this.triggerStunt('⚡ SPIKE NET SEVERED!', 450);
        vF = Math.min(targetMaxSpeed * 1.2, vF + 2.5);
      } else {
        soundManager.playThud();
        soundManager.playSplash();
        this.propellerFouledTimer = 3.8;
        this.takeDamage(6);
        if (window.game && window.game.addTrauma) window.game.addTrauma(0.35);
        const dispatch = document.getElementById('dispatch-msg');
        if (dispatch) {
          dispatch.innerText = '⚠️ [COAST GUARD]: Net fouled suspect propeller! Speed cut in half!';
          dispatch.style.color = '#f59e0b';
        }
      }
    }

    // 6e. Buoyant Horned Naval Contact Mine Check
    if (this.world.checkMines) {
      this.world.checkMines(this.position.x, this.position.z, this.radius, this);
    }

    // 7. Tangential Deflection Collisions (No full backwards reverse!)
    const collision = this.world.checkCollision(this.position.x, this.position.z, this.radius);
    if (collision) {
      this._resolveDeflection(collision, dt, k);
    }

    // 8. Combo Pressure Decay Window
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      this.updateComboHUD();
      if (this.comboTimer <= 0) {
        this.comboCount = 0;
        this.comboMultiplier = 1.0;
        this.pendingComboScore = 0;
        this.updateComboHUD();
      }
    }

    // 9. Update Visual Mesh Position & Sprung Rotations
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotation;
    this.mesh.rotation.x = this.visualPitch;
    this.mesh.rotation.z = THREE.MathUtils.clamp(this.visualRoll, -0.045, 0.045);

    // Outboard motor center exhaust glow pulsating
    const glowScale = this.isBoosting ? 1.8 + Math.random() * 0.6 : 0.8;
    const centerGlow = this.mesh.getObjectByName('exhaust_center');
    if (centerGlow) {
      centerGlow.scale.set(glowScale, glowScale, glowScale);
      centerGlow.material.color.setHex(this.isBoosting ? 0xff0055 : 0x00d2d3);
    }

    // 10. Wake & Sunwake Bow Wave Spray particles
    this.emitWake(dt);
    for (const p of this.wakeParticles) {
      if (p.mesh.visible) {
        p.life += dt;
        if (p.velocity) {
          p.mesh.position.addScaledVector(p.velocity, dt);
          p.velocity.multiplyScalar(0.92);
        }
        if (p.life >= p.maxLife) {
          p.mesh.visible = false;
        } else {
          const progress = p.life / p.maxLife;
          const s = p.scale * (1.0 + progress * 2.5);
          p.mesh.scale.set(s, s, s);
          p.mesh.material.opacity = p.alpha * (1.0 - progress);
        }
      }
    }

    // 10b. Dynamic Neon Underglow & Nanite Energy Shield
    if (this.underglowMesh && this.underglowLight) {
      const speedRatio = Math.min(1.4, Math.abs(this.speed) / CONFIG.PLAYER.MAX_SPEED);
      const pulse = Math.sin((this.lifeTime || 0) * 6) * 0.12;
      let baseOpacity = 0.65 + speedRatio * 0.35 + pulse;
      let lightIntensity = 1.4 + speedRatio * 1.2;
      let targetColor = 0x00f2fe; // Electric cyan default

      if (this.isBoosting) {
        baseOpacity = 1.0;
        lightIntensity = 3.6 + Math.random() * 0.8;
        targetColor = 0xf43f5e; // Blazing hot pink/rose under nitro
      } else if (this.isDrifting) {
        targetColor = 0xa855f7; // Neon purple during drift
        lightIntensity = 2.4;
      }

      this.underglowMesh.material.opacity = baseOpacity;
      this.underglowMesh.material.color.setHex(targetColor);
      this.underglowLight.intensity = lightIntensity;
      this.underglowLight.color.setHex(targetColor);
    }

    // Nanite Shield Update
    this.naniteShieldTimer = Math.max(0, this.naniteShieldTimer - dt);
    this.shieldFlashTimer = Math.max(0, this.shieldFlashTimer - dt);
    if (this.shieldWire && this.shieldInner) {
      if (this.naniteShieldTimer > 0) {
        this.shieldWire.rotation.y += 1.8 * dt;
        this.shieldWire.rotation.x += 1.1 * dt;
        this.shieldInner.rotation.y -= 1.3 * dt;

        const shieldPulse = 0.35 + 0.22 * Math.sin((this.lifeTime || 0) * 10);
        const flashBoost = this.shieldFlashTimer > 0 ? 0.65 : 0;
        this.shieldWire.material.opacity = Math.min(1.0, shieldPulse + flashBoost);
        this.shieldInner.material.opacity = Math.min(0.65, 0.2 + 0.15 * Math.sin((this.lifeTime || 0) * 8) + flashBoost * 0.4);
        if (this.shieldFlashTimer > 0) {
          this.shieldWire.material.color.setHex(0xffffff);
        } else {
          this.shieldWire.material.color.setHex(0x38bdf8);
        }
      } else {
        this.shieldWire.material.opacity = 0;
        this.shieldInner.material.opacity = 0;
      }
    }

    // 11. Pickups Check (Contraband, Repair Kits & Crown Diamond Cache)
    const pickup = this.world.checkPickups(this.position.x, this.position.z, this.radius);
    if (pickup === 'contraband') {
      this.score += CONFIG.CONTRABAND_SCORE;
      this.boost = this.maxBoost;
      soundManager.playAlertPing();
      this.triggerStunt('💰 CONTRABAND SECURED!', CONFIG.CONTRABAND_SCORE);
    } else if (pickup === 'repair') {
      this.health = Math.min(this.maxHealth, this.health + CONFIG.REPAIR_KIT_HEAL);
      soundManager.playAlertPing();
      this.triggerStunt('🔧 HULL REPAIRED!', 150);
    } else if (pickup === 'diamond_cache') {
      this.boost = this.maxBoost;
      this.naniteShieldTimer = CONFIG.NANITE_SHIELD_DURATION || 10.0;
      soundManager.playAlertPing();
      this.triggerStunt('💎 CROWN DIAMOND HEIST! 10s NANITE SHIELD!', CONFIG.DIAMOND_CACHE_SCORE || 1500, 5.0);
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '💎 [HEIST SECURED]: Crown Diamond recovered! Nanite Shield online (10s)!';
        dispatch.style.color = '#38bdf8';
      }
    } else if (pickup === 'railgun_crate') {
      this.railgunAmmo = Math.min(10, (this.railgunAmmo || 0) + (CONFIG.WEAPONS.RAILGUN.ammo || 5));
      soundManager.playAlertPing();
      this.triggerStunt('⚡ EXPERIMENTAL RAILGUN ARMED! 5 RDS', 950, 4.0);
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = `⚡ [PROTOTYPE WEAPONS]: Hyper-Velocity Railgun loaded (${this.railgunAmmo} rounds)! Press [E] / [RMB] to fire!`;
        dispatch.style.color = '#00f2fe';
      }
    } else if (pickup === 'emp_crate') {
      this.empAmmo = Math.min(6, (this.empAmmo || 0) + (CONFIG.WEAPONS.EMP.ammo || 3));
      soundManager.playAlertPing();
      this.triggerStunt('⚡ EMP SHOCKWAVE ARMED! 3 CHARGES', 1200, 5.0);
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = `⚡ [EXPERIMENTAL WEAPONS]: EMP Shockwave Canisters loaded (${this.empAmmo} charges)! Press [Q] to drop & disable pursuers!`;
        dispatch.style.color = '#a855f7';
      }
    } else if (pickup === 'casino_vault') {
      this.boost = this.maxBoost;
      this.naniteShieldTimer = 12.0;
      soundManager.playCasinoJackpot();
      if (window.game && window.game.addTrauma) window.game.addTrauma(0.55);
      this.triggerStunt('🎰 GRAND CASINO VAULT HEIST! +2500 PTS', (CONFIG.CASINO && CONFIG.CASINO.vaultScore) || 2500, 5.0);
      this.addWanted(2);
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '🎰 [HIGH ROLLER HEIST]: GRAND POSEIDON VAULT CRACKED! $2.5M DIAMOND SHIPMENT SECURED!';
        dispatch.style.color = '#f59e0b';
      }
    }

    // 11b. Horned Naval Mines Contact Check
    if (this.world && this.world.checkMines) {
      this.world.checkMines(this.position.x, this.position.z, this.radius, this);
    }

    // 12. Auto-Hull Regeneration
    this.timeSinceDamage = (this.timeSinceDamage || 0) + dt;
    if (this.timeSinceDamage > CONFIG.PLAYER.REGEN_DELAY && this.health < this.maxHealth * 0.60) {
      this.health = Math.min(this.maxHealth * 0.60, this.health + CONFIG.PLAYER.REGEN_RATE * dt);
    }

    // Sound engine modulation
    soundManager.updateEngine(dt, input.throttle, Math.abs(this.speed) / CONFIG.PLAYER.MAX_SPEED, this.isAirborne, this.isBoosting);
  }

  // Tangential Deflection: shallow grazes preserve speed; head-on hits push out and scrub smoothly
  _resolveDeflection(col, dt, k) {
    const dx = this.position.x - col.x;
    const dz = this.position.z - col.z;
    const dist = Math.sqrt(dx * dx + dz * dz) || 0.001;
    const nx = dx / dist;
    const nz = dz / dist;
    const normal = new THREE.Vector3(nx, 0, nz);

    // 1. Positional push-out FIRST (prevents sticky or vibrating walls)
    const overlap = (col.radius + this.radius) - dist;
    if (overlap > 0) {
      this.position.x += nx * (overlap + 0.15);
      this.position.z += nz * (overlap + 0.15);
    }

    // 1b. Coral reef hazard scraping damage
    if (col.isCoral) {
      if (this.world && this.world.spawnVoxelCrumbles) {
        this.world.spawnVoxelCrumbles(col.x, 2.5, col.z, 14, 0xf43f5e);
      }
      this.takeDamage(18);
    }

    // 2. Velocity into surface test
    const into = this.velocity.dot(normal);
    if (into >= 0) return; // Boat is already sliding away

    const speed = this.velocity.length();
    if (speed < 0.1) return;

    const dir = this.velocity.clone().normalize();
    const hitAngle = Math.abs(dir.dot(normal)); // 0 = shallow graze, 1 = head-on

    // 3. Power-curve speed scrub: shallow grazes preserve 85-95% of speed!
    const scrub = Math.max(0.20, 1.0 - 0.55 * Math.pow(hitAngle, 1.5));
    const restitution = 0.15; // Tiny bounce nudge

    // 4. Slide component along surface tangent
    const tangent = this.velocity.clone().addScaledVector(normal, -into);
    this.velocity.copy(tangent).multiplyScalar(scrub).addScaledVector(normal, -into * restitution);

    // 5. Align boat heading smoothly along tangent if glancing angle
    if (hitAngle < 0.80 && this.velocity.lengthSq() > 4) {
      const wantYaw = Math.atan2(this.velocity.x, this.velocity.z);
      this.rotation = THREE.MathUtils.lerp(this.rotation, wantYaw, 0.32 * k);
    }

    // 6. Audio thud & camera trauma
    soundManager.playThud();
    if (window.game && window.game.addTrauma) {
      window.game.addTrauma(0.12 + 0.45 * hitAngle);
    }

    // Take damage only on genuine high-speed impacts
    if (hitAngle > 0.42 && speed > 28) {
      soundManager.playExplosion(0.25, 0.2);
      this.takeDamage(speed * hitAngle * CONFIG.PLAYER.COLLISION_DAMAGE_FACTOR * 0.45);
    }
  }

  takeDamage(amount) {
    if (!this.alive) return;
    if (this.naniteShieldTimer > 0) {
      this.shieldFlashTimer = 0.28;
      soundManager.playAlertPing();
      if (window.game && window.game.addTrauma) {
        window.game.addTrauma(0.04);
      }
      return; // Damage 100% absorbed by Nanite Shield!
    }
    this.timeSinceDamage = 0;
    this.health = Math.max(0, this.health - amount);
    if (this.health <= 0) {
      this.die();
    }
  }

  setFactionManager(fm) {
    this.factionManager = fm;
  }

  die() {
    this.alive = false;
    soundManager.playExplosion(0.9, 1.2);
    this.mesh.visible = false;
  }
}
