// Boat Chase: Circular Tactical Radar Minimap
// Displays waterways, islands, player heading, enemy blips by faction, and escape point.
import { CONFIG } from './config.js';

export class Radar {
  constructor(canvasId, world, player, factionManager) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) {
      this.canvas = document.createElement('canvas');
      this.canvas.id = canvasId;
      document.body.appendChild(this.canvas);
    }
    this.ctx = this.canvas.getContext('2d');
    this.world = world;
    this.player = player;
    this.factionManager = factionManager;

    this.size = 200; // pixels
    this.canvas.width = this.size;
    this.canvas.height = this.size;
    this.radarRange = 650; // world units visible on radar radius
    this.sweepAngle = 0;
  }

  update(dt) {
    this.sweepAngle = (this.sweepAngle + dt * 2.8) % (Math.PI * 2);
    this._render();
  }

  _render() {
    const ctx = this.ctx;
    const center = this.size / 2;
    const radius = center - 8;

    ctx.clearRect(0, 0, this.size, this.size);

    // 1. Radar Circular Border & Dark Ocean Background
    ctx.save();
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(7, 24, 38, 0.88)';
    ctx.fill();
    ctx.clip(); // Keep all drawing inside circle

    // 2. Concentric Range Rings
    ctx.strokeStyle = 'rgba(0, 220, 255, 0.15)';
    ctx.lineWidth = 1;
    for (const r of [radius * 0.33, radius * 0.66, radius * 0.98]) {
      ctx.beginPath();
      ctx.arc(center, center, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Crosshairs
    ctx.beginPath();
    ctx.moveTo(center, center - radius);
    ctx.lineTo(center, center + radius);
    ctx.moveTo(center - radius, center);
    ctx.lineTo(center + radius, center);
    ctx.stroke();

    // 3. World Colliders & Islands
    const px = this.player ? this.player.position.x : 0;
    const pz = this.player ? this.player.position.z : 0;
    const scale = radius / this.radarRange;

    for (const col of this.world.colliders) {
      const dx = col.x - px;
      const dz = col.z - pz;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < this.radarRange + col.radius) {
        const sx = center + dx * scale;
        const sz = center + dz * scale;
        const sr = Math.max(2, col.radius * scale);

        ctx.beginPath();
        ctx.arc(sx, sz, sr, 0, Math.PI * 2);
        ctx.fillStyle = col.type === 'island' ? 'rgba(46, 120, 80, 0.55)' : 'rgba(100, 110, 120, 0.6)';
        ctx.fill();
      }
    }

    // 4. Safe Haven Objective
    const sh = this.world.safeHaven;
    const shDx = sh.x - px;
    const shDz = sh.z - pz;
    const shDist = Math.sqrt(shDx * shDx + shDz * shDz);
    let shSx = center + shDx * scale;
    let shSz = center + shDz * scale;

    // Clamp to edge if off-radar
    if (shDist > this.radarRange) {
      const angle = Math.atan2(shDz, shDx);
      shSx = center + Math.cos(angle) * (radius - 12);
      shSz = center + Math.sin(angle) * (radius - 12);
    }

    ctx.beginPath();
    ctx.arc(shSx, shSz, 7, 0, Math.PI * 2);
    ctx.fillStyle = '#00ff88';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Label
    ctx.font = '9px monospace';
    ctx.fillStyle = '#00ff88';
    ctx.fillText(`${Math.round(shDist)}m ESCAPE`, shSx - 22, shSz - 9);

    // 4b. Breachable Fortress Sea Gate Marker
    if (this.world && this.world.seaGate && this.world.seaGate.alive) {
      const sg = this.world.seaGate;
      const sgDx = sg.x - px;
      const sgDz = sg.z - pz;
      const sgDist = Math.sqrt(sgDx * sgDx + sgDz * sgDz);
      if (sgDist <= this.radarRange) {
        const sx = center + sgDx * scale;
        const sz = center + sgDz * scale;
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(sx - 7, sz - 2.5, 14, 5);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(sx - 7, sz - 2.5, 14, 5);
      }
    }

    // 4c. Bascule Drawbridge Marker
    if (this.world && this.world.drawbridges) {
      for (const db of this.world.drawbridges) {
        const dbDx = db.x - px;
        const dbDz = db.z - pz;
        const dbDist = Math.hypot(dbDx, dbDz);
        if (dbDist <= this.radarRange) {
          const sx = center + dbDx * scale;
          const sz = center + dbDz * scale;
          ctx.fillStyle = db.state === 'OPEN' ? '#00ff88' : (db.state === 'CLOSED' ? '#94a3b8' : '#f59e0b');
          ctx.fillRect(sx - 5, sz - 2, 10, 4);
        }
      }
    }

    // 4d. Floating Spike Net Markers
    if (this.world && this.world.spikeNets) {
      for (const net of this.world.spikeNets) {
        if (!net.alive) continue;
        const nDx = net.x - px;
        const nDz = net.z - pz;
        const nDist = Math.hypot(nDx, nDz);
        if (nDist <= this.radarRange) {
          const sx = center + nDx * scale;
          const sz = center + nDz * scale;
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(sx - 4, sz);
          ctx.lineTo(sx + 4, sz);
          ctx.stroke();
        }
      }
    }

    // 4d-2. Horned Naval Contact Mines
    if (this.world && this.world.mines) {
      for (const mine of this.world.mines) {
        if (!mine.alive) continue;
        const mdx = mine.x - px;
        const mdz = mine.z - pz;
        if (Math.hypot(mdx, mdz) <= this.radarRange) {
          const msx = center + mdx * scale;
          const msz = center + mdz * scale;
          ctx.save();
          ctx.translate(msx, msz);
          ctx.beginPath();
          ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
          ctx.fillStyle = '#ef4444';
          ctx.fill();
          ctx.strokeStyle = '#f87171';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-3.5, 0); ctx.lineTo(3.5, 0);
          ctx.moveTo(0, -3.5); ctx.lineTo(0, 3.5);
          ctx.stroke();
          ctx.restore();
        }
      }
    }

    // 4e. Floating Pickups & Crown Diamond Cache Blips
    if (this.world && this.world.pickups) {
      for (const p of this.world.pickups) {
        if (!p.alive) continue;
        const pdx = p.x - px;
        const pdz = p.z - pz;
        if (Math.hypot(pdx, pdz) <= this.radarRange) {
          const psx = center + pdx * scale;
          const psz = center + pdz * scale;
          ctx.save();
          ctx.translate(psx, psz);
          if (p.type === 'diamond_cache') {
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('💎', 0, 0);
          } else if (p.type === 'railgun_crate') {
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('⚡', 0, 0);
          } else if (p.type === 'emp_crate') {
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('⚡', 0, 0);
            ctx.strokeStyle = '#a855f7';
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.arc(0, 0, 7, 0, Math.PI * 2);
            ctx.stroke();
          } else if (p.type === 'contraband') {
            ctx.fillStyle = '#f59e0b';
            ctx.fillRect(-2.5, -2.5, 5, 5);
          } else if (p.type === 'repair') {
            ctx.fillStyle = '#10b981';
            ctx.fillRect(-2, -2, 4, 4);
          }
          ctx.restore();
        }
      }
    }

    // 4f. Offshore Oil Rig Refinery Platform Marker
    if (this.world && this.world.oilRig) {
      const rig = this.world.oilRig;
      const rdx = rig.x - px;
      const rdz = rig.z - pz;
      if (Math.hypot(rdx, rdz) <= this.radarRange) {
        const rsx = center + rdx * scale;
        const rsz = center + rdz * scale;
        ctx.save();
        ctx.translate(rsx, rsz);
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⛽', 0, 0);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, Math.PI * 2);
        ctx.stroke();

        // Fuel tank dots
        if (rig.tanks) {
          for (const t of rig.tanks) {
            if (t.alive) {
              const tox = (t.x - rig.x) * scale;
              const toz = (t.z - rig.z) * scale;
              ctx.fillStyle = '#ef4444';
              ctx.beginPath();
              ctx.arc(tox, toz, 1.8, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }
        ctx.restore();
      }
    }

    // 4g. Secret Submarine Pen Cavern Dock Marker
    if (this.world && this.world.subPen) {
      const pen = this.world.subPen;
      const pdx = pen.x - px;
      const pdz = pen.z - pz;
      if (Math.hypot(pdx, pdz) <= this.radarRange) {
        const psx = center + pdx * scale;
        const psz = center + pdz * scale;
        ctx.save();
        ctx.translate(psx, psz);
        ctx.font = 'bold 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⚓', 0, 0);
        ctx.strokeStyle = '#00f2fe';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4h. Naval Supercarrier "USS Leviathan" Marker
    if (this.world && this.world.carrier) {
      const c = this.world.carrier;
      const cdx = c.x - px;
      const cdz = c.z - pz;
      if (Math.hypot(cdx, cdz) <= this.radarRange) {
        const csx = center + cdx * scale;
        const csz = center + cdz * scale;
        ctx.save();
        ctx.translate(csx, csz);
        ctx.font = 'bold 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🚢', 0, 0);
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(0, 0, 10, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4i. Floating Seaplane Hangar & Water Runway Marker
    if (this.world && this.world.seaplaneHangar) {
      const h = this.world.seaplaneHangar;
      const hdx = h.x - px;
      const hdz = h.z - pz;
      if (Math.hypot(hdx, hdz) <= this.radarRange) {
        const hsx = center + hdx * scale;
        const hsz = center + hdz * scale;
        ctx.save();
        ctx.translate(hsx, hsz);
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🛩️', 0, 0);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, Math.PI * 2);
        ctx.stroke();

        // Water runway dashed line extending south
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 1.0;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(0, 8);
        ctx.lineTo(0, 8 + 190 * scale);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }
    }

    // 4j. Smuggler's Sea Arch Cavern & Slalom Spire Marker
    if (this.world && this.world.seaArch) {
      const arch = this.world.seaArch;
      const adx = arch.x - px;
      const adz = arch.z - pz;
      if (Math.hypot(adx, adz) <= this.radarRange) {
        const asx = center + adx * scale;
        const asz = center + adz * scale;
        ctx.save();
        ctx.translate(asx, asz);
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🗿', 0, 0);
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4k. Dynamic Rogue Tidal Wave Surge Wavefront Line
    if (this.world && this.world.rogueWave && this.world.rogueWave.active) {
      const rw = this.world.rogueWave;
      const rdx = rw.x - px;
      const rdz = rw.z - pz;
      if (Math.hypot(rdx, rdz) <= this.radarRange + rw.width * 0.5) {
        const rsx = center + rdx * scale;
        const rsz = center + rdz * scale;
        ctx.save();
        ctx.translate(rsx, rsz);
        ctx.rotate(-rw.angle + Math.PI * 0.5); // Perpendicular to heading
        const halfW = (rw.width * 0.5) * scale;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2.4;
        ctx.shadowColor = '#00f2fe';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.moveTo(-halfW, 0);
        ctx.lineTo(halfW, 0);
        ctx.stroke();

        // Wave crest chevron indicators pointing in propagation direction
        ctx.fillStyle = '#ffffff';
        for (let i = -halfW + 6; i <= halfW - 6; i += 12) {
          ctx.beginPath();
          ctx.moveTo(i, 0);
          ctx.lineTo(i - 2.5, -4);
          ctx.lineTo(i + 2.5, -4);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      }
    }

    // 4l. Sentinel Lighthouse Island & Sweeping Searchlight Marker
    if (this.world && this.world.lighthouse) {
      const lh = this.world.lighthouse;
      const ldx = lh.x - px;
      const ldz = lh.z - pz;
      if (Math.hypot(ldx, ldz) <= this.radarRange + lh.beamLength) {
        const lsx = center + ldx * scale;
        const lsz = center + ldz * scale;
        ctx.save();
        ctx.translate(lsx, lsz);

        // Sweeping searchlight cone arc
        const beamL = lh.beamLength * scale;
        ctx.save();
        ctx.rotate(-lh.angle + Math.PI * 0.5);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, beamL, -0.22, 0.22);
        ctx.closePath();
        ctx.fillStyle = 'rgba(254, 240, 138, 0.22)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(254, 240, 138, 0.65)';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.restore();

        ctx.font = 'bold 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🗼', 0, 0);
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4m. Sunken Galleon Coral Ramp Reef Marker
    const gCfg = CONFIG.SUNKEN_GALLEON;
    if (gCfg) {
      const gdx = gCfg.x - px;
      const gdz = gCfg.z - pz;
      if (Math.hypot(gdx, gdz) <= this.radarRange) {
        const gsx = center + gdx * scale;
        const gsz = center + gdz * scale;
        ctx.save();
        ctx.translate(gsx, gsz);
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🏴‍☠️', 0, 0);
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, 7, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4n. Waterspout Vortex Hazard Marker
    if (this.world && this.world.waterspout) {
      const wsp = this.world.waterspout;
      const wdx = wsp.x - px;
      const wdz = wsp.z - pz;
      if (Math.hypot(wdx, wdz) <= this.radarRange + wsp.radius) {
        const wsx = center + wdx * scale;
        const wsz = center + wdz * scale;
        ctx.save();
        ctx.translate(wsx, wsz);

        // Suction vortex radius ring
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.arc(0, 0, (wsp.suctionRadius || 55) * scale, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.font = 'bold 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🌪️', 0, 0);
        ctx.restore();
      }
    }

    // 4o. Floating Offshore Casino Palace & Luxury Superyacht Marina Marker
    if (this.world && this.world.casino) {
      const c = this.world.casino;
      const cdx = c.x - px;
      const cdz = c.z - pz;
      if (Math.hypot(cdx, cdz) <= this.radarRange + 70) {
        const csx = center + cdx * scale;
        const csz = center + cdz * scale;
        ctx.save();
        ctx.translate(csx, csz);

        // Casino perimeter gold ring
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.stroke();

        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🎰', 0, 0);
        ctx.restore();
      }
    }

    // 5. Enemy Blips with Faction Colors & Alert States
    if (this.factionManager) {
      for (const enemy of this.factionManager.enemies) {
        if (!enemy.alive) continue;
        const edx = enemy.position.x - px;
        const edz = enemy.position.z - pz;
        const edist = Math.sqrt(edx * edx + edz * edz);

        if (edist <= this.radarRange) {
          const esx = center + edx * scale;
          const esz = center + edz * scale;

          if (enemy.isIronclad) {
            // Pirate Boss: Blackbeard's Ironclad Galleon
            ctx.save();
            ctx.translate(esx, esz);
            ctx.font = 'bold 13px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('☠️', 0, 0);
            ctx.strokeStyle = enemy.state === 'ALERTED' ? '#ef4444' : '#d97706';
            ctx.lineWidth = 1.6;
            ctx.beginPath();
            ctx.arc(0, 0, 9, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
          } else if (enemy.isConvoyLeader) {
            // Cartel Flagship with Crown Diamond
            ctx.save();
            ctx.translate(esx, esz);
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('👑', 0, 0);
            ctx.strokeStyle = enemy.state === 'ALERTED' ? '#ef4444' : '#f59e0b';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(0, 0, 8, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
          } else if (enemy.isHovercraft) {
            // Cartel Armored Amphibious Hovercraft Gunship
            ctx.save();
            ctx.translate(esx, esz);
            ctx.beginPath();
            ctx.ellipse(0, 0, 7, 5, enemy.rotation || 0, 0, Math.PI * 2);
            ctx.fillStyle = '#f59e0b';
            ctx.fill();
            ctx.strokeStyle = enemy.state === 'ALERTED' ? '#ef4444' : '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(-3, -2, 2, 4);
            ctx.fillRect(1, -2, 2, 4);
            ctx.restore();
          } else if (enemy.isSecurityCatamaran) {
            // Casino Security Catamaran twin hull icon
            ctx.save();
            ctx.translate(esx, esz);
            ctx.fillStyle = '#00f2fe';
            ctx.fillRect(-4, -4, 2.5, 8);
            ctx.fillRect(1.5, -4, 2.5, 8);
            ctx.strokeStyle = enemy.state === 'ALERTED' ? '#ef4444' : '#ffffff';
            ctx.lineWidth = 1.2;
            ctx.strokeRect(-4, -4, 8, 8);
            ctx.restore();
          } else if (enemy.isHeavy) {
            // Heavy Interceptor Cutter diamond icon
            ctx.save();
            ctx.translate(esx, esz);
            ctx.beginPath();
            ctx.moveTo(0, -6);
            ctx.lineTo(6, 0);
            ctx.lineTo(0, 6);
            ctx.lineTo(-6, 0);
            ctx.closePath();
            ctx.fillStyle = '#38bdf8';
            ctx.fill();
            ctx.strokeStyle = enemy.state === 'ALERTED' ? '#ef4444' : '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            ctx.restore();
          } else {
            ctx.beginPath();
            ctx.arc(esx, esz, enemy.state === 'ALERTED' ? 5 : 3.5, 0, Math.PI * 2);
            ctx.fillStyle = enemy.faction.hudColor;
            ctx.fill();

            // Alert ring if actively chasing
            if (enemy.state === 'ALERTED') {
              ctx.strokeStyle = '#ff0044';
              ctx.lineWidth = 1.5;
              ctx.stroke();
            }
          }
        }
      }

      // Air-1 Police Helicopter radar blip
      if (this.factionManager.helicopter && this.factionManager.helicopter.alive) {
        const h = this.factionManager.helicopter;
        const hdx = h.position.x - px;
        const hdz = h.position.z - pz;
        const hdist = Math.sqrt(hdx * hdx + hdz * hdz);
        if (hdist <= this.radarRange) {
          const hsx = center + hdx * scale;
          const hsz = center + hdz * scale;
          ctx.save();
          ctx.translate(hsx, hsz);
          ctx.font = 'bold 11px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🚁', 0, 0);
          ctx.restore();
        }
      }

      // Naval Zeppelin Gunship Boss radar blip
      if (this.factionManager.zeppelin && this.factionManager.zeppelin.alive) {
        const z = this.factionManager.zeppelin;
        const zdx = z.position.x - px;
        const zdz = z.position.z - pz;
        const zdist = Math.sqrt(zdx * zdx + zdz * zdz);
        if (zdist <= this.radarRange) {
          const zsx = center + zdx * scale;
          const zsz = center + zdz * scale;
          ctx.save();
          ctx.translate(zsx, zsz);
          ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(0, 0, 10, 0, Math.PI * 2);
          ctx.stroke();
          ctx.font = 'bold 13px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🎈', 0, 0);
          ctx.restore();
        }
      }
    }

    // 6. Sweeping Beam
    const sweepGrad = ctx.createRadialGradient(center, center, 0, center, center, radius);
    sweepGrad.addColorStop(0, 'rgba(0, 255, 200, 0.0)');
    sweepGrad.addColorStop(1, 'rgba(0, 255, 200, 0.18)');

    ctx.beginPath();
    ctx.moveTo(center, center);
    ctx.arc(center, center, radius, this.sweepAngle, this.sweepAngle + 0.35);
    ctx.closePath();
    ctx.fillStyle = sweepGrad;
    ctx.fill();

    // 7. Player Indicator (Center Triangle)
    ctx.save();
    ctx.translate(center, center);
    if (this.player) {
      // Rotation on radar matches player heading
      ctx.rotate(-this.player.rotation + Math.PI);
    }
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5, 6);
    ctx.lineTo(-5, 6);
    ctx.closePath();
    ctx.fillStyle = '#00ffff';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();

    ctx.restore(); // Restore clipping

    // Outer Neon Ring
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.strokeStyle = '#00f2fe';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = '#00f2fe';
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }
}
