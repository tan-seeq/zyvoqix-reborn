// Boat Chase: Procedural Web Audio Sound Synthesizer & BGM Radio
// 100% self-contained synthesized sound effects & multi-station radio, zero external files needed.

class ArcadeBGMSequencer {
  constructor(soundManager) {
    this.sound = soundManager;
    this.ctx = null;
    this.isPlaying = false;
    this.bpm = 126;
    this.step = 0;
    this.timer = null;
    this.nextNoteTime = 0;
    this.bassFilter = null;
    this.leadFilter = null;
    this.noiseBuffer = null;
    this.radioGain = null;
    this.stationIndex = 0;
    this.stations = [
      { name: "Neon Drive 104.2 FM", bpm: 126, genre: "Synthwave / Outrun" },
      { name: "Cyber Rush 168.0 FM", bpm: 168, genre: "Drum & Bass Chase" },
      { name: "Midnight Drift 88.5 FM", bpm: 88, genre: "Lo-Fi Electro Funk" }
    ];
  }

  init(ctx, masterGain) {
    this.ctx = ctx;

    // Dedicated radio volume bus with ducking support
    this.radioGain = this.ctx.createGain();
    this.radioGain.gain.setValueAtTime(0.42, this.ctx.currentTime);
    this.radioGain.connect(masterGain);

    // Pre-allocate noise buffer for snares and hi-hats
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.5);
    this.noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    // Bassline resonant lowpass filter
    this.bassFilter = this.ctx.createBiquadFilter();
    this.bassFilter.type = 'lowpass';
    this.bassFilter.frequency.setValueAtTime(750, this.ctx.currentTime);
    this.bassFilter.Q.setValueAtTime(3.2, this.ctx.currentTime);
    this.bassFilter.connect(this.radioGain);

    // Lead arpeggio bandpass filter
    this.leadFilter = this.ctx.createBiquadFilter();
    this.leadFilter.type = 'bandpass';
    this.leadFilter.frequency.setValueAtTime(1350, this.ctx.currentTime);
    this.leadFilter.Q.setValueAtTime(2.0, this.ctx.currentTime);
    this.leadFilter.connect(this.radioGain);
  }

  getCurrentStation() {
    return this.stations[this.stationIndex];
  }

  nextStation() {
    this.stationIndex = (this.stationIndex + 1) % this.stations.length;
    const station = this.stations[this.stationIndex];
    this.bpm = station.bpm;
    this.step = 0;
    this.sound.playTone(480, 0.09, 'sawtooth');
    return station;
  }

  start() {
    if (this.isPlaying || !this.ctx) return;
    this.isPlaying = true;
    this.step = 0;
    this.nextNoteTime = this.ctx.currentTime + 0.05;
    this._schedulerLoop();
  }

  stop() {
    this.isPlaying = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  toggle() {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  duckRadio(duckAmount = 0.15, duration = 0.55) {
    if (!this.ctx || !this.radioGain || !this.isPlaying) return;
    const now = this.ctx.currentTime;
    this.radioGain.gain.cancelScheduledValues(now);
    this.radioGain.gain.setValueAtTime(this.radioGain.gain.value, now);
    this.radioGain.gain.linearRampToValueAtTime(duckAmount, now + 0.03);
    this.radioGain.gain.linearRampToValueAtTime(0.42, now + duration);
  }

  _schedulerLoop() {
    if (!this.isPlaying || !this.ctx) return;

    // Lookahead audio scheduling: queue 200ms of events ahead of AudioContext clock
    const lookahead = 0.20;
    while (this.nextNoteTime < this.ctx.currentTime + lookahead) {
      this._playStep(this.step, this.nextNoteTime);
      const secondsPer16th = (60.0 / this.bpm) / 4.0;
      this.nextNoteTime += secondsPer16th;
      this.step = (this.step + 1) % 32;
    }

    this.timer = setTimeout(() => this._schedulerLoop(), 25);
  }

  _playStep(step, time) {
    if (!this.ctx || this.sound.muted) return;
    const ctx = this.ctx;

    // 1. Heavy Arcade Kick Drum (4-on-the-floor beat)
    if (step % 4 === 0) {
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(140, time);
        osc.frequency.exponentialRampToValueAtTime(28, time + 0.11);
        gain.gain.setValueAtTime(0.26, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.11);
        osc.connect(gain);
        gain.connect(this.radioGain);
        osc.start(time);
        osc.stop(time + 0.11);
      } catch (e) {}
    }

    // 2. Snappy Snare (Backbeats: 4, 12, 20, 28)
    if (step % 8 === 4) {
      try {
        if (this.noiseBuffer) {
          const noise = ctx.createBufferSource();
          noise.buffer = this.noiseBuffer;
          const filter = ctx.createBiquadFilter();
          filter.type = 'highpass';
          filter.frequency.setValueAtTime(900, time);
          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0.19, time);
          gain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
          noise.connect(filter);
          filter.connect(gain);
          gain.connect(this.radioGain);
          noise.start(time);
          noise.stop(time + 0.15);
        }
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(180, time);
        osc.frequency.exponentialRampToValueAtTime(60, time + 0.08);
        gain.gain.setValueAtTime(0.14, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.08);
        osc.connect(gain);
        gain.connect(this.radioGain);
        osc.start(time);
        osc.stop(time + 0.08);
      } catch (e) {}
    }

    // 3. Hi-Hats (Running 16th notes, accented on offbeats)
    if (step % 2 === 0 && this.noiseBuffer) {
      try {
        const isAccent = (step % 4 === 2);
        const hat = ctx.createBufferSource();
        hat.buffer = this.noiseBuffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(7200, time);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(isAccent ? 0.065 : 0.03, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + (isAccent ? 0.055 : 0.035));
        hat.connect(filter);
        filter.connect(gain);
        gain.connect(this.radioGain);
        hat.start(time);
        hat.stop(time + 0.06);
      } catch (e) {}
    }

    // 4. Funky Synthwave Bassline (D minor groove)
    const bassNotes = [
      73.4, 0, 73.4, 87.3, 0, 98.0, 0, 110.0,
      73.4, 73.4, 0, 130.8, 110.0, 0, 87.3, 0,
      73.4, 0, 73.4, 87.3, 0, 98.0, 0, 146.8,
      130.8, 0, 110.0, 0, 87.3, 98.0, 87.3, 0
    ];
    const bassFreq = bassNotes[step];
    if (bassFreq > 0 && this.bassFilter) {
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(bassFreq, time);
        gain.gain.setValueAtTime(0.13, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.16);
        osc.connect(gain);
        gain.connect(this.bassFilter);
        osc.start(time);
        osc.stop(time + 0.16);
      } catch (e) {}
    }

    // 5. Chiptune Lead Arpeggio (Neon Outrun Melody)
    const leadArp = [
      293.7, 349.2, 440.0, 523.3, 440.0, 349.2, 293.7, 349.2,
      440.0, 523.3, 587.3, 523.3, 440.0, 349.2, 440.0, 523.3
    ];
    const leadFreq = leadArp[step % 16];
    if (leadFreq > 0 && this.leadFilter && (step % 2 === 0 || this.stationIndex === 1)) {
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(leadFreq, time);
        gain.gain.setValueAtTime(0.038, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.11);
        osc.connect(gain);
        gain.connect(this.leadFilter);
        osc.start(time);
        osc.stop(time + 0.11);
      } catch (e) {}
    }
  }
}

class SoundManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.sfxGain = null;
    this.engineNode = null;
    this.engineSubNode = null;
    this.engineGain = null;
    this.boostNode = null;
    this.boostGain = null;
    this.sprayNode = null;
    this.sprayGain = null;
    this.rpm = 0;
    this.initialized = false;
    this.muted = false;
    this.radio = new ArcadeBGMSequencer(this);
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.72, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.85, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);

      this._initEngineSound();
      this._initHelicopterAudio();
      this.radio.init(this.ctx, this.masterGain);
      this.radio.start();
      this.initialized = true;
    } catch (e) {
      console.warn("Web Audio initialization error:", e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    if (!this.radio.isPlaying && !this.muted) {
      this.radio.start();
    }
  }

  _initEngineSound() {
    // Primary offshore boat engine oscillator (sawtooth V8 bite)
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(52, this.ctx.currentTime);

    // Sub oscillator for deep hull bass rumble
    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'triangle';
    subOsc.frequency.setValueAtTime(26, this.ctx.currentTime);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(280, this.ctx.currentTime);
    filter.Q.setValueAtTime(2.0, this.ctx.currentTime);

    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.setValueAtTime(0.04, this.ctx.currentTime);

    osc.connect(filter);
    subOsc.connect(filter);
    filter.connect(this.engineGain);
    this.engineGain.connect(this.masterGain);

    osc.start();
    subOsc.start();
    this.engineNode = osc;
    this.engineSubNode = subOsc;

    // Nitro Boost whoosh (bandpass filtered noise)
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const boostFilter = this.ctx.createBiquadFilter();
    boostFilter.type = 'bandpass';
    boostFilter.frequency.setValueAtTime(850, this.ctx.currentTime);
    boostFilter.Q.setValueAtTime(1.8, this.ctx.currentTime);

    this.boostGain = this.ctx.createGain();
    this.boostGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);

    whiteNoise.connect(boostFilter);
    boostFilter.connect(this.boostGain);
    this.boostGain.connect(this.masterGain);
    whiteNoise.start();
    this.boostNode = whiteNoise;

    // Water spray rushing noise
    const sprayNoise = this.ctx.createBufferSource();
    sprayNoise.buffer = noiseBuffer;
    sprayNoise.loop = true;

    const sprayFilter = this.ctx.createBiquadFilter();
    sprayFilter.type = 'highpass';
    sprayFilter.frequency.setValueAtTime(1200, this.ctx.currentTime);

    this.sprayGain = this.ctx.createGain();
    this.sprayGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);

    sprayNoise.connect(sprayFilter);
    sprayFilter.connect(this.sprayGain);
    this.sprayGain.connect(this.masterGain);
    sprayNoise.start();
    this.sprayNode = sprayNoise;
  }

  _initHelicopterAudio() {
    // Low frequency rotor chop (18 Hz blade pulse modulated lowpass)
    const chopperOsc = this.ctx.createOscillator();
    chopperOsc.type = 'sawtooth';
    chopperOsc.frequency.setValueAtTime(18, this.ctx.currentTime);

    const chopperFilter = this.ctx.createBiquadFilter();
    chopperFilter.type = 'lowpass';
    chopperFilter.frequency.setValueAtTime(160, this.ctx.currentTime);
    chopperFilter.Q.setValueAtTime(3.5, this.ctx.currentTime);

    this.chopperGain = this.ctx.createGain();
    this.chopperGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);

    chopperOsc.connect(chopperFilter);
    chopperFilter.connect(this.chopperGain);
    this.chopperGain.connect(this.masterGain);
    chopperOsc.start();
    this.chopperNode = chopperOsc;
  }

  // Reactive engine RPM: instantly snaps on throttle, flares up when propeller unloads in the air!
  updateEngine(dt, throttle, speedFraction, isAirborne, isBoosting) {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    const k = Math.min(Math.max((dt || 0.016) * 60, 0.2), 2.0);

    // Target RPM derives from throttle attack first so sound reacts in 1 frame
    const targetRPM = throttle > 0
      ? 0.35 + 0.65 * speedFraction
      : speedFraction * 0.40;

    const rate = throttle > 0 ? 0.24 : 0.08;
    this.rpm += (targetRPM - this.rpm) * (1 - Math.pow(1 - rate, k));

    // Propeller unloads during stunt airtime -> instant screaming rev flare!
    if (isAirborne) {
      this.rpm = Math.min(1.20, this.rpm + 0.35 * (dt || 0.016) * 60);
    }

    const baseFreq = 48 * (1 + this.rpm * 2.8) + (isBoosting ? 28 : 0);
    this.engineNode.frequency.setTargetAtTime(baseFreq, t, 0.05);
    this.engineSubNode.frequency.setTargetAtTime(baseFreq * 0.5, t, 0.05);

    const targetGain = 0.035 + this.rpm * 0.085;
    this.engineGain.gain.setTargetAtTime(targetGain, t, 0.05);

    const targetBoostGain = isBoosting ? 0.20 : 0.0001;
    this.boostGain.gain.setTargetAtTime(targetBoostGain, t, 0.04);

    const targetSprayGain = Math.min(0.12, speedFraction * 0.12);
    this.sprayGain.gain.setTargetAtTime(isAirborne ? 0.01 : targetSprayGain, t, 0.06);
  }

  playTone(freq, duration = 0.1, type = 'sine') {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + duration);
  }

  playThud() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(120, t);
    osc.frequency.exponentialRampToValueAtTime(32, t + 0.12);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.38, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  playNearMiss() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, t);
    osc.frequency.exponentialRampToValueAtTime(920, t + 0.18);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.20);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.20);
  }

  playComboBonus(multiplier = 1) {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const baseFreq = 440 * Math.min(2.5, 1.0 + (multiplier - 1) * 0.25);

    [0, 0.08, 0.16].forEach((delay, idx) => {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq * (1 + idx * 0.25), t + delay);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.18, t + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.18);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t + delay);
      osc.stop(t + delay + 0.2);
    });
  }

  playGunfire(pitch = 1.0) {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(380 * pitch, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.07);

    const bufferSize = this.ctx.sampleRate * 0.07;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.24, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);

    osc.connect(gain);
    noise.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    noise.start(t);
    osc.stop(t + 0.07);
    noise.stop(t + 0.07);
  }

  playCannon() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(28, t + 0.45);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.55, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.48);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.48);

    this.playExplosion(0.3, 0.25);
  }

  playExplosion(volume = 0.5, duration = 0.6) {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    // Duck radio during explosions
    this.radio.duckRadio(0.12, duration + 0.2);

    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const decay = Math.exp(-i / (bufferSize * 0.3));
      data[i] = (Math.random() * 2 - 1) * decay;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(340, t);
    filter.frequency.exponentialRampToValueAtTime(55, t + duration);

    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(95, t);
    subOsc.frequency.exponentialRampToValueAtTime(22, t + duration);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(volume, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    noise.connect(filter);
    filter.connect(gain);
    subOsc.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(t);
    subOsc.start(t);
    noise.stop(t + duration);
    subOsc.stop(t + duration);
  }

  playAlertPing() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, t);
    osc.frequency.setValueAtTime(1320, t + 0.08);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.25);
  }

  playPoliceSirenChirp() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(650, t);
    osc.frequency.linearRampToValueAtTime(950, t + 0.15);
    osc.frequency.linearRampToValueAtTime(650, t + 0.3);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1400, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.32);
  }

  playSplash() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.38);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.35));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(650, t);
    filter.frequency.exponentialRampToValueAtTime(220, t + 0.38);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);
    noise.stop(t + 0.38);
  }

  playRocketLaunch() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(700, t + 0.3);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.4);
  }

  playHarpoonLaunch() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(450, t);
    osc.frequency.exponentialRampToValueAtTime(1900, t + 0.12);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.24, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  playHarpoonSlingshot() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.exponentialRampToValueAtTime(980, t + 0.26);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1200, t);
    filter.frequency.exponentialRampToValueAtTime(3200, t + 0.26);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.32, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.28);
  }

  playRoadblockSmash() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.1, 0.45);

    const bufferSize = Math.floor(this.ctx.sampleRate * 0.35);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(550, t);
    filter.frequency.exponentialRampToValueAtTime(120, t + 0.35);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.48, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);
    noise.stop(t + 0.35);

    this.playThud();
  }

  updateHelicopterSound(active, distToPlayer = 100) {
    if (!this.initialized || !this.chopperGain || !this.ctx) return;
    const now = this.ctx.currentTime;
    if (!active || this.muted) {
      this.chopperGain.gain.setTargetAtTime(0.0001, now, 0.25);
    } else {
      const vol = Math.min(0.24, 35 / (distToPlayer + 32));
      this.chopperGain.gain.setTargetAtTime(vol, now, 0.12);
    }
  }

  playThunder() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.15, 1.8);

    const duration = 1.8;
    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const decay = Math.exp(-i / (bufferSize * 0.42));
      data[i] = (Math.random() * 2 - 1) * decay;
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(110, t);
    filter.frequency.exponentialRampToValueAtTime(35, t + duration);

    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(55, t);
    subOsc.frequency.exponentialRampToValueAtTime(16, t + duration);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.65, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    noise.connect(filter);
    filter.connect(gain);
    subOsc.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(t);
    subOsc.start(t);
    noise.stop(t + duration);
    subOsc.stop(t + duration);
  }

  playRailgunFire() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.08, 0.45);

    // 1. Supersonic electromagnetic zap
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(2600, t);
    osc.frequency.exponentialRampToValueAtTime(120, t + 0.22);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(4500, t);
    filter.frequency.exponentialRampToValueAtTime(800, t + 0.22);

    const oscGain = this.ctx.createGain();
    oscGain.gain.setValueAtTime(0.55, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(filter);
    filter.connect(oscGain);
    oscGain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.25);

    // 2. Sub-bass kinetic cavitation punch
    const sub = this.ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(75, t);
    sub.frequency.exponentialRampToValueAtTime(32, t + 0.35);

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.65, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

    sub.connect(subGain);
    subGain.connect(this.sfxGain);
    sub.start(t);
    sub.stop(t + 0.38);
  }

  playSonarPing() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1080, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 1.6);
  }

  playEMPBlast() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.02, 1.8);

    // 1. High-frequency electrostatic discharge spark
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(3200, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.35);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1800, t);
    filter.frequency.exponentialRampToValueAtTime(300, t + 0.35);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.65, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.38);

    // 2. Heavy 60Hz magnetic induction hum
    const hum = this.ctx.createOscillator();
    hum.type = 'sawtooth';
    hum.frequency.setValueAtTime(60, t);
    hum.frequency.setValueAtTime(58, t + 0.8);

    const humFilter = this.ctx.createBiquadFilter();
    humFilter.type = 'lowpass';
    humFilter.frequency.setValueAtTime(140, t);

    const humGain = this.ctx.createGain();
    humGain.gain.setValueAtTime(0.5, t);
    humGain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);

    hum.connect(humFilter);
    humFilter.connect(humGain);
    humGain.connect(this.sfxGain);
    hum.start(t);
    hum.stop(t + 1.2);
  }

  playFireIgnite() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;

    const bufferSize = Math.floor(this.ctx.sampleRate * 0.45);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.2));
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(320, t);
    filter.frequency.exponentialRampToValueAtTime(1200, t + 0.15);
    filter.frequency.exponentialRampToValueAtTime(180, t + 0.45);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.48, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);
  }

  playRampLaunch() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(840, t + 0.28);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1800, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.38, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.32);

    this.playSplash();
  }

  playRogueWaveSurge() {
    if (!this.initialized) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.15, 2.2);

    // 1. Heavy sub-bass swell rumble
    const sub = this.ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(42, t);
    sub.frequency.exponentialRampToValueAtTime(26, t + 1.8);

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.75, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 2.0);

    sub.connect(subGain);
    subGain.connect(this.sfxGain);
    sub.start(t);
    sub.stop(t + 2.0);

    // 2. Churning ocean foam crest wash
    const bufferSize = Math.floor(this.ctx.sampleRate * 1.5);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, t);
    filter.frequency.exponentialRampToValueAtTime(120, t + 1.5);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.55, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);
  }

  playFogHorn() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.18, 2.4);

    // Deep dual-tone resonant foghorn blast
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc2.type = 'sawtooth';
    osc1.frequency.setValueAtTime(115, t);
    osc2.frequency.setValueAtTime(118.5, t); // Chorus beat

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, t);
    filter.frequency.exponentialRampToValueAtTime(160, t + 2.2);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.48, t + 0.25);
    gain.gain.setValueAtTime(0.48, t + 1.6);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 2.4);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 2.4);
    osc2.stop(t + 2.4);
  }

  playSearchlightAlarm() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1350, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.18);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1200, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.26, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.18);
  }

  playWaterspoutRoar() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.12, 1.8);

    // 1. Swirling wind vortex roar
    const bufferSize = Math.floor(this.ctx.sampleRate * 1.8);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const swirl = Math.sin((i / bufferSize) * Math.PI * 6);
      data[i] = (Math.random() * 2 - 1) * (0.6 + 0.4 * swirl);
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(380, t);
    filter.frequency.linearRampToValueAtTime(750, t + 0.8);
    filter.frequency.linearRampToValueAtTime(280, t + 1.8);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.55, t + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.8);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(t);

    // 2. Sub-bass updraft rumble
    const sub = this.ctx.createOscillator();
    sub.type = 'sawtooth';
    sub.frequency.setValueAtTime(55, t);
    sub.frequency.exponentialRampToValueAtTime(110, t + 1.2);

    const subFilter = this.ctx.createBiquadFilter();
    subFilter.type = 'lowpass';
    subFilter.frequency.setValueAtTime(160, t);

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.42, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 1.8);

    sub.connect(subFilter);
    subFilter.connect(subGain);
    subGain.connect(this.sfxGain);
    sub.start(t);
    sub.stop(t + 1.8);
  }

  playAutocannon() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.12);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1800, t);
    filter.frequency.exponentialRampToValueAtTime(320, t + 0.12);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.14);
  }

  playCasinoJackpot() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.15, 2.2);

    // Fast sparkling arpeggio chords (C major pentatonic: C5, E5, G5, A5, C6, E6, G6)
    const notes = [523.25, 659.25, 783.99, 880.00, 1046.50, 1318.51, 1567.98];
    for (let i = 0; i < 14; i++) {
      const noteTime = t + i * 0.085;
      const freq = notes[i % notes.length] * (i >= 7 ? 1.5 : 1.0);

      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.24, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.22);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(noteTime);
      osc.stop(noteTime + 0.22);
    }

    // Celebratory brass synth stab
    const brass = this.ctx.createOscillator();
    brass.type = 'sawtooth';
    brass.frequency.setValueAtTime(261.63, t + 0.6);
    brass.frequency.linearRampToValueAtTime(523.25, t + 0.8);

    const brassFilter = this.ctx.createBiquadFilter();
    brassFilter.type = 'lowpass';
    brassFilter.frequency.setValueAtTime(800, t + 0.6);
    brassFilter.frequency.linearRampToValueAtTime(2400, t + 0.8);
    brassFilter.frequency.exponentialRampToValueAtTime(300, t + 2.0);

    const brassGain = this.ctx.createGain();
    brassGain.gain.setValueAtTime(0.01, t + 0.6);
    brassGain.gain.linearRampToValueAtTime(0.35, t + 0.7);
    brassGain.gain.exponentialRampToValueAtTime(0.001, t + 2.0);

    brass.connect(brassFilter);
    brassFilter.connect(brassGain);
    brassGain.connect(this.sfxGain);
    brass.start(t + 0.6);
    brass.stop(t + 2.0);
  }

  playShockCannon() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(850, t);
    osc.frequency.exponentialRampToValueAtTime(140, t + 0.16);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1600, t);
    filter.Q.setValueAtTime(4.0, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.32, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.16);
  }

  playAirRaidSiren() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;
    this.radio.duckRadio(0.2, 3.5);

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(420, t);
    osc.frequency.linearRampToValueAtTime(760, t + 1.2);
    osc.frequency.linearRampToValueAtTime(440, t + 2.4);
    osc.frequency.linearRampToValueAtTime(720, t + 3.4);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(650, t);
    filter.Q.setValueAtTime(2.5, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.38, t + 0.3);
    gain.gain.setValueAtTime(0.35, t + 2.6);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 3.6);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 3.6);
  }

  playBombWhistle() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1600, t);
    osc.frequency.exponentialRampToValueAtTime(280, t + 0.85);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.05, t);
    gain.gain.linearRampToValueAtTime(0.36, t + 0.65);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.90);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.90);
  }

  playHydrofoilWhoosh() {
    if (!this.initialized || !this.ctx) return;
    const t = this.ctx.currentTime;

    const bufferSize = Math.floor(this.ctx.sampleRate * 0.45);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, t);
    filter.frequency.linearRampToValueAtTime(2600, t + 0.2);
    filter.frequency.linearRampToValueAtTime(900, t + 0.45);
    filter.Q.setValueAtTime(3.0, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(t);
  }

  toggleMute() {
    if (!this.masterGain) return false;
    this.muted = !this.muted;
    this.masterGain.gain.setValueAtTime(this.muted ? 0 : 0.72, this.ctx.currentTime);
    return this.muted;
  }
}

export const soundManager = new SoundManager();
if (typeof window !== 'undefined') {
  window.soundManager = soundManager;
}
