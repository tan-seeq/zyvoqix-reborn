// Boat Chase: Main Game Loop, Three.js Rendering, Camera Controllers, HUD & Input
import * as THREE from '../lib/three.module.js';
import { CONFIG } from './config.js';
import { WorldManager } from './world.js';
import { PlayerBoat } from './boat.js';
import { FactionManager } from './factions.js';
import { WeaponManager } from './weapons.js';
import { Radar } from './radar.js';
import { GameVideoRecorder } from './recorder.js';
import { DevHook } from '../dev_hook.js';
import { soundManager } from './audio.js';

class Game {
  constructor() {
    this.container = document.getElementById('game-container');
    this.clock = new THREE.Clock();

    // Camera modes: 'GTA_CHASE' (default) or 'TOP_DOWN'
    this.cameraMode = 'GTA_CHASE';
    this.cameraOffset = new THREE.Vector3();
    this.cameraTarget = new THREE.Vector3();
    this.cameraVelocityLag = new THREE.Vector3();
    this.trauma = 0;
    this.traumaTime = 0;

    // Input state
    this.input = {
      throttle: 0,
      steer: 0,
      boost: false,
      drift: false,
      grapple: false,
      fireMG: false,
      fireTorpedo: false,
      fireDepthCharge: false
    };

    this._initThree();
    this._initSystems();
    this._initInputs();
    this._initHUD();

    // Auto-start loop
    this.animate = this.animate.bind(this);
    requestAnimationFrame(this.animate);
  }

  addTrauma(amount) {
    this.trauma = Math.min(1.0, this.trauma + amount);
  }

  _initThree() {
    // 1. Scene & Atmosphere Fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(CONFIG.WATER_DEEP_COLOR);
    this.scene.fog = new THREE.Fog(CONFIG.FOG_COLOR, CONFIG.FOG_NEAR, CONFIG.FOG_FAR);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 1, 1200);
    this.camera.position.set(0, 115, -35);

    // 3. WebGL Renderer with High Precision & Shadow Maps
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // 4. Lighting: Golden Hour Twilight / Miami Vice Sun
    const hemiLight = new THREE.HemisphereLight(0x7ed6df, 0x130f40, 0.75);
    this.scene.add(hemiLight);
    this.hemiLight = hemiLight;

    const dirLight = new THREE.DirectionalLight(0xffbe76, 1.4);
    dirLight.position.set(120, 180, 100);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 450;
    const d = 160;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    this.scene.add(dirLight);
    this.sunLight = dirLight;

    this.currentAtmosphere = 'DAY';
    this.currentSunOffset = { x: 120, y: 180, z: 100 };

    // Window resize handler
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }

  _initSystems() {
    // World
    this.world = new WorldManager(this.scene);

    // Player
    this.player = new PlayerBoat(this.scene, this.world);
    this.player.position.set(0, 0, 0);

    // Weapons
    this.weaponManager = new WeaponManager(this.scene, this.world);

    // Factions
    this.factionManager = new FactionManager(this.scene, this.world, this.player, this.weaponManager);
    this.weaponManager.setReferences(this.player, this.factionManager);
    this.player.setFactionManager(this.factionManager);

    // Radar Minimap
    this.radar = new Radar('radar-canvas', this.world, this.player, this.factionManager);

    // Video Recorder
    this.recorder = new GameVideoRecorder(this.renderer.domElement);

    // Dev Tuner Hook
    this.devHook = new DevHook(this);
  }

  _initInputs() {
    const onKey = (e, isDown) => {
      // Initialize audio context on first player interaction
      soundManager.init();
      soundManager.resume();

      switch (e.code) {
        case 'KeyW':
        case 'ArrowUp':
          this.input.throttle = isDown ? 1 : (this.input.throttle === 1 ? 0 : this.input.throttle);
          break;
        case 'KeyS':
        case 'ArrowDown':
          this.input.throttle = isDown ? -1 : (this.input.throttle === -1 ? 0 : this.input.throttle);
          break;
        case 'KeyA':
        case 'ArrowLeft':
          this.input.steer = isDown ? 1 : (this.input.steer === 1 ? 0 : this.input.steer);
          break;
        case 'KeyD':
        case 'ArrowRight':
          this.input.steer = isDown ? -1 : (this.input.steer === -1 ? 0 : this.input.steer);
          break;
        case 'Space':
          this.input.boost = isDown;
          break;
        case 'ShiftLeft':
        case 'ShiftRight':
          this.input.drift = isDown;
          break;
        case 'KeyE':
          if (isDown) this.input.fireTorpedo = true;
          break;
        case 'KeyQ':
          if (isDown) this.input.fireDepthCharge = true;
          break;
        case 'KeyF':
          this.input.grapple = isDown;
          break;
        case 'KeyR':
          if (isDown) this.cycleRadioStation();
          break;
        case 'KeyN':
          if (isDown) {
            e.preventDefault();
            this.cycleAtmosphere();
          }
          break;
        case 'KeyC':
        case 'Tab':
          if (isDown) {
            e.preventDefault();
            this.toggleCameraMode();
          }
          break;
      }
    };

    window.addEventListener('keydown', (e) => onKey(e, true));
    window.addEventListener('keyup', (e) => {
      onKey(e, false);
      if (e.code === 'KeyE') this.input.fireTorpedo = false;
      if (e.code === 'KeyQ') this.input.fireDepthCharge = false;
      if (e.code === 'KeyF') this.input.grapple = false;
    });

    // Mouse Aim & Fire
    window.addEventListener('mousedown', (e) => {
      soundManager.init();
      soundManager.resume();
      if (e.button === 0) {
        this.input.fireMG = true;
      } else if (e.button === 2) {
        e.preventDefault();
        this.input.fireTorpedo = true;
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.input.fireMG = false;
      if (e.button === 2) this.input.fireTorpedo = false;
    });

    window.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  cycleRadioStation() {
    soundManager.init();
    soundManager.resume();
    const station = soundManager.radio.nextStation();
    let banner = document.getElementById('radio-banner');
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'radio-banner';
      banner.className = 'radio-banner';
      document.body.appendChild(banner);
    }
    banner.innerText = `📻 ${station.name} • ${station.genre}`;
    banner.classList.add('show');
    if (this.radioBannerTimer) clearTimeout(this.radioBannerTimer);
    this.radioBannerTimer = setTimeout(() => banner.classList.remove('show'), 2400);

    const radioBtn = document.getElementById('radio-btn');
    if (radioBtn) radioBtn.innerText = `📻 ${station.name.split(' ')[0]}`;
  }

  setAtmosphere(mode) {
    const preset = CONFIG.LIGHTING_PRESETS[mode] || CONFIG.LIGHTING_PRESETS.DAY;
    this.currentAtmosphere = mode;
    this.currentSunOffset = preset.sunOffset || { x: 120, y: 180, z: 100 };

    // 1. Scene background & Fog
    if (this.scene.background) this.scene.background.setHex(preset.waterDeepColor);
    if (this.scene.fog) {
      this.scene.fog.color.setHex(preset.fogColor);
      this.scene.fog.near = preset.fogNear;
      this.scene.fog.far = preset.fogFar;
    }

    // 2. Lights
    if (this.hemiLight) {
      this.hemiLight.color.setHex(preset.hemiSky);
      this.hemiLight.groundColor.setHex(preset.hemiGround);
      this.hemiLight.intensity = preset.hemiIntensity;
    }
    if (this.sunLight) {
      this.sunLight.color.setHex(preset.sunColor);
      this.sunLight.intensity = preset.sunIntensity;
    }

    // 3. World terrain, sky dome & water
    if (this.world && this.world.setTimeOfDay) {
      this.world.setTimeOfDay(mode);
    }

    // 4. Update HUD button & radio dispatch
    const lightBtn = document.getElementById('lighting-btn');
    if (lightBtn) {
      const icon = mode === 'SUNSET' ? '🌆' : (mode === 'CYBER_NIGHT' ? '🌃' : '☀️');
      lightBtn.innerText = `${icon} Light: ${preset.name} [N]`;
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = `🌆 [ATMOSPHERE SHIFT]: TIME OF DAY SET TO ${preset.name.toUpperCase()}!`;
      dispatch.style.color = mode === 'CYBER_NIGHT' ? '#38bdf8' : (mode === 'SUNSET' ? '#f59e0b' : '#10b981');
    }
  }

  cycleAtmosphere() {
    const modes = ['DAY', 'SUNSET', 'CYBER_NIGHT'];
    const nextIndex = (modes.indexOf(this.currentAtmosphere) + 1) % modes.length;
    this.setAtmosphere(modes[nextIndex]);
  }

  toggleCameraMode() {
    this.cameraMode = this.cameraMode === 'GTA_CHASE' ? 'TOP_DOWN' : 'GTA_CHASE';
    const camBtn = document.getElementById('cam-btn');
    if (camBtn) {
      camBtn.innerText = this.cameraMode === 'GTA_CHASE' ? '🎥 View: GTA Chase' : '🎥 View: Top-Down';
    }
  }

  _initHUD() {
    // Start game button
    const startBtn = document.getElementById('start-game-btn');
    const startModal = document.getElementById('start-modal');
    if (startBtn && startModal) {
      startBtn.addEventListener('click', () => {
        soundManager.init();
        soundManager.resume();
        startModal.style.display = 'none';
      });
    }

    // HUD button listeners
    const camBtn = document.getElementById('cam-btn');
    if (camBtn) {
      camBtn.innerText = '🎥 View: GTA Chase';
      camBtn.addEventListener('click', () => this.toggleCameraMode());
    }

    const radioBtn = document.getElementById('radio-btn');
    if (radioBtn) {
      radioBtn.addEventListener('click', () => this.cycleRadioStation());
    }

    const lightBtn = document.getElementById('lighting-btn');
    if (lightBtn) {
      lightBtn.addEventListener('click', () => this.cycleAtmosphere());
    }

    const harpoonBtn = document.getElementById('harpoon-btn');
    if (harpoonBtn) {
      const startGrapple = (e) => {
        e.preventDefault();
        soundManager.init();
        soundManager.resume();
        this.input.grapple = true;
      };
      const endGrapple = (e) => {
        e.preventDefault();
        this.input.grapple = false;
      };
      harpoonBtn.addEventListener('mousedown', startGrapple);
      window.addEventListener('mouseup', endGrapple);
      harpoonBtn.addEventListener('touchstart', startGrapple, { passive: false });
      window.addEventListener('touchend', endGrapple);
    }

    const audioBtn = document.getElementById('audio-btn');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        soundManager.init();
        const muted = soundManager.toggleMute();
        audioBtn.innerText = muted ? '🔇 Sound: Off' : '🔊 Sound: On';
      });
    }

    const restartBtn = document.getElementById('restart-btn');
    if (restartBtn) restartBtn.addEventListener('click', () => window.location.reload());

    this.lastHealth = CONFIG.PLAYER.MAX_HEALTH;
    this.lastStuntCount = 0;
    this.survivalSeconds = 0;
    this.maxWantedRecorded = 1;
  }

  updateCamera(dt) {
    if (!this.player) return;

    const pPos = this.player.position;
    const forwardX = Math.sin(this.player.rotation);
    const forwardZ = Math.cos(this.player.rotation);

    if (this.cameraMode === 'TOP_DOWN') {
      const cfg = CONFIG.CAMERA.TOP_DOWN;
      const targetCamX = pPos.x + forwardX * cfg.leadDistance;
      const targetCamZ = pPos.z + forwardZ * cfg.leadDistance - 45;
      const targetCamY = pPos.y + cfg.height;

      this.camera.position.lerp(new THREE.Vector3(targetCamX, targetCamY, targetCamZ), dt * 6);
      this.camera.lookAt(pPos.x + forwardX * 15, pPos.y, pPos.z + forwardZ * 15);
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, cfg.fov, dt * 5);
      this.camera.updateProjectionMatrix();
    } else {
      // Authentic GTA 3rd-person Chase Camera with acceleration lag & drift swing
      const cfg = CONFIG.CAMERA.GTA_CHASE;
      const targetDist = cfg.distance + (this.player.isBoosting ? 6 : 0);
      const targetHeight = cfg.height + (this.player.isBoosting ? 1.5 : 0);

      // Camera lag: camera drops back on acceleration
      this.cameraVelocityLag.lerp(this.player.velocity, dt * 4.5);
      const lagX = -this.cameraVelocityLag.x * 0.08;
      const lagZ = -this.cameraVelocityLag.z * 0.08;

      const targetCamX = pPos.x - forwardX * targetDist + lagX;
      const targetCamZ = pPos.z - forwardZ * targetDist + lagZ;
      const targetCamY = pPos.y + targetHeight;

      this.camera.position.lerp(new THREE.Vector3(targetCamX, targetCamY, targetCamZ), dt * cfg.damping);

      // Look ahead over the bow with velocity anticipation
      const lookTarget = new THREE.Vector3(
        pPos.x + forwardX * 36 + this.player.velocity.x * 0.18,
        pPos.y + 3.2,
        pPos.z + forwardZ * 36 + this.player.velocity.z * 0.18
      );
      this.camera.lookAt(lookTarget);

      // Power-curve dynamic FOV for genuine speed sensation
      const speedRatio = Math.min(1.0, Math.abs(this.player.speed) / CONFIG.PLAYER.MAX_SPEED);
      const targetFov = 62 + Math.pow(speedRatio, 1.5) * 18 + (this.player.isBoosting ? 8 : 0);
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, dt * 5.0);
      this.camera.updateProjectionMatrix();
    }

    // Trauma screen shake (squared for organic physical jolts)
    if (this.trauma > 0) {
      this.trauma = Math.max(0, this.trauma - 1.35 * dt);
      this.traumaTime += dt;
      const s = this.trauma * this.trauma;
      if (s > 0.001) {
        this.camera.position.x += Math.sin(this.traumaTime * 28) * 1.2 * s;
        this.camera.position.y += Math.cos(this.traumaTime * 32) * 1.2 * s;
        this.camera.rotation.z += Math.sin(this.traumaTime * 26) * 0.038 * s;
      }
    }

    // Move directional sunlight to track player
    const sOff = this.currentSunOffset || { x: 120, y: 180, z: 100 };
    this.sunLight.position.set(pPos.x + sOff.x, sOff.y, pPos.z + sOff.z);
    this.sunLight.target.position.copy(pPos);
    this.sunLight.target.updateMatrixWorld();
  }

  _updateHUD(dt) {
    if (!this.player) return;

    this.survivalSeconds += dt;
    this.maxWantedRecorded = Math.max(this.maxWantedRecorded, this.player.wantedLevel);

    // 1. Health Bar & Numeric Value (with Nanite Shield Support)
    const hpBar = document.getElementById('health-fill');
    const hpText = document.getElementById('health-text');
    const hpPct = Math.max(0, (this.player.health / this.player.maxHealth) * 100);
    const hasShield = this.player.naniteShieldTimer > 0;

    if (hpBar) {
      hpBar.style.width = `${hpPct}%`;
      if (hasShield) {
        hpBar.style.background = 'linear-gradient(90deg, #38bdf8, #00f2fe)';
      } else {
        hpBar.style.background = hpPct > 40 ? 'linear-gradient(90deg, #00c6ff, #0072ff)' : (hpPct > 20 ? 'linear-gradient(90deg, #f39c12, #e67e22)' : 'linear-gradient(90deg, #ff4757, #ff3838)');
      }
    }
    if (hpText) {
      if (hasShield) {
        hpText.innerText = `🛡️ ${this.player.naniteShieldTimer.toFixed(1)}s`;
        hpText.style.color = '#38bdf8';
      } else {
        hpText.innerText = `${Math.round(hpPct)}%`;
        hpText.style.color = hpPct > 40 ? '#00f2fe' : (hpPct > 20 ? '#f39c12' : '#ff3838');
      }
    }

    // Damage flash vignette
    if (this.player.health < this.lastHealth) {
      const dmgVignette = document.getElementById('damage-vignette');
      if (dmgVignette) {
        dmgVignette.classList.add('hit');
        setTimeout(() => dmgVignette.classList.remove('hit'), 180);
      }
    }
    this.lastHealth = this.player.health;

    // 2. Boost Bar & Vignette
    const boostBar = document.getElementById('boost-fill');
    const boostText = document.getElementById('boost-text');
    const boostPct = (this.player.boost / this.player.maxBoost) * 100;
    if (boostBar) boostBar.style.width = `${boostPct}%`;
    if (boostText) {
      boostText.innerText = this.player.boost > 5 ? (this.player.isBoosting ? 'BOOSTING!' : 'READY') : 'RECHARGING';
      boostText.style.color = this.player.isBoosting ? '#ff007f' : '#e056fd';
    }

    const boostVignette = document.getElementById('boost-vignette');
    if (boostVignette) {
      if (this.player.isBoosting) {
        boostVignette.classList.add('boosting');
      } else {
        boostVignette.classList.remove('boosting');
      }
    }

    // 3. Stunt Popup
    if (this.player.stuntsPerformed > this.lastStuntCount) {
      this.lastStuntCount = this.player.stuntsPerformed;
      const stuntPopup = document.getElementById('stunt-banner');
      if (stuntPopup) {
        stuntPopup.classList.add('show');
        setTimeout(() => stuntPopup.classList.remove('show'), 2000);
      }
    }

    // 4. Sunwake Speedometer
    const speedEl = document.getElementById('speed-display');
    const knots = Math.round(Math.abs(this.player.speed) * 1.2);
    if (speedEl) speedEl.innerText = knots;

    // 5. Score
    const scoreEl = document.getElementById('score-display');
    if (scoreEl) scoreEl.innerText = this.player.score;

    // 5b. Safe Haven Distance
    const havenEl = document.getElementById('haven-distance');
    if (havenEl && this.world && this.world.safeHaven) {
      const dist = Math.round(Math.hypot(this.player.position.x - this.world.safeHaven.x, this.player.position.z - this.world.safeHaven.z));
      havenEl.innerText = `Safe Haven ${dist}m`;
    }

    // 5c. Sunwake Nautical Compass Dial & Bearing
    const needleEl = document.getElementById('dial-needle');
    const bearingEl = document.getElementById('compass-bearing');
    if (this.player) {
      const rad = ((this.player.rotation % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const deg = Math.round(rad * (180 / Math.PI));
      const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
      const dirIndex = Math.round(deg / 45) % 8;
      const cardinal = dirs[dirIndex];
      if (needleEl) needleEl.style.transform = `rotate(${deg}deg)`;
      if (bearingEl) bearingEl.innerText = `${cardinal} ${deg}°`;
    }

    // 6. Wanted Stars
    const starContainer = document.getElementById('wanted-stars');
    if (starContainer) {
      const stars = starContainer.querySelectorAll('.star');
      stars.forEach((star, idx) => {
        if (idx < this.player.wantedLevel) {
          star.classList.add('active');
        } else {
          star.classList.remove('active');
        }
      });
    }

    // 7. Tactical Radio Scanner Dispatch
    const dispatchEl = document.getElementById('dispatch-msg');
    if (dispatchEl && this.factionManager) {
      const alertEnemies = this.factionManager.enemies.filter(e => e.alive && e.state === 'ALERTED');
      if (alertEnemies.length === 0) {
        dispatchEl.innerText = 'PATROLLING WATERS... RADIO SILENCE. STAY UNDETECTED.';
        dispatchEl.style.color = '#e2e8f0';
      } else {
        const police = alertEnemies.find(e => e.faction.id === 'police');
        const gangster = alertEnemies.find(e => e.faction.id === 'gangster');
        const pirate = alertEnemies.find(e => e.faction.id === 'pirates');

        if (police && gangster) {
          dispatchEl.innerText = '💥 [FACTION WAR]: CARTEL GUNBOATS ENGAGING COAST GUARD UNITS!';
          dispatchEl.style.color = '#ff9f43';
        } else if (police) {
          dispatchEl.innerText = '🚨 [COAST GUARD NET]: PATROL CUTTER HAS VISUAL! ALL UNITS CONVERGE!';
          dispatchEl.style.color = '#00a6ff';
        } else if (gangster) {
          dispatchEl.innerText = '⚠️ [CARTEL COMMS]: INTRUDER IN DOCK CANALS! OPEN FIRE AND RAM!';
          dispatchEl.style.color = '#ff2a4b';
        } else if (pirate) {
          dispatchEl.innerText = '☠️ [PIRATE SKULL-NET]: ENEMY VESSEL SPOTTED! PREPARE BROADSWORD CANNONS!';
          dispatchEl.style.color = '#ffb81c';
        }
      }
    }

    // 8. Weapon Cooldowns & Prototype Railgun Display on Dock
    const torpCd = document.getElementById('torpedo-cd');
    if (torpCd && this.weaponManager) {
      const maxCd = (this.player && this.player.railgunAmmo > 0) ? (CONFIG.WEAPONS.RAILGUN.fireRate || 1.8) : CONFIG.WEAPONS.TORPEDO.fireRate;
      const torpPct = Math.min(100, Math.max(0, (1.0 - this.weaponManager.torpedoCooldown / maxCd) * 100));
      torpCd.style.width = `${torpPct}%`;
    }

    const torpCard = document.getElementById('wep-torpedo');
    if (torpCard && this.player) {
      const nameEl = torpCard.querySelector('.wep-name');
      const ammoEl = torpCard.querySelector('.wep-ammo');
      const iconEl = torpCard.querySelector('.wep-icon');
      if (this.player.railgunAmmo > 0) {
        if (nameEl && nameEl.innerText !== 'RAILGUN') nameEl.innerText = 'RAILGUN';
        if (ammoEl) ammoEl.innerText = `${this.player.railgunAmmo} RDS`;
        if (iconEl && iconEl.innerText !== '⚡') iconEl.innerText = '⚡';
        torpCard.style.borderColor = '#00f2fe';
        torpCard.style.boxShadow = '0 0 14px rgba(0, 242, 254, 0.45)';
      } else {
        if (nameEl && nameEl.innerText !== 'TORPEDO') nameEl.innerText = 'TORPEDO';
        if (ammoEl && ammoEl.innerText !== 'HOMING') ammoEl.innerText = 'HOMING';
        if (iconEl && iconEl.innerText !== '🚀') iconEl.innerText = '🚀';
        torpCard.style.borderColor = '';
        torpCard.style.boxShadow = '';
      }
    }

    const depthCd = document.getElementById('depth-cd');
    if (depthCd && this.weaponManager) {
      const maxCd = (this.player && this.player.empAmmo > 0) ? (CONFIG.WEAPONS.EMP.fireRate || 2.5) : CONFIG.WEAPONS.DEPTH_CHARGE.fireRate;
      const dPct = Math.min(100, Math.max(0, (1.0 - this.weaponManager.depthChargeCooldown / maxCd) * 100));
      depthCd.style.width = `${dPct}%`;
    }

    const depthCard = document.getElementById('wep-depth');
    if (depthCard && this.player) {
      const nameEl = depthCard.querySelector('.wep-name');
      const ammoEl = depthCard.querySelector('.wep-ammo');
      const iconEl = depthCard.querySelector('.wep-icon');
      if (this.player.empAmmo > 0) {
        if (nameEl && nameEl.innerText !== 'EMP BLAST') nameEl.innerText = 'EMP BLAST';
        if (ammoEl) ammoEl.innerText = `${this.player.empAmmo} CHARGES`;
        if (iconEl && iconEl.innerText !== '⚡') iconEl.innerText = '⚡';
        depthCard.style.borderColor = '#a855f7';
        depthCard.style.boxShadow = '0 0 14px rgba(168, 85, 247, 0.45)';
      } else {
        if (nameEl && nameEl.innerText !== 'MINE CHARGE') nameEl.innerText = 'MINE CHARGE';
        if (ammoEl && ammoEl.innerText !== 'PROXIMITY') ammoEl.innerText = 'PROXIMITY';
        if (iconEl && iconEl.innerText !== '💣') iconEl.innerText = '💣';
        depthCard.style.borderColor = '';
        depthCard.style.boxShadow = '';
      }
    }

    // 9. Safe Haven Distance & Escape Check
    const sh = this.world.safeHaven;
    const dx = this.player.position.x - sh.x;
    const dz = this.player.position.z - sh.z;
    const distToHaven = Math.sqrt(dx * dx + dz * dz);

    const distEl = document.getElementById('haven-distance');
    if (distEl) distEl.innerText = `${Math.round(distToHaven)}m`;

    // Escape victory trigger
    if (distToHaven < sh.radius && this.player.alive) {
      this.triggerGameOver(true);
    }

    // Death trigger
    if (!this.player.alive) {
      this.triggerGameOver(false);
    }
  }

  triggerGameOver(victory) {
    if (this.isGameOver) return;
    this.isGameOver = true;

    const modal = document.getElementById('end-game-modal');
    if (modal) {
      const title = document.getElementById('end-title');
      const icon = document.getElementById('end-status-icon');
      const scoreSub = document.getElementById('end-score-sub');
      const statTime = document.getElementById('stat-time');
      const statStunts = document.getElementById('stat-stunts');
      const statWanted = document.getElementById('stat-wanted');

      if (title) {
        title.innerText = victory ? '🏆 ESCAPED TO SAFE HAVEN!' : '💥 VESSEL DESTROYED';
        title.style.color = victory ? '#00ff88' : '#ff3838';
      }
      if (icon) icon.innerText = victory ? '🏆' : '💥';
      if (scoreSub) scoreSub.innerText = `Final Score: ${this.player.score}`;
      if (statTime) statTime.innerText = `${Math.round(this.survivalSeconds)}s`;
      if (statStunts) statStunts.innerText = this.player.stuntsPerformed;
      if (statWanted) statWanted.innerText = `${this.maxWantedRecorded} ★`;

      modal.style.display = 'flex';
    }

    this.recorder.triggerEndGameReplay(victory, this.player.score, this.player.stuntsPerformed);
  }

  animate() {
    requestAnimationFrame(this.animate);
    const baseDt = Math.min(this.clock.getDelta(), 0.1);
    // Hollywood slow-motion stunt jump effect!
    const timeScale = (this.player && this.player.isAirborne) ? 0.45 : 1.0;
    const dt = baseDt * timeScale;

    // Update modules
    this.world.update(dt, this.player, this.weaponManager);
    this.player.update(dt, this.input);
    this.factionManager.update(dt);
    this.weaponManager.update(dt, this.input);
    this.radar.update(dt);
    this.updateCamera(baseDt);
    this._updateHUD(dt);

    // Render WebGL
    this.renderer.render(this.scene, this.camera);
  }
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', () => {
      window.game = new Game();
    });
  } else {
    window.game = new Game();
  }
}
