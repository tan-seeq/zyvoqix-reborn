// Boat Chase: Weapons, Projectiles, Guided Torpedoes, Depth Charges & Particle Explosions
import * as THREE from '../lib/three.module.js';
import { CONFIG } from './config.js';
import { soundManager } from './audio.js';

export class WeaponManager {
  constructor(scene, world) {
    this.scene = scene;
    this.world = world;
    this.projectiles = [];
    this.explosions = [];
    this.particles = [];
    this.factionManager = null; // attached after creation
    this.player = null;

    // Cooldown timers for player
    this.mgCooldown = 0;
    this.torpedoCooldown = 0;
    this.depthChargeCooldown = 0;

    // Reusable projectile geometries
    this.mgGeo = new THREE.CylinderGeometry(0.25, 0.25, 2.4, 6);
    this.mgGeo.rotateX(Math.PI / 2);
    this.mgMat = new THREE.MeshBasicMaterial({ color: 0xffea00 });

    this.cannonGeo = new THREE.SphereGeometry(1.2, 8, 8);
    this.cannonMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.9 });

    this.torpedoGeo = new THREE.CylinderGeometry(0.5, 0.6, 4.0, 8);
    this.torpedoGeo.rotateX(Math.PI / 2);
    this.torpedoMat = new THREE.MeshStandardMaterial({ color: 0x00f2fe, metalness: 0.8 });

    this.mineGeo = new THREE.SphereGeometry(1.4, 8, 8);
    this.mineMat = new THREE.MeshStandardMaterial({ color: 0xff3838, roughness: 0.3 });

    this.railgunGeo = new THREE.CylinderGeometry(0.35, 0.45, 5.2, 8);
    this.railgunGeo.rotateX(Math.PI / 2);
    this.railgunMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });

    this.empGeo = new THREE.CylinderGeometry(0.7, 0.7, 2.2, 8);
    this.empGeo.rotateX(Math.PI / 2);
    this.empMat = new THREE.MeshStandardMaterial({ color: 0xa855f7, metalness: 0.9, roughness: 0.2 });
  }

  setReferences(player, factionManager) {
    this.player = player;
    this.factionManager = factionManager;
  }

  update(dt, input) {
    // Cooldowns
    if (this.mgCooldown > 0) this.mgCooldown -= dt;
    if (this.torpedoCooldown > 0) this.torpedoCooldown -= dt;
    if (this.depthChargeCooldown > 0) this.depthChargeCooldown -= dt;

    // Player inputs
    if (this.player && this.player.alive && !this.player.isAirborne) {
      if (input.fireMG && this.mgCooldown <= 0) {
        this.firePlayerMG();
      }
      if (input.fireTorpedo && this.torpedoCooldown <= 0) {
        if (this.player.railgunAmmo && this.player.railgunAmmo > 0) {
          this.firePlayerRailgun();
        } else {
          this.firePlayerTorpedo();
        }
      }
      if (input.fireDepthCharge && this.depthChargeCooldown <= 0) {
        if (this.player.empAmmo && this.player.empAmmo > 0) {
          this.firePlayerEMP();
        } else {
          this.firePlayerDepthCharge();
        }
      }
    }

    // Update projectiles
    this._updateProjectiles(dt);

    // Update explosions & particles
    this._updateParticles(dt);

    // Check world explosive barrels
    this._checkBarrels();
  }

  firePlayerMG() {
    this.mgCooldown = CONFIG.WEAPONS.MG.fireRate;
    const forwardX = Math.sin(this.player.rotation);
    const forwardZ = Math.cos(this.player.rotation);
    const sideX = Math.cos(this.player.rotation);
    const sideZ = -Math.sin(this.player.rotation);

    // Alternate left/right gun
    const side = Math.random() > 0.5 ? 1.4 : -1.4;
    const spawnX = this.player.position.x + forwardX * 6.5 + sideX * side;
    const spawnZ = this.player.position.z + forwardZ * 6.5 + sideZ * side;

    // Slight spread
    const spreadAngle = (Math.random() - 0.5) * CONFIG.WEAPONS.MG.spread;
    const rot = this.player.rotation + spreadAngle;
    const dirX = Math.sin(rot);
    const dirZ = Math.cos(rot);

    this.spawnProjectile(spawnX, 1.6, spawnZ, dirX, dirZ, CONFIG.WEAPONS.MG.damage, 'mg', this.player);
    soundManager.playGunfire(1.15);
  }

  firePlayerTorpedo() {
    this.torpedoCooldown = CONFIG.WEAPONS.TORPEDO.fireRate;
    const forwardX = Math.sin(this.player.rotation);
    const forwardZ = Math.cos(this.player.rotation);

    const spawnX = this.player.position.x + forwardX * 7.5;
    const spawnZ = this.player.position.z + forwardZ * 7.5;

    // Find nearest hostile enemy boat to lock on!
    let bestEnemy = null;
    let closestDist = 380;
    if (this.factionManager) {
      for (const enemy of this.factionManager.enemies) {
        if (enemy.alive) {
          const dx = enemy.position.x - spawnX;
          const dz = enemy.position.z - spawnZ;
          const d = Math.sqrt(dx * dx + dz * dz);
          if (d < closestDist) {
            closestDist = d;
            bestEnemy = enemy;
          }
        }
      }
    }

    const p = this.spawnProjectile(spawnX, 0.8, spawnZ, forwardX, forwardZ, CONFIG.WEAPONS.TORPEDO.damage, 'torpedo', this.player);
    p.homingTarget = bestEnemy;
    soundManager.playRocketLaunch();
  }

  firePlayerDepthCharge() {
    this.depthChargeCooldown = CONFIG.WEAPONS.DEPTH_CHARGE.fireRate;
    const backX = -Math.sin(this.player.rotation);
    const backZ = -Math.cos(this.player.rotation);

    const spawnX = this.player.position.x + backX * 6.5;
    const spawnZ = this.player.position.z + backZ * 6.5;

    const p = this.spawnProjectile(spawnX, 0.5, spawnZ, backX * 0.2, backZ * 0.2, CONFIG.WEAPONS.DEPTH_CHARGE.damage, 'depth_charge', this.player);
    p.fuse = CONFIG.WEAPONS.DEPTH_CHARGE.fuseTime;
    soundManager.playSplash();
  }

  firePlayerEMP() {
    this.depthChargeCooldown = CONFIG.WEAPONS.EMP.fireRate || 2.5;
    this.player.empAmmo = Math.max(0, this.player.empAmmo - 1);
    const backX = -Math.sin(this.player.rotation);
    const backZ = -Math.cos(this.player.rotation);

    const spawnX = this.player.position.x + backX * 6.5;
    const spawnZ = this.player.position.z + backZ * 6.5;

    const p = this.spawnProjectile(
      spawnX, 0.6, spawnZ,
      backX * 0.15, backZ * 0.15,
      40,
      'emp_charge',
      this.player
    );
    p.fuse = 1.8;
    soundManager.playSplash();
  }

  firePlayerRailgun() {
    this.torpedoCooldown = CONFIG.WEAPONS.RAILGUN.fireRate || 1.8;
    this.player.railgunAmmo = Math.max(0, this.player.railgunAmmo - 1);
    const forwardX = Math.sin(this.player.rotation);
    const forwardZ = Math.cos(this.player.rotation);

    const spawnX = this.player.position.x + forwardX * 7.5;
    const spawnZ = this.player.position.z + forwardZ * 7.5;

    const p = this.spawnProjectile(
      spawnX, 1.4, spawnZ,
      forwardX, forwardZ,
      CONFIG.WEAPONS.RAILGUN.damage || 160,
      'railgun',
      this.player
    );
    p.penetrationsLeft = CONFIG.WEAPONS.RAILGUN.penetrationCount || 4;
    p.pierced = new Set();
    p.kills = 0;

    // Supersonic recoil impulse & screen trauma
    this.player.speed = Math.max(-15, this.player.speed - 6.5);
    this.player.trauma = Math.min(1.0, (this.player.trauma || 0) + 0.45);
    if (window.game && window.game.addTrauma) {
      window.game.addTrauma(0.45);
    }

    soundManager.playRailgunFire();
  }

  spawnProjectile(x, y, z, dirX, dirZ, damage, type, owner) {
    let mesh;
    let speed = CONFIG.WEAPONS.MG.speed;

    if (type === 'mg' || type === 'bullet') {
      mesh = new THREE.Mesh(this.mgGeo, this.mgMat);
      speed = CONFIG.WEAPONS.MG.speed;
    } else if (type === 'cannon') {
      mesh = new THREE.Mesh(this.cannonGeo, this.cannonMat);
      speed = 100;
    } else if (type === 'torpedo') {
      mesh = new THREE.Mesh(this.torpedoGeo, this.torpedoMat);
      speed = CONFIG.WEAPONS.TORPEDO.speed;
    } else if (type === 'depth_charge') {
      mesh = new THREE.Mesh(this.mineGeo, this.mineMat);
      speed = 12;
    } else if (type === 'railgun') {
      mesh = new THREE.Mesh(this.railgunGeo, this.railgunMat);
      const boltLight = new THREE.PointLight(0x00f2fe, 3.2, 28);
      mesh.add(boltLight);
      speed = CONFIG.WEAPONS.RAILGUN.speed || 340;
    } else if (type === 'emp_charge') {
      mesh = new THREE.Mesh(this.empGeo, this.empMat);
      const violetLight = new THREE.PointLight(0xa855f7, 3.5, 25);
      mesh.add(violetLight);
      speed = 10;
    }

    mesh.position.set(x, y, z);
    mesh.rotation.y = Math.atan2(dirX, dirZ);
    this.scene.add(mesh);

    const proj = {
      mesh,
      position: mesh.position,
      velocity: new THREE.Vector3(dirX * speed, 0, dirZ * speed),
      damage,
      type,
      owner,
      life: 0,
      maxLife: type === 'railgun' ? 1.5 : (type === 'emp_charge' ? 2.5 : (type === 'torpedo' ? 4.5 : (type === 'depth_charge' ? 3.0 : 1.8))),
      homingTarget: null,
      penetrationsLeft: type === 'railgun' ? (CONFIG.WEAPONS.RAILGUN.penetrationCount || 4) : 1,
      pierced: type === 'railgun' ? new Set() : null,
      kills: 0
    };

    this.projectiles.push(proj);
    return proj;
  }

  _updateProjectiles(dt) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life += dt;

      // Guided torpedo homing steering
      if (p.type === 'torpedo' && p.homingTarget && p.homingTarget.alive) {
        const dx = p.homingTarget.position.x - p.position.x;
        const dz = p.homingTarget.position.z - p.position.z;
        const targetAngle = Math.atan2(dx, dz);
        let curAngle = Math.atan2(p.velocity.x, p.velocity.z);

        let diff = targetAngle - curAngle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;

        curAngle += Math.sign(diff) * Math.min(Math.abs(diff), CONFIG.WEAPONS.TORPEDO.turnRate * dt);
        const speed = CONFIG.WEAPONS.TORPEDO.speed;
        p.velocity.x = Math.sin(curAngle) * speed;
        p.velocity.z = Math.cos(curAngle) * speed;
        p.mesh.rotation.y = curAngle;
      }

      // Depth charge and EMP charge drag
      if (p.type === 'depth_charge' || p.type === 'emp_charge') {
        p.velocity.multiplyScalar(0.92);
      }

      // Step position
      p.position.x += p.velocity.x * dt;
      p.position.z += p.velocity.z * dt;

      // Check collision with breachable sea gate
      if (this.world && this.world.seaGate && this.world.seaGate.alive) {
        const sg = this.world.seaGate;
        if (!p.pierced || !p.pierced.has(sg)) {
          const dx = sg.x - p.position.x;
          const dz = sg.z - p.position.z;
          if (dx * dx + dz * dz < (sg.radius + 2) * (sg.radius + 2)) {
            this.world.damageSeaGate(p.damage, p.owner);
            if (p.type === 'railgun') {
              if (p.pierced) p.pierced.add(sg);
              p.penetrationsLeft--;
              this.spawnRailgunPierceFX(p.position.x, p.position.z);
              if (p.penetrationsLeft <= 0) {
                this._detonateProjectile(p);
                this.projectiles.splice(i, 1);
                continue;
              }
            } else {
              this._detonateProjectile(p);
              this.projectiles.splice(i, 1);
              continue;
            }
          }
        }
      }

      // Check collision with islands / world barriers
      const hitObstacle = this.world.checkCollision(p.position.x, p.position.z, 1.2);
      if (hitObstacle) {
        if (p.type === 'railgun') {
          if (!p.pierced || !p.pierced.has(hitObstacle)) {
            if (p.pierced) p.pierced.add(hitObstacle);
            p.penetrationsLeft--;
            this.spawnRailgunPierceFX(p.position.x, p.position.z);
            p.velocity.multiplyScalar(0.9);
            if (p.penetrationsLeft <= 0) {
              this._detonateProjectile(p);
              this.projectiles.splice(i, 1);
              continue;
            }
          }
        } else {
          this._detonateProjectile(p);
          this.projectiles.splice(i, 1);
          continue;
        }
      }

      // Check collision with naval contact mines
      let hitMine = false;
      if (this.world && this.world.mines) {
        for (const mine of this.world.mines) {
          if (mine.alive) {
            if (p.pierced && p.pierced.has(mine)) continue;
            const mdx = mine.x - p.position.x;
            const mdz = mine.z - p.position.z;
            if (mdx * mdx + mdz * mdz < (mine.radius + 1.4) * (mine.radius + 1.4)) {
              if (p.type === 'railgun') {
                if (p.pierced) p.pierced.add(mine);
                this.world.detonateMine(mine, p.owner);
                p.penetrationsLeft--;
                this.spawnRailgunPierceFX(p.position.x, p.position.z);
                if (p.penetrationsLeft <= 0) {
                  this._detonateProjectile(p);
                  this.projectiles.splice(i, 1);
                  hitMine = true;
                  break;
                }
              } else {
                this.world.detonateMine(mine, p.owner);
                this._detonateProjectile(p);
                this.projectiles.splice(i, 1);
                hitMine = true;
                break;
              }
            }
          }
        }
      }
      if (hitMine) continue;

      // Check collision with oil rig chemical fuel storage tanks
      let hitTank = false;
      if (this.world && this.world.oilRig && this.world.oilRig.tanks) {
        for (const tank of this.world.oilRig.tanks) {
          if (tank.alive) {
            if (p.pierced && p.pierced.has(tank)) continue;
            const tdx = tank.x - p.position.x;
            const tdz = tank.z - p.position.z;
            if (tdx * tdx + tdz * tdz < (tank.radius + 1.4) * (tank.radius + 1.4)) {
              if (p.type === 'railgun') {
                if (p.pierced) p.pierced.add(tank);
                this.world.damageFuelTank(tank, p.damage, p.owner);
                p.penetrationsLeft--;
                this.spawnRailgunPierceFX(p.position.x, p.position.z);
                if (p.penetrationsLeft <= 0) {
                  this._detonateProjectile(p);
                  this.projectiles.splice(i, 1);
                  hitTank = true;
                  break;
                }
              } else {
                this.world.damageFuelTank(tank, p.damage, p.owner);
                this._detonateProjectile(p);
                this.projectiles.splice(i, 1);
                hitTank = true;
                break;
              }
            }
          }
        }
      }
      if (hitTank) continue;

      // Check collision with seaplane hangar aviation fuel drums
      let hitAvDrum = false;
      if (this.world && this.world.seaplaneHangar && this.world.seaplaneHangar.fuelDrums) {
        for (const drum of this.world.seaplaneHangar.fuelDrums) {
          if (drum.alive) {
            if (p.pierced && p.pierced.has(drum)) continue;
            const ddx = drum.x - p.position.x;
            const ddz = drum.z - p.position.z;
            if (ddx * ddx + ddz * ddz < (drum.radius + 1.4) * (drum.radius + 1.4)) {
              if (p.type === 'railgun') {
                if (p.pierced) p.pierced.add(drum);
                this.world.detonateAvGasDrum(drum, p.owner);
                p.penetrationsLeft--;
                this.spawnRailgunPierceFX(p.position.x, p.position.z);
                if (p.penetrationsLeft <= 0) {
                  this._detonateProjectile(p);
                  this.projectiles.splice(i, 1);
                  hitAvDrum = true;
                  break;
                }
              } else {
                this.world.detonateAvGasDrum(drum, p.owner);
                this._detonateProjectile(p);
                this.projectiles.splice(i, 1);
                hitAvDrum = true;
                break;
              }
            }
          }
        }
      }
      if (hitAvDrum) continue;

      // Check collision with boats (Player and Enemies)
      let hitBoat = false;

      // Check player
      if (p.owner !== this.player && this.player && this.player.alive) {
        const dx = this.player.position.x - p.position.x;
        const dz = this.player.position.z - p.position.z;
        if (dx * dx + dz * dz < this.player.radius * this.player.radius) {
          this.player.takeDamage(p.damage);
          this._detonateProjectile(p);
          this.projectiles.splice(i, 1);
          continue;
        }
      }

      // Check aerial craft (Police Helicopter & Naval Zeppelin Boss)
      if (p.owner === this.player && this.factionManager) {
        if (this.factionManager.helicopter && this.factionManager.helicopter.alive) {
          const heli = this.factionManager.helicopter;
          const hdx = heli.position.x - p.position.x;
          const hdz = heli.position.z - p.position.z;
          if (hdx * hdx + hdz * hdz < 14 * 14) {
            heli.takeDamage(p.damage);
            this._detonateProjectile(p);
            this.projectiles.splice(i, 1);
            continue;
          }
        }
        if (this.factionManager.zeppelin && this.factionManager.zeppelin.alive) {
          const zep = this.factionManager.zeppelin;
          const zdx = zep.position.x - p.position.x;
          const zdz = zep.position.z - p.position.z;
          if (zdx * zdx + zdz * zdz < 28 * 28) {
            zep.takeDamage(p.damage);
            this._detonateProjectile(p);
            this.projectiles.splice(i, 1);
            continue;
          }
        }
      }

      // Check enemies
      if (this.factionManager) {
        for (const enemy of this.factionManager.enemies) {
          if (enemy.alive && enemy !== p.owner) {
            if (p.pierced && p.pierced.has(enemy)) continue;
            const dx = enemy.position.x - p.position.x;
            const dz = enemy.position.z - p.position.z;
            if (dx * dx + dz * dz < enemy.radius * enemy.radius) {
              const prevHealth = enemy.health;
              enemy.takeDamage(p.damage, p.owner);
              if (p.type === 'railgun') {
                if (p.pierced) p.pierced.add(enemy);
                p.penetrationsLeft--;
                this.spawnRailgunPierceFX(p.position.x, p.position.z);
                if (prevHealth > 0 && enemy.health <= 0) {
                  p.kills = (p.kills || 0) + 1;
                  if (p.kills >= 2 && this.player && this.player.triggerStunt) {
                    this.player.triggerStunt(`⚡ RAILGUN PENETRATOR MULTI-KILL (${p.kills}X)!`, 800 * p.kills, 5.0);
                  }
                }
                if (p.penetrationsLeft <= 0) {
                  this._detonateProjectile(p);
                  this.projectiles.splice(i, 1);
                  hitBoat = true;
                  break;
                }
              } else {
                this._detonateProjectile(p);
                this.projectiles.splice(i, 1);
                hitBoat = true;
                break;
              }
            }
          }
        }
      }

      if (hitBoat) continue;

      // Expiration
      if (p.life >= p.maxLife) {
        if (p.type === 'depth_charge' || p.type === 'torpedo' || p.type === 'railgun' || p.type === 'emp_charge') {
          this._detonateProjectile(p);
        } else {
          this.scene.remove(p.mesh);
        }
        this.projectiles.splice(i, 1);
      }
    }
  }

  _detonateProjectile(p) {
    this.scene.remove(p.mesh);

    if (p.type === 'mg') {
      this.spawnWaterSplash(p.position.x, p.position.z);
      return;
    }

    if (p.type === 'railgun') {
      this.createRailgunDetonation(p.position.x, p.position.z, p.owner);
      return;
    }

    if (p.type === 'emp_charge') {
      this.detonateEMP(p.position.x, p.position.z, p.owner);
      return;
    }

    // Explosion
    const radius = p.type === 'depth_charge' ? CONFIG.WEAPONS.DEPTH_CHARGE.blastRadius : 32;
    const damage = p.damage;
    this.createExplosion(p.position.x, p.position.z, radius, damage, p.owner);
  }

  spawnRailgunPierceFX(x, z) {
    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(x, 2.5, z, 14, 0x00f2fe);
      this.world.spawnVoxelCrumbles(x, 2.5, z, 10, 0xffffff);
    }
  }

  createRailgunDetonation(x, z, sourceOwner) {
    soundManager.playExplosion(0.85, 0.7);

    // Cyan plasma detonation sphere
    const blastGeo = new THREE.SphereGeometry(18, 12, 12);
    const blastMat = new THREE.MeshBasicMaterial({
      color: 0x00f2fe,
      transparent: true,
      opacity: 0.95
    });
    const blastMesh = new THREE.Mesh(blastGeo, blastMat);
    blastMesh.position.set(x, 2.5, z);
    this.scene.add(blastMesh);

    this.explosions.push({
      mesh: blastMesh,
      radius: 28,
      life: 0,
      maxLife: 0.4,
      startScale: 0.2,
      targetScale: 1.0
    });

    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(x, 2.5, z, 26, 0x00f2fe);
      this.world.spawnVoxelCrumbles(x, 2.5, z, 18, 0xffffff);
    }

    // AOE plasma shockwave damage
    if (this.factionManager) {
      for (const enemy of this.factionManager.enemies) {
        if (enemy.alive && enemy !== sourceOwner) {
          const d = Math.hypot(enemy.position.x - x, enemy.position.z - z);
          if (d < 28) {
            enemy.takeDamage(120 * (1.0 - d / 28), sourceOwner);
          }
        }
      }
    }
  }

  detonateEMP(x, z, sourceOwner) {
    soundManager.playEMPBlast();

    if (window.game && window.game.addTrauma) {
      window.game.addTrauma(0.65);
    }

    // Expanding violet shockwave sphere
    const blastGeo = new THREE.SphereGeometry(24, 16, 16);
    const blastMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      transparent: true,
      opacity: 0.95
    });
    const blastMesh = new THREE.Mesh(blastGeo, blastMat);
    blastMesh.position.set(x, 2.5, z);
    this.scene.add(blastMesh);

    this.explosions.push({
      mesh: blastMesh,
      radius: CONFIG.WEAPONS.EMP.blastRadius || 65,
      life: 0,
      maxLife: 0.65,
      startScale: 0.15,
      targetScale: 1.0
    });

    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(x, 2.5, z, 32, 0xa855f7);
      this.world.spawnVoxelCrumbles(x, 2.5, z, 24, 0xc084fc);
      this.world.spawnVoxelCrumbles(x, 2.5, z, 20, 0x00f2fe);
    }

    const blastRadius = CONFIG.WEAPONS.EMP.blastRadius || 65;
    const disableDuration = CONFIG.WEAPONS.EMP.disableDuration || 7.0;
    let disabledCount = 0;

    // Disable all hostile enemy vessels in blast radius
    if (this.factionManager) {
      for (const enemy of this.factionManager.enemies) {
        if (enemy.alive && enemy !== sourceOwner) {
          const d = Math.hypot(enemy.position.x - x, enemy.position.z - z);
          if (d < blastRadius) {
            enemy.empDisabledTimer = disableDuration;
            enemy.speed = 0;
            if (enemy.velocity) enemy.velocity.set(0, 0, 0);
            disabledCount++;
            if (this.world && this.world.spawnVoxelCrumbles) {
              this.world.spawnVoxelCrumbles(enemy.position.x, 3.0, enemy.position.z, 16, 0xa855f7);
            }
          }
        }
      }

      // Check police helicopter
      if (this.factionManager.helicopter && this.factionManager.helicopter.alive) {
        const heli = this.factionManager.helicopter;
        const hd = Math.hypot(heli.mesh.position.x - x, heli.mesh.position.z - z);
        if (hd < blastRadius + 20) {
          heli.empDisabledTimer = disableDuration;
          disabledCount++;
        }
      }

      // Check Naval Zeppelin Gunship Boss
      if (this.factionManager.zeppelin && this.factionManager.zeppelin.alive) {
        const zep = this.factionManager.zeppelin;
        const zd = Math.hypot(zep.position.x - x, zep.position.z - z);
        if (zd < blastRadius + 35) {
          zep.empDisabledTimer = disableDuration;
          disabledCount++;
        }
      }
    }

    if (this.player && this.player.triggerStunt && disabledCount > 0) {
      this.player.triggerStunt(`⚡ EMP SHOCKWAVE DISCHARGE! (${disabledCount} PURSUERS DISABLED!)`, 1200 + disabledCount * 300, 5.0);
    } else if (this.player && this.player.triggerStunt) {
      this.player.triggerStunt('⚡ EMP SHOCKWAVE DISCHARGE!', 800, 4.0);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = `🚨 [TACTICAL EMP]: Electromagnetic blast detonated! ${disabledCount} pursuers immobilized!`;
      dispatch.style.color = '#c084fc';
    }
  }

  createExplosion(x, z, radius, maxDamage, sourceOwner) {
    soundManager.playExplosion(0.7, 0.8);

    // Glowing explosion fireball
    const blastGeo = new THREE.SphereGeometry(radius * 0.7, 12, 12);
    const blastMat = new THREE.MeshBasicMaterial({
      color: 0xff7700,
      transparent: true,
      opacity: 0.95
    });
    const blastMesh = new THREE.Mesh(blastGeo, blastMat);
    blastMesh.position.set(x, 2.5, z);
    this.scene.add(blastMesh);

    this.explosions.push({
      mesh: blastMesh,
      radius,
      life: 0,
      maxLife: 0.45,
      startScale: 0.2,
      targetScale: 1.0
    });

    // Area-of-effect damage to boats
    if (this.player && this.player.alive) {
      const dx = this.player.position.x - x;
      const dz = this.player.position.z - z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < radius) {
        const falloff = 1.0 - dist / radius;
        this.player.takeDamage(maxDamage * falloff);
      }
    }

    if (this.factionManager) {
      for (const enemy of this.factionManager.enemies) {
        if (enemy.alive) {
          const dx = enemy.position.x - x;
          const dz = enemy.position.z - z;
          const dist = Math.sqrt(dx * dx + dz * dz);
          if (dist < radius) {
            const falloff = 1.0 - dist / radius;
            enemy.takeDamage(maxDamage * falloff, sourceOwner);
          }
        }
      }
    }

    // Explode nearby fuel barrels
    for (const b of this.world.barrels) {
      if (b.alive) {
        const dx = b.x - x;
        const dz = b.z - z;
        if (dx * dx + dz * dz < (radius + 8) * (radius + 8)) {
          b.alive = false;
          this.scene.remove(b.mesh);
          setTimeout(() => {
            this.createExplosion(b.x, b.z, CONFIG.BARREL_EXPLOSION_RADIUS, CONFIG.BARREL_EXPLOSION_DAMAGE, sourceOwner);
          }, 80);
        }
      }
    }

    // Explode nearby destructibles and spawn voxel crumbles
    if (this.world && this.world.destructibles) {
      for (const d of this.world.destructibles) {
        if (d.alive) {
          const dx = d.x - x;
          const dz = d.z - z;
          if (dx * dx + dz * dz < (radius + 12) * (radius + 12)) {
            d.alive = false;
            this.scene.remove(d.mesh);
            this.world.spawnVoxelCrumbles(d.x, 2.5, d.z, d.isExplosive ? 24 : 16, d.color);
            if (this.player && sourceOwner === this.player) {
              this.player.triggerStunt(`BLAST: ${d.name}!`, d.score);
            }
          }
        }
      }
    }

    // Screen trauma shake based on proximity
    if (window.game && window.game.addTrauma && this.player) {
      const pDist = Math.sqrt((this.player.position.x - x) ** 2 + (this.player.position.z - z) ** 2);
      if (pDist < 140) {
        window.game.addTrauma((1 - pDist / 140) * 0.45);
      }
    }

    // Explode / damage breachable sea gate
    if (this.world && this.world.seaGate && this.world.seaGate.alive) {
      const sg = this.world.seaGate;
      const dx = sg.x - x;
      const dz = sg.z - z;
      if (dx * dx + dz * dz < (radius + sg.radius) * (radius + sg.radius)) {
        this.world.damageSeaGate(maxDamage, sourceOwner);
      }
    }

    // Explode nearby sea mines
    for (const m of this.world.mines) {
      if (m.alive) {
        const dx = m.x - x;
        const dz = m.z - z;
        if (dx * dx + dz * dz < (radius + 8) * (radius + 8)) {
          m.alive = false;
          this.scene.remove(m.mesh);
          setTimeout(() => {
            this.createExplosion(m.x, m.z, 36, 120, sourceOwner);
          }, 60);
        }
      }
    }
  }

  _checkBarrels() {
    // Check boat collisions with sea mines
    for (const m of this.world.mines) {
      if (m.alive) {
        if (this.player && this.player.alive) {
          const dx = this.player.position.x - m.x;
          const dz = this.player.position.z - m.z;
          if (dx * dx + dz * dz < (this.player.radius + m.radius) * (this.player.radius + m.radius)) {
            m.alive = false;
            this.scene.remove(m.mesh);
            this.createExplosion(m.x, m.z, 38, 120, null);
            continue;
          }
        }

        if (this.factionManager) {
          for (const enemy of this.factionManager.enemies) {
            if (enemy.alive) {
              const dx = enemy.position.x - m.x;
              const dz = enemy.position.z - m.z;
              if (dx * dx + dz * dz < (enemy.radius + m.radius) * (enemy.radius + m.radius)) {
                m.alive = false;
                this.scene.remove(m.mesh);
                this.createExplosion(m.x, m.z, 38, 120, null);
                break;
              }
            }
          }
        }
      }
    }
  }

  spawnWaterSplash(x, z) {
    const splashGeo = new THREE.RingGeometry(0.8, 2.2, 12);
    splashGeo.rotateX(-Math.PI / 2);
    const splashMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 });
    const mesh = new THREE.Mesh(splashGeo, splashMat);
    mesh.position.set(x, 0.25, z);
    this.scene.add(mesh);

    this.particles.push({
      mesh,
      life: 0,
      maxLife: 0.35,
      type: 'splash'
    });
  }

  _updateParticles(dt) {
    // Explosions
    for (let i = this.explosions.length - 1; i >= 0; i--) {
      const exp = this.explosions[i];
      exp.life += dt;
      if (exp.life >= exp.maxLife) {
        this.scene.remove(exp.mesh);
        this.explosions.splice(i, 1);
      } else {
        const prog = exp.life / exp.maxLife;
        const scale = exp.startScale + prog * (exp.targetScale - exp.startScale);
        exp.mesh.scale.set(scale, scale, scale);
        exp.mesh.material.opacity = 1.0 - prog;
        exp.mesh.material.color.setHex(prog > 0.4 ? 0x333333 : 0xff5500);
      }
    }

    // Splashes
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      } else {
        const prog = p.life / p.maxLife;
        const s = 1.0 + prog * 2.2;
        p.mesh.scale.set(s, s, s);
        p.mesh.material.opacity = (1.0 - prog) * 0.7;
      }
    }
  }
}
