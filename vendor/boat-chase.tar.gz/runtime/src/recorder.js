// Boat Chase: In-Browser 60FPS Video Recorder & Cinematic End-Game Replay
// Native MediaRecorder capturing WebGL canvas with zero dependencies.

export class GameVideoRecorder {
  constructor(canvas) {
    this.canvas = canvas;
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.isRecording = false;
    this.videoUrl = null;
    this.recordingStartTime = 0;

    this.recIndicator = document.getElementById('rec-indicator');
    this.recBtn = document.getElementById('rec-btn');
    this._setupUI();
  }

  _setupUI() {
    if (this.recBtn) {
      this.recBtn.addEventListener('click', () => {
        if (this.isRecording) {
          this.stopRecording(true);
        } else {
          this.startRecording();
        }
      });
    }
  }

  startRecording() {
    if (this.isRecording) return;
    try {
      // 60 FPS Canvas stream capture
      const stream = this.canvas.captureStream(60);
      let options = { mimeType: 'video/webm;codecs=vp9' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) {
        options = { mimeType: 'video/webm' };
      }

      this.mediaRecorder = new MediaRecorder(stream, options);
      this.recordedChunks = [];

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          this.recordedChunks.push(e.data);
        }
      };

      this.mediaRecorder.onstop = () => {
        const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
        this.videoUrl = URL.createObjectURL(blob);
        this._showReplayModal(blob);
      };

      this.mediaRecorder.start(1000); // 1-second chunks
      this.isRecording = true;
      this.recordingStartTime = Date.now();

      if (this.recIndicator) this.recIndicator.classList.add('active');
      if (this.recBtn) this.recBtn.innerText = '⏹ Stop Recording';
      console.log('Gameplay recording started at 60 FPS');
    } catch (err) {
      console.warn('MediaRecorder error:', err);
    }
  }

  stopRecording(showModal = true) {
    if (!this.isRecording || !this.mediaRecorder) return;
    this.isRecording = false;
    if (this.recIndicator) this.recIndicator.classList.remove('active');
    if (this.recBtn) this.recBtn.innerText = '🔴 Record Clip';

    if (this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
  }

  _showReplayModal(blob) {
    let modal = document.getElementById('video-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'video-modal';
      modal.className = 'modal-overlay';
      document.body.appendChild(modal);
    }

    const durationSec = Math.round((Date.now() - this.recordingStartTime) / 1000);

    modal.innerHTML = `
      <div class="modal-card">
        <h2 style="color: #00f2fe; margin-top: 0;">🎬 Gameplay Video Ready!</h2>
        <p style="color: #ccc;">Captured ${durationSec}s HD WebGL footage ready to upload to GitHub.</p>
        <div style="margin: 15px 0;">
          <video id="replay-video-player" src="${this.videoUrl}" controls autoplay loop style="width: 100%; max-height: 320px; border-radius: 8px; border: 2px solid #00f2fe; background: #000;"></video>
        </div>
        <div style="display: flex; gap: 12px; justify-content: center;">
          <button id="download-video-btn" class="btn btn-primary" style="background: #2ecc71;">💾 Download Video (.webm)</button>
          <button id="close-video-btn" class="btn btn-secondary">✕ Close</button>
        </div>
      </div>
    `;

    modal.style.display = 'flex';

    document.getElementById('download-video-btn').addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = this.videoUrl;
      a.download = `Boat_Chase_GTA_Gameplay_${Date.now()}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });

    document.getElementById('close-video-btn').addEventListener('click', () => {
      modal.style.display = 'none';
      const player = document.getElementById('replay-video-player');
      if (player) player.pause();
    });
  }

  triggerEndGameReplay(victory, score, stunts) {
    // If we've been recording, stop and display video
    if (this.isRecording) {
      this.stopRecording(true);
    } else {
      // Auto-recorded clip or show victory screen
      const modal = document.getElementById('end-game-modal');
      if (modal) {
        modal.querySelector('.end-title').innerText = victory ? '🏆 ESCAPED TO SAFE HAVEN!' : '💥 BOAT DESTROYED';
        modal.querySelector('.end-title').style.color = victory ? '#2ecc71' : '#ff3838';
        modal.querySelector('.end-score').innerText = `Final Score: ${score} | Stunts: ${stunts}`;
        modal.style.display = 'flex';
      }
    }
  }
}
