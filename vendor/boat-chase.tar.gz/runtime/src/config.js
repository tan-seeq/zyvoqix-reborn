// Boat Chase: Faction Turf Wars - Game Configuration

export const CONFIG = {
  // World & Map: Vibrant Sunwake Golden Hour Sunset
  WORLD_SIZE: 3200,
  TIME_OF_DAY: 'SUNSET', // Default to Sunwake Golden Hour
  SKY_COLOR: 0xfba056, // Warm peach sunset sky
  WATER_COLOR: 0x0284c7, // Vibrant sapphire/cyan faceted ocean
  WATER_DEEP_COLOR: 0x034791, // Deep navy ocean floor
  WATER_SPECULAR: 0xfef08a, // Golden sun reflection glint
  FOG_COLOR: 0xfba056, // Golden atmospheric haze
  FOG_NEAR: 320,
  FOG_FAR: 1300,

  // Lighting
  SUN_COLOR: 0xffe082,
  SUN_INTENSITY: 2.2,
  AMBIENT_COLOR: 0xfde68a,
  AMBIENT_INTENSITY: 0.95,

  // Player Boat Physics & Handling (Faster, Agile, Rock-Solid Upright Stability)
  PLAYER: {
    ACCELERATION: 78, // Snappy instantaneous throttle
    MAX_SPEED: 92, // Much faster base cruising speed (was 74)
    REVERSE_SPEED: 32,
    TURN_SPEED: 3.2, // Snappy turning authority to both sides
    DRIFT_FACTOR: 0.88,
    DRAG: 0.990,
    BOOST_MULTIPLIER: 1.85, // Thrilling boost speed (reaches ~170 knots!)
    MAX_BOOST: 100,
    BOOST_DRAIN: 25, // per sec (more generous boost)
    BOOST_RECHARGE: 22, // per sec
    MAX_HEALTH: 200,
    REGEN_RATE: 10,
    REGEN_DELAY: 3.5,
    COLLISION_DAMAGE_FACTOR: 0.06, // Very forgiving
    RAMMING_FORCE: 80,
  },

  // Factions definition & hostility
  FACTIONS: {
    POLICE: {
      id: 'police',
      name: 'Coast Guard / Police',
      color: 0x0284c7,
      hudColor: '#0284c7',
      hullColor: 0xf8fafc,
      cabinColor: 0x1e3a8a,
      stripeColor: 0x2563eb,
      sirenColors: [0xef4444, 0x3b82f6],
      baseSpeed: 60,
      turnSpeed: 2.1,
      health: 75,
      damage: 4, // Cinematically survivable
      fireRate: 0.38,
      spread: 0.18, // Bullets splash around player dramatically
      detectRadius: 180,
      visionAngle: Math.PI * 0.55,
      alertRadioRadius: 280,
      scoreValue: 200,
      description: 'High-speed interceptor cutters with sirens.'
    },
    HEAVY_POLICE: {
      id: 'police',
      subType: 'heavy_cutter',
      name: 'Port Authority Heavy Cutter',
      color: 0x0284c7,
      hudColor: '#38bdf8',
      hullColor: 0x0f172a,
      cabinColor: 0x1e293b,
      stripeColor: 0x38bdf8,
      sirenColors: [0xef4444, 0x3b82f6],
      baseSpeed: 52,
      turnSpeed: 1.45,
      health: 220,
      damage: 10,
      fireRate: 0.28,
      spread: 0.12,
      detectRadius: 240,
      visionAngle: Math.PI * 0.75,
      alertRadioRadius: 360,
      scoreValue: 850,
      description: 'Armored twin-hull coastal patrol cutter with dual autocannons and depth charges.'
    },
    GANGSTER: {
      id: 'gangster',
      name: 'Cartel Gunboat Gang',
      color: 0xdc2626,
      hudColor: '#ef4444',
      hullColor: 0x0f172a,
      cabinColor: 0x991b1b,
      stripeColor: 0xef4444,
      baseSpeed: 66,
      turnSpeed: 2.5,
      health: 60,
      damage: 6,
      fireRate: 0.24,
      spread: 0.20,
      detectRadius: 165,
      visionAngle: Math.PI * 0.60,
      alertRadioRadius: 240,
      scoreValue: 160,
      description: 'Fast offshore catamarans with rapid SMGs.'
    },
    CONVOY_LEADER: {
      id: 'gangster',
      subType: 'convoy_leader',
      name: 'Cartel Convoy Flagship',
      color: 0x18181b,
      hudColor: '#f59e0b',
      hullColor: 0x18181b,
      cabinColor: 0x7c2d12,
      stripeColor: 0xf59e0b,
      baseSpeed: 48,
      turnSpeed: 1.5,
      health: 240,
      damage: 9,
      fireRate: 0.22,
      spread: 0.14,
      detectRadius: 260,
      visionAngle: Math.PI * 0.70,
      alertRadioRadius: 360,
      scoreValue: 1500,
      description: 'Armored cartel flagship transporting the Crown Smuggle Diamond.'
    },
    PIRATES: {
      id: 'pirates',
      name: 'Skull Cove Pirates',
      color: 0xd97706,
      hudColor: '#f59e0b',
      hullColor: 0x451a03,
      cabinColor: 0x1c1917,
      stripeColor: 0xd97706,
      baseSpeed: 46,
      turnSpeed: 1.7,
      health: 130,
      damage: 22,
      fireRate: 1.4,
      spread: 0.15,
      detectRadius: 190,
      visionAngle: Math.PI * 0.70,
      alertRadioRadius: 220,
      scoreValue: 300,
      description: 'Armored gun barges firing heavy cannonballs.'
    },
    IRONCLAD_GALLEON: {
      id: 'pirates',
      subType: 'ironclad_galleon',
      name: "Blackbeard's Ironclad Galleon",
      color: 0x451a03,
      hudColor: '#d97706',
      hullColor: 0x271306,
      cabinColor: 0x1c1917,
      stripeColor: 0xd97706,
      baseSpeed: 42,
      turnSpeed: 1.3,
      health: 280,
      damage: 26,
      fireRate: 1.2,
      spread: 0.10,
      detectRadius: 280,
      visionAngle: Math.PI * 0.85,
      alertRadioRadius: 400,
      scoreValue: 1800,
      description: 'Heavily armored pirate war galleon with triple broadside cannons and explosive pitch barrels.'
    }
  },

  // Dynamic Day / Sunset / Cyber-Night Lighting Presets
  LIGHTING_PRESETS: {
    DAY: {
      name: 'Day',
      skyColor: 0x48b4e0,
      fogColor: 0x7dd3fc,
      fogNear: 350,
      fogFar: 1100,
      waterColor: 0x0ea5e9,
      waterDeepColor: 0x0369a1,
      hemiSky: 0x7ed6df,
      hemiGround: 0x130f40,
      hemiIntensity: 0.75,
      sunColor: 0xfffbeb,
      sunIntensity: 1.4,
      sunOffset: { x: 120, y: 180, z: 100 }
    },
    SUNSET: {
      name: 'Golden Sunset',
      skyColor: 0xf472b6, // Soft sunset rose
      fogColor: 0xfba056, // Warm peach haze
      fogNear: 300,
      fogFar: 1300,
      waterColor: 0x0284c7, // Vibrant sapphire/cyan faceted ocean
      waterDeepColor: 0x034791, // Deep ocean base
      hemiSky: 0xfba056,
      hemiGround: 0x0c4a6e,
      hemiIntensity: 0.95,
      sunColor: 0xffe082, // Low golden sun
      sunIntensity: 2.2,
      sunOffset: { x: 180, y: 52, z: -140 }
    },
    CYBER_NIGHT: {
      name: 'Cyber-Night',
      skyColor: 0x030712,
      fogColor: 0x0b132b,
      fogNear: 180,
      fogFar: 820,
      waterColor: 0x082f49,
      waterDeepColor: 0x020617,
      hemiSky: 0x1e1b4b,
      hemiGround: 0x020617,
      hemiIntensity: 0.45,
      sunColor: 0x60a5fa,
      sunIntensity: 0.9,
      sunOffset: { x: -90, y: 160, z: -90 }
    }
  },
  DIAMOND_CACHE_SCORE: 1500,
  NANITE_SHIELD_DURATION: 10.0,

  // Offshore Oil Rig Refinery Platform
  OIL_RIG: {
    x: 350,
    z: -850,
    deckWidth: 58,
    deckLength: 48,
    deckHeight: 14,
    tankCount: 4,
    tankHealth: 120,
    tankBlastRadius: 42,
    tankBlastDamage: 130,
    stuntScore: 1100
  },

  // Police Helicopter Air Support (Wanted Level 3+)
  HELICOPTER: {
    speed: 55,
    altitude: 38,
    searchlightRadius: 40,
    fireRate: 0.18,
    burstCount: 5,
    damage: 6,
    health: 120
  },

  // Hostility matrix
  HOSTILITY: {
    player: { police: true, gangster: true, pirates: true },
    police: { player: true, gangster: true, pirates: true },
    gangster: { player: true, police: true, pirates: true },
    pirates: { player: true, police: true, gangster: true }
  },

  // Weapons
  WEAPONS: {
    MG: {
      speed: 210,
      damage: 14,
      spread: 0.035,
      fireRate: 0.11,
      range: 240,
      color: 0xfde047
    },
    TORPEDO: {
      speed: 105,
      turnRate: 3.8,
      damage: 85,
      blastRadius: 32,
      fireRate: 1.6,
      range: 380,
      color: 0x38bdf8
    },
    DEPTH_CHARGE: {
      drag: 0.94,
      damage: 120,
      blastRadius: 48,
      fuseTime: 2.2,
      fireRate: 2.0,
      color: 0xf97316
    },
    RAILGUN: {
      speed: 340,
      damage: 160,
      range: 450,
      fireRate: 1.8,
      ammo: 5,
      penetrationCount: 4,
      color: 0x00f2fe
    },
    EMP: {
      blastRadius: 65,
      disableDuration: 7.0,
      fireRate: 2.5,
      ammo: 3,
      color: 0xa855f7
    }
  },

  // Secret Submarine Pen Cavern Dock
  SUB_PEN: {
    x: -920,
    z: 120,
    width: 44,
    length: 90,
    height: 26,
    subLength: 76,
    subHealth: 350,
    stuntScore: 950
  },

  // Naval Supercarrier Battlecruiser "USS Leviathan"
  CARRIER: {
    x: 880,
    z: -1050,
    length: 220,
    deckWidth: 52,
    deckHeight: 15,
    rampWidth: 24,
    rampLength: 42,
    rampAngle: 0.38,
    stuntScore: 1600
  },

  // Floating Seaplane Hangar & Amphibious Water Landing Strip
  SEAPLANE_HANGAR: {
    x: -480,
    z: -920,
    hangarWidth: 54,
    hangarLength: 64,
    hangarHeight: 22,
    runwayLength: 190,
    runwayWidth: 32,
    stuntScore: 900
  },

  // Smuggler's Sea Arch Cavern & Slalom Spire Channel
  SEA_ARCH: {
    x: 240,
    z: -420,
    span: 38,
    archHeight: 22,
    chasmLength: 68,
    pillarRadius: 14,
    stuntScore: 800
  },

  // Dynamic Rogue Tidal Wave Surge
  ROGUE_WAVE: {
    interval: 50.0,
    speed: 32.0,
    width: 260.0,
    amplitude: 4.8,
    launchBoost: 2.2,
    stuntScore: 1400
  },

  // Sentinel Lighthouse Island & Sweeping Searchlight
  LIGHTHOUSE: {
    x: -200,
    z: -780,
    towerHeight: 38,
    beamLength: 95,
    beamRadius: 28,
    rotationSpeed: 0.68,
    stuntScore: 1050
  },

  // Sunken 17th-Century Spanish Galleon Shipwreck & Coral Reef Ramp
  SUNKEN_GALLEON: {
    x: -160,
    z: -740,
    wreckLength: 54,
    rampWidth: 16,
    rampLength: 32,
    rampBoost: 1.55,
    stuntScore: 1100
  },

  // Dynamic Marine Waterspout Tornado Vortex Hazard
  WATERSPOUT: {
    x: -60,
    z: -350,
    radius: 55,
    coreRadius: 11,
    suctionForce: 26,
    swirlSpeed: 34,
    launchVelo: 52,
    stuntScore: 1350
  },

  // Cartel Armored Amphibious Hovercraft Gunship
  HOVERCRAFT: {
    x: 650,
    z: 250,
    health: 190,
    maxSpeed: 42,
    autocannonDamage: 8,
    fireRate: 0.20,
    burstCount: 4,
    stuntScore: 1200
  },

  // Floating Offshore Casino Palace & Luxury Superyacht Marina
  CASINO: {
    x: 520,
    z: -180,
    width: 58,
    length: 110,
    fountainRampX: 520,
    fountainRampZ: -122,
    fountainRampBoost: 1.52,
    helipadRampX: 520,
    helipadRampZ: -205,
    helipadRampBoost: 1.60,
    vaultScore: 2500,
    stuntScore: 1150
  },

  // Private Casino Security Patrol Catamaran
  SECURITY_CATAMARAN: {
    health: 140,
    baseSpeed: 38,
    turnSpeed: 2.5,
    damage: 9,
    fireRate: 0.28,
    stuntScore: 750
  },

  // Naval Zeppelin Gunship ("The Iron Valkyrie") Aerial Boss
  ZEPPELIN: {
    altitude: 62,
    health: 380,
    speed: 18,
    searchlightRadius: 36,
    bombRate: 3.5,
    bombDamage: 38,
    turretDamage: 10,
    turretRate: 0.22,
    stuntScore: 2200
  },

  // Smuggler's Hydrofoil Speed Wings Upgrade
  HYDROFOIL: {
    deploySpeed: 28,
    liftHeight: 0.85,
    speedBonus: 14,
    dragReduction: 0.35,
    stuntScore: 700
  },

  // GTA Camera Settings: Cinematic 3rd-Person Follow Cam (Default)
  CAMERA: {
    DEFAULT_MODE: 'GTA_CHASE', // 'GTA_CHASE' or 'TOP_DOWN'
    GTA_CHASE: {
      height: 14,
      distance: 34,
      pitch: -0.18,
      fov: 62,
      boostFov: 74,
      damping: 6.5,
      leadDistance: 12
    },
    TOP_DOWN: {
      height: 130,
      pitch: -1.35,
      fov: 52,
      leadDistance: 16
    }
  },

  // Stunts & Pickups
  RAMP_LAUNCH_FORCE: 44,
  BARREL_EXPLOSION_RADIUS: 38,
  BARREL_EXPLOSION_DAMAGE: 95,
  CONTRABAND_SCORE: 350,
  REPAIR_KIT_HEAL: 40
};
