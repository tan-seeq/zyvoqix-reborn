// Boat Chase: World, Islands, Waterways, Bridges, Pickups & Day Atmosphere
import * as THREE from '../lib/three.module.js';
import { CONFIG } from './config.js';

export class VoxelDebrisManager {
  constructor(scene) {
    this.scene = scene;
    this.maxDebris = 240;
    this.debrisPool = [];
    this.currentIndex = 0;

    const geo = new THREE.BoxGeometry(0.85, 0.85, 0.85);
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    this.instancedMesh = new THREE.InstancedMesh(geo, mat, this.maxDebris);
    this.instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    const dummy = new THREE.Object3D();
    dummy.position.set(0, -9999, 0);
    dummy.updateMatrix();

    for (let i = 0; i < this.maxDebris; i++) {
      this.instancedMesh.setMatrixAt(i, dummy.matrix);
      this.instancedMesh.setColorAt(i, new THREE.Color(0xf59e0b));
      this.debrisPool.push({
        active: false,
        pos: new THREE.Vector3(0, -9999, 0),
        vel: new THREE.Vector3(),
        rot: new THREE.Vector3(),
        rotVel: new THREE.Vector3(),
        scale: 1,
        life: 0,
        maxLife: 1.5
      });
    }
    this.instancedMesh.instanceMatrix.needsUpdate = true;
    if (this.instancedMesh.instanceColor) {
      this.instancedMesh.instanceColor.needsUpdate = true;
    }
    this.scene.add(this.instancedMesh);
    this.dummy = dummy;
  }

  spawn(x, y, z, count = 14, colorHex = 0xf59e0b) {
    const col = new THREE.Color(colorHex);
    for (let i = 0; i < count; i++) {
      const p = this.debrisPool[this.currentIndex];
      const idx = this.currentIndex;
      this.currentIndex = (this.currentIndex + 1) % this.maxDebris;

      p.active = true;
      p.pos.set(
        x + (Math.random() - 0.5) * 2.2,
        y + Math.random() * 1.5,
        z + (Math.random() - 0.5) * 2.2
      );
      const speed = 14 + Math.random() * 26;
      const angle = Math.random() * Math.PI * 2;
      p.vel.set(
        Math.cos(angle) * speed,
        15 + Math.random() * 25,
        Math.sin(angle) * speed
      );
      p.rot.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      p.rotVel.set(
        (Math.random() - 0.5) * 18,
        (Math.random() - 0.5) * 18,
        (Math.random() - 0.5) * 18
      );
      p.scale = 0.6 + Math.random() * 0.7;
      p.life = 0;
      p.maxLife = 1.2 + Math.random() * 0.8;
      this.instancedMesh.setColorAt(idx, col);
    }
    if (this.instancedMesh.instanceColor) {
      this.instancedMesh.instanceColor.needsUpdate = true;
    }
  }

  update(dt, world) {
    let anyActive = false;
    for (let i = 0; i < this.maxDebris; i++) {
      const p = this.debrisPool[i];
      if (!p.active) continue;

      anyActive = true;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        this.dummy.position.set(0, -9999, 0);
        this.dummy.scale.set(1, 1, 1);
        this.dummy.updateMatrix();
        this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
        continue;
      }

      // Arcade ballistic gravity
      p.vel.y -= 44 * dt;
      p.pos.x += p.vel.x * dt;
      p.pos.y += p.vel.y * dt;
      p.pos.z += p.vel.z * dt;

      p.rot.x += p.rotVel.x * dt;
      p.rot.y += p.rotVel.y * dt;
      p.rot.z += p.rotVel.z * dt;

      // Water surface bounce & splash dampening
      const wave = world ? world.getWaveHeight(p.pos.x, p.pos.z) : 0;
      if (p.pos.y < wave) {
        p.pos.y = wave;
        p.vel.y = -p.vel.y * 0.32;
        p.vel.x *= 0.7;
        p.vel.z *= 0.7;
      }

      const shrink = Math.max(0.01, 1.0 - (p.life / p.maxLife) * 0.85);
      const s = p.scale * shrink;
      this.dummy.position.copy(p.pos);
      this.dummy.rotation.set(p.rot.x, p.rot.y, p.rot.z);
      this.dummy.scale.set(s, s, s);
      this.dummy.updateMatrix();
      this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
    }

    if (anyActive) {
      this.instancedMesh.instanceMatrix.needsUpdate = true;
    }
  }
}

export class WorldManager {
  constructor(scene) {
    this.scene = scene;
    this.colliders = [];     // { x, z, radius, type, mesh }
    this.ramps = [];         // { x, z, width, length, angle, mesh }
    this.barrels = [];       // { x, z, radius, health, mesh, alive }
    this.destructibles = []; // { x, z, radius, type, color, score, mesh, alive }
    this.mines = [];         // { x, z, radius, mesh, alive }
    this.buoys = [];         // { mesh, x, z, baseY, phase }
    this.searchlights = [];  // { mesh, beam, angle, speed }
    this.pickups = [];       // { mesh, x, z, type, radius, alive, rotSpeed }
    this.bridges = [];       // { mesh, x, z, width, length }
    this.roadblocks = [];    // { x, z, width, angle, mesh, barrierBeamsMesh, strobeRed, strobeBlue, alive }
    this.grappleDolphins = []; // { x, z, mesh }
    this.fortTowers = [];      // { x, z, turretMesh, fireTimer, range, engaged }
    this.seaGate = null;       // { x, z, radius, health, maxHealth, alive, mesh, collider, ... }
    this.drawbridges = [];     // { x, z, southLeaf, northLeaf, southRamp, northRamp, ... }
    this.spikeNets = [];       // { x, z, width, angle, alive, mesh, ... }
    this.waterMesh = null;
    this.waterTime = 0;
    this.safeHaven = { x: 1100, z: -1100, radius: 130 };
    this.oilRig = null;
    this.subPen = null;
    this.carrier = null;
    this.seaplaneHangar = null;
    this.seaArch = null;
    this.rogueWave = null;
    this.lighthouse = null;
    this.waterspout = null;
    this.casino = null;
    this.fireHazards = [];

    // Dynamic Tropical Squall System
    this.squallTimer = 0;
    this.isSquallActive = false;
    this.stormWaveMultiplier = 1.0;
    this.lightningTimer = 0;
    this.rainMesh = null;
    this.rainData = [];
    this.lightningLight = null;

    this.debris = new VoxelDebrisManager(this.scene);

    this._createSkyAndAtmosphere();
    this._createWater();
    this._generateComplexMap();
    this._createBridges();
    this._createDrawbridge();
    this._createSpikeNets();
    this._createFloatingPickups();
    this._createDestructibles();
    this._createNavalMinefields();
    this._createRoadblocks();
    this._createGrappleDolphins();
    this._createMovingFreighter();
    this._createSafeHaven();
    this._createOilRig();
    this._createSubmarinePen();
    this._createSupercarrier();
    this._createSeaplaneHangar();
    this._createSeaArch();
    this._initRogueWave();
    this._createLighthouseAndReef();
    this._createWaterspout();
    this._createCasinoPalace();
    this._initSquallSystem();
  }

  _createSkyAndAtmosphere() {
    // 1. Sunwake Gradient Sky Dome (Peach horizon -> Rose mid -> Twilight purple zenith)
    const skyCanvas = document.createElement('canvas');
    skyCanvas.width = 128;
    skyCanvas.height = 512;
    const sCtx = skyCanvas.getContext('2d');
    const grad = sCtx.createLinearGradient(0, 512, 0, 0);
    grad.addColorStop(0, '#fba056');    // Warm golden peach at sea horizon
    grad.addColorStop(0.25, '#fb923c'); // Rich sunset amber
    grad.addColorStop(0.55, '#f472b6'); // Soft evening rose
    grad.addColorStop(0.80, '#818cf8'); // Periwinkle / lavender twilight
    grad.addColorStop(1.0, '#312e81');  // Deep indigo zenith
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 128, 512);

    const skyTex = new THREE.CanvasTexture(skyCanvas);
    const skyGeo = new THREE.SphereGeometry(1400, 32, 24);
    const skyMat = new THREE.MeshBasicMaterial({
      map: skyTex,
      side: THREE.BackSide
    });
    const sky = new THREE.Mesh(skyGeo, skyMat);
    this.scene.add(sky);
    this.skyMesh = sky;

    // 2. Low Golden Sun Disk on the Sunset Horizon
    const sunGroup = new THREE.Group();
    const sunGeo = new THREE.CircleGeometry(58, 32);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffedd5 });
    const sunDisk = new THREE.Mesh(sunGeo, sunMat);
    sunGroup.add(sunDisk);

    // Warm Solar Corona Glow
    const coronaGeo = new THREE.CircleGeometry(110, 32);
    const coronaMat = new THREE.MeshBasicMaterial({
      color: 0xfde047,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending
    });
    const corona = new THREE.Mesh(coronaGeo, coronaMat);
    sunGroup.add(corona);

    sunGroup.position.set(380, 135, -1150);
    sunGroup.lookAt(0, 0, 0);
    this.scene.add(sunGroup);
    this.sunDiskGroup = sunGroup;

    // 3. Stylized Low-Poly Flat-Bottomed Sunset Clouds (Sunwake style)
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xfce7f3, // Soft sunset pink-white
      roughness: 0.65,
      metalness: 0.05,
      flatShading: true,
      transparent: true,
      opacity: 0.92
    });

    for (let i = 0; i < 32; i++) {
      const cloudGroup = new THREE.Group();
      const numBlocks = 3 + Math.floor(Math.random() * 4);
      const baseWidth = 80 + Math.random() * 110;
      const baseHeight = 16 + Math.random() * 14;
      const baseDepth = 42 + Math.random() * 30;

      for (let b = 0; b < numBlocks; b++) {
        const bw = baseWidth * (0.5 + Math.random() * 0.5);
        const bh = baseHeight * (0.6 + Math.random() * 0.6);
        const bd = baseDepth * (0.6 + Math.random() * 0.5);
        const block = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), cloudMat);
        block.position.set((b - numBlocks / 2) * (bw * 0.45), bh * 0.5, (Math.random() - 0.5) * 15);
        cloudGroup.add(block);
      }

      const cx = (Math.random() - 0.5) * 2600;
      const cz = -300 - Math.random() * 2000;
      cloudGroup.position.set(cx, 130 + Math.random() * 75, cz);
      this.scene.add(cloudGroup);
    }
  }

  _createWater() {
    // Large stylized tropical water plane with smooth waves
    const waterGeo = new THREE.PlaneGeometry(CONFIG.WORLD_SIZE, CONFIG.WORLD_SIZE, 140, 140);
    waterGeo.rotateX(-Math.PI / 2);

    const waterMat = new THREE.MeshStandardMaterial({
      color: CONFIG.WATER_COLOR,
      roughness: 0.12,
      metalness: 0.85,
      flatShading: true,
      transparent: true,
      opacity: 0.95
    });

    this.waterMesh = new THREE.Mesh(waterGeo, waterMat);
    this.waterMesh.receiveShadow = true;
    this.scene.add(this.waterMesh);

    // Deep seabed plane
    const floorGeo = new THREE.PlaneGeometry(CONFIG.WORLD_SIZE, CONFIG.WORLD_SIZE);
    floorGeo.rotateX(-Math.PI / 2);
    const floorMat = new THREE.MeshBasicMaterial({ color: CONFIG.WATER_DEEP_COLOR });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.position.y = -26;
    this.scene.add(floorMesh);
    this.floorMesh = floorMesh;
  }

  setTimeOfDay(mode) {
    const preset = CONFIG.LIGHTING_PRESETS[mode] || CONFIG.LIGHTING_PRESETS.DAY;
    this.timeOfDay = mode;

    if (this.skyMesh && this.skyMesh.material) {
      this.skyMesh.material.color.setHex(preset.skyColor);
    }
    if (this.waterMesh && this.waterMesh.material) {
      this.waterMesh.material.color.setHex(preset.waterColor);
      if (preset.waterRoughness !== undefined) this.waterMesh.material.roughness = preset.waterRoughness;
      if (preset.waterMetalness !== undefined) this.waterMesh.material.metalness = preset.waterMetalness;
    }
    if (this.floorMesh && this.floorMesh.material) {
      this.floorMesh.material.color.setHex(preset.waterDeepColor);
    }
  }

  getWaveHeight(x, z) {
    const t = this.waterTime;
    const w1 = Math.sin(x * 0.014 + t * 2.0) * Math.cos(z * 0.014 + t * 1.5) * 0.85;
    const w2 = Math.sin((x + z) * 0.032 - t * 2.4) * 0.45;
    const w3 = Math.cos(x * 0.055 - z * 0.038 + t * 1.1) * 0.22;
    let baseWave = (w1 + w2 + w3) * (this.stormWaveMultiplier || 1.0);

    // Dynamic Rogue Tidal Wave Surge
    if (this.rogueWave && this.rogueWave.active) {
      const rw = this.rogueWave;
      const dx = x - rw.x;
      const dz = z - rw.z;
      const nx = Math.sin(rw.angle);
      const nz = Math.cos(rw.angle);
      const perpDist = Math.abs(dx * (-nz) + dz * nx);
      if (perpDist < rw.width * 0.5) {
        const alongDist = dx * nx + dz * nz;
        if (Math.abs(alongDist) < 24) {
          const crestFactor = Math.cos((alongDist / 24) * Math.PI * 0.5);
          const lateralTaper = Math.cos((perpDist / (rw.width * 0.5)) * Math.PI * 0.5);
          baseWave += rw.amplitude * Math.max(0, crestFactor) * Math.max(0, lateralTaper);
        }
      }
    }

    return baseWave;
  }

  _generateComplexMap() {
    this._buildPoliceMarinaZone(-900, -700);
    this._buildIndustrialDocksZone(850, 800);
    this._buildMangroveCanalsZone(-300, 350);
    this._buildPirateSkullCoveZone(950, -650);
    this._buildNavalSeaFortZone(-50, 750);
    this._buildCentralArchipelago(-50, -50);
    this._buildOuterReefBorder();
  }

  _buildPoliceMarinaZone(baseX, baseZ) {
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.7 });
    this._addIsland(baseX, baseZ, 230, 0x475569, 6.5);

    // Concrete breakwater seawalls
    this._addSeawall(baseX + 170, baseZ - 40, 32, 280, Math.PI * 0.08);
    this._addSeawall(baseX - 40, baseZ + 190, 250, 32, -Math.PI * 0.04);

    // Police HQ Building
    const hqGeo = new THREE.BoxGeometry(95, 36, 65);
    const hqMesh = new THREE.Mesh(hqGeo, wallMat);
    hqMesh.position.set(baseX, 18, baseZ);
    hqMesh.castShadow = true;
    this.scene.add(hqMesh);
    this.colliders.push({ x: baseX, z: baseZ, radius: 58, type: 'building' });

    // Helipad on HQ roof with glowing H marker
    const heliGeo = new THREE.CylinderGeometry(19, 19, 1.5, 16);
    const heliMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const helipad = new THREE.Mesh(heliGeo, heliMat);
    helipad.position.set(baseX, 37, baseZ);
    this.scene.add(helipad);

    // Police Watchtower & Searchlight
    this._addLighthouse(baseX + 180, baseZ + 110, 52, 0x38bdf8);

    // Docks
    for (let i = -2; i <= 2; i++) {
      this._addDockPier(baseX + 95, baseZ + i * 44, 70, 14, 0);
    }

    // Stunt ramp over seawall
    this._addStuntRamp(baseX + 140, baseZ - 150, 26, 44, Math.PI * 0.62);
  }

  _buildIndustrialDocksZone(baseX, baseZ) {
    this._addIsland(baseX, baseZ, 270, 0x78716c, 5.0);

    const colors = [0xef4444, 0x0284c7, 0x10b981, 0xf59e0b, 0x334155];
    for (let x = -3; x <= 3; x++) {
      for (let z = -2; z <= 2; z++) {
        if (Math.random() > 0.32) {
          const cx = baseX + x * 54;
          const cz = baseZ + z * 68;
          const h = 16 + Math.floor(Math.random() * 3) * 11;
          const col = colors[Math.floor(Math.random() * colors.length)];
          const boxGeo = new THREE.BoxGeometry(42, h, 22);
          const boxMat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.5, metalness: 0.4 });
          const box = new THREE.Mesh(boxGeo, boxMat);
          box.position.set(cx, h / 2 + 1, cz);
          box.castShadow = true;
          this.scene.add(box);
          this.colliders.push({ x: cx, z: cz, radius: 26, type: 'container' });
        }
      }
    }

    // Oil Storage Silos
    for (let i = -1; i <= 1; i++) {
      const sx = baseX - 150;
      const sz = baseZ + i * 80;
      const siloGeo = new THREE.CylinderGeometry(30, 30, 42, 22);
      const siloMat = new THREE.MeshStandardMaterial({ color: 0xcfd8dc, metalness: 0.7, roughness: 0.3 });
      const silo = new THREE.Mesh(siloGeo, siloMat);
      silo.position.set(sx, 21, sz);
      this.scene.add(silo);
      this.colliders.push({ x: sx, z: sz, radius: 34, type: 'silo' });
    }

    // Explosive fuel barrels
    for (let i = 0; i < 16; i++) {
      const angle = (i / 16) * Math.PI * 2 + (Math.random() - 0.5) * 0.25;
      const dist = 290 + Math.random() * 90;
      this._addExplosiveBarrel(baseX + Math.cos(angle) * dist, baseZ + Math.sin(angle) * dist);
    }

    // Massive docked cargo freighter
    this._addCargoShip(baseX + 250, baseZ + 50, Math.PI * 0.5);

    // Stunt ramp
    this._addStuntRamp(baseX + 130, baseZ + 250, 28, 46, -Math.PI * 0.25);
  }

  _buildMangroveCanalsZone(baseX, baseZ) {
    const islandConfigs = [
      { dx: 0, dz: 0, r: 135 },
      { dx: -190, dz: -95, r: 95 },
      { dx: 180, dz: -115, r: 115 },
      { dx: -150, dz: 155, r: 105 },
      { dx: 170, dz: 165, r: 125 },
      { dx: -320, dz: 45, r: 90 },
      { dx: 330, dz: -25, r: 100 },
      { dx: 45, dz: 290, r: 120 },
      { dx: 0, dz: -270, r: 110 },
    ];

    for (const c of islandConfigs) {
      this._addIsland(baseX + c.dx, baseZ + c.dz, c.r, 0x15803d, 4.0, true);
    }

    // Winding canal stunt ramps
    this._addStuntRamp(baseX - 75, baseZ + 35, 22, 38, Math.PI * 0.22);
    this._addStuntRamp(baseX + 85, baseZ - 45, 22, 38, -Math.PI * 0.68);

    // Buoys
    for (let i = 0; i < 12; i++) {
      const bx = baseX + (i - 6) * 65 + (Math.random() - 0.5) * 30;
      const bz = baseZ + Math.sin(i) * 95;
      this._addBuoy(bx, bz, 0x22c55e);
    }
  }

  _buildPirateSkullCoveZone(baseX, baseZ) {
    this._addIsland(baseX, baseZ, 230, 0x3f2e20, 8.5);

    // Jagged sea rock spires
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2;
      const dist = 230 + Math.sin(i * 3) * 50;
      const rx = baseX + Math.cos(angle) * dist;
      const rz = baseZ + Math.sin(angle) * dist;
      this._addRockPillar(rx, rz, 15 + Math.random() * 16, 28 + Math.random() * 26);
    }

    // Watchtower
    this._addLighthouse(baseX - 85, baseZ - 65, 45, 0xef4444);

    // Galleon Shipwreck
    this._addShipwreck(baseX + 115, baseZ + 95, 0.45);

    // Sea Mines
    for (let i = 0; i < 18; i++) {
      const mx = baseX - 200 + (Math.random() - 0.5) * 130;
      const mz = baseZ - 140 + (Math.random() - 0.5) * 130;
      this._addSeaMine(mx, mz);
    }

    // Pirate ramp over sunken wreck
    this._addStuntRamp(baseX + 45, baseZ - 145, 26, 46, Math.PI * 0.85);
  }

  _buildNavalSeaFortZone(baseX, baseZ) {
    // Fortified naval citadel with twin flanking bastions and a deep canal corridor
    const bastionMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.85 });

    // West Bastion Island & Stone Citadel
    this._addIsland(baseX - 65, baseZ, 56, 0x334155, 8.0);
    const westBastionGeo = new THREE.CylinderGeometry(36, 44, 18, 8);
    const westBastion = new THREE.Mesh(westBastionGeo, bastionMat);
    westBastion.position.set(baseX - 65, 9, baseZ);
    this.scene.add(westBastion);
    this.colliders.push({ x: baseX - 65, z: baseZ, radius: 44, type: 'fort' });

    // East Bastion Island & Stone Citadel
    this._addIsland(baseX + 65, baseZ, 56, 0x334155, 8.0);
    const eastBastionGeo = new THREE.CylinderGeometry(36, 44, 18, 8);
    const eastBastion = new THREE.Mesh(eastBastionGeo, bastionMat);
    eastBastion.position.set(baseX + 65, 9, baseZ);
    this.scene.add(eastBastion);
    this.colliders.push({ x: baseX + 65, z: baseZ, radius: 44, type: 'fort' });

    // Breachable Heavy Sea Gate spanning across the canal entrance at (baseX, baseZ - 20)
    const gateGroup = new THREE.Group();

    // Flanking gate pilasters
    const pierGeo = new THREE.BoxGeometry(8, 22, 12);
    const pierMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 });
    const leftPier = new THREE.Mesh(pierGeo, pierMat);
    leftPier.position.set(baseX - 18, 9, baseZ - 20);
    gateGroup.add(leftPier);

    const rightPier = new THREE.Mesh(pierGeo, pierMat);
    rightPier.position.set(baseX + 18, 9, baseZ - 20);
    gateGroup.add(rightPier);

    // Overhead lintel beam
    const lintelGeo = new THREE.BoxGeometry(42, 3.5, 6.5);
    const lintelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.6 });
    const lintel = new THREE.Mesh(lintelGeo, lintelMat);
    lintel.position.set(baseX, 19, baseZ - 20);
    gateGroup.add(lintel);

    // Heavy iron portcullis grid
    const portcullisGeo = new THREE.BoxGeometry(32, 15, 2.2);
    const portcullisMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.3 });
    const portcullis = new THREE.Mesh(portcullisGeo, portcullisMat);
    portcullis.position.set(baseX, 7.5, baseZ - 20);
    gateGroup.add(portcullis);

    // Yellow caution hazard chevron plate
    const hazardGeo = new THREE.BoxGeometry(28, 2.5, 2.8);
    const hazardMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const hazard = new THREE.Mesh(hazardGeo, hazardMat);
    hazard.position.set(baseX, 7.5, baseZ - 20);
    gateGroup.add(hazard);

    // Flashing red warning beacons on gate piers
    const beaconGeo = new THREE.CylinderGeometry(0.8, 0.8, 1.4, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.9 });
    const leftBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    leftBeacon.position.set(baseX - 18, 21, baseZ - 20);
    gateGroup.add(leftBeacon);

    const rightBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    rightBeacon.position.set(baseX + 18, 21, baseZ - 20);
    gateGroup.add(rightBeacon);

    this.scene.add(gateGroup);

    const gateCollider = { x: baseX, z: baseZ - 20, radius: 18, type: 'seagate' };
    this.colliders.push(gateCollider);

    this.seaGate = {
      x: baseX,
      z: baseZ - 20,
      radius: 18,
      health: 160,
      maxHealth: 160,
      alive: true,
      mesh: gateGroup,
      collider: gateCollider,
      leftBeacon,
      rightBeacon
    };

    // Twin Active Coastal Defense Gun Turrets on the bastions
    for (const off of [-55, 55]) {
      const towerBaseGeo = new THREE.CylinderGeometry(11, 13, 22, 12);
      const towerBase = new THREE.Mesh(towerBaseGeo, bastionMat);
      towerBase.position.set(baseX + off, 11, baseZ + 15);
      this.scene.add(towerBase);

      // Rotating turret assembly
      const turretGroup = new THREE.Group();
      turretGroup.position.set(baseX + off, 22, baseZ + 15);

      const turretDomeGeo = new THREE.CylinderGeometry(7, 8, 4.5, 10);
      const turretMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85 });
      const dome = new THREE.Mesh(turretDomeGeo, turretMat);
      turretGroup.add(dome);

      // Dual heavy artillery barrels
      const gunGeo = new THREE.CylinderGeometry(0.9, 1.2, 16, 8);
      gunGeo.rotateX(Math.PI / 2);
      const leftGun = new THREE.Mesh(gunGeo, turretMat);
      leftGun.position.set(-2.0, 1.0, 8.0);
      turretGroup.add(leftGun);

      const rightGun = new THREE.Mesh(gunGeo, turretMat);
      rightGun.position.set(2.0, 1.0, 8.0);
      turretGroup.add(rightGun);

      this.scene.add(turretGroup);

      this.fortTowers.push({
        x: baseX + off,
        z: baseZ + 15,
        turretMesh: turretGroup,
        fireTimer: 1.0 + Math.random() * 2.0,
        range: 300,
        engaged: false
      });
    }

    // Secret loot inside the citadel canal
    this._addPickup(baseX, baseZ + 25, 'contraband');
    this._addPickup(baseX, baseZ + 55, 'repair');
    this._addPickup(baseX, baseZ + 85, 'contraband');

    // Buoys lining the canal edges
    for (let zOff = 0; zOff <= 100; zOff += 25) {
      this._addBuoy(baseX - 15, baseZ + zOff, 0x00f2fe);
      this._addBuoy(baseX + 15, baseZ + zOff, 0x00f2fe);
    }

    // Stunt ramps: northern exit ramp into open sea & outer approach ramp
    this._addStuntRamp(baseX, baseZ + 115, 24, 44, 0);
    this._addStuntRamp(baseX, baseZ - 90, 26, 44, 0);
  }

  _buildCentralArchipelago(baseX, baseZ) {
    const sands = [
      { x: baseX - 390, z: baseZ - 190, r: 75 },
      { x: baseX + 350, z: baseZ - 230, r: 85 },
      { x: baseX - 270, z: baseZ + 330, r: 90 },
      { x: baseX + 320, z: baseZ + 370, r: 80 },
      { x: baseX, z: baseZ, r: 95 },
    ];

    for (const s of sands) {
      this._addIsland(s.x, s.z, s.r, 0xfde047, 3.0, true);
    }

    // Open bay stunt ramps
    this._addStuntRamp(baseX - 125, baseZ - 85, 30, 50, Math.PI * 0.4);
    this._addStuntRamp(baseX + 145, baseZ + 115, 30, 50, -Math.PI * 0.6);

    // Channel buoys
    for (let i = -5; i <= 5; i++) {
      this._addBuoy(baseX + i * 95, baseZ - 35, i % 2 === 0 ? 0xef4444 : 0x10b981);
    }
  }

  _buildOuterReefBorder() {
    const half = CONFIG.WORLD_SIZE / 2 - 60;
    const step = 85;
    for (let x = -half; x <= half; x += step) {
      this._addRockPillar(x, -half, 26, 36);
      this._addRockPillar(x, half, 26, 36);
    }
    for (let z = -half; z <= half; z += step) {
      this._addRockPillar(-half, z, 26, 36);
      this._addRockPillar(half, z, 26, 36);
    }
  }

  _createBridges() {
    // Grand Highway Bridge spanning over water channel connecting Police base to central island
    this._addBridge(-480, -320, 320, 24, 22, Math.PI * 0.25);
    // Industrial canal bridge
    this._addBridge(420, 480, 260, 20, 18, -Math.PI * 0.35);
  }

  _addBridge(x, z, length, width, clearanceHeight, rotY) {
    const bridgeGroup = new THREE.Group();
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.6 });
    const asphaltMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });

    // Road Deck
    const deckGeo = new THREE.BoxGeometry(width, 3.5, length);
    const deck = new THREE.Mesh(deckGeo, asphaltMat);
    deck.position.y = clearanceHeight;
    bridgeGroup.add(deck);

    // Guardrails
    for (const sx of [-width / 2 + 0.5, width / 2 - 0.5]) {
      const railGeo = new THREE.BoxGeometry(0.8, 2.0, length);
      const rail = new THREE.Mesh(railGeo, bridgeMat);
      rail.position.set(sx, clearanceHeight + 2.5, 0);
      bridgeGroup.add(rail);
    }

    // Support pillars in the water (boats can speed between them!)
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.8 });
    for (const pz of [-length * 0.35, length * 0.35]) {
      const pGeo = new THREE.CylinderGeometry(4.5, 5.5, clearanceHeight + 4, 12);
      const pMesh = new THREE.Mesh(pGeo, pillarMat);
      pMesh.position.set(0, clearanceHeight / 2, pz);
      bridgeGroup.add(pMesh);

      // Add pillar colliders so boats crash if hitting pillars directly
      const cos = Math.cos(rotY);
      const sin = Math.sin(rotY);
      const wx = x - sin * pz;
      const wz = z + cos * pz;
      this.colliders.push({ x: wx, z: wz, radius: 6.5, type: 'pillar' });
    }

    bridgeGroup.position.set(x, 0, z);
    bridgeGroup.rotation.y = rotY;
    this.scene.add(bridgeGroup);
    this.bridges.push({ mesh: bridgeGroup, x, z, width, length });
  }

  _createDrawbridge() {
    // Dynamic Bascule Drawbridge spanning across the industrial canal (x: 180, z: 220)
    const abutmentMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.8 });
    const asphaltMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    const hazardMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

    const width = 22;
    const clearance = 14;
    const spanLen = 46;

    // South Abutment Pier (x: 180, z: 165)
    const southPierGeo = new THREE.BoxGeometry(width + 6, clearance + 6, 18);
    const southPier = new THREE.Mesh(southPierGeo, abutmentMat);
    southPier.position.set(180, (clearance + 6) / 2, 165);
    this.scene.add(southPier);
    this.colliders.push({ x: 180, z: 165, radius: 15, type: 'pillar' });

    // North Abutment Pier (x: 180, z: 275)
    const northPierGeo = new THREE.BoxGeometry(width + 6, clearance + 6, 18);
    const northPier = new THREE.Mesh(northPierGeo, abutmentMat);
    northPier.position.set(180, (clearance + 6) / 2, 275);
    this.scene.add(northPier);
    this.colliders.push({ x: 180, z: 275, radius: 15, type: 'pillar' });

    // Approach Roadways
    const appGeo = new THREE.BoxGeometry(width, 3, 50);
    const southApp = new THREE.Mesh(appGeo, asphaltMat);
    southApp.position.set(180, clearance + 1.5, 135);
    this.scene.add(southApp);

    const northApp = new THREE.Mesh(appGeo, asphaltMat);
    northApp.position.set(180, clearance + 1.5, 305);
    this.scene.add(northApp);

    // South Bascule Leaf Pivot Group (pivots at z: 174, y: clearance + 1.5)
    const southLeaf = new THREE.Group();
    southLeaf.position.set(180, clearance + 1.5, 174);

    const leafDeckGeo = new THREE.BoxGeometry(width, 2.5, spanLen);
    const southLeafDeck = new THREE.Mesh(leafDeckGeo, asphaltMat);
    southLeafDeck.position.set(0, 0, spanLen / 2);
    southLeaf.add(southLeafDeck);

    // Side truss guardrails
    for (const sx of [-width / 2 + 0.6, width / 2 - 0.6]) {
      const trussGeo = new THREE.BoxGeometry(0.8, 4.2, spanLen);
      const truss = new THREE.Mesh(trussGeo, steelMat);
      truss.position.set(sx, 2.8, spanLen / 2);
      southLeaf.add(truss);
    }

    // Yellow hazard warning stripe at tip of span
    const tipGeo = new THREE.BoxGeometry(width + 0.2, 2.7, 2.5);
    const southTip = new THREE.Mesh(tipGeo, hazardMat);
    southTip.position.set(0, 0, spanLen - 1.25);
    southLeaf.add(southTip);

    // Warning amber strobes on tip
    const beaconGeo = new THREE.CylinderGeometry(0.7, 0.7, 1.2, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.9 });
    const southBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    southBeacon.position.set(0, 2.2, spanLen - 1.25);
    southLeaf.add(southBeacon);

    this.scene.add(southLeaf);

    // North Bascule Leaf Pivot Group (pivots at z: 266, y: clearance + 1.5)
    const northLeaf = new THREE.Group();
    northLeaf.position.set(180, clearance + 1.5, 266);

    const northLeafDeck = new THREE.Mesh(leafDeckGeo, asphaltMat);
    northLeafDeck.position.set(0, 0, -spanLen / 2);
    northLeaf.add(northLeafDeck);

    for (const sx of [-width / 2 + 0.6, width / 2 - 0.6]) {
      const trussGeo = new THREE.BoxGeometry(0.8, 4.2, spanLen);
      const truss = new THREE.Mesh(trussGeo, steelMat);
      truss.position.set(sx, 2.8, -spanLen / 2);
      northLeaf.add(truss);
    }

    const northTip = new THREE.Mesh(tipGeo, hazardMat);
    northTip.position.set(0, 0, -(spanLen - 1.25));
    northLeaf.add(northTip);

    const northBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    northBeacon.position.set(0, 2.2, -(spanLen - 1.25));
    northLeaf.add(northBeacon);

    this.scene.add(northLeaf);

    // Dynamic Ramps associated with the leaves
    const southRamp = {
      x: 180,
      z: 195,
      width: width,
      length: spanLen,
      angle: 0,
      isDrawbridge: true,
      active: false
    };
    const northRamp = {
      x: 180,
      z: 245,
      width: width,
      length: spanLen,
      angle: Math.PI,
      isDrawbridge: true,
      active: false
    };
    this.ramps.push(southRamp, northRamp);

    this.drawbridges.push({
      x: 180,
      z: 220,
      southLeaf,
      northLeaf,
      southBeacon,
      northBeacon,
      southRamp,
      northRamp,
      currentAngle: 0,
      state: 'CLOSED',
      timer: 0
    });
  }

  _createSpikeNets() {
    const netConfigs = [
      { x: -380, z: -180, width: 38, angle: 0.3 }, // Police Marina exit channel
      { x: 360, z: -240, width: 38, angle: -0.5 }  // Skull Cove straits channel
    ];

    for (const cfg of netConfigs) {
      const group = new THREE.Group();
      const numBuoys = 7;
      const step = cfg.width / (numBuoys - 1);

      const buoyGeo = new THREE.SphereGeometry(1.2, 8, 8);
      const buoyMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 });
      const cableGeo = new THREE.CylinderGeometry(0.18, 0.18, cfg.width, 6);
      cableGeo.rotateZ(Math.PI / 2);
      const cableMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9 });
      const cable = new THREE.Mesh(cableGeo, cableMat);
      cable.position.y = 0.5;
      group.add(cable);

      for (let i = 0; i < numBuoys; i++) {
        const bx = -cfg.width / 2 + i * step;
        const buoy = new THREE.Mesh(buoyGeo, buoyMat);
        buoy.position.set(bx, 0.4, 0);
        group.add(buoy);

        // Underwater triangular spike teeth
        const spikeGeo = new THREE.ConeGeometry(0.45, 1.6, 4);
        const spikeMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.85 });
        const spike = new THREE.Mesh(spikeGeo, spikeMat);
        spike.position.set(bx, -0.6, 0);
        group.add(spike);
      }

      // Flashing amber strobe beacons on ends
      const beaconGeo = new THREE.CylinderGeometry(0.5, 0.5, 1.0, 8);
      const beaconMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.9 });
      const leftBeacon = new THREE.Mesh(beaconGeo, beaconMat);
      leftBeacon.position.set(-cfg.width / 2, 1.8, 0);
      group.add(leftBeacon);

      const rightBeacon = new THREE.Mesh(beaconGeo, beaconMat);
      rightBeacon.position.set(cfg.width / 2, 1.8, 0);
      group.add(rightBeacon);

      group.position.set(cfg.x, 0, cfg.z);
      group.rotation.y = cfg.angle;
      this.scene.add(group);

      this.spikeNets.push({
        x: cfg.x,
        z: cfg.z,
        width: cfg.width,
        angle: cfg.angle,
        alive: true,
        mesh: group,
        leftBeacon,
        rightBeacon
      });
    }
  }

  _createFloatingPickups() {
    // Golden Contraband Loot Crates
    const crateSpawns = [
      { x: -280, z: 220 }, { x: -140, z: 420 }, { x: 380, z: 280 },
      { x: 580, z: 620 }, { x: -620, z: -350 }, { x: 750, z: -380 },
      { x: -50, z: -250 }, { x: 220, z: -480 }, { x: -450, z: 120 }
    ];
    for (const c of crateSpawns) {
      this._addPickup(c.x, c.z, 'contraband');
    }

    // Green Hull Repair Kits
    const kitSpawns = [
      { x: 120, z: 50 }, { x: -520, z: 280 }, { x: 680, z: 450 },
      { x: -380, z: -520 }, { x: 880, z: -250 }
    ];
    for (const k of kitSpawns) {
      this._addPickup(k.x, k.z, 'repair');
    }
  }

  _addPickup(x, z, type) {
    const group = new THREE.Group();
    if (type === 'contraband') {
      // Golden glowing cargo crate
      const boxGeo = new THREE.BoxGeometry(4.5, 4.5, 4.5);
      const boxMat = new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        metalness: 0.85,
        roughness: 0.2
      });
      const box = new THREE.Mesh(boxGeo, boxMat);
      group.add(box);

      // Gold halo ring
      const ringGeo = new THREE.TorusGeometry(4.8, 0.4, 8, 20);
      ringGeo.rotateX(Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      group.add(ring);
      group.position.set(x, 2.5, z);
      this.scene.add(group);
      this.pickups.push({ mesh: group, x, z, type, radius: 5.5, alive: true, rotSpeed: 1.8 });
    } else if (type === 'diamond_cache') {
      // High-Value Crown Diamond Cargo Cache (Heist Drop)
      const boxGeo = new THREE.BoxGeometry(4.8, 3.2, 4.8);
      const boxMat = new THREE.MeshStandardMaterial({
        color: 0x18181b,
        metalness: 0.9,
        roughness: 0.2
      });
      const box = new THREE.Mesh(boxGeo, boxMat);
      group.add(box);

      // Gold frame brackets
      const bracketGeo = new THREE.BoxGeometry(5.0, 3.4, 5.0);
      const bracketMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.25, wireframe: true });
      const bracket = new THREE.Mesh(bracketGeo, bracketMat);
      group.add(bracket);

      // Large Glowing Crown Diamond Octahedron
      const gemGeo = new THREE.OctahedronGeometry(2.4, 0);
      const gemMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0ea5e9,
        emissiveIntensity: 0.85,
        roughness: 0.1,
        metalness: 0.95
      });
      const gem = new THREE.Mesh(gemGeo, gemMat);
      gem.position.y = 3.6;
      group.add(gem);

      // Dual Orbiting Halo Rings
      const ring1Geo = new THREE.TorusGeometry(3.6, 0.22, 8, 24);
      ring1Geo.rotateX(Math.PI / 2);
      const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
      ring1.position.y = 3.6;
      group.add(ring1);

      const ring2Geo = new THREE.TorusGeometry(3.6, 0.22, 8, 24);
      ring2Geo.rotateZ(Math.PI / 3);
      const ring2Mat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
      const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
      ring2.position.y = 3.6;
      group.add(ring2);

      // Dynamic Point Light illuminating water
      const pLight = new THREE.PointLight(0x38bdf8, 2.5, 22);
      pLight.position.y = 3.6;
      group.add(pLight);

      group.position.set(x, 2.5, z);
      this.scene.add(group);
      this.pickups.push({
        mesh: group,
        gem,
        ring1,
        ring2,
        light: pLight,
        x,
        z,
        type,
        radius: 6.5,
        alive: true,
        rotSpeed: 2.2
      });
    } else if (type === 'railgun_crate') {
      // Experimental Railgun Torpedo Weapon Ordnance Crate
      const crateGeo = new THREE.BoxGeometry(4.6, 2.6, 6.2);
      const crateMat = new THREE.MeshStandardMaterial({
        color: 0x09090b,
        metalness: 0.92,
        roughness: 0.2
      });
      const crate = new THREE.Mesh(crateGeo, crateMat);
      group.add(crate);

      // Cyan neon energy battery coils
      const coilGeo = new THREE.CylinderGeometry(0.35, 0.35, 5.8, 8);
      coilGeo.rotateX(Math.PI / 2);
      const coilMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });
      for (const cx of [-1.5, 0, 1.5]) {
        const coil = new THREE.Mesh(coilGeo, coilMat);
        coil.position.set(cx, 1.4, 0);
        group.add(coil);
      }

      // Energy field halo rings
      const haloGeo = new THREE.TorusGeometry(4.0, 0.2, 8, 20);
      haloGeo.rotateX(Math.PI / 2);
      const haloMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.position.y = 1.4;
      group.add(halo);

      // Cyan dynamic point light
      const pLight = new THREE.PointLight(0x00f2fe, 2.8, 25);
      pLight.position.y = 2.0;
      group.add(pLight);

      group.position.set(x, 2.5, z);
      this.scene.add(group);
      this.pickups.push({
        mesh: group,
        light: pLight,
        x,
        z,
        type,
        radius: 6.0,
        alive: true,
        rotSpeed: 2.5
      });
    } else if (type === 'emp_crate') {
      // Experimental EMP Shockwave Weapon Ordnance Canister Crate
      const crateGeo = new THREE.BoxGeometry(4.4, 2.6, 5.8);
      const crateMat = new THREE.MeshStandardMaterial({
        color: 0x2e1065,
        metalness: 0.88,
        roughness: 0.22
      });
      const crate = new THREE.Mesh(crateGeo, crateMat);
      group.add(crate);

      // Violet neon electromagnetic coils
      const coilGeo = new THREE.CylinderGeometry(0.35, 0.35, 5.4, 8);
      coilGeo.rotateX(Math.PI / 2);
      const coilMat = new THREE.MeshBasicMaterial({ color: 0xa855f7 });
      for (const cx of [-1.4, 0, 1.4]) {
        const coil = new THREE.Mesh(coilGeo, coilMat);
        coil.position.set(cx, 1.4, 0);
        group.add(coil);
      }

      // Violet electromagnetic torus halo ring
      const haloGeo = new THREE.TorusGeometry(3.8, 0.22, 8, 20);
      haloGeo.rotateX(Math.PI / 2);
      const haloMat = new THREE.MeshBasicMaterial({ color: 0xc084fc });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.position.y = 1.4;
      group.add(halo);

      // Violet point light
      const pLight = new THREE.PointLight(0xa855f7, 3.2, 28);
      pLight.position.y = 2.0;
      group.add(pLight);

      group.position.set(x, 2.5, z);
      this.scene.add(group);
      this.pickups.push({
        mesh: group,
        light: pLight,
        x,
        z,
        type,
        radius: 6.0,
        alive: true,
        rotSpeed: 2.5
      });
    } else if (type === 'casino_vault') {
      // High-Stakes Grand Poseidon Casino Diamond Vault Safe
      const safeGeo = new THREE.BoxGeometry(4.2, 4.2, 4.2);
      const safeMat = new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        metalness: 0.95,
        roughness: 0.15
      });
      const safe = new THREE.Mesh(safeGeo, safeMat);
      group.add(safe);

      // Gold reinforced trim & vault wheel
      const trimGeo = new THREE.TorusGeometry(1.4, 0.22, 8, 16);
      const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 });
      const wheel = new THREE.Mesh(trimGeo, goldMat);
      wheel.position.set(0, 0, 2.2);
      group.add(wheel);

      // Rotating Laser Security Rings (Magenta and Cyan)
      const ring1Geo = new THREE.TorusGeometry(4.8, 0.16, 8, 24);
      const ring1Mat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
      const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
      ring1.rotateX(Math.PI / 2);
      group.add(ring1);

      const ring2Geo = new THREE.TorusGeometry(5.4, 0.16, 8, 24);
      const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
      const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
      ring2.rotateY(Math.PI / 2);
      group.add(ring2);

      // Golden high-roller point light
      const pLight = new THREE.PointLight(0xf59e0b, 3.8, 30);
      pLight.position.y = 2.0;
      group.add(pLight);

      group.position.set(x, 4.5, z);
      this.scene.add(group);
      this.pickups.push({
        mesh: group,
        light: pLight,
        ring1,
        ring2,
        x,
        z,
        type,
        radius: 6.8,
        alive: true,
        rotSpeed: 2.0
      });
    } else {
      // Green medical cross repair kit
      const boxGeo = new THREE.BoxGeometry(4.2, 4.2, 4.2);
      const boxMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.3 });
      const box = new THREE.Mesh(boxGeo, boxMat);
      group.add(box);

      const crossGeo = new THREE.BoxGeometry(4.4, 1.2, 1.2);
      const crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const cross1 = new THREE.Mesh(crossGeo, crossMat);
      const cross2 = new THREE.Mesh(crossGeo, crossMat);
      cross2.rotation.z = Math.PI / 2;
      group.add(cross1);
      group.add(cross2);
      group.position.set(x, 2.5, z);
      this.scene.add(group);
      this.pickups.push({ mesh: group, x, z, type, radius: 5.5, alive: true, rotSpeed: 1.8 });
    }
  }

  addPickup(x, z, type = 'contraband') {
    return this._addPickup(x, z, type);
  }

  spawnDiamondCache(x, z) {
    return this._addPickup(x, z, 'diamond_cache');
  }

  spawnRailgunCrate(x, z) {
    return this._addPickup(x, z, 'railgun_crate');
  }

  spawnEMPCrate(x, z) {
    return this._addPickup(x, z, 'emp_crate');
  }

  spawnCasinoVault(x, z) {
    return this._addPickup(x, z, 'casino_vault');
  }

  _addIsland(x, z, radius, color, height = 4, addPalmTrees = false) {
    // Sand beach base
    const sandGeo = new THREE.CylinderGeometry(radius * 0.95, radius * 1.08, height * 0.5, 20);
    const sandMat = new THREE.MeshStandardMaterial({ color: 0xfde047, roughness: 0.9, flatShading: true });
    const sand = new THREE.Mesh(sandGeo, sandMat);
    sand.position.set(x, height * 0.25 - 0.2, z);
    this.scene.add(sand);

    // Upper grassy/rocky terrain
    const geo = new THREE.CylinderGeometry(radius * 0.85, radius * 0.95, height, 20);
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.8, flatShading: true });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, height / 2, z);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    this.scene.add(mesh);

    this.colliders.push({ x, z, radius: radius * 0.94, type: 'island', mesh });

    if (addPalmTrees) {
      const treeCount = Math.floor(radius / 20);
      for (let i = 0; i < treeCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * (radius * 0.65);
        this._addPalmTree(x + Math.cos(angle) * dist, z + Math.sin(angle) * dist, height);
      }
    }
  }

  _addPalmTree(x, z, baseY) {
    const trunkGeo = new THREE.CylinderGeometry(0.7, 1.3, 16, 6);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(x, baseY + 7, z);
    trunk.rotation.z = (Math.random() - 0.5) * 0.28;
    trunk.rotation.x = (Math.random() - 0.5) * 0.28;
    trunk.castShadow = true;
    this.scene.add(trunk);

    const leavesGeo = new THREE.ConeGeometry(8.5, 6, 6);
    const leavesMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.7 });
    const leaves = new THREE.Mesh(leavesGeo, leavesMat);
    leaves.position.set(x, baseY + 16, z);
    leaves.castShadow = true;
    this.scene.add(leaves);
  }

  _addRockPillar(x, z, radius, height) {
    const geo = new THREE.ConeGeometry(radius, height, 7);
    const mat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.9, flatShading: true });
    const rock = new THREE.Mesh(geo, mat);
    rock.position.set(x, height / 2 - 2, z);
    rock.rotation.y = Math.random() * Math.PI;
    rock.castShadow = true;
    this.scene.add(rock);
    this.colliders.push({ x, z, radius: radius * 0.85, type: 'rock' });
  }

  _addSeawall(x, z, lengthX, lengthZ, rotY = 0) {
    const geo = new THREE.BoxGeometry(lengthX, 10, lengthZ);
    const mat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.8 });
    const wall = new THREE.Mesh(geo, mat);
    wall.position.set(x, 4, z);
    wall.rotation.y = rotY;
    wall.castShadow = true;
    this.scene.add(wall);
    const maxR = Math.max(lengthX, lengthZ) / 2;
    this.colliders.push({ x, z, radius: maxR * 0.82, type: 'seawall' });
  }

  _addDockPier(x, z, length, width, rotY = 0) {
    const geo = new THREE.BoxGeometry(length, 2.4, width);
    const mat = new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.85 });
    const pier = new THREE.Mesh(geo, mat);
    pier.position.set(x, 1.2, z);
    pier.rotation.y = rotY;
    this.scene.add(pier);
    this.colliders.push({ x, z, radius: (length + width) / 4, type: 'dock' });
  }

  _addLighthouse(x, z, height, lightColor) {
    const towerGeo = new THREE.CylinderGeometry(5.5, 9.5, height, 12);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
    const tower = new THREE.Mesh(towerGeo, towerMat);
    tower.position.set(x, height / 2, z);
    this.scene.add(tower);

    const capGeo = new THREE.ConeGeometry(7, 6.5, 12);
    const capMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
    const cap = new THREE.Mesh(capGeo, capMat);
    cap.position.set(x, height + 3.2, z);
    this.scene.add(cap);

    const beamGeo = new THREE.ConeGeometry(26, 140, 16, 1, true);
    beamGeo.rotateX(Math.PI / 2);
    beamGeo.translate(0, 0, 70);
    const beamMat = new THREE.MeshBasicMaterial({
      color: lightColor,
      transparent: true,
      opacity: 0.4,
      side: THREE.DoubleSide
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(x, height - 2, z);
    this.scene.add(beam);

    this.searchlights.push({ mesh: beam, angle: Math.random() * Math.PI * 2, speed: 1.3 });
    this.colliders.push({ x, z, radius: 11, type: 'building' });
  }

  _addStuntRamp(x, z, width, length, angle) {
    const rampGeo = new THREE.BoxGeometry(width, 1.4, length);
    const rampMat = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      roughness: 0.5,
      metalness: 0.2
    });
    const ramp = new THREE.Mesh(rampGeo, rampMat);
    ramp.position.set(x, 3.8, z);
    ramp.rotation.y = angle;
    ramp.rotation.x = 0.33;
    this.scene.add(ramp);
    this.ramps.push({ x, z, width, length, angle, mesh: ramp });
  }

  _addExplosiveBarrel(x, z) {
    const geo = new THREE.CylinderGeometry(2.5, 2.5, 6, 10);
    const mat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.3, metalness: 0.7 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, 2.0, z);
    this.scene.add(mesh);
    this.barrels.push({ x, z, radius: 3.8, health: 15, mesh, alive: true });
  }

  _addSeaMine(x, z) {
    const geo = new THREE.SphereGeometry(3.0, 8, 8);
    const mat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.8 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, 1.4, z);

    for (let i = 0; i < 6; i++) {
      const spikeGeo = new THREE.ConeGeometry(0.55, 2.4, 4);
      const spikeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const spike = new THREE.Mesh(spikeGeo, spikeMat);
      spike.rotation.x = (i / 6) * Math.PI * 2;
      mesh.add(spike);
    }

    this.scene.add(mesh);
    this.mines.push({ x, z, radius: 4.2, alive: true, mesh });
  }

  _addBuoy(x, z, color) {
    const buoyGeo = new THREE.CylinderGeometry(1.5, 2.6, 6.5, 8);
    const buoyMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.4 });
    const mesh = new THREE.Mesh(buoyGeo, buoyMat);
    mesh.position.set(x, 1.6, z);

    const lightGeo = new THREE.SphereGeometry(0.9, 8, 8);
    const lightMat = new THREE.MeshBasicMaterial({ color: color });
    const lightMesh = new THREE.Mesh(lightGeo, lightMat);
    lightMesh.position.y = 4.2;
    mesh.add(lightMesh);

    this.scene.add(mesh);
    this.buoys.push({ mesh, x, z, baseY: 1.6, phase: Math.random() * Math.PI * 2 });
  }

  _addCargoShip(x, z, rotY) {
    const shipGroup = new THREE.Group();

    // 1. Massive Hull
    const hullGeo = new THREE.BoxGeometry(46, 16, 175);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.75, metalness: 0.2 });
    const ship = new THREE.Mesh(hullGeo, hullMat);
    ship.position.y = 7;
    ship.castShadow = true;
    shipGroup.add(ship);

    // 2. Multi-tier Deck Bridge Tower at stern
    const bridgeGeo = new THREE.BoxGeometry(36, 26, 36);
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, 20, -52);
    bridge.castShadow = true;
    shipGroup.add(bridge);

    // Radar antenna on mast
    const mastGeo = new THREE.CylinderGeometry(0.5, 0.5, 14);
    const mast = new THREE.Mesh(mastGeo, hullMat);
    mast.position.set(0, 36, -52);
    shipGroup.add(mast);

    // 3. Colorful Shipping Container Stacks along the deck
    const containerColors = [0xef4444, 0x0284c7, 0xf59e0b, 0x10b981, 0x8b5cf6];
    for (let row = -1; row <= 1; row++) {
      for (let bay = 0; bay < 4; bay++) {
        const cGeo = new THREE.BoxGeometry(10, 8, 20);
        const col = containerColors[(bay + Math.abs(row)) % containerColors.length];
        const cMat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.6, metalness: 0.3 });
        const cMesh = new THREE.Mesh(cGeo, cMat);
        cMesh.position.set(row * 12, 16, -10 + bay * 24);
        cMesh.castShadow = true;
        shipGroup.add(cMesh);
      }
    }

    // 4. Lowered Stern Stunt Ramp leading from water onto ship
    const rampWidth = 24;
    const rampLength = 52;
    const rampGeo = new THREE.BoxGeometry(rampWidth, 1.8, rampLength);
    const rampMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.5, metalness: 0.3 });
    const rampMesh = new THREE.Mesh(rampGeo, rampMat);
    rampMesh.position.set(0, 4.5, -88);
    rampMesh.rotation.x = 0.32;
    rampMesh.castShadow = true;
    shipGroup.add(rampMesh);

    // Position entire group in world
    shipGroup.position.set(x, 0, z);
    shipGroup.rotation.y = rotY;
    this.scene.add(shipGroup);

    // Register ramp in world coordinates
    const cos = Math.cos(rotY);
    const sin = Math.sin(rotY);
    const rx = x - sin * -88;
    const rz = z + cos * -88;
    this.ramps.push({
      x: rx,
      z: rz,
      width: rampWidth,
      length: rampLength,
      angle: rotY,
      mesh: rampMesh,
      isFreighterRamp: true
    });

    this.colliders.push({ x, z, radius: 82, type: 'ship', group: shipGroup });
    return shipGroup;
  }

  _createMovingFreighter() {
    // Moving 165m container ship that cruises the deep outer channel
    const group = new THREE.Group();

    const hullGeo = new THREE.BoxGeometry(42, 15, 165);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7, metalness: 0.3 });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 6.5;
    hull.castShadow = true;
    group.add(hull);

    // Bridge Tower
    const bridgeGeo = new THREE.BoxGeometry(32, 22, 32);
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.5 });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, 18, -46);
    group.add(bridge);

    // Shipping containers on moving deck
    const cols = [0x06b6d4, 0xf97316, 0xef4444, 0x10b981];
    for (let r = -1; r <= 1; r += 2) {
      for (let b = 0; b < 3; b++) {
        const cGeo = new THREE.BoxGeometry(10, 7.5, 22);
        const colIdx = Math.abs(b + (r < 0 ? 0 : 1)) % cols.length;
        const cMesh = new THREE.Mesh(cGeo, new THREE.MeshStandardMaterial({ color: cols[colIdx] }));
        cMesh.position.set(r * 11, 15, -6 + b * 26);
        group.add(cMesh);
      }
    }

    // Moving stern ramp
    const rampWidth = 22;
    const rampLength = 48;
    const rampGeo = new THREE.BoxGeometry(rampWidth, 1.6, rampLength);
    const rampMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });
    const ramp = new THREE.Mesh(rampGeo, rampMat);
    ramp.position.set(0, 4.0, -82);
    ramp.rotation.x = 0.30;
    group.add(ramp);

    this.scene.add(group);

    // Waypoints for circuit patrol in the deep waterway
    const waypoints = [
      { x: -550, z: 250 },
      { x: -150, z: -350 },
      { x: 500, z: -320 },
      { x: 600, z: 350 },
      { x: 100, z: 580 },
      { x: -450, z: 500 }
    ];

    const rampObj = {
      x: 0,
      z: 0,
      width: rampWidth,
      length: rampLength,
      angle: 0,
      mesh: ramp,
      isFreighterRamp: true
    };
    this.ramps.push(rampObj);

    const colliderObj = {
      x: waypoints[0].x,
      z: waypoints[0].z,
      radius: 76,
      type: 'moving_ship'
    };
    this.colliders.push(colliderObj);

    this.movingFreighter = {
      mesh: group,
      x: waypoints[0].x,
      z: waypoints[0].z,
      speed: 13.5, // ~14 knots cruising speed
      angle: 0,
      waypoints,
      currentWp: 0,
      rampObj,
      colliderObj
    };
  }

  _updateMovingFreighter(dt) {
    const f = this.movingFreighter;
    if (!f) return;

    const targetWp = f.waypoints[f.currentWp];
    const dx = targetWp.x - f.x;
    const dz = targetWp.z - f.z;
    const dist = Math.sqrt(dx * dx + dz * dz);

    if (dist < 40) {
      f.currentWp = (f.currentWp + 1) % f.waypoints.length;
    } else {
      const targetAngle = Math.atan2(dx, dz);
      let diff = targetAngle - f.angle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;
      f.angle += diff * Math.min(1.0, dt * 0.8);

      f.x += Math.sin(f.angle) * f.speed * dt;
      f.z += Math.cos(f.angle) * f.speed * dt;
    }

    f.mesh.position.set(f.x, 0, f.z);
    f.mesh.rotation.y = f.angle;

    // Update ramp world coordinates
    const sin = Math.sin(f.angle);
    const cos = Math.cos(f.angle);
    f.rampObj.x = f.x - sin * -82;
    f.rampObj.z = f.z + cos * -82;
    f.rampObj.angle = f.angle;

    // Update collider position
    f.colliderObj.x = f.x;
    f.colliderObj.z = f.z;
  }

  _addShipwreck(x, z, rotY) {
    const wreckGeo = new THREE.BoxGeometry(34, 18, 100);
    const wreckMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.95 });
    const wreck = new THREE.Mesh(wreckGeo, wreckMat);
    wreck.position.set(x, 2.5, z);
    wreck.rotation.y = rotY;
    wreck.rotation.z = 0.38;
    this.scene.add(wreck);
    this.colliders.push({ x, z, radius: 50, type: 'shipwreck' });
  }

  _createSafeHaven() {
    const sh = this.safeHaven;
    this._addIsland(sh.x, sh.z, sh.radius, 0x10b981, 4.0, true);

    const ringGeo = new THREE.TorusGeometry(sh.radius * 0.72, 4.0, 12, 32);
    ringGeo.rotateX(Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x22c55e,
      transparent: true,
      opacity: 0.8
    });
    const beacon = new THREE.Mesh(ringGeo, ringMat);
    beacon.position.set(sh.x, 2.5, sh.z);
    this.scene.add(beacon);
    this.safeHavenBeacon = beacon;
  }

  _createDestructibles() {
    // Breakable wooden crate clusters, tire stacks, and warning floats along waterways
    const crateSpawns = [
      { x: -160, z: -120, count: 4, color: 0xd97706, name: 'CARGO CRATE' },
      { x: 210, z: -180, count: 5, color: 0x0ea5e9, name: 'SMUGGLER CACHE' },
      { x: -350, z: 80, count: 6, color: 0xf59e0b, name: 'SUPPLY BARRIER' },
      { x: 120, z: 320, count: 4, color: 0xef4444, name: 'EXPLOSIVE DRUM', isExplosive: true },
      { x: 420, z: -450, count: 5, color: 0x10b981, name: 'CONTRABAND CRATE' },
      { x: -550, z: -220, count: 6, color: 0x8b5cf6, name: 'PIRATE LOOT BOX' },
      { x: 620, z: 410, count: 5, color: 0xf97316, name: 'DOCK BARRICADE' },
      { x: -80, z: 520, count: 4, color: 0x06b6d4, name: 'WATER CACHE' },
      { x: 310, z: 680, count: 6, color: 0xef4444, name: 'FUEL DRUMS', isExplosive: true }
    ];

    const boxGeo = new THREE.BoxGeometry(3.2, 3.2, 3.2);
    for (const cluster of crateSpawns) {
      for (let i = 0; i < cluster.count; i++) {
        const cx = cluster.x + (Math.random() - 0.5) * 16;
        const cz = cluster.z + (Math.random() - 0.5) * 16;
        const mat = new THREE.MeshStandardMaterial({
          color: cluster.color,
          roughness: 0.6,
          metalness: cluster.isExplosive ? 0.6 : 0.2
        });
        const mesh = new THREE.Mesh(boxGeo, mat);
        mesh.position.set(cx, 1.6, cz);
        mesh.rotation.y = Math.random() * Math.PI;
        mesh.castShadow = true;
        this.scene.add(mesh);

        this.destructibles.push({
          mesh,
          x: cx,
          z: cz,
          radius: 3.2,
          color: cluster.color,
          name: cluster.name,
          score: cluster.isExplosive ? 450 : 250,
          isExplosive: !!cluster.isExplosive,
          alive: true
        });
      }
    }
  }

  _createNavalMinefields() {
    // WWII-style Buoyant Horned Naval Contact Minefields across Skull Cove & Mangrove channels
    const mineSpawns = [
      // Skull Cove pirate ambush slalom corridor (14 mines)
      { x: 730, z: -500 }, { x: 780, z: -530 }, { x: 740, z: -570 },
      { x: 820, z: -580 }, { x: 760, z: -620 }, { x: 840, z: -640 },
      { x: 790, z: -680 }, { x: 860, z: -700 }, { x: 820, z: -740 },
      { x: 890, z: -760 }, { x: 940, z: -720 }, { x: 910, z: -660 },
      { x: 960, z: -620 }, { x: 880, z: -580 },

      // Mangrove Canals south entrance chokepoint (6 mines)
      { x: -210, z: 180 }, { x: -170, z: 210 }, { x: -230, z: 240 },
      { x: -160, z: 270 }, { x: -220, z: 300 }, { x: -180, z: 330 }
    ];

    const sphereGeo = new THREE.SphereGeometry(1.9, 12, 10);
    const sphereMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.85,
      roughness: 0.25
    });

    const weldGeo = new THREE.TorusGeometry(1.92, 0.10, 6, 20);
    const weldMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });

    const hornGeo = new THREE.ConeGeometry(0.28, 1.2, 6);
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9, roughness: 0.2 });

    const chainGeo = new THREE.CylinderGeometry(0.12, 0.12, 12, 4);
    const chainMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    const beaconGeo = new THREE.SphereGeometry(0.35, 6, 6);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.9 });

    for (const pos of mineSpawns) {
      const group = new THREE.Group();

      // Main spherical mine casing
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      group.add(sphere);

      // Welded equator flange
      const weld = new THREE.Mesh(weldGeo, weldMat);
      weld.rotation.x = Math.PI / 2;
      group.add(weld);

      // 6 Detonator chemical horns protruding radially
      const hornOffsets = [
        { pos: [0, 2.2, 0], rot: [0, 0, 0] },
        { pos: [0, -2.2, 0], rot: [Math.PI, 0, 0] },
        { pos: [2.2, 0, 0], rot: [0, 0, -Math.PI / 2] },
        { pos: [-2.2, 0, 0], rot: [0, 0, Math.PI / 2] },
        { pos: [0, 0, 2.2], rot: [Math.PI / 2, 0, 0] },
        { pos: [0, 0, -2.2], rot: [-Math.PI / 2, 0, 0] }
      ];
      for (const h of hornOffsets) {
        const horn = new THREE.Mesh(hornGeo, hornMat);
        horn.position.set(h.pos[0], h.pos[1], h.pos[2]);
        horn.rotation.set(h.rot[0], h.rot[1], h.rot[2]);
        group.add(horn);
      }

      // Mooring anchor chain going down into seabed
      const chain = new THREE.Mesh(chainGeo, chainMat);
      chain.position.set(0, -6.0, 0);
      group.add(chain);

      // Top red proximity warning beacon
      const beacon = new THREE.Mesh(beaconGeo, beaconMat.clone());
      beacon.position.set(0, 2.8, 0);
      group.add(beacon);

      group.position.set(pos.x, 1.2, pos.z);
      this.scene.add(group);

      this.mines.push({
        mesh: group,
        beaconMesh: beacon,
        x: pos.x,
        z: pos.z,
        radius: 2.8,
        alive: true,
        baseY: 1.2,
        phase: Math.random() * Math.PI * 2
      });
    }
  }

  detonateMine(mine, attacker = null, isChain = false) {
    if (!mine || !mine.alive) return;
    mine.alive = false;
    if (mine.mesh) mine.mesh.visible = false;

    // Voxel debris explosion
    this.spawnVoxelCrumbles(mine.x, 2.5, mine.z, 28, 0x1e293b);
    this.spawnVoxelCrumbles(mine.x, 2.5, mine.z, 20, 0xef4444);
    this.spawnVoxelCrumbles(mine.x, 2.5, mine.z, 16, 0xf59e0b);

    soundManager.playExplosion(0.9, 1.2);
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.55);

    // Damage boats within blast radius (28m)
    if (window.game && window.game.player && window.game.player.alive) {
      const p = window.game.player;
      const pDist = Math.hypot(p.position.x - mine.x, p.position.z - mine.z);
      if (pDist < 28) {
        const falloff = 1.0 - pDist / 28;
        p.takeDamage(95 * falloff);
      }
    }

    if (window.game && window.game.factionManager) {
      for (const enemy of window.game.factionManager.enemies) {
        if (enemy.alive) {
          const eDist = Math.hypot(enemy.position.x - mine.x, enemy.position.z - mine.z);
          if (eDist < 28) {
            const falloff = 1.0 - eDist / 28;
            enemy.takeDamage(120 * falloff, attacker);
          }
        }
      }
    }

    // Chain reaction: check adjacent mines within 26m
    for (const other of this.mines) {
      if (other.alive && other !== mine) {
        const dist = Math.hypot(other.x - mine.x, other.z - mine.z);
        if (dist < 26) {
          setTimeout(() => {
            if (other.alive) this.detonateMine(other, attacker, true);
          }, 110);
        }
      }
    }

    if (isChain && window.game && window.game.player && window.game.player.triggerStunt) {
      window.game.player.triggerStunt('💥 NAVAL MINE CHAIN DETONATION!', 600);
    }
  }

  checkMines(x, z, boatRadius = 4.5, attacker = null) {
    for (const mine of this.mines) {
      if (mine.alive) {
        const dx = x - mine.x;
        const dz = z - mine.z;
        if (dx * dx + dz * dz < (mine.radius + boatRadius) * (mine.radius + boatRadius)) {
          this.detonateMine(mine, attacker);
          return true;
        }
      }
    }
    return false;
  }

  _createOilRig() {
    const cfg = CONFIG.OIL_RIG || {
      x: 350,
      z: -850,
      deckWidth: 58,
      deckLength: 48,
      deckHeight: 14,
      tankCount: 4,
      tankHealth: 120,
      tankBlastRadius: 42,
      tankBlastDamage: 130,
      stuntScore: 1100
    };

    const group = new THREE.Group();
    const cx = cfg.x;
    const cz = cfg.z;

    // 1. Four Heavy Steel Lattice Jacket Legs
    const legOffsets = [
      { x: -22, z: -18 },
      { x: 22, z: -18 },
      { x: -22, z: 18 },
      { x: 22, z: 18 }
    ];

    const legGeo = new THREE.CylinderGeometry(2.6, 3.8, 36, 8);
    const legMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.82,
      roughness: 0.28
    });

    const braceMat = new THREE.MeshStandardMaterial({
      color: 0x78716c,
      metalness: 0.85,
      roughness: 0.3
    });

    for (const off of legOffsets) {
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(off.x, 2, off.z);
      group.add(leg);

      // Register physics colliders for each jacket leg so boats bounce off them
      this.colliders.push({
        x: cx + off.x,
        z: cz + off.z,
        radius: 4.5,
        type: 'oilrig_leg'
      });
    }

    // Diagonal structural cross-bracing tubes connecting legs
    const braceGeo = new THREE.CylinderGeometry(0.5, 0.5, 46, 6);
    braceGeo.rotateZ(Math.PI / 4);
    const brace1 = new THREE.Mesh(braceGeo, braceMat);
    brace1.position.set(0, 0, -18);
    group.add(brace1);

    const brace2 = new THREE.Mesh(braceGeo, braceMat);
    brace2.position.set(0, 0, 18);
    group.add(brace2);

    // 2. Main Grated Industrial Platform Deck
    const deckGeo = new THREE.BoxGeometry(cfg.deckWidth, 3.2, cfg.deckLength);
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.85,
      roughness: 0.3
    });
    const deck = new THREE.Mesh(deckGeo, deckMat);
    deck.position.set(0, cfg.deckHeight, 0);
    group.add(deck);

    // Yellow safety perimeter railings
    const railGeo = new THREE.BoxGeometry(cfg.deckWidth + 1.0, 1.4, cfg.deckLength + 1.0);
    const railMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, wireframe: true });
    const rail = new THREE.Mesh(railGeo, railMat);
    rail.position.set(0, cfg.deckHeight + 2.2, 0);
    group.add(rail);

    // 3. Cantilever Helipad Deck (Extends off southwest corner)
    const helipadGeo = new THREE.CylinderGeometry(14, 14, 1.8, 8);
    const helipadMat = new THREE.MeshStandardMaterial({ color: 0x065f46, roughness: 0.6 });
    const helipad = new THREE.Mesh(helipadGeo, helipadMat);
    helipad.position.set(-28, cfg.deckHeight + 3.2, 22);
    group.add(helipad);

    // Painted yellow 'H' landing ring
    const hRingGeo = new THREE.RingGeometry(8, 10, 16);
    hRingGeo.rotateX(-Math.PI / 2);
    const hRingMat = new THREE.MeshBasicMaterial({ color: 0xfde047, side: THREE.DoubleSide });
    const hRing = new THREE.Mesh(hRingGeo, hRingMat);
    hRing.position.set(-28, cfg.deckHeight + 4.15, 22);
    group.add(hRing);

    // Helipad green perimeter LED beacons
    for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 4) {
      const bGeo = new THREE.SphereGeometry(0.4, 6, 6);
      const bMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
      const bMesh = new THREE.Mesh(bGeo, bMat);
      bMesh.position.set(-28 + Math.cos(angle) * 13, cfg.deckHeight + 4.3, 22 + Math.sin(angle) * 13);
      group.add(bMesh);
    }

    // 4. Towering Central Drilling Derrick Mast
    const derrickGeo = new THREE.CylinderGeometry(2.5, 9.0, 36, 4);
    derrickGeo.rotateY(Math.PI / 4);
    const derrickMat = new THREE.MeshStandardMaterial({ color: 0x475569, wireframe: true });
    const derrick = new THREE.Mesh(derrickGeo, derrickMat);
    derrick.position.set(0, cfg.deckHeight + 19.5, 0);
    group.add(derrick);

    // Central derrick red aviation warning strobe
    const derrickBeaconGeo = new THREE.SphereGeometry(0.8, 8, 8);
    const derrickBeaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const derrickBeacon = new THREE.Mesh(derrickBeaconGeo, derrickBeaconMat);
    derrickBeacon.position.set(0, cfg.deckHeight + 38, 0);
    group.add(derrickBeacon);

    const derrickLight = new THREE.PointLight(0xef4444, 2.0, 45);
    derrickLight.position.set(0, cfg.deckHeight + 38, 0);
    group.add(derrickLight);

    // 5. Flare Boom & Natural Gas Flame
    const boomGeo = new THREE.CylinderGeometry(0.6, 0.8, 28, 6);
    boomGeo.rotateZ(Math.PI / 4);
    boomGeo.rotateY(-Math.PI / 4);
    const boomMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9 });
    const boom = new THREE.Mesh(boomGeo, boomMat);
    boom.position.set(28, cfg.deckHeight + 10, -24);
    group.add(boom);

    // Flickering natural gas flare flame mesh at boom tip
    const flameGeo = new THREE.ConeGeometry(2.4, 7.5, 8);
    flameGeo.rotateX(-Math.PI / 4);
    flameGeo.rotateY(Math.PI / 4);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.95
    });
    const flareMesh = new THREE.Mesh(flameGeo, flameMat);
    flareMesh.position.set(40, cfg.deckHeight + 21, -34);
    group.add(flareMesh);

    const flareLight = new THREE.PointLight(0xf97316, 3.2, 75);
    flareLight.position.set(40, cfg.deckHeight + 22, -34);
    group.add(flareLight);

    // 6. Four Pressurized Chemical Fuel Storage Tanks
    const tanks = [];
    const tankGeo = new THREE.CylinderGeometry(4.2, 4.2, 7.2, 16);
    const tankBodyMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.35, metalness: 0.4 });
    const tankStripeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const tankCapMat = new THREE.MeshStandardMaterial({ color: 0x09090b, metalness: 0.85 });

    const tankOffsets = [
      { x: -16, z: -10 },
      { x: -16, z: 10 },
      { x: 10, z: -12 },
      { x: 10, z: 12 }
    ];

    for (let i = 0; i < tankOffsets.length; i++) {
      const toff = tankOffsets[i];
      const tGroup = new THREE.Group();

      const tBody = new THREE.Mesh(tankGeo, tankBodyMat);
      tGroup.add(tBody);

      // Red hazard band
      const stripeGeo = new THREE.CylinderGeometry(4.26, 4.26, 2.0, 16);
      const tStripe = new THREE.Mesh(stripeGeo, tankStripeMat);
      tGroup.add(tStripe);

      // Top industrial pressure cap
      const capGeo = new THREE.CylinderGeometry(1.8, 1.8, 1.2, 10);
      const tCap = new THREE.Mesh(capGeo, tankCapMat);
      tCap.position.y = 4.2;
      tGroup.add(tCap);

      const tankWorldX = cx + toff.x;
      const tankWorldZ = cz + toff.z;
      const tankWorldY = cfg.deckHeight + 5.2;
      tGroup.position.set(toff.x, cfg.deckHeight + 5.2, toff.z);
      group.add(tGroup);

      tanks.push({
        id: i,
        mesh: tGroup,
        x: tankWorldX,
        y: tankWorldY,
        z: tankWorldZ,
        radius: 4.6,
        health: cfg.tankHealth || 120,
        maxHealth: cfg.tankHealth || 120,
        alive: true
      });
    }

    // 7. Heavy Gantry Dock Crane & Suspended Shipping Container
    const craneTowerGeo = new THREE.BoxGeometry(3.0, 14.0, 3.0);
    const craneMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.7, roughness: 0.3 });
    const craneTower = new THREE.Mesh(craneTowerGeo, craneMat);
    craneTower.position.set(20, cfg.deckHeight + 8, 14);
    group.add(craneTower);

    const craneJibGeo = new THREE.BoxGeometry(22.0, 2.0, 2.0);
    const craneJib = new THREE.Mesh(craneJibGeo, craneMat);
    craneJib.position.set(28, cfg.deckHeight + 15, 14);
    group.add(craneJib);

    // Container dangling over water
    const containerGeo = new THREE.BoxGeometry(6.5, 6.0, 14.0);
    const containerMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.5 });
    const container = new THREE.Mesh(containerGeo, containerMat);
    container.position.set(38, 7.5, 14);
    group.add(container);

    // Crane cables
    const cableGeo = new THREE.CylinderGeometry(0.08, 0.08, 8.0, 4);
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x18181b });
    const cable1 = new THREE.Mesh(cableGeo, cableMat);
    cable1.position.set(38, 11.5, 14);
    group.add(cable1);

    group.position.set(cx, 0, cz);
    this.scene.add(group);

    // 8. Stunt Jump Ramps along Water Approaches to the Rig
    const rampWidth = 20;
    const rampLength = 36;
    const rampGeo = new THREE.BoxGeometry(rampWidth, 1.8, rampLength);
    const rampMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });

    // Ramp 1: South approach (launches north through the jacket legs)
    const ramp1Mesh = new THREE.Mesh(rampGeo, rampMat);
    ramp1Mesh.position.set(cx, 3.5, cz + 58);
    ramp1Mesh.rotation.x = -0.32;
    this.scene.add(ramp1Mesh);

    this.ramps.push({
      x: cx,
      z: cz + 58,
      width: rampWidth,
      length: rampLength,
      angle: 0,
      mesh: ramp1Mesh,
      isOilRigRamp: true
    });

    // Ramp 2: East approach (launches west toward the rig)
    const ramp2Mesh = new THREE.Mesh(rampGeo, rampMat);
    ramp2Mesh.position.set(cx + 58, 3.5, cz);
    ramp2Mesh.rotation.z = 0.32;
    this.scene.add(ramp2Mesh);

    this.ramps.push({
      x: cx + 58,
      z: cz,
      width: rampWidth,
      length: rampLength,
      angle: Math.PI / 2,
      mesh: ramp2Mesh,
      isOilRigRamp: true
    });

    this.oilRig = {
      mesh: group,
      x: cx,
      z: cz,
      flareMesh,
      flareLight,
      derrickBeacon,
      derrickLight,
      tanks
    };
  }

  damageFuelTank(tank, damage, attacker = null) {
    if (!tank || !tank.alive) return;
    tank.health -= damage;
    if (tank.health <= 0) {
      tank.alive = false;
      if (tank.mesh) tank.mesh.visible = false;

      // Colossal Multi-Stage Explosion Voxel Cascade
      this.spawnVoxelCrumbles(tank.x, tank.y, tank.z, 40, 0xf1f5f9);
      this.spawnVoxelCrumbles(tank.x, tank.y, tank.z, 36, 0xef4444);
      this.spawnVoxelCrumbles(tank.x, tank.y, tank.z, 32, 0xf59e0b);
      this.spawnVoxelCrumbles(tank.x, tank.y, tank.z, 28, 0xf97316);

      soundManager.playExplosion(1.0, 1.4);
      if (window.game && window.game.addTrauma) window.game.addTrauma(0.85);

      // Area-of-effect blast damage (42m radius)
      const blastRadius = CONFIG.OIL_RIG.tankBlastRadius || 42;
      const blastDamage = CONFIG.OIL_RIG.tankBlastDamage || 130;

      if (window.game && window.game.player && window.game.player.alive) {
        const p = window.game.player;
        const pDist = Math.hypot(p.position.x - tank.x, p.position.z - tank.z);
        if (pDist < blastRadius) {
          p.takeDamage(blastDamage * (1.0 - pDist / blastRadius));
        }
      }

      if (window.game && window.game.factionManager) {
        for (const enemy of window.game.factionManager.enemies) {
          if (enemy.alive) {
            const eDist = Math.hypot(enemy.position.x - tank.x, enemy.position.z - tank.z);
            if (eDist < blastRadius) {
              enemy.takeDamage(blastDamage * 1.2 * (1.0 - eDist / blastRadius), attacker);
            }
          }
        }
      }

      // Stunt for player
      if (window.game && window.game.player && window.game.player.triggerStunt) {
        window.game.player.triggerStunt('💥 REFINERY TANK ANNIHILATED!', 750, 4.0);
      }

      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '🚨 [HAZMAT DISPATCH]: 10-99! REFINERY TANK DETONATED! MASSIVE INFERNO AT OIL RIG!';
        dispatch.style.color = '#ef4444';
      }

      // Chain reaction to adjacent alive fuel tanks within 26m
      if (this.oilRig && this.oilRig.tanks) {
        for (const other of this.oilRig.tanks) {
          if (other.alive && other !== tank) {
            const d = Math.hypot(other.x - tank.x, other.z - tank.z);
            if (d < 26) {
              setTimeout(() => {
                if (other.alive) this.damageFuelTank(other, 999, attacker);
              }, 180);
            }
          }
        }
      }
    }
  }

  checkOilRigTanks(projX, projZ, projRadius = 1.4, damage = 25, attacker = null) {
    if (!this.oilRig || !this.oilRig.tanks) return false;
    for (const tank of this.oilRig.tanks) {
      if (tank.alive) {
        const dx = projX - tank.x;
        const dz = projZ - tank.z;
        if (dx * dx + dz * dz < (tank.radius + projRadius) * (tank.radius + projRadius)) {
          this.damageFuelTank(tank, damage, attacker);
          return true;
        }
      }
    }
    return false;
  }

  _createSubmarinePen() {
    const cfg = CONFIG.SUB_PEN || {
      x: -920,
      z: 120,
      width: 44,
      length: 90,
      height: 26,
      subLength: 76
    };
    const cx = cfg.x;
    const cz = cfg.z;

    const group = new THREE.Group();

    // 1. Natural Sea Cliff Mountain Framing
    const rockMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.95,
      metalness: 0.15,
      flatShading: true
    });
    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.85,
      metalness: 0.25
    });
    const darkSteelMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.8
    });

    // Left cliff bastion
    const leftCliffGeo = new THREE.BoxGeometry(32, 42, 110);
    const leftCliff = new THREE.Mesh(leftCliffGeo, rockMat);
    leftCliff.position.set(-34, 21, -5);
    leftCliff.castShadow = true;
    leftCliff.receiveShadow = true;
    group.add(leftCliff);

    // Right cliff bastion
    const rightCliffGeo = new THREE.BoxGeometry(32, 42, 110);
    const rightCliff = new THREE.Mesh(rightCliffGeo, rockMat);
    rightCliff.position.set(34, 21, -5);
    rightCliff.castShadow = true;
    rightCliff.receiveShadow = true;
    group.add(rightCliff);

    // Rear mountain wall
    const rearCliffGeo = new THREE.BoxGeometry(96, 46, 26);
    const rearCliff = new THREE.Mesh(rearCliffGeo, rockMat);
    rearCliff.position.set(0, 23, -56);
    rearCliff.castShadow = true;
    group.add(rearCliff);

    // 2. Reinforced Cavern Bunker Roof & Portal Arch
    const roofGeo = new THREE.BoxGeometry(cfg.width + 12, 6, cfg.length + 8);
    const roofMesh = new THREE.Mesh(roofGeo, concreteMat);
    roofMesh.position.set(0, cfg.height, -5);
    roofMesh.castShadow = true;
    group.add(roofMesh);

    // Heavy Portal Lintel Arch
    const lintelGeo = new THREE.BoxGeometry(cfg.width + 10, 7, 10);
    const lintel = new THREE.Mesh(lintelGeo, concreteMat);
    lintel.position.set(0, cfg.height - 4, 46);
    group.add(lintel);

    // Hazard chevron striping along portal lintel
    const stripeGeo = new THREE.BoxGeometry(cfg.width + 8, 1.2, 0.4);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(0, cfg.height - 4, 51.2);
    group.add(stripe);

    // Portal support pillars
    const pillarGeo = new THREE.BoxGeometry(6, cfg.height, 8);
    const leftPillar = new THREE.Mesh(pillarGeo, concreteMat);
    leftPillar.position.set(-21, cfg.height / 2, 46);
    group.add(leftPillar);

    const rightPillar = new THREE.Mesh(pillarGeo, concreteMat);
    rightPillar.position.set(21, cfg.height / 2, 46);
    group.add(rightPillar);

    // Flashing entrance warning beacons
    const beaconGeo = new THREE.SphereGeometry(0.9, 8, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe, transparent: true, opacity: 0.9 });
    const leftBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    leftBeacon.position.set(-21, cfg.height + 0.5, 46);
    group.add(leftBeacon);

    const rightBeacon = new THREE.Mesh(beaconGeo, beaconMat);
    rightBeacon.position.set(21, cfg.height + 0.5, 46);
    group.add(rightBeacon);

    // 3. Flooded Drydock Slip & Steel Catwalks
    const catwalkGeo = new THREE.BoxGeometry(5, 1.4, 82);
    const leftCatwalk = new THREE.Mesh(catwalkGeo, darkSteelMat);
    leftCatwalk.position.set(-16, 3.2, -5);
    group.add(leftCatwalk);

    const rightCatwalk = new THREE.Mesh(catwalkGeo, darkSteelMat);
    rightCatwalk.position.set(16, 3.2, -5);
    group.add(rightCatwalk);

    const rearCatwalkGeo = new THREE.BoxGeometry(28, 1.4, 5);
    const rearCatwalk = new THREE.Mesh(rearCatwalkGeo, darkSteelMat);
    rearCatwalk.position.set(0, 3.2, -43);
    group.add(rearCatwalk);

    // Overhead Heavy Drydock Gantry Crane
    const gantryGeo = new THREE.BoxGeometry(32, 2.5, 4);
    const gantryMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.7, roughness: 0.3 });
    const gantry = new THREE.Mesh(gantryGeo, gantryMat);
    gantry.position.set(0, 18, 6);
    group.add(gantry);

    const hoistGeo = new THREE.BoxGeometry(4, 2.2, 4);
    const hoist = new THREE.Mesh(hoistGeo, darkSteelMat);
    hoist.position.set(0, 16.5, 6);
    group.add(hoist);

    const hoistCableGeo = new THREE.CylinderGeometry(0.06, 0.06, 6.5, 4);
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x18181b });
    const cable = new THREE.Mesh(hoistCableGeo, cableMat);
    cable.position.set(0, 12.8, 6);
    group.add(cable);

    // 4. Typhoon-Class Stealth Nuclear Submarine (76m length)
    const subGroup = new THREE.Group();
    const subHullMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.85,
      metalness: 0.35
    });
    const subSailMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.75,
      metalness: 0.45
    });
    const keelMat = new THREE.MeshStandardMaterial({
      color: 0x991b1b,
      roughness: 0.7
    });

    // Main pressure hull cylinder
    const hullGeo = new THREE.CylinderGeometry(5.6, 5.6, 68, 16);
    hullGeo.rotateX(Math.PI / 2);
    const hullMesh = new THREE.Mesh(hullGeo, subHullMat);
    hullMesh.position.set(0, 1.2, 0);
    subGroup.add(hullMesh);

    // Lower keel boot-topping stripe
    const keelGeo = new THREE.BoxGeometry(2.4, 2.2, 64);
    const keelMesh = new THREE.Mesh(keelGeo, keelMat);
    keelMesh.position.set(0, -3.2, 0);
    subGroup.add(keelMesh);

    // Bulbous bow sonar dome
    const bowGeo = new THREE.SphereGeometry(5.6, 16, 12);
    bowGeo.scale(1.0, 0.96, 1.4);
    const bowMesh = new THREE.Mesh(bowGeo, subSailMat);
    bowMesh.position.set(0, 1.2, 34);
    subGroup.add(bowMesh);

    // Tapered stern cone
    const sternGeo = new THREE.ConeGeometry(5.6, 14, 16);
    sternGeo.rotateX(-Math.PI / 2);
    const sternMesh = new THREE.Mesh(sternGeo, subHullMat);
    sternMesh.position.set(0, 1.2, -41);
    subGroup.add(sternMesh);

    // Conning tower sail
    const sailGeo = new THREE.BoxGeometry(4.2, 8.2, 19);
    const sailMesh = new THREE.Mesh(sailGeo, subSailMat);
    sailMesh.position.set(0, 7.8, 8);
    subGroup.add(sailMesh);

    // Sail bridge top curve
    const sailTopGeo = new THREE.CylinderGeometry(2.1, 2.1, 19, 8);
    sailTopGeo.rotateX(Math.PI / 2);
    const sailTop = new THREE.Mesh(sailTopGeo, subSailMat);
    sailTop.position.set(0, 11.9, 8);
    subGroup.add(sailTop);

    // Sail diving planes (horizontal hydroplanes)
    const divePlaneGeo = new THREE.BoxGeometry(13.2, 0.6, 4.4);
    const divePlane = new THREE.Mesh(divePlaneGeo, subSailMat);
    divePlane.position.set(0, 8.8, 11);
    subGroup.add(divePlane);

    // Periscope and sensor mast cluster atop sail
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.2 });
    const mastGeo = new THREE.CylinderGeometry(0.22, 0.22, 4.2, 6);
    const mast1 = new THREE.Mesh(mastGeo, mastMat);
    mast1.position.set(0.6, 14.8, 9);
    subGroup.add(mast1);

    const mast2 = new THREE.Mesh(mastGeo, mastMat);
    mast2.position.set(-0.6, 14.5, 6);
    subGroup.add(mast2);

    const radarMastGeo = new THREE.BoxGeometry(2.4, 0.4, 0.6);
    const radarMast = new THREE.Mesh(radarMastGeo, mastMat);
    radarMast.position.set(0, 15.6, 4);
    subGroup.add(radarMast);

    // Cruciform stern rudders
    const rudderMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 });
    const vRudderGeo = new THREE.BoxGeometry(0.8, 13.5, 5.2);
    const vRudder = new THREE.Mesh(vRudderGeo, rudderMat);
    vRudder.position.set(0, 1.2, -45);
    subGroup.add(vRudder);

    const hRudderGeo = new THREE.BoxGeometry(13.5, 0.8, 5.2);
    const hRudder = new THREE.Mesh(hRudderGeo, rudderMat);
    hRudder.position.set(0, 1.2, -45);
    subGroup.add(hRudder);

    // 7-Bladed Bronze Propulsion Screw Propeller
    const screwGroup = new THREE.Group();
    const screwHubGeo = new THREE.CylinderGeometry(0.9, 0.7, 1.2, 12);
    screwHubGeo.rotateX(Math.PI / 2);
    const bronzeMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.88,
      roughness: 0.25
    });
    const screwHub = new THREE.Mesh(screwHubGeo, bronzeMat);
    screwGroup.add(screwHub);

    const bladeGeo = new THREE.BoxGeometry(0.35, 2.4, 0.6);
    for (let b = 0; b < 7; b++) {
      const blade = new THREE.Mesh(bladeGeo, bronzeMat);
      const angle = (b / 7) * Math.PI * 2;
      blade.position.set(Math.cos(angle) * 1.2, Math.sin(angle) * 1.2, 0);
      blade.rotation.z = angle;
      blade.rotation.y = 0.35;
      screwGroup.add(blade);
    }
    screwGroup.position.set(0, 1.2, -48.5);
    subGroup.add(screwGroup);

    // Missile Deck Silo Hatches (2 rows of 8 along deck)
    const hatchGeo = new THREE.CylinderGeometry(1.1, 1.1, 0.3, 10);
    const hatchMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    for (let r = 0; r < 8; r++) {
      const hz = -5 - r * 3.8;
      const hLeft = new THREE.Mesh(hatchGeo, hatchMat);
      hLeft.position.set(-1.8, 6.7, hz);
      subGroup.add(hLeft);

      const hRight = new THREE.Mesh(hatchGeo, hatchMat);
      hRight.position.set(1.8, 6.7, hz);
      subGroup.add(hRight);
    }

    subGroup.position.set(0, 0, -14);
    group.add(subGroup);

    // 5. Cavern Lighting & Reactor Sonar Luminescence
    // Submerged emerald green reactor coolant glow
    const reactorLight = new THREE.PointLight(0x10b981, 2.6, 38);
    reactorLight.position.set(cx, -1.5, cz - 14);
    this.scene.add(reactorLight);

    // Sodium interior cavern floodlights
    const cavernLight = new THREE.PointLight(0xf59e0b, 1.8, 55);
    cavernLight.position.set(cx, 16, cz + 6);
    this.scene.add(cavernLight);

    // Entrance cyan beacon light
    const entranceLight = new THREE.PointLight(0x00f2fe, 2.2, 35);
    entranceLight.position.set(cx, cfg.height + 2, cz + 46);
    this.scene.add(entranceLight);

    group.position.set(cx, 0, cz);
    this.scene.add(group);

    // 6. Prototype Railgun Torpedo Pickup in the Drydock Slipway
    this.spawnRailgunCrate(cx, cz + 28);

    // 7. World Obstacle Colliders
    this.colliders.push({ x: cx - 28, z: cz, radius: 22, type: 'subpen_wall' });
    this.colliders.push({ x: cx + 28, z: cz, radius: 22, type: 'subpen_wall' });
    this.colliders.push({ x: cx, z: cz - 56, radius: 20, type: 'subpen_wall' });
    this.colliders.push({ x: cx, z: cz - 14, radius: 8.5, type: 'submarine' });

    this.subPen = {
      x: cx,
      z: cz,
      width: cfg.width,
      length: cfg.length,
      subMesh: subGroup,
      propMesh: screwGroup,
      entered: false,
      dockBeacon: leftBeacon
    };
  }

  _createSupercarrier() {
    const cfg = CONFIG.CARRIER || {
      x: 880,
      z: -1050,
      length: 220,
      deckWidth: 52,
      deckHeight: 15,
      rampWidth: 24,
      rampLength: 42,
      stuntScore: 1600
    };
    const cx = cfg.x;
    const cz = cfg.z;

    const group = new THREE.Group();

    // 1. Lower Hull Structure
    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.72,
      metalness: 0.38
    });
    const bootTopMat = new THREE.MeshStandardMaterial({
      color: 0x991b1b,
      roughness: 0.75
    });
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.92,
      metalness: 0.15
    });
    const towerMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.65,
      metalness: 0.45
    });

    // Main lower hull box
    const hullGeo = new THREE.BoxGeometry(40, 14, 200);
    const hullMesh = new THREE.Mesh(hullGeo, hullMat);
    hullMesh.position.set(0, 7.0, 0);
    hullMesh.castShadow = true;
    hullMesh.receiveShadow = true;
    group.add(hullMesh);

    // Flared bow wedge
    const bowWedgeGeo = new THREE.ConeGeometry(20, 36, 4);
    bowWedgeGeo.rotateX(-Math.PI / 2);
    bowWedgeGeo.rotateY(Math.PI / 4);
    const bowWedge = new THREE.Mesh(bowWedgeGeo, hullMat);
    bowWedge.position.set(0, 7.0, -112);
    bowWedge.castShadow = true;
    group.add(bowWedge);

    // Waterline red stripe
    const bootGeo = new THREE.BoxGeometry(41, 1.8, 202);
    const bootMesh = new THREE.Mesh(bootGeo, bootTopMat);
    bootMesh.position.set(0, 1.2, 0);
    group.add(bootMesh);

    // 2. Flight Deck Platform
    const deckGeo = new THREE.BoxGeometry(52, 2.4, 218);
    const deckMesh = new THREE.Mesh(deckGeo, deckMat);
    deckMesh.position.set(0, 15.2, 0);
    deckMesh.castShadow = true;
    deckMesh.receiveShadow = true;
    group.add(deckMesh);

    // Angled port deck sponson overhang
    const sponsonGeo = new THREE.BoxGeometry(16, 2.0, 120);
    const sponsonMesh = new THREE.Mesh(sponsonGeo, deckMat);
    sponsonMesh.position.set(-24, 15.0, 10);
    group.add(sponsonMesh);

    // Painted Flight Deck Striping & Catapult Steam Tracks
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const steelTrackMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.85 });

    // Centerline runway stripe
    const centerLineGeo = new THREE.BoxGeometry(1.4, 0.1, 180);
    const centerLine = new THREE.Mesh(centerLineGeo, lineMat);
    centerLine.position.set(-4, 16.45, 0);
    group.add(centerLine);

    // Dual steam catapult launch tracks along forward deck
    const catTrackGeo = new THREE.BoxGeometry(0.6, 0.12, 85);
    const cat1 = new THREE.Mesh(catTrackGeo, steelTrackMat);
    cat1.position.set(8, 16.45, -50);
    group.add(cat1);

    const cat2 = new THREE.Mesh(catTrackGeo, steelTrackMat);
    cat2.position.set(16, 16.45, -50);
    group.add(cat2);

    // 4 Arrestor cable lines across landing deck
    const cableGeo = new THREE.CylinderGeometry(0.12, 0.12, 38, 4);
    cableGeo.rotateZ(Math.PI / 2);
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    for (const czOffset of [48, 56, 64, 72]) {
      const arrestor = new THREE.Mesh(cableGeo, cableMat);
      arrestor.position.set(-4, 16.5, czOffset);
      group.add(arrestor);
    }

    // 3. Starboard Command Island Superstructure
    const islandGeo = new THREE.BoxGeometry(11, 18, 32);
    const islandMesh = new THREE.Mesh(islandGeo, towerMat);
    islandMesh.position.set(20, 24, -20);
    islandMesh.castShadow = true;
    group.add(islandMesh);

    // Bridge Navigation Windows
    const bridgeGeo = new THREE.BoxGeometry(11.4, 3.2, 22);
    const bridgeMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const bridgeMesh = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridgeMesh.position.set(20, 30, -20);
    group.add(bridgeMesh);

    // Phased Array SPY Radar Panels
    const spyPanelGeo = new THREE.BoxGeometry(5.5, 5.5, 0.8);
    const spyMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 });
    for (const [px, py, pz, rY] of [
      [20, 26, -36.4, 0],
      [25.8, 26, -20, Math.PI / 2],
      [14.2, 26, -20, -Math.PI / 2],
      [20, 26, -3.6, Math.PI]
    ]) {
      const panel = new THREE.Mesh(spyPanelGeo, spyMat);
      panel.position.set(px, py, pz);
      panel.rotation.y = rY;
      group.add(panel);
    }

    // Lattice Radar Mast
    const mastGeo = new THREE.CylinderGeometry(1.2, 1.8, 16, 6);
    const mast = new THREE.Mesh(mastGeo, spyMat);
    mast.position.set(20, 40, -20);
    group.add(mast);

    // Rotating Surveillance Radar Antenna
    const radarGeo = new THREE.BoxGeometry(9, 2.2, 0.8);
    const radarMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.85, roughness: 0.2 });
    const radarDish = new THREE.Mesh(radarGeo, radarMat);
    radarDish.position.set(20, 48, -20);
    group.add(radarDish);

    // Top Aviation Red Warning Strobe
    const beaconGeo = new THREE.SphereGeometry(0.9, 8, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.95 });
    const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    beaconMesh.position.set(20, 50, -20);
    group.add(beaconMesh);

    const beaconLight = new THREE.PointLight(0xef4444, 2.5, 40);
    beaconLight.position.set(cx + 20, 50, cz - 20);
    this.scene.add(beaconLight);

    // 4. Parked Naval Strike Fighters (3 Jets on Apron)
    const jetMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.4 });
    const canopyMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });

    const createJet = (jx, jz, jrot) => {
      const jet = new THREE.Group();
      const fuse = new THREE.Mesh(new THREE.BoxGeometry(3.0, 1.8, 15), jetMat);
      jet.add(fuse);

      const wing = new THREE.Mesh(new THREE.BoxGeometry(11, 0.3, 5.0), jetMat);
      wing.position.set(0, 0.2, -1.0);
      jet.add(wing);

      const tailL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.2, 3.0), jetMat);
      tailL.position.set(-1.2, 1.6, 5.5);
      tailL.rotation.z = -0.25;
      jet.add(tailL);

      const tailR = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.2, 3.0), jetMat);
      tailR.position.set(1.2, 1.6, 5.5);
      tailR.rotation.z = 0.25;
      jet.add(tailR);

      const canopy = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.1, 4.2), canopyMat);
      canopy.position.set(0, 1.2, -3.2);
      jet.add(canopy);

      jet.position.set(jx, 17.0, jz);
      jet.rotation.y = jrot;
      return jet;
    };

    group.add(createJet(18, 26, 0.35));
    group.add(createJet(18, 62, 0.25));
    group.add(createJet(-16, -72, -0.4));

    // 5. Automated Phalanx CIWS Air-Defense Mounts
    const ciwsMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3, metalness: 0.7 });
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9 });
    for (const [ciwsX, ciwsZ] of [[-27, -32], [23, 82]]) {
      const ciwsGroup = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.2, 2.5, 10), ciwsMat);
      ciwsGroup.add(base);

      const dome = new THREE.Mesh(new THREE.SphereGeometry(1.5, 10, 10), ciwsMat);
      dome.position.y = 2.2;
      ciwsGroup.add(dome);

      const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 3.8), gunMat);
      barrel.position.set(0, 1.8, 2.2);
      ciwsGroup.add(barrel);

      ciwsGroup.position.set(ciwsX, 16.2, ciwsZ);
      group.add(ciwsGroup);
    }

    group.position.set(cx, 0, cz);
    this.scene.add(group);

    // 6. Stunt Ramps: Stern Boarding Incline & Bow Ski-Jump Launch
    const rampMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });

    // Stern Boarding Incline: Slopes up from sea level into the flight deck
    const sternRampGeo = new THREE.BoxGeometry(22, 1.8, 44);
    const sternRampMesh = new THREE.Mesh(sternRampGeo, rampMat);
    sternRampMesh.position.set(cx, 8.2, cz + 118);
    sternRampMesh.rotation.x = -0.36;
    this.scene.add(sternRampMesh);

    this.ramps.push({
      x: cx,
      z: cz + 118,
      width: 22,
      length: 44,
      angle: 0,
      mesh: sternRampMesh,
      isCarrierRamp: true
    });

    // Bow Ski-Jump Launch Ramp: High supersonic launch off the carrier bow!
    const bowRampGeo = new THREE.BoxGeometry(26, 2.4, 38);
    const bowRampMesh = new THREE.Mesh(bowRampGeo, rampMat);
    bowRampMesh.position.set(cx, 18.5, cz - 110);
    bowRampMesh.rotation.x = 0.38;
    this.scene.add(bowRampMesh);

    this.ramps.push({
      x: cx,
      z: cz - 110,
      width: 26,
      length: 38,
      angle: Math.PI,
      mesh: bowRampMesh,
      isCarrierRamp: true,
      isSuperJump: true
    });

    // 7. Experimental EMP Shockwave Weapon Pickup at Mooring Berth
    this.spawnEMPCrate(cx + 36, cz + 24);

    // 8. World Colliders
    this.colliders.push({ x: cx, z: cz, radius: 32, type: 'carrier_hull' });
    this.colliders.push({ x: cx, z: cz - 70, radius: 24, type: 'carrier_hull' });
    this.colliders.push({ x: cx, z: cz + 70, radius: 24, type: 'carrier_hull' });
    this.colliders.push({ x: cx + 20, z: cz - 20, radius: 14, type: 'carrier_island' });

    this.carrier = {
      x: cx,
      z: cz,
      length: cfg.length,
      width: cfg.deckWidth,
      mesh: group,
      radarDish,
      beaconMesh,
      beaconLight
    };
  }

  _createSeaplaneHangar() {
    const cfg = CONFIG.SEAPLANE_HANGAR || {
      x: -480,
      z: -920,
      hangarWidth: 54,
      hangarLength: 64,
      hangarHeight: 22,
      runwayLength: 190,
      runwayWidth: 32,
      stuntScore: 900
    };
    const cx = cfg.x;
    const cz = cfg.z;

    const group = new THREE.Group();

    // 1. Materials
    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      metalness: 0.75,
      roughness: 0.35,
      side: THREE.DoubleSide
    });
    const dockMat = new THREE.MeshStandardMaterial({
      color: 0x5c4033,
      roughness: 0.85
    });
    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.8
    });
    const hazardStripeMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

    // 2. Double Barrel-Vault Arched Hangar Roof
    const vaultGeo = new THREE.CylinderGeometry(13.5, 13.5, cfg.hangarLength, 16, 1, true, 0, Math.PI);
    vaultGeo.rotateZ(Math.PI / 2);
    vaultGeo.rotateY(Math.PI / 2);

    const leftRoof = new THREE.Mesh(vaultGeo, metalMat);
    leftRoof.position.set(-13.5, 9.0, 0);
    leftRoof.castShadow = true;
    group.add(leftRoof);

    const rightRoof = new THREE.Mesh(vaultGeo, metalMat);
    rightRoof.position.set(13.5, 9.0, 0);
    rightRoof.castShadow = true;
    group.add(rightRoof);

    // Outer and center dividing sidewalls
    const wallGeo = new THREE.BoxGeometry(2.4, 12, cfg.hangarLength);
    const leftWall = new THREE.Mesh(wallGeo, metalMat);
    leftWall.position.set(-27, 6.0, 0);
    group.add(leftWall);

    const rightWall = new THREE.Mesh(wallGeo, metalMat);
    rightWall.position.set(27, 6.0, 0);
    group.add(rightWall);

    const centerDivider = new THREE.Mesh(wallGeo, metalMat);
    centerDivider.position.set(0, 6.0, 0);
    group.add(centerDivider);

    // Rear End Wall
    const rearWallGeo = new THREE.BoxGeometry(cfg.hangarWidth + 2, 16, 2.5);
    const rearWall = new THREE.Mesh(rearWallGeo, metalMat);
    rearWall.position.set(0, 8.0, -cfg.hangarLength / 2);
    group.add(rearWall);

    // Front Portal Lintels with Hazard Chevron Stripes
    const lintelGeo = new THREE.BoxGeometry(cfg.hangarWidth + 2, 2.2, 2.5);
    const lintel = new THREE.Mesh(lintelGeo, concreteMat);
    lintel.position.set(0, 13.5, cfg.hangarLength / 2);
    group.add(lintel);

    const stripeGeo = new THREE.BoxGeometry(cfg.hangarWidth, 0.8, 0.2);
    const stripe = new THREE.Mesh(stripeGeo, hazardStripeMat);
    stripe.position.set(0, 13.5, cfg.hangarLength / 2 + 1.3);
    group.add(stripe);

    // 3. Floating Timber Service Pontoons
    const pierGeo = new THREE.BoxGeometry(4.2, 1.4, cfg.hangarLength - 4);
    const leftPier = new THREE.Mesh(pierGeo, dockMat);
    leftPier.position.set(-24, 0.7, 0);
    group.add(leftPier);

    const rightPier = new THREE.Mesh(pierGeo, dockMat);
    rightPier.position.set(24, 0.7, 0);
    group.add(rightPier);

    const centerPier = new THREE.Mesh(pierGeo, dockMat);
    centerPier.position.set(0, 0.7, 0);
    group.add(centerPier);

    // Roof aviation warning beacons
    const beaconGeo = new THREE.SphereGeometry(0.8, 8, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.95 });
    const beaconLeft = new THREE.Mesh(beaconGeo, beaconMat);
    beaconLeft.position.set(-13.5, 23.0, cfg.hangarLength / 2);
    group.add(beaconLeft);

    const beaconRight = new THREE.Mesh(beaconGeo, beaconMat);
    beaconRight.position.set(13.5, 23.0, cfg.hangarLength / 2);
    group.add(beaconRight);

    // Sodium interior floodlights
    const sodiumLight = new THREE.PointLight(0xf59e0b, 2.2, 48);
    sodiumLight.position.set(0, 16, 0);
    group.add(sodiumLight);

    // 4. Detailed 3D Amphibious Twin-Engine Seaplane (Moored in Port Slip)
    const planeGroup = new THREE.Group();
    const planeHullMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.35, metalness: 0.5 });
    const keelMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 });
    const cowlMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3, metalness: 0.7 });
    const propMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9, roughness: 0.2 });
    const canopyMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });

    // Streamlined stepped fuselage hull
    const fuseGeo = new THREE.BoxGeometry(3.6, 2.8, 18);
    const fuse = new THREE.Mesh(fuseGeo, planeHullMat);
    fuse.position.y = 2.0;
    planeGroup.add(fuse);

    const stepHullGeo = new THREE.BoxGeometry(3.4, 1.2, 16);
    const stepHull = new THREE.Mesh(stepHullGeo, keelMat);
    stepHull.position.y = 0.8;
    planeGroup.add(stepHull);

    // High gull wing
    const wingGeo = new THREE.BoxGeometry(26, 0.4, 4.4);
    const wing = new THREE.Mesh(wingGeo, planeHullMat);
    wing.position.set(0, 3.8, 0);
    planeGroup.add(wing);

    // Twin wingtip stabilization pontoons
    const tipFloatGeo = new THREE.BoxGeometry(1.2, 1.2, 4.0);
    const floatL = new THREE.Mesh(tipFloatGeo, cowlMat);
    floatL.position.set(-12, 1.2, 0);
    planeGroup.add(floatL);

    const floatR = new THREE.Mesh(tipFloatGeo, cowlMat);
    floatR.position.set(12, 1.2, 0);
    planeGroup.add(floatR);

    // Twin Radial Engine Cowlings
    const cowlGeo = new THREE.CylinderGeometry(1.3, 1.3, 3.2, 10);
    cowlGeo.rotateX(Math.PI / 2);
    const cowlLeft = new THREE.Mesh(cowlGeo, cowlMat);
    cowlLeft.position.set(-5.5, 3.8, 2.0);
    planeGroup.add(cowlLeft);

    const cowlRight = new THREE.Mesh(cowlGeo, cowlMat);
    cowlRight.position.set(5.5, 3.8, 2.0);
    planeGroup.add(cowlRight);

    // Twin spinning 3-bladed propellers
    const propGroupL = new THREE.Group();
    const propHubGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.6, 8);
    propHubGeo.rotateX(Math.PI / 2);
    propGroupL.add(new THREE.Mesh(propHubGeo, propMat));

    const bladeGeo = new THREE.BoxGeometry(0.2, 1.8, 0.35);
    for (let b = 0; b < 3; b++) {
      const bl = new THREE.Mesh(bladeGeo, propMat);
      bl.rotation.z = (b / 3) * Math.PI * 2;
      propGroupL.add(bl);
    }
    propGroupL.position.set(-5.5, 3.8, 3.8);
    planeGroup.add(propGroupL);

    const propGroupR = propGroupL.clone();
    propGroupR.position.set(5.5, 3.8, 3.8);
    planeGroup.add(propGroupR);

    // Cockpit greenhouse canopy
    const canopyGeo = new THREE.BoxGeometry(2.6, 1.2, 3.8);
    const canopy = new THREE.Mesh(canopyGeo, canopyMat);
    canopy.position.set(0, 3.8, 4.0);
    planeGroup.add(canopy);

    // Vertical tail stabilizer
    const finGeo = new THREE.BoxGeometry(0.35, 3.6, 3.2);
    const fin = new THREE.Mesh(finGeo, cowlMat);
    fin.position.set(0, 4.6, -7.5);
    planeGroup.add(fin);

    const horizGeo = new THREE.BoxGeometry(7.5, 0.25, 2.2);
    const horiz = new THREE.Mesh(horizGeo, planeHullMat);
    horiz.position.set(0, 5.0, -7.5);
    planeGroup.add(horiz);

    planeGroup.position.set(-13.5, 0, 4);
    group.add(planeGroup);

    group.position.set(cx, 0, cz);
    this.scene.add(group);

    // 5. Water Runway Landing Strip (190m length south from hangar)
    const rStart = cz + 36;
    const rLength = cfg.runwayLength || 190;
    const rWidth = cfg.runwayWidth || 32;

    const runwayPontoonGeo = new THREE.BoxGeometry(4.0, 1.4, 18);
    const pontoonMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const greenBeaconMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
    const redBeaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const bGeo = new THREE.SphereGeometry(0.5, 6, 6);

    for (let rz = 0; rz <= rLength; rz += 30) {
      const zPos = rStart + rz;
      const pL = new THREE.Mesh(runwayPontoonGeo, pontoonMat);
      pL.position.set(cx - rWidth / 2 - 2, 0.7, zPos);
      this.scene.add(pL);

      const bL = new THREE.Mesh(bGeo, rz === 0 ? greenBeaconMat : (rz >= rLength - 30 ? redBeaconMat : greenBeaconMat));
      bL.position.set(cx - rWidth / 2 - 2, 2.2, zPos);
      this.scene.add(bL);

      const pR = new THREE.Mesh(runwayPontoonGeo, pontoonMat);
      pR.position.set(cx + rWidth / 2 + 2, 0.7, zPos);
      this.scene.add(pR);

      const bR = new THREE.Mesh(bGeo, rz === 0 ? greenBeaconMat : (rz >= rLength - 30 ? redBeaconMat : greenBeaconMat));
      bR.position.set(cx + rWidth / 2 + 2, 2.2, zPos);
      this.scene.add(bR);

      this.colliders.push({ x: cx - rWidth / 2 - 2, z: zPos, radius: 4.5, type: 'dock' });
      this.colliders.push({ x: cx + rWidth / 2 + 2, z: zPos, radius: 4.5, type: 'dock' });
    }

    // 6. Water Ski-Jump Runway Takeoff Ramps
    const rampMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 });
    const rampGeo = new THREE.BoxGeometry(rWidth - 4, 1.6, 28);

    // North Runway Ramp (Facing South)
    const northRampMesh = new THREE.Mesh(rampGeo, rampMat);
    northRampMesh.position.set(cx, 3.2, rStart + 14);
    northRampMesh.rotation.x = -0.32;
    this.scene.add(northRampMesh);

    this.ramps.push({
      x: cx,
      z: rStart + 14,
      width: rWidth - 4,
      length: 28,
      angle: 0,
      mesh: northRampMesh,
      isRunwayRamp: true
    });

    // South Runway Ramp (Facing North)
    const southRampMesh = new THREE.Mesh(rampGeo, rampMat);
    southRampMesh.position.set(cx, 3.2, rStart + rLength - 14);
    southRampMesh.rotation.x = 0.32;
    this.scene.add(southRampMesh);

    this.ramps.push({
      x: cx,
      z: rStart + rLength - 14,
      width: rWidth - 4,
      length: 28,
      angle: Math.PI,
      mesh: southRampMesh,
      isRunwayRamp: true
    });

    // 7. High-Octane Aviation Fuel Drums (AVGAS 100LL)
    const fuelDrums = [];
    const drumCoords = [
      { x: cx - 34, z: cz - 12 },
      { x: cx - 34, z: cz + 16 },
      { x: cx + 34, z: cz - 12 },
      { x: cx + 34, z: cz + 16 },
      { x: cx - 22, z: rStart + 50 },
      { x: cx + 22, z: rStart + 50 }
    ];

    const drumGeo = new THREE.CylinderGeometry(1.3, 1.3, 3.4, 10);
    const drumMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, metalness: 0.8, roughness: 0.3 });
    const drumBandMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

    for (const d of drumCoords) {
      const dGroup = new THREE.Group();
      const drumMesh = new THREE.Mesh(drumGeo, drumMat);
      drumMesh.position.y = 1.7;
      dGroup.add(drumMesh);

      const bandMesh = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.4, 2.8), drumBandMat);
      bandMesh.position.y = 1.7;
      dGroup.add(bandMesh);

      const padMesh = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.8, 4.5), dockMat);
      padMesh.position.y = 0.4;
      dGroup.add(padMesh);

      dGroup.position.set(d.x, 0, d.z);
      this.scene.add(dGroup);

      fuelDrums.push({
        x: d.x,
        z: d.z,
        radius: 2.6,
        health: 20,
        alive: true,
        mesh: dGroup
      });
    }

    // 8. Guaranteed Crown Diamond Smuggle Cache inside Starboard Slip
    this.spawnDiamondCache(cx + 13.5, cz);

    // 9. World Obstacle Colliders
    this.colliders.push({ x: cx - 27, z: cz, radius: 18, type: 'hangar_wall' });
    this.colliders.push({ x: cx + 27, z: cz, radius: 18, type: 'hangar_wall' });
    this.colliders.push({ x: cx, z: cz - cfg.hangarLength / 2, radius: 16, type: 'hangar_wall' });
    this.colliders.push({ x: cx - 13.5, z: cz + 4, radius: 8.0, type: 'seaplane' });

    this.seaplaneHangar = {
      x: cx,
      z: cz,
      width: cfg.hangarWidth,
      length: cfg.hangarLength,
      planeMesh: planeGroup,
      propLeft: propGroupL,
      propRight: propGroupR,
      fuelDrums,
      entered: false
    };
  }

  detonateAvGasDrum(drum, attacker = null) {
    if (!drum || !drum.alive) return;
    drum.alive = false;
    if (drum.mesh) drum.mesh.visible = false;

    // Fire & voxel crumbles
    this.spawnVoxelCrumbles(drum.x, 2.5, drum.z, 28, 0xef4444);
    this.spawnVoxelCrumbles(drum.x, 2.5, drum.z, 20, 0xf59e0b);
    this.spawnVoxelCrumbles(drum.x, 2.5, drum.z, 16, 0x1d4ed8);

    soundManager.playFireIgnite();
    soundManager.playExplosion(0.8, 1.1);

    if (window.game && window.game.addTrauma) window.game.addTrauma(0.55);

    // Spawn Surface Oil Fire Hazard
    this.spawnOilFire(drum.x, drum.z);

    const player = (attacker && attacker.triggerStunt) ? attacker : (window.game ? window.game.player : null);
    if (player && player.triggerStunt) {
      player.triggerStunt('🔥 FUEL DEPOT INFERNO!', 700);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '🚨 [FIRE HAZMAT]: 10-99! AVIATION FUEL DETONATED AT SEAPLANE HANGAR!';
      dispatch.style.color = '#ef4444';
    }
  }

  spawnOilFire(x, z) {
    const fireGroup = new THREE.Group();

    // Surface burning oil slick circle
    const slickGeo = new THREE.CircleGeometry(12, 16);
    slickGeo.rotateX(-Math.PI / 2);
    const slickMat = new THREE.MeshBasicMaterial({
      color: 0x18181b,
      transparent: true,
      opacity: 0.82
    });
    const slickMesh = new THREE.Mesh(slickGeo, slickMat);
    slickMesh.position.y = 0.25;
    fireGroup.add(slickMesh);

    // Flickering fire cones
    const flameGeo = new THREE.ConeGeometry(2.4, 7.5, 6);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.9
    });
    for (let f = 0; f < 5; f++) {
      const flame = new THREE.Mesh(flameGeo, flameMat);
      const angle = (f / 5) * Math.PI * 2;
      flame.position.set(Math.cos(angle) * 4.5, 3.5, Math.sin(angle) * 4.5);
      fireGroup.add(flame);
    }

    // Central flame pillar
    const centerFlame = new THREE.Mesh(new THREE.ConeGeometry(3.5, 9.5, 8), new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.95 }));
    centerFlame.position.y = 4.5;
    fireGroup.add(centerFlame);

    // Flickering fire point light
    const fireLight = new THREE.PointLight(0xff7700, 3.2, 28);
    fireLight.position.set(0, 4.0, 0);
    fireGroup.add(fireLight);

    fireGroup.position.set(x, 0, z);
    this.scene.add(fireGroup);

    this.fireHazards.push({
      x,
      z,
      radius: 13,
      mesh: fireGroup,
      light: fireLight,
      life: 0,
      maxLife: 14.0
    });
  }

  _createSeaArch() {
    const cfg = CONFIG.SEA_ARCH;
    const archGroup = new THREE.Group();

    const rockMat = new THREE.MeshStandardMaterial({
      color: 0x786958,
      roughness: 0.88,
      metalness: 0.08
    });
    const peakMat = new THREE.MeshStandardMaterial({
      color: 0x5a4d3f,
      roughness: 0.92,
      metalness: 0.05
    });

    // Twin massive limestone pillars flanking the channel
    const pillarGeo = new THREE.CylinderGeometry(11, 14, 28, 12);
    const pLeft = new THREE.Mesh(pillarGeo, rockMat);
    pLeft.position.set(cfg.x - 22, 14, cfg.z);
    pLeft.castShadow = true;
    pLeft.receiveShadow = true;
    archGroup.add(pLeft);

    const pRight = new THREE.Mesh(pillarGeo, rockMat);
    pRight.position.set(cfg.x + 22, 14, cfg.z);
    pRight.castShadow = true;
    pRight.receiveShadow = true;
    archGroup.add(pRight);

    // Overhead curved limestone arch bridge spanning between the pillars (y: 20-27m)
    const archSpanGeo = new THREE.BoxGeometry(46, 7.5, 15);
    const archSpan = new THREE.Mesh(archSpanGeo, rockMat);
    archSpan.position.set(cfg.x, 24, cfg.z);
    archSpan.castShadow = true;
    archSpan.receiveShadow = true;
    archGroup.add(archSpan);

    const peakGeo = new THREE.ConeGeometry(9, 8, 8);
    const peak = new THREE.Mesh(peakGeo, peakMat);
    peak.position.set(cfg.x, 30.5, cfg.z);
    peak.castShadow = true;
    archGroup.add(peak);

    // North slalom entrance spire
    const spireGeo = new THREE.ConeGeometry(5.2, 22, 8);
    const spireNorth = new THREE.Mesh(spireGeo, rockMat);
    spireNorth.position.set(cfg.x, 10, cfg.z - 45);
    spireNorth.castShadow = true;
    spireNorth.receiveShadow = true;
    archGroup.add(spireNorth);

    // South slalom exit spire
    const spireSouth = new THREE.Mesh(spireGeo, rockMat);
    spireSouth.position.set(cfg.x, 10, cfg.z + 45);
    spireSouth.castShadow = true;
    spireSouth.receiveShadow = true;
    archGroup.add(spireSouth);

    // Central high-tension grapple mooring dolphin in the chasm for high-g slingshot drift
    const dolphinGeo = new THREE.CylinderGeometry(1.6, 2.0, 7.5, 8);
    const dolphinMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6, metalness: 0.5 });
    const dolphin = new THREE.Mesh(dolphinGeo, dolphinMat);
    dolphin.position.set(cfg.x, 3.5, cfg.z);
    dolphin.castShadow = true;
    archGroup.add(dolphin);

    const ringGeo = new THREE.TorusGeometry(2.4, 0.35, 8, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(cfg.x, 6.2, cfg.z);
    archGroup.add(ring);

    this.grappleDolphins.push({
      x: cfg.x,
      z: cfg.z,
      mesh: dolphin,
      ring: ring
    });

    // Add limestone colliders to world
    this.colliders.push(
      { x: cfg.x - 22, z: cfg.z, radius: 13, type: 'pillar', mesh: pLeft },
      { x: cfg.x + 22, z: cfg.z, radius: 13, type: 'pillar', mesh: pRight },
      { x: cfg.x, z: cfg.z - 45, radius: 5.5, type: 'pillar', mesh: spireNorth },
      { x: cfg.x, z: cfg.z + 45, radius: 5.5, type: 'pillar', mesh: spireSouth }
    );

    this.scene.add(archGroup);

    // Floating contraband pickup tucked under the arch
    this._addPickup(cfg.x, cfg.z, 'contraband');

    this.seaArch = {
      x: cfg.x,
      z: cfg.z,
      mesh: archGroup,
      entered: false
    };
  }

  _initRogueWave() {
    const rwCfg = CONFIG.ROGUE_WAVE;
    const waveGroup = new THREE.Group();

    // Foaming cyan wave crest face
    const waveGeo = new THREE.PlaneGeometry(rwCfg.width || 260, 14, 16, 2);
    waveGeo.rotateX(-0.35);
    const waveMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.55,
      transparent: true,
      opacity: 0.78,
      roughness: 0.25,
      metalness: 0.1,
      side: THREE.DoubleSide
    });
    const waveMesh = new THREE.Mesh(waveGeo, waveMat);
    waveMesh.position.y = 5.0;
    waveGroup.add(waveMesh);

    // Brilliant white foam spray lip on the peak
    const foamGeo = new THREE.BoxGeometry(rwCfg.width || 260, 1.4, 2.8);
    const foamMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.92
    });
    const foamMesh = new THREE.Mesh(foamGeo, foamMat);
    foamMesh.position.y = 10.5;
    waveGroup.add(foamMesh);

    waveGroup.position.set(0, -9999, 0);
    this.scene.add(waveGroup);

    this.rogueWave = {
      active: false,
      x: -750,
      z: -450,
      angle: 0.42,
      speed: rwCfg.speed || 32.0,
      width: rwCfg.width || 260.0,
      amplitude: rwCfg.amplitude || 4.8,
      distanceTraveled: 0,
      maxDistance: 1700,
      timer: 35.0,
      interval: rwCfg.interval || 50.0,
      mesh: waveGroup
    };
  }

  triggerRogueWave(angle = 0.42, startX = -750, startZ = -450) {
    if (!this.rogueWave) return;
    this.rogueWave.active = true;
    this.rogueWave.x = startX;
    this.rogueWave.z = startZ;
    this.rogueWave.angle = angle;
    this.rogueWave.distanceTraveled = 0;
    if (this.rogueWave.mesh) {
      this.rogueWave.mesh.visible = true;
      this.rogueWave.mesh.position.set(startX, 3.2, startZ);
      this.rogueWave.mesh.rotation.y = angle;
    }
    soundManager.playRogueWaveSurge();
    if (window.game && window.game.addTrauma) {
      window.game.addTrauma(0.55);
    }
    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '🌊 [ROGUE SWELL SURGE]: 50-FOOT ROGUE TIDAL WAVE CRASHING THROUGH WATERWAYS!';
      dispatch.style.color = '#38bdf8';
    }
  }

  _updateRogueWave(dt, player = null) {
    if (!this.rogueWave) return;
    const rw = this.rogueWave;

    rw.timer += dt;
    if (!rw.active && rw.timer >= rw.interval) {
      rw.timer = 0;
      this.triggerRogueWave();
    }

    if (!rw.active) return;

    // Advance wave along heading vector
    const step = rw.speed * dt;
    rw.x += Math.sin(rw.angle) * step;
    rw.z += Math.cos(rw.angle) * step;
    rw.distanceTraveled += step;

    if (rw.mesh) {
      rw.mesh.position.set(rw.x, 3.5 + Math.sin(this.waterTime * 12) * 0.4, rw.z);
      rw.mesh.rotation.y = rw.angle;
    }

    // Broadside wave slam against enemy boats
    if (window.game && window.game.factionManager) {
      const nx = Math.sin(rw.angle);
      const nz = Math.cos(rw.angle);
      for (const enemy of window.game.factionManager.enemies) {
        if (!enemy.alive) continue;
        const edx = enemy.position.x - rw.x;
        const edz = enemy.position.z - rw.z;
        const alongDist = edx * nx + edz * nz;
        const perpDist = Math.abs(edx * (-nz) + edz * nx);

        if (Math.abs(alongDist) < 16 && perpDist < rw.width * 0.5) {
          enemy.takeDamage(45 * dt * 2.5, player);
          enemy.velocity.x += nx * 22 * dt;
          enemy.velocity.z += nz * 22 * dt;
          if (enemy.spinVelocity !== undefined) {
            enemy.spinVelocity = (Math.random() - 0.5) * 16;
          }
          if (Math.random() < 0.3) {
            this.spawnVoxelCrumbles(enemy.position.x, 3.0, enemy.position.z, 8, 0x38bdf8);
            this.spawnVoxelCrumbles(enemy.position.x, 3.0, enemy.position.z, 6, 0xffffff);
          }
        }
      }
    }

    if (rw.distanceTraveled >= rw.maxDistance) {
      rw.active = false;
      if (rw.mesh) rw.mesh.visible = false;
    }
  }

  _createLighthouseAndReef() {
    const lCfg = CONFIG.LIGHTHOUSE;
    const gCfg = CONFIG.SUNKEN_GALLEON;
    const group = new THREE.Group();

    // 1. Granite Island Base at (-200, -780)
    const islandGeo = new THREE.CylinderGeometry(34, 38, 5, 14);
    const islandMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.9,
      metalness: 0.1
    });
    const island = new THREE.Mesh(islandGeo, islandMat);
    island.position.set(lCfg.x, 1.5, lCfg.z);
    island.receiveShadow = true;
    group.add(island);

    // Island Shoreline Boulders
    const boulderMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });
    for (let i = 0; i < 8; i++) {
      const bAng = (i / 8) * Math.PI * 2;
      const bRad = 31 + (i % 3) * 2;
      const bx = lCfg.x + Math.cos(bAng) * bRad;
      const bz = lCfg.z + Math.sin(bAng) * bRad;
      const bGeo = new THREE.DodecahedronGeometry(3.6, 1);
      const bMesh = new THREE.Mesh(bGeo, boulderMat);
      bMesh.position.set(bx, 2.5, bz);
      bMesh.castShadow = true;
      group.add(bMesh);
      this.colliders.push({ x: bx, z: bz, radius: 4.0, type: 'pillar', mesh: bMesh });
    }

    // 2. Weathered Sentinel Lighthouse Tower
    // Tapered tower shaft
    const towerGeo = new THREE.CylinderGeometry(4.2, 7.2, 36, 16);
    const towerMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.75,
      metalness: 0.1
    });
    const towerShaft = new THREE.Mesh(towerGeo, towerMat);
    towerShaft.position.set(lCfg.x, 21.5, lCfg.z);
    towerShaft.castShadow = true;
    towerShaft.receiveShadow = true;
    group.add(towerShaft);

    // Dark masonry bands around tower shaft
    const bandMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });
    for (let b = 0; b < 3; b++) {
      const bandGeo = new THREE.CylinderGeometry(4.8 + b * 0.8, 5.2 + b * 0.8, 3.5, 16);
      const bandMesh = new THREE.Mesh(bandGeo, bandMat);
      bandMesh.position.set(lCfg.x, 11 + b * 10, lCfg.z);
      bandMesh.castShadow = true;
      group.add(bandMesh);
    }

    // Gallery Walkway Deck & Railings
    const galleryGeo = new THREE.CylinderGeometry(6.6, 6.6, 1.2, 16);
    const gallery = new THREE.Mesh(galleryGeo, bandMat);
    gallery.position.set(lCfg.x, 39.5, lCfg.z);
    gallery.castShadow = true;
    group.add(gallery);

    const railGeo = new THREE.TorusGeometry(6.4, 0.25, 8, 16);
    const railMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, roughness: 0.4 });
    const rail = new THREE.Mesh(railGeo, railMat);
    rail.rotation.x = Math.PI / 2;
    rail.position.set(lCfg.x, 40.8, lCfg.z);
    group.add(rail);

    // Lantern Room Enclosure (Glass + Verdigris Dome)
    const glassGeo = new THREE.CylinderGeometry(4.5, 4.5, 5.0, 12);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
      roughness: 0.1,
      metalness: 0.2
    });
    const glassMesh = new THREE.Mesh(glassGeo, glassMat);
    glassMesh.position.set(lCfg.x, 42.5, lCfg.z);
    group.add(glassMesh);

    const domeGeo = new THREE.SphereGeometry(4.8, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.5);
    const domeMat = new THREE.MeshStandardMaterial({
      color: 0x0d9488, // Verdigris oxidized copper
      roughness: 0.65,
      metalness: 0.3
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.set(lCfg.x, 45.0, lCfg.z);
    domeMesh.castShadow = true;
    group.add(domeMesh);

    // Lightning Rod Spire
    const rodGeo = new THREE.CylinderGeometry(0.2, 0.4, 5.0, 6);
    const rodMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 });
    const rodMesh = new THREE.Mesh(rodGeo, rodMat);
    rodMesh.position.set(lCfg.x, 49.5, lCfg.z);
    group.add(rodMesh);

    // Add tower base collider
    this.colliders.push({ x: lCfg.x, z: lCfg.z, radius: 7.5, type: 'pillar', mesh: towerShaft });

    // Lantern Light Source
    const lanternLight = new THREE.PointLight(0xfffbeb, 4.5, 140);
    lanternLight.position.set(lCfg.x, 43.0, lCfg.z);
    group.add(lanternLight);

    // 3. Rotating High-Power Searchlight Beam
    const beamGroup = new THREE.Group();
    beamGroup.position.set(lCfg.x, 42.5, lCfg.z);

    // Translucent Volumetric Light Cone
    const coneGeo = new THREE.ConeGeometry(24, 95, 16, 1, true);
    coneGeo.translate(0, -47.5, 0);
    coneGeo.rotateX(-Math.PI / 2 + 0.38); // Tilted down towards ocean surface
    const coneMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    const beamCone = new THREE.Mesh(coneGeo, coneMat);
    beamGroup.add(beamCone);

    // Focused SpotLight
    const spotLight = new THREE.SpotLight(0xfffbeb, 5.5, 130, Math.PI * 0.24, 0.45, 1.4);
    spotLight.position.set(0, 0, 0);
    const spotTarget = new THREE.Object3D();
    spotTarget.position.set(0, -40, 85);
    beamGroup.add(spotTarget);
    spotLight.target = spotTarget;
    beamGroup.add(spotLight);

    group.add(beamGroup);

    // 4. Automated Coastal Defense Turrets (North & South emplacements)
    const turrets = [];
    const turretGeo = new THREE.BoxGeometry(2.4, 1.8, 3.2);
    const turretMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.4 });
    const barrelGeo = new THREE.CylinderGeometry(0.25, 0.25, 3.2, 8);
    barrelGeo.rotateX(Math.PI / 2);
    const barrelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.3 });

    const turretPos = [
      { x: lCfg.x, z: lCfg.z - 26, label: 'North' },
      { x: lCfg.x, z: lCfg.z + 26, label: 'South' }
    ];

    for (const tPos of turretPos) {
      const tMesh = new THREE.Group();
      const base = new THREE.Mesh(turretGeo, turretMat);
      base.castShadow = true;
      tMesh.add(base);

      const bLeft = new THREE.Mesh(barrelGeo, barrelMat);
      bLeft.position.set(-0.6, 0.2, 1.6);
      tMesh.add(bLeft);

      const bRight = new THREE.Mesh(barrelGeo, barrelMat);
      bRight.position.set(0.6, 0.2, 1.6);
      tMesh.add(bRight);

      tMesh.position.set(tPos.x, 4.5, tPos.z);
      group.add(tMesh);

      turrets.push({
        x: tPos.x,
        z: tPos.z,
        mesh: tMesh,
        fireTimer: 1.2,
        engaged: false
      });
    }

    // 5. Sunken 17th-Century Spanish Galleon Shipwreck at (-160, -740)
    const wreckGroup = new THREE.Group();
    wreckGroup.position.set(gCfg.x, -2.5, gCfg.z);
    wreckGroup.rotation.y = 0.65;
    wreckGroup.rotation.z = 0.26; // Tilted list onto the reef

    // Timber galleon hull
    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.88,
      metalness: 0.1
    });
    const wHullGeo = new THREE.BoxGeometry(16, 12, 54);
    const wHull = new THREE.Mesh(wHullGeo, hullMat);
    wHull.position.y = 4.0;
    wHull.castShadow = true;
    wreckGroup.add(wHull);

    // Forecastle and Sterncastle structures
    const castleGeo = new THREE.BoxGeometry(14, 8, 12);
    const sternCastle = new THREE.Mesh(castleGeo, hullMat);
    sternCastle.position.set(0, 9.0, 20);
    sternCastle.castShadow = true;
    wreckGroup.add(sternCastle);

    // Weathered rib timbers protruding from smashed hull
    const ribMat = new THREE.MeshStandardMaterial({ color: 0x271306, roughness: 0.95 });
    for (let r = -4; r <= 4; r++) {
      const ribGeo = new THREE.TorusGeometry(8.5, 0.6, 6, 8, Math.PI);
      const rib = new THREE.Mesh(ribGeo, ribMat);
      rib.position.set(0, 6.0, r * 5.5);
      rib.rotation.y = Math.PI / 2;
      wreckGroup.add(rib);
    }

    // Snapped Mainmast angled up to form oceanic stunt ramp!
    const mastGeo = new THREE.BoxGeometry(14, 1.8, 34);
    mastGeo.rotateX(-0.35); // Incline ramp
    const mastMat = new THREE.MeshStandardMaterial({
      color: 0x78350f,
      roughness: 0.85,
      metalness: 0.15
    });
    const mastMesh = new THREE.Mesh(mastGeo, mastMat);
    mastMesh.position.set(0, 6.8, -8);
    mastMesh.castShadow = true;
    wreckGroup.add(mastMesh);

    group.add(wreckGroup);

    // Register shipwreck stunt ramp
    this.ramps.push({
      x: gCfg.x,
      z: gCfg.z,
      width: 16,
      length: 34,
      angle: 0.65,
      isShipwreckRamp: true,
      mesh: mastMesh
    });

    // Shipwreck hull collider
    this.colliders.push({
      x: gCfg.x,
      z: gCfg.z,
      radius: 18,
      type: 'dock',
      mesh: wHull
    });

    // Hidden submerged Crown Diamond Smuggle Cache inside the captain's quarters
    this._addPickup(gCfg.x, gCfg.z, 'diamond_cache');

    // 6. Jagged Coral Reef Hazard Shallows
    const coralCoords = [
      { x: -180, z: -720 },
      { x: -145, z: -715 },
      { x: -178, z: -762 },
      { x: -138, z: -758 },
      { x: -188, z: -740 },
      { x: -132, z: -736 }
    ];

    const coralMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e, // Vibrant coral reef pink/rose
      roughness: 0.82,
      metalness: 0.1
    });

    for (const c of coralCoords) {
      const cGeo = new THREE.ConeGeometry(3.6, 9.5, 7);
      const cMesh = new THREE.Mesh(cGeo, coralMat);
      cMesh.position.set(c.x, 2.8, c.z);
      cMesh.castShadow = true;
      group.add(cMesh);

      this.colliders.push({
        x: c.x,
        z: c.z,
        radius: 4.2,
        type: 'coral_rock',
        isCoral: true,
        mesh: cMesh
      });
    }

    this.scene.add(group);

    this.lighthouse = {
      x: lCfg.x,
      z: lCfg.z,
      angle: 0,
      rotationSpeed: lCfg.rotationSpeed || 0.68,
      beamLength: lCfg.beamLength || 95,
      beamRadius: lCfg.beamRadius || 28,
      beamGroup: beamGroup,
      spotLight: spotLight,
      lanternLight: lanternLight,
      turrets: turrets,
      alarmCooldown: 0,
      hornTimer: 18.0
    };
  }

  _updateLighthouse(dt, player = null, weaponManager = null) {
    if (!this.lighthouse) return;
    const lh = this.lighthouse;

    // Rotate searchlight beam
    lh.angle += lh.rotationSpeed * dt;
    if (lh.beamGroup) {
      lh.beamGroup.rotation.y = lh.angle;
    }

    // Periodic Foghorn Blast
    lh.hornTimer += dt;
    if (lh.hornTimer >= 32.0) {
      lh.hornTimer = 0;
      soundManager.playFogHorn();
    }

    // Alarm cooldown
    if (lh.alarmCooldown > 0) {
      lh.alarmCooldown -= dt;
    }

    const p = player || (window.game ? window.game.player : null);
    if (!p || !p.alive) return;

    const pdx = p.position.x - lh.x;
    const pdz = p.position.z - lh.z;
    const distToPlayer = Math.hypot(pdx, pdz);

    // Searchlight illumination check
    if (distToPlayer < lh.beamLength && distToPlayer > 12) {
      const angleToPlayer = Math.atan2(pdx, pdz);
      let diff = angleToPlayer - lh.angle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;

      // Illuminated within searchlight cone!
      if (Math.abs(diff) < 0.22) {
        if (lh.alarmCooldown <= 0) {
          lh.alarmCooldown = 4.2;
          soundManager.playSearchlightAlarm();
          if (p.addWanted) p.addWanted(1);
          if (window.game && window.game.addTrauma) window.game.addTrauma(0.25);
          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '🚨 [SENTINEL BEACON]: INTRUDER VESSEL ILLUMINATED BY LIGHTHOUSE WATCHTOWER!';
            dispatch.style.color = '#ef4444';
          }
        }
      }
    }

    // Automated Coastal Defense Turrets engage alerted targets
    const shouldEngage = (p.wantedLevel >= 2 || lh.alarmCooldown > 0) && distToPlayer <= 135;
    for (const turret of lh.turrets) {
      turret.fireTimer -= dt;
      if (shouldEngage) {
        const tdx = p.position.x - turret.x;
        const tdz = p.position.z - turret.z;
        const tAngle = Math.atan2(tdx, tdz);
        turret.mesh.rotation.y = tAngle;

        if (turret.fireTimer <= 0) {
          turret.fireTimer = 1.4;
          const wm = weaponManager || (window.game ? window.game.weaponManager : null);
          if (wm) {
            const fwdX = Math.sin(tAngle);
            const fwdZ = Math.cos(tAngle);
            wm.spawnProjectile(turret.x + fwdX * 3, 4.5, turret.z + fwdZ * 3, fwdX, fwdZ, 12, 'bullet', turret);
            soundManager.playGunfire();
          }
        }
      }
    }
  }

  _createWaterspout() {
    const cfg = CONFIG.WATERSPOUT;
    const group = new THREE.Group();

    // 1. Inner swirling funnel column (tapered upward from base to sky)
    const innerGeo = new THREE.CylinderGeometry(16.0, 3.2, 85, 16, 4, true);
    innerGeo.translate(0, 42.5, 0);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.52,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    const innerFunnel = new THREE.Mesh(innerGeo, innerMat);
    group.add(innerFunnel);

    // 2. Outer churning white spray sheath
    const outerGeo = new THREE.CylinderGeometry(22.0, 5.0, 80, 16, 4, true);
    outerGeo.translate(0, 40.0, 0);
    const outerMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.38,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    const outerFunnel = new THREE.Mesh(outerGeo, outerMat);
    group.add(outerFunnel);

    // 3. Base sea-churn spray collar on water surface
    const sprayGeo = new THREE.TorusGeometry(15.0, 3.2, 8, 24);
    sprayGeo.rotateX(Math.PI / 2);
    const sprayMat = new THREE.MeshBasicMaterial({
      color: 0xe0f2fe,
      transparent: true,
      opacity: 0.68,
      blending: THREE.AdditiveBlending
    });
    const sprayCollar = new THREE.Mesh(sprayGeo, sprayMat);
    sprayCollar.position.y = 1.2;
    group.add(sprayCollar);

    // 4. Overhead storm cloud connector
    const cloudGeo = new THREE.SphereGeometry(24, 10, 8);
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.95,
      metalness: 0.05
    });
    const stormCloud = new THREE.Mesh(cloudGeo, cloudMat);
    stormCloud.position.y = 85.0;
    stormCloud.scale.set(1.5, 0.6, 1.5);
    group.add(stormCloud);

    // 5. Dynamic vortex core light
    const light = new THREE.PointLight(0x00f2fe, 3.5, 55);
    light.position.y = 6.0;
    group.add(light);

    group.position.set(cfg.x, 0, cfg.z);
    this.scene.add(group);

    this.waterspout = {
      x: cfg.x,
      z: cfg.z,
      baseX: cfg.x,
      baseZ: cfg.z,
      wanderTime: 0,
      radius: cfg.radius || 55,
      coreRadius: cfg.coreRadius || 11,
      suctionForce: cfg.suctionForce || 26,
      swirlSpeed: cfg.swirlSpeed || 34,
      launchVelo: cfg.launchVelo || 52,
      mesh: group,
      funnelInner: innerFunnel,
      funnelOuter: outerFunnel,
      sprayCollar: sprayCollar,
      light: light
    };
  }

  _updateWaterspout(dt, player = null) {
    if (!this.waterspout) return;
    const ws = this.waterspout;

    // Slow organic wander across the channel
    ws.wanderTime += dt * 0.45;
    ws.x = ws.baseX + Math.sin(ws.wanderTime * 0.8) * 45;
    ws.z = ws.baseZ + Math.cos(ws.wanderTime * 0.6) * 35;
    ws.mesh.position.set(ws.x, 0, ws.z);

    // Visual cyclone rotation
    ws.funnelInner.rotation.y += dt * 6.5;
    ws.funnelOuter.rotation.y -= dt * 4.2;
    ws.sprayCollar.rotation.z += dt * 7.5;

    // Water height bobbing
    const wave = this.getWaveHeight(ws.x, ws.z);
    ws.sprayCollar.position.y = 1.2 + wave;

    const p = player || (window.game ? window.game.player : null);
    if (p && p.alive) {
      const pdx = ws.x - p.position.x;
      const pdz = ws.z - p.position.z;
      const dist = Math.hypot(pdx, pdz);

      if (dist < ws.radius && dist > 0.1) {
        const factor = 1.0 - dist / ws.radius;
        const nx = pdx / dist;
        const nz = pdz / dist;

        // Centripetal inward suction pull
        const pull = factor * ws.suctionForce * dt;
        p.velocity.x += nx * pull;
        p.velocity.z += nz * pull;

        // Tangential whirlpool swirl torque
        const perpX = -nz;
        const perpZ = nx;
        const swirl = factor * ws.swirlSpeed * dt;
        p.velocity.x += perpX * swirl;
        p.velocity.z += perpZ * swirl;

        // Cyclonic screenshake trauma
        if (window.game && window.game.addTrauma && Math.random() < 0.3) {
          window.game.addTrauma(0.08 * factor);
        }

        // Waterspout Core Launch Updraft!
        if (dist < ws.coreRadius && !p.isAirborne) {
          p.isAirborne = true;
          p.verticalVelocity = ws.launchVelo;
          p.airTime = 0;
          p.peakJumpHeight = 0;
          p.airborneRollAccum = 0;
          p.didBarrelRoll = false;
          p.currentRamp = { isWaterspout: true };
          soundManager.playWaterspoutRoar();
          if (p.triggerStunt) {
            p.triggerStunt('🌪️ WATERSPOUT VORTEX LAUNCH! +1350 PTS', CONFIG.WATERSPOUT.stuntScore || 1350, 4.5);
          }
          if (window.game && window.game.addTrauma) {
            window.game.addTrauma(0.75);
          }
          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '🌪️ [CYCLONIC UPDRAFT]: Speedboat sucked into the eye of the marine waterspout!';
            dispatch.style.color = '#38bdf8';
          }
        }
      }
    }

    // Hostile enemy boat suction and violent airborne toss
    if (window.game && window.game.factionManager) {
      for (const enemy of window.game.factionManager.enemies) {
        if (!enemy.alive) continue;
        const edx = ws.x - enemy.position.x;
        const edz = ws.z - enemy.position.z;
        const edist = Math.hypot(edx, edz);

        if (edist < ws.radius && edist > 0.1) {
          const efactor = 1.0 - edist / ws.radius;
          const enx = edx / edist;
          const enz = edz / edist;

          enemy.velocity.x += enx * efactor * ws.suctionForce * dt;
          enemy.velocity.z += enz * efactor * ws.suctionForce * dt;

          // Tangential swirl
          enemy.velocity.x += -enz * efactor * ws.swirlSpeed * dt;
          enemy.velocity.z += enx * efactor * ws.swirlSpeed * dt;

          if (edist < ws.coreRadius) {
            enemy.takeDamage(45 * dt * 2.0, p);
            enemy.position.y = Math.min(28, enemy.position.y + 35 * dt);
            if (enemy.spinVelocity !== undefined) {
              enemy.spinVelocity = 22.0;
            }
            if (Math.random() < 0.25) {
              this.spawnVoxelCrumbles(enemy.position.x, 3.5, enemy.position.z, 8, 0x38bdf8);
              this.spawnVoxelCrumbles(enemy.position.x, 3.5, enemy.position.z, 6, 0xffffff);
            }
          }
        }
      }
    }
  }

  _createCasinoPalace() {
    const cfg = CONFIG.CASINO || { x: 520, z: -180 };
    const group = new THREE.Group();

    // 1. Massive Twin Catamaran Pontoons (Port & Starboard)
    const pontoonGeo = new THREE.BoxGeometry(14, 6.5, 115);
    const pontoonMat = new THREE.MeshStandardMaterial({
      color: 0x090d16, // Onyx navy
      roughness: 0.5,
      metalness: 0.6
    });

    const bootStripeGeo = new THREE.BoxGeometry(14.4, 0.8, 114.5);
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.25,
      metalness: 0.85
    });

    // Port Pontoon (x: -24)
    const pPort = new THREE.Mesh(pontoonGeo, pontoonMat);
    pPort.position.set(-24, 2.5, 0);
    pPort.castShadow = true;
    group.add(pPort);
    const sPort = new THREE.Mesh(bootStripeGeo, goldMat);
    sPort.position.set(-24, 3.2, 0);
    group.add(sPort);

    // Starboard Pontoon (x: +24)
    const pStbd = new THREE.Mesh(pontoonGeo, pontoonMat);
    pStbd.position.set(24, 2.5, 0);
    pStbd.castShadow = true;
    group.add(pStbd);
    const sStbd = new THREE.Mesh(bootStripeGeo, goldMat);
    sStbd.position.set(24, 3.2, 0);
    group.add(sStbd);

    // Add colliders for the mega-pontoons
    this.colliders.push({ x: cfg.x - 24, z: cfg.z, radius: 28, type: 'casino_hull' });
    this.colliders.push({ x: cfg.x + 24, z: cfg.z, radius: 28, type: 'casino_hull' });
    this.colliders.push({ x: cfg.x - 24, z: cfg.z - 35, radius: 22, type: 'casino_hull' });
    this.colliders.push({ x: cfg.x + 24, z: cfg.z - 35, radius: 22, type: 'casino_hull' });
    this.colliders.push({ x: cfg.x - 24, z: cfg.z + 35, radius: 22, type: 'casino_hull' });
    this.colliders.push({ x: cfg.x + 24, z: cfg.z + 35, radius: 22, type: 'casino_hull' });

    // 2. Main Promenade Gaming Deck
    const deckGeo = new THREE.BoxGeometry(62, 3.2, 100);
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.7,
      metalness: 0.3
    });
    const mainDeck = new THREE.Mesh(deckGeo, deckMat);
    mainDeck.position.set(0, 5.2, -5);
    mainDeck.castShadow = true;
    group.add(mainDeck);

    // 3. Lower Gaming Salon with Illuminated Cyan Windows
    const salonGeo = new THREE.BoxGeometry(48, 5.5, 78);
    const salonMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.2,
      metalness: 0.4,
      transparent: true,
      opacity: 0.75
    });
    const salon = new THREE.Mesh(salonGeo, salonMat);
    salon.position.set(0, 9.5, -8);
    salon.castShadow = true;
    group.add(salon);

    // Salon interior golden gaming glow
    const salonGlow = new THREE.PointLight(0xfbbf24, 2.5, 45);
    salonGlow.position.set(0, 9.5, -8);
    group.add(salonGlow);

    // 4. VIP Penthouse Superstructure
    const penthouseGeo = new THREE.BoxGeometry(34, 4.5, 52);
    const penthouseMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.4,
      metalness: 0.7
    });
    const penthouse = new THREE.Mesh(penthouseGeo, penthouseMat);
    penthouse.position.set(0, 14.5, -12);
    penthouse.castShadow = true;
    group.add(penthouse);

    // 5. Rooftop Helipad with Stunt Ramp
    const helipadGeo = new THREE.BoxGeometry(26, 1.2, 26);
    const helipadMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.8
    });
    const helipad = new THREE.Mesh(helipadGeo, helipadMat);
    helipad.position.set(0, 17.0, -22);
    group.add(helipad);

    // Helipad yellow perimeter ring
    const hRingGeo = new THREE.TorusGeometry(10, 0.4, 8, 24);
    hRingGeo.rotateX(Math.PI / 2);
    const yellowMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const hRing = new THREE.Mesh(hRingGeo, yellowMat);
    hRing.position.set(0, 17.7, -22);
    group.add(hRing);

    // Helipad 'H' Marking
    const hBarGeo = new THREE.BoxGeometry(2.0, 0.1, 10.0);
    const hBar1 = new THREE.Mesh(hBarGeo, yellowMat);
    hBar1.position.set(-3.5, 17.7, -22);
    group.add(hBar1);
    const hBar2 = new THREE.Mesh(hBarGeo, yellowMat);
    hBar2.position.set(3.5, 17.7, -22);
    group.add(hBar2);
    const hCrossGeo = new THREE.BoxGeometry(5.0, 0.1, 2.0);
    const hCross = new THREE.Mesh(hCrossGeo, yellowMat);
    hCross.position.set(0, 17.7, -22);
    group.add(hCross);

    // Helipad Rooftop Stunt Jump Ramp (pointing North)
    const heliRampWidth = 18;
    const heliRampLength = 28;
    const heliRampGeo = new THREE.BoxGeometry(heliRampWidth, 1.4, heliRampLength);
    const heliRampMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4, metalness: 0.4 });
    const heliRampMesh = new THREE.Mesh(heliRampGeo, heliRampMat);
    heliRampMesh.position.set(0, 17.8, -38);
    heliRampMesh.rotation.x = -0.32;
    group.add(heliRampMesh);

    this.ramps.push({
      x: cfg.x,
      z: cfg.z - 25,
      width: heliRampWidth,
      length: heliRampLength,
      angle: Math.PI,
      mesh: heliRampMesh,
      isCasinoHelipadRamp: true,
      boostFactor: cfg.helipadRampBoost || 1.60
    });

    // 6. Glowing Animated Neon Marquee Sign
    const signGroup = new THREE.Group();
    const signFrameGeo = new THREE.BoxGeometry(32, 5.0, 1.8);
    const signFrameMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.8 });
    const signFrame = new THREE.Mesh(signFrameGeo, signFrameMat);
    signGroup.add(signFrame);

    // Neon tubes
    const neonMagentaGeo = new THREE.BoxGeometry(29, 1.4, 0.6);
    const neonMagentaMat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    const neonMagenta = new THREE.Mesh(neonMagentaGeo, neonMagentaMat);
    neonMagenta.position.set(0, 1.2, 1.0);
    signGroup.add(neonMagenta);

    const neonCyanGeo = new THREE.BoxGeometry(29, 1.4, 0.6);
    const neonCyanMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const neonCyan = new THREE.Mesh(neonCyanGeo, neonCyanMat);
    neonCyan.position.set(0, -1.2, 1.0);
    signGroup.add(neonCyan);

    const signLight = new THREE.PointLight(0xec4899, 3.5, 45);
    signLight.position.set(0, 0, 4.0);
    signGroup.add(signLight);

    signGroup.position.set(0, 18.0, 14);
    group.add(signGroup);

    // 7. Southern Grand Entrance Canal Fountain & Stunt Launch Ramp
    const fountainGroup = new THREE.Group();
    const basinGeo = new THREE.TorusGeometry(10, 1.8, 8, 24);
    basinGeo.rotateX(Math.PI / 2);
    const basinMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.3, metalness: 0.5 });
    const basin = new THREE.Mesh(basinGeo, basinMat);
    basin.position.y = 1.6;
    fountainGroup.add(basin);

    // Fountain water jet plume
    const jetGeo = new THREE.ConeGeometry(2.4, 12, 12, 1, true);
    const jetMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.72,
      side: THREE.DoubleSide
    });
    const jet = new THREE.Mesh(jetGeo, jetMat);
    jet.position.y = 7.0;
    fountainGroup.add(jet);

    const fountainLight = new THREE.PointLight(0x00f2fe, 3.0, 24);
    fountainLight.position.y = 4.0;
    fountainGroup.add(fountainLight);

    // Marble Stunt Ramp launching boats into the casino promenade
    const fRampWidth = 16;
    const fRampLength = 32;
    const fRampGeo = new THREE.BoxGeometry(fRampWidth, 1.6, fRampLength);
    const fRampMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.3, metalness: 0.2 });
    const fRampMesh = new THREE.Mesh(fRampGeo, fRampMat);
    fRampMesh.position.set(0, 3.8, 22);
    fRampMesh.rotation.x = 0.30;
    fRampMesh.castShadow = true;
    fountainGroup.add(fRampMesh);

    fountainGroup.position.set(0, 0, 58);
    group.add(fountainGroup);

    this.ramps.push({
      x: cfg.x,
      z: cfg.z + 58,
      width: fRampWidth,
      length: fRampLength,
      angle: 0,
      mesh: fRampMesh,
      isCasinoFountainRamp: true,
      boostFactor: cfg.fountainRampBoost || 1.52
    });

    // 8. Docked Luxury Superyachts (Starboard & Port Slips)
    // Yacht 1 (Starboard slip at x: +44, z: 12)
    const yacht1 = this._buildSuperyachtMesh(0x0f172a, 0xf59e0b);
    yacht1.position.set(44, 1.8, 12);
    yacht1.rotation.y = 0.12;
    group.add(yacht1);
    this.colliders.push({ x: cfg.x + 44, z: cfg.z + 12, radius: 18, type: 'yacht' });

    // Yacht 2 (Port slip at x: -44, z: -15)
    const yacht2 = this._buildSuperyachtMesh(0xf8fafc, 0x0284c7);
    yacht2.position.set(-44, 1.8, -15);
    yacht2.rotation.y = -0.12;
    group.add(yacht2);
    this.colliders.push({ x: cfg.x - 44, z: cfg.z - 15, radius: 18, type: 'yacht' });

    group.position.set(cfg.x, 0, cfg.z);
    this.scene.add(group);

    // 9. Flanking Grapple Mooring Dolphins with Neon Rings
    const dolphinGeo = new THREE.CylinderGeometry(2.8, 3.4, 14, 12);
    const dolphinMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8, metalness: 0.3 });
    const gdRingMat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    const gdRingGeo = new THREE.TorusGeometry(3.6, 0.45, 8, 20);
    gdRingGeo.rotateX(Math.PI / 2);

    for (const dOffset of [{ x: -48, z: 65 }, { x: 48, z: 65 }]) {
      const dGroup = new THREE.Group();
      const pile = new THREE.Mesh(dolphinGeo, dolphinMat);
      pile.position.y = 5.0;
      dGroup.add(pile);
      const ring = new THREE.Mesh(gdRingGeo, gdRingMat.clone());
      ring.position.y = 11.2;
      dGroup.add(ring);
      dGroup.position.set(cfg.x + dOffset.x, 0, cfg.z + dOffset.z);
      this.scene.add(dGroup);

      this.grappleDolphins.push({ x: cfg.x + dOffset.x, z: cfg.z + dOffset.z, mesh: dGroup, ring });
      this.colliders.push({ x: cfg.x + dOffset.x, z: cfg.z + dOffset.z, radius: 4.0, type: 'dolphin' });
    }

    // 10. High-Stakes Diamond Vault Pickup on the Casino Promenade
    this.spawnCasinoVault(cfg.x, cfg.z);

    this.casino = {
      x: cfg.x,
      z: cfg.z,
      width: cfg.width || 58,
      length: cfg.length || 110,
      mesh: group,
      signGroup,
      signLight,
      fountainLight,
      jet,
      entered: false
    };
  }

  _buildSuperyachtMesh(hullColor = 0x0f172a, trimColor = 0xf59e0b) {
    const yachtGroup = new THREE.Group();

    // 1. Sleek Monohull
    const hullGeo = new THREE.BoxGeometry(11, 4.5, 34);
    const hullMat = new THREE.MeshStandardMaterial({ color: hullColor, roughness: 0.4, metalness: 0.5 });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 2.0;
    hull.castShadow = true;
    yachtGroup.add(hull);

    // Teak Sun Deck
    const deckGeo = new THREE.BoxGeometry(10.2, 0.4, 32);
    const deckMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const deck = new THREE.Mesh(deckGeo, deckMat);
    deck.position.y = 4.4;
    yachtGroup.add(deck);

    // Bridge / Flybridge
    const bridgeGeo = new THREE.BoxGeometry(7.5, 3.2, 14);
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2 });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, 6.0, -2);
    bridge.castShadow = true;
    yachtGroup.add(bridge);

    // Tinted windscreen
    const screenGeo = new THREE.BoxGeometry(7.0, 1.6, 3.2);
    const screenMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, transparent: true, opacity: 0.7 });
    const screen = new THREE.Mesh(screenGeo, screenMat);
    screen.position.set(0, 7.8, 2.5);
    yachtGroup.add(screen);

    // Radar arch
    const archGeo = new THREE.BoxGeometry(6.5, 2.8, 1.2);
    const arch = new THREE.Mesh(archGeo, bridgeMat);
    arch.position.set(0, 8.8, -6);
    yachtGroup.add(arch);

    // Waterline gold boot stripe
    const bootGeo = new THREE.BoxGeometry(11.2, 0.4, 33.6);
    const boot = new THREE.Mesh(bootGeo, new THREE.MeshStandardMaterial({ color: trimColor, metalness: 0.8 }));
    boot.position.y = 1.2;
    yachtGroup.add(boot);

    return yachtGroup;
  }

  _updateCasino(dt, player = null) {
    if (!this.casino) return;
    const c = this.casino;

    // Animated marquee sign color pulsing
    const t = this.waterTime || 0;
    if (c.signLight) {
      c.signLight.intensity = 2.8 + Math.sin(t * 8) * 0.8;
      const hue = (t * 0.2) % 1.0;
      c.signLight.color.setHSL(hue, 0.9, 0.55);
    }

    // Fountain water jet pulse
    if (c.jet) {
      const s = 1.0 + Math.sin(t * 5) * 0.15;
      c.jet.scale.set(s, 1.0 + Math.sin(t * 4) * 0.2, s);
    }
    if (c.fountainLight) {
      c.fountainLight.intensity = 2.4 + Math.sin(t * 6) * 0.8;
    }

    // First-time infiltration trigger
    const p = player || (window.game ? window.game.player : null);
    if (p && p.alive && !c.entered) {
      const dx = p.position.x - c.x;
      const dz = p.position.z - c.z;
      if (dx * dx + dz * dz < 52 * 52) {
        c.entered = true;
        soundManager.playAlertPing();
        if (p.triggerStunt) {
          p.triggerStunt('🎰 GRAND POSEIDON CASINO INFILTRATION! +850 PTS', 850, 4.0);
        }
        const dispatch = document.getElementById('dispatch-msg');
        if (dispatch) {
          dispatch.innerText = '🎰 [MARINA DISPATCH]: Suspect vessel identified cruising Grand Poseidon Casino waters!';
          dispatch.style.color = '#f59e0b';
        }
      }
    }
  }

  _createRoadblocks() {
    // 5 floating police boom barrier checkpoints across key canal thoroughfares
    const configs = [
      { x: -720, z: -580, width: 38, angle: 0.82 },  // Police Marina exit
      { x: -480, z: -250, width: 34, angle: 0.25 },  // Highway Bridge approach
      { x: -220, z: 240, width: 36, angle: -0.42 }, // Mangrove Canals entrance
      { x: 520, z: 640, width: 38, angle: 0.65 },   // Industrial Docks canal
      { x: -50, z: 180, width: 36, angle: 0.0 }     // Central Bay narrows
    ];

    const postGeo = new THREE.CylinderGeometry(2.0, 2.6, 7.5, 10);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6, metalness: 0.6 });

    const strobeGeo = new THREE.SphereGeometry(0.85, 8, 8);
    const redStrobeMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.9 });
    const blueStrobeMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe, transparent: true, opacity: 0.9 });

    const beamGeo = new THREE.BoxGeometry(1, 2.2, 2.2);
    const beamMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.5,
      metalness: 0.3
    });

    const hazardStripeMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.8
    });

    for (const cfg of configs) {
      const group = new THREE.Group();
      const halfW = cfg.width * 0.5;

      // 1. End anchor posts (strobe beacons mounted on top)
      const postLeft = new THREE.Mesh(postGeo, postMat);
      postLeft.position.set(-halfW, 2.2, 0);
      postLeft.castShadow = true;
      group.add(postLeft);

      const strobeLeft = new THREE.Mesh(strobeGeo, redStrobeMat.clone());
      strobeLeft.position.set(-halfW, 6.2, 0);
      group.add(strobeLeft);

      const postRight = new THREE.Mesh(postGeo, postMat);
      postRight.position.set(halfW, 2.2, 0);
      postRight.castShadow = true;
      group.add(postRight);

      const strobeRight = new THREE.Mesh(strobeGeo, blueStrobeMat.clone());
      strobeRight.position.set(halfW, 6.2, 0);
      group.add(strobeRight);

      // Register post positions in colliders for collision and grapple anchoring
      const cosA = Math.cos(cfg.angle);
      const sinA = Math.sin(cfg.angle);
      this.colliders.push({
        x: cfg.x - cosA * halfW,
        z: cfg.z + sinA * halfW,
        radius: 3.0,
        type: 'roadblock_post'
      });
      this.colliders.push({
        x: cfg.x + cosA * halfW,
        z: cfg.z - sinA * halfW,
        radius: 3.0,
        type: 'roadblock_post'
      });

      // 2. Destructible Floating Boom Barrier Beams (disappears on ramming!)
      const barrierGroup = new THREE.Group();

      const mainBeam = new THREE.Mesh(beamGeo, beamMat);
      mainBeam.scale.set(cfg.width - 4.5, 1, 1);
      mainBeam.position.set(0, 1.6, 0);
      mainBeam.castShadow = true;
      barrierGroup.add(mainBeam);

      const numStripes = Math.floor(cfg.width / 5.5);
      for (let s = -numStripes / 2; s <= numStripes / 2; s++) {
        const stripeGeo = new THREE.BoxGeometry(2.0, 2.3, 2.3);
        const stripe = new THREE.Mesh(stripeGeo, hazardStripeMat);
        stripe.position.set(s * 5.2, 1.6, 0);
        barrierGroup.add(stripe);
      }

      const spikeGeo = new THREE.ConeGeometry(0.55, 1.8, 5);
      spikeGeo.rotateX(Math.PI / 2);
      const spikeMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 });
      for (let sp = -numStripes / 2; sp <= numStripes / 2; sp++) {
        const spike = new THREE.Mesh(spikeGeo, spikeMat);
        spike.position.set(sp * 5.2, 1.6, 1.3);
        barrierGroup.add(spike);
      }

      group.add(barrierGroup);

      group.position.set(cfg.x, 0, cfg.z);
      group.rotation.y = cfg.angle;
      this.scene.add(group);

      this.roadblocks.push({
        x: cfg.x,
        z: cfg.z,
        width: cfg.width,
        angle: cfg.angle,
        mesh: group,
        barrierBeamsMesh: barrierGroup,
        strobeRed: strobeLeft,
        strobeBlue: strobeRight,
        alive: true
      });
    }
  }

  _createGrappleDolphins() {
    // High-visibility mooring dolphins with cyan neon rings at hairpin canal corners
    const dolphinCoords = [
      { x: -580, z: -380 },
      { x: -150, z: 420 },
      { x: -380, z: 200 },
      { x: 720, z: 680 },
      { x: 820, z: -520 },
      { x: -120, z: 620 },
      { x: 120, z: -160 },
      { x: -180, z: -120 }
    ];

    const dolphinGeo = new THREE.CylinderGeometry(2.8, 3.4, 14, 12);
    const dolphinMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8, metalness: 0.3 });

    const ringGeo = new THREE.TorusGeometry(3.6, 0.45, 8, 20);
    ringGeo.rotateX(Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });

    for (const c of dolphinCoords) {
      const group = new THREE.Group();

      const pile = new THREE.Mesh(dolphinGeo, dolphinMat);
      pile.position.y = 5.0;
      pile.castShadow = true;
      group.add(pile);

      const ring = new THREE.Mesh(ringGeo, ringMat.clone());
      ring.position.y = 11.2;
      group.add(ring);

      group.position.set(c.x, 0, c.z);
      this.scene.add(group);

      this.grappleDolphins.push({ x: c.x, z: c.z, mesh: group, ring });
      this.colliders.push({ x: c.x, z: c.z, radius: 4.0, type: 'dolphin' });
    }
  }

  spawnVoxelCrumbles(x, y, z, count = 16, colorHex = 0xf59e0b) {
    if (this.debris) {
      this.debris.spawn(x, y, z, count, colorHex);
    }
  }

  _initSquallSystem() {
    // 1. Instanced Rain Particle Streaks (450 raindrops falling in 280x280 box around player)
    const rainCount = 450;
    const rainGeo = new THREE.CylinderGeometry(0.04, 0.04, 3.8, 4);
    const rainMat = new THREE.MeshBasicMaterial({
      color: 0x93c5fd,
      transparent: true,
      opacity: 0.65,
      depthWrite: false
    });
    this.rainMesh = new THREE.InstancedMesh(rainGeo, rainMat, rainCount);
    this.rainMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.rainMesh.visible = false;
    this.scene.add(this.rainMesh);

    this.rainData = [];
    const dummy = new THREE.Object3D();
    for (let i = 0; i < rainCount; i++) {
      const rx = (Math.random() - 0.5) * 280;
      const rz = (Math.random() - 0.5) * 280;
      const ry = Math.random() * 85;
      const speed = 130 + Math.random() * 40;
      this.rainData.push({ rx, rz, y: ry, speed });
      dummy.position.set(rx, ry, rz);
      dummy.updateMatrix();
      this.rainMesh.setMatrixAt(i, dummy.matrix);
    }
    this.rainMesh.instanceMatrix.needsUpdate = true;

    // 2. Lightning Flash Light
    const lightningLight = new THREE.DirectionalLight(0xe0f2fe, 0.0);
    lightningLight.position.set(50, 300, 50);
    this.scene.add(lightningLight);
    this.lightningLight = lightningLight;
  }

  update(dt, player = null, weaponManager = null) {
    this.waterTime += dt;

    // Voxel physics debris
    if (this.debris) {
      this.debris.update(dt, this);
    }

    // Searchlights
    for (const sl of this.searchlights) {
      sl.angle += sl.speed * dt;
      sl.mesh.rotation.y = sl.angle;
    }

    // Destructible crates bobbing on waves
    for (const d of this.destructibles) {
      if (d.alive) {
        const wave = this.getWaveHeight(d.x, d.z);
        d.mesh.position.y = 1.6 + wave;
      }
    }

    // Buoys bobbing
    for (const b of this.buoys) {
      const wave = this.getWaveHeight(b.x, b.z);
      b.mesh.position.y = b.baseY + wave;
      b.mesh.rotation.z = Math.sin(this.waterTime * 2 + b.phase) * 0.12;
      b.mesh.rotation.x = Math.cos(this.waterTime * 1.8 + b.phase) * 0.12;
    }

    // Pickups rotating & bobbing
    for (const p of this.pickups) {
      if (p.alive) {
        p.mesh.rotation.y += p.rotSpeed * dt;
        const wave = this.getWaveHeight(p.x, p.z);
        p.mesh.position.y = 2.5 + wave + Math.sin(this.waterTime * 3) * 0.5;
        if (p.gem) {
          p.gem.rotation.y += dt * 2.8;
          p.gem.rotation.x += dt * 1.4;
        }
        if (p.ring1) p.ring1.rotation.z += dt * 2.0;
        if (p.ring2) p.ring2.rotation.x += dt * 2.2;
      }
    }

    // Horned Naval Mines wave bobbing & beacon flashing
    for (const m of this.mines) {
      if (m.alive) {
        const wave = this.getWaveHeight(m.x, m.z);
        m.mesh.position.y = m.baseY + wave + Math.sin(this.waterTime * 2.2 + m.phase) * 0.25;
        if (m.beaconMesh) {
          m.beaconMesh.material.opacity = Math.sin(this.waterTime * 9 + m.phase) > 0 ? 1.0 : 0.2;
        }
      }
    }

    // Safe Haven pulse
    if (this.safeHavenBeacon) {
      this.safeHavenBeacon.rotation.z += dt * 0.5;
      const s = 1.0 + Math.sin(this.waterTime * 3) * 0.08;
      this.safeHavenBeacon.scale.set(s, s, s);
    }

    // Moving mega-freighter patrol
    if (this.movingFreighter) {
      this._updateMovingFreighter(dt);
    }

    // Roadblock strobes & wave bobbing
    for (const rb of this.roadblocks) {
      if (rb.alive) {
        const wave = this.getWaveHeight(rb.x, rb.z);
        rb.mesh.position.y = wave;
        const strobeState = Math.sin(this.waterTime * 14) > 0;
        if (rb.strobeRed && rb.strobeBlue) {
          rb.strobeRed.material.opacity = strobeState ? 1.0 : 0.15;
          rb.strobeBlue.material.opacity = !strobeState ? 1.0 : 0.15;
        }
      }
    }

    // Grapple dolphin pulsing
    for (const gd of this.grappleDolphins) {
      if (gd.ring) {
        const s = 1.0 + Math.sin(this.waterTime * 4) * 0.08;
        gd.ring.scale.set(s, s, s);
      }
    }

    // Offshore Oil Rig flare flame flicker and derrick warning beacon
    if (this.oilRig) {
      if (this.oilRig.flareLight && this.oilRig.flareMesh) {
        const flicker = 0.82 + Math.sin(this.waterTime * 16) * 0.18 + (Math.random() - 0.5) * 0.12;
        this.oilRig.flareLight.intensity = 3.2 * flicker;
        this.oilRig.flareMesh.scale.set(flicker, 1.0 + (flicker - 1.0) * 0.5, flicker);
      }
      if (this.oilRig.derrickBeacon && this.oilRig.derrickLight) {
        const strobe = Math.sin(this.waterTime * 7) > 0 ? 1.0 : 0.2;
        this.oilRig.derrickBeacon.material.opacity = strobe;
        this.oilRig.derrickLight.intensity = strobe * 2.0;
      }
    }

    // Secret Submarine Pen Cavern Dock Infiltration & Propeller Turn
    if (this.subPen) {
      if (this.subPen.propMesh) {
        this.subPen.propMesh.rotation.z += dt * 1.8;
      }
      if (this.subPen.dockBeacon) {
        const penStrobe = Math.sin(this.waterTime * 8) > 0;
        this.subPen.dockBeacon.material.opacity = penStrobe ? 1.0 : 0.2;
      }
      if (player && player.alive && !this.subPen.entered) {
        const pdx = player.position.x - this.subPen.x;
        const pdz = player.position.z - this.subPen.z;
        if (pdx * pdx + pdz * pdz < 44 * 44) {
          this.subPen.entered = true;
          soundManager.playSonarPing();
          if (player.triggerStunt) {
            player.triggerStunt('⚓ SECRET SUB PEN INFILTRATION! +950 PTS', 950, 4.0);
          }
          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '⚓ [CODE RED DISPATCH]: Intrusion at Submarine Pen Zulu! Prototype Railgun armed!';
            dispatch.style.color = '#00f2fe';
          }
        }
      }
    }

    // Naval Supercarrier "USS Leviathan" Radar Rotation & Strobe
    if (this.carrier) {
      if (this.carrier.radarDish) {
        this.carrier.radarDish.rotation.y += dt * 2.5;
      }
      if (this.carrier.beaconMesh && this.carrier.beaconLight) {
        const cStrobe = Math.sin(this.waterTime * 6) > 0;
        this.carrier.beaconMesh.material.opacity = cStrobe ? 1.0 : 0.2;
        this.carrier.beaconLight.intensity = cStrobe ? 2.8 : 0.4;
      }
    }

    // Floating Seaplane Hangar Infiltration & Propeller Idle
    if (this.seaplaneHangar) {
      if (this.seaplaneHangar.propLeft) this.seaplaneHangar.propLeft.rotation.z += dt * 3.5;
      if (this.seaplaneHangar.propRight) this.seaplaneHangar.propRight.rotation.z += dt * 3.5;
      if (player && player.alive && !this.seaplaneHangar.entered) {
        const hdx = player.position.x - this.seaplaneHangar.x;
        const hdz = player.position.z - this.seaplaneHangar.z;
        if (hdx * hdx + hdz * hdz < 34 * 34) {
          this.seaplaneHangar.entered = true;
          soundManager.playAlertPing();
          if (player.triggerStunt) {
            player.triggerStunt('✈️ SEAPLANE HANGAR INFILTRATION! +850 PTS', 850, 4.0);
          }
          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '✈️ [AIR-SEA DISPATCH]: Unidentified speedboat entered Seaplane Slipway 2!';
            dispatch.style.color = '#38bdf8';
          }
        }
      }
    }

    // Smuggler's Sea Arch Cavern & Slalom Spire Channel Infiltration
    if (this.seaArch && player && player.alive && !this.seaArch.entered) {
      const adx = player.position.x - this.seaArch.x;
      const adz = player.position.z - this.seaArch.z;
      if (adx * adx + adz * adz < 32 * 32) {
        this.seaArch.entered = true;
        soundManager.playAlertPing();
        if (player.triggerStunt) {
          player.triggerStunt('🗿 SEA ARCH SLALOM! +800 PTS', CONFIG.SEA_ARCH.stuntScore || 800, 3.5);
        }
        const dispatch = document.getElementById('dispatch-msg');
        if (dispatch) {
          dispatch.innerText = '🗿 [CHASM NAVIGATED]: Speedboat threaded the Smuggler\'s Sea Arch!';
          dispatch.style.color = '#38bdf8';
        }
      }
    }

    // Dynamic Rogue Tidal Wave Surge Advance & Impact
    this._updateRogueWave(dt, player);

    // Sentinel Lighthouse Rotating Searchlight & Coastal Defense Turrets
    this._updateLighthouse(dt, player, weaponManager);

    // Dynamic Marine Waterspout Tornado Vortex Hazard
    this._updateWaterspout(dt, player);

    // Floating Offshore Casino Palace & Marina
    this._updateCasino(dt, player);

    // Surface Oil Fire Hazards Update
    for (let fIdx = this.fireHazards.length - 1; fIdx >= 0; fIdx--) {
      const f = this.fireHazards[fIdx];
      f.life += dt;
      if (f.life >= f.maxLife) {
        this.scene.remove(f.mesh);
        this.fireHazards.splice(fIdx, 1);
        continue;
      }

      // Fire flicker
      const flicker = 0.8 + Math.sin(this.waterTime * 22 + fIdx) * 0.2 + (Math.random() - 0.5) * 0.15;
      if (f.light) f.light.intensity = 3.2 * flicker;
      f.mesh.scale.set(flicker, 1.0 + (flicker - 1.0) * 0.6, flicker);

      // Emitting flame/smoke voxels
      if (Math.random() < 0.35) {
        this.spawnVoxelCrumbles(f.x + (Math.random() - 0.5) * 8, 3.0, f.z + (Math.random() - 0.5) * 8, 2, 0xef4444);
        this.spawnVoxelCrumbles(f.x + (Math.random() - 0.5) * 8, 4.5, f.z + (Math.random() - 0.5) * 8, 1, 0x18181b);
      }

      // Damage enemies entering flame corridor
      if (window.game && window.game.factionManager) {
        for (const enemy of window.game.factionManager.enemies) {
          if (enemy.alive) {
            const ed = Math.hypot(enemy.position.x - f.x, enemy.position.z - f.z);
            if (ed < f.radius) {
              enemy.takeDamage(35 * dt, player);
              if (Math.random() < 0.25) {
                this.spawnVoxelCrumbles(enemy.position.x, 2.5, enemy.position.z, 2, 0xef4444);
              }
            }
          }
        }
      }

      // Damage player if entering flame corridor without Nanite Shield
      if (player && player.alive) {
        const pd = Math.hypot(player.position.x - f.x, player.position.z - f.z);
        if (pd < f.radius) {
          if (!player.naniteShieldTimer || player.naniteShieldTimer <= 0) {
            player.takeDamage(12 * dt);
          }
        }
      }
    }

    // Dynamic Tropical Squall & Weather Swells
    this.squallTimer += dt;
    if (!this.isSquallActive && this.squallTimer > 75) {
      this.isSquallActive = true;
      if (this.rainMesh) this.rainMesh.visible = true;
      soundManager.playThunder();
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '⚠️ [WEATHER ADVISORY]: SEVERE TROPICAL SQUALL MOVING OVER WATERWAYS!';
        dispatch.style.color = '#f59e0b';
      }
    } else if (this.isSquallActive && this.squallTimer > 105) {
      this.isSquallActive = false;
      if (this.rainMesh) this.rainMesh.visible = false;
      this.squallTimer = 0;
      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '☀️ SQUALL CLEARED: TROPICAL WATERS RETURNING TO CALM.';
        dispatch.style.color = '#10b981';
      }
    }

    const targetWaveMul = this.isSquallActive ? 2.15 : 1.0;
    this.stormWaveMultiplier = THREE.MathUtils.lerp(this.stormWaveMultiplier, targetWaveMul, dt * 0.45);

    // Rain particles centered around player
    if (this.isSquallActive && this.rainMesh && window.game && window.game.player) {
      const px = window.game.player.position.x;
      const pz = window.game.player.position.z;
      const dummy = new THREE.Object3D();

      for (let i = 0; i < this.rainData.length; i++) {
        const r = this.rainData[i];
        r.y -= r.speed * dt;
        if (r.y <= 0) {
          r.y = 75 + Math.random() * 15;
          r.rx = (Math.random() - 0.5) * 280;
          r.rz = (Math.random() - 0.5) * 280;
        }
        dummy.position.set(px + r.rx, r.y, pz + r.rz);
        dummy.updateMatrix();
        this.rainMesh.setMatrixAt(i, dummy.matrix);
      }
      this.rainMesh.instanceMatrix.needsUpdate = true;

      // Random Lightning Flashes
      this.lightningTimer += dt;
      if (this.lightningTimer > 5.5 + Math.random() * 3.5) {
        this.lightningTimer = 0;
        if (this.lightningLight) {
          this.lightningLight.intensity = 3.2;
          setTimeout(() => { if (this.lightningLight) this.lightningLight.intensity = 0; }, 60);
          setTimeout(() => {
            if (this.lightningLight) this.lightningLight.intensity = 2.5;
            soundManager.playThunder();
            if (window.game && window.game.addTrauma) window.game.addTrauma(0.18);
          }, 130);
          setTimeout(() => { if (this.lightningLight) this.lightningLight.intensity = 0; }, 200);
        }
      }
    }

    // Active Naval Sea Fort Artillery Turrets Defense
    for (const tower of this.fortTowers) {
      tower.fireTimer -= dt;

      // Target player if wanted level >= 2 or player enters fort citadel perimeter
      const p = player || (window.game ? window.game.player : null);
      if (p && p.alive) {
        const dx = p.position.x - tower.x;
        const dz = p.position.z - tower.z;
        const dist = Math.sqrt(dx * dx + dz * dz);

        if (dist <= tower.range && (p.wantedLevel >= 2 || dist < 210)) {
          const targetAngle = Math.atan2(dx, dz);
          tower.turretMesh.rotation.y = targetAngle;

          if (tower.fireTimer <= 0) {
            tower.fireTimer = 2.8;

            if (!tower.engaged) {
              tower.engaged = true;
              const dispatch = document.getElementById('dispatch-msg');
              if (dispatch) {
                dispatch.innerText = '⚠️ [CITADEL COMM]: Coastal Defense Artillery battery firing on suspect!';
                dispatch.style.color = '#ef4444';
              }
            }

            const wm = weaponManager || (window.game ? window.game.weaponManager : null);
            if (wm) {
              const forwardX = Math.sin(targetAngle);
              const forwardZ = Math.cos(targetAngle);
              const spawnX = tower.x + forwardX * 12;
              const spawnZ = tower.z + forwardZ * 12;
              wm.spawnProjectile(spawnX, 22, spawnZ, forwardX, forwardZ, 20, 'cannon', tower);
              soundManager.playCannon();
            }
          }
        }
      }
    }

    // Sea Gate Warning Beacons Bobbing / Strobing
    if (this.seaGate && this.seaGate.alive) {
      const beaconState = Math.sin(this.waterTime * 8) > 0;
      if (this.seaGate.leftBeacon && this.seaGate.rightBeacon) {
        this.seaGate.leftBeacon.material.opacity = beaconState ? 1.0 : 0.2;
        this.seaGate.rightBeacon.material.opacity = !beaconState ? 1.0 : 0.2;
      }
    }

    // Dynamic Bascule Drawbridge Timed Articulation
    for (const db of this.drawbridges) {
      db.timer += dt;
      const t = db.timer % 32.0;
      let targetAngle = 0;
      if (t < 12.0) {
        targetAngle = 0;
        db.state = 'CLOSED';
      } else if (t < 16.0) {
        const progress = (t - 12.0) / 4.0;
        targetAngle = progress * 0.65; // ~37 degrees
        db.state = 'OPENING';
      } else if (t < 28.0) {
        targetAngle = 0.65;
        db.state = 'OPEN';
      } else {
        const progress = (32.0 - t) / 4.0;
        targetAngle = progress * 0.65;
        db.state = 'CLOSING';
      }

      db.currentAngle = THREE.MathUtils.lerp(db.currentAngle, targetAngle, dt * 3.5);
      db.southLeaf.rotation.x = -db.currentAngle;
      db.northLeaf.rotation.x = db.currentAngle;

      const isOpen = db.currentAngle > 0.22;
      db.southRamp.active = isOpen;
      db.northRamp.active = isOpen;

      const beaconStrobe = (db.state !== 'CLOSED') && (Math.sin(this.waterTime * 12) > 0);
      if (db.southBeacon && db.northBeacon) {
        db.southBeacon.material.opacity = beaconStrobe ? 1.0 : 0.2;
        db.northBeacon.material.opacity = beaconStrobe ? 1.0 : 0.2;
      }
    }

    // Floating Spike Nets Amber Beacon Strobing
    for (const net of this.spikeNets) {
      if (net.alive) {
        const strobeState = Math.sin(this.waterTime * 10) > 0;
        if (net.leftBeacon && net.rightBeacon) {
          net.leftBeacon.material.opacity = strobeState ? 1.0 : 0.2;
          net.rightBeacon.material.opacity = !strobeState ? 1.0 : 0.2;
        }
      }
    }
  }

  checkCollision(x, z, boatRadius = 4.5) {
    for (const col of this.colliders) {
      const dx = x - col.x;
      const dz = z - col.z;
      const minDist = col.radius + boatRadius;
      if (dx * dx + dz * dz < minDist * minDist) {
        return col;
      }
    }
    return null;
  }

  checkDestructibles(x, z, boatRadius = 4.5) {
    for (const d of this.destructibles) {
      if (d.alive) {
        const dx = x - d.x;
        const dz = z - d.z;
        const minDist = d.radius + boatRadius;
        if (dx * dx + dz * dz < minDist * minDist) {
          d.alive = false;
          this.scene.remove(d.mesh);
          this.spawnVoxelCrumbles(d.x, 2.5, d.z, d.isExplosive ? 24 : 16, d.color);
          return d;
        }
      }
    }
    return null;
  }

  // Ramp check gated on approach direction: must drive onto ramp face, not side or reverse!
  checkRamp(x, z, boatHeading = 0) {
    for (const ramp of this.ramps) {
      if (ramp.isDrawbridge && !ramp.active) continue;
      const dx = ramp.x - x;
      const dz = ramp.z - z;
      const distSq = dx * dx + dz * dz;
      const maxDist = (ramp.length * 0.65);
      if (distSq < maxDist * maxDist) {
        // Compute angle from boat to ramp center
        const toRamp = Math.atan2(dx, dz);
        let a = toRamp - boatHeading;
        while (a < -Math.PI) a += Math.PI * 2;
        while (a > Math.PI) a -= Math.PI * 2;
        // Gated on approach direction: within 55 degrees of head-on approach
        if (Math.abs(a) < 0.95) {
          return ramp;
        }
      }
    }
    return null;
  }

  checkPickups(x, z, boatRadius = 4.5) {
    for (const p of this.pickups) {
      if (p.alive) {
        const dx = x - p.x;
        const dz = z - p.z;
        if (dx * dx + dz * dz < (p.radius + boatRadius) * (p.radius + boatRadius)) {
          p.alive = false;
          this.scene.remove(p.mesh);
          return p.type;
        }
      }
    }
    return null;
  }

  checkRoadblocks(x, z, boatRadius = 4.5, boatSpeed = 0) {
    for (const rb of this.roadblocks) {
      if (!rb.alive) continue;
      const dx = x - rb.x;
      const dz = z - rb.z;
      const cos = Math.cos(-rb.angle);
      const sin = Math.sin(-rb.angle);
      const localX = cos * dx - sin * dz;
      const localZ = sin * dx + cos * dz;

      // Barrier bounding box check
      if (Math.abs(localX) < (rb.width * 0.5 + boatRadius) && Math.abs(localZ) < (3.5 + boatRadius)) {
        rb.alive = false;
        if (rb.barrierBeamsMesh) {
          rb.barrierBeamsMesh.visible = false;
        }
        // Explosive voxel shatter
        this.spawnVoxelCrumbles(rb.x, 2.8, rb.z, 36, 0xf59e0b);
        this.spawnVoxelCrumbles(rb.x, 2.8, rb.z, 18, 0xef4444);
        this.spawnVoxelCrumbles(rb.x, 2.8, rb.z, 18, 0xffffff);
        return rb;
      }
    }
    return null;
  }

  addPickup(x, z, type) {
    this._addPickup(x, z, type);
  }

  damageSeaGate(amount, attacker = null) {
    if (!this.seaGate || !this.seaGate.alive) return;
    this.seaGate.health -= amount;

    // Sparks & metal crumbles
    this.spawnVoxelCrumbles(this.seaGate.x, 3.5, this.seaGate.z, 8, 0xf59e0b);

    if (this.seaGate.health <= 0) {
      this.breachSeaGate(attacker);
    }
  }

  breachSeaGate(attacker = null) {
    if (!this.seaGate || !this.seaGate.alive) return;
    this.seaGate.alive = false;

    // Remove collider
    const idx = this.colliders.findIndex(c => c === this.seaGate.collider);
    if (idx !== -1) {
      this.colliders.splice(idx, 1);
    }

    // Hide gate mesh
    if (this.seaGate.mesh) {
      this.seaGate.mesh.visible = false;
    }

    // Huge explosion & voxel shatter
    this.spawnVoxelCrumbles(this.seaGate.x, 4.0, this.seaGate.z, 48, 0x475569);
    this.spawnVoxelCrumbles(this.seaGate.x, 4.0, this.seaGate.z, 28, 0xf59e0b);
    this.spawnVoxelCrumbles(this.seaGate.x, 4.0, this.seaGate.z, 20, 0xef4444);
    this.spawnVoxelCrumbles(this.seaGate.x, 4.0, this.seaGate.z, 20, 0xffffff);

    soundManager.playRoadblockSmash();
    soundManager.playExplosion(1.0, 1.2);

    if (window.game && window.game.addTrauma) {
      window.game.addTrauma(0.65);
    }

    const player = (attacker && attacker.triggerStunt) ? attacker : (window.game ? window.game.player : null);
    if (player && player.triggerStunt) {
      player.triggerStunt('🏰 FORTRESS GATE BREACHED!', 900);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '🚨 [CITADEL ALERT]: EMERGENCY! Sector 4 Fort Gate breached!';
      dispatch.style.color = '#ef4444';
    }
  }

  checkSeaGate(x, z, boatRadius = 4.5, boatSpeed = 0, isBoosting = false) {
    if (!this.seaGate || !this.seaGate.alive) return null;

    const dx = x - this.seaGate.x;
    const dz = z - this.seaGate.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    const minDist = this.seaGate.radius + boatRadius;

    if (dist < minDist) {
      // Ramming with boost and high speed breaches it instantly!
      if (isBoosting && boatSpeed > 26) {
        this.breachSeaGate();
        return { breached: true };
      }

      // Ramming with moderate speed deals structural damage
      if (boatSpeed > 14) {
        this.damageSeaGate(boatSpeed * 2.5);
        if (!this.seaGate.alive) {
          return { breached: true };
        }
      }

      return { breached: false, collider: this.seaGate.collider };
    }
    return null;
  }

  checkSpikeNets(x, z, boatRadius = 4.5, boatSpeed = 0, isBoosting = false) {
    for (const net of this.spikeNets) {
      if (!net.alive) continue;
      const dx = x - net.x;
      const dz = z - net.z;
      const cos = Math.cos(-net.angle);
      const sin = Math.sin(-net.angle);
      const localX = cos * dx - sin * dz;
      const localZ = sin * dx + cos * dz;

      if (Math.abs(localX) < (net.width * 0.5 + boatRadius) && Math.abs(localZ) < (3.0 + boatRadius)) {
        net.alive = false;
        if (net.mesh) net.mesh.visible = false;

        this.spawnVoxelCrumbles(net.x, 1.5, net.z, 28, 0xf59e0b);
        this.spawnVoxelCrumbles(net.x, 1.5, net.z, 16, 0x1e293b);

        if (isBoosting || boatSpeed > 26) {
          return { severed: true };
        } else {
          return { severed: false };
        }
      }
    }
    return null;
  }

  getNearestGrappleAnchor(x, z, boatHeading = 0, maxDist = 78) {
    let bestAnchor = null;
    let bestScore = -999;

    const candidates = [];
    for (const b of this.buoys) {
      candidates.push({ x: b.x, z: b.z, y: 2.5, type: 'buoy' });
    }
    for (const d of this.grappleDolphins) {
      candidates.push({ x: d.x, z: d.z, y: 3.5, type: 'dolphin' });
    }
    for (const col of this.colliders) {
      if (col.type === 'pillar' || col.type === 'roadblock_post' || col.type === 'dock') {
        candidates.push({ x: col.x, z: col.z, y: 2.5, type: col.type });
      }
    }

    for (const c of candidates) {
      const dx = c.x - x;
      const dz = c.z - z;
      const distSq = dx * dx + dz * dz;
      if (distSq > maxDist * maxDist || distSq < 10 * 10) continue;
      const dist = Math.sqrt(distSq);

      const toAngle = Math.atan2(dx, dz);
      let rel = toAngle - boatHeading;
      while (rel < -Math.PI) rel += Math.PI * 2;
      while (rel > Math.PI) rel -= Math.PI * 2;

      // Must be within 125 degrees of boat heading (not directly behind)
      if (Math.abs(rel) > 2.18) continue;

      // Sweet spot: 30 to 90 degrees to either side (perfect tangential arc)
      const sideBonus = Math.sin(Math.abs(rel));
      const score = (1.0 / (dist + 6)) * (1.0 + sideBonus * 1.8);
      if (score > bestScore) {
        bestScore = score;
        bestAnchor = { x: c.x, z: c.z, y: c.y, type: c.type, dist, relAngle: rel };
      }
    }
    return bestAnchor;
  }
}
