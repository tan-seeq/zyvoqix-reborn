// Boat Chase: Faction AI, Detection Cones, Radio Alerts & Inter-Faction Warfare
import * as THREE from '../lib/three.module.js';
import { CONFIG } from './config.js';
import { soundManager } from './audio.js';

export class FactionManager {
  constructor(scene, world, player, weaponManager) {
    this.scene = scene;
    this.world = world;
    this.player = player;
    this.weaponManager = weaponManager;
    this.enemies = []; // Array of EnemyBoat instances

    this._spawnFactions();
  }

  _spawnFactions() {
    // 1. Police Coast Guard flotilla stationed near Police Marina & harbor checkpoints
    const policeSpawns = [
      { x: -800, z: -550 }, { x: -650, z: -620 }, { x: -850, z: -400 },
      { x: -500, z: -400 }, { x: -350, z: -700 }, { x: -700, z: -200 }
    ];
    for (const p of policeSpawns) {
      this._createEnemyBoat(CONFIG.FACTIONS.POLICE, p.x, p.z);
    }

    // 2. Gangster Cartel fleet patrolling Industrial Docks & Central Canals
    const gangsterSpawns = [
      { x: 650, z: 650 }, { x: 750, z: 500 }, { x: 920, z: 700 },
      { x: 500, z: 850 }, { x: 400, z: 450 }, { x: 250, z: 600 }
    ];
    for (const g of gangsterSpawns) {
      this._createEnemyBoat(CONFIG.FACTIONS.GANGSTER, g.x, g.z);
    }

    // 3. Pirate armada prowling Skull Cove & Jagged Straits
    const pirateSpawns = [
      { x: 800, z: -500 }, { x: 950, z: -400 }, { x: 1100, z: -600 },
      { x: 750, z: -750 }, { x: 600, z: -550 }, { x: 880, z: -800 }
    ];
    for (const pi of pirateSpawns) {
      this._createEnemyBoat(CONFIG.FACTIONS.PIRATES, pi.x, pi.z);
    }

    // 4. Roaming patrols in central channels
    this._createEnemyBoat(CONFIG.FACTIONS.POLICE, -150, 150);
    this._createEnemyBoat(CONFIG.FACTIONS.GANGSTER, 150, -100);
    this._createEnemyBoat(CONFIG.FACTIONS.PIRATES, -50, -350);

    // 5. Heavy Interceptor Cutters on strategic patrol
    this._createHeavyCutter(-640, -480); // Police Marina outer breakwater channel
    this._createHeavyCutter(0, 380);     // Grand Canal / Citadel approach

    // 6. Cartel Armored Speedboat Convoy with High-Value Diamond Cargo Escort
    this._createConvoy(550, 450);

    // 7. Skull Cove Pirate Boss: Blackbeard's Armored Ironclad Galleon
    this._createIroncladGalleon(880, -680);

    // 8. Cartel Armored Amphibious Hovercraft Gunship patrolling the Eastern Sandbanks & Canals
    this._createCartelHovercraft(CONFIG.HOVERCRAFT.x || 650, CONFIG.HOVERCRAFT.z || 250);

    // 9. Casino Private Security Patrol Catamarans guarding the Grand Poseidon Marina
    this._createSecurityCatamaran(575, -150);
    this._createSecurityCatamaran(465, -210);

    // 10. Naval Zeppelin Gunship Aerial Boss ("The Iron Valkyrie")
    this._createZeppelin(200, -350);
  }

  _createEnemyBoat(factionConfig, x, z) {
    const enemy = new EnemyBoat(this.scene, this.world, factionConfig, x, z, this);
    this.enemies.push(enemy);
    return enemy;
  }

  _createHeavyCutter(x, z) {
    const cutter = new HeavyInterceptorCutter(this.scene, this.world, CONFIG.FACTIONS.HEAVY_POLICE, x, z, this);
    this.enemies.push(cutter);
    return cutter;
  }

  _createConvoy(x, z) {
    const leader = new CartelConvoyLeader(this.scene, this.world, x, z, this);
    this.enemies.push(leader);
    this.convoyLeader = leader;

    const escort1 = new CartelConvoyEscort(this.scene, this.world, x - 18, z - 22, this, leader, -18, -22);
    const escort2 = new CartelConvoyEscort(this.scene, this.world, x + 18, z - 22, this, leader, 18, -22);
    this.enemies.push(escort1);
    this.enemies.push(escort2);
    leader.escorts = [escort1, escort2];

    return leader;
  }

  _createIroncladGalleon(x, z) {
    const galleon = new IroncladGalleon(this.scene, this.world, x, z, this);
    this.enemies.push(galleon);
    this.ironcladGalleon = galleon;
    return galleon;
  }

  _createCartelHovercraft(x, z) {
    const hovercraft = new CartelHovercraft(this.scene, this.world, x, z, this);
    this.enemies.push(hovercraft);
    this.cartelHovercraft = hovercraft;
    return hovercraft;
  }

  _createSecurityCatamaran(x, z) {
    const sec = new SecurityCatamaran(this.scene, this.world, x, z, this);
    this.enemies.push(sec);
    return sec;
  }

  _createZeppelin(x, z) {
    const zep = new NavalZeppelin(this.scene, this.world, this.player, this.weaponManager, this, x, z);
    this.zeppelin = zep;
    return zep;
  }

  update(dt) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (!enemy.alive) {
        this.enemies.splice(i, 1);
        continue;
      }
      enemy.update(dt);
    }

    // Convoy respawn logic if flagship sank
    if (this.convoyLeader && !this.convoyLeader.alive) {
      this.convoyRespawnTimer = (this.convoyRespawnTimer || 0) + dt;
      if (this.convoyRespawnTimer > 75.0) {
        this.convoyRespawnTimer = 0;
        this._createConvoy(550, 450);
      }
    }

    // Ironclad Galleon respawn logic if sunk
    if (this.ironcladGalleon && !this.ironcladGalleon.alive) {
      this.galleonRespawnTimer = (this.galleonRespawnTimer || 0) + dt;
      if (this.galleonRespawnTimer > 90.0) {
        this.galleonRespawnTimer = 0;
        this._createIroncladGalleon(880, -680);
      }
    }

    // Cartel Hovercraft respawn logic if sunk
    if (this.cartelHovercraft && !this.cartelHovercraft.alive) {
      this.hovercraftRespawnTimer = (this.hovercraftRespawnTimer || 0) + dt;
      if (this.hovercraftRespawnTimer > 70.0) {
        this.hovercraftRespawnTimer = 0;
        this._createCartelHovercraft(CONFIG.HOVERCRAFT.x || 650, CONFIG.HOVERCRAFT.z || 250);
      }
    }

    // Casino Security Catamaran reinforcements
    const activeSec = this.enemies.filter(e => e.isSecurityCatamaran && e.alive).length;
    if (activeSec < 2) {
      this.secRespawnTimer = (this.secRespawnTimer || 0) + dt;
      if (this.secRespawnTimer > 50.0) {
        this.secRespawnTimer = 0;
        this._createSecurityCatamaran(575, -150);
      }
    }

    // Naval Zeppelin Gunship Aerial Boss update & respawn
    if (this.zeppelinCooldown > 0) {
      this.zeppelinCooldown -= dt;
    }
    if (!this.zeppelin && (!this.zeppelinCooldown || this.zeppelinCooldown <= 0)) {
      this._createZeppelin(200, -350);
    }
    if (this.zeppelin) {
      this.zeppelin.update(dt);
      if (!this.zeppelin.alive) {
        this.zeppelin = null;
        this.zeppelinCooldown = 95.0;
      }
    }

    // Check if player wanted level should increase based on active chasers
    const alertedPolice = this.enemies.filter(e => e.faction.id === 'police' && e.state === 'ALERTED').length;
    if (alertedPolice >= 4) {
      this.player.wantedLevel = Math.max(this.player.wantedLevel, 5);
    } else if (alertedPolice >= 3) {
      this.player.wantedLevel = Math.max(this.player.wantedLevel, 4);
    } else if (alertedPolice >= 2) {
      this.player.wantedLevel = Math.max(this.player.wantedLevel, 3);
    } else if (alertedPolice >= 1) {
      this.player.wantedLevel = Math.max(this.player.wantedLevel, 2);
    } else {
      // Evasion cool-down: slowly lose a star after 18s of successful evasion
      this.evasionTimer = (this.evasionTimer || 0) + dt;
      if (this.evasionTimer > 18.0) {
        this.player.wantedLevel = Math.max(1, this.player.wantedLevel - 1);
        this.evasionTimer = 0;
      }
    }

    // Heavy Cutter Reinforcements at Wanted Level 4+
    if (this.player.wantedLevel >= 4) {
      const activeCutters = this.enemies.filter(e => e.isHeavy && e.alive).length;
      if (activeCutters < 2) {
        this.cutterSpawnTimer = (this.cutterSpawnTimer || 0) + dt;
        if (this.cutterSpawnTimer > 24.0) {
          this._createHeavyCutter(-640, -480);
          this.cutterSpawnTimer = 0;
          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '🚨 [POLICE DISPATCH]: ALL UNITS, COASTAL HEAVY CUTTER SCRAMBLED!';
            dispatch.style.color = '#38bdf8';
          }
        }
      }
    }

    // Police Helicopter Air Support at Wanted Level 3+ (with 30s respawn cooldown)
    if (this.helicopterCooldown > 0) {
      this.helicopterCooldown -= dt;
    }

    if (this.player.wantedLevel >= 3 && !this.helicopter && (!this.helicopterCooldown || this.helicopterCooldown <= 0)) {
      this.helicopter = new PoliceHelicopter(this.scene, this.player, this.weaponManager);
    } else if (this.player.wantedLevel < 3 && this.helicopter) {
      this.helicopter.destroy();
      this.helicopter = null;
    }

    if (this.helicopter) {
      this.helicopter.update(dt);
      if (!this.helicopter.alive) {
        this.helicopter = null;
        this.helicopterCooldown = 30.0;
      }
    }
  }

  // Faction alert broadcast: when an enemy spots a target, only alert ALLIES of the SAME FACTION
  broadcastAlert(spottingEnemy, target) {
    const broadcastRadius = spottingEnemy.faction.alertRadioRadius;
    const sameFaction = this.enemies.filter(e => e.faction.id === spottingEnemy.faction.id && e !== spottingEnemy);

    for (const ally of sameFaction) {
      const dx = ally.position.x - spottingEnemy.position.x;
      const dz = ally.position.z - spottingEnemy.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist <= broadcastRadius && ally.state !== 'ALERTED') {
        ally.receiveRadioAlert(target);
      }
    }
  }
}

export class EnemyBoat {
  constructor(scene, world, faction, x, z, manager) {
    this.scene = scene;
    this.world = world;
    this.faction = faction;
    this.manager = manager;

    // Physics
    this.position = new THREE.Vector3(x, 0, z);
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.rotation = Math.random() * Math.PI * 2;
    this.speed = 0;
    this.radius = 4.5;
    this.health = faction.health;
    this.maxHealth = faction.health;
    this.alive = true;

    // AI States: 'PATROL', 'SUSPICIOUS', 'ALERTED'
    this.state = 'PATROL';
    this.target = null; // can be player OR rival faction boat!
    this.patrolCenter = new THREE.Vector3(x, 0, z);
    this.patrolRadius = 140 + Math.random() * 80;
    this.patrolAngle = Math.random() * Math.PI * 2;
    this.fireTimer = Math.random() * faction.fireRate;
    this.alertTimer = 0; // how long we stay alerted if target lost

    // Visuals & Indicator
    this.mesh = this._buildMesh();
    this.scene.add(this.mesh);

    this.alertIcon = this._createAlertIcon();
    this.mesh.add(this.alertIcon);

    // Siren / strobe lights
    this.sirenTimer = 0;
    this.sirenLights = [];
    this.empDisabledTimer = 0;
    if (faction.id === 'police') {
      this._addPoliceSirens();
    }
  }

  _buildMesh() {
    const group = new THREE.Group();

    // 1. Hull
    const hullShape = new THREE.Shape();
    hullShape.moveTo(0, 7.0);
    hullShape.lineTo(2.3, 2.5);
    hullShape.lineTo(2.2, -5.0);
    hullShape.lineTo(-2.2, -5.0);
    hullShape.lineTo(-2.3, 2.5);
    hullShape.closePath();

    const extrudeSettings = { depth: 2.0, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.4, bevelThickness: 0.5 };
    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.rotateX(Math.PI / 2);

    const hullMat = new THREE.MeshStandardMaterial({
      color: this.faction.hullColor,
      roughness: 0.4,
      metalness: 0.6
    });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 0.9;
    group.add(hull);

    // 2. Cabin / Superstructure
    const cabinGeo = new THREE.BoxGeometry(3.2, 1.6, 5.0);
    const cabinMat = new THREE.MeshStandardMaterial({
      color: this.faction.cabinColor,
      roughness: 0.3,
      metalness: 0.5
    });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 1.8, -0.6);
    group.add(cabin);

    // 3. Faction Trim Stripe
    const stripeGeo = new THREE.BoxGeometry(3.6, 0.4, 6.2);
    const stripeMat = new THREE.MeshBasicMaterial({ color: this.faction.stripeColor });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(0, 1.1, 0);
    group.add(stripe);

    // 4. Pirate Flag / Police Radar Antenna
    if (this.faction.id === 'pirates') {
      // Mast & Skull Flag
      const mastGeo = new THREE.CylinderGeometry(0.15, 0.2, 7.5);
      const mastMat = new THREE.MeshStandardMaterial({ color: 0x24170d });
      const mast = new THREE.Mesh(mastGeo, mastMat);
      mast.position.set(0, 4.5, -1.8);
      group.add(mast);

      const flagGeo = new THREE.PlaneGeometry(2.4, 1.4);
      const flagMat = new THREE.MeshBasicMaterial({ color: 0x111111, side: THREE.DoubleSide });
      const flag = new THREE.Mesh(flagGeo, flagMat);
      flag.position.set(1.2, 7.0, -1.8);
      group.add(flag);
    } else if (this.faction.id === 'police') {
      // Radar dome & searchlight
      const domeGeo = new THREE.SphereGeometry(0.65, 8, 8);
      const domeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const dome = new THREE.Mesh(domeGeo, domeMat);
      dome.position.set(0, 2.9, -0.6);
      group.add(dome);
    }

    return group;
  }

  _addPoliceSirens() {
    const redGeo = new THREE.SphereGeometry(0.35, 8, 8);
    const redMat = new THREE.MeshBasicMaterial({ color: 0xff0022 });
    const redSiren = new THREE.Mesh(redGeo, redMat);
    redSiren.position.set(-0.8, 2.8, -0.6);
    this.mesh.add(redSiren);

    const blueGeo = new THREE.SphereGeometry(0.35, 8, 8);
    const blueMat = new THREE.MeshBasicMaterial({ color: 0x0066ff });
    const blueSiren = new THREE.Mesh(blueGeo, blueMat);
    blueSiren.position.set(0.8, 2.8, -0.6);
    this.mesh.add(blueSiren);

    this.sirenLights = [redSiren, blueSiren];
  }

  _createAlertIcon() {
    // 3D Billboard marker above boat: '!' for Alerted, '?' for Suspicious
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ff1144';
    ctx.beginPath();
    ctx.arc(32, 32, 28, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('!', 32, 32);

    const texture = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(4.5, 4.5, 1);
    sprite.position.set(0, 6.5, 0);
    sprite.visible = false;
    return sprite;
  }

  receiveRadioAlert(target) {
    this.state = 'ALERTED';
    this.target = target;
    this.alertTimer = 14; // chase for at least 14s
    this.alertIcon.visible = true;
    if (this.faction.id === 'police') {
      soundManager.playPoliceSirenChirp();
    }
  }

  detectPotentialTargets() {
    // Scan for:
    // 1. The Player (if hostile to player)
    // 2. Rival faction boats within detection cone!
    const candidateTargets = [];

    // Check player
    if (this.manager.player && this.manager.player.alive) {
      candidateTargets.push(this.manager.player);
    }

    // Check other enemy boats from opposing factions
    for (const other of this.manager.enemies) {
      if (other !== this && other.alive && other.faction.id !== this.faction.id) {
        candidateTargets.push(other);
      }
    }

    // Check vision cones for candidates
    for (const cand of candidateTargets) {
      const dx = cand.position.x - this.position.x;
      const dz = cand.position.z - this.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist <= this.faction.detectRadius) {
        // Calculate angle between our heading and candidate direction
        const candAngle = Math.atan2(dx, dz);
        let angleDiff = Math.abs(this.rotation - candAngle);
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        angleDiff = Math.abs(angleDiff);

        // Within vision cone OR heard loud noise (close proximity)
        if (angleDiff < this.faction.visionAngle / 2 || dist < 45) {
          // Check line of sight: ensure no massive island blocks direct line
          const hitIsland = this._hasLineOfSight(cand.position);
          if (hitIsland) {
            return cand;
          }
        }
      }
    }

    return null;
  }

  _hasLineOfSight(targetPos) {
    // Raycast approximation through world colliders
    const steps = 6;
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const testX = this.position.x + (targetPos.x - this.position.x) * t;
      const testZ = this.position.z + (targetPos.z - this.position.z) * t;
      const col = this.world.checkCollision(testX, testZ, 2.0);
      if (col && col.type === 'island') {
        return false; // Vision blocked by island landmass!
      }
    }
    return true;
  }

  update(dt) {
    if (!this.alive) return;

    // EMP Shockwave disabling state
    if (this.empDisabledTimer && this.empDisabledTimer > 0) {
      this.empDisabledTimer -= dt;
      this.speed = 0;
      if (this.velocity) this.velocity.set(0, 0, 0);
      if (this.sirenLights) {
        for (const s of this.sirenLights) s.visible = false;
      }
      if (this.alertIcon) this.alertIcon.visible = false;
      if (Math.random() < 0.25 && this.world && this.world.spawnVoxelCrumbles) {
        this.world.spawnVoxelCrumbles(this.position.x, 2.5, this.position.z, 2, 0xa855f7);
      }
      const wave = this.world.getWaveHeight(this.position.x, this.position.z);
      this.position.y = wave;
      this.mesh.position.copy(this.position);
      return;
    }

    // Siren flashing
    if (this.sirenLights.length > 0) {
      this.sirenTimer += dt * 8;
      const isRed = Math.sin(this.sirenTimer) > 0;
      this.sirenLights[0].visible = this.state === 'ALERTED' && isRed;
      this.sirenLights[1].visible = this.state === 'ALERTED' && !isRed;
    }

    // State Machine
    if (this.state === 'PATROL') {
      this.alertIcon.visible = false;
      const spotted = this.detectPotentialTargets();
      if (spotted) {
        this.state = 'ALERTED';
        this.target = spotted;
        this.alertTimer = 12;
        this.alertIcon.visible = true;

        if (this.target === this.manager.player) {
          soundManager.playAlertPing();
          if (this.faction.id === 'police') {
            soundManager.playPoliceSirenChirp();
          }
        }

        // Radio all allies of this faction!
        this.manager.broadcastAlert(this, spotted);
      } else {
        this._updatePatrol(dt);
      }
    } else if (this.state === 'ALERTED') {
      this.alertIcon.visible = true;
      if (!this.target || !this.target.alive) {
        // Target destroyed or lost, resume patrol
        this.state = 'PATROL';
        this.target = null;
        return;
      }

      const dx = this.target.position.x - this.position.x;
      const dz = this.target.position.z - this.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist > this.faction.detectRadius * 1.5) {
        this.alertTimer -= dt;
        if (this.alertTimer <= 0) {
          this.state = 'PATROL';
          this.target = null;
        }
      } else {
        this.alertTimer = 12;
      }

      this._updatePursuit(dt, dx, dz, dist);
      this._updateCombat(dt, dx, dz, dist);
    }

    // World collision
    const col = this.world.checkCollision(this.position.x, this.position.z, this.radius);
    if (col) {
      const dx = this.position.x - col.x;
      const dz = this.position.z - col.z;
      const dist = Math.sqrt(dx * dx + dz * dz) || 1;
      this.position.x += (dx / dist) * 2.0;
      this.position.z += (dz / dist) * 2.0;
      this.speed *= 0.5;
    }

    // Check contact with naval mines
    if (this.world && this.world.checkMines) {
      this.world.checkMines(this.position.x, this.position.z, this.radius, null);
    }

    // Water wave height
    const wave = this.world.getWaveHeight(this.position.x, this.position.z);
    this.position.y = wave;
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotation;
  }

  _updatePatrol(dt) {
    // Gentle circular/oval route around patrol center
    this.patrolAngle += 0.3 * dt;
    const targetX = this.patrolCenter.x + Math.cos(this.patrolAngle) * this.patrolRadius;
    const targetZ = this.patrolCenter.z + Math.sin(this.patrolAngle) * this.patrolRadius;

    this._steerToward(targetX, targetZ, dt, this.faction.baseSpeed * 0.45);
  }

  _updatePursuit(dt, dx, dz, dist) {
    // Pursue target while steering around obstacles
    const targetSpeed = this.faction.baseSpeed;
    this._steerToward(this.target.position.x, this.target.position.z, dt, targetSpeed);
  }

  _steerToward(targetX, targetZ, dt, maxSpeed) {
    const desiredAngle = Math.atan2(targetX - this.position.x, targetZ - this.position.z);
    let diff = desiredAngle - this.rotation;
    while (diff < -Math.PI) diff += Math.PI * 2;
    while (diff > Math.PI) diff -= Math.PI * 2;

    this.rotation += Math.sign(diff) * Math.min(Math.abs(diff), this.faction.turnSpeed * dt);
    this.speed = THREE.MathUtils.lerp(this.speed, maxSpeed, dt * 2.5);

    this.velocity.x = Math.sin(this.rotation) * this.speed;
    this.velocity.z = Math.cos(this.rotation) * this.speed;

    this.position.x += this.velocity.x * dt;
    this.position.z += this.velocity.z * dt;
  }

  _updateCombat(dt, dx, dz, dist) {
    this.fireTimer -= dt;
    if (this.fireTimer <= 0 && dist < 140) {
      this.fireTimer = this.faction.fireRate * (0.8 + Math.random() * 0.4);

      // Aim at target with spread (creates cinematic near-miss water splashes)
      const spreadAngle = (Math.random() - 0.5) * (this.faction.spread || 0.18);
      const angle = Math.atan2(dx, dz) + spreadAngle;
      const forwardX = Math.sin(angle);
      const forwardZ = Math.cos(angle);

      if (this.faction.id === 'pirates') {
        // Heavy Cannonball
        this.manager.weaponManager.spawnProjectile(
          this.position.x + forwardX * 6,
          this.position.y + 2.5,
          this.position.z + forwardZ * 6,
          forwardX,
          forwardZ,
          this.faction.damage,
          'cannon',
          this
        );
        soundManager.playCannon();
      } else {
        // Machine Gun burst
        this.manager.weaponManager.spawnProjectile(
          this.position.x + forwardX * 5,
          this.position.y + 1.8,
          this.position.z + forwardZ * 5,
          forwardX,
          forwardZ,
          this.faction.damage,
          'mg',
          this
        );
        soundManager.playGunfire(0.85);
      }
    }
  }

  takeDamage(amount, attacker) {
    if (!this.alive) return;
    this.health -= amount;

    // Retaliate against attacker if not already alerted
    if (attacker && attacker !== this) {
      this.state = 'ALERTED';
      this.target = attacker;
      this.alertTimer = 14;
      this.manager.broadcastAlert(this, attacker);
    }

    if (this.health <= 0) {
      this.die();
    }
  }

  die() {
    this.alive = false;
    soundManager.playExplosion(0.8, 1.0);
    this.manager.player.score += this.faction.scoreValue;

    // Remove mesh and create sinking wreckage
    this.scene.remove(this.mesh);
  }
}

export class HeavyInterceptorCutter extends EnemyBoat {
  constructor(scene, world, faction, x, z, manager) {
    super(scene, world, faction, x, z, manager);
    this.isHeavy = true;
    this.radius = 6.8;
    this.depthChargeTimer = 2.0;
    this.altGun = false;
    this.radarDish = null;
  }

  _buildMesh() {
    const group = new THREE.Group();

    // Twin Catamaran Hulls (deep draft navy armor)
    const pontoonGeo = new THREE.BoxGeometry(2.4, 2.6, 17);
    const pontoonMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.7,
      roughness: 0.35
    });

    const leftPontoon = new THREE.Mesh(pontoonGeo, pontoonMat);
    leftPontoon.position.set(-3.4, 0.8, 0);
    group.add(leftPontoon);

    const rightPontoon = new THREE.Mesh(pontoonGeo, pontoonMat);
    rightPontoon.position.set(3.4, 0.8, 0);
    group.add(rightPontoon);

    // Main Armored Deck
    const deckGeo = new THREE.BoxGeometry(9.2, 1.4, 14);
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.5,
      roughness: 0.45
    });
    const deck = new THREE.Mesh(deckGeo, deckMat);
    deck.position.set(0, 1.8, 0);
    group.add(deck);

    // High Command Bridge / Pilot House
    const bridgeGeo = new THREE.BoxGeometry(5.4, 3.2, 6.2);
    const bridgeMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.6,
      roughness: 0.4
    });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, 3.8, -0.8);
    group.add(bridge);

    // Ballistic Tinted Windows
    const glassGeo = new THREE.BoxGeometry(4.8, 1.2, 1.2);
    const glassMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 4.4, 2.3);
    group.add(glass);

    // Heavy Police Decal Stripes
    const stripeGeo = new THREE.BoxGeometry(9.4, 0.45, 12);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(0, 2.4, 0);
    group.add(stripe);

    // Forward Twin Heavy Autocannon Barrels
    const barrelGeo = new THREE.CylinderGeometry(0.35, 0.4, 4.5, 8);
    barrelGeo.rotateX(Math.PI / 2);
    const barrelMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.85 });

    const leftGun = new THREE.Mesh(barrelGeo, barrelMat);
    leftGun.position.set(-1.8, 2.6, 7.8);
    group.add(leftGun);

    const rightGun = new THREE.Mesh(barrelGeo, barrelMat);
    rightGun.position.set(1.8, 2.6, 7.8);
    group.add(rightGun);

    // Stern Depth Charge Rail
    const railGeo = new THREE.BoxGeometry(4.5, 0.6, 2.2);
    const railMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
    const rail = new THREE.Mesh(railGeo, railMat);
    rail.position.set(0, 2.2, -6.8);
    group.add(rail);

    for (let c = -1; c <= 1; c++) {
      const chargeGeo = new THREE.CylinderGeometry(0.5, 0.5, 1.6, 8);
      chargeGeo.rotateZ(Math.PI / 2);
      const chargeMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.3 });
      const charge = new THREE.Mesh(chargeGeo, chargeMat);
      charge.position.set(c * 1.3, 2.8, -6.8);
      group.add(charge);
    }

    // Rotating Radar Mast
    const mastGeo = new THREE.CylinderGeometry(0.2, 0.25, 2.5, 6);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.set(0, 6.2, -1.0);
    group.add(mast);

    const dishGeo = new THREE.BoxGeometry(2.4, 0.4, 0.6);
    const dishMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.radarDish = new THREE.Mesh(dishGeo, dishMat);
    this.radarDish.position.set(0, 7.4, -1.0);
    group.add(this.radarDish);

    return group;
  }

  _addPoliceSirens() {
    const geo = new THREE.BoxGeometry(1.0, 0.5, 0.5);
    const redMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.9 });
    const blueMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.9 });

    const redStrobe = new THREE.Mesh(geo, redMat);
    redStrobe.position.set(-1.8, 5.7, -0.8);
    this.mesh.add(redStrobe);

    const blueStrobe = new THREE.Mesh(geo, blueMat);
    blueStrobe.position.set(1.8, 5.7, -0.8);
    this.mesh.add(blueStrobe);

    this.sirenLights.push(redStrobe, blueStrobe);
  }

  update(dt) {
    super.update(dt);
    if (!this.alive) return;

    // Spin radar mast
    if (this.radarDish) {
      this.radarDish.rotation.y += dt * 4.0;
    }

    // Stern depth-charge drop AI: if alerted and player is pursuing closely behind
    if (this.state === 'ALERTED' && this.target === this.manager.player) {
      this.depthChargeTimer -= dt;
      if (this.depthChargeTimer <= 0) {
        const dx = this.target.position.x - this.position.x;
        const dz = this.target.position.z - this.position.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        const forwardX = Math.sin(this.rotation);
        const forwardZ = Math.cos(this.rotation);
        const dot = dx * forwardX + dz * forwardZ;

        // Player is behind cutter within 85 units
        if (dot < -10 && dist < 85) {
          this.depthChargeTimer = 5.2;
          const dropX = this.position.x - forwardX * 8.8;
          const dropZ = this.position.z - forwardZ * 8.8;
          this.manager.weaponManager.spawnProjectile(
            dropX,
            1.2,
            dropZ,
            -forwardX * 0.15,
            -forwardZ * 0.15,
            35,
            'depth_charge',
            this
          );
          soundManager.playSplash();

          const dispatch = document.getElementById('dispatch-msg');
          if (dispatch) {
            dispatch.innerText = '⚠️ [RADIO SCANNER]: Heavy Cutter deploying stern depth charges!';
            dispatch.style.color = '#f59e0b';
          }
        }
      }
    }
  }

  _updateCombat(dt, dx, dz, dist) {
    this.fireTimer -= dt;
    if (this.fireTimer <= 0 && dist < this.faction.detectRadius) {
      const toTargetAngle = Math.atan2(dx, dz);
      let angleDiff = Math.abs(toTargetAngle - this.rotation);
      while (angleDiff > Math.PI) angleDiff = Math.PI * 2 - angleDiff;

      // Twin forward autocannons with wide firing cone
      if (angleDiff < this.faction.visionAngle) {
        this.fireTimer = this.faction.fireRate;
        this.altGun = !this.altGun;
        const sideOffset = this.altGun ? 1.8 : -1.8;
        const forwardX = Math.sin(this.rotation);
        const forwardZ = Math.cos(this.rotation);
        const sideX = Math.cos(this.rotation);
        const sideZ = -Math.sin(this.rotation);

        const spawnX = this.position.x + forwardX * 8.2 + sideX * sideOffset;
        const spawnZ = this.position.z + forwardZ * 8.2 + sideZ * sideOffset;

        this.manager.weaponManager.spawnProjectile(
          spawnX,
          2.6,
          spawnZ,
          forwardX,
          forwardZ,
          this.faction.damage,
          'mg',
          this
        );
        soundManager.playGunfire(1.15);
      }
    }
  }

  die() {
    super.die();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.65);
    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 32, 0x0284c7);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 16, 0x38bdf8);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 16, 0xf59e0b);
    }
    // Guaranteed high-value contraband drop
    if (this.world && this.world.addPickup) {
      this.world.addPickup(this.position.x, this.position.z, 'contraband');
    }
    if (this.manager.player && this.manager.player.triggerStunt) {
      this.manager.player.triggerStunt('💥 HEAVY CUTTER NEUTRALIZED!', 850);
    }
    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '💥 [POLICE DISPATCH]: 10-99! Heavy Coastal Cutter neutralized!';
      dispatch.style.color = '#ef4444';
    }
  }
}

export class CartelConvoyLeader extends EnemyBoat {
  constructor(scene, world, x, z, manager) {
    const config = CONFIG.FACTIONS.CONVOY_LEADER || {
      id: 'gangster',
      subType: 'convoy_leader',
      name: 'Cartel Convoy Flagship',
      color: 0x18181b,
      hudColor: '#f59e0b',
      hullColor: 0x18181b,
      cabinColor: 0x7c2d12,
      stripeColor: 0xf59e0b,
      baseSpeed: 48,
      turnSpeed: 1.5,
      health: 240,
      damage: 9,
      fireRate: 0.22,
      spread: 0.14,
      detectRadius: 260,
      visionAngle: Math.PI * 0.70,
      alertRadioRadius: 360,
      scoreValue: 1500
    };
    super(scene, world, config, x, z, manager);
    this.isConvoyLeader = true;
    this.radius = 6.2;
    this.health = config.health || 240;
    this.maxHealth = this.health;
    this.escorts = [];

    // Eastern Trade Channel Waypoints (Loops through cargo shipping routes)
    this.waypoints = [
      { x: 550, z: 450 },
      { x: 740, z: 200 },
      { x: 620, z: -150 },
      { x: 380, z: -80 },
      { x: 340, z: 260 }
    ];
    this.currentWpIndex = 0;
  }

  _buildMesh() {
    const group = new THREE.Group();

    // 1. Sleek Armored Gunboat Hull (Black Composite Armor)
    const hullShape = new THREE.Shape();
    hullShape.moveTo(0, 8.2);
    hullShape.lineTo(2.8, 3.2);
    hullShape.lineTo(2.6, -6.0);
    hullShape.lineTo(-2.6, -6.0);
    hullShape.lineTo(-2.8, 3.2);
    hullShape.closePath();

    const extrudeSettings = { depth: 2.4, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.5, bevelThickness: 0.6 };
    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.rotateX(Math.PI / 2);

    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.25,
      metalness: 0.8
    });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 1.0;
    group.add(hull);

    // 2. Gold Racing Accents & Armor Plates
    const trimGeo = new THREE.BoxGeometry(4.4, 0.45, 10.5);
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.2
    });
    const trim = new THREE.Mesh(trimGeo, trimMat);
    trim.position.set(0, 1.8, -0.4);
    group.add(trim);

    // 3. Tinted Canopy / Superstructure
    const bridgeGeo = new THREE.BoxGeometry(3.6, 1.8, 4.2);
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0x7c2d12, metalness: 0.6, roughness: 0.3 });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, 2.6, 0.6);
    group.add(bridge);

    const glassGeo = new THREE.BoxGeometry(3.2, 0.9, 1.4);
    const glassMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 3.1, 1.8);
    group.add(glass);

    // 4. Forward Twin Assault SMGs
    const gunGeo = new THREE.CylinderGeometry(0.2, 0.25, 3.2, 8);
    gunGeo.rotateX(Math.PI / 2);
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x09090b, metalness: 0.9 });
    for (const gx of [-1.2, 1.2]) {
      const gun = new THREE.Mesh(gunGeo, gunMat);
      gun.position.set(gx, 2.2, 6.8);
      group.add(gun);
    }

    // 5. Aft Cargo Platform: Crown Smuggle Diamond Gemstone
    const platformGeo = new THREE.BoxGeometry(3.8, 0.8, 3.8);
    const platformMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.7 });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.set(0, 2.2, -3.8);
    group.add(platform);

    // Four corner gold hazard pylons
    const pylonGeo = new THREE.CylinderGeometry(0.15, 0.15, 1.8, 6);
    const pylonMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8 });
    for (const px of [-1.5, 1.5]) {
      for (const pz of [-1.5, 1.5]) {
        const pylon = new THREE.Mesh(pylonGeo, pylonMat);
        pylon.position.set(px, 3.0, -3.8 + pz);
        group.add(pylon);
      }
    }

    // Rotating Crown Diamond Gemstone Mesh
    const gemGeo = new THREE.OctahedronGeometry(1.6, 0);
    const gemMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0ea5e9,
      emissiveIntensity: 0.9,
      roughness: 0.1,
      metalness: 0.95
    });
    this.diamondGem = new THREE.Mesh(gemGeo, gemMat);
    this.diamondGem.position.set(0, 3.8, -3.8);
    group.add(this.diamondGem);

    // Glowing amber beacon on roof
    const beaconGeo = new THREE.SphereGeometry(0.35, 8, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const beacon = new THREE.Mesh(beaconGeo, beaconMat);
    beacon.position.set(0, 3.8, 0.6);
    group.add(beacon);

    return group;
  }

  update(dt) {
    super.update(dt);
    if (!this.alive) return;

    // Spin Crown Diamond gemstone on aft deck
    if (this.diamondGem) {
      this.diamondGem.rotation.y += dt * 3.2;
      this.diamondGem.rotation.x += dt * 1.6;
    }
  }

  _updatePatrol(dt) {
    // Steer along waypoint route
    const wp = this.waypoints[this.currentWpIndex];
    const dx = wp.x - this.position.x;
    const dz = wp.z - this.position.z;
    const dist = Math.hypot(dx, dz);

    if (dist < 32) {
      this.currentWpIndex = (this.currentWpIndex + 1) % this.waypoints.length;
    }

    this._steerToward(wp.x, wp.z, dt, this.faction.baseSpeed * 0.7);
  }

  takeDamage(amount, attacker) {
    super.takeDamage(amount, attacker);
    // Alert convoy escorts to engage attacker
    if (attacker && this.escorts) {
      for (const esc of this.escorts) {
        if (esc && esc.alive && esc.state !== 'ALERTED') {
          esc.state = 'ALERTED';
          esc.target = attacker;
          esc.alertTimer = 16;
        }
      }
    }
  }

  die() {
    super.die();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.75);

    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 36, 0x18181b);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 24, 0xf59e0b);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 20, 0x38bdf8);
    }

    // Spawn guaranteed Crown Diamond Smuggle Cache pickup!
    if (this.world && this.world.spawnDiamondCache) {
      this.world.spawnDiamondCache(this.position.x, this.position.z);
    }

    if (this.manager.player && this.manager.player.triggerStunt) {
      this.manager.player.triggerStunt('👑 CONVOY HEIST COMPLETE! +1500 PTS', 1500);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '👑 [CARTEL COMMS]: "MAYDAY! FLAGSHIP HIT! THE CROWN DIAMOND IS FLOATING IN OPEN WATER!"';
      dispatch.style.color = '#ef4444';
    }
  }
}

export class CartelConvoyEscort extends EnemyBoat {
  constructor(scene, world, x, z, manager, leader, offsetX, offsetZ) {
    super(scene, world, CONFIG.FACTIONS.GANGSTER, x, z, manager);
    this.isConvoyEscort = true;
    this.leader = leader;
    this.offsetX = offsetX;
    this.offsetZ = offsetZ;
    this.health = 80;
    this.maxHealth = 80;
  }

  _updatePatrol(dt) {
    if (this.leader && this.leader.alive) {
      // Calculate world position corresponding to leader offset
      const lRot = this.leader.rotation;
      const cos = Math.cos(lRot);
      const sin = Math.sin(lRot);

      // Local offset rotated by leader heading
      const wx = this.leader.position.x + cos * this.offsetX + sin * this.offsetZ;
      const wz = this.leader.position.z - sin * this.offsetX + cos * this.offsetZ;

      const dist = Math.hypot(wx - this.position.x, wz - this.position.z);
      const targetSpeed = dist > 20 ? this.faction.baseSpeed * 1.1 : this.faction.baseSpeed * 0.7;
      this._steerToward(wx, wz, dt, targetSpeed);
    } else {
      super._updatePatrol(dt);
    }
  }
}

export class IroncladGalleon extends EnemyBoat {
  constructor(scene, world, x, z, manager) {
    const config = CONFIG.FACTIONS.IRONCLAD_GALLEON || {
      id: 'pirates',
      subType: 'ironclad_galleon',
      name: "Blackbeard's Ironclad Galleon",
      color: 0x451a03,
      hudColor: '#d97706',
      hullColor: 0x271306,
      cabinColor: 0x1c1917,
      stripeColor: 0xd97706,
      baseSpeed: 42,
      turnSpeed: 1.3,
      health: 280,
      damage: 26,
      fireRate: 1.2,
      spread: 0.10,
      detectRadius: 280,
      visionAngle: Math.PI * 0.85,
      alertRadioRadius: 400,
      scoreValue: 1800
    };
    super(scene, world, config, x, z, manager);
    this.isIronclad = true;
    this.radius = 7.5;
    this.health = config.health || 280;
    this.maxHealth = this.health;
    this.broadsideCooldown = 2.4;
    this.mineDropCooldown = 4.5;

    // Skull Cove patrol waypoints circling pirate waters
    this.waypoints = [
      { x: 880, z: -680 },
      { x: 760, z: -550 },
      { x: 920, z: -480 },
      { x: 1050, z: -620 },
      { x: 980, z: -760 }
    ];
    this.currentWpIndex = 0;
  }

  _buildMesh() {
    const group = new THREE.Group();

    // 1. Massive Armored War Galleon Hull
    const hullShape = new THREE.Shape();
    hullShape.moveTo(0, 10.5);      // High curved bow prow
    hullShape.lineTo(3.6, 4.5);
    hullShape.lineTo(3.4, -7.5);    // Broad stern
    hullShape.lineTo(-3.4, -7.5);
    hullShape.lineTo(-3.6, 4.5);
    hullShape.closePath();

    const extrudeSettings = { depth: 3.2, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.6, bevelThickness: 0.7 };
    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.rotateX(Math.PI / 2);

    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x271306,
      roughness: 0.55,
      metalness: 0.35
    });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 1.2;
    group.add(hull);

    // 2. Heavy Ironclad Armor Belts along Port & Starboard Sides
    const armorPlateGeo = new THREE.BoxGeometry(0.5, 2.2, 14.0);
    const armorPlateMat = new THREE.MeshStandardMaterial({
      color: 0x3f3f46,
      metalness: 0.88,
      roughness: 0.22
    });
    const portArmor = new THREE.Mesh(armorPlateGeo, armorPlateMat);
    portArmor.position.set(-3.7, 1.8, -1.0);
    group.add(portArmor);

    const stbdArmor = new THREE.Mesh(armorPlateGeo, armorPlateMat);
    stbdArmor.position.set(3.7, 1.8, -1.0);
    group.add(stbdArmor);

    // 3. Reinforced Iron Ram Prow with Spikes
    const ramGeo = new THREE.ConeGeometry(0.9, 3.5, 4);
    ramGeo.rotateX(Math.PI / 2);
    const ramMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.92, roughness: 0.15 });
    const ram = new THREE.Mesh(ramGeo, ramMat);
    ram.position.set(0, 1.2, 11.8);
    group.add(ram);

    // 4. Forecastle (Forward elevated gun deck)
    const foreDeckGeo = new THREE.BoxGeometry(4.2, 1.6, 4.0);
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.6 });
    const foreDeck = new THREE.Mesh(foreDeckGeo, woodMat);
    foreDeck.position.set(0, 2.8, 5.0);
    group.add(foreDeck);

    // 5. Towering 2-Tier Sterncastle (Aft fortress structure)
    const sternDeck1Geo = new THREE.BoxGeometry(5.2, 2.2, 5.5);
    const sternDeck1 = new THREE.Mesh(sternDeck1Geo, woodMat);
    sternDeck1.position.set(0, 3.2, -4.5);
    group.add(sternDeck1);

    const sternDeck2Geo = new THREE.BoxGeometry(4.0, 1.8, 3.5);
    const sternDeck2 = new THREE.Mesh(sternDeck2Geo, woodMat);
    sternDeck2.position.set(0, 5.0, -5.2);
    group.add(sternDeck2);

    // Glowing Stern Windows (Amber gallery)
    const windowGeo = new THREE.BoxGeometry(3.6, 0.9, 0.4);
    const windowMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const sternWin = new THREE.Mesh(windowGeo, windowMat);
    sternWin.position.set(0, 4.8, -7.05);
    group.add(sternWin);

    // Stern red skull beacon lantern
    const lanternGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.8, 6);
    const lanternMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const lantern = new THREE.Mesh(lanternGeo, lanternMat);
    lantern.position.set(0, 6.2, -6.5);
    group.add(lantern);

    const lanternLight = new THREE.PointLight(0xef4444, 1.8, 18);
    lanternLight.position.set(0, 6.4, -6.5);
    group.add(lanternLight);

    // 6. Dual Masts (Foremast & Mainmast)
    const mastGeo1 = new THREE.CylinderGeometry(0.25, 0.35, 12, 8);
    const mastGeo2 = new THREE.CylinderGeometry(0.3, 0.4, 15, 8);
    const sparGeo = new THREE.CylinderGeometry(0.12, 0.12, 5.5, 6);
    sparGeo.rotateZ(Math.PI / 2);
    const sparMat = new THREE.MeshStandardMaterial({ color: 0x57534e });

    // Foremast
    const foremast = new THREE.Mesh(mastGeo1, sparMat);
    foremast.position.set(0, 8.0, 3.5);
    group.add(foremast);
    const forespar = new THREE.Mesh(sparGeo, sparMat);
    forespar.position.set(0, 11.5, 3.5);
    group.add(forespar);

    // Mainmast
    const mainmast = new THREE.Mesh(mastGeo2, sparMat);
    mainmast.position.set(0, 9.5, -1.2);
    group.add(mainmast);
    const mainspar = new THREE.Mesh(sparGeo, sparMat);
    mainspar.position.set(0, 13.5, -1.2);
    group.add(mainspar);

    // Jolly Roger Pirate Flag atop Mainmast
    const flagGeo = new THREE.PlaneGeometry(2.4, 1.5);
    const flagMat = new THREE.MeshBasicMaterial({
      color: 0x09090b,
      side: THREE.DoubleSide
    });
    this.skullFlag = new THREE.Mesh(flagGeo, flagMat);
    this.skullFlag.position.set(1.3, 16.2, -1.2);
    group.add(this.skullFlag);

    // Skull emblem on flag
    const skullEmblemGeo = new THREE.CircleGeometry(0.45, 8);
    const skullEmblemMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc, side: THREE.DoubleSide });
    const skullMesh = new THREE.Mesh(skullEmblemGeo, skullEmblemMat);
    skullMesh.position.set(0, 0, 0.02);
    this.skullFlag.add(skullMesh);

    // 7. Broadside Cannons (3 Port, 3 Starboard)
    const cannonGeo = new THREE.CylinderGeometry(0.28, 0.38, 2.4, 8);
    cannonGeo.rotateZ(Math.PI / 2);
    const cannonMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.95, roughness: 0.1 });

    this.portCannons = [];
    this.stbdCannons = [];

    const zOffsets = [2.0, -1.0, -4.0];
    for (const zOff of zOffsets) {
      // Port cannon (facing -X)
      const portC = new THREE.Mesh(cannonGeo, cannonMat);
      portC.position.set(-3.8, 2.2, zOff);
      group.add(portC);
      this.portCannons.push(portC);

      // Starboard cannon (facing +X)
      const stbdC = new THREE.Mesh(cannonGeo, cannonMat);
      stbdC.position.set(3.8, 2.2, zOff);
      group.add(stbdC);
      this.stbdCannons.push(stbdC);
    }

    return group;
  }

  update(dt) {
    if (!this.alive) return;
    super.update(dt);

    // Wave flag gently
    if (this.skullFlag) {
      this.skullFlag.rotation.y = Math.sin((this.manager.world.time || 0) * 4) * 0.3;
    }
  }

  _updatePatrol(dt) {
    const wp = this.waypoints[this.currentWpIndex];
    const dx = wp.x - this.position.x;
    const dz = wp.z - this.position.z;
    const dist = Math.hypot(dx, dz);

    if (dist < 36) {
      this.currentWpIndex = (this.currentWpIndex + 1) % this.waypoints.length;
    }

    this._steerToward(wp.x, wp.z, dt, this.faction.baseSpeed * 0.7);
  }

  _updateCombat(dt, dx, dz, dist) {
    this.broadsideCooldown -= dt;
    this.mineDropCooldown -= dt;

    // Vector to target in galleon local space
    const cos = Math.cos(this.rotation);
    const sin = Math.sin(this.rotation);
    const forwardDot = (dx * sin + dz * cos) / (dist || 1);
    const rightDot = (dx * cos - dz * sin) / (dist || 1);

    // 1. Broadside Salvo Logic
    // If target is to the side (broadside alignment: |rightDot| > 0.4) and within 170m
    if (this.broadsideCooldown <= 0 && dist < 170 && Math.abs(rightDot) > 0.4) {
      this.broadsideCooldown = 2.6 + Math.random() * 0.6;
      const isStarboard = rightDot > 0;
      this._fireBroadsideSalvo(isStarboard);
    }

    // 2. Chased from behind: drop floating contact mine!
    // If target is behind (forwardDot < -0.6) and close (dist < 55)
    if (this.mineDropCooldown <= 0 && forwardDot < -0.6 && dist < 55) {
      this.mineDropCooldown = 5.5 + Math.random() * 2.0;
      this._dropSternMine();
    }

    // 3. Fallback forward cannon if facing target
    if (forwardDot > 0.65) {
      super._updateCombat(dt, dx, dz, dist);
    }
  }

  _fireBroadsideSalvo(isStarboard) {
    soundManager.playCannon();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.42);

    const cannons = isStarboard ? this.stbdCannons : this.portCannons;
    const sign = isStarboard ? 1 : -1;

    // Local right direction in world space
    const cos = Math.cos(this.rotation);
    const sin = Math.sin(this.rotation);
    const rightX = cos * sign;
    const rightZ = -sin * sign;

    for (let idx = 0; idx < cannons.length; idx++) {
      const c = cannons[idx];
      setTimeout(() => {
        if (!this.alive) return;
        const spreadAngle = (Math.random() - 0.5) * 0.12;
        const shotAngle = Math.atan2(rightX, rightZ) + spreadAngle;
        const dirX = Math.sin(shotAngle);
        const dirZ = Math.cos(shotAngle);

        const spawnX = this.position.x + cos * c.position.x + sin * c.position.z;
        const spawnZ = this.position.z - sin * c.position.x + cos * c.position.z;

        this.manager.weaponManager.spawnProjectile(
          spawnX,
          2.6,
          spawnZ,
          dirX,
          dirZ,
          CONFIG.FACTIONS.IRONCLAD_GALLEON.damage || 26,
          'cannon',
          this
        );
        soundManager.playCannon();
      }, idx * 120);
    }
  }

  _dropSternMine() {
    soundManager.playSplash();
    const backX = -Math.sin(this.rotation);
    const backZ = -Math.cos(this.rotation);
    const dropX = this.position.x + backX * 8.5;
    const dropZ = this.position.z + backZ * 8.5;

    // Deploy depth charge / naval mine
    const p = this.manager.weaponManager.spawnProjectile(
      dropX,
      0.5,
      dropZ,
      backX * 0.15,
      backZ * 0.15,
      45,
      'depth_charge',
      this
    );
    p.fuse = 5.0;

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '☠️ [GALLEON]: Blackbeard rolled an explosive pitch barrel off the stern!';
      dispatch.style.color = '#ef4444';
    }
  }

  die() {
    super.die();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.85);

    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, 3.5, this.position.z, 48, 0x271306);
      this.world.spawnVoxelCrumbles(this.position.x, 3.5, this.position.z, 28, 0x3f3f46);
      this.world.spawnVoxelCrumbles(this.position.x, 3.5, this.position.z, 24, 0xef4444);
    }

    // Spawn 3 floating Treasure Chest / Diamond Cache pickups around the sunken wreck!
    if (this.world && this.world.spawnDiamondCache) {
      this.world.spawnDiamondCache(this.position.x, this.position.z);
      this.world.spawnDiamondCache(this.position.x - 12, this.position.z + 8);
      this.world.spawnDiamondCache(this.position.x + 12, this.position.z - 8);
    }

    if (this.manager.player && this.manager.player.triggerStunt) {
      this.manager.player.triggerStunt("☠️ BLACKBEARD'S IRONCLAD SUNK! +1800 PTS", 1800, 5.0);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = "☠️ [COAST GUARD]: ALL SHIPS: BLACKBEARD'S IRONCLAD GALLEON HAS SUNK TO THE SEABED!";
      dispatch.style.color = '#ef4444';
    }
  }
}

export class CartelHovercraft extends EnemyBoat {
  constructor(scene, world, x, z, manager) {
    const cfg = {
      id: 'gangster_hovercraft',
      name: 'Cartel Armored Hovercraft',
      color: 0x18181b,
      hudColor: '#f59e0b',
      health: CONFIG.HOVERCRAFT.health || 190,
      baseSpeed: CONFIG.HOVERCRAFT.maxSpeed || 42,
      turnSpeed: 2.2,
      damage: CONFIG.HOVERCRAFT.autocannonDamage || 8,
      fireRate: CONFIG.HOVERCRAFT.fireRate || 0.20,
      spread: 0.12,
      detectRadius: 240,
      visionAngle: Math.PI * 0.85,
      alertRadioRadius: 350,
      scoreValue: CONFIG.HOVERCRAFT.stuntScore || 1200,
      scale: 1.25
    };
    super(scene, world, cfg, x, z, manager);
    this.id = cfg.id;
    this.name = cfg.name;
    this.isHovercraft = true;
    this.maxHealth = cfg.health;
    this.health = cfg.health;
    if (!this.rotors) this.rotors = [];
    this.hoverBob = Math.random() * Math.PI * 2;
    this.autocannonBurst = 0;
    this.autocannonTimer = 1.0;
  }

  _buildMesh() {
    this.rotors = [];
    const group = new THREE.Group();

    // 1. Inflated black rubber perimeter hover skirt
    const skirtGeo = new THREE.TorusGeometry(8.5, 1.8, 8, 20);
    skirtGeo.scale(0.85, 0.7, 1.35); // Elliptical skirt
    skirtGeo.rotateX(Math.PI / 2);
    const skirtMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.95,
      metalness: 0.1
    });
    const skirt = new THREE.Mesh(skirtGeo, skirtMat);
    skirt.position.y = 1.2;
    skirt.castShadow = true;
    group.add(skirt);

    // 2. Reinforced armored composite superstructure
    const deckGeo = new THREE.BoxGeometry(11, 2.6, 20);
    const deckMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.65,
      metalness: 0.55
    });
    const deck = new THREE.Mesh(deckGeo, deckMat);
    deck.position.y = 2.4;
    deck.castShadow = true;
    group.add(deck);

    // Hazard amber carbon racing stripes
    const stripeGeo = new THREE.BoxGeometry(1.6, 0.2, 19.5);
    const stripeMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.4,
      metalness: 0.3
    });
    const sLeft = new THREE.Mesh(stripeGeo, stripeMat);
    sLeft.position.set(-3.6, 3.75, 0);
    group.add(sLeft);

    const sRight = new THREE.Mesh(stripeGeo, stripeMat);
    sRight.position.set(3.6, 3.75, 0);
    group.add(sRight);

    // 3. Tinted amber cockpit greenhouse bridge
    const cabinGeo = new THREE.BoxGeometry(5.2, 2.4, 7.5);
    const cabinMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.65,
      roughness: 0.2,
      metalness: 0.4
    });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 4.4, 2.5);
    group.add(cabin);

    // 4. Twin Aft Ducted Propulsion Fans
    const shroudGeo = new THREE.CylinderGeometry(2.4, 2.4, 1.8, 14, 1, true);
    shroudGeo.rotateX(Math.PI / 2);
    const shroudMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.6,
      metalness: 0.7
    });

    const bladeGeo = new THREE.BoxGeometry(0.3, 4.2, 0.4);
    const bladeMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.8,
      roughness: 0.3
    });

    for (const sx of [-3.4, 3.4]) {
      const shroud = new THREE.Mesh(shroudGeo, shroudMat);
      shroud.position.set(sx, 4.0, -7.5);
      shroud.castShadow = true;
      group.add(shroud);

      const bladeGroup = new THREE.Group();
      const blade1 = new THREE.Mesh(bladeGeo, bladeMat);
      bladeGroup.add(blade1);
      const blade2 = new THREE.Mesh(bladeGeo, bladeMat);
      blade2.rotation.z = Math.PI / 2;
      bladeGroup.add(blade2);

      bladeGroup.position.set(sx, 4.0, -7.5);
      group.add(bladeGroup);
      this.rotors.push(bladeGroup);
    }

    // 5. Twin Forward Autocannons on Bow Sponsons
    const canonGeo = new THREE.CylinderGeometry(0.2, 0.25, 4.2, 8);
    canonGeo.rotateX(Math.PI / 2);
    const canonMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.2
    });

    const cLeft = new THREE.Mesh(canonGeo, canonMat);
    cLeft.position.set(-4.5, 2.8, 8.5);
    group.add(cLeft);

    const cRight = new THREE.Mesh(canonGeo, canonMat);
    cRight.position.set(4.5, 2.8, 8.5);
    group.add(cRight);

    // Under-skirt cushion air glow
    const cushionLight = new THREE.PointLight(0xf59e0b, 2.0, 18);
    cushionLight.position.y = 0.5;
    group.add(cushionLight);

    return group;
  }

  update(dt) {
    if (!this.alive) return;
    super.update(dt);

    // Spin ducted fan blades continuously with speed
    const fanSpeed = 16.0 + Math.abs(this.speed) * 0.8;
    for (const r of this.rotors) {
      r.rotation.z += dt * fanSpeed;
    }

    // Smooth buoyant hover altitude hovering above water waves
    this.hoverBob += dt * 3.5;
    const wave = this.world ? this.world.getWaveHeight(this.position.x, this.position.z) : 0;
    this.position.y = 1.2 + wave + Math.sin(this.hoverBob) * 0.25;
    this.mesh.position.y = this.position.y;

    // Autocannon attack behavior when targeting player or rivals
    if (this.state === 'ALERTED' && this.target && this.target.alive) {
      const dx = this.target.position.x - this.position.x;
      const dz = this.target.position.z - this.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 140) {
        this.autocannonTimer -= dt;
        if (this.autocannonTimer <= 0) {
          if (this.autocannonBurst <= 0) {
            this.autocannonBurst = CONFIG.HOVERCRAFT.burstCount || 4;
            this.autocannonTimer = 2.4;
          } else {
            this.autocannonBurst--;
            this.autocannonTimer = CONFIG.HOVERCRAFT.fireRate || 0.20;

            const aimAngle = Math.atan2(dx, dz) + (Math.random() - 0.5) * 0.12;
            const fwdX = Math.sin(aimAngle);
            const fwdZ = Math.cos(aimAngle);

            // Alternating sponson fire
            const side = (this.autocannonBurst % 2 === 0) ? -4.5 : 4.5;
            const cos = Math.cos(this.rotation);
            const sin = Math.sin(this.rotation);
            const spawnX = this.position.x + cos * side + sin * 8.5;
            const spawnZ = this.position.z - sin * side + cos * 8.5;

            if (this.manager && this.manager.weaponManager) {
              this.manager.weaponManager.spawnProjectile(
                spawnX,
                2.8,
                spawnZ,
                fwdX,
                fwdZ,
                CONFIG.HOVERCRAFT.autocannonDamage || 8,
                'mg',
                this
              );
            }
            soundManager.playAutocannon();
          }
        }
      }
    }
  }

  die() {
    super.die();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.72);

    // Violent skirt blowout & turbine explosion
    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 36, 0x18181b);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 24, 0xf59e0b);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 20, 0x0f172a);
      this.world.spawnVoxelCrumbles(this.position.x, 3.0, this.position.z, 16, 0xffffff);
    }

    // Drop Railgun Ammo Crate pickup upon defeat!
    if (this.world && this.world.addPickup) {
      this.world.addPickup(this.position.x, this.position.z, 'railgun_crate');
    }

    if (this.manager && this.manager.player && this.manager.player.triggerStunt) {
      this.manager.player.triggerStunt('💥 CARTEL HOVERCRAFT SUNK! +1200 PTS', CONFIG.HOVERCRAFT.stuntScore || 1200, 5.0);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '⚠️ [CARTEL FREQ]: Heavy Hovercraft gunship neutralized! Prototype railgun cache dropped!';
      dispatch.style.color = '#f59e0b';
    }
  }
}

export class SecurityCatamaran extends EnemyBoat {
  constructor(scene, world, x, z, manager) {
    const cfg = {
      id: 'security_catamaran',
      name: 'Casino Security Catamaran',
      color: 0x090d16,
      hudColor: '#00f2fe',
      health: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.health) || 140,
      baseSpeed: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.baseSpeed) || 38,
      turnSpeed: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.turnSpeed) || 2.5,
      damage: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.damage) || 9,
      fireRate: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.fireRate) || 0.28,
      spread: 0.12,
      detectRadius: 220,
      visionAngle: Math.PI * 0.85,
      alertRadioRadius: 300,
      scoreValue: (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.stuntScore) || 750,
      scale: 1.15
    };
    super(scene, world, cfg, x, z, manager);
    this.id = cfg.id;
    this.name = cfg.name;
    this.isSecurityCatamaran = true;
    this.radius = 5.2;
    this.maxHealth = cfg.health;
    this.health = cfg.health;
    this.strobeTimer = 0;
    this.shockBurst = 0;
    this.shockTimer = 1.0;
  }

  _buildMesh() {
    const group = new THREE.Group();

    // 1. Sleek Twin Catamaran Hulls (Port & Starboard)
    const hullGeo = new THREE.BoxGeometry(2.4, 2.2, 18);
    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      roughness: 0.4,
      metalness: 0.7
    });

    const hPort = new THREE.Mesh(hullGeo, hullMat);
    hPort.position.set(-4.0, 1.1, 0);
    hPort.castShadow = true;
    group.add(hPort);

    const hStbd = new THREE.Mesh(hullGeo, hullMat);
    hStbd.position.set(4.0, 1.1, 0);
    hStbd.castShadow = true;
    group.add(hStbd);

    // Gold waterline accent stripes
    const stripeGeo = new THREE.BoxGeometry(0.3, 0.4, 17.8);
    const stripeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.2 });
    const sP = new THREE.Mesh(stripeGeo, stripeMat);
    sP.position.set(-2.7, 1.4, 0);
    group.add(sP);
    const sS = new THREE.Mesh(stripeGeo, stripeMat);
    sS.position.set(2.7, 1.4, 0);
    group.add(sS);

    // 2. Central Bridging Hydrofoil Cross-Deck
    const bridgeDeckGeo = new THREE.BoxGeometry(7.0, 1.2, 13);
    const bridgeDeckMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 });
    const bDeck = new THREE.Mesh(bridgeDeckGeo, bridgeDeckMat);
    bDeck.position.set(0, 2.0, -1.0);
    group.add(bDeck);

    // 3. Tinted Aerodynamic Greenhouse Cockpit
    const cabinGeo = new THREE.BoxGeometry(4.6, 1.8, 6.5);
    const cabinMat = new THREE.MeshStandardMaterial({
      color: 0x00f2fe,
      roughness: 0.2,
      metalness: 0.5,
      transparent: true,
      opacity: 0.75
    });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 3.2, 1.0);
    group.add(cabin);

    // 4. Roof Siren Beacon (Amber & Cyan)
    const strobeGeo = new THREE.SphereGeometry(0.4, 6, 6);
    const strobeAmber = new THREE.Mesh(strobeGeo, new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.9 }));
    strobeAmber.position.set(-0.8, 4.3, 0);
    group.add(strobeAmber);
    this.strobeAmber = strobeAmber;

    const strobeCyan = new THREE.Mesh(strobeGeo, new THREE.MeshBasicMaterial({ color: 0x00f2fe, transparent: true, opacity: 0.9 }));
    strobeCyan.position.set(0.8, 4.3, 0);
    group.add(strobeCyan);
    this.strobeCyan = strobeCyan;

    // Underglow neon projector
    const ugLight = new THREE.PointLight(0x00f2fe, 2.0, 16);
    ugLight.position.y = 0.5;
    group.add(ugLight);

    return group;
  }

  update(dt) {
    if (!this.alive) return;
    super.update(dt);

    // Flash security strobe beacons
    this.strobeTimer += dt * 10;
    const isAmber = Math.sin(this.strobeTimer) > 0;
    if (this.strobeAmber) this.strobeAmber.material.opacity = (this.state === 'ALERTED' && isAmber) ? 1.0 : 0.15;
    if (this.strobeCyan) this.strobeCyan.material.opacity = (this.state === 'ALERTED' && !isAmber) ? 1.0 : 0.15;

    // Electrified Shock Cannon firing behavior
    if (this.state === 'ALERTED' && this.target && this.target.alive) {
      const dx = this.target.position.x - this.position.x;
      const dz = this.target.position.z - this.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 130) {
        this.shockTimer -= dt;
        if (this.shockTimer <= 0) {
          if (this.shockBurst <= 0) {
            this.shockBurst = 3;
            this.shockTimer = 2.2;
          } else {
            this.shockBurst--;
            this.shockTimer = 0.22;

            const aimAngle = Math.atan2(dx, dz) + (Math.random() - 0.5) * 0.10;
            const fwdX = Math.sin(aimAngle);
            const fwdZ = Math.cos(aimAngle);

            if (this.manager && this.manager.weaponManager) {
              this.manager.weaponManager.spawnProjectile(
                this.position.x,
                2.2,
                this.position.z,
                fwdX,
                fwdZ,
                (CONFIG.SECURITY_CATAMARAN && CONFIG.SECURITY_CATAMARAN.damage) || 9,
                'mg',
                this
              );
            }
            soundManager.playShockCannon();
          }
        }
      }
    }
  }

  die() {
    super.die();
    if (window.game && window.game.addTrauma) window.game.addTrauma(0.48);

    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, 2.5, this.position.z, 28, 0x090d16);
      this.world.spawnVoxelCrumbles(this.position.x, 2.5, this.position.z, 18, 0xf59e0b);
      this.world.spawnVoxelCrumbles(this.position.x, 2.5, this.position.z, 14, 0x00f2fe);
    }

    // Drop contraband crate
    if (this.world && this.world.addPickup) {
      this.world.addPickup(this.position.x, this.position.z, 'contraband');
    }

    if (this.manager && this.manager.player && this.manager.player.triggerStunt) {
      this.manager.player.triggerStunt('⚡ CASINO SECURITY NEUTRALIZED! +750 PTS', 750, 4.0);
    }

    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '⚠️ [CASINO SECURITY]: Unit 4 patrol craft sunk! Contraband cargo floating!';
      dispatch.style.color = '#00f2fe';
    }
  }
}

export class PoliceHelicopter {
  constructor(scene, player, weaponManager) {
    this.scene = scene;
    this.player = player;
    this.weaponManager = weaponManager;
    this.alive = true;
    this.health = CONFIG.HELICOPTER.health;
    this.empDisabledTimer = 0;
    this.position = new THREE.Vector3(player.position.x, CONFIG.HELICOPTER.altitude, player.position.z - 80);
    this.fireTimer = 1.2;
    this.burstLeft = 0;

    this.mesh = this._buildMesh();
    this.scene.add(this.mesh);

    // Dynamic water searchlight spot on sea surface
    const spotGeo = new THREE.RingGeometry(2.0, 16, 24);
    spotGeo.rotateX(-Math.PI / 2);
    const spotMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35,
      depthWrite: false
    });
    this.waterSpot = new THREE.Mesh(spotGeo, spotMat);
    this.scene.add(this.waterSpot);

    // Police Comms Dispatch Alert
    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '🚁 [AIR-1 DISPATCH]: SUSPECT VESSEL SIGHTED IN CHANNEL! COMMENCING SEARCHLIGHT PURSUIT!';
      dispatch.style.color = '#38bdf8';
    }
    soundManager.playPoliceSirenChirp();
  }

  _buildMesh() {
    const group = new THREE.Group();

    // Fuselage
    const bodyGeo = new THREE.BoxGeometry(4.5, 3.2, 11);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3, metalness: 0.6 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    group.add(body);

    // Windshield
    const noseGeo = new THREE.SphereGeometry(2.3, 8, 8);
    const noseMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 });
    const nose = new THREE.Mesh(noseGeo, noseMat);
    nose.position.set(0, 0.3, 5.0);
    group.add(nose);

    // Tail boom
    const tailGeo = new THREE.CylinderGeometry(0.5, 0.9, 10, 6);
    tailGeo.rotateX(Math.PI / 2);
    const tailMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc });
    const tail = new THREE.Mesh(tailGeo, tailMat);
    tail.position.set(0, 0.6, -9.5);
    group.add(tail);

    // Tail fin
    const finGeo = new THREE.BoxGeometry(0.3, 2.6, 2.0);
    const fin = new THREE.Mesh(finGeo, bodyMat);
    fin.position.set(0, 1.6, -14.0);
    group.add(fin);

    // Main Rotor Blades
    const rotorGeo = new THREE.BoxGeometry(20, 0.1, 0.9);
    const rotorMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
    const rotor = new THREE.Mesh(rotorGeo, rotorMat);
    rotor.position.set(0, 2.2, 0);
    group.add(rotor);
    this.rotor = rotor;

    // Tail Rotor Blades
    const tailRotorGeo = new THREE.BoxGeometry(0.1, 4.2, 0.4);
    const tailRotorMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
    const tailRotor = new THREE.Mesh(tailRotorGeo, tailRotorMat);
    tailRotor.position.set(0.4, 1.8, -14.2);
    group.add(tailRotor);
    this.tailRotor = tailRotor;

    // Flashing Strobe Beacons (Red on tail, Blue on belly)
    const strobeGeo = new THREE.SphereGeometry(0.55, 6, 6);
    const strobeRed = new THREE.Mesh(strobeGeo, new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.9 }));
    strobeRed.position.set(0, 3.2, -14.0);
    group.add(strobeRed);
    this.strobeRed = strobeRed;

    const strobeBlue = new THREE.Mesh(strobeGeo, new THREE.MeshBasicMaterial({ color: 0x00f2fe, transparent: true, opacity: 0.9 }));
    strobeBlue.position.set(0, -1.7, 0);
    group.add(strobeBlue);
    this.strobeBlue = strobeBlue;

    // Searchlight Cone pointing down to water
    const beamGeo = new THREE.ConeGeometry(CONFIG.HELICOPTER.searchlightRadius, 45, 16, 1, true);
    beamGeo.rotateX(-Math.PI / 2);
    beamGeo.translate(0, 0, 22.5);
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(0, -1.5, 0);
    beam.rotation.x = Math.PI / 2;
    group.add(beam);

    return group;
  }

  update(dt) {
    if (!this.alive) return;

    // EMP Shockwave disabling state
    if (this.empDisabledTimer && this.empDisabledTimer > 0) {
      this.empDisabledTimer -= dt;
      if (this.rotor) this.rotor.rotation.y += 6 * dt;
      if (this.tailRotor) this.tailRotor.rotation.x += 8 * dt;
      if (this.waterSpot) this.waterSpot.scale.set(0.1, 0.1, 0.1);
      if (this.strobeRed) this.strobeRed.material.opacity = 0.1;
      if (this.strobeBlue) this.strobeBlue.material.opacity = 0.1;
      this.position.y = Math.max(14, this.position.y - 12 * dt);
      this.mesh.position.copy(this.position);
      if (Math.random() < 0.25 && window.game && window.game.world) {
        window.game.world.spawnVoxelCrumbles(this.position.x, this.position.y, this.position.z, 2, 0xa855f7);
      }
      return;
    }

    if (this.rotor) this.rotor.rotation.y += 32 * dt;
    if (this.tailRotor) this.tailRotor.rotation.x += 45 * dt;

    // Blink strobes
    const blink = Math.sin(Date.now() * 0.014) > 0;
    if (this.strobeRed) this.strobeRed.material.opacity = blink ? 1.0 : 0.15;
    if (this.strobeBlue) this.strobeBlue.material.opacity = !blink ? 1.0 : 0.15;

    const targetX = this.player.position.x;
    const targetZ = this.player.position.z;
    this.position.x = THREE.MathUtils.lerp(this.position.x, targetX + Math.sin(Date.now() * 0.001) * 22, dt * 1.8);
    this.position.z = THREE.MathUtils.lerp(this.position.z, targetZ + Math.cos(Date.now() * 0.001) * 22, dt * 1.8);
    this.position.y = CONFIG.HELICOPTER.altitude + Math.sin(Date.now() * 0.002) * 2.5;

    const angle = Math.atan2(targetX - this.position.x, targetZ - this.position.z);
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = angle;
    this.mesh.rotation.x = 0.12;

    // Update searchlight caustic spot on water plane
    if (this.waterSpot) {
      this.waterSpot.position.set(this.position.x, 0.4, this.position.z);
      const s = 1.0 + Math.sin(Date.now() * 0.006) * 0.12;
      this.waterSpot.scale.set(s, s, s);
    }

    // Audio distance modulation
    const distToPlayer = Math.hypot(this.position.x - targetX, this.position.z - targetZ);
    soundManager.updateHelicopterSound(true, distToPlayer);

    this.fireTimer -= dt;
    if (this.fireTimer <= 0) {
      if (this.burstLeft <= 0) {
        this.burstLeft = CONFIG.HELICOPTER.burstCount;
        this.fireTimer = 2.5;
      } else {
        this.burstLeft--;
        this.fireTimer = CONFIG.HELICOPTER.fireRate;
        const spreadAngle = (Math.random() - 0.5) * 0.22;
        const dirX = Math.sin(angle + spreadAngle);
        const dirZ = Math.cos(angle + spreadAngle);
        this.weaponManager.spawnProjectile(
          this.position.x,
          this.position.y - 2,
          this.position.z,
          dirX,
          dirZ,
          CONFIG.HELICOPTER.damage,
          'mg',
          this
        );
        soundManager.playGunfire(0.9);
      }
    }
  }

  takeDamage(amount) {
    this.health -= amount;
    if (this.health <= 0) {
      this.alive = false;
      soundManager.updateHelicopterSound(false);
      soundManager.playExplosion(1.0, 1.4);
      if (window.game && window.game.addTrauma) window.game.addTrauma(0.68);
      if (this.player && this.player.triggerStunt) {
        this.player.triggerStunt('🚁 AIR-1 DOWNED!', 1200);
      }
      if (window.game && window.game.world) {
        window.game.world.spawnVoxelCrumbles(this.position.x, 15, this.position.z, 45, 0xef4444);
        window.game.world.spawnVoxelCrumbles(this.position.x, 15, this.position.z, 25, 0x0284c7);
      }
      this.destroy();

      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '💥 [RADIO SCANNER]: MAYDAY! AIR-1 IS DOWN IN THE WATERWAYS!';
        dispatch.style.color = '#ef4444';
      }
    }
  }

  destroy() {
    this.alive = false;
    soundManager.updateHelicopterSound(false);
    if (this.waterSpot) {
      this.scene.remove(this.waterSpot);
      this.waterSpot = null;
    }
    if (this.mesh) {
      this.scene.remove(this.mesh);
      this.mesh = null;
    }
  }
}

export class NavalZeppelin {
  constructor(scene, world, player, weaponManager, manager, x = 200, z = -350) {
    this.scene = scene;
    this.world = world;
    this.player = player;
    this.weaponManager = weaponManager;
    this.manager = manager;

    this.id = 'naval_zeppelin';
    this.name = 'Naval Zeppelin Gunship ("The Iron Valkyrie")';
    this.altitude = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.altitude) || 62;
    this.maxHealth = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.health) || 380;
    this.health = this.maxHealth;
    this.speed = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.speed) || 18;
    this.alive = true;
    this.isZeppelin = true;
    this.isAerial = true;
    this.radius = 28;

    this.position = new THREE.Vector3(x, this.altitude, z);
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.rotation = Math.PI * 0.25;

    this.bombCooldown = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.bombRate) || 3.5;
    this.bombTimer = 2.0;
    this.turretTimer = 0.5;
    this.burstLeft = 0;
    this.empDisabledTimer = 0;
    this.sirenTimer = 0;

    // Waypoint patrol circuit
    this.patrolWaypoints = [
      { x: 200, z: -350 },
      { x: 550, z: -200 },
      { x: 300, z: 200 },
      { x: -250, z: 150 },
      { x: -400, z: -350 }
    ];
    this.currentWpIndex = 0;

    this.outriggerPropellers = [];
    this.mesh = this._buildMesh();
    this.scene.add(this.mesh);

    // Dynamic searchlight ground caustic spot on water plane
    const spotRadius = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.searchlightRadius) || 36;
    const spotGeo = new THREE.CircleGeometry(spotRadius, 24);
    spotGeo.rotateX(-Math.PI / 2);
    const spotMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.32,
      depthWrite: false
    });
    this.waterSpot = new THREE.Mesh(spotGeo, spotMat);
    this.scene.add(this.waterSpot);

    // Radio Scanner Dispatch Warning
    const dispatch = document.getElementById('dispatch-msg');
    if (dispatch) {
      dispatch.innerText = '🎈 [AIR DEFENSE RADAR]: "WARNING! THE IRON VALKYRIE ZEPPELIN GUNSHIP HAS ENTERED AIRSPACE!"';
      dispatch.style.color = '#f59e0b';
    }
  }

  _buildMesh() {
    const group = new THREE.Group();

    // 1. Giant Rigid Dirigible Envelope (Length ~105m, Diameter 24m)
    const envelopeGeo = new THREE.SphereGeometry(12.5, 20, 16);
    envelopeGeo.scale(1.0, 0.92, 4.2);
    const envelopeMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.65,
      roughness: 0.42
    });
    const envelope = new THREE.Mesh(envelopeGeo, envelopeMat);
    envelope.castShadow = true;
    group.add(envelope);

    // 2. Brass Tactical Rib Banding along Envelope
    const ribMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.8,
      roughness: 0.3
    });
    [-32, -16, 0, 16, 32].forEach(zOffset => {
      const ringGeo = new THREE.TorusGeometry(12.4, 0.28, 8, 24);
      const ring = new THREE.Mesh(ringGeo, ribMat);
      ring.position.set(0, 0, zOffset);
      group.add(ring);
    });

    // 3. Stabilizer Fins at Stern
    const finMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5 });
    const vFinGeo = new THREE.BoxGeometry(0.8, 12, 16);
    const topFin = new THREE.Mesh(vFinGeo, finMat);
    topFin.position.set(0, 11, -38);
    group.add(topFin);

    const bottomFin = new THREE.Mesh(vFinGeo, finMat);
    bottomFin.position.set(0, -11, -38);
    group.add(bottomFin);

    const hFinGeo = new THREE.BoxGeometry(16, 0.8, 16);
    const hFin = new THREE.Mesh(hFinGeo, finMat);
    hFin.position.set(0, 0, -38);
    group.add(hFin);

    // 4. Suspended Command Gondola
    const gondolaGeo = new THREE.BoxGeometry(6.2, 4.4, 36);
    const gondolaMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      metalness: 0.85,
      roughness: 0.25
    });
    const gondola = new THREE.Mesh(gondolaGeo, gondolaMat);
    gondola.position.set(0, -12.5, 6);
    group.add(gondola);

    // Observation Bridge Windows
    const bridgeGeo = new THREE.BoxGeometry(5.8, 2.0, 4.0);
    const bridgeMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridge.position.set(0, -12.2, 22.5);
    group.add(bridge);

    // Ventral Autocannon Turrets
    const turretMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9 });
    const tFwd = new THREE.Mesh(new THREE.SphereGeometry(1.4, 8, 8), turretMat);
    tFwd.position.set(0, -14.8, 16);
    group.add(tFwd);

    const barrelFwd = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 3.2, 6), turretMat);
    barrelFwd.rotateX(Math.PI / 2);
    barrelFwd.position.set(0, -15.0, 17.5);
    group.add(barrelFwd);

    const tAft = new THREE.Mesh(new THREE.SphereGeometry(1.4, 8, 8), turretMat);
    tAft.position.set(0, -14.8, -6);
    group.add(tAft);

    // 5. Outrigger Propulsion Nacelles & Propellers
    const nacelleGeo = new THREE.CylinderGeometry(1.8, 1.8, 10, 8);
    nacelleGeo.rotateX(Math.PI / 2);
    const nacelleMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7 });
    const propMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    [-18, 18].forEach(xSign => {
      const strutGeo = new THREE.BoxGeometry(10, 0.4, 1.8);
      const strut = new THREE.Mesh(strutGeo, gondolaMat);
      strut.position.set(xSign * 0.55, -6.5, -8);
      group.add(strut);

      const nacelle = new THREE.Mesh(nacelleGeo, nacelleMat);
      nacelle.position.set(xSign, -6.5, -8);
      group.add(nacelle);

      const propGroup = new THREE.Group();
      const blade1 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6.2, 0.6), propMat);
      const blade2 = new THREE.Mesh(new THREE.BoxGeometry(6.2, 0.2, 0.6), propMat);
      propGroup.add(blade1);
      propGroup.add(blade2);
      propGroup.position.set(xSign, -6.5, -13.2);
      group.add(propGroup);
      this.outriggerPropellers.push(propGroup);
    });

    // 6. Searchlight Cone from Gondola Nose
    const beamRadius = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.searchlightRadius) || 36;
    const beamGeo = new THREE.ConeGeometry(beamRadius, 62, 16, 1, true);
    beamGeo.rotateX(-Math.PI / 2);
    beamGeo.translate(0, 0, 31);
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending
    });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(0, -14.0, 18);
    beam.rotation.x = Math.PI / 2;
    group.add(beam);
    this.searchlightBeam = beam;

    return group;
  }

  update(dt) {
    if (!this.alive) return;

    // Spin propellers
    const propSpeed = this.empDisabledTimer > 0 ? 5 : 28;
    for (const prop of this.outriggerPropellers) {
      prop.rotation.z += propSpeed * dt;
    }

    // EMP Shockwave disabling state
    if (this.empDisabledTimer > 0) {
      this.empDisabledTimer -= dt;
      if (this.waterSpot) this.waterSpot.scale.set(0.1, 0.1, 0.1);
      if (this.searchlightBeam) this.searchlightBeam.visible = false;
      this.position.y = Math.max(38, this.position.y - 4.5 * dt);
      this.mesh.position.copy(this.position);
      if (Math.random() < 0.3 && this.world && this.world.spawnVoxelCrumbles) {
        this.world.spawnVoxelCrumbles(this.position.x, this.position.y - 12, this.position.z, 2, 0xa855f7);
      }
      return;
    }

    if (this.searchlightBeam) this.searchlightBeam.visible = true;

    // Target tracking: Player boat
    const targetX = this.player.position.x;
    const targetZ = this.player.position.z;
    const dx = targetX - this.position.x;
    const dz = targetZ - this.position.z;
    const distToPlayer = Math.hypot(dx, dz);

    const isEngaged = distToPlayer < 280 || (this.player.wantedLevel >= 3 && distToPlayer < 450);

    let targetHeading;
    if (isEngaged) {
      targetHeading = Math.atan2(dx, dz);
      this.sirenTimer -= dt;
      if (this.sirenTimer <= 0) {
        this.sirenTimer = 18.0;
        soundManager.playAirRaidSiren();
      }
    } else {
      const wp = this.patrolWaypoints[this.currentWpIndex];
      const wdx = wp.x - this.position.x;
      const wdz = wp.z - this.position.z;
      if (Math.hypot(wdx, wdz) < 60) {
        this.currentWpIndex = (this.currentWpIndex + 1) % this.patrolWaypoints.length;
      }
      targetHeading = Math.atan2(wdx, wdz);
    }

    let angleDiff = targetHeading - this.rotation;
    while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
    while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
    this.rotation += Math.sign(angleDiff) * Math.min(Math.abs(angleDiff), dt * 0.45);

    const curSpeed = isEngaged ? this.speed * 1.15 : this.speed;
    this.position.x += Math.sin(this.rotation) * curSpeed * dt;
    this.position.z += Math.cos(this.rotation) * curSpeed * dt;
    this.position.y = this.altitude + Math.sin(Date.now() * 0.0008) * 3.5;

    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotation;
    this.mesh.rotation.z = -angleDiff * 0.18;

    if (this.waterSpot) {
      this.waterSpot.position.set(this.position.x, 0.4, this.position.z);
      const pulse = 1.0 + Math.sin(Date.now() * 0.004) * 0.1;
      this.waterSpot.scale.set(pulse, pulse, pulse);
    }

    // Heavy Autocannon Barrage
    if (isEngaged && distToPlayer < 220) {
      this.turretTimer -= dt;
      if (this.turretTimer <= 0) {
        if (this.burstLeft <= 0) {
          this.burstLeft = 6;
          this.turretTimer = 2.8;
        } else {
          this.burstLeft--;
          this.turretTimer = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.turretRate) || 0.22;
          const spread = (Math.random() - 0.5) * 0.16;
          const shotAngle = Math.atan2(dx, dz) + spread;
          const sX = Math.sin(shotAngle);
          const sZ = Math.cos(shotAngle);

          this.weaponManager.spawnProjectile(
            this.position.x,
            this.position.y - 12,
            this.position.z,
            sX,
            sZ,
            (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.turretDamage) || 10,
            'mg',
            this
          );
          soundManager.playAutocannon();
        }
      }
    }

    // Aerial Cluster Depth Charge Drops
    if (isEngaged && distToPlayer < 85) {
      this.bombTimer -= dt;
      if (this.bombTimer <= 0) {
        this.bombTimer = (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.bombRate) || 3.5;
        this._dropAerialClusterBombs();
      }
    }
  }

  _dropAerialClusterBombs() {
    soundManager.playBombWhistle();
    const offsets = [
      { x: 0, z: 0, delay: 0 },
      { x: (Math.random() - 0.5) * 20, z: (Math.random() - 0.5) * 20, delay: 180 },
      { x: (Math.random() - 0.5) * 24, z: (Math.random() - 0.5) * 24, delay: 360 }
    ];

    offsets.forEach(off => {
      setTimeout(() => {
        if (!this.alive) return;
        const dropX = this.position.x + off.x;
        const dropZ = this.position.z + off.z;
        const bomb = this.weaponManager.spawnProjectile(
          dropX,
          this.position.y - 14,
          dropZ,
          (Math.random() - 0.5) * 0.2,
          (Math.random() - 0.5) * 0.2,
          (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.bombDamage) || 38,
          'depth_charge',
          this
        );
        bomb.fuse = 1.1;
        soundManager.playBombWhistle();
      }, off.delay);
    });
  }

  takeDamage(amount) {
    this.health -= amount;
    if (this.world && this.world.spawnVoxelCrumbles) {
      this.world.spawnVoxelCrumbles(this.position.x, this.position.y - 6, this.position.z, 14, 0xd97706);
    }

    if (this.health <= 0 && this.alive) {
      this.alive = false;
      soundManager.playExplosion(1.5, 2.6);
      if (window.game && window.game.addTrauma) window.game.addTrauma(0.8);

      if (this.player && this.player.triggerStunt) {
        this.player.triggerStunt('🎈 THE IRON VALKYRIE DOWNED! +2200 PTS', (CONFIG.ZEPPELIN && CONFIG.ZEPPELIN.stuntScore) || 2200, 5.0);
      }

      if (this.world && this.world.spawnVoxelCrumbles) {
        this.world.spawnVoxelCrumbles(this.position.x, this.position.y, this.position.z, 60, 0xef4444);
        this.world.spawnVoxelCrumbles(this.position.x, this.position.y, this.position.z, 40, 0xd97706);
        this.world.spawnVoxelCrumbles(this.position.x, this.position.y, this.position.z, 50, 0x1e293b);
      }

      if (this.world) {
        if (this.world.spawnDiamondCache) {
          this.world.spawnDiamondCache(this.position.x - 14, this.position.z);
          this.world.spawnDiamondCache(this.position.x + 14, this.position.z);
        }
        if (this.world._addPickup) {
          this.world._addPickup(this.position.x, this.position.z + 12, 'emp_crate');
        }
      }

      const dispatch = document.getElementById('dispatch-msg');
      if (dispatch) {
        dispatch.innerText = '💥 [AIR DEFENSE WARNING]: THE IRON VALKYRIE HAS EXPLODED! AIRSPACE CLEAR!';
        dispatch.style.color = '#ef4444';
      }

      this.destroy();
    }
  }

  destroy() {
    this.alive = false;
    if (this.waterSpot) {
      this.scene.remove(this.waterSpot);
      this.waterSpot = null;
    }
    if (this.mesh) {
      this.scene.remove(this.mesh);
      this.mesh = null;
    }
  }
}
