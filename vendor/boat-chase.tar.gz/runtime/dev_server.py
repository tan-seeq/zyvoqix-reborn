"""
Boat Chase: Local Development Server & Automation Runner
Runs a local HTTP server with correct MIME types for ES6 modules and WebGL.
"""

import http.server
import socketserver
import webbrowser
import sys
import os

PORT = 8080

class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS and shared array buffer if needed
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        super().end_headers()

def run_server():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        url = f"http://localhost:{PORT}"
        print(f"==================================================")
        print(f"🚤 Boat Chase: Faction Turf Wars Server Running!")
        print(f"👉 Local URL: {url}")
        print(f"Press Ctrl+C to stop the server.")
        print(f"==================================================")
        
        # Open in default browser
        if "--no-browser" not in sys.argv:
            webbrowser.open(url)
            
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")

if __name__ == "__main__":
    run_server()
