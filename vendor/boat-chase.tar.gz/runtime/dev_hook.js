// Boat Chase: Self-Improvement Hook & Real-Time Balancing Dev Tuner
import { CONFIG } from './src/config.js';

export class DevHook {
  constructor(game) {
    this.game = game;
    this.stats = {
      startTime: Date.now(),
      stuntsPerformed: 0,
      killsByFaction: { police: 0, gangster: 0, pirates: 0 },
      damageTaken: 0,
      shotsFired: 0
    };
    this.panelVisible = false;

    this._createDevUI();
    this._bindKeys();
  }

  _bindKeys() {
    window.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === 't' || e.key === 'T' || e.key === '`' || e.key === '~' || e.key === 'F1') {
        e.preventDefault();
        this.toggleDevPanel();
      }
    });

    // Also bind HUD dev button
    const devBtn = document.getElementById('dev-btn');
    if (devBtn) {
      devBtn.addEventListener('click', () => this.toggleDevPanel());
    }
  }

  _createDevUI() {
    const panel = document.createElement('div');
    panel.id = 'dev-tuner-panel';
    panel.style.display = 'none';
    panel.innerHTML = `
      <div class="dev-card">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334; padding-bottom: 8px;">
          <h3 style="margin: 0; color: #00f2fe;">🛠️ Live Dev Tuner & Improvement Hook</h3>
          <button id="close-dev-btn" style="background: none; border: none; color: #888; font-size: 18px; cursor: pointer;">✕</button>
        </div>

        <div style="margin-top: 10px; font-size: 12px; color: #aaa;">
          Press <b>T</b>, <b>\`</b> or click <b>🛠️ Tuner</b> in toolbar to toggle.
        </div>

        <div class="dev-section">
          <h4>🚀 Boat Physics & Speed</h4>
          <label>Max Speed: <span id="val-speed">${CONFIG.PLAYER.MAX_SPEED}</span></label>
          <input type="range" id="tune-speed" min="30" max="110" value="${CONFIG.PLAYER.MAX_SPEED}">

          <label>Acceleration: <span id="val-accel">${CONFIG.PLAYER.ACCELERATION}</span></label>
          <input type="range" id="tune-accel" min="20" max="90" value="${CONFIG.PLAYER.ACCELERATION}">

          <label>Turn Rate: <span id="val-turn">${CONFIG.PLAYER.TURN_SPEED}</span></label>
          <input type="range" id="tune-turn" min="1.0" max="4.5" step="0.1" value="${CONFIG.PLAYER.TURN_SPEED}">

          <label>Drift Slide Factor: <span id="val-drift">${CONFIG.PLAYER.DRIFT_FACTOR}</span></label>
          <input type="range" id="tune-drift" min="0.6" max="0.98" step="0.02" value="${CONFIG.PLAYER.DRIFT_FACTOR}">
        </div>

        <div class="dev-section">
          <h4>🤖 Faction Detection & AI</h4>
          <label>Police Vision Radius: <span id="val-pol-vis">${CONFIG.FACTIONS.POLICE.detectRadius}</span></label>
          <input type="range" id="tune-pol-vis" min="80" max="300" value="${CONFIG.FACTIONS.POLICE.detectRadius}">

          <label>Radio Alert Broadcast Radius: <span id="val-radio">${CONFIG.FACTIONS.POLICE.alertRadioRadius}</span></label>
          <input type="range" id="tune-radio" min="100" max="450" value="${CONFIG.FACTIONS.POLICE.alertRadioRadius}">
        </div>

        <div class="dev-section">
          <h4>✨ Next Iteration Improvement Prompts</h4>
          <div style="background: #0f172a; padding: 10px; border-radius: 6px; font-family: monospace; font-size: 11px; color: #38bdf8; max-height: 120px; overflow-y: auto;">
            <p>1. 🚁 Add Police Helicopter air support with searchlight</p>
            <p>2. ⛈️ Add dynamic thunderstorm weather with lightning</p>
            <p>3. 💥 Add sea-mine laying enemy patrol boats</p>
            <p>4. 🛥️ Add smuggling contraband pickups for cash</p>
          </div>
          <button id="copy-prompt-btn" class="btn btn-secondary" style="margin-top: 8px; width: 100%; font-size: 12px;">📋 Copy AI Improvement Prompt</button>
        </div>

        <div style="display: flex; gap: 8px; margin-top: 15px;">
          <button id="export-config-btn" class="btn btn-primary" style="flex: 1; font-size: 12px;">💾 Export Config JSON</button>
          <button id="respawn-factions-btn" class="btn btn-secondary" style="flex: 1; font-size: 12px;">🔄 Respawn Fleets</button>
        </div>
      </div>
    `;

    document.body.appendChild(panel);
    this._attachListeners();
  }

  _attachListeners() {
    document.getElementById('close-dev-btn').addEventListener('click', () => this.toggleDevPanel());

    const bindSlider = (id, valId, callback) => {
      const slider = document.getElementById(id);
      slider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById(valId).innerText = val;
        callback(val);
      });
    };

    bindSlider('tune-speed', 'val-speed', (v) => { CONFIG.PLAYER.MAX_SPEED = v; });
    bindSlider('tune-accel', 'val-accel', (v) => { CONFIG.PLAYER.ACCELERATION = v; });
    bindSlider('tune-turn', 'val-turn', (v) => { CONFIG.PLAYER.TURN_SPEED = v; });
    bindSlider('tune-drift', 'val-drift', (v) => { CONFIG.PLAYER.DRIFT_FACTOR = v; });
    bindSlider('tune-pol-vis', 'val-pol-vis', (v) => { CONFIG.FACTIONS.POLICE.detectRadius = v; });
    bindSlider('tune-radio', 'val-radio', (v) => {
      CONFIG.FACTIONS.POLICE.alertRadioRadius = v;
      CONFIG.FACTIONS.GANGSTER.alertRadioRadius = v;
    });

    document.getElementById('export-config-btn').addEventListener('click', () => {
      const json = JSON.stringify(CONFIG, null, 2);
      navigator.clipboard.writeText(json);
      alert('Config copied to clipboard!');
    });

    document.getElementById('copy-prompt-btn').addEventListener('click', () => {
      const prompt = `Current Game Feedback:
- Boat handling: Max Speed ${CONFIG.PLAYER.MAX_SPEED}, Turn Rate ${CONFIG.PLAYER.TURN_SPEED}, Drift ${CONFIG.PLAYER.DRIFT_FACTOR}.
- Please implement the next feature: Add police helicopter air-strike support and dynamic night rainstorm with water ripples!`;
      navigator.clipboard.writeText(prompt);
      alert('Improvement prompt copied to clipboard!');
    });

    document.getElementById('respawn-factions-btn').addEventListener('click', () => {
      if (this.game.factionManager) {
        for (const e of this.game.factionManager.enemies) {
          this.game.scene.remove(e.mesh);
        }
        this.game.factionManager.enemies = [];
        this.game.factionManager._spawnFactions();
      }
    });
  }

  toggleDevPanel() {
    this.panelVisible = !this.panelVisible;
    const p = document.getElementById('dev-tuner-panel');
    if (p) p.style.display = this.panelVisible ? 'block' : 'none';
  }
}
