"""
Boat Chase: Autonomous Iteration & Self-Improvement Watchdog Hook
This script runs in the background to monitor codebase health, track feature iterations,
and provide ready-to-execute autonomous development prompts.
"""

import time
import os
import json
import subprocess
import sys
from datetime import datetime

# Ensure safe UTF-8 output on Windows consoles
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(ROOT_DIR, "IMPROVEMENT_LOG.md")
CONFIG_FILE = os.path.join(ROOT_DIR, "src", "config.js")

FEATURE_BACKLOG = [
    {
        "id": "ITER-01",
        "title": "Police Helicopter Air Support",
        "desc": "At 4-5 stars wanted level, spawn a 3D police helicopter with rotating rotor and sweeping searchlight.",
        "status": "READY"
    },
    {
        "id": "ITER-02",
        "title": "Dynamic Weather & Storm Waves",
        "desc": "Periodic tropical squalls with darker waters, rain particle system, and lightning flash lights.",
        "status": "READY"
    },
    {
        "id": "ITER-03",
        "title": "Floating Contraband Cargo Loot",
        "desc": "Golden crates floating in narrow canals that grant instant score, Nitro recharge, or repair kits.",
        "status": "READY"
    },
    {
        "id": "ITER-04",
        "title": "Naval Sea Fort Boss Encounter",
        "desc": "Guarded fortress in the southern straits with rotating twin turrets protecting an escape shortcut.",
        "status": "READY"
    }
]

def verify_codebase():
    """Runs node syntax checks on all source files."""
    files = [
        "src/config.js", "src/audio.js", "src/world.js", "src/boat.js",
        "src/factions.js", "src/weapons.js", "src/radar.js", "src/recorder.js",
        "src/game.js", "dev_hook.js"
    ]
    cmd = ["node", "-c"] + files
    try:
        res = subprocess.run(cmd, cwd=ROOT_DIR, capture_output=True, text=True)
        return res.returncode == 0, res.stderr
    except Exception as e:
        return False, str(e)

def update_log(iteration_count):
    passed, error = verify_codebase()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    entry = f"""
### 🔄 Watchdog Iteration Cycle #{iteration_count} [{now}]
- **Codebase Integrity**: {"✅ All 10 JS Modules Valid" if passed else f"❌ Error: {error}"}
- **Map Zones**: 5 Zones Active (Police Marina, Industrial Docks, Mangrove Canals, Skull Cove, Central Archipelago)
- **Factions**: 3 Active Factions (Coast Guard, Cartel, Pirates) + Inter-faction Turf Wars
- **HUD Telemetry**: Active (Speedometer, Wanted Stars, Radar Minimap, Radio Scanner, Weapon Dock)
- **Video Capture**: 60 FPS Canvas MediaRecorder Ready
- **Next Autonomous Goals**:
"""
    for item in FEATURE_BACKLOG:
        entry += f"  - [{item['status']}] **{item['title']}**: {item['desc']}\n"

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")
    print(f"[{now}] Iteration #{iteration_count} logged. Codebase healthy: {passed}")

def run_loop(max_cycles=3, interval_seconds=5):
    print("==================================================")
    print("🤖 Autonomous Improvement Hook Activated")
    print(f"Tracking codebase at: {ROOT_DIR}")
    print("==================================================")
    
    # Initialize header in log file if needed
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write("# 🚤 Boat Chase: Autonomous Development & Improvement Log\n\n")

    for cycle in range(1, max_cycles + 1):
        update_log(cycle)
        if cycle < max_cycles:
            time.sleep(interval_seconds)

    print("\n✅ Autonomous watchdog cycle completed successfully.")

if __name__ == "__main__":
    run_loop()
