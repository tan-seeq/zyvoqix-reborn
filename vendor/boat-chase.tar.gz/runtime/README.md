<p align="center">
  <img src="docs/banner.png" alt="Boat Chase: Faction Turf Wars banner" width="100%">
</p>

<p align="center">
  <a href="https://hammadshakeelai.github.io/Boat-Chase/"><b>▶ Play in your browser</b></a> ·
  <a href="#controls">Controls</a> ·
  <a href="#run-it-locally">Run locally</a> ·
  <a href="https://github.com/hammadshakeelai/Tidebreaker">Successor: Tidebreaker →</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Three.js-r160-000000?style=flat-square&logo=three.js" alt="Three.js">
  <img src="https://img.shields.io/badge/WebGL-ES%20modules-00f2fe?style=flat-square" alt="WebGL">
  <img src="https://img.shields.io/badge/build-none-f39c12?style=flat-square" alt="No build step">
  <img src="https://img.shields.io/badge/deploy-GitHub%20Pages-2ecc71?style=flat-square&logo=github" alt="GitHub Pages">
</p>

# Boat Chase: Faction Turf Wars

A 3D boat chase game that runs in a browser tab. You're a smuggler running through island canals, container docks and pirate coves. Three factions patrol the water, and they only come after you once they've spotted you. Drag one faction into another's territory and they start shooting at each other instead of you.

This is the **original build (v1)**. It grew over 14 feature cycles (see [`IMPROVEMENT_LOG.md`](IMPROVEMENT_LOG.md)) and is kept here as-is. The rebuilt, faster and better-looking successor is **[Tidebreaker](https://github.com/hammadshakeelai/Tidebreaker)**.

| Chase cam | Golden sunset |
| :---: | :---: |
| ![Chase camera with HUD](docs/screenshots/chase-hud.png) | ![Golden sunset lighting](docs/screenshots/golden-sunset.png) |
| **Cyber night** | **Top-down tactical view** |
| ![Cyber night lighting](docs/screenshots/cyber-night.png) | ![Top-down camera](docs/screenshots/top-down.png) |

## Features

**Three hostile factions**
- 🚓 **Coast Guard**: fast cutters with searchlights and sirens. When one spots you, it radios every patrol boat in range.
- 🏎️ **Cartel**: catamarans with twin SMGs working the cargo docks. They try to ram you.
- 🏴‍☠️ **Skull Cove pirates**: slow, armoured gunboats with cannons. They attack the Coast Guard and the Cartel as well as you.

**Stealth and radio alerts**
- Every enemy boat has a vision cone and can hear gunfire. Stay out of sight and nobody chases you.
- A boat that spots you calls only its own faction. Get two factions into the same fight and they turn on each other.

**Handling and stunts**
- Arcade physics with wave bobbing, roll into turns, and stern drift slides.
- Wooden ramps and sandbars for jumps, a slow-motion camera while you're airborne, and combo scoring.
- Nitro boost, plus a harpoon you can use to slingshot around anchors.

**Arsenal**
- Twin machine guns, homing torpedoes, rear depth charges, and explosive barrels that set each other off.

**Extras**
- Day, golden-sunset and cyber-night lighting.
- Procedural synth radio stations.
- A 60 FPS in-browser clip recorder (`MediaRecorder`).
- A live dev tuner (`T`) for changing speed, drift and AI detection while you play.

## Controls

| Action | Key |
| :--- | :--- |
| Throttle / reverse | `W` / `S` or `↑` / `↓` |
| Steer | `A` / `D` or `←` / `→` |
| Nitro boost | `Space` |
| Drift slide | `Shift` |
| Harpoon slingshot | `F` (hold) |
| Machine guns | Left click |
| Homing torpedo | Right click or `E` |
| Depth charge | `Q` |
| Camera (chase / top-down) | `C` or `Tab` |
| Lighting preset | `N` |
| Radio station | `R` |
| Dev tuner | `T` or `` ` `` |

## Run it locally

There's no build step. Serve the folder with any static server:

```bash
python dev_server.py
```

or

```bash
python -m http.server 8080
```

Then open <http://localhost:8080>.

## Project layout

```
index.html        HUD markup + entry point
style.css         HUD / menu styling
lib/three.module.js
src/
  game.js         main loop, camera, input, HUD updates
  world.js        islands, docks, canals, ramps, pickups
  boat.js         player boat physics & effects
  factions.js     enemy AI, detection, radio network, turf wars
  weapons.js      guns, torpedoes, mines, explosions
  radar.js        minimap
  audio.js        procedural Web Audio SFX + synth radio
  recorder.js     canvas video capture
dev_hook.js       live tuning panel
```

## Known limitations (v1)

- Every sound is synthesised at runtime, so the audio is thin compared with recorded samples.
- The world is one huge hand-placed scene (`world.js` is about 180 KB), so it's heavy on low-end GPUs.
- Tidebreaker rebuilds the game from scratch to fix both of these.

## License

MIT. Three.js is © three.js authors (MIT).
