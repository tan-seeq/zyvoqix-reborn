# 🚤 Boat Chase: Autonomous Development & Improvement Log

## 🌟 Live Dual-AI Collaboration Session (Claude & ChatGPT)

### 🤖 ChatGPT Recommendations (Gathered via Chrome Subagent)
1. **Wake-Surf Slingshot**: Large boats and cutters create churning wakes that launch pursuers and grant speed boosts when crossed cleanly.
2. **Faction Crossfire & Betrayal**: Lure police convoys into cartel dock turf or pirate minefields to ignite three-way faction wars.
3. **Moving-World Stunt Routes**: Closing drawbridges, lowered cargo freighter ramps, and swinging shipping container cranes.

### 🧠 Claude (Opus) Recommendations (Gathered via Chrome Subagent)
1. **Wake Ramps + Drafting**: Store boat positions as a wake spline. Sitting in the wake grants drafting boost; cutting across perpendicularly launches the boat into the air.
2. **Harpoon Slingshot**: Single-line cable to grapple buoys/piers for 180° hairpin drifts around tight canal bends.
3. **The Heat Triangle (Cargo as the Aggro Token)**: Factions prioritize targets dynamically:
   - Pirates relentlessly hunt whoever carries the contraband crate.
   - Police chase whoever discharged weapons most recently.
   - Cartel aggressively defend their dock territory.

---

## 🛠️ Implemented Iterations (Live in Game)

### Cycle #1: Daytime Tropical Environment & GTA Aesthetics
- [x] Switched from night twilight to bright midday tropical sun with caustic wave glints and foam crests.
- [x] Added atmospheric sky dome with fluffy procedural cloud puffs.
- [x] Added arched highway bridges spanning channels for boats to speed underneath.
- [x] Enhanced island geometry with sandy beaches, palm trees with bent trunks, and concrete seawalls.

### Cycle #2: Authentic GTA 3rd-Person Chase Cam
- [x] Set default camera to GTA 3rd-person follow cam positioned behind the boat stern.
- [x] Dynamic speed FOV: Expands from $62^\circ$ to $74^\circ$ under Nitro boost for Hollywood tunnel-vision sensation.
- [x] Slow-Motion Movie Stunt Camera: When launching off wooden ramps or wake crests, time dilates ($0.45\times$) for epic aerial rotations, then snaps back upon landing with massive splash effects!

### Cycle #3: Survivable Hollywood Chase (No Cheap Deaths)
- [x] Player Hull Integrity increased from `100` to `180` HP.
- [x] Obstacle collision damage slashed by 75% (`0.08` factor) for forgiving scrapes and bounces.
- [x] Auto-Hull Nanite Regeneration: Slowly repairs up to 55% health after 4 seconds out of enemy fire.
- [x] Realistic Enemy Bullet Spread: Pursuers fire with slight angle variance so bullets splash dramatically in the water around the player instead of laser-beaming.

### Cycle #4: Air Support & Canal Loot Pickups
- [x] **Police Helicopter Air Support**: At Wanted Level 3+, a 3D Police Helicopter flies in, shines a downward searchlight cone on the water, and fires tracer bursts.
- [x] **Floating Contraband Crates**: Golden crates in winding channels grant $+350$ Score and instant Full Nitro Recharge.
- [x] **Hull Repair Kits**: Green medical crosses restore $+40$ Hull Integrity.
- [x] **Dev Tuner Controls**: Changed from `F1` to **`T`** / **``` ` ```** and added a direct on-screen **`🛠️ Tuner [T]`** button.

### Cycle #5: The NitroCity Arcade Overhaul (Tire Model Drift, Deflection, Stunt Combos & Synth Radio)
- [x] **Frame-Rate Normalization ($k$ Factor)**: Normalised physics against a 60 FPS baseline using $k = \min(\max(dt \times 60, 0.2), 2.0)$ and exponential decays with $\text{Math.pow}(\text{rate}, k)$ across steering, friction, and camera smoothing.
- [x] **Fake-Grip Arcade Steering (Car Tire Model on Water)**:
  - Decomposed velocity into forward ($v_F$) and lateral ($v_R$) vectors.
  - Exponential lateral grip damping ($\text{grip}^{k}$) with smooth power-drift slide on `SHIFT`.
  - Clean drift exit gives an immediate $+5.5$ knot kick of speed!
  - Rudder authority scales with forward speed ($\sin(\text{ratio} \times \pi / 2)$) with smooth attack/release steering inputs so the boat steers effortlessly without fidget spinning.
  - Sprung visual hull lean into turns and acceleration pitch for authentic speedboat weight.
- [x] **Tangential Deflection Collisions**:
  - Replaced rigid backwards rebound with tangential deflection and positional push-out.
  - Glancing scrapes preserve 85–95% forward momentum using power-curve speed scrub ($\text{scrub} = 1 - 0.55 \times \text{hitAngle}^{1.5}$).
  - Full rebound is reserved strictly for direct head-on crashes ($\text{hitAngle} > 0.85$).
  - Glancing impacts smoothly slide the boat's heading along the contact tangent.
- [x] **NitroCity Stunt Combo Multiplier Engine**:
  - Pressure window (3.2s timer) to chain stunts into escalating multipliers ($1.0\times \to 5.0\times$).
  - Stunts tracked: `BIG AIR`, `360 BARREL ROLL`, `MEGA POWERSLIDE`, `SMASH: CARGO CRATE`, `POWER DRIFT BOOST`.
  - Spring-overshoot animated HUD popups with dynamic scale and glow.
- [x] **Destructible Voxel Debris**:
  - Implemented `VoxelDebrisManager` with instanced 3D physics cubes that burst outward on crate, barrel, or buoy impact with ballistic arcs, spin, and water splashes.
- [x] **Live Procedural Web Audio Synthesizer Radio**:
  - Ported NitroCity's `ArcadeBGMSequencer` directly into `src/audio.js` with 3 live radio stations:
    1. *Neon Drive 104.2 FM* (126 BPM Synthwave)
    2. *Cyber Rush 168.0 FM* (168 BPM Drum & Bass Chase)
    3. *Midnight Drift 88.5 FM* (88 BPM Lo-Fi Electro Funk)
  - Audio clock lookahead scheduling (200ms) prevents stuttering under CPU load.
  - Impact ducking temporarily lowers radio volume during explosions and crashes.
  - Cycle stations via **`R`** key or the HUD `📻 Radio` button with an animated radio banner.
- [x] **Instant-Response Throttle & Airborne Rev Flare**:
  - Simulated engine RPM responds in 1 frame to throttle attack.
  - Propeller unloads when airborne for a roaring rev-flare sound effect!
- [x] **Camera Juice**:
  - Organic trauma screen shake ($s = \text{trauma}^2$) using smooth trigonometric noise.
  - Speed-curve dynamic FOV ($62^\circ \to 82^\circ$).
  - Camera acceleration lag and drift-swing anticipation.

### Cycle #6: Moving Cargo Freighter Ramps & Hydraulic Wake Slingshots
- [x] **Container Freighter Stunt Ramps**:
  - Upgraded docked cargo freighter with stacked multi-colored shipping containers (red, cyan, yellow, green) and a lowered industrial stern ramp extending directly out of the water.
  - Hitting the freighter stern ramp launches the boat across the container deck with an exclusive `CONTAINER FREIGHTER FLIGHT!` $+950$ PTS stunt badge.
- [x] **Moving Mega-Freighter Patrol**:
  - Implemented an independent 165m container ship `movingFreighter` cruising along outer channel waypoints at 14 knots.
  - Dynamically updates its physical colliders, bridge, and stern ramp in real-time each frame so players can jump onto and over a live moving vessel!
- [x] **Hydraulic Wake-Surfing Slingshots & Slipstream Drafting**:
  - Cutting perpendicularly across the turbulent stern wake of any enemy cutter, catamaran, or pirate barge at $> 26$ knots launches your boat into the air (`WAKE SURF SLINGSHOT! +600 PTS`).
  - Tucking directly into the slipstream corridor behind an enemy vessel yields an immediate $+20\%$ acceleration boost!

---

### 🔄 Cycle 7: Harpoon Slingshot Drift Cable & Police Canal Roadblocks
- **Harpoon Slingshot Drift Cable (`KeyF` / HUD button)**:
  - Added smart anchor acquisition detecting buoys, mooring dolphins, bridge pillars, and roadblock posts within 78 units.
  - Visualized with pulsating cyan target reticle and dynamic high-voltage cable mesh (`THREE.Line`).
  - Centripetal cable tension pulls boat into orbital hairpin drift arcs with deep visual hull lean.
  - Releasing `KeyF` triggers **Harpoon Apex Slingshot** with $+8.5$ knot forward speed kick, whoosh audio, and $+550$ stunt points.
- **Police Canal Roadblock Barriers**:
  - 5 floating boom barriers across canal thoroughfares featuring heavy timber beams, hazard chevrons, steel warning spikes, and alternating red/blue police strobe beacons.
  - High-speed ramming shatters barrier into 36+ voxel crumbles, awarding `"💥 ROADBLOCK SMASH: RAMMING SPEED!"` (+700 PTS) or `"ROADBLOCK BUSTED!"` (+500 PTS).
- **8 Canal Mooring Dolphins**:
  - High-visibility mooring piles with glowing neon rings placed at tight channel chicanes for hairpin grapple slingshots.
- **Procedural SFX**:
  - Synthesized `playHarpoonLaunch()`, `playHarpoonSlingshot()`, and `playRoadblockSmash()`.
- **Verification**:
  - Headless Playwright test (`test_cycle7.py`) passed with `ALL TESTS PASSED WITH ZERO ERRORS!`.

---

### 🔄 Cycle 8: Police Helicopter Air-1 Support & Tropical Squall Storm Engine
- **Air-1 Police Helicopter Pursuit (`src/factions.js`)**:
  - Automatically scrambled when wanted level reaches 3+ stars.
  - Features dual spinning rotors (main rotor + tail rotor), twin alternating strobes (red tail, blue belly), and a dynamic circular searchlight spot tracking the water surface.
  - Procedural helicopter audio engine in `src/audio.js` synthesizing 18 Hz blade chop beats with distance attenuation.
  - Radio dispatch: `"🚁 AIR-1 DISPATCH: SUSPECT VESSEL SIGHTED IN CHANNEL! COMMENCING SEARCHLIGHT PURSUIT!"`
  - Explosive crash sequence on defeat: 45 red/blue/black voxel crumbles, screen trauma spike, and `"🚁 AIR-1 DOWNED!"` (+1200 PTS) with 30-second respawn cooldown.
- **Dynamic Tropical Squall System (`src/world.js`)**:
  - Cyclical 28-second tropical storm squall with darker atmospheric mood.
  - 450 instanced falling rain streak particles centered dynamically around player camera.
  - Procedural lightning flash illuminations with deep sub-bass thunder rumble (`playThunder()`).
  - Ocean wave amplitude scales up to 2.15x for heavy storm swells.
  - Hitting crests at high speed triggers `"🌊 SQUALL SWELL LAUNCH!"` (+400 PTS).
- **Wanted Level Heat Persistence**:
  - Fixed rapid 1-frame wanted level reset bug; implemented an 18-second evasion cooldown so multi-star pursuit heat stays active realistically.
- **Verification**:
  - Headless Playwright test (`test_cycle8.py`) passed with `CYCLE 8 TESTS PASSED WITH ZERO ERRORS!`. Screenshot saved: `squall_helicopter_gameplay.png`.

---

### 🔄 Cycle 9: Port Authority Heavy Coastal Cutter & Naval Sea Fort Citadel Defense
- **Port Authority Heavy Interceptor Cutter (`HeavyInterceptorCutter` in `src/factions.js`)**:
  - Twin-pontoon heavy catamaran armored hull (length: 17, width: 9.2, radius: 6.8, health: 220 HP).
  - Features high command bridge, ballistic tinted glass, dual alternating police siren strobes, forward twin heavy autocannons, spinning radar mast, and stern depth charge deployment rack.
  - Custom AI: Employs wide-arc autocannon salvos and stern depth-charge deployment (`⚠️ [RADIO SCANNER]: Heavy Cutter deploying stern depth charges!`) when the player attempts to tail closely.
  - Spawns at 2 strategic maritime choke points (Police Marina outer breakwater and Grand Canal approach) and scrambles dynamic reinforcements at Wanted Level 4+.
  - On defeat: Shatters into 64 multi-colored voxel crumbles (`0x0284c7`, `0x38bdf8`, `0xf59e0b`), triggers screen trauma, drops a guaranteed Golden Contraband crate pickup, and awards `"💥 HEAVY CUTTER NEUTRALIZED! +850 PTS"`.
- **Naval Sea Fort Citadel & Active Coastal Defense Turrets (`src/world.js`)**:
  - Re-engineered the naval fort zone into twin stone bastions (West Bastion & East Bastion) with an open 42-unit wide deep-water canal corridor running north-south through the island.
  - Twin Coastal Defense Artillery Turrets mounted on elevated bastions that track incoming hostile vessels (range: 300m) and fire heavy explosive cannon shells with muzzle flash, smoke, and deep artillery audio (`soundManager.playCannon()`).
- **Breachable Heavy Fortress Sea Gate**:
  - Guarding the secret citadel canal entrance with a 32-unit reinforced steel portcullis, yellow caution hazard chevron plates, and alternating red/amber maritime strobe beacons.
  - 160 HP structural health: Can be breached via direct Torpedo impacts, high-speed Boost ramming ($>26$ knots), or heavy weapons fire.
  - On breach: Explodes into 116 voxel debris pieces (`0x475569`, `0xf59e0b`, `0xef4444`, `0xffffff`), clears canal collision geometry, triggers screen trauma, awards `"🏰 FORTRESS GATE BREACHED! +900 PTS"`, and unlocks a secret canal corridor packed with Contraband loot, Repair kits, and a northern sea exit launch ramp!
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - Added dedicated diamond icons for Heavy Interceptor Cutters (`#38bdf8` with alert border).
  - Added rectangular red/amber gate obstacle markers for the Fortress Sea Gate.
  - Added dynamic helicopter `🚁` radar icons tracking Air-1 in real-time.
- **Verification**:
  - Headless Playwright test suite (`test_cycle9.py`) executed cleanly with 0 console errors.
  - Verified 2 active heavy cutters, fort artillery turrets, sea gate destruction, and guaranteed contraband drop.
  - Screenshot captured: `cutter_fortress_gameplay.png`.

---

### 🔄 Cycle 10: Dynamic Bascule Drawbridge & Coast Guard Spike Strip Drag Nets
- **Dynamic Bascule Harbor Drawbridge (`src/world.js`)**:
  - 140m articulated twin-leaf bascule bridge spanning across the central industrial canal at `(x: 180, z: 220)`.
  - Built with twin concrete abutment piers, steel truss guardrails, hazard chevrons, amber construction warning strobes, and synchronized maritime navigation beacons.
  - Dynamic 32-second mechanical lift cycle:
    - 12s closed (flat crossing)
    - 4s opening (leaves tilt up $0^\circ \to 37^\circ$)
    - 12s open (spans stand tall with warning beacons flashing)
    - 4s closing
  - When tilted ($>0.22$ rad), both leaves dynamically activate as stunt ramps!
  - Hitting the elevated leaves at speed launches the boat across the open canal chasm for the high-multiplier stunt:
    `"🌉 DRAWBRIDGE CHASM JUMP! +850 PTS"`.
- **Coast Guard Floating Spike Strip Drag Nets (`src/world.js`, `src/boat.js`)**:
  - Deployed across 2 key canal chokepoints (Police Marina egress channel and Skull Cove straits).
  - Composed of 7 buoyant yellow/black hazard buoys linked by heavy steel cables, underwater shark-tooth spikes, and pulsing amber beacons.
  - Hitting the net with Nitro Boost ($v_F > 26$) or torpedoes severs the cables into 42 voxel fragments with explosive audio, awarding `"⚡ SPIKE NET SEVERED! +450 PTS"`.
  - Hitting the net without boost fouls the boat's propeller (`propellerFouledTimer = 3.8s`), cutting top speed in half with churn audio and Coast Guard radio chatter.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - Added real-time bascule drawbridge state icon (green when open, grey when closed, amber during transition).
  - Added amber barrier line markers indicating live spike strip drag nets.
- **Verification**:
  - Headless Playwright test suite (`test_cycle10.py`) passed cleanly with 0 console errors.
  - Verified drawbridge timer articulation, dynamic ramp activation, spike net severing with boost, and propeller fouling penalty.
  - Screenshot captured: `drawbridge_spikenet_gameplay.png`.

---

## 📋 Overnight Feature Backlog
- [x] **Harpoon Drift Cable**: Press `F` to shoot a grapple cable at canal buoys for high-speed hairpin turns. *(Completed in Cycle 7)*
- [x] **Police Canal Roadblocks**: Destructible floating boom barriers at checkpoints. *(Completed in Cycle 7)*
- [x] **Police Helicopter Air Support**: Air-1 gunship with searchlight, strobes, and audio. *(Completed in Cycle 8)*
- [x] **Dynamic Tropical Squall**: Rain particles, lightning flashes, thunder, and heavy swells. *(Completed in Cycle 8)*
- [x] **Police Coastal Interceptor Cutter**: Heavy catamaran pursuit cutter with siren convoys. *(Completed in Cycle 9)*
- [x] **Cargo Sea Fort Boss Shortcut**: Secret canal gate guarded by heavy sea fort guns. *(Completed in Cycle 9)*
- [x] **Dynamic Harbor Drawbridge**: Timed opening/closing drawbridge with ramp jump angle. *(Completed in Cycle 10)*
- [x] **Coast Guard Spike Strip Nets**: Floating barrier nets that foul player propeller unless cut with torpedoes or nitro jumped. *(Completed in Cycle 10)*
- [x] **Day / Sunset / Cyber-Night Atmosphere Cycle**: Golden hour twilight and cyberpunk midnight with neon boat underglow. *(Completed in Cycle 11)*
- [x] **Cartel Armored Convoy & Crown Diamond Heist**: Armored flagship with 2 wingman escorts, dropping 10s Nanite Shield. *(Completed in Cycle 11)*

---

### 🔄 Cycle 11: Dynamic Day / Sunset / Cyber-Night Lighting Cycle, Neon Underglow & Cartel Armored Diamond Convoy
- **Dynamic Lighting Atmosphere Cycle (`src/config.js`, `src/world.js`, `src/game.js`)**:
  - Implemented 3 distinctive cinematic atmosphere lighting presets:
    1. **Midday Tropical (`DAY`)**: Crisp cyan sky (`0x48b4e0`), sunny tropical azure sea (`0x0ea5e9`), clear sea mist fog, and bright midday sunlight.
    2. **Golden Hour Miami Vice (`SUNSET`)**: Fiery orange/magenta twilight sky (`0xf97316`), deep bronze ocean waters (`0xc2410c`), golden specular wave glints, and low-grazing grazing sunlight (`y: 70`) casting dramatic long shadows.
    3. **Outrun Cyber-Night (`CYBER_NIGHT`)**: Midnight navy/black sky (`0x030712`), dark reflective ocean (`0x082f49`), neon electric cyan wave highlights, and silver moonlight.
  - Seamless atmosphere cycling via **`KeyN`** or the HUD **`🌆 Light: Sunset [N]`** toolbar button.
  - Updates background, fog, hemispheric sky/ground fill, directional sun/moon light, sky dome, water shader roughness/metalness, and seabed floor dynamically in 1 frame.
- **Dynamic Neon Boat Underglow Projector (`src/boat.js`)**:
  - Projected underglow radial canvas texture on sea surface with dedicated point light illuminating water ripples and wake foam.
  - Underglow pulses with boat speed (electric cyan `0x00f2fe` default).
  - Intensifies into blazing hot pink/rose `0xf43f5e` at $3.6\times$ intensity under Nitro Boost with organic jitter.
  - Switches to electric purple `0xa855f7` during drift maneuvers.
- **Cartel Armored Convoy with Crown Diamond Escort (`src/factions.js`)**:
  - **Convoy Flagship (`CartelConvoyLeader`)**: 240 HP armored black composite gunboat (`0x18181b`) with metallic gold racing trim (`0xf59e0b`), dual forward assault SMGs, and a large rotating **Crown Diamond Gemstone** (`new THREE.OctahedronGeometry(1.6)`) mounted on the aft deck with amber hazard beacons.
  - **2 Wingman Escorts (`CartelConvoyEscort`)**: Agile cartel catamarans flying in synchronized formation on the leader's left and right flanks.
  - Patrols the Eastern Trade Channel between Industrial Docks and Central Archipelago along waypoint courses.
  - When attacked, the flagship commands all escorts to instantly alert and engage the aggressor.
  - On defeat: Massive voxel debris explosion (black, gold, cyan), screenshake trauma, and spawns the guaranteed **Crown Diamond Smuggle Cache Pickup** at its sinking location (`"👑 CONVOY HEIST COMPLETE! +1500 PTS"`).
- **Crown Diamond Smuggle Cache Pickup & 10-Second Nanite Shield (`src/world.js`, `src/boat.js`)**:
  - Floating armored cache with rotating 3D gemstone, dual orbiting halo rings (`0x38bdf8`, `0xfde047`), and dynamic point light illuminating the water.
  - Scooping the Diamond Cache awards $+1500$ points, maxes the stunt combo multiplier to $5.0\times$, fully charges Nitro Boost, and activates a **10-Second Nanite Energy Shield**.
  - **Nanite Energy Shield Forcefield**: Translucent glowing icosahedron wireframe shell + energetic inner shield rotating around player's boat.
  - **100% Invulnerability**: Deflects all incoming damage from bullets, torpedoes, cannon fire, depth charges, collision impacts, and spike nets. Flashes brilliant white/cyan on hit.
  - HUD hull telemetry displays `🛡️ SHIELD: 8.7s` with glowing cyan pulse.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - Prominent golden crown blip (`👑`) tracking the Cartel Convoy Flagship.
  - Gemstone icon (`💎`) tracking floating Crown Diamond Caches.
- **Verification**:
  - Headless Playwright test suite (`test_cycle11.py`) passed cleanly with 0 console errors.
  - Verified atmosphere transitions, underglow state, convoy formation, diamond cache pickup, nanite shield invulnerability, and captured screenshot `sunset_convoy_gameplay.png`.

---

## 📅 Cycle 12 Completed: Skull Cove Pirate Ironclad Galleon Boss & Horned Naval Minefield Slalom
- **Blackbeard's Armored Ironclad Galleon (`src/factions.js`)**:
  - **Boss Warship Hull**: 280 HP armored war galleon (`0x271306` ebony timber) wrapped in heavy iron armor belts (`0x3f3f46`, metalness 0.88), reinforced iron battering ram prow, elevated forecastle, and 2-tiered fortress sterncastle with glowing amber gallery windows (`0xf59e0b`).
  - **Masts & Jolly Roger Flag**: 12m foremast and 15m mainmast with rigging yards, spars, and a ragged black pirate flag with skull & crossbones waving gently in the ocean wind.
  - **Triple Broadside Cannon Batteries**: 6 heavy broadside cannons (3 Port, 3 Starboard) with flared muzzles. When enemy vessels or the player enter the broadside firing arc ($|rightDot| > 0.4$, within 170m), the Galleon unleashes a thunderous **Triple Cannonball Broadside Salvo** staggered across gun decks with deep booming audio, black smoke trails, and geyser splashes!
  - **Aft Rolling Pitch Barrel Mines**: When chased from behind ($forwardDot < -0.6$, distance $< 55m$), the Galleon drops floating explosive pitch depth charges into the wake to punish tailgaters!
  - **Boss Defeat Sequence**: Catastrophic structural detonation splitting into 100+ voxel fragments (dark wood, iron plates, fire), $+0.85$ trauma shake, $+1800$ stunt points with instant $5.0\times$ combo max, and drops **3 floating Treasure Chest / Diamond Pickups** around the sinking wreckage (`"☠️ BLACKBEARD'S IRONCLAD SUNK! +1800 PTS"`).
- **WWII-Style Buoyant Horned Naval Minefield System (`src/world.js`, `src/boat.js`, `src/weapons.js`, `src/factions.js`)**:
  - **Physical Contact Mine Casings**: Spherical iron mine bodies with welded equator flanges, 6 protruding chemical detonator horns, submerged mooring anchor chains, and flashing red proximity warning LEDs.
  - **Slalom Courses**: Positioned in strategic minefields across the Skull Cove pirate entrance and Mangrove Canal chokepoints.
  - **Cascading Chain Reactions**: Mine detonations blast 64+ voxel debris pieces, deal 95–120 area damage within 28m, and trigger cascading chain reactions to adjacent mines within 26m with staggered 110ms delays!
  - **Tactical Interactivity**: Player weapons (machine gun bullets, torpedoes, depth charges) hit-test against mines to clear lanes from afar or detonate them as pursuers pass by. Enemy boats navigating through the minefield can strike mines, triggering `"MINEFIELD TRAP! +600 PTS"`.
  - **Nanite Shield Integration**: Player's Nanite Energy Shield absorbs 100% of mine blast damage with high-tech cyan deflection flashes.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `☠️` Pirate skull blip with pulsing amber/crimson ring tracking Blackbeard's Galleon.
  - Red spiked crosshair blips tracking all active horned contact mines.
- **Verification**:
  - Automated test suite `test_cycle12.py` verified Galleon instantiation, broadside salvos, stern pitch drops, minefield placement, chain reaction cascades, and 0 console errors.
  - Captured gameplay artifact `ironclad_minefield_gameplay.png`.

---

## 📅 Cycle 13 Completed: Offshore Oil Rig Refinery Platform & Stunt Crane Jump Network
- **Offshore Deepwater Oil Rig Architecture (`src/world.js`, `src/config.js`)**:
  - **Location & Jacket Legs**: Anchored at `(350, -850)` in deep ocean waters with 4 massive steel lattice jacket pile legs (`0xd97706`, radius 3.8m, height 36m) cross-braced with diagonal steel tubular trusses (`0x78716c`).
  - **Industrial Grated Platform Deck**: 58m x 46m steel deck (`0x334155`, metalness 0.85) at height `y: 14m` with yellow hazard safety perimeter railings.
  - **Cantilever Helipad**: Hexagonal 28m green helipad cantilevered off the southwest corner with painted yellow `'H'` landing ring (`0xfde047`) and green perimeter LED beacons.
  - **Drilling Derrick & Flare Boom**: 36m tapered structural drilling mast rising to `y: 50m` with red pulsing aviation warning beacon (`0xef4444`, 45m range) and a 28m angled flare boom venting a dynamic flickering natural gas flare flame with orange point lighting.
  - **Gantry Dock Crane & Dangling Container**: Industrial deck crane suspending a blue 20ft shipping container dangling 6m above the water on steel cables.
- **Pressurized Chemical Fuel Storage Tanks & Chain Combustion**:
  - 4 high-capacity cylindrical fuel tanks (120 HP each) with white composite bodies, bold red hazard bands (`0xef4444`), and top pressure relief caps.
  - Projectile hit-testing (`src/weapons.js`) allows players and enemies to shoot tanks from long range.
  - On tank destruction: 136+ multi-stage voxel debris particles (white metal, hazard red, bright yellow, fiery orange), $+0.85$ screen trauma shake, 42m blast radius dealing 130 area damage, and a cascading chain reaction detonating adjacent tanks within 26m!
  - Awards stunt: `"💥 REFINERY TANK ANNIHILATED! +750 PTS"`.
  - Radio dispatch: `'🚨 [HAZMAT DISPATCH]: 10-99! REFINERY TANK DETONATED! MASSIVE INFERNO AT OIL RIG!'`.
- **Catwalk Aerial Stunt Launch Ramps (`src/boat.js`, `src/world.js`)**:
  - 2 high-speed angled launch ramps on the South and East water approaches aligned with the rig's leg corridors.
  - Hitting the ramp at speed launches the boat flying between the jacket legs and underneath the crane:
    `"✈️ OIL RIG CATWALK FLIGHT! +1100 PTS"` with instant $5.0\times$ combo max!
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - Industrial refinery icon `⛽` with golden circular border and red chemical fuel tank dots.
- **Verification**:
  - Playwright test suite `test_cycle13.py` passed with 0 console errors.
  - Verified fuel tank detonation, chain reaction explosion, weapon hit detection, and captured `oil_rig_gameplay.png`.

---

## 📅 Cycle 14 Completed: Secret Submarine Pen Cavern Dock & Experimental Railgun Torpedo
- **Submarine Pen Cavern Architecture (`src/world.js`, `src/config.js`)**:
  - **Location & Mountain Bastions**: Carved into the northwest shoreline sea cliff at `(-920, 120)` with 42m tall dark slate rock bluffs (`0x334155`), reinforced concrete bunker roof (`y: 26m`), and heavy portal lintel with yellow/black hazard chevrons (`0xf59e0b`).
  - **Flooded Drydock Slipway**: 44m x 90m water slipway flanked by dual steel service catwalks (`0x1e293b`), safety railings, and an overhead heavy industrial gantry crane with hoist carriage and cable hook.
  - **Atmospheric Lighting & Bioluminescence**: Interior sodium cavern floodlights (`0xf59e0b`, 55m range), cyan portal warning beacons (`0x00f2fe`), and an eerie submerged emerald green reactor coolant glow (`0x10b981`, 38m range) illuminating the cavern seabed.
  - **Infiltration Event**: Piloting within 44m triggers `soundManager.playSonarPing()`, police alert dispatch (`'⚓ [CODE RED DISPATCH]: Intrusion at Submarine Pen Zulu! Prototype Railgun armed!'`), and stunt reward:
    `"⚓ SECRET SUB PEN INFILTRATION! +950 PTS"`.
- **76-Meter Typhoon-Class Stealth Nuclear Submarine**:
  - Anchored in the drydock berth with anechoic matte black rubber tiles (`0x0f172a`), streamlined teardrop bow with bulbous sonar dome (`0x1e293b`), and red boot-topping keel stripe (`0x991b1b`).
  - Massive conning tower sail with forward hydroplane diving fins, periscope masts, radar array, and snorkel intake shafts.
  - 16 flush ICBM missile silo hatch doors (2 rows of 8) along the spine.
  - Cruciform stern rudders and active 7-bladed bronze propulsion screw propeller (`0xd97706`) with continuous idle rotational animation.
- **Prototype Hyper-Velocity Railgun Torpedo Weapon (`src/weapons.js`, `src/boat.js`, `src/audio.js`, `src/config.js`)**:
  - **Pickup Crate**: High-tech black ordnance crate with cyan neon energy coils and dynamic energy field halo spawned inside the drydock berth (`cx, cz + 28`).
  - **Ammo & HUD Integration**: Collecting awards $+5$ rounds of Railgun Torpedoes. Secondary weapon card dynamically transforms to `⚡ RAILGUN` with remaining ammo count and glowing cyan neon border.
  - **Supersonic Sabot Ballistics**: Fires at `speed: 340` units/s (3.2x faster than torpedoes) with supersonic recoil impulse ($-6.5$ speed) and $+0.45$ camera trauma screen shake.
  - **Multi-Target Linear Penetration**: Pierces up to 4 consecutive targets (enemies, breachable sea gate, naval mines, oil rig fuel tanks, rock barriers), dealing 160 kinetic damage per target with cyan particle shockwaves.
  - **Multi-Kill Combos**: Piercing multiple enemies in a single shot triggers:
    `"⚡ RAILGUN PENETRATOR MULTI-KILL (2X/3X)! +1600/+2400 PTS"`.
  - **Terminal Plasma Detonation**: On final penetration or expiration, detonates in a 28m cyan plasma fireball with AOE shockwave damage.
  - **Synthesized Electromagnetic Audio**: `soundManager.playRailgunFire()` combines a 2.6kHz supersonic electromagnetic zap descending to 120Hz with a sub-bass 75Hz kinetic cavitation punch.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `⚓` Submarine Pen bunker icon with cyan circular perimeter ring.
  - `⚡` Prototype Railgun weapon crate blip.
- **Verification**:
  - Automated Playwright test suite `test_cycle14.py` verified sub pen instantiation, submarine meshes, infiltration dispatch, pickup collection, weapon dock HUD transition, multi-target dummy penetration, and 0 console errors.
  - Captured gameplay artifact `sub_pen_railgun_gameplay.png`.

---

- [x] **Naval Supercarrier Battlecruiser "USS Leviathan" & EMP Shockwave Ordnance**:
  - 220m nuclear aircraft carrier moored in the northeast ocean with angled flight deck, radar tower island, and bow ski-jump stunt ramp. *(Completed in Cycle 15)*

---

## 📅 Cycle 15 Completed: Naval Supercarrier "USS Leviathan" & EMP Shockwave Ordnance
- **Naval Supercarrier Battlecruiser "USS Leviathan" (`src/world.js`, `src/config.js`)**:
  - **Scale & Hull Geometry**: Moored at `(880, -1050)` in deep northeast waters; 220m warship with 40m lower armored hull (`0x334155`), flared bow wedge, boot-topping red waterline band (`0x991b1b`), and 52m wide flight deck platform at height `y: 15.2m` (`0x18181b`).
  - **Angled Flight Deck & Equipment**: 16m angled port sponson overhang, centerline runway striping, dual forward steam catapult tracks, and 4 arrestor steel cable lines across the recovery deck.
  - **Starboard Command Island Superstructure**: 18m tall bridge island at `y: 24m` with tinted bridge navigation windows (`0x0284c7`), 4 flush SPY phased-array radar panels facing cardinal points, lattice mast rising to 50m, rotating air-search radar antenna, and top aviation red warning strobe beacon.
  - **Naval Aviation Wing & Defense**: 3 parked strike fighter jets on the deck apron with swept wings and twin canted vertical stabilizers; 2 automated Phalanx CIWS radar-guided rotary cannon mounts protecting port and starboard approaches.
  - **Stunt Ramp Network**:
    - **Stern Boarding Incline**: 22m x 44m angled ramp sloping up from water level into the flight deck runway.
    - **Bow Ski-Jump Launch**: 26m x 38m ski-jump ramp (`angle: 0.38 rad`) with $1.85\times$ launch multiplier sending the boat soaring high above the bay for the exclusive stunt:
      `"🚀 SUPERCARRIER FLIGHT DECK LAUNCH! +1600 PTS"` with instant $5.0\times$ combo max!
- **Tactical EMP Shockwave Ordnance Weapon (`src/weapons.js`, `src/factions.js`, `src/audio.js`, `src/boat.js`, `src/game.js`, `src/config.js`)**:
  - **EMP Ordnance Pickup Crate**: High-tech composite crate with violet neon electromagnetic coils (`0xa855f7`), rotating torus halo, and violet point light spawned at the carrier mooring berth (`(916, -1026)`). Scooping awards $+3$ EMP charges.
  - **HUD Weapon Dock Transformation**: Secondary weapon slot `#wep-depth` dynamically transforms into `⚡ EMP BLAST` with remaining charge counter (`X CHARGES`) and glowing violet neon border (`#a855f7`).
  - **Electromagnetic Discharge Mechanics (`Q` key)**: Drops a buoyant EMP canister with hydrodynamic drag. On detonation:
    - Triggers synthesized dual-stage audio `soundManager.playEMPBlast()` (3.2kHz electrostatic discharge snap descending into a heavy 60Hz magnetic hum).
    - Spawns expanding violet shockwave sphere (`radius: 65m`, `life: 0.65s`) and $+0.65$ camera trauma screen shake.
    - 76+ multi-stage violet and cyan voxel crumbles burst outward on detonation.
  - **Fleet Immobilization Effect**: All hostile vessels within 65m (Police Cutters, Heavy Interceptors, Cartel Gunboats, Pirates, and Air-1 Helicopter) have their engines disabled (`empDisabledTimer = 7.0s`), speed forced to zero, sirens silenced, weapons jammed, searchlights extinguished, and emit violet spark voxels.
  - **Stunt Reward**: Awards `"⚡ EMP SHOCKWAVE DISCHARGE! (X PURSUERS DISABLED!)"` with up to $+2100$ combo score.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🚢` Supercarrier icon at `(880, -1050)` with purple circular radar reticle.
  - `⚡` Violet halo blip tracking active EMP Shockwave ordnance crates.
- **Verification**:
  - Automated Playwright test suite `test_cycle15.py` verified supercarrier dimensions, flight deck ramps, EMP crate collection, weapon card dynamic HUD transition, EMP detonation pursuer immobilization, bow ski-jump stunt launch, and 0 console errors.
  - Captured gameplay artifact `supercarrier_emp_gameplay.png`.

---

- [x] **Floating Seaplane Hangar & Amphibious Water Landing Strip with Fuel Fire Hazards**:
  - Twin-slip floating hangar carved into the southern reef at `(-480, -920)` with corrugated metal arched roof, taxiway buoys, and moored amphibious Grumman Goose seaplane. *(Completed in Cycle 16)*

---

## 📅 Cycle 16 Completed: Floating Seaplane Hangar & Water Runway with Surface Oil Fire Hazards
- **Floating Seaplane Hangar Architecture (`src/world.js`, `src/config.js`)**:
  - **Location & Dimensions**: Anchored in the southern reef at `(-480, -920)`; 54m wide by 64m long by 22m high floating marine aviation facility with double barrel-vault arched roofs (`0x475569`, metalness 0.75), heavy concrete portal lintels with hazard chevrons (`0xf59e0b`), amber aviation roof beacons, and sodium floodlights (`0xf59e0b`).
  - **Twin-Slip Marine Docks**: Flanked by floating timber service pontoons (`0x5c4033`) with central gangway divider separating Port and Starboard slipways.
  - **Infiltration Event**: Piloting into the slipway triggers `"✈️ SEAPLANE HANGAR INFILTRATION! +850 PTS"` and radio dispatch:
    `'✈️ [AIR-SEA DISPATCH]: Unidentified speedboat entered Seaplane Slipway 2!'`.
  - **Guaranteed Crown Diamond Smuggle Cache**: Spawned in the starboard slipway (`x: -466.5, z: -920`) providing $+1500$ points and 10s Nanite Shield.
- **Moored Amphibious Twin-Engine Seaplane (Grumman Goose Style)**:
  - Moored in the port slipway with stepped flying boat hull (`0xf8fafc`), dark keel boot-topping stripe (`0x0f172a`), 26m high gull wing, wingtip stabilizer floats (`0x0284c7`), glazed greenhouse canopy (`0x00f2fe`), and twin radial engine cowlings with continuous idling 3-bladed propellers (`0xd97706`).
- **Amphibious Water Runway Landing Strip & Takeoff Ski-Jumps (`src/world.js`, `src/boat.js`)**:
  - 190m water landing strip extending south from the hangar (`z: -884` to `z: -694`) flanked by 14 floating breakwater pontoons with green threshold approach lights and red end-of-runway beacons.
  - **Dual Ski-Jump Runway Ramps**: North and south thresholds equipped with 28m ski-jump ramps (`isRunwayRamp: true`, $1.48\times$ launch force).
  - Launching off the ramp awards:
    `"🛫 WATER RUNWAY TAKEOFF! +900 PTS"`!
- **High-Octane Aviation Fuel Drums & Surface Oil Fire Hazards (`src/world.js`, `src/weapons.js`, `src/audio.js`)**:
  - 6 pressurized `AVGAS 100LL` fuel drum clusters on floating wooden pontoon pads around the hangar perimeter and runway threshold.
  - Projectile hit-testing across all player and enemy weapons (MGs, torpedoes, railgun bolts, depth charges).
  - On destruction: Detonates into multi-stage fireballs, triggers `soundManager.playFireIgnite()`, screen trauma shake, and spawns a **Surface Oil Fire Hazard** (`burnDuration: 14s`).
  - **Persistent Flame Corridor**: Surface burning oil slick mesh with animated flame cones and dynamic flickering orange point light (`0xff7700`, 3.2 intensity, 28m range).
  - **Combustion Damage**: Deals 35 HP/s fire damage to hostile boats traversing the flame patch (with continuous hull fire voxel crumbles). Deals 12 HP/s heat damage to player boat unless protected by the Nanite Energy Shield.
  - Awards stunt: `"🔥 FUEL DEPOT INFERNO! +700 PTS"`.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🛩️` Seaplane hangar icon at `(-480, -920)`.
  - Green dashed runway vector line delineating the 190m water landing corridor.
- **Verification**:
  - Headless Playwright test suite `test_cycle16.py` verified seaplane hangar geometry, seaplane model, infiltration stunt, fuel drum detonation, surface oil fire damage, water runway takeoff jump, and 0 console errors.
  - Captured gameplay artifact `seaplane_runway_gameplay.png`.

---

- [x] **Smuggler's Sea Arch Cavern & Dynamic Rogue Wave Surge Hazard**: Natural coral sea arch cavern at `(240, -420)` with narrow rock pillars requiring precise high-speed drift chicanes and periodic 50-foot rogue tidal wave swell rolling across the channel. *(Completed in Cycle 17)*

---

## 📅 Cycle 17 Completed: Smuggler's Sea Arch Cavern, Slalom Needle Spires & Dynamic Rogue Tidal Wave Surge
- **Smuggler's Sea Arch Cavern Landmark (`src/world.js`, `src/config.js`)**:
  - **Limestone Chasm & Arch Bridge**: Positioned at `(240, -420)`. Features twin massive weathered limestone pillars (`x: 218` and `x: 262`, radius 13m, height 28m) flanking the ocean thoroughfare, spanned by an overhead arched limestone rock bridge (`y: 20-27m`) with natural jagged stone peaks.
  - **Slalom Needle Spires**: Flanked by sharp needle rock spires at `(240, -465)` (North approach) and `(240, -375)` (South exit) forming a challenging chicane slalom course that punishes reckless navigation.
  - **Central High-Tension Grapple Mooring Dolphin**: Heavy mooring dolphin centered inside the arch chasm at `(240, -420)` with an electric cyan neon ring (`0x00f2fe`), enabling high-G slingshot drift turns around the limestone pillars!
  - **Infiltration Event & Stunt**: Weaving through the chasm awards:
    `"🗿 SEA ARCH SLALOM! +800 PTS"`
    and broadcasts radio dispatch:
    `'🗿 [CHASM NAVIGATED]: Speedboat threaded the Smuggler\'s Sea Arch!'`.
  - **Guaranteed Contraband Cache**: Floating contraband pickup positioned directly under the arch bridge.
- **Dynamic Rogue Tidal Wave Surge System (`src/world.js`, `src/boat.js`, `src/audio.js`, `src/config.js`)**:
  - **Mathematical Wavefront Superposition**: Integrated directly into `world.getWaveHeight(x, z)`, dynamically lifting the entire Three.js ocean mesh, player hull buoyancy, and boat wake physics simultaneously without artificial physics decoupling.
  - **Visual Wave Crest Mesh**: 260m-wide curved translucent foaming cyan wavefront (`0x38bdf8`, emissive `0x0284c7`, opacity 0.78) with brilliant white crest spray lip (`0xffffff`) surging diagonally across the waterways at 32 m/s.
  - **Periodic Channel Inundation**: Automatically surges every 50 seconds (or on scripted trigger), playing thunderous acoustic rumbling `soundManager.playRogueWaveSurge()`, camera trauma shake ($+0.55$), and emergency dispatch:
    `'🌊 [ROGUE SWELL SURGE]: 50-FOOT ROGUE TIDAL WAVE CRASHING THROUGH WATERWAYS!'`.
  - **Broadside Swell Impact on Enemy Fleet**: Hostile vessels caught in the wave crest path take 45 HP structural damage, spin out violently (`spinVelocity: 16 rad/s`), and are propelled along the wave propagation normal with explosive water splash debris.
  - **50-Foot Rogue Wave Surf Launch Stunt (`src/boat.js`)**: Speedboats hitting the crest face at speed ($v_F > 20$) are launched into genuine ballistic high-altitude flight ($v_Y \approx 47\text{ m/s}$), triggering:
    `"🌊 50-FOOT ROGUE WAVE SURF LAUNCH! +1400 PTS"`,
    aerodynamic whoosh audio `playRampLaunch()`, screen trauma, and landing touchdown stunt:
    `"🌊 TITANIC SURF TOUCHDOWN! +600 PTS"`.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🗿` Sea Arch icon at `(240, -420)`.
  - Dynamic cyan wavefront vector line with forward-pointing chevron directional arrows tracing the active rogue wave across the minimap in real time.
- **Verification**:
  - Headless Playwright test suite `test_cycle17.py` verified Sea Arch colliders, grapple dolphin, slalom stunt trigger, rogue wave mathematical height displacement ($+4.74\text{m}$ crest), broadside enemy damage/impulse, and the 50-foot surf launch.
  - 100% PASS with 0 console errors.
  - Captured visual gameplay screenshot `sea_arch_roguewave_gameplay.png`.

---

- [x] **Sentinel Lighthouse Island, Rotating Searchlight Sweeper & Sunken Galleon Coral Ramp Reef**: Weathered 38m granite lighthouse island at `(-200, -780)` with rotating Fresnel lens spotlight beam that sweeps a 95m radius, automated coastal defense turrets, and sunken 17th-century Spanish Galleon shipwreck on a treacherous coral reef. *(Completed in Cycle 18)*

---

## 📅 Cycle 18 Completed: Sentinel Lighthouse Island, Rotating Searchlight Sweeper & Sunken Galleon Coral Ramp Reef
- **Sentinel Lighthouse Island Landmark (`src/world.js`, `src/config.js`, `src/audio.js`)**:
  - **Granite Island Base**: Positioned at `(-200, -780)` with a 38m-diameter granite bedrock platform (`0x334155`) surrounded by 8 shoreline boulder colliders.
  - **38m Weathered Sentinel Lighthouse Tower**: Tapered cylindrical masonry tower with alternating white (`0xf8fafc`) and dark slate (`0x1e293b`) striped bands, elevated gallery walkway with dark steel railings, lantern room glass enclosure (`0x38bdf8`, opacity 0.45), verdigris oxidized copper dome (`0x0d9488`), and brass lightning rod spire (`y: 49.5m`).
  - **High-Power Rotating Fresnel Spotlight**: Translucent volumetric light cone (`coneGeo`, length 95m, additive yellow `0xfef08a`, opacity 0.35) combined with a high-intensity focused spotlight tilted 22 degrees onto the sea surface, continuously rotating at 0.68 rad/s.
  - **Dynamic Illumination Detection**: Computes angular angular divergence between spotlight orientation and the player boat. When illuminated in the searchlight cone:
    - Triggers acoustic klaxon alarm `soundManager.playSearchlightAlarm()`.
    - Escalates Wanted Level by $+1$ star (`player.addWanted(1)`).
    - Dispatches emergency alert: `'🚨 [SENTINEL BEACON]: INTRUDER VESSEL ILLUMINATED BY LIGHTHOUSE WATCHTOWER!'`.
    - Adds $+0.25$ camera screenshake trauma.
  - **Mournful Acoustic Foghorn (`src/audio.js`)**: Periodic dual-oscillator acoustic brass foghorn blast (`soundManager.playFogHorn()`, 115 Hz and 118.5 Hz beating chorus with resonant lowpass decay over 2.4s).
  - **Dual Automated Coastal Defense Turrets**: Twin heavy machine gun turrets on the north (`z: -806`) and south (`z: -754`) bastions that automatically track illuminated or high-wanted suspect vessels within 135m, firing high-velocity tracer bursts every 1.4s.
- **Sunken 17th-Century Spanish Galleon Shipwreck (`CONFIG.SUNKEN_GALLEON` at `(-160, -740)`)**:
  - **Timber Shipwreck Model**: 54m half-submerged weathered timber galleon hull resting at a dramatic 15-degree tilt on the reef shallows, with elevated forecastle, tiered sterncastle, and 9 curved wooden hull ribs protruding above the surf.
  - **Mainmast Oceanic Stunt Ramp**: Snapped mainmast timber spar forming a natural 34m incline ramp (`isShipwreckRamp: true`, $1.55\times$ launch boost).
  - **Stunt Jump & Touchdown Sequence (`src/boat.js`)**: Hitting the mast ramp at speed launches the boat into ballistic aerial flight, awarding:
    `"🏴‍☠️ SUNKEN GALLEON MAST JUMP! +1100 PTS"`!
  - **Submerged Crown Diamond Smuggle Cache**: Hidden inside the flooded captain's quarters, providing $+1500$ points and a 10s Nanite Energy Shield.
- **Jagged Coral Reef Hazard Shallows**:
  - 6 sharp conical coral reef rock spires flanking the shipwreck shallows (`color: 0xf43f5e` vibrant rose reef).
  - Contacting or scraping the jagged coral instantly tears 18 structural damage from unprotected hulls, ejecting vibrant pink/rose coral voxel crumbles into the surf (completely absorbed by the Nanite Shield).
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🗼` Lighthouse icon at `(-200, -780)` with dynamic sweeping yellow translucent searchlight beam sector indicating live beam orientation.
  - `🏴‍☠️` Sunken Galleon shipwreck icon at `(-160, -740)`.
- **Verification**:
  - Headless Playwright test suite `test_cycle18.py` verified lighthouse geometry, beam illumination detection, searchlight alarm siren, coastal defense turret projectile fire, shipwreck mast ramp registration, mast stunt launch, coral reef hazard damage, and 0 console errors.
  - Captured visual gameplay screenshot `lighthouse_shipwreck_gameplay.png`.

---

- [x] **Waterspout Vortex Hazard & Cartel Armored Amphibious Hovercraft Gunship**: Dynamic marine waterspout tornado vortex with swirling cloud funnel and physical centripetal suction that pulls boats into a whirling whirlpool and launches them into the sky; Heavy Cartel Armored Hovercraft enemy with dual spinning stern propeller fans and twin forward autocannons. *(Completed in Cycle 19)*

---

## 📅 Cycle 19 Completed: Waterspout Vortex Hazard & Cartel Armored Amphibious Hovercraft Gunship
- **Dynamic Marine Waterspout Tornado Hazard (`src/world.js`, `src/config.js`, `src/audio.js`, `src/boat.js`)**:
  - **3D Atmospheric Funnel Architecture**: Positioned at base coordinates `(-60, -350)`. Built with dual-sheath geometry:
    - Inner swirling cyclonic funnel column (85m height, tapered base radius 3.2m to 16m aloft, electric cyan `0x38bdf8`, additive blending, opacity 0.52).
    - Outer churning white spray sheath (80m height, base radius 5m to 22m aloft, pure white `0xffffff`, counter-rotating at 4.2 rad/s).
    - Base water spray collar on sea surface (torus geometry, radius 15m, tube 3.2m, foam white `0xe0f2fe`, spinning at 7.5 rad/s with dynamic wave bobbing).
    - Overhead storm cloud anvil (`0x1e293b`, 24m radius, scaled 1.5x at altitude 85m).
    - Dynamic cyan vortex point light (`0x00f2fe`, intensity 3.5, 55m attenuation).
  - **Organic Channel Wandering**: Waterspout wanders smoothly along a sinusoidal figure-eight across the central channel (`45m` X-range, `35m` Z-range).
  - **Physical Cyclonic Centripetal Suction**:
    - Calculates distance $d$ within suction radius ($55\text{m}$).
    - Applies radial centripetal pull inward toward the eye: $F_r = (1 - d/R) \times 26\text{ m/s}^2$.
    - Applies tangential whirlpool swirl torque: $F_\theta = (1 - d/R) \times 34\text{ m/s}^2$, whipping boats around the vortex perimeter with camera trauma screenshake.
  - **Core Eye Updraft Stunt Launch ($52\text{ m/s}$)**:
    - Speedboats drawn into the eye core ($d < 11\text{m}$) are catapulted vertically into the stratosphere with $v_Y = 52\text{ m/s}$.
    - Plays thunderous cyclonic roar `soundManager.playWaterspoutRoar()`.
    - Triggers slow-motion aerial camera dilation and stunt badge:
      `"🌪️ WATERSPOUT VORTEX LAUNCH! +1350 PTS"`!
    - Emergency police scanner dispatch: `'🌪️ [CYCLONIC UPDRAFT]: Speedboat sucked into the eye of the marine waterspout!'`.
    - Safe touchdown awards: `"🌪️ CYCLONE TOUCHDOWN! +500 PTS"`.
  - **Hostile Fleet Vortex Tossing**:
    - Enemy police cutters, cartel speedboats, and pirate skiffs caught in the vortex take continuous grinding damage (90 DPS) and are whipped into the air ($v_Y = 35\text{ m/s}$) with violent 22 rad/s spinouts and blue/white water voxel crumbles!
- **Cartel Armored Amphibious Hovercraft Gunship (`CartelHovercraft` in `src/factions.js`)**:
  - **Composite Hull & Skirt Architecture**:
    - Inflated black perimeter hover skirt (`0x0f172a`, elliptical torus $8.5 \times 1.8\text{m}$).
    - Heavy armored composite deck (`0x18181b`) with amber carbon racing stripes (`0xf59e0b`).
    - Amber-tinted greenhouse cockpit bridge (`0xf59e0b`, opacity 0.65).
    - Twin aft ducted propulsion fans with orange composite blades that spin dynamically with vehicle velocity.
    - Under-skirt cushion air point light (`0xf59e0b`).
  - **Amphibious Wave Cushion Dynamics**:
    - Rides on an air cushion elevated $1.2\text{m}$ above sea swells with smooth sinusoidal hover bobbing.
  - **Twin Bow Sponson Autocannons**:
    - Alternating 4-round burst salvos from dual forward sponsons every 2.4s.
    - Custom rapid-fire metallic autocannon sound `soundManager.playAutocannon()`.
  - **Destruction Blowout & Prototype Weapon Drop**:
    - 190 HP heavy armor.
    - Defeat causes violent multi-color voxel blowout (composite black, amber, dark slate, white spray).
    - Drops a **Hyper-Velocity Railgun Ammo Crate** pickup upon destruction!
    - Awards stunt badge: `"💥 CARTEL HOVERCRAFT SUNK! +1200 PTS"`!
    - Scanner dispatch: `'⚠️ [CARTEL FREQ]: Heavy Hovercraft gunship neutralized! Prototype railgun cache dropped!'`.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🌪️` Waterspout vortex icon with dashed cyan perimeter suction radius circle.
  - Cartel Hovercraft blip rendered with distinct amber elliptical hull and dual ducted fan tick marks.
- **Verification**:
  - Headless Playwright test suite `test_cycle19.py` verified waterspout 3D meshes, inward centripetal suction physics, 52 m/s core updraft launch, Cartel Hovercraft AI, autocannon salvos, defeat railgun drop, and radar markers.
  - 100% PASS with 0 console errors.
  - Captured visual gameplay screenshot `waterspout_hovercraft_gameplay.png`.

---

- [x] **Floating Offshore Casino Palace & Luxury Superyacht Marina with High-Stakes Vault Heist**: Lavish 120m multi-tiered Floating Casino Mega-Catamaran anchored in the southeast lagoon with animated neon roof marquee signs (`CASINO POSEIDON`), glass skylights, grand entrance canal with fountain ramps, and a rooftop helicopter landing pad with a stunt jump launch; High-Stakes Diamond Vault with $+2500$ PTS jackpot, 12s Nanite Shield, and 2 Private Security Patrol Catamarans armed with electrified shock cannons. *(Completed in Cycle 20)*

---

## 📅 Cycle 20 Completed: Floating Offshore Casino Palace, Superyacht Marina & High-Stakes Vault Heist
- **Floating Offshore Casino Palace ("The Grand Poseidon") Landmark (`src/world.js`, `src/config.js`, `src/audio.js`)**:
  - **Mega-Catamaran Double-Hull Architecture**: Located at `(520, -180)`. Built with twin 115m onyx-navy pontoons (`0x090d16`) with metallic gold waterline boot-stripes (`0xf59e0b`), spanning a 62m-wide central promenade gaming deck (`y: 5.2m`).
  - **Lower Gaming Salon**: 48m-wide illuminated cyan glass pavilion (`0x0284c7`, opacity 0.75) with warm interior golden gaming chandelier glow (`0xfbbf24`, intensity 2.5).
  - **VIP Penthouse Superstructure**: Onyx composite executive penthouse (`y: 14.5m`) overlooking the lagoon.
  - **Rooftop Helipad & High-Altitude Launch Ramp**:
    - 26m rooftop helipad at `y: 17.0m` with bold yellow `H` markings and landing circle.
    - 28m rooftop stunt ramp pointing North (`isCasinoHelipadRamp: true`, $1.60\times$ launch boost).
    - Vaulting off the rooftop helipad triggers:
      `"🚁 CASINO HELIPAD ROOF VAULT! +1300 PTS"`!
  - **Animated Neon Marquee Sign**:
    - Dual neon tube marquee sign (`CASINO POSEIDON`) with cycling magenta (`0xec4899`) and cyan (`0x06b6d4`) neon light tubes and dynamic HSL color-shifting point light.
  - **Southern Grand Entrance Canal Fountain & Stunt Launch Ramp**:
    - 20m marble fountain basin at `(520, -122)` with dynamic pulsating water jet plume and cyan underwater spot.
    - White marble stunt launch ramp (`isCasinoFountainRamp: true`, $1.52\times$ launch boost).
    - Vaulting over the fountain basin into the casino promenade triggers:
      `"🎰 CASINO FOUNTAIN LAUNCH! +1150 PTS"`!
  - **Luxury Superyacht Berths**:
    - 2 sleek 34m multi-million dollar luxury motor yachts docked at the marina slips:
      - Starboard yacht at `(564, -168)` (Onyx black with gold waterline trim).
      - Port yacht at `(476, -195)` (Brilliant white with sapphire blue trim).
    - Modeled with swept tinted flybridges, teak sun decks, radar arches, and full physical colliders.
  - **Flanking Grapple Mooring Dolphins**:
    - Dual high-tension grapple mooring dolphins flanking the casino entrance with pulsating magenta neon rings (`0xec4899`), enabling high-speed drift wraps around the complex.
- **High-Stakes Diamond Vault Heist (`src/world.js`, `src/boat.js`, `src/audio.js`)**:
  - Heavy armored steel safe with gold vault wheel, surrounded by rotating magenta and cyan electric security laser rings.
  - Infiltrating the vault awards:
    `"🎰 GRAND CASINO VAULT HEIST! +2500 PTS"`!
  - Activates **12 seconds of Nanite Energy Shield** invulnerability and full nitro boost.
  - Triggers casino jackpot fanfare `soundManager.playCasinoJackpot()` (rapid C-major pentatonic arpeggios + brass synthesizer stab).
  - Escalates Wanted Level by $+2$ stars to 3-Star Heat with camera screenshake trauma ($+0.55$).
  - Dispatch: `'🎰 [HIGH ROLLER HEIST]: GRAND POSEIDON VAULT CRACKED! $2.5M DIAMOND SHIPMENT SECURED!'`.
- **Casino Private Security Patrol Catamarans (`SecurityCatamaran` in `src/factions.js`)**:
  - 2 high-speed luxury security catamarans patrolling the marina perimeter at 38 knots.
  - Twin sleek catamaran hulls, central hydrofoil cross-deck, cyan greenhouse cockpit, and alternating amber/cyan roof strobe beacons.
  - **Electrified Shock Cannon Salvo**: Fires rapid-fire 3-round bursts of high-velocity plasma projectiles with custom buzzing electric audio `soundManager.playShockCannon()`.
  - Defeating a security boat produces onyx/gold/cyan voxel debris, drops a **Contraband Crate** pickup, awards $+750$ stunt points, and broadcasts security alert.
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🎰` Grand Poseidon Casino icon at `(520, -180)` with gold circular perimeter boundary.
  - Dual-hull cyan icon for Casino Security Catamarans with flashing alert rings.
- **Verification**:
  - Headless Playwright test suite `test_cycle20.py` verified Casino Palace structure, pontoon & superyacht colliders, fountain & helipad stunt launches, diamond vault heist pickup, security catamaran AI and shock cannons, defeat drops, and radar rendering.
  - 100% PASS with 0 console errors.
  - Captured visual gameplay screenshot `casino_superyacht_gameplay.png`.

---

- [x] **Naval Zeppelin Gunship ("The Iron Valkyrie") Aerial Boss & Smuggler's Hydrofoil Speed Wings**: Massive 110m rigid dirigible airship patrolling the skies at altitude 62m above the waterways, armed with twin gondola autocannons, aerial cluster depth charges, and a downward spotlight; Smuggler's Hydrofoil Speedboat dynamic retractable T-foils lifting the hull 0.85m above water drag with $+14$ knots max speed bonus and wing-flight stunt engine. *(Completed in Cycle 21)*

---

## 📅 Cycle 21 Completed: Naval Zeppelin Gunship Boss & Smuggler's Hydrofoil Speed Wings
- **Smuggler's Retractable Hydrofoil Speed Wings (`src/boat.js`, `src/config.js`, `src/audio.js`)**:
  - **T-Foil Carbon Wing Assembly**: Dual carbon-composite T-foils mounted at bow (`z: +3.2m`) and stern (`z: -3.8m`) with vibrant cyan winglet stabilizers (`0x00f2fe`).
  - **High-Speed Auto-Deployment Physics**:
    - Triggers whenever forward speed exceeds $28\text{ knots}$ or boost is engaged (`input.throttle > 0`).
    - Smooth strut deployment animation: carbon foils extend downward into the water (`-0.45m` strut stroke).
    - Custom acoustic foil hydro-whoosh sound effect `soundManager.playHydrofoilWhoosh()`.
  - **Dynamic Sea-Surface Hydrodynamic Lift**:
    - Elevates boat hull $0.85\text{m}$ completely out of the water, skimming above swell chop and wave friction.
    - Grants $+14\text{ knot}$ top speed bonus, transforming top speed into an astonishing $52\text{ knots}$ ($67\text{ knots}$ on nitro boost!).
  - **Hydrofoil Wing-Flight Stunt Engine**:
    - Sustaining continuous hydrofoil flight at $>30\text{ knots}$ for 3.0 seconds triggers:
      `"🪽 HYDROFOIL WING-FLIGHT! +700 PTS"`!
- **Naval Zeppelin Gunship ("The Iron Valkyrie") Aerial Boss (`NavalZeppelin` in `src/factions.js`)**:
  - **105m Armored Dirigible Envelope**:
    - Giant aerodynamic rigid airship envelope (`y: 62m`) with dark slate armored composite plates (`0x1e293b`), 5 brass structural rib rings (`0xd97706`), and 4 cruciform empennage stabilizer fins at the stern.
  - **Suspended Underbelly Command Gondola**:
    - 36m armored command car with illuminated amber observation bridge windows (`0xf59e0b`).
  - **Outrigger Propulsion Nacelles & Spinning Propellers**:
    - Heavy port and starboard outrigger pylons with twin engine nacelles and spinning 4-blade propellers.
  - **Downward Conical Searchlight & Water Caustic Footprint**:
    - 62m translucent amber spotlight beam (`0xfbbf24`, opacity 0.22) casting a 36m radius glowing caustic spot on the sea surface.
  - **Air Defense Radio Warning & Air Raid Siren**:
    - Approaching the zeppelin triggers periodic rising/falling acoustic air raid siren `soundManager.playAirRaidSiren()`.
    - Scanner dispatch: `'🎈 [AIR DEFENSE RADAR]: "WARNING! THE IRON VALKYRIE ZEPPELIN GUNSHIP HAS ENTERED AIRSPACE!"'`.
  - **Ventral Autocannon Barrage**:
    - Fires rapid 6-round bursts of high-velocity ammunition from gondola turrets at hostile vessels within 220m.
  - **Aerial Cluster Depth Charge Drops**:
    - When player boat maneuvers under or within 85m of the zeppelin, drops salvos of 3 whistling high-explosive cluster depth charges with custom whistling sound `soundManager.playBombWhistle()`.
    - Charges detonate upon striking the water with explosive shockwaves and water plumes!
  - **EMP Disabling**:
    - Detonating an EMP shockwave disables the Zeppelin for 7.0 seconds: engines sputter to 5 rad/s, searchlight extinguishes, and altitude dips.
  - **Combustion Death Sequence & High-Value Drops**:
    - 380 HP boss armor with physical projectile hit detection in `src/weapons.js`.
    - Fatal damage causes fiery explosion with 150+ voxel crumbles, screen traumascreenshake ($+0.8$), and awards:
      `"🎈 THE IRON VALKYRIE DOWNED! +2200 PTS"`!
    - Drops **2 Crown Diamond Caches** ($+1500$ PTS each) and **1 EMP Crate** into the water!
- **Minimap Tactical Radar Upgrades (`src/radar.js`)**:
  - `🎈` Zeppelin airship icon with glowing amber searchlight footprint perimeter circle.
- **Verification**:
  - Headless Playwright test suite `test_cycle21.py` verified hydrofoil mesh, speed-activated deployment, hull lift ($+0.62\text{m}$), foil strut extension, Zeppelin boss patrol, searchlight, EMP disabling, defeat destruction, and cargo drops.
  - 100% PASS with 0 console errors.
  - Captured visual gameplay screenshot `zeppelin_hydrofoil_gameplay.png`.

---

## 📋 Next Up: Cycle 22 (Overnight Backlog)
- [ ] **Bermuda Triangle Ghost Fleet & Phantom Leviathan Tentacle Hazard**:
  - Haunted northern mist sector with derelict spectral galleons, ghost fog, and giant bioluminescent Kraken tentacles that erupt from the ocean depths to smash hulls, fling boats into the air, and swallow pursuers!












