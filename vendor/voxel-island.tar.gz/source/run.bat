@echo off
title Project Launcher
color 0A

cd /d "%~dp0"

echo ============================================
echo        Installing Dependencies...
echo ============================================
echo.

:: Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo Node.js is not installed.
    echo Download: https://nodejs.org/
    pause
    exit /b
)

:: Install dependencies
if not exist "node_modules" (
    call npm install
)

echo.
echo ============================================
echo      Starting Development Server...
echo ============================================
echo.

:: Wait a few seconds, then open browser
start "" cmd /c "timeout /t 8 /nobreak >nul && start http://localhost:5173"

call npm run dev

pause