// Voxel Floating Island — Third Person View
// ============================================

import * as THREE from 'three/webgpu';
// TSL imports removed — water uses simple MeshLambertMaterial now
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';

// ============================================
// CONSTANTS
// ============================================
const WORLD_SIZE = 64;
const WORLD_HEIGHT = 32;
const WATER_LEVEL = 6;
const TOTAL_BLOCKS = WORLD_SIZE * WORLD_HEIGHT * WORLD_SIZE;

const BLOCK_TYPES = {
  AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, SAND: 4,
  WOOD: 5, LEAVES: 6, WATER: 7, COAL: 8, BEDROCK: 9, PLANK: 10,
  FENCE: 11, FLOWER_WHITE: 12, FLOWER_RED: 13, PATH: 14
};

// ============================================
// RENDERER SETUP
// ============================================
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x88D8F0);
scene.fog = new THREE.FogExp2(0x88D8F0, 0.004);

const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 500);

let renderer;
let useGPUCompute = false;

renderer = new THREE.WebGPURenderer({ antialias: true, forceWebGL: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
await renderer.init();

renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap; // PCFShadow is cheaper than PCFSoft
const root = document.getElementById('root') ?? document.body;
root.appendChild(renderer.domElement);

// ============================================
// TEXTURE GENERATION
// ============================================
function createTexture(drawFn, size = 16) {
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  drawFn(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

const grassTopTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#07a60c'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 40; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#069a0a' : '#08b20e'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 1, 1); }
});
const grassSideTex = createTexture((ctx, s) => {
  // Top half: grass green (rows 0-7)
  ctx.fillStyle = '#07a60c'; ctx.fillRect(0, 0, s, s / 2);
  // Green noise variation on top half
  for (let i = 0; i < 30; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#069a0a' : '#08b20e'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * (s / 2)), 1, 1); }
  // Slightly darker green at the very top edge (like Minecraft grass top border)
  ctx.fillStyle = '#058a09'; ctx.fillRect(0, 0, s, 1);
  // Bottom half: dirt brown (rows 8-15)
  ctx.fillStyle = '#9B7B4E'; ctx.fillRect(0, s / 2, s, s / 2);
  // Dirt noise variation on bottom half
  for (let i = 0; i < 30; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#8B6B3E' : '#AB8B5E'; ctx.fillRect(Math.floor(Math.random() * s), s / 2 + Math.floor(Math.random() * (s / 2)), Math.random() > 0.5 ? 2 : 1, 1); }
  // Darker dirt at very bottom
  ctx.fillStyle = '#7B5B2E'; ctx.fillRect(0, s - 2, s, 2);
  // Jagged grass-dirt transition at the midline
  for (let i = 0; i < s; i++) {
    const hang = Math.floor(Math.random() * 3);
    if (hang > 0) { ctx.fillStyle = Math.random() > 0.4 ? '#069a0a' : '#058209'; ctx.fillRect(i, s / 2, 1, hang); }
    const rise = Math.floor(Math.random() * 2);
    if (rise > 0) { ctx.fillStyle = Math.random() > 0.5 ? '#8B6B3E' : '#9B7B4E'; ctx.fillRect(i, s / 2 - rise, 1, rise); }
  }
});
const dirtTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#9B7B4E'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 40; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#8B6B3E' : '#AB8B5E'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 1, 1); }
});
const stoneTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#999999'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 60; i++) { const shade = 0x88 + Math.floor(Math.random() * 0x33); ctx.fillStyle = `rgb(${shade},${shade},${shade})`; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), Math.random() > 0.5 ? 2 : 1, 1); }
});
const sandTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#e4c97a'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 40; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#d4b96a' : '#f4d98a'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 1, 1); }
});
const woodTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#7B5236'; ctx.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y++) { ctx.fillStyle = y % 3 === 0 ? '#6B4226' : '#8B6246'; ctx.fillRect(0, y, s, 1); }
});
const leavesTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#069a0a'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 50; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#058209' : '#08b20e'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 2, 2); }
});
const waterTex = createTexture((ctx, s) => {
  ctx.fillStyle = 'rgba(30, 110, 210, 0.9)'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 20; i++) { ctx.fillStyle = 'rgba(60, 155, 235, 0.7)'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 3, 1); }
});
const coalTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#999'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 40; i++) { const shade = 0x88 + Math.floor(Math.random() * 0x33); ctx.fillStyle = `rgb(${shade},${shade},${shade})`; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 1, 1); }
  ctx.fillStyle = '#333'; ctx.fillRect(3, 4, 3, 3); ctx.fillRect(8, 9, 4, 3); ctx.fillRect(11, 3, 3, 2);
});
const bedrockTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#444'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 60; i++) { ctx.fillStyle = `rgb(${40 + Math.floor(Math.random() * 40)},${40 + Math.floor(Math.random() * 40)},${40 + Math.floor(Math.random() * 40)})`; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), 2, 2); }
});
const plankTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#c8a46a'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 4; i++) { const y = i * 4; ctx.fillStyle = '#b8945a'; ctx.fillRect(0, y, s, 1); ctx.fillStyle = i % 2 === 0 ? '#d8b47a' : '#c8a46a'; ctx.fillRect(0, y + 1, s, 3); }
});
const fenceTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#C4A05A'; ctx.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y++) { ctx.fillStyle = y % 4 === 0 ? '#A88040' : '#D4B06A'; ctx.fillRect(0, y, s, 1); }
});
const pathTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#C8A870'; ctx.fillRect(0, 0, s, s);
  // Stone-like path texture with visible block edges
  ctx.fillStyle = '#B89860'; ctx.fillRect(0, 0, s, 1); ctx.fillRect(0, 0, 1, s);
  ctx.fillStyle = '#D8B880'; ctx.fillRect(1, 1, s-2, s-2);
  for (let i = 0; i < 20; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#C09050' : '#DABB80'; ctx.fillRect(1+Math.floor(Math.random() * (s-2)), 1+Math.floor(Math.random() * (s-2)), 2, 1); }
  // Darker edges to make each cube visible
  ctx.fillStyle = '#A08040'; ctx.fillRect(0, s-1, s, 1); ctx.fillRect(s-1, 0, 1, s);
});
const pathSideTex = createTexture((ctx, s) => {
  ctx.fillStyle = '#A08050'; ctx.fillRect(0, 0, s, s);
  // Top strip matches path color
  ctx.fillStyle = '#C8A870'; ctx.fillRect(0, 0, s, 2);
  // Dirt underneath
  for (let i = 0; i < 25; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#907040' : '#B09060'; ctx.fillRect(Math.floor(Math.random() * s), 2+Math.floor(Math.random() * (s-2)), 1, 1); }
  ctx.fillStyle = '#806030'; ctx.fillRect(0, s-1, s, 1);
});

// ============================================
// BLOCK MATERIALS
// ============================================
const blockMaterials = {};
function createBlockMaterial(topTex, sideTex, bottomTex) {
  return [
    new THREE.MeshLambertMaterial({ map: sideTex }),
    new THREE.MeshLambertMaterial({ map: sideTex }),
    new THREE.MeshLambertMaterial({ map: topTex }),
    new THREE.MeshLambertMaterial({ map: bottomTex || sideTex }),
    new THREE.MeshLambertMaterial({ map: sideTex }),
    new THREE.MeshLambertMaterial({ map: sideTex })
  ];
}
const grassBottomTex = createTexture((ctx, s) => {
  // Dirt texture for grass underside (not stone)
  ctx.fillStyle = '#8B6B3E'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 50; i++) { ctx.fillStyle = Math.random() > 0.5 ? '#7B5B2E' : '#9B7B4E'; ctx.fillRect(Math.floor(Math.random() * s), Math.floor(Math.random() * s), Math.random() > 0.5 ? 2 : 1, 1); }
  // Root-like details hanging down
  ctx.fillStyle = '#6B4B1E'; ctx.fillRect(2, 3, 1, 3); ctx.fillRect(7, 1, 1, 4); ctx.fillRect(12, 5, 1, 2);
  ctx.fillRect(5, 8, 2, 1); ctx.fillRect(10, 11, 1, 3); ctx.fillRect(3, 13, 2, 1);
  // Slightly darker edges
  ctx.fillStyle = '#6B4B1E'; ctx.fillRect(0, 0, s, 1); ctx.fillRect(0, 0, 1, s);
  ctx.fillStyle = '#7B5B2E'; ctx.fillRect(0, s-1, s, 1); ctx.fillRect(s-1, 0, 1, s);
});
blockMaterials[BLOCK_TYPES.GRASS] = createBlockMaterial(grassTopTex, grassSideTex, grassBottomTex);
blockMaterials[BLOCK_TYPES.DIRT] = createBlockMaterial(dirtTex, dirtTex, dirtTex);
blockMaterials[BLOCK_TYPES.STONE] = createBlockMaterial(stoneTex, stoneTex, stoneTex);
blockMaterials[BLOCK_TYPES.SAND] = createBlockMaterial(sandTex, sandTex, sandTex);
blockMaterials[BLOCK_TYPES.WOOD] = createBlockMaterial(woodTex, woodTex, woodTex);
blockMaterials[BLOCK_TYPES.LEAVES] = Array(6).fill(null).map(() => new THREE.MeshLambertMaterial({ map: leavesTex, transparent: true, opacity: 0.9 }));
// Water material — simple MeshLambertMaterial, no vertex displacement (avoids gaps/z-fighting)
const waterMat = new THREE.MeshLambertMaterial({
  map: waterTex,
  transparent: true,
  opacity: 0.8,
  polygonOffset: true,
  polygonOffsetFactor: 1,
  polygonOffsetUnits: 1,
  depthWrite: false,
  side: THREE.DoubleSide,
  color: 0x2E8AE6,
});

blockMaterials[BLOCK_TYPES.WATER] = waterMat;
blockMaterials[BLOCK_TYPES.COAL] = createBlockMaterial(coalTex, coalTex, coalTex);
blockMaterials[BLOCK_TYPES.BEDROCK] = createBlockMaterial(bedrockTex, bedrockTex, bedrockTex);
blockMaterials[BLOCK_TYPES.PLANK] = createBlockMaterial(plankTex, plankTex, plankTex);
blockMaterials[BLOCK_TYPES.FENCE] = createBlockMaterial(fenceTex, fenceTex, fenceTex);
blockMaterials[BLOCK_TYPES.PATH] = createBlockMaterial(pathTex, pathSideTex, dirtTex);

// ============================================
// CPU TERRAIN GENERATION — FLOATING ISLAND
// ============================================
const worldCPU = new Int32Array(TOTAL_BLOCKS);
const heightCPU = new Int32Array(WORLD_SIZE * WORLD_SIZE);

function cpuHash(x, z) {
  let n = Math.imul(x, 374761393) + Math.imul(z, 668265263);
  n = (n ^ (n >> 13)) >>> 0;
  n = Math.imul(n, 1274126177);
  return (n ^ (n >> 16)) & 0x7fffffff;
}
function cpuSmoothNoise(x, z, scale) {
  const sx = x / scale, sz = z / scale;
  const ix = Math.floor(sx), iz = Math.floor(sz);
  let fx = sx - ix, fz = sz - iz;
  const ufx = fx * fx * (3 - 2 * fx), ufz = fz * fz * (3 - 2 * fz);
  const inv = 1.0 / 0x7fffffff;
  const a = cpuHash(ix, iz) * inv, b = cpuHash(ix + 1, iz) * inv;
  const c = cpuHash(ix, iz + 1) * inv, d = cpuHash(ix + 1, iz + 1) * inv;
  return a * (1 - ufx) * (1 - ufz) + b * ufx * (1 - ufz) + c * (1 - ufx) * ufz + d * ufx * ufz;
}
function cpuGetHeight(x, z) {
  const h1 = cpuSmoothNoise(x, z, 20) * 10;
  const h2 = cpuSmoothNoise(x + 100, z + 100, 10) * 5;
  const h3 = cpuSmoothNoise(x + 200, z + 200, 5) * 2.5;
  return Math.min(Math.max(0, Math.floor(h1 + h2 + h3 + 6)), WORLD_HEIGHT - 1);
}

// ============================================
// FLOATING ISLAND SHAPE — Multiple flat platforms at ONE level
// ============================================
const islandCenterX = WORLD_SIZE / 2;
const islandCenterZ = WORLD_SIZE / 2;
const SURFACE_Y = 14; // Main flat surface level
const ISLAND_BASE = 8;
const SURFACE_Y_LOW = 12; // Lower plateau level
const SURFACE_Y_HIGH = 17; // Elevated plateau / hill level

// Define multiple connected island chunks with varying elevations
const islandPlatforms = [
  // Main large platform (center) — main level
  { cx: WORLD_SIZE / 2, cz: WORLD_SIZE / 2, rx: 14, rz: 14, shape: 'rect', tint: 0, surfaceY: SURFACE_Y },
  // Extensions at main level
  { cx: WORLD_SIZE / 2 + 12, cz: WORLD_SIZE / 2 + 4, rx: 7, rz: 6, shape: 'rect', tint: 1, surfaceY: SURFACE_Y },
  { cx: WORLD_SIZE / 2 - 11, cz: WORLD_SIZE / 2 + 2, rx: 7, rz: 8, shape: 'rect', tint: 2, surfaceY: SURFACE_Y },
  // Lower beach/valley platforms
  { cx: WORLD_SIZE / 2 + 3, cz: WORLD_SIZE / 2 - 13, rx: 8, rz: 5, shape: 'rect', tint: 3, surfaceY: SURFACE_Y_LOW },
  { cx: WORLD_SIZE / 2 - 3, cz: WORLD_SIZE / 2 + 14, rx: 6, rz: 5, shape: 'rect', tint: 4, surfaceY: SURFACE_Y_LOW },
  // Elevated hill platforms
  { cx: WORLD_SIZE / 2 + 20, cz: WORLD_SIZE / 2 - 5, rx: 4, rz: 4, shape: 'rect', tint: 5, surfaceY: SURFACE_Y_HIGH },
  { cx: WORLD_SIZE / 2 - 19, cz: WORLD_SIZE / 2 - 7, rx: 4, rz: 3, shape: 'rect', tint: 6, surfaceY: SURFACE_Y_HIGH },
  // Small detached at various levels
  { cx: WORLD_SIZE / 2 + 8, cz: WORLD_SIZE / 2 + 18, rx: 3, rz: 3, shape: 'rect', tint: 7, surfaceY: SURFACE_Y },
  { cx: WORLD_SIZE / 2 - 8, cz: WORLD_SIZE / 2 - 18, rx: 4, rz: 3, shape: 'rect', tint: 5, surfaceY: SURFACE_Y_LOW },
  // Bridge connectors (narrow) — ramp between levels
  { cx: WORLD_SIZE / 2 + 6, cz: WORLD_SIZE / 2 + 1, rx: 2, rz: 2, shape: 'rect', tint: 0, surfaceY: SURFACE_Y },
  { cx: WORLD_SIZE / 2 - 5, cz: WORLD_SIZE / 2 + 1, rx: 2, rz: 2, shape: 'rect', tint: 2, surfaceY: SURFACE_Y },
  { cx: WORLD_SIZE / 2 + 1, cz: WORLD_SIZE / 2 - 7, rx: 2, rz: 2, shape: 'rect', tint: 3, surfaceY: SURFACE_Y - 1 },
  { cx: WORLD_SIZE / 2 - 1, cz: WORLD_SIZE / 2 + 8, rx: 2, rz: 2, shape: 'rect', tint: 4, surfaceY: SURFACE_Y - 1 },
];

// Rocky mountain / hill definitions — placed on top of platforms
const mountains = [
  // Main rocky hill near center-right
  { cx: WORLD_SIZE / 2 + 6, cz: WORLD_SIZE / 2 - 3, radius: 5, peakHeight: 6, type: 'rocky' },
  // Small rock outcrop on elevated platform
  { cx: WORLD_SIZE / 2 + 20, cz: WORLD_SIZE / 2 - 5, radius: 3, peakHeight: 4, type: 'rocky' },
  // Gentle dirt mound on main platform
  { cx: WORLD_SIZE / 2 - 6, cz: WORLD_SIZE / 2 - 4, radius: 4, peakHeight: 3, type: 'dirt_hill' },
  // Small rock cluster
  { cx: WORLD_SIZE / 2 - 19, cz: WORLD_SIZE / 2 - 7, radius: 2, peakHeight: 3, type: 'rocky' },
];

// Determine if a block is on a platform, how deep, and at what surface level
function getPlatformInfo(x, z) {
  let bestDepth = -1;
  let onPlatform = false;
  let bestTint = 0;
  let bestSurfaceY = SURFACE_Y;
  for (const p of islandPlatforms) {
    const dx = Math.abs(x - p.cx);
    const dz = Math.abs(z - p.cz);
    const edgeNoise = (cpuHash(x * 7 + 123, z * 13 + 456) / 0x7fffffff) * 1.8 - 0.9;
    const inX = dx < p.rx + edgeNoise;
    const inZ = dz < p.rz + edgeNoise;
    if (inX && inZ) {
      onPlatform = true;
      const edgeDistX = p.rx - dx + edgeNoise;
      const edgeDistZ = p.rz - dz + edgeNoise;
      const edgeDist = Math.min(edgeDistX, edgeDistZ);
      const depth = Math.min(Math.floor(edgeDist * 1.5) + 2, 8);
      if (depth > bestDepth) {
        bestDepth = depth;
        bestTint = p.tint;
        bestSurfaceY = p.surfaceY;
      }
    }
  }
  return { onPlatform, depth: bestDepth, tint: bestTint, surfaceY: bestSurfaceY };
}

// Store per-block tint index for grass color variation
const grassTintMap = new Uint8Array(WORLD_SIZE * WORLD_SIZE);

// Generate floating island terrain with multiple surface levels
for (let z = 0; z < WORLD_SIZE; z++) {
  for (let x = 0; x < WORLD_SIZE; x++) {
    const info = getPlatformInfo(x, z);
    grassTintMap[x + z * WORLD_SIZE] = info.tint;
    if (!info.onPlatform) {
      heightCPU[x + z * WORLD_SIZE] = -1;
      for (let y = 0; y < WORLD_HEIGHT; y++) {
        worldCPU[x + y * WORLD_SIZE + z * WORLD_SIZE * WORLD_HEIGHT] = BLOCK_TYPES.AIR;
      }
      continue;
    }

    // Add subtle height variation within platform using noise (clamped later)
    const surfaceNoise = cpuSmoothNoise(x + 500, z + 500, 8) * 1.5 - 0.5;
    const topY = Math.min(info.surfaceY + Math.floor(surfaceNoise), WORLD_HEIGHT - 6);
    const bottomY = Math.max(topY - info.depth, ISLAND_BASE - 3);
    heightCPU[x + z * WORLD_SIZE] = topY;

    for (let y = 0; y < WORLD_HEIGHT; y++) {
      const idx = x + y * WORLD_SIZE + z * WORLD_SIZE * WORLD_HEIGHT;
      if (y < bottomY || y > topY) {
        worldCPU[idx] = BLOCK_TYPES.AIR;
        continue;
      }

      if (y === topY) {
        // Lower platforms get sand on edges
        if (info.surfaceY === SURFACE_Y_LOW && info.depth <= 3) {
          worldCPU[idx] = BLOCK_TYPES.SAND;
        } else {
          worldCPU[idx] = BLOCK_TYPES.GRASS;
        }
      } else if (y > topY - 3) {
        worldCPU[idx] = BLOCK_TYPES.DIRT;
      } else if (y === bottomY) {
        worldCPU[idx] = BLOCK_TYPES.STONE;
      } else {
        const rng = cpuHash(x * 17 + z * 31, y);
        const rngNorm = rng / 0x7fffffff;
        if (y > topY - 5) {
          worldCPU[idx] = BLOCK_TYPES.DIRT;
        } else {
          worldCPU[idx] = rngNorm < 0.08 ? BLOCK_TYPES.COAL : BLOCK_TYPES.STONE;
        }
      }
    }
  }
}

// ============================================
// SMOOTH TERRAIN — enforce max 1-block height difference between neighbors
// ============================================
{
  const maxDiff = 1;
  // Multiple passes to propagate smoothing across the terrain
  for (let pass = 0; pass < 6; pass++) {
    let changed = false;
    for (let z = 0; z < WORLD_SIZE; z++) {
      for (let x = 0; x < WORLD_SIZE; x++) {
        const h = heightCPU[x + z * WORLD_SIZE];
        if (h < ISLAND_BASE) continue;
        // Check all 4 neighbors
        for (const [dx, dz] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx = x + dx, nz = z + dz;
          if (nx < 0 || nx >= WORLD_SIZE || nz < 0 || nz >= WORLD_SIZE) continue;
          const nh = heightCPU[nx + nz * WORLD_SIZE];
          if (nh < ISLAND_BASE) continue;
          // If this block is too much higher than neighbor, lower it
          if (h - nh > maxDiff) {
            const newH = nh + maxDiff;
            // Remove blocks above newH
            for (let y = newH + 1; y <= h; y++) {
              setBlock(x, y, z, BLOCK_TYPES.AIR);
            }
            // Make sure newH is grass surface
            setBlock(x, newH, z, BLOCK_TYPES.GRASS);
            heightCPU[x + z * WORLD_SIZE] = newH;
            changed = true;
          }
        }
      }
    }
    if (!changed) break;
  }
}

// Generate mountains and rocky hills on top of existing terrain
for (const mt of mountains) {
  for (let mx = mt.cx - mt.radius - 1; mx <= mt.cx + mt.radius + 1; mx++) {
    for (let mz = mt.cz - mt.radius - 1; mz <= mt.cx + mt.radius + 1; mz++) {
      if (mx < 0 || mx >= WORLD_SIZE || mz < 0 || mz >= WORLD_SIZE) continue;
      const baseH = getHeightCPU(mx, mz);
      if (baseH < ISLAND_BASE) continue;

      const dx = mx - mt.cx;
      const dz = mz - mt.cz;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > mt.radius + 0.5) continue;

      // Height falls off from center with noise
      const falloff = 1 - (dist / (mt.radius + 0.5));
      const noiseVal = cpuSmoothNoise(mx * 3 + 777, mz * 3 + 888, 4) * 0.4;
      const pillarHeight = Math.max(0, Math.floor(mt.peakHeight * falloff * (0.7 + noiseVal)));
      if (pillarHeight === 0) continue;

      for (let dy = 1; dy <= pillarHeight; dy++) {
        const by = baseH + dy;
        if (by >= WORLD_HEIGHT) break;

        if (mt.type === 'rocky') {
          // Rocky: stone with some coal veins
          const rng = cpuHash(mx * 23 + mz * 41, by) / 0x7fffffff;
          if (dy === pillarHeight) {
            // Top: grass cap on shorter sections, stone on peak
            setBlock(mx, by, mz, dist < mt.radius * 0.4 ? BLOCK_TYPES.STONE : BLOCK_TYPES.GRASS);
          } else {
            setBlock(mx, by, mz, rng < 0.1 ? BLOCK_TYPES.COAL : BLOCK_TYPES.STONE);
          }
        } else {
          // Dirt hill: dirt with grass on top
          if (dy === pillarHeight) {
            setBlock(mx, by, mz, BLOCK_TYPES.GRASS);
          } else {
            setBlock(mx, by, mz, BLOCK_TYPES.DIRT);
          }
        }

        // Update height map
        if (by > getHeightCPU(mx, mz)) {
          heightCPU[mx + mz * WORLD_SIZE] = by;
        }
      }
    }
  }
}

// Smooth mountain transitions so all terrain has max 1-block height steps
{
  const maxDiff = 1;
  for (let pass = 0; pass < 8; pass++) {
    let changed = false;
    for (let z = 0; z < WORLD_SIZE; z++) {
      for (let x = 0; x < WORLD_SIZE; x++) {
        const h = heightCPU[x + z * WORLD_SIZE];
        if (h < ISLAND_BASE) continue;
        for (const [dx, dz] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx = x + dx, nz = z + dz;
          if (nx < 0 || nx >= WORLD_SIZE || nz < 0 || nz >= WORLD_SIZE) continue;
          const nh = heightCPU[nx + nz * WORLD_SIZE];
          if (nh < ISLAND_BASE) continue;
          if (h - nh > maxDiff) {
            const newH = nh + maxDiff;
            for (let y = newH + 1; y <= h; y++) {
              setBlock(x, y, z, BLOCK_TYPES.AIR);
            }
            // Preserve the surface block type (grass, stone, sand)
            const surfType = getBlock(x, newH, z);
            if (surfType === BLOCK_TYPES.AIR || surfType === BLOCK_TYPES.DIRT) {
              setBlock(x, newH, z, BLOCK_TYPES.GRASS);
            }
            heightCPU[x + z * WORLD_SIZE] = newH;
            changed = true;
          }
        }
      }
    }
    if (!changed) break;
  }
}

// Scatter loose rocks / boulders on the surface
for (let i = 0; i < 40; i++) {
  const rx = 4 + Math.floor(cpuHash(i * 97, i * 53) / 0x7fffffff * (WORLD_SIZE - 8));
  const rz = 4 + Math.floor(cpuHash(i * 61, i * 79) / 0x7fffffff * (WORLD_SIZE - 8));
  const rh = getHeightCPU(rx, rz);
  if (rh < ISLAND_BASE) continue;
  const blockBelow = getBlock(rx, rh, rz);
  if (blockBelow !== BLOCK_TYPES.GRASS && blockBelow !== BLOCK_TYPES.DIRT) continue;
  if (getBlock(rx, rh + 1, rz) !== BLOCK_TYPES.AIR) continue;
  // Place 1-2 stone blocks as a small rock
  setBlock(rx, rh + 1, rz, BLOCK_TYPES.STONE);
  heightCPU[rx + rz * WORLD_SIZE] = rh + 1;
  if (cpuHash(i * 33, i * 44) % 3 === 0 && getBlock(rx, rh + 2, rz) === BLOCK_TYPES.AIR) {
    setBlock(rx, rh + 2, rz, BLOCK_TYPES.STONE);
    heightCPU[rx + rz * WORLD_SIZE] = rh + 2;
  }
}

function getBlock(x, y, z) {
  if (x < 0 || x >= WORLD_SIZE || y < 0 || y >= WORLD_HEIGHT || z < 0 || z >= WORLD_SIZE) return BLOCK_TYPES.AIR;
  return worldCPU[x + y * WORLD_SIZE + z * WORLD_SIZE * WORLD_HEIGHT];
}
function setBlock(x, y, z, type) {
  if (x < 0 || x >= WORLD_SIZE || y < 0 || y >= WORLD_HEIGHT || z < 0 || z >= WORLD_SIZE) return;
  worldCPU[x + y * WORLD_SIZE + z * WORLD_SIZE * WORLD_HEIGHT] = type;
}
function getHeightCPU(x, z) {
  if (x < 0 || x >= WORLD_SIZE || z < 0 || z >= WORLD_SIZE) return -1;
  return heightCPU[x + z * WORLD_SIZE];
}

// ============================================
// TREE GENERATION
// ============================================
function hash(x, z) {
  let n = x * 374761393 + z * 668265263;
  n = (n ^ (n >> 13)) * 1274126177;
  return (n ^ (n >> 16)) & 0x7fffffff;
}

// Sparse trees — only a handful
for (let x = 4; x < WORLD_SIZE - 4; x += 6) {
  for (let z = 4; z < WORLD_SIZE - 4; z += 6) {
    if (hash(x, z) % 18 !== 0) continue;
    const h = getHeightCPU(x, z);
    if (h < 0 || h < SURFACE_Y_LOW || h >= WORLD_HEIGHT - 8) continue;
    if (getBlock(x, h, z) !== BLOCK_TYPES.GRASS) continue;
    const treeHeight = 4 + (hash(x * 7, z * 13) % 3);
    for (let y = h + 1; y <= h + treeHeight; y++) {
      setBlock(x, y, z, BLOCK_TYPES.WOOD);
    }
    const leafRadius = 2 + (hash(x * 3, z * 5) % 2);
    for (let lx = -leafRadius; lx <= leafRadius; lx++) {
      for (let lz = -leafRadius; lz <= leafRadius; lz++) {
        for (let ly = -1; ly <= 3; ly++) {
          const dist = Math.sqrt(lx * lx + lz * lz + ly * ly * 0.5);
          if (dist > leafRadius + 0.5) continue;
          const bx = x + lx, bz = z + lz, by = h + treeHeight + ly;
          if (getBlock(bx, by, bz) === BLOCK_TYPES.AIR) {
            setBlock(bx, by, bz, BLOCK_TYPES.LEAVES);
          }
        }
      }
    }
  }
}

// ============================================
// DIRT PATHS — Raised cube paths sitting ON TOP of grass
// ============================================
function generatePath(startX, startZ, endX, endZ) {
  let cx = startX, cz = startZ;
  for (let step = 0; step < 200; step++) {
    const ix = Math.floor(cx), iz = Math.floor(cz);
    const h = getHeightCPU(ix, iz);
    if (h >= ISLAND_BASE) {
      // Path width of 2-3 blocks — replace grass surface with path (same level) — replace grass surface with path (same level)
      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          if (Math.abs(dx) + Math.abs(dz) > 1 && hash(ix + dx, iz + dz) % 3 === 0) continue;
          const px = ix + dx, pz = iz + dz;
          const ph = getHeightCPU(px, pz);
          if (ph >= ISLAND_BASE && getBlock(px, ph, pz) === BLOCK_TYPES.GRASS) {
            // Replace grass block with path at same level (flat road)
            setBlock(px, ph, pz, BLOCK_TYPES.PATH);
          }
        }
      }
    }
    // Move toward target with some randomness
    const ddx = endX - cx, ddz = endZ - cz;
    const dist = Math.sqrt(ddx * ddx + ddz * ddz);
    if (dist < 2) break;
    cx += (ddx / dist) * 0.8 + (Math.random() - 0.5) * 1.2;
    cz += (ddz / dist) * 0.8 + (Math.random() - 0.5) * 1.2;
    cx = Math.max(2, Math.min(WORLD_SIZE - 3, cx));
    cz = Math.max(2, Math.min(WORLD_SIZE - 3, cz));
  }
}

// Create several paths
generatePath(WORLD_SIZE / 2, WORLD_SIZE / 2 - 10, WORLD_SIZE / 2, WORLD_SIZE / 2 + 15);
generatePath(WORLD_SIZE / 2 - 12, WORLD_SIZE / 2, WORLD_SIZE / 2 + 12, WORLD_SIZE / 2);
generatePath(WORLD_SIZE / 2, WORLD_SIZE / 2, WORLD_SIZE / 2 + 8, WORLD_SIZE / 2 + 12);

// ============================================
// FENCES ALONG PATHS
// ============================================
for (let x = 2; x < WORLD_SIZE - 2; x++) {
  for (let z = 2; z < WORLD_SIZE - 2; z++) {
    const h = getHeightCPU(x, z);
    if (h < ISLAND_BASE) continue;
    // Path blocks are now at surface level
    if (getBlock(x, h, z) !== BLOCK_TYPES.PATH) continue;
    // Check if edge of path — path is now AT surface level
    const hasPathNeighbor = (nx, nz) => {
      const nh = getHeightCPU(nx, nz);
      return nh >= ISLAND_BASE && getBlock(nx, nh, nz) === BLOCK_TYPES.PATH;
    };
    const hasGrassNeighbor = (nx, nz) => {
      const nh = getHeightCPU(nx, nz);
      return nh >= ISLAND_BASE && getBlock(nx, nh, nz) === BLOCK_TYPES.GRASS;
    };
    const grassCount = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dz]) => hasGrassNeighbor(x+dx, z+dz)).length;
    if (grassCount >= 1 && hash(x * 13, z * 29) % 5 === 0) {
      // Place fence posts on grass alongside the path edge — in a line
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, nz = z + dz;
        const nh = getHeightCPU(nx, nz);
        if (nh >= ISLAND_BASE && getBlock(nx, nh, nz) === BLOCK_TYPES.GRASS && getBlock(nx, nh + 1, nz) === BLOCK_TYPES.AIR && hash(nx * 7, nz * 11) % 2 === 0) {
                    setBlock(nx, nh + 1, nz, BLOCK_TYPES.FENCE);
          // Extend fence line in same direction for 1-3 more posts
          const extLen = 1 + hash(nx * 3, nz * 5) % 3;
          for (let e = 1; e <= extLen; e++) {
            const ex = nx + dx * e, ez = nz + dz * e;
            const eh = getHeightCPU(ex, ez);
            if (eh >= ISLAND_BASE && getBlock(ex, eh, ez) === BLOCK_TYPES.GRASS && getBlock(ex, eh + 1, ez) === BLOCK_TYPES.AIR) {
                            setBlock(ex, eh + 1, ez, BLOCK_TYPES.FENCE);
            }
          }
        }
      }
    }
  }
}

// ============================================
// FLOWERS — sparse, only on grass with no path nearby
// ============================================
for (let x = 1; x < WORLD_SIZE - 1; x++) {
  for (let z = 1; z < WORLD_SIZE - 1; z++) {
    const h = getHeightCPU(x, z);
    if (h < ISLAND_BASE) continue;
    if (getBlock(x, h, z) !== BLOCK_TYPES.GRASS) continue;
    if (getBlock(x, h + 1, z) !== BLOCK_TYPES.AIR) continue;
    // Don't place flowers where paths or fences already are
    if (hash(x * 31, z * 47) % 16 === 0) {
      setBlock(x, h + 1, z, hash(x, z) % 3 === 0 ? BLOCK_TYPES.FLOWER_RED : BLOCK_TYPES.FLOWER_WHITE);
    }
  }
}

// ============================================
// GRASS TINT PALETTE (mutable — updated by color picker)
// ============================================
const grassTints = [
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Main' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Bright' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Forest' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Lime' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Mossy' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Spring' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Emerald' },
  { top: '#07a60c', side: '#07a60c', sideEdge: '#058209', label: 'Sage' },
];

const defaultTints = grassTints.map(t => ({ ...t }));

// Derive sideEdge from top color (darken by ~25%)
function deriveEdge(hexColor) {
  const c = new THREE.Color(hexColor);
  c.offsetHSL(0, 0.05, -0.12);
  return '#' + c.getHexString();
}



// ============================================
// MESH BUILDING
// ============================================
const blockGeometry = new THREE.BoxGeometry(1, 1, 1);
const fenceGeometry = new THREE.BoxGeometry(0.3, 1, 0.3);
const blockMeshes = new THREE.Group();
blockMeshes.name = 'blockMeshes';
scene.add(blockMeshes);

function isTransparent(type) {
  return type === BLOCK_TYPES.AIR || type === BLOCK_TYPES.WATER || type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED || type === BLOCK_TYPES.FENCE;
}

function shouldRenderBlock(x, y, z) {
  const type = getBlock(x, y, z);
  if (type === BLOCK_TYPES.AIR) return false;
  if (type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED) return true;
  if (type === BLOCK_TYPES.FENCE) return true;
  if (isTransparent(getBlock(x + 1, y, z)) || isTransparent(getBlock(x - 1, y, z)) ||
      isTransparent(getBlock(x, y + 1, z)) || isTransparent(getBlock(x, y - 1, z)) ||
      isTransparent(getBlock(x, y, z + 1)) || isTransparent(getBlock(x, y, z - 1))) {
    return true;
  }
  if (type === BLOCK_TYPES.WATER) {
    return getBlock(x, y + 1, z) !== BLOCK_TYPES.WATER;
  }
  return false;
}

function collectVisibleBlocks() {
  const buckets = {};
  for (let z = 0; z < WORLD_SIZE; z++) {
    for (let y = 0; y < WORLD_HEIGHT; y++) {
      for (let x = 0; x < WORLD_SIZE; x++) {
        if (shouldRenderBlock(x, y, z)) {
          const type = getBlock(x, y, z);
          if (!buckets[type]) buckets[type] = [];
          buckets[type].push(x, y, z);
        }
      }
    }
  }
  return buckets;
}

const instancedMeshes = {};
const dummy = new THREE.Object3D();

// Build a merged water mesh that removes internal faces between adjacent water blocks
function buildWaterMesh(coords, count) {
  const positions = [];
  const normals = [];
  const uvs = [];
  const indices = [];
  let vertCount = 0;

  // Face definitions: [axis, dir, nx, ny, nz, vertices...]
  // Each face is a unit quad on one side of a cube
  const faces = [
    // +X face
    { check: [1, 0, 0], normal: [1, 0, 0], verts: [[1,0,0],[1,1,0],[1,1,1],[1,0,1]] },
    // -X face
    { check: [-1, 0, 0], normal: [-1, 0, 0], verts: [[0,0,1],[0,1,1],[0,1,0],[0,0,0]] },
    // +Y face
    { check: [0, 1, 0], normal: [0, 1, 0], verts: [[0,1,0],[0,1,1],[1,1,1],[1,1,0]] },
    // -Y face
    { check: [0, -1, 0], normal: [0, -1, 0], verts: [[0,0,1],[0,0,0],[1,0,0],[1,0,1]] },
    // +Z face
    { check: [0, 0, 1], normal: [0, 0, 1], verts: [[0,0,1],[0,1,1],[1,1,1],[1,0,1]] },
    // -Z face
    { check: [0, 0, -1], normal: [0, 0, -1], verts: [[1,0,0],[1,1,0],[0,1,0],[0,0,0]] },
  ];

  for (let i = 0; i < count; i++) {
    const bx = coords[i * 3], by = coords[i * 3 + 1], bz = coords[i * 3 + 2];

    for (const face of faces) {
      const nx = bx + face.check[0], ny = by + face.check[1], nz = bz + face.check[2];
      // Only emit face if neighbor is NOT water
      if (getBlock(nx, ny, nz) === BLOCK_TYPES.WATER) continue;

      // Add 4 vertices — shrink inward by 0.005 along face normal to prevent z-fighting with solid neighbors
      const inset = 0.005;
      for (const v of face.verts) {
        positions.push(
          bx + v[0] - face.normal[0] * inset,
          by + v[1] - face.normal[1] * inset,
          bz + v[2] - face.normal[2] * inset
        );
        normals.push(face.normal[0], face.normal[1], face.normal[2]);
      }
      // UVs for the quad
      uvs.push(0, 0, 0, 1, 1, 1, 1, 0);
      // Two triangles
      indices.push(vertCount, vertCount + 1, vertCount + 2, vertCount, vertCount + 2, vertCount + 3);
      vertCount += 4;
    }
  }

  if (vertCount === 0) return null;

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);

  const mesh = new THREE.Mesh(geo, waterMat);
  mesh.name = 'waterMerged';
  mesh.renderOrder = 1;
  return mesh;
}

function buildInstancedMeshes() {
  while (blockMeshes.children.length) blockMeshes.remove(blockMeshes.children[0]);
  for (const k of Object.keys(instancedMeshes)) delete instancedMeshes[k];

  const buckets = collectVisibleBlocks();
  let totalRendered = 0;

  for (const typeStr of Object.keys(buckets)) {
    const type = parseInt(typeStr);
    const coords = buckets[type];
    const count = coords.length / 3;
    if (count === 0) continue;

    let geo = blockGeometry;
    let mat;

    if (type === BLOCK_TYPES.WATER) {
      // Build merged water mesh — no internal faces
      const waterMesh = buildWaterMesh(coords, count);
      if (waterMesh) {
        blockMeshes.add(waterMesh);
        instancedMeshes[type] = waterMesh;
      }
      totalRendered += count;
      continue;
    } else if (type === BLOCK_TYPES.FENCE) {
      // Build proper fences: vertical post + 2 horizontal rails
      const fenceWoodMat = new THREE.MeshLambertMaterial({ color: 0xC4A05A });
      const fenceWoodDarkMat = new THREE.MeshLambertMaterial({ color: 0xA08040 });
      const postGeo = new THREE.BoxGeometry(0.2, 1.0, 0.2);
      const railGeoX = new THREE.BoxGeometry(1.0, 0.12, 0.1);
      const railGeoZ = new THREE.BoxGeometry(0.1, 0.12, 1.0);

      for (let i = 0; i < count; i++) {
        const fx = coords[i * 3], fy = coords[i * 3 + 1], fz = coords[i * 3 + 2];
        const fenceGroup = new THREE.Group();

        // Vertical post
        const post = new THREE.Mesh(postGeo, fenceWoodMat);
        post.position.y = 0.5;
        post.castShadow = true;
        fenceGroup.add(post);

        // Check neighbors for rail direction
        const hasLeft = getBlock(fx - 1, fy, fz) === BLOCK_TYPES.FENCE;
        const hasRight = getBlock(fx + 1, fy, fz) === BLOCK_TYPES.FENCE;
        const hasFront = getBlock(fx, fy, fz + 1) === BLOCK_TYPES.FENCE;
        const hasBack = getBlock(fx, fy, fz - 1) === BLOCK_TYPES.FENCE;

        // X-axis rails — no castShadow on rails for perf
        if (hasLeft || hasRight) {
          const rail1 = new THREE.Mesh(railGeoX, fenceWoodDarkMat);
          rail1.position.set(0, 0.7, 0);
          fenceGroup.add(rail1);
          const rail2 = new THREE.Mesh(railGeoX, fenceWoodDarkMat);
          rail2.position.set(0, 0.35, 0);
          fenceGroup.add(rail2);
        }
        // Z-axis rails
        if (hasFront || hasBack) {
          const rail1 = new THREE.Mesh(railGeoZ, fenceWoodDarkMat);
          rail1.position.set(0, 0.7, 0);
          fenceGroup.add(rail1);
          const rail2 = new THREE.Mesh(railGeoZ, fenceWoodDarkMat);
          rail2.position.set(0, 0.35, 0);
          fenceGroup.add(rail2);
        }
        // If isolated, add rails in both directions
        if (!hasLeft && !hasRight && !hasFront && !hasBack) {
          const rail1 = new THREE.Mesh(railGeoX, fenceWoodDarkMat);
          rail1.position.set(0, 0.7, 0);
          fenceGroup.add(rail1);
          const rail2 = new THREE.Mesh(railGeoX, fenceWoodDarkMat);
          rail2.position.set(0, 0.35, 0);
          fenceGroup.add(rail2);
        }

        fenceGroup.position.set(fx + 0.5, fy, fz + 0.5);
        blockMeshes.add(fenceGroup);
      }
      totalRendered += count;
      continue;
    } else if (type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED) {
      // Build proper voxel flowers: stem + 4 petals + center
      const flowerColor = type === BLOCK_TYPES.FLOWER_WHITE ? 0xffffff : 0xff4444;
      const stemMat = new THREE.MeshLambertMaterial({ color: 0x3D7A1E });
      const petalMat = new THREE.MeshLambertMaterial({ color: flowerColor });
      const centerMat = new THREE.MeshLambertMaterial({ color: 0xFFDD00 });
      const petalSize = 0.18;
      const centerSize = 0.16;
      const stemGeo = new THREE.BoxGeometry(0.05, 0.3, 0.05);
      const petalGeo = new THREE.BoxGeometry(petalSize, petalSize, petalSize);
      const centerGeo = new THREE.BoxGeometry(centerSize, centerSize, centerSize);

      for (let i = 0; i < count; i++) {
        const fx = coords[i * 3], fy = coords[i * 3 + 1], fz = coords[i * 3 + 2];
        const flowerGroup = new THREE.Group();
        // Stem — no castShadow on tiny flowers for perf
        const stem = new THREE.Mesh(stemGeo, stemMat);
        stem.position.y = 0.2;
        flowerGroup.add(stem);
        // 4 petals around center
        const pOff = 0.14;
        const pH = 0.48;
        for (const [px, pz] of [[pOff, 0], [-pOff, 0], [0, pOff], [0, -pOff]]) {
          const petal = new THREE.Mesh(petalGeo, petalMat);
          petal.position.set(px, pH, pz);
          flowerGroup.add(petal);
        }
        // Yellow center
        const center = new THREE.Mesh(centerGeo, centerMat);
        center.position.set(0, pH, 0);
        flowerGroup.add(center);

        flowerGroup.position.set(fx + 0.5, fy, fz + 0.5);
        blockMeshes.add(flowerGroup);
      }
      totalRendered += count;
      continue;
    } else {
      const mats = blockMaterials[type];
      mat = Array.isArray(mats) ? mats : mats;
    }
    if (!mat) continue;

    const im = new THREE.InstancedMesh(geo, mat, count);
    im.receiveShadow = true;
    im.castShadow = true;

    for (let i = 0; i < count; i++) {
      const x = coords[i * 3], y = coords[i * 3 + 1], z = coords[i * 3 + 2];
      dummy.position.set(x + 0.5, y + 0.5, z + 0.5);
      dummy.updateMatrix();
      im.setMatrixAt(i, dummy.matrix);
    }
    im.instanceMatrix.needsUpdate = true;
    if (type === BLOCK_TYPES.WATER || type === BLOCK_TYPES.LEAVES) {
      im.renderOrder = 1;
    }
    blockMeshes.add(im);
    instancedMeshes[type] = im;
    totalRendered += count;
  }
  console.log('World built! Blocks:', totalRendered);
}

let needsRebuild = false;
let rebuildTimer = null;
function rebuildNearby() { needsRebuild = true; }

// ============================================
// DIRTY-REGION REBUILD SYSTEM (Option A)
// ============================================
// Instead of rebuilding the entire world, only rebuild a small cube around the edit.
// We track pending dirty blocks and batch-rebuild only affected regions.
const dirtyRegions = []; // Array of {x, y, z} edit centers

function markDirty(x, y, z) {
  dirtyRegions.push({ x, y, z });
}

// Collect visible blocks ONLY within a bounding box
function collectVisibleBlocksInRegion(minX, minY, minZ, maxX, maxY, maxZ) {
  const buckets = {};
  for (let z = minZ; z <= maxZ; z++) {
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        if (x < 0 || x >= WORLD_SIZE || y < 0 || y >= WORLD_HEIGHT || z < 0 || z >= WORLD_SIZE) continue;
        if (shouldRenderBlock(x, y, z)) {
          const type = getBlock(x, y, z);
          if (!buckets[type]) buckets[type] = [];
          buckets[type].push(x, y, z);
        }
      }
    }
  }
  return buckets;
}

// For each InstancedMesh, we need to be able to remove instances in a region and add new ones.
// Strategy: store per-type coordinate arrays alongside the InstancedMesh, 
// then splice out old region entries, add new ones, and rebuild just that InstancedMesh.

const instanceData = {}; // type -> { coords: [x,y,z, x,y,z, ...], mesh: InstancedMesh, capacity: number }
const fenceGroups = []; // { x, y, z, group } for individual fence groups
const flowerGroups = []; // { x, y, z, group } for individual flower groups

function buildInstancedMeshesTracked() {
  // Full rebuild but also populates instanceData for future partial updates
  while (blockMeshes.children.length) {
    const c = blockMeshes.children[0];
    blockMeshes.remove(c);
  }
  for (const k of Object.keys(instancedMeshes)) delete instancedMeshes[k];
  for (const k of Object.keys(instanceData)) delete instanceData[k];
  fenceGroups.length = 0;
  flowerGroups.length = 0;

  const buckets = collectVisibleBlocks();
  let totalRendered = 0;

  for (const typeStr of Object.keys(buckets)) {
    const type = parseInt(typeStr);
    const coords = buckets[type];
    const count = coords.length / 3;
    if (count === 0) continue;

    if (type === BLOCK_TYPES.WATER) {
      const waterMesh = buildWaterMesh(coords, count);
      if (waterMesh) {
        blockMeshes.add(waterMesh);
        instancedMeshes[type] = waterMesh;
        instanceData[type] = { coords: Array.from(coords), mesh: waterMesh, capacity: count };
      }
      totalRendered += count;
      continue;
    } else if (type === BLOCK_TYPES.FENCE) {
      buildFencesFromCoords(coords, count);
      totalRendered += count;
      continue;
    } else if (type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED) {
      buildFlowersFromCoords(coords, count, type);
      totalRendered += count;
      continue;
    }

    const mats = blockMaterials[type];
    if (!mats) continue;

    const capacity = count + INSTANCE_CAPACITY_MARGIN;
    const im = new THREE.InstancedMesh(blockGeometry, mats, capacity);
    im.count = count;
    im.receiveShadow = true;
    im.castShadow = true;

    for (let i = 0; i < count; i++) {
      dummy.position.set(coords[i * 3] + 0.5, coords[i * 3 + 1] + 0.5, coords[i * 3 + 2] + 0.5);
      dummy.updateMatrix();
      im.setMatrixAt(i, dummy.matrix);
    }
    im.instanceMatrix.needsUpdate = true;
    if (type === BLOCK_TYPES.WATER || type === BLOCK_TYPES.LEAVES) im.renderOrder = 1;
    blockMeshes.add(im);
    instancedMeshes[type] = im;
    // Store coords for partial rebuild with capacity for fast future appends
    instanceData[type] = { coords: Array.from(coords), mesh: im, capacity: capacity };
    totalRendered += count;
  }
  console.log('World built (tracked)! Blocks:', totalRendered);
}

// Build fence groups from coords array
function buildFencesFromCoords(coords, count) {
  const fenceWoodMat = new THREE.MeshLambertMaterial({ color: 0xC4A05A });
  const fenceWoodDarkMat = new THREE.MeshLambertMaterial({ color: 0xA08040 });
  const postGeo = new THREE.BoxGeometry(0.2, 1.0, 0.2);
  const railGeoX = new THREE.BoxGeometry(1.0, 0.12, 0.1);
  const railGeoZ = new THREE.BoxGeometry(0.1, 0.12, 1.0);

  for (let i = 0; i < count; i++) {
    const fx = coords[i * 3], fy = coords[i * 3 + 1], fz = coords[i * 3 + 2];
    const fenceGroup = new THREE.Group();
    const post = new THREE.Mesh(postGeo, fenceWoodMat);
    post.position.y = 0.5;
    fenceGroup.add(post);

    const hasLeft = getBlock(fx - 1, fy, fz) === BLOCK_TYPES.FENCE;
    const hasRight = getBlock(fx + 1, fy, fz) === BLOCK_TYPES.FENCE;
    const hasFront = getBlock(fx, fy, fz + 1) === BLOCK_TYPES.FENCE;
    const hasBack = getBlock(fx, fy, fz - 1) === BLOCK_TYPES.FENCE;

    if (hasLeft || hasRight) {
      const r1 = new THREE.Mesh(railGeoX, fenceWoodDarkMat); r1.position.set(0, 0.7, 0); fenceGroup.add(r1);
      const r2 = new THREE.Mesh(railGeoX, fenceWoodDarkMat); r2.position.set(0, 0.35, 0); fenceGroup.add(r2);
    }
    if (hasFront || hasBack) {
      const r1 = new THREE.Mesh(railGeoZ, fenceWoodDarkMat); r1.position.set(0, 0.7, 0); fenceGroup.add(r1);
      const r2 = new THREE.Mesh(railGeoZ, fenceWoodDarkMat); r2.position.set(0, 0.35, 0); fenceGroup.add(r2);
    }
    if (!hasLeft && !hasRight && !hasFront && !hasBack) {
      const r1 = new THREE.Mesh(railGeoX, fenceWoodDarkMat); r1.position.set(0, 0.7, 0); fenceGroup.add(r1);
      const r2 = new THREE.Mesh(railGeoX, fenceWoodDarkMat); r2.position.set(0, 0.35, 0); fenceGroup.add(r2);
    }

    fenceGroup.position.set(fx + 0.5, fy, fz + 0.5);
    fenceGroup.name = `fence_${fx}_${fy}_${fz}`;
    blockMeshes.add(fenceGroup);
    fenceGroups.push({ x: fx, y: fy, z: fz, group: fenceGroup });
  }
}

// Build flower groups from coords array
function buildFlowersFromCoords(coords, count, type) {
  const flowerColor = type === BLOCK_TYPES.FLOWER_WHITE ? 0xffffff : 0xff4444;
  const stemMat = new THREE.MeshLambertMaterial({ color: 0x3D7A1E });
  const petalMat = new THREE.MeshLambertMaterial({ color: flowerColor });
  const centerMat = new THREE.MeshLambertMaterial({ color: 0xFFDD00 });
  const stemGeo = new THREE.BoxGeometry(0.05, 0.3, 0.05);
  const petalGeo = new THREE.BoxGeometry(0.18, 0.18, 0.18);
  const centerGeo = new THREE.BoxGeometry(0.16, 0.16, 0.16);

  for (let i = 0; i < count; i++) {
    const fx = coords[i * 3], fy = coords[i * 3 + 1], fz = coords[i * 3 + 2];
    const flowerGroup = new THREE.Group();
    // No castShadow on flowers — tiny objects, saves many shadow draw calls
    const stem = new THREE.Mesh(stemGeo, stemMat); stem.position.y = 0.2; flowerGroup.add(stem);
    const pOff = 0.14, pH = 0.48;
    for (const [px, pz] of [[pOff, 0], [-pOff, 0], [0, pOff], [0, -pOff]]) {
      const petal = new THREE.Mesh(petalGeo, petalMat); petal.position.set(px, pH, pz); flowerGroup.add(petal);
    }
    const center = new THREE.Mesh(centerGeo, centerMat); center.position.set(0, pH, 0); flowerGroup.add(center);

    flowerGroup.position.set(fx + 0.5, fy, fz + 0.5);
    flowerGroup.name = `flower_${fx}_${fy}_${fz}`;
    blockMeshes.add(flowerGroup);
    flowerGroups.push({ x: fx, y: fy, z: fz, group: flowerGroup });
  }
}

// PARTIAL REBUILD — only the region around an edit
// Optimized: reuses existing InstancedMesh with over-allocated capacity when possible
// to avoid destroying and recreating the GPU buffer on every single block placement.
const INSTANCE_CAPACITY_MARGIN = 128; // extra slots to pre-allocate

function rebuildDirtyRegions() {
  if (dirtyRegions.length === 0) return;

  // Compute bounding box of all dirty edits, padded by 1 (neighbors may change visibility)
  let rMinX = WORLD_SIZE, rMinY = WORLD_HEIGHT, rMinZ = WORLD_SIZE;
  let rMaxX = 0, rMaxY = 0, rMaxZ = 0;
  for (const d of dirtyRegions) {
    rMinX = Math.min(rMinX, d.x - 1);
    rMinY = Math.min(rMinY, d.y - 1);
    rMinZ = Math.min(rMinZ, d.z - 1);
    rMaxX = Math.max(rMaxX, d.x + 1);
    rMaxY = Math.max(rMaxY, d.y + 1);
    rMaxZ = Math.max(rMaxZ, d.z + 1);
  }
  rMinX = Math.max(0, rMinX); rMinY = Math.max(0, rMinY); rMinZ = Math.max(0, rMinZ);
  rMaxX = Math.min(WORLD_SIZE - 1, rMaxX); rMaxY = Math.min(WORLD_HEIGHT - 1, rMaxY); rMaxZ = Math.min(WORLD_SIZE - 1, rMaxZ);
  dirtyRegions.length = 0;

  // Helper: is a coord inside the dirty region?
  function inRegion(x, y, z) {
    return x >= rMinX && x <= rMaxX && y >= rMinY && y <= rMaxY && z >= rMinZ && z <= rMaxZ;
  }

  // Collect new visible blocks in the dirty region
  const newBuckets = collectVisibleBlocksInRegion(rMinX, rMinY, rMinZ, rMaxX, rMaxY, rMaxZ);

  // For each block type that uses InstancedMesh, remove old entries in region, add new ones
  const allTypes = new Set([
    ...Object.keys(instanceData).map(Number),
    ...Object.keys(newBuckets).map(Number)
  ]);

  for (const type of allTypes) {
    if (type === BLOCK_TYPES.FENCE || type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED) {
      continue; // Handle separately below
    }

    const oldData = instanceData[type];
    const newCoords = newBuckets[type] || [];

    // Filter out old coords that are inside the dirty region
    let keptCoords = [];
    if (oldData) {
      const oc = oldData.coords;
      for (let i = 0; i < oc.length; i += 3) {
        if (!inRegion(oc[i], oc[i + 1], oc[i + 2])) {
          keptCoords.push(oc[i], oc[i + 1], oc[i + 2]);
        }
      }
    }

    // Append new coords from dirty region
    for (let i = 0; i < newCoords.length; i++) {
      keptCoords.push(newCoords[i]);
    }

    const totalCount = keptCoords.length / 3;

    if (totalCount === 0) {
      if (oldData && oldData.mesh) {
        blockMeshes.remove(oldData.mesh);
        if (oldData.mesh.geometry) oldData.mesh.geometry.dispose();
        if (oldData.mesh.dispose) oldData.mesh.dispose();
      }
      delete instanceData[type];
      delete instancedMeshes[type];
      continue;
    }

    // Water uses merged geometry — always full rebuild
    if (type === BLOCK_TYPES.WATER) {
      if (oldData && oldData.mesh) {
        blockMeshes.remove(oldData.mesh);
        if (oldData.mesh.geometry) oldData.mesh.geometry.dispose();
      }
      const waterMesh = buildWaterMesh(keptCoords, totalCount);
      if (waterMesh) {
        blockMeshes.add(waterMesh);
        instancedMeshes[type] = waterMesh;
        instanceData[type] = { coords: keptCoords, mesh: waterMesh, capacity: totalCount };
      }
      continue;
    }

    const mats = blockMaterials[type];
    if (!mats) continue;

    // Check if we can reuse the existing InstancedMesh (same type, enough capacity)
    const existingCapacity = oldData ? (oldData.capacity || 0) : 0;
    let im;

    if (oldData && oldData.mesh && existingCapacity >= totalCount) {
      // FAST PATH: reuse existing InstancedMesh — just update instance matrices in-place
      im = oldData.mesh;
      im.count = totalCount;

      for (let i = 0; i < totalCount; i++) {
        dummy.position.set(keptCoords[i * 3] + 0.5, keptCoords[i * 3 + 1] + 0.5, keptCoords[i * 3 + 2] + 0.5);
        dummy.updateMatrix();
        im.setMatrixAt(i, dummy.matrix);
      }
      im.instanceMatrix.needsUpdate = true;

      instanceData[type] = { coords: keptCoords, mesh: im, capacity: existingCapacity };
    } else {
      // SLOW PATH: need a new InstancedMesh (first time or capacity exceeded)
      if (oldData && oldData.mesh) {
        blockMeshes.remove(oldData.mesh);
        if (oldData.mesh.geometry) oldData.mesh.geometry.dispose();
        if (oldData.mesh.dispose) oldData.mesh.dispose();
      }

      const capacity = totalCount + INSTANCE_CAPACITY_MARGIN;
      im = new THREE.InstancedMesh(blockGeometry, mats, capacity);
      im.count = totalCount;
      im.receiveShadow = true;
      im.castShadow = true;

      for (let i = 0; i < totalCount; i++) {
        dummy.position.set(keptCoords[i * 3] + 0.5, keptCoords[i * 3 + 1] + 0.5, keptCoords[i * 3 + 2] + 0.5);
        dummy.updateMatrix();
        im.setMatrixAt(i, dummy.matrix);
      }
      im.instanceMatrix.needsUpdate = true;
      if (type === BLOCK_TYPES.LEAVES) im.renderOrder = 1;
      blockMeshes.add(im);

      instancedMeshes[type] = im;
      instanceData[type] = { coords: keptCoords, mesh: im, capacity: capacity };
    }
  }

  // Handle fences in dirty region: remove old, add new
  for (let i = fenceGroups.length - 1; i >= 0; i--) {
    const f = fenceGroups[i];
    if (inRegion(f.x, f.y, f.z)) {
      blockMeshes.remove(f.group);
      fenceGroups.splice(i, 1);
    }
  }
  if (newBuckets[BLOCK_TYPES.FENCE]) {
    const fc = newBuckets[BLOCK_TYPES.FENCE];
    buildFencesFromCoords(fc, fc.length / 3);
  }

  // Handle flowers in dirty region: remove old, add new
  for (let i = flowerGroups.length - 1; i >= 0; i--) {
    const f = flowerGroups[i];
    if (inRegion(f.x, f.y, f.z)) {
      blockMeshes.remove(f.group);
      flowerGroups.splice(i, 1);
    }
  }
  for (const flType of [BLOCK_TYPES.FLOWER_WHITE, BLOCK_TYPES.FLOWER_RED]) {
    if (newBuckets[flType]) {
      const fc = newBuckets[flType];
      buildFlowersFromCoords(fc, fc.length / 3, flType);
    }
  }

  clearTempBlocks();
}

// Instant single-block mesh add/remove for zero-latency feedback
const tempBlockGroup = new THREE.Group();
tempBlockGroup.name = 'tempBlocks';
scene.add(tempBlockGroup);

// Pre-cached materials/geometry for temp blocks to avoid allocations on each placement
const _tempFenceMat = new THREE.MeshLambertMaterial({ map: fenceTex });
const _tempFlowerGeo = new THREE.BoxGeometry(0.4, 0.4, 0.4);
const _tempFlowerRedMat = new THREE.MeshLambertMaterial({ color: 0xff4444 });
const _tempFlowerWhiteMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
const _tempFallbackMat = new THREE.MeshLambertMaterial({ color: 0xcccccc });

function addTempBlock(x, y, z, type) {
  let geo = blockGeometry;
  let mat;
  if (type === BLOCK_TYPES.FENCE) {
    geo = fenceGeometry;
    mat = _tempFenceMat;
  } else if (type === BLOCK_TYPES.FLOWER_WHITE || type === BLOCK_TYPES.FLOWER_RED) {
    geo = _tempFlowerGeo;
    mat = type === BLOCK_TYPES.FLOWER_RED ? _tempFlowerRedMat : _tempFlowerWhiteMat;
  } else {
    const mats = blockMaterials[type];
    mat = mats || _tempFallbackMat;
  }
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
  mesh.castShadow = false;
  mesh.receiveShadow = false;
  mesh.name = `temp_${x}_${y}_${z}`;
  tempBlockGroup.add(mesh);
  return mesh;
}

function removeTempBlock(x, y, z) {
  const name = `temp_${x}_${y}_${z}`;
  for (let i = tempBlockGroup.children.length - 1; i >= 0; i--) {
    if (tempBlockGroup.children[i].name === name) {
      tempBlockGroup.remove(tempBlockGroup.children[i]);
      return;
    }
  }
}

function clearTempBlocks() {
  // Just remove children — geometry and materials are shared/cached, don't dispose them
  while (tempBlockGroup.children.length) {
    tempBlockGroup.remove(tempBlockGroup.children[0]);
  }
}

// Fast rebuild — runs on next frame via dirty region system
let rebuildQueued = false;
function scheduleRebuild() {
  if (rebuildQueued) return;
  rebuildQueued = true;
  requestAnimationFrame(() => {
    rebuildQueued = false;
    rebuildDirtyRegions();
  });
}

// Rebuild only the grass meshes (for color picker updates)
function rebuildGrassMeshes() {
  buildInstancedMeshesTracked();
}

// Validate all fences have a solid block underneath — fill entire column down to ISLAND_BASE
for (let z = 0; z < WORLD_SIZE; z++) {
  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let y = 1; y < WORLD_HEIGHT; y++) {
      if (getBlock(x, y, z) === BLOCK_TYPES.FENCE) {
        // Ensure every block from fence-1 down to ISLAND_BASE is solid
        for (let fy = y - 1; fy >= ISLAND_BASE - 3; fy--) {
          const b = getBlock(x, fy, z);
          if (b === BLOCK_TYPES.AIR || b === BLOCK_TYPES.WATER ||
              b === BLOCK_TYPES.FLOWER_WHITE || b === BLOCK_TYPES.FLOWER_RED) {
            if (fy === y - 1) {
              setBlock(x, fy, z, BLOCK_TYPES.GRASS);
            } else if (fy > y - 4) {
              setBlock(x, fy, z, BLOCK_TYPES.DIRT);
            } else {
              setBlock(x, fy, z, BLOCK_TYPES.STONE);
            }
          } else {
            break; // hit existing solid block, stop filling
          }
        }
        // Update height map
        if (y - 1 > getHeightCPU(x, z)) {
          heightCPU[x + z * WORLD_SIZE] = y - 1;
        }
      }
    }
  }
}

console.log('Building world meshes...');
buildInstancedMeshesTracked();

// ============================================
// LIGHTING — brighter, more vibrant
// ============================================
const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
scene.add(ambientLight);

const sunLight = new THREE.DirectionalLight(0xfff8e0, 1.2);
sunLight.position.set(60, 100, 60);
sunLight.castShadow = true;
sunLight.shadow.camera.left = -35;
sunLight.shadow.camera.right = 35;
sunLight.shadow.camera.top = 35;
sunLight.shadow.camera.bottom = -35;
sunLight.shadow.camera.near = 1;
sunLight.shadow.camera.far = 180;
sunLight.shadow.mapSize.width = 1024;
sunLight.shadow.mapSize.height = 1024;
sunLight.shadow.bias = -0.0005;
sunLight.shadow.normalBias = 0.02;
scene.add(sunLight);

const hemiLight = new THREE.HemisphereLight(0x87CEEB, 0x07a60c, 0.5);
scene.add(hemiLight);

// ============================================
// PLAYER CHARACTER — Skeleton Rigged Minecraft Style
// ============================================
const playerGroup = new THREE.Group();
playerGroup.name = 'playerCharacter';
scene.add(playerGroup);

let playerModelReady = false;

// Skeleton bone references
let bonePelvis, boneChest, boneHead;
let boneLeftUpperArm, boneLeftLowerArm;
let boneRightUpperArm, boneRightLowerArm;
let boneLeftUpperLeg, boneLeftLowerLeg;
let boneRightUpperLeg, boneRightLowerLeg;

// Load GLB model for textures, then build rigged character
// Extract materials/textures from the GLB model
let glbMaterial = null;

function buildSkinnedPlayer(baseMat) {
  // Minecraft proportions (in blocks): head 0.5, body 0.75h, arms 0.75h, legs 0.75h
  // Total height ~1.8 blocks
  const pixelScale = 1.0 / 16.0; // 1 pixel = 1/16 block

  // --- SKELETON (Bone Hierarchy) ---
  // Root bone at feet level
  const rootBone = new THREE.Bone();
  rootBone.name = 'root';
  rootBone.position.set(0, 0, 0);

  // Pelvis — center of body, at hip height
  bonePelvis = new THREE.Bone();
  bonePelvis.name = 'pelvis';
  bonePelvis.position.set(0, 0.75, 0); // hip height
  rootBone.add(bonePelvis);

  // Chest — upper body
  boneChest = new THREE.Bone();
  boneChest.name = 'chest';
  boneChest.position.set(0, 0.45, 0); // above pelvis
  bonePelvis.add(boneChest);

  // Head — sits directly on top of chest/torso
  boneHead = new THREE.Bone();
  boneHead.name = 'head';
  boneHead.position.set(0, 0.05, 0);
  boneChest.add(boneHead);

  // Left arm (attached to chest)
  boneLeftUpperArm = new THREE.Bone();
  boneLeftUpperArm.name = 'leftUpperArm';
  boneLeftUpperArm.position.set(-0.35, 0.05, 0);
  boneChest.add(boneLeftUpperArm);

  boneLeftLowerArm = new THREE.Bone();
  boneLeftLowerArm.name = 'leftLowerArm';
  boneLeftLowerArm.position.set(0, -0.35, 0);
  boneLeftUpperArm.add(boneLeftLowerArm);

  // Right arm
  boneRightUpperArm = new THREE.Bone();
  boneRightUpperArm.name = 'rightUpperArm';
  boneRightUpperArm.position.set(0.35, 0.05, 0);
  boneChest.add(boneRightUpperArm);

  boneRightLowerArm = new THREE.Bone();
  boneRightLowerArm.name = 'rightLowerArm';
  boneRightLowerArm.position.set(0, -0.35, 0);
  boneRightUpperArm.add(boneRightLowerArm);

  // Left leg (attached to pelvis)
  boneLeftUpperLeg = new THREE.Bone();
  boneLeftUpperLeg.name = 'leftUpperLeg';
  boneLeftUpperLeg.position.set(-0.12, 0, 0);
  bonePelvis.add(boneLeftUpperLeg);

  boneLeftLowerLeg = new THREE.Bone();
  boneLeftLowerLeg.name = 'leftLowerLeg';
  boneLeftLowerLeg.position.set(0, -0.375, 0);
  boneLeftUpperLeg.add(boneLeftLowerLeg);

  // Right leg
  boneRightUpperLeg = new THREE.Bone();
  boneRightUpperLeg.name = 'rightUpperLeg';
  boneRightUpperLeg.position.set(0.12, 0, 0);
  bonePelvis.add(boneRightUpperLeg);

  boneRightLowerLeg = new THREE.Bone();
  boneRightLowerLeg.name = 'rightLowerLeg';
  boneRightLowerLeg.position.set(0, -0.375, 0);
  boneRightUpperLeg.add(boneRightLowerLeg);

  const skeleton = new THREE.Skeleton([
    rootBone, bonePelvis, boneChest, boneHead,
    boneLeftUpperArm, boneLeftLowerArm,
    boneRightUpperArm, boneRightLowerArm,
    boneLeftUpperLeg, boneLeftLowerLeg,
    boneRightUpperLeg, boneRightLowerLeg
  ]);

  // --- MATERIALS ---
  const skinColor = new THREE.Color(0x8B5E3C);
  const shirtColor = new THREE.Color(0x4A90D9); // blue shirt
  const pantsColor = new THREE.Color(0x3B3B6D); // dark blue pants
  const shoeColor = new THREE.Color(0x555555);
  const hairColor = new THREE.Color(0x4A2E14);

  const skinMat = new THREE.MeshLambertMaterial({ color: skinColor });
  const shirtMat = new THREE.MeshLambertMaterial({ color: shirtColor });
  const pantsMat = new THREE.MeshLambertMaterial({ color: pantsColor });
  const shoeMat = new THREE.MeshLambertMaterial({ color: shoeColor });
  const hairMat = new THREE.MeshLambertMaterial({ color: hairColor });

  // --- HELPER: create a skinned box attached to a single bone ---
  function createSkinnedBox(w, h, d, material, boneIndex, offsetY) {
    const geom = new THREE.BoxGeometry(w, h, d);
    // Shift vertices so pivot is at the top of the box
    geom.translate(0, offsetY, 0);

    // Skinning attributes: all vertices bound to one bone
    const vertexCount = geom.attributes.position.count;
    const skinIndices = new Float32Array(vertexCount * 4);
    const skinWeights = new Float32Array(vertexCount * 4);
    for (let i = 0; i < vertexCount; i++) {
      skinIndices[i * 4] = boneIndex;
      skinIndices[i * 4 + 1] = 0;
      skinIndices[i * 4 + 2] = 0;
      skinIndices[i * 4 + 3] = 0;
      skinWeights[i * 4] = 1.0;
      skinWeights[i * 4 + 1] = 0;
      skinWeights[i * 4 + 2] = 0;
      skinWeights[i * 4 + 3] = 0;
    }
    geom.setAttribute('skinIndex', new THREE.BufferAttribute(new Uint16Array(skinIndices), 4));
    geom.setAttribute('skinWeight', new THREE.BufferAttribute(skinWeights, 4));

    const mesh = new THREE.SkinnedMesh(geom, material);
    mesh.castShadow = true;
    mesh.receiveShadow = false;
    mesh.frustumCulled = false;
    return mesh;
  }

  // Bone indices (matching skeleton array order):
  // 0=root, 1=pelvis, 2=chest, 3=head
  // 4=leftUpperArm, 5=leftLowerArm
  // 6=rightUpperArm, 7=rightLowerArm
  // 8=leftUpperLeg, 9=leftLowerLeg
  // 10=rightUpperLeg, 11=rightLowerLeg

  // Head (0.5 x 0.5 x 0.5) — pivot at bottom (neck)
  const headMesh = createSkinnedBox(0.5, 0.5, 0.5, skinMat, 3, 0.25);
  headMesh.name = 'playerHead';

  // Hair on top of head
  const hairMesh = createSkinnedBox(0.52, 0.15, 0.52, hairMat, 3, 0.5);
  hairMesh.name = 'playerHair';

  // Eyes (two tiny dark boxes — polygon offset to eliminate z-fighting)
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x222222, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  const leftEyeMesh = createSkinnedBox(0.08, 0.08, 0.06, eyeMat, 3, 0.3);
  leftEyeMesh.name = 'playerLeftEye';
  const rightEyeMesh = createSkinnedBox(0.08, 0.08, 0.06, eyeMat, 3, 0.3);
  rightEyeMesh.name = 'playerRightEye';

  // Nose (small protruding box on front of face)
  const noseMat = new THREE.MeshLambertMaterial({ color: skinColor.clone().multiplyScalar(0.9) });
  const noseMesh = createSkinnedBox(0.06, 0.08, 0.06, noseMat, 3, 0.22);
  noseMesh.name = 'playerNose';

  // Mouth (wide flat dark box below nose)
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x8B4040 });
  const mouthMesh = createSkinnedBox(0.14, 0.03, 0.04, mouthMat, 3, 0.13);
  mouthMesh.name = 'playerMouth';

  // Body / torso (0.5 x 0.7 x 0.25) — pivot at top (chest bone)
  const bodyMesh = createSkinnedBox(0.5, 0.7, 0.25, shirtMat, 2, -0.35);
  bodyMesh.name = 'playerBody';

  // Left upper arm (0.22 x 0.35 x 0.22) — pivot at top (shoulder)
  const leftUpperArmMesh = createSkinnedBox(0.22, 0.35, 0.22, shirtMat, 4, -0.175);
  leftUpperArmMesh.name = 'playerLeftUpperArm';

  // Left lower arm (0.2 x 0.35 x 0.2) — pivot at top (elbow)
  const leftLowerArmMesh = createSkinnedBox(0.2, 0.35, 0.2, skinMat, 5, -0.175);
  leftLowerArmMesh.name = 'playerLeftLowerArm';

  // Right upper arm
  const rightUpperArmMesh = createSkinnedBox(0.22, 0.35, 0.22, shirtMat, 6, -0.175);
  rightUpperArmMesh.name = 'playerRightUpperArm';

  // Right lower arm
  const rightLowerArmMesh = createSkinnedBox(0.2, 0.35, 0.2, skinMat, 7, -0.175);
  rightLowerArmMesh.name = 'playerRightLowerArm';

  // Left upper leg (0.22 x 0.375 x 0.22) — pivot at top (hip)
  const leftUpperLegMesh = createSkinnedBox(0.22, 0.375, 0.22, pantsMat, 8, -0.19);
  leftUpperLegMesh.name = 'playerLeftUpperLeg';

  // Left lower leg (0.22 x 0.375 x 0.22) — pivot at top (knee)
  const leftLowerLegMesh = createSkinnedBox(0.22, 0.375, 0.22, shoeMat, 9, -0.19);
  leftLowerLegMesh.name = 'playerLeftLowerLeg';

  // Right upper leg
  const rightUpperLegMesh = createSkinnedBox(0.22, 0.375, 0.22, pantsMat, 10, -0.19);
  rightUpperLegMesh.name = 'playerRightUpperLeg';

  // Right lower leg
  const rightLowerLegMesh = createSkinnedBox(0.22, 0.375, 0.22, shoeMat, 11, -0.19);
  rightLowerLegMesh.name = 'playerRightLowerLeg';

  // Assemble all skinned meshes
  const allParts = [
    headMesh, hairMesh, leftEyeMesh, rightEyeMesh,
    noseMesh, mouthMesh,
    bodyMesh,
    leftUpperArmMesh, leftLowerArmMesh,
    rightUpperArmMesh, rightLowerArmMesh,
    leftUpperLegMesh, leftLowerLegMesh,
    rightUpperLegMesh, rightLowerLegMesh
  ];

  // Create the skinned group
  const skinnedGroup = new THREE.Group();
  skinnedGroup.name = 'skinnedPlayer';
  skinnedGroup.add(rootBone);

  allParts.forEach(mesh => {
    skinnedGroup.add(mesh);
    mesh.bind(skeleton);
  });

  // Offset eyes to front of face (pushed out further to prevent z-fighting)
  leftEyeMesh.geometry.translate(-0.1, 0, 0.26);
  rightEyeMesh.geometry.translate(0.1, 0, 0.26);

  // Nose — centered, sticks out from face
  noseMesh.geometry.translate(0, 0, 0.28);

  // Mouth — centered below nose
  mouthMesh.geometry.translate(0, 0, 0.26);

  playerGroup.add(skinnedGroup);
  playerModelReady = true;

  return skeleton;
}

// Use the original procedural character; no remote colour-reference model is required.
let playerSkeleton = buildSkinnedPlayer(null);

// ============================================
// WALKING DUST PARTICLES
// ============================================
const DUST_MAX = 3;
// Create soft round cloud texture via canvas
const dustCanvas = document.createElement('canvas');
dustCanvas.width = 64;
dustCanvas.height = 64;
const dustCtx = dustCanvas.getContext('2d');
const dustGrad = dustCtx.createRadialGradient(32, 32, 0, 32, 32, 32);
dustGrad.addColorStop(0, 'rgba(255,255,255,0.7)');
dustGrad.addColorStop(0.3, 'rgba(255,255,255,0.45)');
dustGrad.addColorStop(0.6, 'rgba(255,255,255,0.15)');
dustGrad.addColorStop(1, 'rgba(255,255,255,0)');
dustCtx.fillStyle = dustGrad;
dustCtx.fillRect(0, 0, 64, 64);
const dustTexture = new THREE.CanvasTexture(dustCanvas);

const dustPool = [];
for (let i = 0; i < DUST_MAX; i++) {
  const spriteMat = new THREE.SpriteMaterial({
    map: dustTexture,
    transparent: true,
    opacity: 0.5,
    depthWrite: false
  });
  const s = new THREE.Sprite(spriteMat);
  s.visible = false;
  s.name = 'dustParticle_' + i;
  s.scale.set(0.4, 0.4, 0.4);
  scene.add(s);
  dustPool.push(s);
}
let dustTimer = 0;

function spawnDust(px, py, pz) {
  let p = null;
  for (let i = 0; i < dustPool.length; i++) {
    if (!dustPool[i].visible) { p = dustPool[i]; break; }
  }
  if (!p) return;
  p.position.set(
    px + (Math.random() - 0.5) * 0.3,
    py + 0.05,
    pz + (Math.random() - 0.5) * 0.3
  );
  const baseSize = 0.4 + Math.random() * 0.25;
  p.scale.set(baseSize, baseSize, baseSize);
  p.material.opacity = 0.4;
  p.visible = true;
  p.userData.life = 0;
  p.userData.maxLife = 0.5 + Math.random() * 0.3;
  p.userData.vy = 0.2 + Math.random() * 0.3;
  p.userData.vx = (Math.random() - 0.5) * 0.15;
  p.userData.vz = (Math.random() - 0.5) * 0.15;
}

function updateDust(dt) {
  for (let i = 0; i < dustPool.length; i++) {
    const p = dustPool[i];
    if (!p.visible) continue;
    p.userData.life += dt;
    const t = p.userData.life / p.userData.maxLife;
    if (t >= 1) { p.visible = false; continue; }
    p.position.x += p.userData.vx * dt;
    p.position.y += p.userData.vy * dt;
    p.position.z += p.userData.vz * dt;
    p.userData.vy *= 0.95;
    p.material.opacity = (1 - t * t) * 0.4;
    const grow = 0.4 + t * 0.5;
    p.scale.set(grow, grow, grow);
  }
}

// ============================================
// CUTE CREATURES (Blocky sheep/chickens)
// ============================================
const creatures = [];

function createCreature(x, z, type) {
  const group = new THREE.Group();
  const h = getHeightCPU(Math.floor(x), Math.floor(z));
  if (h < ISLAND_BASE) return null;
  if (getBlock(Math.floor(x), h, Math.floor(z)) !== BLOCK_TYPES.GRASS &&
      getBlock(Math.floor(x), h, Math.floor(z)) !== BLOCK_TYPES.PATH) return null;

  if (type === 'sheep') {
    // Body - fluffy white
    const bodyG = new THREE.BoxGeometry(0.7, 0.5, 0.9);
    const bodyM = new THREE.MeshLambertMaterial({ color: 0xF0F0F0 });
    const body = new THREE.Mesh(bodyG, bodyM);
    body.position.y = 0.45;
    body.castShadow = true;
    group.add(body);

    // Head
    const headG = new THREE.BoxGeometry(0.35, 0.35, 0.35);
    const headM = new THREE.MeshLambertMaterial({ color: 0xE8E8E8 });
    const head = new THREE.Mesh(headG, headM);
    head.position.set(0, 0.55, 0.5);
    head.castShadow = true;
    group.add(head);

    // Face
    const faceG = new THREE.BoxGeometry(0.25, 0.2, 0.1);
    const faceM = new THREE.MeshLambertMaterial({ color: 0x333333 });
    const face = new THREE.Mesh(faceG, faceM);
    face.position.set(0, 0.5, 0.68);
    group.add(face);

    // Legs (4)
    const legG = new THREE.BoxGeometry(0.12, 0.25, 0.12);
    const legM = new THREE.MeshLambertMaterial({ color: 0x888888 });
    for (const [lx, lz] of [[-0.2, -0.3], [0.2, -0.3], [-0.2, 0.3], [0.2, 0.3]]) {
      const leg = new THREE.Mesh(legG, legM);
      leg.position.set(lx, 0.125, lz);
      leg.castShadow = true;
      group.add(leg);
    }
  } else {
    // Chicken — no castShadow on small creatures for perf
    const bodyG = new THREE.BoxGeometry(0.3, 0.3, 0.4);
    const bodyM = new THREE.MeshLambertMaterial({ color: 0xF5F5F0 });
    const body = new THREE.Mesh(bodyG, bodyM);
    body.position.y = 0.3;
    group.add(body);

    // Head
    const headG = new THREE.BoxGeometry(0.2, 0.2, 0.2);
    const head = new THREE.Mesh(headG, bodyM);
    head.position.set(0, 0.5, 0.2);
    group.add(head);

    // Beak
    const beakG = new THREE.BoxGeometry(0.08, 0.06, 0.1);
    const beakM = new THREE.MeshLambertMaterial({ color: 0xE8A030 });
    const beak = new THREE.Mesh(beakG, beakM);
    beak.position.set(0, 0.47, 0.35);
    group.add(beak);

    // Wattle
    const wattleG = new THREE.BoxGeometry(0.06, 0.08, 0.04);
    const wattleM = new THREE.MeshLambertMaterial({ color: 0xDD3333 });
    const wattle = new THREE.Mesh(wattleG, wattleM);
    wattle.position.set(0, 0.42, 0.3);
    group.add(wattle);

    // Legs
    const legG = new THREE.BoxGeometry(0.05, 0.15, 0.05);
    const legM = new THREE.MeshLambertMaterial({ color: 0xE8A030 });
    const ll = new THREE.Mesh(legG, legM);
    ll.position.set(-0.08, 0.075, 0);
    group.add(ll);
    const rl = new THREE.Mesh(legG, legM);
    rl.position.set(0.08, 0.075, 0);
    group.add(rl);
  }

  group.position.set(x + 0.5, h + 1, z + 0.5);
  group.rotation.y = Math.random() * Math.PI * 2;
  scene.add(group);

  creatures.push({
    group,
    baseX: x + 0.5,
    baseZ: z + 0.5,
    wanderAngle: Math.random() * Math.PI * 2,
    wanderTimer: Math.random() * 3,
    speed: 0.3 + Math.random() * 0.3,
    type
  });
  return group;
}

// Creature spawning is deferred until after waterfall generation (see below)

// ============================================
// PLAYER STATE & THIRD-PERSON CAMERA
// ============================================
const player = {
  position: new THREE.Vector3(WORLD_SIZE / 2, 0, WORLD_SIZE / 2),
  velocity: new THREE.Vector3(0, 0, 0),
  yaw: 0,
  speed: 5,
  jumpForce: 8,
  onGround: false,
  height: 1.7,
  width: 0.3,
  walkCycle: 0,
  targetGroundY: 0,
  visualY: 0,
  jumpTime: 0,
  wasJumping: false,
  landTimer: -1
};

// Find a clear spawn point near the waterfall — deferred until after waterfall is generated
// We'll set a temporary position here and override it after waterfall generation below
let spawnX = WORLD_SIZE / 2;
let spawnZ = WORLD_SIZE / 2;
let spawnDeferred = true; // flag to re-place player after waterfall
const spawnH = getHeightCPU(Math.floor(spawnX), Math.floor(spawnZ));
player.position.set(spawnX, Math.max(spawnH + 2, SURFACE_Y + 2), spawnZ);
player.targetGroundY = Math.max(spawnH + 1, SURFACE_Y + 1);
player.visualY = player.position.y;

// Camera orbit state
let cameraDistance = 18;
let cameraAngleH = Math.PI * 0.25; // horizontal angle — will be overridden after waterfall
let cameraAngleV = 0.6; // vertical angle (radians from horizontal)
let targetCamAngleH = cameraAngleH;
let targetCamAngleV = cameraAngleV;

// ============================================
// CONTROLS
// ============================================
const keys = {};
window.addEventListener('keydown', (e) => { keys[e.code] = true; });
window.addEventListener('keyup', (e) => { keys[e.code] = false; });



// Start immediately — no splash screen
let isLocked = true;

// Mouse drag for camera rotation
let isRightDragging = false;
let isDragging = false;
let lastDragX = 0, lastDragY = 0;

renderer.domElement.addEventListener('mousedown', (e) => {
  if (e.button === 2) {
    isRightDragging = true;
    lastDragX = e.clientX;
    lastDragY = e.clientY;
    e.preventDefault();
  } else if (e.button === 1 || (e.button === 0 && e.altKey)) {
    isDragging = true;
    lastDragX = e.clientX;
    lastDragY = e.clientY;
  }
});

window.addEventListener('mouseup', (e) => {
  if (e.button === 2) isRightDragging = false;
  if (e.button === 1 || e.button === 0) isDragging = false;
});

window.addEventListener('mousemove', (e) => {
  if (!isLocked) return;
  if (isRightDragging || isDragging) {
    const dx = e.clientX - lastDragX;
    const dy = e.clientY - lastDragY;
    lastDragX = e.clientX;
    lastDragY = e.clientY;
    targetCamAngleH -= dx * 0.005;
    targetCamAngleV = Math.max(0.15, Math.min(1.2, targetCamAngleV + dy * 0.005));
    mouseDirty = true;
  }
});

window.addEventListener('wheel', (e) => {
  if (!isLocked) return;
  cameraDistance = Math.max(5, Math.min(40, cameraDistance + e.deltaY * 0.02));
});



window.addEventListener('contextmenu', (e) => e.preventDefault());

// ============================================
// PHYSICS
// ============================================
const GRAVITY = -22;

function isSolid(x, y, z) {
  const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
  if (bx < 0 || bx >= WORLD_SIZE || bz < 0 || bz >= WORLD_SIZE || by < 0 || by >= WORLD_HEIGHT) return false;
  const b = getBlock(bx, by, bz);
  return b !== BLOCK_TYPES.AIR && b !== BLOCK_TYPES.WATER &&
         b !== BLOCK_TYPES.FLOWER_WHITE && b !== BLOCK_TYPES.FLOWER_RED;
}

function collides(px, py, pz, startDy) {
  const w = player.width;
  const footStart = startDy !== undefined ? startDy : 0.01;
  // Check corners, edge midpoints, and center at every height step
  // Water is NOT solid — player can walk/fall through it
  const offsets = [
    [-w, -w], [w, -w], [-w, w], [w, w],  // corners
    [0, -w], [0, w], [-w, 0], [w, 0],    // midpoints of each edge
    [0, 0]                                 // center
  ];
  for (let i = 0; i < offsets.length; i++) {
    const dx = offsets[i][0], dz = offsets[i][1];
    for (let dy = footStart; dy < player.height; dy += 0.25) {
      if (isSolid(px + dx, py + dy, pz + dz)) return true;
    }
    if (isSolid(px + dx, py + player.height, pz + dz)) return true;
  }
  return false;
}

// Push the player out of any solid block they are currently overlapping
function pushOutOfBlocks() {
  const w = player.width;
  const px = player.position.x, py = player.position.y, pz = player.position.z;
  const SKIN = 0.02;
  // Check each horizontal direction — if the player's collision edge is inside a solid block, push them out
  const checks = [
    { dx: w, dz: 0, axis: 'x', sign: 1 },
    { dx: -w, dz: 0, axis: 'x', sign: -1 },
    { dx: 0, dz: w, axis: 'z', sign: 1 },
    { dx: 0, dz: -w, axis: 'z', sign: -1 },
  ];
  for (const c of checks) {
    // Check at feet+0.1, mid-height, and head
    for (let dy = 0.1; dy < player.height; dy += 0.8) {
      if (isSolid(px + c.dx, py + dy, pz + c.dz)) {
        // Push the player back so their edge is flush with the block face
        if (c.axis === 'x') {
          const blockEdge = c.sign > 0 ? Math.floor(px + c.dx) : Math.floor(px + c.dx) + 1;
          player.position.x = blockEdge - c.sign * (w + SKIN);
        } else {
          const blockEdge = c.sign > 0 ? Math.floor(pz + c.dz) : Math.floor(pz + c.dz) + 1;
          player.position.z = blockEdge - c.sign * (w + SKIN);
        }
        break;
      }
    }
  }
}

// Try to move horizontally on a given axis. Returns true if moved.
// Handles step-down and step-up automatically so player never gets stuck on edges.
function tryHorizontalMove(newX, newZ) {
  const py = player.position.y;
  // 1) Normal collision — no obstacles at current height
  if (!collides(newX, py, newZ)) {
    player.position.x = newX;
    player.position.z = newZ;
    return true;
  }
  if (!player.onGround) return false;
  // 2) Step-up: try raising the player by small increments up to 1 block
  //    This handles walking UP onto a 1-block ledge
  for (let up = 0.25; up <= 1.0; up += 0.25) {
    if (!collides(newX, py + up, newZ)) {
      player.position.x = newX;
      player.position.z = newZ;
      player.targetGroundY = py + up;
      return true;
    }
  }
  // 3) Step-down: try lowering the player by small increments up to 2 blocks
  //    This handles walking DOWN from a higher block to a lower one
  for (let down = 0.25; down <= 2.0; down += 0.25) {
    if (!collides(newX, py - down, newZ)) {
      player.position.x = newX;
      player.position.z = newZ;
      // For small drops, smoothly lerp. For larger drops, let gravity take over.
      if (down <= 1.25) {
        player.targetGroundY = py - down;
      } else {
        player.onGround = false;
        player.velocity.y = -1;
      }
      return true;
    }
  }
  return false;
}

// Reusable vectors to avoid per-frame allocation
const _forward = new THREE.Vector3();
const _right = new THREE.Vector3();
const _move = new THREE.Vector3();

function updatePlayer(dt) {
  if (!isLocked) return;
  const sprint = keys['ShiftLeft'] || keys['ShiftRight'] ? 1.6 : 1;
  const speed = player.speed * sprint;

  // Movement relative to camera horizontal angle — forward is AWAY from camera (toward where player faces)
  const moveAngle = cameraAngleH;
  _forward.set(-Math.sin(moveAngle), 0, -Math.cos(moveAngle));
  _right.set(Math.cos(moveAngle), 0, -Math.sin(moveAngle));
  _move.set(0, 0, 0);
  const forward = _forward, right = _right, move = _move;
  let isMoving = false;

  if (keys['KeyW'] || keys['ArrowUp']) { move.add(forward); isMoving = true; }
  if (keys['KeyS'] || keys['ArrowDown']) { move.sub(forward); isMoving = true; }
  if (keys['KeyA'] || keys['ArrowLeft']) { move.sub(right); isMoving = true; }
  if (keys['KeyD'] || keys['ArrowRight']) { move.add(right); isMoving = true; }

  if (move.length() > 0) {
    move.normalize().multiplyScalar(speed);
    // Rotate player character to face movement direction
    player.yaw = Math.atan2(move.x, move.z);
  }

  // Walking animation
  if (isMoving && player.onGround) {
    player.walkCycle += dt * speed * 1.5;
    // Spawn dust particles while walking
    dustTimer += dt;
    if (dustTimer > 0.35) {
      dustTimer = 0;
      spawnDust(player.position.x, player.visualY, player.position.z);
    }
  } else {
    player.walkCycle *= 0.9;
    dustTimer = 0;
  }

  if (keys['Space'] && player.onGround) {
    player.velocity.y = player.jumpForce;
    player.onGround = false;
    player.jumpTime = 0;
    player.wasJumping = true;
    player.landTimer = -1;
  }

  // Track jump time while airborne
  if (!player.onGround) {
    player.jumpTime += dt;
  } else if (player.wasJumping) {
    // Just landed
    player.wasJumping = false;
    player.landTimer = 0;
    // Spawn landing dust burst
    for (let i = 0; i < 2; i++) {
      spawnDust(player.position.x + (Math.random() - 0.5) * 0.4, player.visualY, player.position.z + (Math.random() - 0.5) * 0.4);
    }
  }

  // Update landing animation timer
  if (player.landTimer >= 0) {
    player.landTimer += dt;
    if (player.landTimer > 0.3) player.landTimer = -1; // landing anim done
  }

  // Find ground height below player — only solid blocks count as ground
  // Water is passable — player falls through it to the solid block below
  // Check all 4 corners of the player's collision box and return the highest ground
  function getGroundY(px, py, pz) {
    const w = player.width;
    const startY = Math.floor(py);
    let maxGround = -100;
    const probes = [
      [px - w, pz - w], [px + w, pz - w],
      [px - w, pz + w], [px + w, pz + w],
      [px, pz] // center too
    ];
    for (let p = 0; p < probes.length; p++) {
      const bx = Math.floor(probes[p][0]), bz = Math.floor(probes[p][1]);
      for (let by = startY; by >= 0; by--) {
        if (isSolid(bx, by, bz)) {
          const g = by + 1;
          if (g > maxGround) maxGround = g;
          break;
        }
      }
    }
    return maxGround;
  }

  // Horizontal movement — try X and Z separately for wall-sliding,
  // with automatic step-up / step-down so the player never gets stuck on block edges.
  const newX = player.position.x + move.x * dt;
  const newZ = player.position.z + move.z * dt;

  // Try moving on both axes at once first (diagonal movement)
  if (move.x !== 0 && move.z !== 0) {
    if (tryHorizontalMove(newX, newZ)) {
      // Diagonal move succeeded — done
    } else {
      // Fall back to per-axis movement for wall-sliding
      if (move.x !== 0) tryHorizontalMove(newX, player.position.z);
      if (move.z !== 0) tryHorizontalMove(player.position.x, newZ);
    }
  } else {
    // Single-axis movement
    if (move.x !== 0) tryHorizontalMove(newX, player.position.z);
    if (move.z !== 0) tryHorizontalMove(player.position.x, newZ);
  }

  // Vertical movement — gravity with smooth ground lerp
  if (player.onGround) {
    // When grounded, scan for ground below current position
    const groundY = getGroundY(player.position.x, player.position.y, player.position.z);
    if (groundY < -50) {
      // Fell off edge
      player.onGround = false;
      player.velocity.y = 0;
    } else {
      // Always update target to the real ground beneath us
      player.targetGroundY = groundY;
      
      const diff = groundY - player.position.y;
      if (diff < -3.2) {
        // Ground dropped away significantly — start falling
        player.onGround = false;
        player.velocity.y = -2; // downward nudge for smooth descent
      } else {
        player.velocity.y = 0;
      }
    }
    // Smooth lerp toward target ground height
    const lerpSpeed = 22; // higher = snappier
    const yDiff = player.targetGroundY - player.position.y;
    if (Math.abs(yDiff) < 0.005) {
      player.position.y = player.targetGroundY;
    } else {
      player.position.y += yDiff * Math.min(1, lerpSpeed * dt);
    }
  } else {
    // Airborne — apply gravity
    player.velocity.y += GRAVITY * dt;
    const newY = player.position.y + player.velocity.y * dt;
    const groundY = getGroundY(player.position.x, newY, player.position.z);

    if (player.velocity.y <= 0 && newY <= groundY && groundY > -50) {
      // Landed — set target and start lerping
      player.targetGroundY = groundY;
      player.position.y = groundY;
      player.velocity.y = 0;
      player.onGround = true;
    } else if (!collides(player.position.x, newY, player.position.z)) {
      player.position.y = newY;
    } else {
      // Hit ceiling
      player.velocity.y = 0;
    }
  }

  // Safety: push player out of any solid blocks they overlap with
  pushOutOfBlocks();

  // Fall reset — find a clear spawn point (no tree/blocks above)
  if (player.position.y < -10) {
    let respawnX = WORLD_SIZE / 2 + 0.5;
    let respawnZ = WORLD_SIZE / 2 + 0.5;
    for (let tries = 0; tries < 200; tries++) {
      const tx = Math.floor(WORLD_SIZE / 2 + (Math.random() - 0.5) * 20);
      const tz = Math.floor(WORLD_SIZE / 2 + (Math.random() - 0.5) * 20);
      const th = getHeightCPU(tx, tz);
      if (th >= SURFACE_Y_LOW && getBlock(tx, th, tz) === BLOCK_TYPES.GRASS &&
          getBlock(tx, th + 1, tz) === BLOCK_TYPES.AIR &&
          getBlock(tx, th + 2, tz) === BLOCK_TYPES.AIR &&
          getBlock(tx, th + 3, tz) === BLOCK_TYPES.AIR) {
        let blocked = false;
        for (let dx = -1; dx <= 1 && !blocked; dx++) {
          for (let dz = -1; dz <= 1 && !blocked; dz++) {
            for (let dy = 1; dy <= 3; dy++) {
              const b = getBlock(tx + dx, th + dy, tz + dz);
              if (b === BLOCK_TYPES.WOOD || b === BLOCK_TYPES.LEAVES || b === BLOCK_TYPES.FENCE) {
                blocked = true;
                break;
              }
            }
          }
        }
        if (!blocked) {
          respawnX = tx + 0.5;
          respawnZ = tz + 0.5;
          break;
        }
      }
    }
    const respawnH = getHeightCPU(Math.floor(respawnX), Math.floor(respawnZ));
    const respawnY = Math.max(respawnH + 1, SURFACE_Y + 1);
    player.position.set(respawnX, respawnY, respawnZ);
    player.targetGroundY = respawnY;
    player.visualY = respawnY;
    player.velocity.set(0, 0, 0);
    player.onGround = true;
  }

  // Update visual Y with smooth lerp for character model
  const visualLerpSpeed = 10;
  const visualDiff = player.position.y - player.visualY;
  if (Math.abs(visualDiff) < 0.01) {
    player.visualY = player.position.y;
  } else {
    player.visualY += visualDiff * Math.min(1, visualLerpSpeed * dt);
  }

  // Update character model using smoothed visual Y
  playerGroup.position.set(player.position.x, player.visualY, player.position.z);
  playerGroup.rotation.y = player.yaw;

  // Animate skeleton bones
  if (playerModelReady && bonePelvis) {
    const isWalking = player.walkCycle > 0.05;
    const wc = player.walkCycle;
    const isAirborne = !player.onGround;
    const jt = player.jumpTime;

    if (isAirborne) {
      // ---- JUMP / AIRBORNE ANIMATION (rising pose throughout) ----
      const jumpPhase = Math.min(jt / 0.15, 1);
      const tuck = jumpPhase * 0.7;

      // Legs tuck up
      if (boneLeftUpperLeg) { boneLeftUpperLeg.rotation.x = -tuck * 0.5; boneLeftUpperLeg.rotation.z = 0; }
      if (boneRightUpperLeg) { boneRightUpperLeg.rotation.x = -tuck * 0.5; boneRightUpperLeg.rotation.z = 0; }
      if (boneLeftLowerLeg) boneLeftLowerLeg.rotation.x = tuck * 0.8;
      if (boneRightLowerLeg) boneRightLowerLeg.rotation.x = tuck * 0.8;

      // Arms reach up
      if (boneLeftUpperArm) { boneLeftUpperArm.rotation.x = -tuck * 1.2; boneLeftUpperArm.rotation.z = 0; }
      if (boneRightUpperArm) { boneRightUpperArm.rotation.x = -tuck * 1.2; boneRightUpperArm.rotation.z = 0; }
      if (boneLeftLowerArm) boneLeftLowerArm.rotation.x = -tuck * 0.3;
      if (boneRightLowerArm) boneRightLowerArm.rotation.x = -tuck * 0.3;

      // Body stretches upward
      if (boneChest) {
        boneChest.position.y = 0.45 + tuck * 0.04;
        boneChest.rotation.x = -tuck * 0.1;
        boneChest.rotation.z = 0;
      }
      if (boneHead) {
        boneHead.rotation.x = -tuck * 0.15;
        boneHead.rotation.y = 0;
        boneHead.rotation.z = 0;
      }
      if (bonePelvis) bonePelvis.rotation.z = 0;
    } else if (isWalking) {
      // ---- WALK ANIMATION ----
      const legSwing = Math.sin(wc) * 0.6;
      const armSwing = Math.sin(wc) * 0.5;
      const kneeFlexBase = 0.15;
      const kneeFlex = Math.max(0, -Math.cos(wc)) * 0.4;

      if (boneLeftUpperLeg) { boneLeftUpperLeg.rotation.x = legSwing; boneLeftUpperLeg.rotation.z = 0; }
      if (boneRightUpperLeg) { boneRightUpperLeg.rotation.x = -legSwing; boneRightUpperLeg.rotation.z = 0; }
      if (boneLeftLowerLeg) boneLeftLowerLeg.rotation.x = kneeFlexBase + (legSwing > 0 ? kneeFlex : 0);
      if (boneRightLowerLeg) boneRightLowerLeg.rotation.x = kneeFlexBase + (-legSwing > 0 ? kneeFlex : 0);

      if (boneLeftUpperArm) { boneLeftUpperArm.rotation.x = -armSwing; boneLeftUpperArm.rotation.z = 0; }
      if (boneRightUpperArm) { boneRightUpperArm.rotation.x = armSwing; boneRightUpperArm.rotation.z = 0; }
      const elbowFlex = Math.max(0, -Math.cos(wc)) * 0.3;
      if (boneLeftLowerArm) boneLeftLowerArm.rotation.x = -0.1 - (armSwing < 0 ? elbowFlex : 0);
      if (boneRightLowerArm) boneRightLowerArm.rotation.x = -0.1 - (armSwing > 0 ? elbowFlex : 0);

      if (boneChest) {
        boneChest.position.y = 0.45 + Math.abs(Math.sin(wc * 2)) * 0.03;
        boneChest.rotation.x = 0;
        boneChest.rotation.z = Math.sin(wc) * 0.02;
      }
      if (boneHead) {
        boneHead.rotation.x = -0.05;
        boneHead.rotation.y = 0;
        boneHead.rotation.z = -Math.sin(wc) * 0.015;
      }
      if (bonePelvis) bonePelvis.rotation.z = Math.sin(wc) * 0.025;
    } else {
      // ---- IDLE ANIMATION ----
      const idleTime = performance.now() * 0.001;
      const breathe = Math.sin(idleTime * 1.5) * 0.015;

      if (boneLeftUpperLeg) { boneLeftUpperLeg.rotation.x = 0; boneLeftUpperLeg.rotation.z = 0; }
      if (boneRightUpperLeg) { boneRightUpperLeg.rotation.x = 0; boneRightUpperLeg.rotation.z = 0; }
      if (boneLeftLowerLeg) boneLeftLowerLeg.rotation.x = 0;
      if (boneRightLowerLeg) boneRightLowerLeg.rotation.x = 0;

      if (boneLeftUpperArm) { boneLeftUpperArm.rotation.x = Math.sin(idleTime * 0.8) * 0.02; boneLeftUpperArm.rotation.z = 0; }
      if (boneRightUpperArm) { boneRightUpperArm.rotation.x = Math.sin(idleTime * 0.8 + 1) * 0.02; boneRightUpperArm.rotation.z = 0; }
      if (boneLeftLowerArm) boneLeftLowerArm.rotation.x = -0.05;
      if (boneRightLowerArm) boneRightLowerArm.rotation.x = -0.05;

      if (boneChest) {
        boneChest.position.y = 0.45 + breathe;
        boneChest.rotation.x = 0;
        boneChest.rotation.z = 0;
      }
      if (boneHead) {
        boneHead.rotation.x = Math.sin(idleTime * 0.5) * 0.03 - 0.02;
        boneHead.rotation.y = Math.sin(idleTime * 0.3) * 0.05;
        boneHead.rotation.z = 0;
      }
      if (bonePelvis) bonePelvis.rotation.z = 0;
    }
  }

  // Update dust particles
  updateDust(dt);

  // Smooth camera
  cameraAngleH += (targetCamAngleH - cameraAngleH) * 0.08;
  cameraAngleV += (targetCamAngleV - cameraAngleV) * 0.08;

  // Position camera behind/above player using smoothed visual Y
  const camX = player.position.x + Math.sin(cameraAngleH) * Math.cos(cameraAngleV) * cameraDistance;
  const camY = player.visualY + Math.sin(cameraAngleV) * cameraDistance + 2;
  const camZ = player.position.z + Math.cos(cameraAngleH) * Math.cos(cameraAngleV) * cameraDistance;

  camera.position.set(camX, camY, camZ);
  camera.lookAt(player.position.x, player.visualY + 1.2, player.position.z);

  // Keep shadow camera centered on player for best shadow quality
  const shadowOffset = 40;
  sunLight.position.set(player.position.x + shadowOffset, 80, player.position.z + shadowOffset);
  sunLight.target.position.set(player.position.x, player.position.y, player.position.z);
  sunLight.target.updateMatrixWorld();
  sunLight.shadow.camera.updateProjectionMatrix();
}

// ============================================
// UPDATE CREATURES
// ============================================
function updateCreatures(dt) {
  for (const c of creatures) {
    c.wanderTimer -= dt;
    if (c.wanderTimer <= 0) {
      c.wanderAngle = Math.random() * Math.PI * 2;
      c.wanderTimer = 2 + Math.random() * 4;
    }

    const nx = c.group.position.x + Math.sin(c.wanderAngle) * c.speed * dt;
    const nz = c.group.position.z + Math.cos(c.wanderAngle) * c.speed * dt;
    const ix = Math.floor(nx), iz = Math.floor(nz);

    if (ix >= 1 && ix < WORLD_SIZE - 1 && iz >= 1 && iz < WORLD_SIZE - 1) {
      const nh = getHeightCPU(ix, iz);
      if (nh >= SURFACE_Y_LOW) {
        const blockAt = getBlock(ix, nh, iz);
        if (blockAt === BLOCK_TYPES.GRASS || blockAt === BLOCK_TYPES.PATH) {
          // Ensure solid ground below (not floating)
          if (nh > 0 && getBlock(ix, nh - 1, iz) === BLOCK_TYPES.AIR) {
            c.wanderAngle += Math.PI; // Turn around
          } else {
            const blockAbove = getBlock(ix, nh + 1, iz);
            if (blockAbove === BLOCK_TYPES.AIR || blockAbove === BLOCK_TYPES.FLOWER_WHITE || blockAbove === BLOCK_TYPES.FLOWER_RED) {
              // Quick water check — cardinal directions only (5 checks vs 27)
              const waterNearby = getBlock(ix, nh, iz) === BLOCK_TYPES.WATER ||
                getBlock(ix + 1, nh, iz) === BLOCK_TYPES.WATER ||
                getBlock(ix - 1, nh, iz) === BLOCK_TYPES.WATER ||
                getBlock(ix, nh, iz + 1) === BLOCK_TYPES.WATER ||
                getBlock(ix, nh, iz - 1) === BLOCK_TYPES.WATER;
              if (!waterNearby) {
                c.group.position.x = nx;
                c.group.position.z = nz;
                c.group.position.y = nh + 1;
                c.group.rotation.y = c.wanderAngle;
              } else {
                c.wanderAngle += Math.PI; // Turn away from water
              }
            }
          }
        } else {
          c.wanderAngle += Math.PI; // Turn around on non-walkable blocks
        }
      }
    }
  }
}

// ============================================
// HUD / UI (minimal — no hotbar, no block selection)
// ============================================

const coordsEl = document.createElement('div');
coordsEl.style.cssText = 'position:fixed;top:12px;left:12px;font-family:Inter,system-ui,monospace;font-size:12px;color:rgba(255,255,255,0.6);z-index:100;line-height:1.6;background:rgba(0,0,0,0.3);padding:8px 12px;border-radius:4px;pointer-events:none;';
document.body.appendChild(coordsEl);

const fpsEl = document.createElement('div');
fpsEl.style.cssText = 'position:fixed;top:12px;right:12px;font-family:Inter,system-ui,monospace;font-size:13px;color:rgba(255,255,255,0.8);z-index:100;background:rgba(0,0,0,0.4);padding:6px 12px;border-radius:4px;pointer-events:none;border:1px solid rgba(255,255,255,0.08);';
document.body.appendChild(fpsEl);
let fpsFrames = 0, fpsLastTime = performance.now(), fpsValue = 0;

// ============================================
// BLOCK PLACEMENT / REMOVAL SYSTEM
// ============================================
let selectedBlockType = BLOCK_TYPES.GRASS;

// Hotbar selection
const hotbarSlots = document.querySelectorAll('.hotbar-slot');
hotbarSlots.forEach(slot => {
  slot.addEventListener('click', () => {
    hotbarSlots.forEach(s => s.classList.remove('selected'));
    slot.classList.add('selected');
    selectedBlockType = parseInt(slot.dataset.type);
  });
});

// Number keys 1-9 for hotbar
window.addEventListener('keydown', (e) => {
  const num = parseInt(e.key);
  if (num >= 1 && num <= 9 && hotbarSlots[num - 1]) {
    hotbarSlots.forEach(s => s.classList.remove('selected'));
    hotbarSlots[num - 1].classList.add('selected');
    selectedBlockType = parseInt(hotbarSlots[num - 1].dataset.type);
    cancelObjectMode();
  }
  // Escape closes object modal and cancels object mode
  if (e.key === 'Escape') {
    objectsModal.classList.add('hidden');
    cancelObjectMode();
  }
  // R key rotates object placement by 90°
  if ((e.key === 'r' || e.key === 'R') && placeMode === 'object' && selectedObjectType) {
    objectRotation = (objectRotation + 1) % 4;
    showObjectIndicator();
  }
});

// ============================================
// OBJECT PLACEMENT SYSTEM
// ============================================
let placeMode = 'block'; // 'block' or 'object'
let selectedObjectType = null;
let objectRotation = 0; // 0, 1, 2, 3 → 0°, 90°, 180°, 270°

const objectsBtn = document.getElementById('objects-btn');
const objectsModal = document.getElementById('objects-modal');
const objectsCloseBtn = document.getElementById('objects-close-btn');
const objCards = document.querySelectorAll('.obj-card');

objectsBtn.addEventListener('click', () => {
  objectsModal.classList.toggle('hidden');
  objectsBtn.classList.toggle('active');
});

objectsCloseBtn.addEventListener('click', () => {
  objectsModal.classList.add('hidden');
  objectsBtn.classList.remove('active');
});

// Click backdrop to close
objectsModal.addEventListener('click', (e) => {
  if (e.target === objectsModal) {
    objectsModal.classList.add('hidden');
    objectsBtn.classList.remove('active');
  }
});

// Prevent scroll/wheel inside modal from zooming the camera
objectsModal.addEventListener('wheel', (e) => { e.stopPropagation(); });

const objectIndicator = document.getElementById('object-indicator');
const objectIndicatorText = document.getElementById('object-indicator-text');
const objectCancelBtn = document.getElementById('object-cancel-btn');

const OBJ_LABELS = {
  bed: '🛏️ Bed', dresser: '🗄️ Dresser', chair: '🪑 Chair', table: '🪵 Table',
  armchair: '🛋️ Armchair', armor: '🛡️ Armor', fireplace: '🔥 Fireplace',
  door: '🚪 Door', 'sword-rack': '⚔️ Sword Rack',
  sofa: '🛋️ Sofa', bookshelf: '📚 Bookshelf', bathtub: '🛁 Bathtub',
  mirror: '🪞 Mirror', sink: '🚰 Sink', 'computer-desk': '🖥️ Computer',
  rug: '🟫 Rug', 'coat-rack': '🧥 Coat Rack', fridge: '🧊 Fridge',
  wardrobe: '👗 Wardrobe',
  painting: '🖼️ Painting', tv: '📺 TV', 'coffee-table': '💡 Coffee Table + Lamp',
  speaker: '🔊 Speaker', 'drum-kit': '🥁 Drum Kit'
};

function showObjectIndicator() {
  if (selectedObjectType && placeMode === 'object') {
    const rotDeg = objectRotation * 90;
    objectIndicatorText.textContent = 'Placing: ' + (OBJ_LABELS[selectedObjectType] || selectedObjectType) + '  ↻ ' + rotDeg + '°  (R to rotate)';
    objectIndicator.classList.remove('hidden');
  } else {
    objectIndicator.classList.add('hidden');
  }
}

function cancelObjectMode() {
  placeMode = 'block';
  selectedObjectType = null;
  objectRotation = 0;
  objectsBtn.classList.remove('active');
  objCards.forEach(c => c.classList.remove('selected'));
  if (typeof objectIndicator !== 'undefined') objectIndicator.classList.add('hidden');
  if (typeof hideGhostObject === 'function') hideGhostObject();
  // Re-select first hotbar slot if none selected
  const anySelected = [...hotbarSlots].some(s => s.classList.contains('selected'));
  if (!anySelected && hotbarSlots[0]) {
    hotbarSlots[0].classList.add('selected');
    selectedBlockType = parseInt(hotbarSlots[0].dataset.type);
  }
}

objectCancelBtn.addEventListener('click', cancelObjectMode);

objCards.forEach(card => {
  card.addEventListener('click', () => {
    objCards.forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedObjectType = card.dataset.obj;
    placeMode = 'object';
    // Deselect hotbar
    hotbarSlots.forEach(s => s.classList.remove('selected'));
    // Close modal
    objectsModal.classList.add('hidden');
    objectsBtn.classList.add('active');
    showObjectIndicator();
  });
});

// When user selects a block from hotbar, switch back to block mode
hotbarSlots.forEach(slot => {
  slot.addEventListener('click', () => {
    placeMode = 'block';
    selectedObjectType = null;
    objectsBtn.classList.remove('active');
    objCards.forEach(c => c.classList.remove('selected'));
    showObjectIndicator();
  });
});

// --- Object builders (procedural voxel furniture) ---
const placedObjects = new THREE.Group();
placedObjects.name = 'placedObjects';
scene.add(placedObjects);

function buildVoxelObject(type) {
  const group = new THREE.Group();
  group.name = 'object_' + type + '_' + Date.now();
  const wood = new THREE.MeshLambertMaterial({ color: 0x8B6B42 });
  const darkWood = new THREE.MeshLambertMaterial({ color: 0x5C3A1E });
  const fabric = new THREE.MeshLambertMaterial({ color: 0x8B2020 });
  const white = new THREE.MeshLambertMaterial({ color: 0xDDCCBB });
  const stone = new THREE.MeshLambertMaterial({ color: 0x777777 });
  const iron = new THREE.MeshLambertMaterial({ color: 0xAAAAAA });
  const fire = new THREE.MeshLambertMaterial({ color: 0xFF6600, emissive: 0xFF3300, emissiveIntensity: 0.5 });

  function box(w, h, d, mat, x, y, z) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    m.receiveShadow = true;
    group.add(m);
    return m;
  }

  switch(type) {
    case 'bed':
      // Frame
      box(1.0, 0.15, 2.0, wood, 0, 0.15, 0);
      // Mattress
      box(0.9, 0.15, 1.8, white, 0, 0.3, 0);
      // Pillow
      box(0.4, 0.1, 0.25, fabric, 0, 0.38, -0.75);
      // Headboard
      box(1.0, 0.5, 0.1, darkWood, 0, 0.35, -0.95);
      // Footboard
      box(1.0, 0.3, 0.1, darkWood, 0, 0.25, 0.95);
      // Legs
      box(0.1, 0.15, 0.1, darkWood, -0.45, 0.07, -0.9);
      box(0.1, 0.15, 0.1, darkWood, 0.45, 0.07, -0.9);
      box(0.1, 0.15, 0.1, darkWood, -0.45, 0.07, 0.9);
      box(0.1, 0.15, 0.1, darkWood, 0.45, 0.07, 0.9);
      break;

    case 'dresser':
      // Body
      box(0.8, 0.9, 0.45, wood, 0, 0.45, 0);
      // Drawers (3)
      box(0.7, 0.2, 0.02, darkWood, 0, 0.2, 0.23);
      box(0.7, 0.2, 0.02, darkWood, 0, 0.45, 0.23);
      box(0.7, 0.2, 0.02, darkWood, 0, 0.7, 0.23);
      // Knobs
      box(0.06, 0.06, 0.04, iron, -0.12, 0.2, 0.25);
      box(0.06, 0.06, 0.04, iron, 0.12, 0.2, 0.25);
      box(0.06, 0.06, 0.04, iron, -0.12, 0.45, 0.25);
      box(0.06, 0.06, 0.04, iron, 0.12, 0.45, 0.25);
      box(0.06, 0.06, 0.04, iron, -0.12, 0.7, 0.25);
      box(0.06, 0.06, 0.04, iron, 0.12, 0.7, 0.25);
      break;

    case 'chair':
      // Seat
      box(0.45, 0.06, 0.45, wood, 0, 0.4, 0);
      // Backrest
      box(0.45, 0.5, 0.06, wood, 0, 0.68, -0.2);
      // Legs
      box(0.06, 0.4, 0.06, darkWood, -0.18, 0.2, -0.18);
      box(0.06, 0.4, 0.06, darkWood, 0.18, 0.2, -0.18);
      box(0.06, 0.4, 0.06, darkWood, -0.18, 0.2, 0.18);
      box(0.06, 0.4, 0.06, darkWood, 0.18, 0.2, 0.18);
      break;

    case 'table':
      // Top
      box(1.2, 0.08, 0.7, wood, 0, 0.7, 0);
      // Legs
      box(0.08, 0.7, 0.08, darkWood, -0.5, 0.35, -0.28);
      box(0.08, 0.7, 0.08, darkWood, 0.5, 0.35, -0.28);
      box(0.08, 0.7, 0.08, darkWood, -0.5, 0.35, 0.28);
      box(0.08, 0.7, 0.08, darkWood, 0.5, 0.35, 0.28);
      break;

    case 'armchair':
      // Seat
      box(0.6, 0.1, 0.55, fabric, 0, 0.35, 0);
      // Backrest
      box(0.6, 0.5, 0.1, fabric, 0, 0.6, -0.25);
      // Armrests
      box(0.08, 0.25, 0.55, wood, -0.3, 0.45, 0);
      box(0.08, 0.25, 0.55, wood, 0.3, 0.45, 0);
      // Base
      box(0.5, 0.3, 0.5, darkWood, 0, 0.15, 0);
      break;

    case 'armor':
      // Stand pole
      box(0.06, 1.2, 0.06, darkWood, 0, 0.6, 0);
      // Base
      box(0.4, 0.06, 0.4, darkWood, 0, 0.03, 0);
      // Helmet
      box(0.3, 0.25, 0.3, iron, 0, 1.15, 0);
      // Chestplate
      box(0.4, 0.4, 0.2, iron, 0, 0.8, 0);
      // Shoulders
      box(0.15, 0.1, 0.15, iron, -0.25, 0.95, 0);
      box(0.15, 0.1, 0.15, iron, 0.25, 0.95, 0);
      break;

    case 'fireplace':
      // Back wall
      box(1.0, 0.9, 0.15, stone, 0, 0.45, -0.42);
      // Side walls
      box(0.15, 0.9, 0.7, stone, -0.42, 0.45, -0.1);
      box(0.15, 0.9, 0.7, stone, 0.42, 0.45, -0.1);
      // Top mantle
      box(1.1, 0.12, 0.8, stone, 0, 0.95, -0.1);
      // Floor
      box(0.7, 0.06, 0.5, stone, 0, 0.03, -0.1);
      // Fire
      box(0.3, 0.3, 0.2, fire, 0, 0.2, -0.15);
      box(0.2, 0.2, 0.15, fire, -0.15, 0.15, -0.1);
      box(0.2, 0.2, 0.15, fire, 0.15, 0.15, -0.1);
      break;

    case 'door': {
      // Frame — 1 block wide x 2 blocks tall
      box(1.0, 0.1, 0.14, darkWood, 0, 2.0, 0);       // top beam
      box(0.1, 2.0, 0.14, darkWood, -0.48, 1.0, 0);    // left post
      box(0.1, 2.0, 0.14, darkWood, 0.48, 1.0, 0);     // right post
      // Door panel (named for animation)
      const doorPanel = box(0.78, 1.9, 0.07, wood, 0, 1.0, 0.02);
      doorPanel.name = 'doorPanel';
      // Handle
      const doorHandle = box(0.07, 0.12, 0.07, iron, 0.28, 0.95, 0.07);
      doorHandle.name = 'doorHandle';
      // Mark as interactive
      group.userData.interactive = 'door';
      group.userData.isOpen = false;
      break;
    }

    case 'sword-rack':
      // Back board
      box(0.7, 0.8, 0.06, darkWood, 0, 0.7, 0);
      // Horizontal holders
      box(0.6, 0.06, 0.15, wood, 0, 0.9, 0.07);
      box(0.6, 0.06, 0.15, wood, 0, 0.5, 0.07);
      // Swords (3)
      box(0.04, 0.65, 0.04, iron, -0.18, 0.7, 0.1);
      box(0.04, 0.7, 0.04, iron, 0.0, 0.72, 0.1);
      box(0.04, 0.6, 0.04, iron, 0.18, 0.68, 0.1);
      // Sword hilts
      box(0.1, 0.04, 0.06, darkWood, -0.18, 0.4, 0.1);
      box(0.1, 0.04, 0.06, darkWood, 0.0, 0.4, 0.1);
      box(0.1, 0.04, 0.06, darkWood, 0.18, 0.38, 0.1);
      break;

    case 'sofa': {
      const cushion = new THREE.MeshLambertMaterial({ color: 0x6B3A3A });
      // Base frame
      box(1.6, 0.15, 0.7, darkWood, 0, 0.15, 0);
      // Seat cushions
      box(0.72, 0.18, 0.55, cushion, -0.38, 0.33, 0.05);
      box(0.72, 0.18, 0.55, cushion, 0.38, 0.33, 0.05);
      // Backrest
      box(1.5, 0.45, 0.12, cushion, 0, 0.6, -0.3);
      // Armrests
      box(0.12, 0.35, 0.65, darkWood, -0.75, 0.4, 0.0);
      box(0.12, 0.35, 0.65, darkWood, 0.75, 0.4, 0.0);
      // Legs
      box(0.08, 0.1, 0.08, darkWood, -0.7, 0.05, 0.28);
      box(0.08, 0.1, 0.08, darkWood, 0.7, 0.05, 0.28);
      box(0.08, 0.1, 0.08, darkWood, -0.7, 0.05, -0.28);
      box(0.08, 0.1, 0.08, darkWood, 0.7, 0.05, -0.28);
      // Back cushions (pillows)
      box(0.35, 0.3, 0.1, fabric, -0.35, 0.58, -0.2);
      box(0.35, 0.3, 0.1, fabric, 0.35, 0.58, -0.2);
      break;
    }

    case 'bookshelf': {
      const book1 = new THREE.MeshLambertMaterial({ color: 0x8B2020 });
      const book2 = new THREE.MeshLambertMaterial({ color: 0x1B4B8A });
      const book3 = new THREE.MeshLambertMaterial({ color: 0x2E6B30 });
      const book4 = new THREE.MeshLambertMaterial({ color: 0x7B5B3A });
      // Main frame
      box(0.9, 1.8, 0.35, wood, 0, 0.9, 0);
      // Shelves (4)
      box(0.85, 0.04, 0.33, darkWood, 0, 0.02, 0);
      box(0.85, 0.04, 0.33, darkWood, 0, 0.45, 0);
      box(0.85, 0.04, 0.33, darkWood, 0, 0.9, 0);
      box(0.85, 0.04, 0.33, darkWood, 0, 1.35, 0);
      // Top
      box(0.9, 0.04, 0.35, darkWood, 0, 1.8, 0);
      // Books row 1 (bottom shelf)
      box(0.08, 0.38, 0.22, book1, -0.3, 0.24, 0.02);
      box(0.06, 0.35, 0.22, book2, -0.2, 0.22, 0.02);
      box(0.07, 0.4, 0.22, book3, -0.1, 0.25, 0.02);
      box(0.08, 0.36, 0.22, book4, 0.0, 0.23, 0.02);
      box(0.06, 0.38, 0.22, book1, 0.1, 0.24, 0.02);
      box(0.07, 0.34, 0.22, book2, 0.2, 0.22, 0.02);
      box(0.08, 0.37, 0.22, book3, 0.3, 0.23, 0.02);
      // Books row 2
      box(0.07, 0.4, 0.22, book4, -0.28, 0.69, 0.02);
      box(0.08, 0.36, 0.22, book1, -0.16, 0.67, 0.02);
      box(0.06, 0.38, 0.22, book3, -0.05, 0.68, 0.02);
      box(0.07, 0.35, 0.22, book2, 0.06, 0.67, 0.02);
      box(0.08, 0.39, 0.22, book4, 0.18, 0.69, 0.02);
      box(0.06, 0.36, 0.22, book1, 0.28, 0.67, 0.02);
      // Books row 3
      box(0.08, 0.37, 0.22, book2, -0.25, 1.13, 0.02);
      box(0.07, 0.4, 0.22, book3, -0.13, 1.15, 0.02);
      box(0.06, 0.35, 0.22, book1, -0.02, 1.12, 0.02);
      box(0.08, 0.38, 0.22, book4, 0.1, 1.14, 0.02);
      box(0.07, 0.36, 0.22, book2, 0.22, 1.13, 0.02);
      // Books row 4 (top shelf)
      box(0.06, 0.38, 0.22, book3, -0.2, 1.57, 0.02);
      box(0.08, 0.36, 0.22, book1, -0.08, 1.56, 0.02);
      box(0.07, 0.4, 0.22, book4, 0.04, 1.58, 0.02);
      box(0.06, 0.35, 0.22, book2, 0.15, 1.55, 0.02);
      break;
    }

    case 'bathtub': {
      const porcelain = new THREE.MeshLambertMaterial({ color: 0xF0EDE5 });
      const chrome = new THREE.MeshLambertMaterial({ color: 0xCCCCCC });
      const bathWater = new THREE.MeshLambertMaterial({ color: 0x3A9AD9, transparent: true, opacity: 0.55 });
      const foam = new THREE.MeshLambertMaterial({ color: 0xFFFFFF, transparent: true, opacity: 0.7 });
      // Outer shell
      box(0.7, 0.5, 1.5, porcelain, 0, 0.3, 0);
      // Water surface (fills the tub)
      const waterSurface = box(0.54, 0.06, 1.28, bathWater, 0, 0.48, 0);
      waterSurface.name = 'bathWater';
      // Foam/bubble clusters on water surface
      box(0.18, 0.04, 0.22, foam, -0.12, 0.52, 0.2);
      box(0.15, 0.04, 0.15, foam, 0.15, 0.52, -0.1);
      box(0.22, 0.04, 0.18, foam, 0.0, 0.52, 0.4);
      box(0.12, 0.04, 0.12, foam, -0.18, 0.52, -0.35);
      box(0.1, 0.04, 0.14, foam, 0.2, 0.52, 0.35);
      // Rim - long sides
      box(0.08, 0.08, 1.5, porcelain, -0.32, 0.54, 0);
      box(0.08, 0.08, 1.5, porcelain, 0.32, 0.54, 0);
      // Rim - short sides
      box(0.7, 0.08, 0.08, porcelain, 0, 0.54, -0.72);
      box(0.7, 0.08, 0.08, porcelain, 0, 0.54, 0.72);
      // Faucet
      box(0.06, 0.25, 0.06, chrome, 0, 0.65, -0.6);
      box(0.06, 0.06, 0.15, chrome, 0, 0.75, -0.53);
      // Feet (clawfoot style)
      box(0.1, 0.08, 0.1, chrome, -0.25, 0.04, -0.6);
      box(0.1, 0.08, 0.1, chrome, 0.25, 0.04, -0.6);
      box(0.1, 0.08, 0.1, chrome, -0.25, 0.04, 0.6);
      box(0.1, 0.08, 0.1, chrome, 0.25, 0.04, 0.6);
      break;
    }

    case 'mirror': {
      const glass = new THREE.MeshLambertMaterial({ color: 0xB8D8E8, emissive: 0x334455, emissiveIntensity: 0.3 });
      const gold = new THREE.MeshLambertMaterial({ color: 0xC9A84C });
      // Frame
      box(0.6, 0.9, 0.05, gold, 0, 0.8, 0);
      // Glass
      box(0.5, 0.8, 0.03, glass, 0, 0.8, 0.02);
      // Frame decorative top
      box(0.65, 0.06, 0.06, gold, 0, 1.27, 0);
      // Frame decorative bottom
      box(0.65, 0.06, 0.06, gold, 0, 0.33, 0);
      // Frame sides
      box(0.06, 0.9, 0.06, gold, -0.3, 0.8, 0);
      box(0.06, 0.9, 0.06, gold, 0.3, 0.8, 0);
      // Corner ornaments
      box(0.1, 0.1, 0.06, gold, -0.3, 1.25, 0.01);
      box(0.1, 0.1, 0.06, gold, 0.3, 1.25, 0.01);
      box(0.1, 0.1, 0.06, gold, -0.3, 0.35, 0.01);
      box(0.1, 0.1, 0.06, gold, 0.3, 0.35, 0.01);
      break;
    }

    case 'sink': {
      const porcelain = new THREE.MeshLambertMaterial({ color: 0xF0EDE5 });
      const chrome = new THREE.MeshLambertMaterial({ color: 0xCCCCCC });
      // Basin
      box(0.55, 0.15, 0.4, porcelain, 0, 0.72, 0.05);
      // Basin inner
      box(0.42, 0.1, 0.3, new THREE.MeshLambertMaterial({ color: 0xD5D0C8 }), 0, 0.72, 0.05);
      // Pedestal column
      box(0.15, 0.65, 0.15, porcelain, 0, 0.35, 0);
      // Pedestal base
      box(0.25, 0.06, 0.25, porcelain, 0, 0.03, 0);
      // Back splash
      box(0.55, 0.2, 0.04, porcelain, 0, 0.88, -0.15);
      // Faucet stem
      box(0.04, 0.18, 0.04, chrome, 0, 0.88, -0.05);
      // Faucet spout
      box(0.04, 0.04, 0.12, chrome, 0, 0.96, 0.02);
      // Handles
      box(0.08, 0.06, 0.04, chrome, -0.12, 0.85, -0.05);
      box(0.08, 0.06, 0.04, chrome, 0.12, 0.85, -0.05);
      break;
    }

    case 'computer-desk': {
      const plastic = new THREE.MeshLambertMaterial({ color: 0x2A2A2A });
      const screen = new THREE.MeshLambertMaterial({ color: 0x2244AA, emissive: 0x1133AA, emissiveIntensity: 0.5 });
      const keyboard = new THREE.MeshLambertMaterial({ color: 0x333333 });
      // Desk top
      box(1.2, 0.06, 0.6, wood, 0, 0.7, 0);
      // Desk legs
      box(0.06, 0.7, 0.06, darkWood, -0.55, 0.35, -0.25);
      box(0.06, 0.7, 0.06, darkWood, 0.55, 0.35, -0.25);
      box(0.06, 0.7, 0.06, darkWood, -0.55, 0.35, 0.25);
      box(0.06, 0.7, 0.06, darkWood, 0.55, 0.35, 0.25);
      // Monitor stand base
      box(0.2, 0.02, 0.15, plastic, 0, 0.74, -0.1);
      // Monitor stand neck
      box(0.04, 0.2, 0.04, plastic, 0, 0.84, -0.1);
      // Monitor frame
      box(0.65, 0.42, 0.04, plastic, 0, 1.15, -0.12);
      // Monitor screen
      box(0.58, 0.35, 0.02, screen, 0, 1.15, -0.1);
      // Keyboard
      box(0.4, 0.02, 0.14, keyboard, 0, 0.74, 0.1);
      // Mouse
      box(0.06, 0.02, 0.1, plastic, 0.3, 0.74, 0.1);
      // Mouse pad
      box(0.2, 0.01, 0.18, new THREE.MeshLambertMaterial({ color: 0x444444 }), 0.3, 0.735, 0.1);
      break;
    }

    case 'rug': {
      const rugMat = new THREE.MeshLambertMaterial({ color: 0x8B3A3A });
      const rugBorder = new THREE.MeshLambertMaterial({ color: 0xC9A84C });
      const rugPattern = new THREE.MeshLambertMaterial({ color: 0x6B2A2A });
      // Main rug body (flat)
      box(2.0, 0.03, 1.4, rugMat, 0, 0.02, 0);
      // Border trim
      box(2.05, 0.035, 0.06, rugBorder, 0, 0.025, -0.7);
      box(2.05, 0.035, 0.06, rugBorder, 0, 0.025, 0.7);
      box(0.06, 0.035, 1.4, rugBorder, -1.0, 0.025, 0);
      box(0.06, 0.035, 1.4, rugBorder, 1.0, 0.025, 0);
      // Center diamond pattern
      box(0.4, 0.035, 0.4, rugPattern, 0, 0.03, 0);
      // Corner decorations
      box(0.15, 0.035, 0.15, rugBorder, -0.7, 0.03, -0.45);
      box(0.15, 0.035, 0.15, rugBorder, 0.7, 0.03, -0.45);
      box(0.15, 0.035, 0.15, rugBorder, -0.7, 0.03, 0.45);
      box(0.15, 0.035, 0.15, rugBorder, 0.7, 0.03, 0.45);
      // Fringe on short sides
      for (let i = -4; i <= 4; i++) {
        box(0.04, 0.01, 0.08, rugBorder, i * 0.2, 0.015, -0.74);
        box(0.04, 0.01, 0.08, rugBorder, i * 0.2, 0.015, 0.74);
      }
      break;
    }

    case 'coat-rack': {
      const pole = new THREE.MeshLambertMaterial({ color: 0x5C3A1E });
      const hookMat = new THREE.MeshLambertMaterial({ color: 0x888888 });
      const coatMat1 = new THREE.MeshLambertMaterial({ color: 0x3A5A8C });
      const coatMat2 = new THREE.MeshLambertMaterial({ color: 0x8B4513 });
      const hatMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
      // Base (cross shape)
      box(0.5, 0.06, 0.12, darkWood, 0, 0.03, 0);
      box(0.12, 0.06, 0.5, darkWood, 0, 0.03, 0);
      // Center pole
      box(0.1, 1.6, 0.1, pole, 0, 0.83, 0);
      // Top knob
      box(0.14, 0.14, 0.14, pole, 0, 1.65, 0);
      // 4 hooks
      box(0.04, 0.04, 0.18, hookMat, 0.15, 1.35, 0);
      box(0.04, 0.04, 0.18, hookMat, -0.15, 1.35, 0);
      box(0.18, 0.04, 0.04, hookMat, 0, 1.35, 0.15);
      box(0.18, 0.04, 0.04, hookMat, 0, 1.35, -0.15);
      // Hook tips (downward)
      box(0.04, 0.1, 0.04, hookMat, 0.15, 1.3, 0.14);
      box(0.04, 0.1, 0.04, hookMat, -0.15, 1.3, 0.14);
      box(0.04, 0.1, 0.04, hookMat, 0.14, 1.3, -0.15);
      box(0.04, 0.1, 0.04, hookMat, -0.14, 1.3, -0.15);
      // Hanging coat (draping on one hook)
      box(0.3, 0.55, 0.12, coatMat1, 0.22, 1.0, 0.0);
      // Scarf on another hook
      box(0.06, 0.5, 0.06, coatMat2, -0.18, 1.05, 0.0);
      // Hat on top
      box(0.22, 0.08, 0.22, hatMat, 0, 1.73, 0);
      box(0.3, 0.03, 0.3, hatMat, 0, 1.68, 0);
      break;
    }

    case 'fridge': {
      const fridgeBody = new THREE.MeshLambertMaterial({ color: 0xE8E8E8 });
      const fridgeInner = new THREE.MeshLambertMaterial({ color: 0xF0F0F0 });
      const fridgeDark = new THREE.MeshLambertMaterial({ color: 0xCCCCCC });
      const handleMat = new THREE.MeshLambertMaterial({ color: 0x999999 });
      const shelfMat = new THREE.MeshLambertMaterial({ color: 0xD8D8D8 });

      // Food materials
      const carrotMat = new THREE.MeshLambertMaterial({ color: 0xED6A11 });
      const carrotGreen = new THREE.MeshLambertMaterial({ color: 0x3DA33D });
      const lettuceMat = new THREE.MeshLambertMaterial({ color: 0x55BB44 });
      const lettuceDark = new THREE.MeshLambertMaterial({ color: 0x3D8B30 });
      const tomatoMat = new THREE.MeshLambertMaterial({ color: 0xDD3322 });
      const tomatoStem = new THREE.MeshLambertMaterial({ color: 0x336622 });
      const lemonMat = new THREE.MeshLambertMaterial({ color: 0xF5E050 });
      const appleMat = new THREE.MeshLambertMaterial({ color: 0xCC2244 });
      const appleGreen = new THREE.MeshLambertMaterial({ color: 0x66BB33 });
      const orangeMat = new THREE.MeshLambertMaterial({ color: 0xFF8C00 });
      const eggplantMat = new THREE.MeshLambertMaterial({ color: 0x5B2C6F });
      const bottleMat = new THREE.MeshLambertMaterial({ color: 0x4488CC, transparent: true, opacity: 0.7 });
      const milkMat = new THREE.MeshLambertMaterial({ color: 0xFAFAFA });
      const cheeseMat = new THREE.MeshLambertMaterial({ color: 0xF5D547 });
      const pepperMat = new THREE.MeshLambertMaterial({ color: 0xCC0000 });
      const broccoliMat = new THREE.MeshLambertMaterial({ color: 0x228B22 });
      const broccoliDark = new THREE.MeshLambertMaterial({ color: 0x1A6B1A });

      // Main body shell (back, left, right, top, bottom)
      // Back panel
      box(0.75, 1.7, 0.04, fridgeBody, 0, 0.85, -0.30);
      // Left side
      box(0.04, 1.7, 0.65, fridgeBody, -0.375, 0.85, 0);
      // Right side
      box(0.04, 1.7, 0.65, fridgeBody, 0.375, 0.85, 0);
      // Top
      box(0.80, 0.04, 0.68, fridgeBody, 0, 1.72, 0);
      // Bottom
      box(0.80, 0.06, 0.68, fridgeBody, 0, 0.03, 0);
      // Inner back wall (slightly lighter)
      box(0.68, 1.6, 0.02, fridgeInner, 0, 0.85, -0.26);

      // Separator between freezer and fridge compartment
      box(0.72, 0.04, 0.62, shelfMat, 0, 1.18, 0);

      // === FRIDGE SHELVES (bottom compartment: y=0.06 to y=1.18) ===
      box(0.66, 0.025, 0.52, shelfMat, 0, 0.40, -0.02);
      box(0.66, 0.025, 0.52, shelfMat, 0, 0.70, -0.02);
      box(0.66, 0.025, 0.52, shelfMat, 0, 1.0, -0.02);

      // Vegetable drawer at bottom (transparent-ish box)
      const drawerMat = new THREE.MeshLambertMaterial({ color: 0xDDEEDD, transparent: true, opacity: 0.5 });
      box(0.60, 0.22, 0.44, drawerMat, 0, 0.22, -0.02);

      // === FOOD IN VEGETABLE DRAWER (y ~ 0.11 to 0.33) ===
      // Carrots (cylinders laying on their side)
      const carrotGeo = new THREE.CylinderGeometry(0.025, 0.008, 0.18, 6);
      const c1 = new THREE.Mesh(carrotGeo, carrotMat);
      c1.rotation.z = Math.PI / 2; c1.position.set(-0.15, 0.14, 0.05); c1.name = 'fridgeFood1';
      group.add(c1);
      const c2 = new THREE.Mesh(carrotGeo, carrotMat);
      c2.rotation.z = Math.PI / 2; c2.rotation.y = 0.2; c2.position.set(-0.10, 0.14, 0.10); c2.name = 'fridgeFood2';
      group.add(c2);
      const c3 = new THREE.Mesh(carrotGeo, carrotMat);
      c3.rotation.z = Math.PI / 2; c3.rotation.y = -0.15; c3.position.set(-0.18, 0.17, 0.12); c3.name = 'fridgeFood3';
      group.add(c3);
      // Carrot greens (small box on top)
      box(0.04, 0.04, 0.03, carrotGreen, -0.22, 0.16, 0.05);
      box(0.04, 0.04, 0.03, carrotGreen, -0.17, 0.16, 0.10);

      // Lettuce head (sphere)
      const lettuceGeo = new THREE.SphereGeometry(0.08, 8, 6);
      const lettuce = new THREE.Mesh(lettuceGeo, lettuceMat);
      lettuce.scale.set(1, 0.7, 1);
      lettuce.position.set(0.10, 0.16, 0.05); lettuce.name = 'fridgeFood4';
      group.add(lettuce);
      // Lettuce leaves detail
      const leafGeo = new THREE.SphereGeometry(0.04, 6, 4);
      const leaf1 = new THREE.Mesh(leafGeo, lettuceDark);
      leaf1.position.set(0.14, 0.19, 0.09); leaf1.name = 'fridgeFood5';
      group.add(leaf1);

      // Eggplant (elongated sphere)
      const eggGeo = new THREE.SphereGeometry(0.035, 8, 6);
      const eggplant = new THREE.Mesh(eggGeo, eggplantMat);
      eggplant.scale.set(1, 1, 2.2);
      eggplant.rotation.x = 0.15;
      eggplant.position.set(0.0, 0.14, -0.05); eggplant.name = 'fridgeFood6';
      group.add(eggplant);

      // Bell pepper
      const pepperGeo = new THREE.SphereGeometry(0.04, 8, 6);
      const pepper = new THREE.Mesh(pepperGeo, pepperMat);
      pepper.scale.set(1, 0.85, 1);
      pepper.position.set(-0.02, 0.15, 0.13); pepper.name = 'fridgeFood7';
      group.add(pepper);
      box(0.015, 0.03, 0.015, tomatoStem, -0.02, 0.19, 0.13);

      // === FOOD ON FIRST SHELF (y ~ 0.41 to 0.68) ===
      // Tomatoes (small spheres)
      const tomatoGeo = new THREE.SphereGeometry(0.04, 8, 6);
      const t1 = new THREE.Mesh(tomatoGeo, tomatoMat);
      t1.position.set(-0.20, 0.45, 0.05); t1.name = 'fridgeFood8';
      group.add(t1);
      const t2 = new THREE.Mesh(tomatoGeo, tomatoMat);
      t2.position.set(-0.12, 0.45, 0.08); t2.name = 'fridgeFood9';
      group.add(t2);
      const t3 = new THREE.Mesh(tomatoGeo, tomatoMat);
      t3.position.set(-0.16, 0.45, 0.14); t3.name = 'fridgeFood10';
      group.add(t3);
      // Tomato stems
      box(0.01, 0.02, 0.01, tomatoStem, -0.20, 0.49, 0.05);
      box(0.01, 0.02, 0.01, tomatoStem, -0.12, 0.49, 0.08);
      box(0.01, 0.02, 0.01, tomatoStem, -0.16, 0.49, 0.14);

      // Lemons
      const lemonGeo = new THREE.SphereGeometry(0.03, 8, 6);
      const l1 = new THREE.Mesh(lemonGeo, lemonMat);
      l1.scale.set(1.2, 1, 1); l1.position.set(0.05, 0.44, 0.10); l1.name = 'fridgeFood11';
      group.add(l1);
      const l2 = new THREE.Mesh(lemonGeo, lemonMat);
      l2.scale.set(1.2, 1, 1); l2.position.set(0.12, 0.44, 0.07); l2.name = 'fridgeFood12';
      group.add(l2);

      // Cheese wedge (box)
      const cheeseWedge = box(0.10, 0.06, 0.08, cheeseMat, 0.22, 0.44, 0.0);
      cheeseWedge.name = 'fridgeFood13';

      // === FOOD ON SECOND SHELF (y ~ 0.71 to 0.98) ===
      // Apples
      const appleGeo = new THREE.SphereGeometry(0.038, 8, 6);
      const a1 = new THREE.Mesh(appleGeo, appleMat);
      a1.position.set(-0.20, 0.74, 0.05); a1.name = 'fridgeFood14';
      group.add(a1);
      const a2 = new THREE.Mesh(appleGeo, appleGreen);
      a2.position.set(-0.12, 0.74, 0.10); a2.name = 'fridgeFood15';
      group.add(a2);
      box(0.01, 0.03, 0.01, tomatoStem, -0.20, 0.78, 0.05);
      box(0.01, 0.03, 0.01, tomatoStem, -0.12, 0.78, 0.10);

      // Orange
      const orangeGeo = new THREE.SphereGeometry(0.04, 8, 6);
      const orange = new THREE.Mesh(orangeGeo, orangeMat);
      orange.position.set(0.0, 0.74, 0.07); orange.name = 'fridgeFood16';
      group.add(orange);

      // Broccoli
      const brocGeo = new THREE.SphereGeometry(0.045, 8, 6);
      const broc = new THREE.Mesh(brocGeo, broccoliMat);
      broc.scale.set(1, 0.7, 1);
      broc.position.set(0.15, 0.75, 0.05); broc.name = 'fridgeFood17';
      group.add(broc);
      box(0.02, 0.06, 0.02, broccoliDark, 0.15, 0.73, 0.05);

      // Milk carton
      box(0.07, 0.18, 0.07, milkMat, 0.25, 0.82, 0.0);

      // === FOOD ON THIRD SHELF (y ~ 1.01 to 1.16) ===
      // Water bottles
      const bottleGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.16, 8);
      const b1 = new THREE.Mesh(bottleGeo, bottleMat);
      b1.position.set(-0.22, 1.10, 0.0); b1.name = 'fridgeFood18';
      group.add(b1);
      const b2 = new THREE.Mesh(bottleGeo, bottleMat);
      b2.position.set(-0.15, 1.10, 0.0); b2.name = 'fridgeFood19';
      group.add(b2);
      const b3 = new THREE.Mesh(bottleGeo, bottleMat);
      b3.position.set(-0.08, 1.10, 0.0); b3.name = 'fridgeFood20';
      group.add(b3);

      // More tomatoes and a zucchini on this shelf
      const zuGeo = new THREE.CylinderGeometry(0.025, 0.02, 0.16, 8);
      const zucchini = new THREE.Mesh(zuGeo, new THREE.MeshLambertMaterial({ color: 0x3A7D2C }));
      zucchini.rotation.z = Math.PI / 2; zucchini.position.set(0.12, 1.04, 0.08); zucchini.name = 'fridgeFood21';
      group.add(zucchini);

      // A second orange
      const o2 = new THREE.Mesh(orangeGeo, orangeMat);
      o2.position.set(0.25, 1.04, 0.05); o2.name = 'fridgeFood22';
      group.add(o2);

      // === FREEZER COMPARTMENT (y ~ 1.20 to 1.70) ===
      // Freezer shelf
      box(0.66, 0.025, 0.52, shelfMat, 0, 1.45, -0.02);
      // Frozen item boxes
      box(0.15, 0.08, 0.12, new THREE.MeshLambertMaterial({ color: 0x8899BB }), -0.18, 1.24, 0.0);
      box(0.15, 0.08, 0.12, new THREE.MeshLambertMaterial({ color: 0x99AABB }), 0.08, 1.24, 0.0);
      // Ice cream tub
      const iceCreamGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.08, 10);
      const iceCream = new THREE.Mesh(iceCreamGeo, new THREE.MeshLambertMaterial({ color: 0xE8C8A0 }));
      iceCream.position.set(0.0, 1.50, 0.02); iceCream.name = 'fridgeFood23';
      group.add(iceCream);
      // Frozen bag
      box(0.12, 0.10, 0.06, new THREE.MeshLambertMaterial({ color: 0x66AA88, transparent: true, opacity: 0.7 }), -0.18, 1.50, 0.02);
      box(0.12, 0.10, 0.06, new THREE.MeshLambertMaterial({ color: 0x7799BB, transparent: true, opacity: 0.7 }), 0.18, 1.50, 0.02);

      // === DOORS WITH PIVOT (proper hinge-based opening) ===
      // Bottom door pivot (hinge on LEFT side: x = -0.375)
      const bottomPivot = new THREE.Group();
      bottomPivot.name = 'fridgeDoorBottom';
      bottomPivot.position.set(-0.375, 0, 0.325);
      // Door panel
      const bottomDoorMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.76, 1.12, 0.04),
        fridgeDark
      );
      bottomDoorMesh.position.set(0.38, 0.62, 0);
      bottomPivot.add(bottomDoorMesh);
      // Bottom handle (on right side of door)
      const bottomHandle = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, 0.20, 0.06),
        handleMat
      );
      bottomHandle.position.set(0.68, 0.75, 0.03);
      bottomPivot.add(bottomHandle);
      group.add(bottomPivot);

      // Top door pivot (hinge on LEFT side: x = -0.375)
      const topPivot = new THREE.Group();
      topPivot.name = 'fridgeDoorTop';
      topPivot.position.set(-0.375, 0, 0.325);
      // Door panel
      const topDoorMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.76, 0.50, 0.04),
        fridgeDark
      );
      topDoorMesh.position.set(0.38, 1.45, 0);
      topPivot.add(topDoorMesh);
      // Top handle (on right side of door)
      const topHandle = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, 0.12, 0.06),
        handleMat
      );
      topHandle.position.set(0.68, 1.45, 0.03);
      topPivot.add(topHandle);
      group.add(topPivot);

      // Door separator strip
      box(0.76, 0.025, 0.05, handleMat, 0, 1.19, 0.34);

      // Mark as interactive
      group.userData.interactive = 'fridge';
      group.userData.isOpen = false;
      group.userData.doorAngle = 0;
      break;
    }

    case 'wardrobe': {
      const wardrobeBody = new THREE.MeshLambertMaterial({ color: 0x8B6B42 });
      const wardrobeDoor = new THREE.MeshLambertMaterial({ color: 0x9B7B52 });
      const handleMatW = new THREE.MeshLambertMaterial({ color: 0xAAAAAA });
      const shirtMat = new THREE.MeshLambertMaterial({ color: 0x4A90D9 });
      const dressMat = new THREE.MeshLambertMaterial({ color: 0xCC3366 });
      const pantsMat2 = new THREE.MeshLambertMaterial({ color: 0x3B3B6D });
      const greenMat = new THREE.MeshLambertMaterial({ color: 0x4CAF50 });
      const orangeMat = new THREE.MeshLambertMaterial({ color: 0xFF9800 });
      const whiteMat = new THREE.MeshLambertMaterial({ color: 0xEEEEEE });
      // Main body (back + sides)
      // Back panel
      box(1.1, 1.8, 0.04, wardrobeBody, 0, 0.9, -0.25);
      // Left side panel
      box(0.04, 1.8, 0.55, wardrobeBody, -0.55, 0.9, 0);
      // Right side panel
      box(0.04, 1.8, 0.55, wardrobeBody, 0.55, 0.9, 0);
      // Top panel
      box(1.15, 0.06, 0.6, darkWood, 0, 1.82, 0);
      // Bottom panel
      box(1.15, 0.06, 0.6, darkWood, 0, 0.03, 0);

      // Internal hanging rod
      box(0.9, 0.04, 0.04, handleMatW, 0, 1.6, 0);

      // Hanging clothes on hangers (more visible, thicker, varied)
      // Hanger 1 - blue shirt
      box(0.22, 0.03, 0.04, handleMatW, -0.35, 1.58, 0);
      box(0.22, 0.55, 0.08, shirtMat, -0.35, 1.25, 0);
      // Hanger 2 - red dress
      box(0.22, 0.03, 0.04, handleMatW, -0.1, 1.58, 0);
      box(0.2, 0.7, 0.08, dressMat, -0.1, 1.18, 0);
      box(0.26, 0.2, 0.08, dressMat, -0.1, 0.88, 0); // flared bottom
      // Hanger 3 - green jacket
      box(0.22, 0.03, 0.04, handleMatW, 0.15, 1.58, 0);
      box(0.24, 0.5, 0.08, greenMat, 0.15, 1.28, 0);
      // Hanger 4 - orange top
      box(0.22, 0.03, 0.04, handleMatW, 0.38, 1.58, 0);
      box(0.2, 0.4, 0.08, orangeMat, 0.38, 1.33, 0);

      // Shelf at bottom with folded clothes stacks
      box(1.0, 0.03, 0.48, darkWood, 0, 0.4, -0.01);
      // Folded shirt stack
      box(0.22, 0.06, 0.18, shirtMat, -0.35, 0.46, -0.01);
      box(0.22, 0.06, 0.18, whiteMat, -0.35, 0.52, -0.01);
      // Folded pants
      box(0.25, 0.08, 0.2, pantsMat2, 0.0, 0.47, -0.01);
      // Folded towel/sweater
      box(0.22, 0.06, 0.18, orangeMat, 0.35, 0.46, -0.01);
      box(0.22, 0.06, 0.18, greenMat, 0.35, 0.52, -0.01);

      // Second shelf higher up
      box(1.0, 0.03, 0.48, darkWood, 0, 0.8, -0.01);
      box(0.2, 0.1, 0.15, pantsMat2, -0.3, 0.88, -0.01);
      box(0.2, 0.1, 0.15, dressMat, 0.3, 0.88, -0.01);

      // Left door with pivot (pivot at left edge: x = -0.55)
      const lPivot = new THREE.Group();
      lPivot.name = 'wardrobeDoorL';
      lPivot.position.set(-0.55, 0, 0.275);
      const lDoorMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.53, 1.7, 0.04),
        wardrobeDoor
      );
      lDoorMesh.position.set(0.265, 0.88, 0);
      lPivot.add(lDoorMesh);
      // Left handle
      const lHandle = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, 0.12, 0.06),
        handleMatW
      );
      lHandle.position.set(0.49, 0.9, 0.03);
      lPivot.add(lHandle);
      group.add(lPivot);

      // Right door with pivot (pivot at right edge: x = +0.55)
      const rPivot = new THREE.Group();
      rPivot.name = 'wardrobeDoorR';
      rPivot.position.set(0.55, 0, 0.275);
      const rDoorMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.53, 1.7, 0.04),
        wardrobeDoor
      );
      rDoorMesh.position.set(-0.265, 0.88, 0);
      rPivot.add(rDoorMesh);
      // Right handle
      const rHandle = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, 0.12, 0.06),
        handleMatW
      );
      rHandle.position.set(-0.49, 0.9, 0.03);
      rPivot.add(rHandle);
      group.add(rPivot);

      // Mark as interactive
      group.userData.interactive = 'wardrobe';
      group.userData.isOpen = false;
      group.userData.doorAngle = 0; // track animated angle
      break;
    }

    case 'painting': {
      const canvas_ = new THREE.MeshLambertMaterial({ color: 0xF5F0E0 });
      const gold = new THREE.MeshLambertMaterial({ color: 0xC9A84C });
      const paint1 = new THREE.MeshLambertMaterial({ color: 0x2266AA });
      const paint2 = new THREE.MeshLambertMaterial({ color: 0x44AA44 });
      const paint3 = new THREE.MeshLambertMaterial({ color: 0xDD8833 });
      const paint4 = new THREE.MeshLambertMaterial({ color: 0x88BBDD });
      // Frame
      box(0.75, 0.55, 0.04, gold, 0, 0.7, 0);
      // Canvas
      box(0.65, 0.45, 0.03, canvas_, 0, 0.7, 0.015);
      // Landscape painting: sky
      box(0.6, 0.2, 0.005, paint4, 0, 0.82, 0.033);
      // Mountains
      box(0.15, 0.15, 0.005, paint1, -0.15, 0.68, 0.033);
      box(0.12, 0.18, 0.005, paint1, 0.1, 0.7, 0.033);
      // Trees / ground
      box(0.6, 0.1, 0.005, paint2, 0, 0.55, 0.033);
      // Sun
      box(0.08, 0.08, 0.005, paint3, 0.22, 0.88, 0.033);
      // Frame corners (ornamental)
      box(0.06, 0.06, 0.05, gold, -0.37, 0.95, 0);
      box(0.06, 0.06, 0.05, gold, 0.37, 0.95, 0);
      box(0.06, 0.06, 0.05, gold, -0.37, 0.45, 0);
      box(0.06, 0.06, 0.05, gold, 0.37, 0.45, 0);
      break;
    }

    case 'tv': {
      const tvBody = new THREE.MeshLambertMaterial({ color: 0x1A1A1A });
      const screenMat = new THREE.MeshLambertMaterial({ color: 0x1144AA, emissive: 0x0022CC, emissiveIntensity: 0.6 });
      const standMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
      const statusLed = new THREE.MeshLambertMaterial({ color: 0x00FF00, emissive: 0x00FF00, emissiveIntensity: 1.0 });
      // TV body (flat panel)
      box(1.1, 0.65, 0.06, tvBody, 0, 0.75, 0);
      // Screen
      box(1.0, 0.56, 0.02, screenMat, 0, 0.76, 0.03);
      // Screen content — colored bars (test image)
      box(0.14, 0.5, 0.01, new THREE.MeshLambertMaterial({ color: 0xFF3333, emissive: 0xFF1111, emissiveIntensity: 0.3 }), -0.36, 0.76, 0.045);
      box(0.14, 0.5, 0.01, new THREE.MeshLambertMaterial({ color: 0x33FF33, emissive: 0x11FF11, emissiveIntensity: 0.3 }), -0.12, 0.76, 0.045);
      box(0.14, 0.5, 0.01, new THREE.MeshLambertMaterial({ color: 0x3366FF, emissive: 0x1133FF, emissiveIntensity: 0.3 }), 0.12, 0.76, 0.045);
      box(0.14, 0.5, 0.01, new THREE.MeshLambertMaterial({ color: 0xFFFF33, emissive: 0xFFFF11, emissiveIntensity: 0.3 }), 0.36, 0.76, 0.045);
      // Bottom bezel — brand logo area
      box(1.1, 0.04, 0.06, tvBody, 0, 0.44, 0);
      // Status LED
      box(0.03, 0.03, 0.02, statusLed, 0, 0.445, 0.04);
      // Stand neck
      box(0.06, 0.18, 0.06, standMat, 0, 0.3, 0);
      // Stand base
      box(0.45, 0.03, 0.25, standMat, 0, 0.2, 0);
      break;
    }

    case 'coffee-table': {
      const tableMat = new THREE.MeshLambertMaterial({ color: 0x8B6B42 });
      const lampBase = new THREE.MeshLambertMaterial({ color: 0x2A2A2A });
      const lampShade = new THREE.MeshLambertMaterial({ color: 0xF5E6C8, transparent: true, opacity: 0.85 });
      const lampGlow = new THREE.MeshLambertMaterial({ color: 0xFFDD66, emissive: 0xFFBB33, emissiveIntensity: 0.8 });
      // Table top
      box(1.1, 0.06, 0.55, tableMat, 0, 0.35, 0);
      // Legs (short — coffee table height)
      box(0.06, 0.32, 0.06, darkWood, -0.48, 0.16, -0.22);
      box(0.06, 0.32, 0.06, darkWood, 0.48, 0.16, -0.22);
      box(0.06, 0.32, 0.06, darkWood, -0.48, 0.16, 0.22);
      box(0.06, 0.32, 0.06, darkWood, 0.48, 0.16, 0.22);
      // Lower shelf
      box(0.95, 0.04, 0.4, darkWood, 0, 0.12, 0);
      // Lamp on table — base
      box(0.12, 0.04, 0.12, lampBase, 0.35, 0.4, 0);
      // Lamp stem
      box(0.04, 0.3, 0.04, lampBase, 0.35, 0.56, 0);
      // Lamp shade (conical approximation)
      box(0.2, 0.18, 0.2, lampShade, 0.35, 0.78, 0);
      // Light bulb glow
      const bulb = box(0.08, 0.08, 0.08, lampGlow, 0.35, 0.72, 0);
      bulb.name = 'lampBulb';
      // Point light (toggleable)
      const lampLight = new THREE.PointLight(0xFFDD66, 0.8, 5);
      lampLight.position.set(0.35, 0.8, 0);
      lampLight.name = 'lampLight';
      group.add(lampLight);
      // Mark as interactive lamp
      group.userData.interactive = 'lamp';
      group.userData.isOn = true;
      break;
    }

    case 'speaker': {
      const spBody = new THREE.MeshLambertMaterial({ color: 0x222222 });
      const grille = new THREE.MeshLambertMaterial({ color: 0x333333 });
      const cone = new THREE.MeshLambertMaterial({ color: 0x555555 });
      const rim = new THREE.MeshLambertMaterial({ color: 0x888888 });
      const led = new THREE.MeshLambertMaterial({ color: 0x00AAFF, emissive: 0x0088FF, emissiveIntensity: 0.6 });
      // Speaker body
      box(0.4, 0.7, 0.35, spBody, 0, 0.35, 0);
      // Grille front
      box(0.36, 0.6, 0.02, grille, 0, 0.38, 0.18);
      // Woofer (large)
      box(0.22, 0.22, 0.03, cone, 0, 0.28, 0.2);
      box(0.26, 0.26, 0.02, rim, 0, 0.28, 0.19);
      // Tweeter (small)
      box(0.1, 0.1, 0.03, cone, 0, 0.55, 0.2);
      box(0.13, 0.13, 0.02, rim, 0, 0.55, 0.19);
      // LED indicator strip
      box(0.3, 0.02, 0.02, led, 0, 0.68, 0.18);
      // Top panel
      box(0.4, 0.02, 0.35, new THREE.MeshLambertMaterial({ color: 0x1A1A1A }), 0, 0.71, 0);
      // Bass port (back)
      box(0.12, 0.06, 0.02, new THREE.MeshLambertMaterial({ color: 0x111111 }), 0, 0.15, -0.18);
      break;
    }

    case 'drum-kit': {
      const shell = new THREE.MeshLambertMaterial({ color: 0xCC3333 });
      const shellBlue = new THREE.MeshLambertMaterial({ color: 0x2255AA });
      const metalRim = new THREE.MeshLambertMaterial({ color: 0xCCCCCC });
      const cymbalMat = new THREE.MeshLambertMaterial({ color: 0xD4AA44 });
      const drumHead = new THREE.MeshLambertMaterial({ color: 0xF0E8D8 });
      const seatMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
      const stickMat = new THREE.MeshLambertMaterial({ color: 0xC8A46A });

      // Bass drum (large, on its side)
      box(0.65, 0.6, 0.35, shell, 0, 0.32, 0);
      box(0.6, 0.55, 0.02, drumHead, 0, 0.32, 0.18);
      box(0.6, 0.55, 0.02, drumHead, 0, 0.32, -0.18);
      box(0.65, 0.02, 0.35, metalRim, 0, 0.62, 0);

      // Snare drum (front left)
      box(0.3, 0.15, 0.3, metalRim, -0.45, 0.6, 0.25);
      box(0.26, 0.02, 0.26, drumHead, -0.45, 0.68, 0.25);
      // Snare stand
      box(0.04, 0.4, 0.04, metalRim, -0.45, 0.4, 0.25);

      // Tom 1 (high tom, on bass drum)
      box(0.22, 0.16, 0.22, shellBlue, -0.15, 0.82, 0);
      box(0.2, 0.02, 0.2, drumHead, -0.15, 0.9, 0);
      // Tom 2 (mid tom, on bass drum)
      box(0.22, 0.16, 0.22, shellBlue, 0.15, 0.82, 0);
      box(0.2, 0.02, 0.2, drumHead, 0.15, 0.9, 0);

      // Floor tom (right)
      box(0.32, 0.25, 0.32, shell, 0.5, 0.45, 0.1);
      box(0.28, 0.02, 0.28, drumHead, 0.5, 0.58, 0.1);
      // Floor tom legs
      box(0.04, 0.32, 0.04, metalRim, 0.38, 0.2, 0.0);
      box(0.04, 0.32, 0.04, metalRim, 0.62, 0.2, 0.2);

      // Hi-hat (left)
      box(0.04, 0.8, 0.04, metalRim, -0.65, 0.4, 0.1);
      box(0.28, 0.02, 0.28, cymbalMat, -0.65, 0.82, 0.1);
      box(0.28, 0.02, 0.28, cymbalMat, -0.65, 0.85, 0.1);

      // Crash cymbal (right)
      box(0.04, 0.95, 0.04, metalRim, 0.55, 0.48, -0.35);
      box(0.32, 0.02, 0.32, cymbalMat, 0.55, 0.98, -0.35);

      // Ride cymbal (far right)
      box(0.04, 0.85, 0.04, metalRim, 0.75, 0.43, 0.25);
      box(0.35, 0.02, 0.35, cymbalMat, 0.75, 0.88, 0.25);

      // Drum throne (seat behind)
      box(0.04, 0.45, 0.04, metalRim, 0, 0.23, -0.55);
      box(0.3, 0.06, 0.3, seatMat, 0, 0.48, -0.55);

      // Drumsticks (resting on snare)
      box(0.03, 0.03, 0.3, stickMat, -0.38, 0.7, 0.25);
      box(0.03, 0.03, 0.3, stickMat, -0.52, 0.7, 0.25);

      // Bass drum pedal
      box(0.1, 0.06, 0.15, metalRim, 0, 0.03, 0.22);
      box(0.04, 0.15, 0.04, metalRim, 0, 0.1, 0.28);
      break;
    }
  }

  return group;
}

// Wall-mounted objects that should be placed flush against a wall surface
const WALL_MOUNTED_OBJECTS = new Set(['sword-rack', 'painting', 'mirror', 'tv']);

// Place object on click (when in object mode)
function placeObjectAtHit(hit) {
  if (!selectedObjectType || placeMode !== 'object') return;
  const obj = buildVoxelObject(selectedObjectType);

  if (WALL_MOUNTED_OBJECTS.has(selectedObjectType)) {
    // Wall-mounted: determine which face of the hit block we're placing against
    const dx = hit.placeX - hit.hitX;
    const dy = hit.placeY - hit.hitY;
    const dz = hit.placeZ - hit.hitZ;
    // Base position: center of the air block
    let px = hit.placeX + 0.5;
    let py = hit.placeY;
    let pz = hit.placeZ + 0.5;
    let wallRotation = 0;

    if (dx === 1) {       // wall is to the -X, object faces +X
      px = hit.hitX + 1.02; // flush against wall face
      wallRotation = Math.PI / 2;
    } else if (dx === -1) { // wall is to the +X, object faces -X
      px = hit.hitX - 0.02;
      wallRotation = -Math.PI / 2;
    } else if (dz === 1) {  // wall is to the -Z, object faces +Z
      pz = hit.hitZ + 1.02;
      wallRotation = 0;
    } else if (dz === -1) { // wall is to the +Z, object faces -Z
      pz = hit.hitZ - 0.02;
      wallRotation = Math.PI;
    } else if (dy === 1) {  // placing on top of a block (fallback — treat like floor)
      py = hit.placeY;
      wallRotation = objectRotation * (Math.PI / 2);
    }

    obj.position.set(px, py, pz);
    // For horizontal placement use the auto wall rotation; user R-key rotation still added
    if (dy !== 0) {
      obj.rotation.y = wallRotation;
    } else {
      obj.rotation.y = wallRotation;
    }
  } else {
    // Floor objects: place on top of the hit block, centered
    obj.position.set(
      hit.placeX + 0.5,
      hit.placeY,
      hit.placeZ + 0.5
    );
    // Orient object using manual rotation (R key) snapped to 90° increments
    obj.rotation.y = objectRotation * (Math.PI / 2);
  }

  placedObjects.add(obj);
  saveObjectsToStorage();
}

// Save/load placed objects to localStorage
function saveObjectsToStorage() {
  const data = [];
  placedObjects.children.forEach(obj => {
    const typeName = obj.name.split('_')[1];
    data.push({
      type: typeName,
      x: obj.position.x,
      y: obj.position.y,
      z: obj.position.z,
      ry: obj.rotation.y
    });
  });
  localStorage.setItem('voxel_objects', JSON.stringify(data));
}

const DEFAULT_VOXEL_OBJECTS = [{"type":"door","x":51.5,"y":15,"z":40.5,"ry":4.71238898038469},{"type":"wardrobe","x":57.5,"y":15,"z":40.5,"ry":4.71238898038469},{"type":"coat-rack","x":55.5,"y":15,"z":39.5,"ry":0},{"type":"fridge","x":57.5,"y":15,"z":44.5,"ry":4.71238898038469},{"type":"drum-kit","x":54.5,"y":15,"z":47.5,"ry":0},{"type":"speaker","x":52.5,"y":15,"z":47.5,"ry":3.141592653589793},{"type":"speaker","x":56.5,"y":15,"z":47.5,"ry":3.141592653589793},{"type":"rug","x":54.5,"y":15,"z":44.5,"ry":4.71238898038469},{"type":"sword-rack","x":57.98,"y":17,"z":45.5,"ry":-1.5707963267948966},{"type":"painting","x":53.5,"y":16,"z":39.02,"ry":0},{"type":"mirror","x":54.5,"y":16,"z":39.02,"ry":0},{"type":"sofa","x":53.5,"y":15,"z":39.5,"ry":0},{"type":"bed","x":57.5,"y":15,"z":48.5,"ry":4.71238898038469}];

function loadObjectsFromStorage() {
  let raw = localStorage.getItem('voxel_objects');
  let data;
  if (!raw) {
    data = DEFAULT_VOXEL_OBJECTS;
  } else {
    try { data = JSON.parse(raw); } catch(e) { data = DEFAULT_VOXEL_OBJECTS; }
  }
  try {
    data.forEach(entry => {
      const obj = buildVoxelObject(entry.type);
      obj.position.set(entry.x, entry.y, entry.z);
      obj.rotation.y = entry.ry || 0;
      placedObjects.add(obj);
    });
  } catch(e) { /* ignore corrupt data */ }
}

// Load saved objects on startup
loadObjectsFromStorage();

// Raycaster for block interaction
const raycaster = new THREE.Raycaster();
raycaster.far = 20;
const mouse = new THREE.Vector2();

// Ghost preview block
const ghostMat = new THREE.MeshLambertMaterial({ color: 0x00ff00, transparent: true, opacity: 0.35 });
const ghostMesh = new THREE.Mesh(new THREE.BoxGeometry(1.01, 1.01, 1.01), ghostMat);
ghostMesh.name = 'ghostPreview';
ghostMesh.visible = false;
scene.add(ghostMesh);

// Remove highlight
const removeMat = new THREE.MeshLambertMaterial({ color: 0xff0000, transparent: true, opacity: 0.3 });
const removeMesh = new THREE.Mesh(new THREE.BoxGeometry(1.02, 1.02, 1.02), removeMat);
removeMesh.name = 'removeHighlight';
removeMesh.visible = false;
scene.add(removeMesh);

// Ghost object preview for furniture placement
let ghostObjectGroup = null;
let ghostObjectType = null;
const ghostObjectMat = new THREE.MeshLambertMaterial({ color: 0x44ff88, transparent: true, opacity: 0.3 });

function updateGhostObject(type, x, y, z, rotation, hit) {
  // Recreate if type changed
  if (ghostObjectType !== type || !ghostObjectGroup) {
    if (ghostObjectGroup) { scene.remove(ghostObjectGroup); }
    ghostObjectGroup = buildVoxelObject(type);
    // Make all children semi-transparent green
    ghostObjectGroup.traverse(child => {
      if (child.isMesh) {
        child.material = ghostObjectMat;
        child.castShadow = false;
        child.receiveShadow = false;
      }
    });
    ghostObjectGroup.name = 'ghostObject';
    scene.add(ghostObjectGroup);
    ghostObjectType = type;
  }

  if (WALL_MOUNTED_OBJECTS.has(type) && hit) {
    const dx = hit.placeX - hit.hitX;
    const dy = hit.placeY - hit.hitY;
    const dz = hit.placeZ - hit.hitZ;
    let px = x + 0.5, py = y, pz = z + 0.5;
    let wallRotation = 0;

    if (dx === 1) {
      px = hit.hitX + 1.02;
      wallRotation = Math.PI / 2;
    } else if (dx === -1) {
      px = hit.hitX - 0.02;
      wallRotation = -Math.PI / 2;
    } else if (dz === 1) {
      pz = hit.hitZ + 1.02;
      wallRotation = 0;
    } else if (dz === -1) {
      pz = hit.hitZ - 0.02;
      wallRotation = Math.PI;
    }

    ghostObjectGroup.position.set(px, py, pz);
    ghostObjectGroup.rotation.y = (dy !== 0) ? rotation * (Math.PI / 2) : wallRotation;
  } else {
    ghostObjectGroup.position.set(x + 0.5, y, z + 0.5);
    ghostObjectGroup.rotation.y = rotation * (Math.PI / 2);
  }
  ghostObjectGroup.visible = true;
}

function hideGhostObject() {
  if (ghostObjectGroup) ghostObjectGroup.visible = false;
}

// Ray march through voxels to find targeted block
function raycastVoxel(origin, direction, maxDist, hitWater = false) {
  const step = 0.15;
  const pos = origin.clone();
  const dir = direction.clone().normalize().multiplyScalar(step);
  let prevBx = -999, prevBy = -999, prevBz = -999;

  for (let d = 0; d < maxDist; d += step) {
    const bx = Math.floor(pos.x), by = Math.floor(pos.y), bz = Math.floor(pos.z);
    if (bx >= 0 && bx < WORLD_SIZE && by >= 0 && by < WORLD_HEIGHT && bz >= 0 && bz < WORLD_SIZE) {
      const block = getBlock(bx, by, bz);
      if (block !== BLOCK_TYPES.AIR &&
          (hitWater || block !== BLOCK_TYPES.WATER) &&
          block !== BLOCK_TYPES.FLOWER_WHITE && block !== BLOCK_TYPES.FLOWER_RED) {
        return {
          hitX: bx, hitY: by, hitZ: bz,
          placeX: prevBx, placeY: prevBy, placeZ: prevBz,
          blockType: block
        };
      }
      prevBx = bx; prevBy = by; prevBz = bz;
    }
    pos.add(dir);
  }
  return null;
}

// Get ray from screen center
function getCenterRay() {
  raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  return { origin: raycaster.ray.origin, direction: raycaster.ray.direction };
}

// Place block or object on left click
renderer.domElement.addEventListener('click', (e) => {
  if (e.button !== 0 || isRightDragging || e.altKey) return;

  mousePos.x = (e.clientX / window.innerWidth) * 2 - 1;
  mousePos.y = -(e.clientY / window.innerHeight) * 2 + 1;
  const ray = getMouseRay();
  const hit = raycastVoxel(ray.origin, ray.direction, 20);
  if (!hit || hit.placeX < 0 || hit.placeX >= WORLD_SIZE || hit.placeY < 0 || hit.placeY >= WORLD_HEIGHT || hit.placeZ < 0 || hit.placeZ >= WORLD_SIZE) return;

  // Don't place inside player
  const px = Math.floor(player.position.x), pz = Math.floor(player.position.z);
  const py1 = Math.floor(player.position.y), py2 = Math.floor(player.position.y + 1);
  if (hit.placeX === px && hit.placeZ === pz && (hit.placeY === py1 || hit.placeY === py2)) return;

  // Object placement mode
  if (placeMode === 'object' && selectedObjectType) {
    placeObjectAtHit(hit);
    return;
  }

  setBlock(hit.placeX, hit.placeY, hit.placeZ, selectedBlockType);
  trackEdit(hit.placeX, hit.placeY, hit.placeZ, selectedBlockType);
  // Update height map if needed
  if (hit.placeY >= getHeightCPU(hit.placeX, hit.placeZ)) {
    heightCPU[hit.placeX + hit.placeZ * WORLD_SIZE] = hit.placeY;
  }
  // Instant visual feedback — add temp mesh immediately
  addTempBlock(hit.placeX, hit.placeY, hit.placeZ, selectedBlockType);
  markDirty(hit.placeX, hit.placeY, hit.placeZ);
  scheduleRebuild();
});

// Remove block on right click (only when not dragging camera)
let rightClickStart = { x: 0, y: 0 };
renderer.domElement.addEventListener('mousedown', (e) => {
  if (e.button === 2) {
    rightClickStart.x = e.clientX;
    rightClickStart.y = e.clientY;
  }
});
renderer.domElement.addEventListener('mouseup', (e) => {
  if (e.button === 2) {
    const dx = Math.abs(e.clientX - rightClickStart.x);
    const dy = Math.abs(e.clientY - rightClickStart.y);
    // Only remove if it was a click, not a drag
    if (dx < 5 && dy < 5) {
      mousePos.x = (e.clientX / window.innerWidth) * 2 - 1;
      mousePos.y = -(e.clientY / window.innerHeight) * 2 + 1;
      const ray = getMouseRay();

      // Check if right-clicking a placed object first
      raycaster.set(ray.origin, ray.direction);
      const objHits = raycaster.intersectObjects(placedObjects.children, true);
      if (objHits.length > 0) {
        // Find the top-level object group
        let target = objHits[0].object;
        while (target.parent && target.parent !== placedObjects) target = target.parent;
        if (target.parent === placedObjects) {
          placedObjects.remove(target);
          saveObjectsToStorage();
          return;
        }
      }

      const hit = raycastVoxel(ray.origin, ray.direction, 20, true);
      if (hit && hit.hitX >= 0 && hit.hitX < WORLD_SIZE && hit.hitY >= 0 && hit.hitY < WORLD_HEIGHT && hit.hitZ >= 0 && hit.hitZ < WORLD_SIZE) {
        // Don't remove bedrock
        if (hit.blockType === BLOCK_TYPES.BEDROCK) return;
        setBlock(hit.hitX, hit.hitY, hit.hitZ, BLOCK_TYPES.AIR);
        trackEdit(hit.hitX, hit.hitY, hit.hitZ, BLOCK_TYPES.AIR);
        // Update height map
        if (hit.hitY >= getHeightCPU(hit.hitX, hit.hitZ)) {
          let newH = -1;
          for (let y = hit.hitY; y >= 0; y--) {
            if (getBlock(hit.hitX, y, hit.hitZ) !== BLOCK_TYPES.AIR) { newH = y; break; }
          }
          heightCPU[hit.hitX + hit.hitZ * WORLD_SIZE] = newH;
        }
        removeTempBlock(hit.hitX, hit.hitY, hit.hitZ);
        markDirty(hit.hitX, hit.hitY, hit.hitZ);
        scheduleRebuild();
      }
    }
  }
});

// Track mouse position
const mousePos = new THREE.Vector2(0, 0);
let mouseDirty = true;
window.addEventListener('mousemove', (e) => {
  mousePos.x = (e.clientX / window.innerWidth) * 2 - 1;
  mousePos.y = -(e.clientY / window.innerHeight) * 2 + 1;
  mouseDirty = true;
});

function getMouseRay() {
  raycaster.setFromCamera(mousePos, camera);
  return { origin: raycaster.ray.origin, direction: raycaster.ray.direction };
}

// Update ghost/remove preview only when mouse moves or camera changes
function updateBlockPreview() {
  if (!mouseDirty) return;
  mouseDirty = false;
  const ray = getMouseRay();
  const hit = raycastVoxel(ray.origin, ray.direction, 20);

  if (hit) {
    const validPlace = hit.placeX >= 0 && hit.placeX < WORLD_SIZE && hit.placeY >= 0 && hit.placeY < WORLD_HEIGHT && hit.placeZ >= 0 && hit.placeZ < WORLD_SIZE;

    if (placeMode === 'object' && selectedObjectType && validPlace) {
      // Show ghost object preview
      updateGhostObject(selectedObjectType, hit.placeX, hit.placeY, hit.placeZ, objectRotation, hit);
      ghostMesh.visible = false;
    } else if (validPlace) {
      // Show green ghost block where block would be placed
      ghostMesh.position.set(hit.placeX + 0.5, hit.placeY + 0.5, hit.placeZ + 0.5);
      ghostMesh.visible = true;
      hideGhostObject();
    } else {
      ghostMesh.visible = false;
      hideGhostObject();
    }
    // Show red highlight on block that would be removed
    removeMesh.position.set(hit.hitX + 0.5, hit.hitY + 0.5, hit.hitZ + 0.5);
    removeMesh.visible = true;
  } else {
    ghostMesh.visible = false;
    removeMesh.visible = false;
    hideGhostObject();
  }
}

// ============================================
// INTERACTIVE OBJECT SYSTEM (Fridge, Wardrobe)
// ============================================
const interactTooltip = document.getElementById('interact-tooltip');
const interactTooltipText = document.getElementById('interact-tooltip-text');
const wardrobeMenu = document.getElementById('wardrobe-menu');
const wardrobeGrid = document.getElementById('wardrobe-grid');
const wardrobeCloseBtn = document.getElementById('wardrobe-close-btn');
const fridgeMenu = document.getElementById('fridge-menu');
const fridgeGrid = document.getElementById('fridge-grid');
const fridgeCloseBtn = document.getElementById('fridge-close-btn');

let hoveredInteractive = null; // currently hovered interactive object

// Clothing system
const CLOTHING_OPTIONS = [
  { id: 'default', icon: '👤', name: 'Default Outfit', shirt: 0x4A90D9, pants: 0x3B3B6D, shoes: 0x555555 },
  { id: 'knight', icon: '⚔️', name: 'Knight', shirt: 0x888888, pants: 0x666666, shoes: 0x444444 },
  { id: 'red-outfit', icon: '🔴', name: 'Red Outfit', shirt: 0xCC3333, pants: 0x222222, shoes: 0x333333 },
  { id: 'green-outfit', icon: '🟢', name: 'Green Outfit', shirt: 0x338833, pants: 0x445544, shoes: 0x3A3A3A },
  { id: 'royal', icon: '👑', name: 'Royal Outfit', shirt: 0x6B3FA0, pants: 0x2A1A50, shoes: 0x1A1A2A },
  { id: 'sport', icon: '⚽', name: 'Sporty', shirt: 0xFFFFFF, pants: 0x222222, shoes: 0xDD4444 },
  { id: 'beach', icon: '🏖️', name: 'Beach', shirt: 0xFF9944, pants: 0x4488BB, shoes: 0xCCBB88 },
  { id: 'formal', icon: '🎩', name: 'Formal', shirt: 0x1A1A2A, pants: 0x1A1A2A, shoes: 0x111111 },
  { id: 'pink', icon: '🌸', name: 'Pink Outfit', shirt: 0xDD66AA, pants: 0xFFCCDD, shoes: 0xCC5599 },
];

let currentClothing = 'default';

// Fridge contents
const FRIDGE_ITEMS = [
  { icon: '🥕', name: 'Carottes' },
  { icon: '🥬', name: 'Salade' },
  { icon: '🧀', name: 'Fromage' },
  { icon: '🍅', name: 'Tomates' },
  { icon: '🥛', name: 'Lait' },
  { icon: '🍎', name: 'Pommes' },
  { icon: '🥚', name: 'Oeufs' },
  { icon: '🧈', name: 'Beurre' },
  { icon: '🍕', name: 'Pizza (restes)' },
];

// Populate fridge grid
FRIDGE_ITEMS.forEach(item => {
  const card = document.createElement('div');
  card.className = 'fridge-item-card';
  card.innerHTML = `<div class="fridge-icon">${item.icon}</div><span>${item.name}</span>`;
  fridgeGrid.appendChild(card);
});

// Build clothing grid
function buildWardrobeGrid() {
  wardrobeGrid.innerHTML = '';
  CLOTHING_OPTIONS.forEach(opt => {
    const card = document.createElement('div');
    card.className = 'clothing-card' + (currentClothing === opt.id ? ' worn' : '');
    card.innerHTML = `<div class="cloth-icon">${opt.icon}</div><span>${opt.name}</span>`;
    card.addEventListener('click', () => {
      currentClothing = opt.id;
      applyClothing(opt);
      updatePreviewClothing(opt);
      buildWardrobeGrid();
    });
    wardrobeGrid.appendChild(card);
  });
}

function applyClothing(opt) {
  // Update the player skinned mesh materials
  const skinnedGroup = playerGroup.getObjectByName('skinnedPlayer');
  if (!skinnedGroup) return;
  const bodyMesh = skinnedGroup.getObjectByName('playerBody');
  const lUpperArm = skinnedGroup.getObjectByName('playerLeftUpperArm');
  const rUpperArm = skinnedGroup.getObjectByName('playerRightUpperArm');
  const lUpperLeg = skinnedGroup.getObjectByName('playerLeftUpperLeg');
  const rUpperLeg = skinnedGroup.getObjectByName('playerRightUpperLeg');
  const lLowerLeg = skinnedGroup.getObjectByName('playerLeftLowerLeg');
  const rLowerLeg = skinnedGroup.getObjectByName('playerRightLowerLeg');

  const shirtMat = new THREE.MeshLambertMaterial({ color: opt.shirt });
  const pantsMat = new THREE.MeshLambertMaterial({ color: opt.pants });
  const shoeMat = new THREE.MeshLambertMaterial({ color: opt.shoes });

  if (bodyMesh) bodyMesh.material = shirtMat;
  if (lUpperArm) lUpperArm.material = shirtMat;
  if (rUpperArm) rUpperArm.material = shirtMat;
  if (lUpperLeg) lUpperLeg.material = pantsMat;
  if (rUpperLeg) rUpperLeg.material = pantsMat;
  if (lLowerLeg) lLowerLeg.material = shoeMat;
  if (rLowerLeg) rLowerLeg.material = shoeMat;

  // Save clothing choice
  localStorage.setItem('voxel_clothing', opt.id);
}

// Load saved clothing
function loadClothing() {
  const saved = localStorage.getItem('voxel_clothing');
  if (saved) {
    const opt = CLOTHING_OPTIONS.find(c => c.id === saved);
    if (opt) {
      currentClothing = saved;
      // Defer application until player model is ready
      const waitForModel = setInterval(() => {
        if (playerModelReady) {
          applyClothing(opt);
          clearInterval(waitForModel);
        }
      }, 100);
    }
  }
}
loadClothing();

// ============================================
// WARDROBE 3D PLAYER PREVIEW
// ============================================
let previewRenderer = null;
let previewScene = null;
let previewCamera = null;
let previewPlayerGroup = null;
let previewAnimId = null;
let previewActive = false;

async function initWardrobePreview() {
  if (previewRenderer) return; // already initialized

  const canvas = document.getElementById('wardrobe-preview-canvas');
  if (!canvas) return;

  // Create a separate renderer for the preview
  previewRenderer = new THREE.WebGPURenderer({ canvas, antialias: true, alpha: true, forceWebGL: true });
  previewRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  previewRenderer.setClearColor(0x000000, 0);
  await previewRenderer.init();

  // Preview scene
  previewScene = new THREE.Scene();

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
  previewScene.add(ambientLight);
  const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
  dirLight.position.set(2, 3, 4);
  previewScene.add(dirLight);
  const backLight = new THREE.DirectionalLight(0x8899cc, 0.4);
  backLight.position.set(-2, 1, -3);
  previewScene.add(backLight);

  // Subtle ground disc
  const groundGeo = new THREE.CircleGeometry(0.7, 32);
  const groundMat = new THREE.MeshLambertMaterial({ color: 0x333340, transparent: true, opacity: 0.5 });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  previewScene.add(ground);

  // Camera
  previewCamera = new THREE.PerspectiveCamera(30, 250 / 370, 0.1, 50);
  previewCamera.position.set(0, 1.1, 3.2);
  previewCamera.lookAt(0, 0.9, 0);
}

function buildPreviewPlayer(clothingOpt) {
  // Remove old preview player
  if (previewPlayerGroup) {
    previewScene.remove(previewPlayerGroup);
    previewPlayerGroup.traverse(child => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
        else child.material.dispose();
      }
    });
  }

  previewPlayerGroup = new THREE.Group();
  previewPlayerGroup.name = 'previewPlayer';

  // Use same proportions as the real player
  const skinColor = new THREE.Color(0x8B5E3C);
  const shirtColor = new THREE.Color(clothingOpt.shirt);
  const pantsColor = new THREE.Color(clothingOpt.pants);
  const shoeColor = new THREE.Color(clothingOpt.shoes);
  const hairColor = new THREE.Color(0x4A2E14);

  const skinMat = new THREE.MeshLambertMaterial({ color: skinColor });
  const shirtMat = new THREE.MeshLambertMaterial({ color: shirtColor });
  const pantsMat = new THREE.MeshLambertMaterial({ color: pantsColor });
  const shoeMat = new THREE.MeshLambertMaterial({ color: shoeColor });
  const hairMat = new THREE.MeshLambertMaterial({ color: hairColor });
  const eyeMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
  const noseMat = new THREE.MeshLambertMaterial({ color: skinColor.clone().multiplyScalar(0.9) });
  const mouthMat = new THREE.MeshLambertMaterial({ color: 0x8B4040 });

  function box(w, h, d, mat, x, y, z) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, y, z);
    previewPlayerGroup.add(mesh);
    return mesh;
  }

  // Body (torso)
  box(0.5, 0.7, 0.25, shirtMat, 0, 1.15, 0);
  // Head
  box(0.5, 0.5, 0.5, skinMat, 0, 1.75, 0);
  // Hair
  box(0.52, 0.15, 0.52, hairMat, 0, 2.07, 0);
  // Eyes
  box(0.08, 0.08, 0.06, eyeMat, -0.1, 1.8, 0.26);
  box(0.08, 0.08, 0.06, eyeMat, 0.1, 1.8, 0.26);
  // Nose
  box(0.06, 0.08, 0.06, noseMat, 0, 1.72, 0.28);
  // Mouth
  box(0.14, 0.03, 0.04, mouthMat, 0, 1.63, 0.26);
  // Left upper arm
  box(0.22, 0.35, 0.22, shirtMat, -0.36, 1.32, 0);
  // Left lower arm
  box(0.2, 0.35, 0.2, skinMat, -0.36, 0.97, 0);
  // Right upper arm
  box(0.22, 0.35, 0.22, shirtMat, 0.36, 1.32, 0);
  // Right lower arm
  box(0.2, 0.35, 0.2, skinMat, 0.36, 0.97, 0);
  // Left upper leg
  box(0.22, 0.375, 0.22, pantsMat, -0.12, 0.61, 0);
  // Left lower leg
  box(0.22, 0.375, 0.22, shoeMat, -0.12, 0.24, 0);
  // Right upper leg
  box(0.22, 0.375, 0.22, pantsMat, 0.12, 0.61, 0);
  // Right lower leg
  box(0.22, 0.375, 0.22, shoeMat, 0.12, 0.24, 0);

  previewScene.add(previewPlayerGroup);
}

function startPreviewRendering() {
  if (previewActive) return;
  previewActive = true;

  const canvas = document.getElementById('wardrobe-preview-canvas');
  if (!canvas) return;

  // Set proper canvas size
  const rect = canvas.getBoundingClientRect();
  const w = Math.floor(rect.width * Math.min(window.devicePixelRatio, 2));
  const h = Math.floor(rect.height * Math.min(window.devicePixelRatio, 2));
  previewRenderer.setSize(rect.width, rect.height, false);
  canvas.width = w;
  canvas.height = h;
  previewCamera.aspect = rect.width / rect.height;
  previewCamera.updateProjectionMatrix();

  let previewTime = 0;
  function animatePreview() {
    if (!previewActive) return;
    previewAnimId = requestAnimationFrame(animatePreview);
    previewTime += 0.015;

    // Slowly rotate the preview player
    if (previewPlayerGroup) {
      previewPlayerGroup.rotation.y = Math.sin(previewTime * 0.5) * 0.4;
    }

    previewRenderer.render(previewScene, previewCamera);
  }
  animatePreview();
}

function stopPreviewRendering() {
  previewActive = false;
  if (previewAnimId) {
    cancelAnimationFrame(previewAnimId);
    previewAnimId = null;
  }
}

async function updatePreviewClothing(opt) {
  if (!previewScene) await initWardrobePreview();
  buildPreviewPlayer(opt);
}

async function openWardrobeMenu() {
  await initWardrobePreview();
  // Build preview with current clothing
  const currentOpt = CLOTHING_OPTIONS.find(c => c.id === currentClothing) || CLOTHING_OPTIONS[0];
  buildPreviewPlayer(currentOpt);
  buildWardrobeGrid();
  wardrobeMenu.classList.remove('hidden');
  startPreviewRendering();
}

function closeWardrobeMenu() {
  wardrobeMenu.classList.add('hidden');
  stopPreviewRendering();
}

// Fridge smooth open/close animation (pivot-based, like wardrobe)
const fridgeAnimations = [];
function toggleFridge(fridgeObj) {
  const isOpen = fridgeObj.userData.isOpen;
  const targetAngle = isOpen ? 0 : -Math.PI * 0.45; // negative = open outward (hinge on left)
  const existIdx = fridgeAnimations.findIndex(a => a.obj === fridgeObj);
  if (existIdx !== -1) fridgeAnimations.splice(existIdx, 1);
  fridgeAnimations.push({
    obj: fridgeObj,
    startAngle: fridgeObj.userData.doorAngle || 0,
    targetAngle,
    progress: 0,
    duration: 0.5
  });
  fridgeObj.userData.isOpen = !isOpen;
}
function updateFridgeAnimations(dt) {
  for (let i = fridgeAnimations.length - 1; i >= 0; i--) {
    const anim = fridgeAnimations[i];
    anim.progress += dt / anim.duration;
    if (anim.progress >= 1) anim.progress = 1;
    // Ease out cubic
    const t = 1 - Math.pow(1 - anim.progress, 3);
    const angle = anim.startAngle + (anim.targetAngle - anim.startAngle) * t;
    anim.obj.userData.doorAngle = angle;
    anim.obj.children.forEach(child => {
      if (child.name === 'fridgeDoorBottom' || child.name === 'fridgeDoorTop') {
        child.rotation.y = angle;
      }
    });
    if (anim.progress >= 1) fridgeAnimations.splice(i, 1);
  }
}

// Wardrobe smooth open/close animation
const wardrobeAnimations = [];
function toggleWardrobe(wardrobeObj) {
  const isOpen = wardrobeObj.userData.isOpen;
  const targetAngle = isOpen ? 0 : Math.PI * 0.55;
  // Remove any existing animation for this wardrobe
  const existIdx = wardrobeAnimations.findIndex(a => a.obj === wardrobeObj);
  if (existIdx !== -1) wardrobeAnimations.splice(existIdx, 1);
  wardrobeAnimations.push({
    obj: wardrobeObj,
    startAngle: wardrobeObj.userData.doorAngle || 0,
    targetAngle,
    progress: 0,
    duration: 0.4
  });
  wardrobeObj.userData.isOpen = !isOpen;
}
function updateWardrobeAnimations(dt) {
  for (let i = wardrobeAnimations.length - 1; i >= 0; i--) {
    const anim = wardrobeAnimations[i];
    anim.progress += dt / anim.duration;
    if (anim.progress >= 1) anim.progress = 1;
    // Ease out cubic
    const t = 1 - Math.pow(1 - anim.progress, 3);
    const angle = anim.startAngle + (anim.targetAngle - anim.startAngle) * t;
    anim.obj.userData.doorAngle = angle;
    anim.obj.children.forEach(child => {
      if (child.name === 'wardrobeDoorL') {
        child.rotation.y = -angle;
      }
      if (child.name === 'wardrobeDoorR') {
        child.rotation.y = angle;
      }
    });
    if (anim.progress >= 1) wardrobeAnimations.splice(i, 1);
  }
}

// Door open/close animation
function toggleDoor(doorObj) {
  const isOpen = doorObj.userData.isOpen;
  doorObj.children.forEach(child => {
    if (child.name === 'doorPanel' || child.name === 'doorHandle') {
      if (!isOpen) {
        child.position.z += 0.38;
        child.position.x += 0.35;
        child.rotation.y = Math.PI / 2.5;
      } else {
        child.position.z -= 0.38;
        child.position.x -= 0.35;
        child.rotation.y = 0;
      }
    }
  });
  doorObj.userData.isOpen = !isOpen;
}

// Lamp toggle on/off
function toggleLamp(lampObj) {
  const isOn = lampObj.userData.isOn;
  lampObj.userData.isOn = !isOn;
  lampObj.children.forEach(child => {
    if (child.name === 'lampLight') {
      child.intensity = isOn ? 0 : 0.8;
    }
    if (child.name === 'lampBulb') {
      if (isOn) {
        child.material = new THREE.MeshLambertMaterial({ color: 0x555544 });
      } else {
        child.material = new THREE.MeshLambertMaterial({ color: 0xFFDD66, emissive: 0xFFBB33, emissiveIntensity: 0.8 });
      }
    }
  });
}

// Close menus
wardrobeCloseBtn.addEventListener('click', () => closeWardrobeMenu());
wardrobeMenu.addEventListener('click', (e) => { if (e.target === wardrobeMenu) closeWardrobeMenu(); });
wardrobeMenu.addEventListener('wheel', (e) => e.stopPropagation());
fridgeCloseBtn.addEventListener('click', () => fridgeMenu.classList.add('hidden'));
fridgeMenu.addEventListener('click', (e) => { if (e.target === fridgeMenu) fridgeMenu.classList.add('hidden'); });
fridgeMenu.addEventListener('wheel', (e) => e.stopPropagation());

// Escape closes these menus too
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeWardrobeMenu();
    fridgeMenu.classList.add('hidden');
  }
});

// Detect interactive object under mouse
const interactRaycaster = new THREE.Raycaster();
interactRaycaster.far = 12;

function findInteractiveUnderMouse() {
  interactRaycaster.setFromCamera(mousePos, camera);
  const hits = interactRaycaster.intersectObjects(placedObjects.children, true);
  if (hits.length > 0) {
    // Walk up to the placed object group
    let target = hits[0].object;
    while (target.parent && target.parent !== placedObjects) target = target.parent;
    if (target.userData && target.userData.interactive) {
      return target;
    }
  }
  return null;
}

function getInteractionLabel(obj) {
  const type = obj.userData.interactive;
  switch (type) {
    case 'fridge': return obj.userData.isOpen ? '🧊 Click to close the fridge' : '🧊 Click to open the fridge';
    case 'wardrobe': return obj.userData.isOpen ? '👗 Click to close the wardrobe' : '👗 Click to open the wardrobe';
    case 'door': return obj.userData.isOpen ? '🚪 Click to close the door' : '🚪 Click to open the door';
    case 'lamp': return obj.userData.isOn ? '💡 Click to turn off the lamp' : '💡 Click to turn on the lamp';
    default: return '🖱️ Click to interact';
  }
}

function updateInteractionCursor() {
  const obj = findInteractiveUnderMouse();
  if (obj) {
    hoveredInteractive = obj;
    renderer.domElement.classList.add('cursor-interact');
    // Show tooltip near mouse
    interactTooltip.classList.remove('hidden');
    interactTooltipText.textContent = getInteractionLabel(obj);
    // Position tooltip near mouse
    const mx = (mousePos.x + 1) / 2 * window.innerWidth;
    const my = (1 - (mousePos.y + 1) / 2) * window.innerHeight;
    interactTooltip.style.left = (mx + 15) + 'px';
    interactTooltip.style.top = (my - 30) + 'px';
  } else {
    hoveredInteractive = null;
    renderer.domElement.classList.remove('cursor-interact');
    interactTooltip.classList.add('hidden');
  }
}

// Click handler for interactive objects
renderer.domElement.addEventListener('click', (e) => {
  if (e.button !== 0 || isRightDragging || e.altKey) return;
  if (!hoveredInteractive) return;

  const type = hoveredInteractive.userData.interactive;
  if (type === 'fridge') {
    toggleFridge(hoveredInteractive);
    e.stopPropagation();
  } else if (type === 'wardrobe') {
    toggleWardrobe(hoveredInteractive);
    // Show clothing menu when opened
    if (hoveredInteractive.userData.isOpen) {
      openWardrobeMenu();
    }
    e.stopPropagation();
  } else if (type === 'door') {
    toggleDoor(hoveredInteractive);
    e.stopPropagation();
  } else if (type === 'lamp') {
    toggleLamp(hoveredInteractive);
    e.stopPropagation();
  }
}, true); // capture phase to intercept before block placement



// ============================================
// WATERFALL GENERATION
// ============================================
(function generateWaterfall() {
  // Find a good edge position on the main platform
  // Scan for an edge where we have solid ground that drops to air
  let wfX = -1, wfZ = -1, wfTopY = -1;
  
  // Try to find a nice edge on the +X side of the main platform
  for (let z = Math.floor(WORLD_SIZE / 2) - 5; z <= Math.floor(WORLD_SIZE / 2) + 5; z++) {
    for (let x = Math.floor(WORLD_SIZE / 2) + 5; x < WORLD_SIZE - 2; x++) {
      const h = getHeightCPU(x, z);
      const hNext = getHeightCPU(x + 1, z);
      const hNext2 = getHeightCPU(x + 2, z);
      if (h >= SURFACE_Y_LOW && (hNext < 0 || hNext2 < 0)) {
        // Found an edge! Check we have enough width
        const hUp = getHeightCPU(x, z - 1);
        const hDown = getHeightCPU(x, z + 1);
        if (hUp >= SURFACE_Y_LOW && hDown >= SURFACE_Y_LOW) {
          wfX = x;
          wfZ = z;
          wfTopY = h;
          break;
        }
      }
    }
    if (wfX >= 0) break;
  }
  
  // Fallback: try -Z side
  if (wfX < 0) {
    for (let x = Math.floor(WORLD_SIZE / 2) - 3; x <= Math.floor(WORLD_SIZE / 2) + 3; x++) {
      for (let z = Math.floor(WORLD_SIZE / 2) - 5; z >= 2; z--) {
        const h = getHeightCPU(x, z);
        const hNext = getHeightCPU(x, z - 1);
        if (h >= SURFACE_Y_LOW && hNext < 0) {
          wfX = x;
          wfZ = z;
          wfTopY = h;
          break;
        }
      }
      if (wfX >= 0) break;
    }
  }
  
  if (wfX < 0) {
    // Hard fallback — just use a known edge area
    wfX = Math.floor(WORLD_SIZE / 2) + 13;
    wfZ = Math.floor(WORLD_SIZE / 2);
    wfTopY = SURFACE_Y;
  }
  
  const waterfallWidth = 3;
  const waterfallDropStart = wfTopY;
  const waterfallBottom = 0; // Falls into the void
  
  // Build a source pool at the top (small pond)
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 1; dz++) {
      const px = wfX + dx, pz = wfZ + dz;
      if (px < 0 || px >= WORLD_SIZE || pz < 0 || pz >= WORLD_SIZE) continue;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 2.5) continue;
      const h = getHeightCPU(px, pz);
      if (h >= SURFACE_Y_LOW) {
        // Dig pool one block deep and fill with water
        setBlock(px, h, pz, BLOCK_TYPES.WATER);
        // Keep stone/dirt below
      }
    }
  }
  
  // Stone frame on the sides of the waterfall lip
  for (let dy = 0; dy <= 2; dy++) {
    for (const dz of [-2, 2]) {
      const sz = wfZ + dz;
      if (sz >= 0 && sz < WORLD_SIZE) {
        const sy = waterfallDropStart + dy;
        if (sy < WORLD_HEIGHT) {
          setBlock(wfX + 1, sy, sz, BLOCK_TYPES.STONE);
          if (wfX + 2 < WORLD_SIZE) setBlock(wfX + 2, sy, sz, BLOCK_TYPES.STONE);
        }
      }
    }
  }
  
  // Waterfall column — water blocks cascading down from the edge
  for (let dz = -1; dz <= 1; dz++) {
    const fz = wfZ + dz;
    if (fz < 0 || fz >= WORLD_SIZE) continue;
    for (let fx = wfX + 1; fx <= wfX + 2 && fx < WORLD_SIZE; fx++) {
      for (let fy = waterfallBottom; fy <= waterfallDropStart; fy++) {
        if (fy < 0 || fy >= WORLD_HEIGHT) continue;
        const existing = getBlock(fx, fy, fz);
        if (existing === BLOCK_TYPES.AIR) {
          setBlock(fx, fy, fz, BLOCK_TYPES.WATER);
        }
      }
    }
  }
  
  // Splash pool at bottom — wider spread of water
  for (let dx = -1; dx <= 3; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      const sx = wfX + dx, sz = wfZ + dz;
      if (sx < 0 || sx >= WORLD_SIZE || sz < 0 || sz >= WORLD_SIZE) continue;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 3) continue;
      for (let sy = waterfallBottom; sy <= waterfallBottom + 1; sy++) {
        if (sy >= 0 && sy < WORLD_HEIGHT && getBlock(sx, sy, sz) === BLOCK_TYPES.AIR) {
          setBlock(sx, sy, sz, BLOCK_TYPES.WATER);
        }
      }
    }
  }
  
  // Clear any obstructing blocks in front of the waterfall so it's visible
  // Remove rocks, mountains, and terrain in a generous area ahead of the waterfall
  for (let dx = 2; dx <= 12; dx++) {
    for (let dz = -5; dz <= 5; dz++) {
      const cx = wfX + dx, cz = wfZ + dz;
      if (cx < 0 || cx >= WORLD_SIZE || cz < 0 || cz >= WORLD_SIZE) continue;
      // Remove all blocks above the waterfall bottom in this area
      for (let cy = waterfallBottom; cy < WORLD_HEIGHT; cy++) {
        const b = getBlock(cx, cy, cz);
        if (b !== BLOCK_TYPES.AIR && b !== BLOCK_TYPES.WATER) {
          setBlock(cx, cy, cz, BLOCK_TYPES.AIR);
        }
      }
      // Update height map — find new top
      let newH = -1;
      for (let cy = WORLD_HEIGHT - 1; cy >= 0; cy--) {
        if (getBlock(cx, cy, cz) !== BLOCK_TYPES.AIR) { newH = cy; break; }
      }
      heightCPU[cx + cz * WORLD_SIZE] = newH;
    }
  }
  
  // Also remove the mountain/rocky hill that overlaps the waterfall area
  // Check behind/beside the waterfall too
  for (let dx = -3; dx <= 1; dx++) {
    for (let dz = -4; dz <= 4; dz++) {
      const cx = wfX + dx, cz = wfZ + dz;
      if (cx < 0 || cx >= WORLD_SIZE || cz < 0 || cz >= WORLD_SIZE) continue;
      // Remove blocks above the surface level (mountains/rocks stacking on top)
      for (let cy = waterfallDropStart + 1; cy < WORLD_HEIGHT; cy++) {
        const b = getBlock(cx, cy, cz);
        if (b !== BLOCK_TYPES.AIR && b !== BLOCK_TYPES.WATER) {
          setBlock(cx, cy, cz, BLOCK_TYPES.AIR);
        }
      }
      let newH = -1;
      for (let cy = WORLD_HEIGHT - 1; cy >= 0; cy--) {
        if (getBlock(cx, cy, cz) !== BLOCK_TYPES.AIR) { newH = cy; break; }
      }
      heightCPU[cx + cz * WORLD_SIZE] = newH;
    }
  }
  
  console.log(`Waterfall generated at X:${wfX} Z:${wfZ} from Y:${waterfallDropStart} down to Y:${waterfallBottom}`);
  
  // Store waterfall position for mist particles
  window._waterfallPos = { x: wfX + 1.5, z: wfZ, topY: waterfallDropStart, bottomY: waterfallBottom };
})();

// Rebuild meshes after waterfall generation
buildInstancedMeshesTracked();

// ============================================
// SAVE / LOAD SYSTEM — auto-save user edits every 5s
// ============================================
const SAVE_KEY = 'voxelIsland_userEdits';
const POSITION_SAVE_KEY = 'voxelIsland_playerPos';
const userEdits = {}; // key: "x,y,z" -> blockType
let editsDirty = false;
let lastSaveTime = performance.now();

function isPlayerStuck() {
  return collides(player.position.x, player.position.y, player.position.z);
}

function savePlayerPosition() {
  try {
    // Don't save if the player is stuck inside a wall/block
    if (isPlayerStuck()) {
      console.warn('Player stuck in geometry — skipping position save');
      return;
    }
    const data = {
      x: player.position.x,
      y: player.position.y,
      z: player.position.z,
      yaw: player.yaw,
      camH: cameraAngleH,
      camV: cameraAngleV,
      camDist: cameraDistance
    };
    localStorage.setItem(POSITION_SAVE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('Failed to save player position:', e);
  }
}

function loadPlayerPosition() {
  try {
    const raw = localStorage.getItem(POSITION_SAVE_KEY);
    if (!raw) return false;
    const data = JSON.parse(raw);
    if (data == null || typeof data.x !== 'number') return false;
    // Validate position is within world bounds
    if (data.x < 0 || data.x >= WORLD_SIZE || data.z < 0 || data.z >= WORLD_SIZE || data.y < -5 || data.y >= WORLD_HEIGHT) return false;
    // Temporarily set position to check for collision at saved spot
    const prevX = player.position.x, prevY = player.position.y, prevZ = player.position.z;
    player.position.set(data.x, data.y, data.z);
    if (collides(data.x, data.y, data.z)) {
      // Saved position is inside geometry — try nudging up a few blocks
      let freed = false;
      for (let nudge = 1; nudge <= 5; nudge++) {
        if (!collides(data.x, data.y + nudge, data.z)) {
          data.y += nudge;
          freed = true;
          console.warn(`Saved position was stuck — nudged up ${nudge} block(s)`);
          break;
        }
      }
      if (!freed) {
        // Can't free — revert to default spawn
        player.position.set(prevX, prevY, prevZ);
        console.warn('Saved position stuck in geometry and could not be freed — using default spawn');
        return false;
      }
    }
    player.position.set(data.x, data.y, data.z);
    player.targetGroundY = data.y;
    player.visualY = data.y;
    player.velocity.set(0, 0, 0);
    player.onGround = false;
    if (typeof data.yaw === 'number') player.yaw = data.yaw;
    if (typeof data.camH === 'number') { cameraAngleH = data.camH; targetCamAngleH = data.camH; }
    if (typeof data.camV === 'number') { cameraAngleV = data.camV; targetCamAngleV = data.camV; }
    if (typeof data.camDist === 'number') cameraDistance = data.camDist;
    playerGroup.position.set(data.x, data.y, data.z);
    playerGroup.rotation.y = player.yaw;
    console.log(`Restored player position: ${data.x.toFixed(1)}, ${data.y.toFixed(1)}, ${data.z.toFixed(1)}`);
    return true;
  } catch (e) {
    console.warn('Failed to load player position:', e);
  }
  return false;
}
let saveToastTimer = 0;
function showSaveToast() {
  const el = document.getElementById('save-toast');
  if (!el) return;
  el.classList.add('show');
  clearTimeout(saveToastTimer);
  saveToastTimer = setTimeout(() => el.classList.remove('show'), 1500);
}

// Snapshot of the procedurally generated world (before user edits)
const baseWorldCPU = new Int32Array(worldCPU);

const DEFAULT_USER_EDITS = {"21,14,25":1,"23,14,27":1,"20,15,20":1,"20,15,19":1,"22,15,23":1,"46,15,37":1,"40,13,18":1,"39,13,18":1,"44,15,20":1,"44,15,19":1,"44,15,18":1,"42,14,28":7,"42,15,28":0,"45,14,25":7,"42,14,25":7,"46,13,25":7,"46,14,25":7,"46,12,25":7,"46,12,26":7,"46,13,26":7,"52,14,42":3,"52,14,41":3,"52,14,40":3,"52,14,39":3,"53,14,42":3,"53,14,41":3,"53,14,40":3,"53,14,39":3,"54,14,39":3,"54,14,40":3,"54,14,41":3,"48,15,42":0,"48,16,42":0,"49,14,42":1,"54,14,42":3,"55,14,39":3,"55,14,40":3,"55,14,41":3,"55,14,42":3,"56,14,42":3,"56,14,41":3,"56,14,40":3,"56,14,39":3,"52,14,43":3,"53,14,43":3,"54,14,43":3,"55,14,43":3,"56,14,43":3,"57,14,39":3,"57,14,40":3,"57,14,41":3,"57,14,42":3,"57,14,43":3,"58,14,39":2,"58,14,40":2,"58,14,41":2,"58,14,42":2,"58,14,43":2,"58,15,43":5,"58,15,42":5,"58,15,41":5,"58,15,40":5,"58,15,39":5,"58,15,38":5,"57,15,38":5,"56,15,38":5,"55,15,38":5,"54,15,38":5,"53,15,38":5,"52,15,38":5,"58,15,44":5,"51,15,38":5,"51,15,39":5,"51,16,39":5,"51,16,38":5,"52,16,38":5,"53,16,38":5,"54,16,38":5,"55,16,38":5,"57,16,38":5,"58,16,38":5,"58,16,39":5,"58,16,40":5,"58,16,41":5,"58,16,43":5,"58,16,42":5,"58,16,44":5,"58,17,44":5,"58,17,42":5,"58,17,40":5,"58,17,38":5,"56,17,38":5,"54,17,38":5,"52,17,38":5,"52,14,44":10,"53,14,44":10,"54,14,44":10,"55,14,44":10,"56,14,44":10,"57,14,44":10,"58,14,44":10,"52,14,45":10,"53,14,45":10,"54,14,45":10,"55,14,45":10,"56,14,45":10,"57,14,45":10,"58,14,45":10,"52,14,46":10,"53,14,46":10,"54,14,46":10,"55,14,46":10,"58,14,46":10,"57,14,46":10,"52,14,47":10,"54,14,47":10,"56,14,47":10,"57,14,47":10,"58,14,47":10,"55,14,48":10,"56,14,48":10,"57,14,48":10,"58,14,48":10,"54,14,48":10,"51,14,44":10,"51,14,45":10,"51,14,46":10,"51,14,47":10,"51,14,43":10,"56,14,46":10,"53,14,47":10,"53,14,48":10,"51,14,48":10,"52,14,48":10,"55,14,47":10,"58,15,45":5,"58,15,46":5,"58,16,45":5,"58,17,45":5,"58,18,42":5,"58,18,43":5,"58,18,44":5,"58,18,40":5,"58,18,41":5,"58,18,38":5,"58,18,39":5,"57,18,38":5,"56,18,38":5,"55,18,38":5,"54,18,38":5,"53,18,38":5,"52,18,38":5,"51,17,38":5,"51,18,38":5,"51,17,39":5,"51,18,39":5,"51,17,40":5,"51,18,40":5,"52,14,49":1,"50,14,45":1,"50,14,43":1,"46,14,19":1,"46,14,20":1,"46,14,21":1,"46,14,22":1,"39,14,21":1,"58,18,45":5};

// Load saved edits from localStorage and apply them
function loadUserEdits() {
  try {
    let saved = localStorage.getItem(SAVE_KEY);
    let edits;
    if (!saved) {
      edits = DEFAULT_USER_EDITS;
    } else {
      edits = JSON.parse(saved);
    }
    if (!edits || typeof edits !== 'object') return false;
    let count = 0;
    for (const key of Object.keys(edits)) {
      const parts = key.split(',');
      if (parts.length !== 3) continue;
      const x = parseInt(parts[0]), y = parseInt(parts[1]), z = parseInt(parts[2]);
      const type = edits[key];
      if (x < 0 || x >= WORLD_SIZE || y < 0 || y >= WORLD_HEIGHT || z < 0 || z >= WORLD_SIZE) continue;
      setBlock(x, y, z, type);
      userEdits[key] = type;
      // Update height map
      if (type === BLOCK_TYPES.AIR) {
        if (y >= getHeightCPU(x, z)) {
          let newH = -1;
          for (let h = y; h >= 0; h--) {
            if (getBlock(x, h, z) !== BLOCK_TYPES.AIR) { newH = h; break; }
          }
          heightCPU[x + z * WORLD_SIZE] = newH;
        }
      } else {
        if (y > getHeightCPU(x, z)) {
          heightCPU[x + z * WORLD_SIZE] = y;
        }
      }
      count++;
    }
    if (count > 0) {
      console.log(`Loaded ${count} saved block edits from localStorage`);
      buildInstancedMeshesTracked();
      return true;
    }
  } catch (e) {
    console.warn('Failed to load saved edits:', e);
  }
  return false;
}

function saveUserEdits() {
  try {
    const keys = Object.keys(userEdits);
    if (keys.length === 0) {
      localStorage.removeItem(SAVE_KEY);
    } else {
      localStorage.setItem(SAVE_KEY, JSON.stringify(userEdits));
      showSaveToast();
    }
    editsDirty = false;
  } catch (e) {
    console.warn('Failed to save edits:', e);
  }
}

function trackEdit(x, y, z, type) {
  const key = `${x},${y},${z}`;
  // If the edit restores the block to its original generated value, remove the edit entry
  const baseType = baseWorldCPU[x + y * WORLD_SIZE + z * WORLD_SIZE * WORLD_HEIGHT];
  if (type === baseType) {
    delete userEdits[key];
  } else {
    userEdits[key] = type;
  }
  editsDirty = true;
}

// Load saved edits on startup
loadUserEdits();

// ============================================
// PLACE PLAYER NEAR WATERFALL — now that we know where it is
// ============================================
if (window._waterfallPos) {
  const wp = window._waterfallPos;
  // Try to spawn player close to waterfall but on the island side, facing the falls
  let bestSpawnX = -1, bestSpawnZ = -1, bestDist = Infinity;
  for (let tries = 0; tries < 500; tries++) {
    // Bias toward waterfall area, slightly behind it on the island
    const tx = Math.floor(wp.x + (Math.random() - 0.8) * 12);
    const tz = Math.floor(wp.z + (Math.random() - 0.5) * 8);
    if (tx < 2 || tx >= WORLD_SIZE - 2 || tz < 2 || tz >= WORLD_SIZE - 2) continue;
    const th = getHeightCPU(tx, tz);
    if (th < SURFACE_Y_LOW) continue;
    const surf = getBlock(tx, th, tz);
    if (surf !== BLOCK_TYPES.GRASS && surf !== BLOCK_TYPES.PATH && surf !== BLOCK_TYPES.DIRT) continue;
    if (getBlock(tx, th + 1, tz) !== BLOCK_TYPES.AIR) continue;
    if (getBlock(tx, th + 2, tz) !== BLOCK_TYPES.AIR) continue;
    if (getBlock(tx, th + 3, tz) !== BLOCK_TYPES.AIR) continue;
    // Check 3x3 clear
    let blocked = false;
    for (let dx = -1; dx <= 1 && !blocked; dx++) {
      for (let dz = -1; dz <= 1 && !blocked; dz++) {
        for (let dy = 1; dy <= 3; dy++) {
          const b = getBlock(tx + dx, th + dy, tz + dz);
          if (b === BLOCK_TYPES.WOOD || b === BLOCK_TYPES.LEAVES || b === BLOCK_TYPES.FENCE) {
            blocked = true; break;
          }
        }
      }
    }
    if (blocked) continue;
    const distToWF = Math.sqrt((tx - wp.x) ** 2 + (tz - wp.z) ** 2);
    if (distToWF < 3 || distToWF > 10) continue;
    // Prefer spots that are on the island side (lower X than waterfall)
    if (tx > wp.x - 1) continue;
    // Pick the closest valid spot to the waterfall
    if (distToWF < bestDist) {
      bestDist = distToWF;
      bestSpawnX = tx;
      bestSpawnZ = tz;
    }
  }
  if (bestSpawnX >= 0) {
    spawnX = bestSpawnX + 0.5;
    spawnZ = bestSpawnZ + 0.5;
    const sh = getHeightCPU(bestSpawnX, bestSpawnZ);
    player.position.set(spawnX, sh + 1, spawnZ);
    player.targetGroundY = sh + 1;
    player.visualY = sh + 1;
    // Face the player toward the waterfall
    player.yaw = Math.atan2(wp.x - spawnX, wp.z - spawnZ);
    playerGroup.rotation.y = player.yaw;

    // Camera behind/above player looking over shoulder at waterfall
    // angleH: camera orbits around player — we want camera on the opposite side of the waterfall
    // So camera is behind player (player faces waterfall, camera faces same direction)
    cameraAngleH = player.yaw + Math.PI + Math.PI / 2 + Math.PI / 4; // camera behind player, rotated -135° on Y
    targetCamAngleH = cameraAngleH;
    cameraAngleV = 0.38; // low angle — close to the screenshot's perspective
    targetCamAngleV = cameraAngleV;
    cameraDistance = 18; // match screenshot distance
    console.log(`Player spawned near waterfall at ${spawnX.toFixed(1)}, ${spawnZ.toFixed(1)}`);
  }
}

// Override spawn with saved position if available
loadPlayerPosition();

// ============================================
// SPAWN CREATURES — after waterfall so terrain is final
// ============================================
let creatureCount = 0;
for (let attempt = 0; attempt < 300 && creatureCount < 30; attempt++) {
  const x = 4 + Math.floor(Math.random() * (WORLD_SIZE - 8));
  const z = 4 + Math.floor(Math.random() * (WORLD_SIZE - 8));
  const h = getHeightCPU(x, z);
  if (h < SURFACE_Y_LOW) continue;
  const surfaceBlock = getBlock(x, h, z);
  if (surfaceBlock !== BLOCK_TYPES.GRASS && surfaceBlock !== BLOCK_TYPES.PATH) continue;
  // Must have 2 clear blocks above for the animal
  if (getBlock(x, h + 1, z) !== BLOCK_TYPES.AIR) continue;
  if (getBlock(x, h + 2, z) !== BLOCK_TYPES.AIR) continue;
  // Ensure at least 2 solid blocks below surface (not a thin floating slab)
  if (h > 0 && getBlock(x, h - 1, z) === BLOCK_TYPES.AIR) continue;
  if (h > 1 && getBlock(x, h - 2, z) === BLOCK_TYPES.AIR) continue;
  // Avoid spawning near water/waterfall — check 3-block radius for water
  let nearWater = false;
  for (let dx = -3; dx <= 3 && !nearWater; dx++) {
    for (let dz = -3; dz <= 3 && !nearWater; dz++) {
      for (let dy = -3; dy <= 3; dy++) {
        if (getBlock(x + dx, h + dy, z + dz) === BLOCK_TYPES.WATER) {
          nearWater = true;
          break;
        }
      }
    }
  }
  if (nearWater) continue;
  // Ensure neighbors also have ground (animal won't be on a 1-block pillar)
  let hasGroundedNeighbors = true;
  for (const [dx, dz] of [[1,0],[-1,0],[0,1],[0,-1]]) {
    const nh = getHeightCPU(x + dx, z + dz);
    if (nh < SURFACE_Y_LOW || Math.abs(nh - h) > 2) {
      hasGroundedNeighbors = false;
      break;
    }
  }
  if (!hasGroundedNeighbors) continue;
  const type = Math.random() > 0.4 ? 'sheep' : 'chicken';
  if (createCreature(x, z, type)) creatureCount++;
}

// ============================================
// WATERFALL MIST PARTICLES
// ============================================
const mistGroup = new THREE.Group();
mistGroup.name = 'waterfallMist';
scene.add(mistGroup);

const mistParticles = [];
const mistGeo = new THREE.BoxGeometry(0.3, 0.3, 0.3);

if (window._waterfallPos) {
  const wp = window._waterfallPos;
  // Use sprites with shared texture for fewer draw calls
  const mistCanvas = document.createElement('canvas');
  mistCanvas.width = 32; mistCanvas.height = 32;
  const mctx = mistCanvas.getContext('2d');
  const mg = mctx.createRadialGradient(16, 16, 0, 16, 16, 16);
  mg.addColorStop(0, 'rgba(255,255,255,0.4)');
  mg.addColorStop(0.5, 'rgba(255,255,255,0.15)');
  mg.addColorStop(1, 'rgba(255,255,255,0)');
  mctx.fillStyle = mg;
  mctx.fillRect(0, 0, 32, 32);
  const mistTex = new THREE.CanvasTexture(mistCanvas);

  for (let i = 0; i < 12; i++) {
    const sMat = new THREE.SpriteMaterial({ map: mistTex, transparent: true, opacity: 0.25, depthWrite: false });
    const s = new THREE.Sprite(sMat);
    s.position.set(
      wp.x + (Math.random() - 0.5) * 4,
      wp.bottomY + Math.random() * 4,
      wp.z + (Math.random() - 0.5) * 4
    );
    s.scale.set(1.5, 1.5, 1.5);
    mistGroup.add(s);
    mistParticles.push({
      mesh: s,
      baseX: wp.x + (Math.random() - 0.5) * 3,
      baseZ: wp.z + (Math.random() - 0.5) * 3,
      speed: 0.3 + Math.random() * 0.6,
      phase: Math.random() * Math.PI * 2,
      minY: wp.bottomY - 1,
      maxY: wp.bottomY + 5,
      baseOpacity: 0.1 + Math.random() * 0.2
    });
  }
}

function updateMistParticles(time) {
  for (let i = 0, len = mistParticles.length; i < len; i++) {
    const p = mistParticles[i];
    p.mesh.position.y += p.speed * 0.016;
    p.mesh.position.x = p.baseX + Math.sin(time * 1.5 + p.phase) * 0.8;
    p.mesh.position.z = p.baseZ + Math.cos(time * 1.2 + p.phase) * 0.8;
    const t = (p.mesh.position.y - p.minY) / (p.maxY - p.minY);
    p.mesh.material.opacity = Math.max(0, (p.baseOpacity || 0.25) * (1 - t));
    const sc = 1.0 + t * 2.0;
    p.mesh.scale.set(sc, sc, sc);
    if (p.mesh.position.y > p.maxY) {
      p.mesh.position.y = p.minY;
      p.mesh.position.x = p.baseX;
      p.mesh.position.z = p.baseZ;
    }
  }
}

// ============================================
// SKY ELEMENTS
// ============================================
// Clouds — InstancedMesh for all cloud boxes (1 draw call instead of ~150)
const cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.45 });
const cloudBoxGeo = new THREE.BoxGeometry(1, 1, 1);
const cloudData = []; // { cx, cz, sinVal } per cluster for movement
const cloudInstanceOffsets = []; // which cluster each instance belongs to
const cloudDummy = new THREE.Object3D();

// First pass: generate cloud positions
const cloudClusters = [];
let totalCloudBoxes = 0;
for (let i = 0; i < 30; i++) {
  const cx = WORLD_SIZE / 2 + (Math.random() - 0.5) * 160;
  const cy = WORLD_HEIGHT + 10 + Math.random() * 20;
  const cz = WORLD_SIZE / 2 + (Math.random() - 0.5) * 160;
  const numBoxes = 3 + Math.floor(Math.random() * 5);
  const boxes = [];
  for (let j = 0; j < numBoxes; j++) {
    boxes.push({
      w: 3 + Math.random() * 6, h: 1 + Math.random() * 1.5, d: 3 + Math.random() * 6,
      ox: (Math.random() - 0.5) * 6, oy: (Math.random() - 0.5) * 1.5, oz: (Math.random() - 0.5) * 6
    });
  }
  cloudClusters.push({ cx, cy, cz, boxes, sinVal: Math.sin(i * 0.5) });
  totalCloudBoxes += numBoxes;
}

// Second pass: build InstancedMesh
const cloudIM = new THREE.InstancedMesh(cloudBoxGeo, cloudMat, totalCloudBoxes);
cloudIM.name = 'cloudInstances';
cloudIM.castShadow = false;
cloudIM.receiveShadow = false;
let cloudIdx = 0;
for (let i = 0; i < cloudClusters.length; i++) {
  const cl = cloudClusters[i];
  for (const b of cl.boxes) {
    cloudDummy.position.set(cl.cx + b.ox, cl.cy + b.oy, cl.cz + b.oz);
    cloudDummy.scale.set(b.w, b.h, b.d);
    cloudDummy.updateMatrix();
    cloudIM.setMatrixAt(cloudIdx, cloudDummy.matrix);
    cloudInstanceOffsets.push(i); // track which cluster
    cloudIdx++;
  }
}
cloudIM.instanceMatrix.needsUpdate = true;
scene.add(cloudIM);

// Sun sphere — warm glow
const sunGeo = new THREE.SphereGeometry(8, 16, 16);
const sunMat = new THREE.MeshBasicMaterial({ color: 0xffee88 });
const sunMesh = new THREE.Mesh(sunGeo, sunMat);
sunMesh.name = 'sun';
sunMesh.position.set(WORLD_SIZE / 2 + 80, 70, WORLD_SIZE / 2 + 80);
scene.add(sunMesh);

// Bottomside — void/sky below platforms
const voidPlane = new THREE.PlaneGeometry(400, 400);
const voidMat = new THREE.MeshBasicMaterial({
  color: 0x6EC8E8,
  transparent: true,
  opacity: 0.25,
  side: THREE.DoubleSide
});
const voidMesh = new THREE.Mesh(voidPlane, voidMat);
voidMesh.name = 'voidPlane';
voidMesh.rotation.x = Math.PI / 2;
voidMesh.position.set(WORLD_SIZE / 2, -10, WORLD_SIZE / 2);
scene.add(voidMesh);



// ============================================
// ANIMATION LOOP
// ============================================
const clock = new THREE.Timer();
let frameCount = 0;

function animate() {
  clock.update();
  frameCount++;
  const dt = Math.min(clock.getDelta(), 0.05);
  updatePlayer(dt);
  // Throttle creature AI to every 3rd frame (saves ~30 creature collision checks)
  if (frameCount % 3 === 0) updateCreatures(dt * 3);



  // Animate wardrobe doors
  updateWardrobeAnimations(dt);
  // Animate fridge doors
  updateFridgeAnimations(dt);

  // Update block preview (ghost/remove highlights)
  updateBlockPreview();

  // Update interactive object cursor (fridge, wardrobe)
  if (mouseDirty || frameCount % 6 === 0) updateInteractionCursor();

  // Rebuild meshes if blocks changed (fallback for non-click triggers)
  if (needsRebuild) {
    needsRebuild = false;
    buildInstancedMeshesTracked();
  }

  // Water animation is now handled by TSL nodes (time-based) — no manual update needed

  // Update waterfall mist
  updateMistParticles(clock.getElapsed());

  // Move clouds — update InstancedMesh transforms (1 draw call)
  // Only update every 4th frame since clouds move slowly
  if (frameCount % 4 === 0) {
    let needsCloudUpdate = false;
    for (let i = 0; i < cloudClusters.length; i++) {
      const cl = cloudClusters[i];
      cl.cx += cl.sinVal * 0.012;
      cl.cz += 0.02;
      if (cl.cz > WORLD_SIZE + 60) { cl.cz = -60; }
    }
    let ci = 0;
    for (let i = 0; i < cloudClusters.length; i++) {
      const cl = cloudClusters[i];
      for (const b of cl.boxes) {
        cloudDummy.position.set(cl.cx + b.ox, cl.cy + b.oy, cl.cz + b.oz);
        cloudDummy.scale.set(b.w, b.h, b.d);
        cloudDummy.updateMatrix();
        cloudIM.setMatrixAt(ci, cloudDummy.matrix);
        ci++;
      }
    }
    cloudIM.instanceMatrix.needsUpdate = true;
  }

  // FPS counter — throttle DOM updates to twice per second
  fpsFrames++;
  const fpsNow = performance.now();
  if (fpsNow - fpsLastTime >= 500) {
    fpsValue = Math.round(fpsFrames / ((fpsNow - fpsLastTime) / 1000));
    fpsFrames = 0;
    fpsLastTime = fpsNow;
    fpsEl.textContent = `${fpsValue} FPS`;
    if (isLocked) {
      coordsEl.textContent = `XYZ: ${player.position.x.toFixed(1)} / ${player.position.y.toFixed(1)} / ${player.position.z.toFixed(1)}`;
      coordsEl.style.display = 'block';
    } else {
      coordsEl.style.display = 'none';
    }
  }

  // Auto-save user edits + player position every 5 seconds
  const now = performance.now();
  if (now - lastSaveTime >= 5000) {
    if (editsDirty) saveUserEdits();
    savePlayerPosition();
    lastSaveTime = now;
  }

  renderer.render(scene, camera);
}
renderer.setAnimationLoop(animate);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});