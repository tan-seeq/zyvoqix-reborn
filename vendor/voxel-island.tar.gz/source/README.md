# 🏝️ Voxel Island Game

A modern, browser-based **3D Voxel Building & Exploration Game** built with **React**, **Three.js**, **WebGL**, and **Vite**.

Create your own low-poly island world by placing blocks, building structures, and exploring a colorful voxel environment. Featuring an intuitive building palette, real-time HUD, performance monitoring, and automatic world saving, Voxel Island Game delivers a smooth sandbox building experience directly in your browser.

---

## 🚀 Overview

Voxel Island Game is a lightweight voxel sandbox that combines modern React architecture with Three.js rendering to provide an interactive building experience.

Construct custom landscapes, place environmental objects, monitor your performance, and continue building where you left off thanks to persistent local saving.

---

## ✨ Features

### 🧱 Voxel Building System

Build your island using multiple terrain and decorative blocks.

#### 🌍 Terrain Blocks
- 🌱 Grass
- 🟫 Dirt
- 🪨 Stone
- 🏖️ Sand
- 🛤️ Path
- 💧 Water

#### 🏠 Building Materials
- 🪵 Wood
- 🟨 Planks
- 🚧 Fence

#### 🌿 Nature Objects
- 🍃 Leaves
- 🌸 Flowers
- 🌳 Trees

---

### 💾 Automatic Saving

- Instant world auto-save
- Persistent LocalStorage support
- Continue building after refreshing the page
- Save status notifications

---

### 📊 Heads-Up Display (HUD)

- 📍 Live player coordinates (X, Y, Z)
- ⚡ Real-time FPS counter
- Performance monitoring
- Minimal modern interface

---

### 🌍 Interactive World

- Low-poly voxel environment
- Smooth exploration controls
- Dynamic block placement
- Real-time world updates

---

## 🎮 Gameplay

- Explore your voxel island.
- Select blocks from the palette.
- Place and remove blocks freely.
- Design custom landscapes.
- Build houses, roads, gardens, and more.
- Watch your world automatically save.

---

## 🛠️ Tech Stack

- React
- Vite
- Three.js
- WebGL
- JavaScript (ES6+)
- HTML5
- CSS3

---

## 📂 Project Structure

```text
vvoxel-island-game/
├── .gitignore
├── LICENSE
├── README.md
├── index.html
├── package-lock.json
├── package.json
├── run.bat
└── scene.js
```

---

## ⚙️ Installation

### Clone the Repository

```bash
git clone https://github.com/rsamwilson2323-cloud/voxel-island-game.git
```

### Navigate to the Project

```bash
cd voxel-island-game
```

### Install Dependencies

```bash
npm install
```

### Start Development Server

```bash
npm run dev
```

Open your browser:

```
http://localhost:5173
```

---

## 🎯 Controls

| Key | Action |
|------|--------|
| W A S D | Move |
| Mouse | Look Around |
| Left Click | Place Block |
| Right Click | Remove Block |
| Scroll Wheel | Change Selection |

---

## 🌍 Available Blocks

| Category | Blocks |
|----------|---------|
| Terrain | Grass, Dirt, Stone, Sand, Path, Water |
| Building | Wood, Plank, Fence |
| Nature | Leaves, Flowers, Trees |

---

## 🎯 Use Cases

- Learn Three.js voxel rendering
- Practice React + WebGL integration
- Experiment with procedural world building
- Portfolio-ready graphics project
- Educational sandbox for beginners

---

## 🚀 Future Improvements

- 🎨 Block color customization
- 📦 Import & Export worlds
- ☁️ Cloud save support
- 👥 Multiplayer building
- 🧱 More block types
- 🌦️ Dynamic weather system
- 🌙 Day/Night cycle
- 🔄 Undo & Redo system
- 📱 Mobile touch controls
- 🎵 Ambient sound effects

---

## 👨‍💻 Author

**Sam Wilson**

AI & Full-Stack Developer

- AI Applications
- Computer Vision
- 3D Web Graphics
- Web Development

---

## 📄 License

Licensed under the **MIT License**.

Feel free to use, modify, and distribute this project.

---

## ⭐ Support

If you enjoyed this project:

⭐ Star the repository

🍴 Fork it

🐞 Report bugs

💡 Suggest new features

Happy Building! 🏝️
