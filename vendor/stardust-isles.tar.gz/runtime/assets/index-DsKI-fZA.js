(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=1e3,t=1001,n=1002,r=1003,i=1004,a=1005,o=1006,s=1007,c=1008,l=1009,u=1010,d=1011,f=1012,p=1013,m=1014,h=1015,g=1016,_=1017,v=1018,y=1020,b=35902,x=35899,S=1021,C=1022,w=1023,T=1026,E=1027,D=1028,O=1029,k=1030,A=1031,j=1033,M=33776,ee=33777,N=33778,P=33779,F=35840,te=35841,ne=35842,re=35843,ie=36196,ae=37492,oe=37496,se=37488,I=37489,ce=37490,le=37491,ue=37808,de=37809,fe=37810,pe=37811,me=37812,he=37813,ge=37814,_e=37815,ve=37816,ye=37817,be=37818,xe=37819,Se=37820,Ce=37821,we=36492,Te=36494,Ee=36495,De=36283,Oe=36284,ke=36285,Ae=36286,je=2300,L=2301,Me=2302,Ne=2303,Pe=2400,R=2401,Fe=2402,z=3200,Ie=`srgb`,Le=`srgb-linear`,Re=`linear`,ze=`srgb`,Be=7680,Ve=35044,He=2e3;function Ue(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function We(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function Ge(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function Ke(){let e=Ge(`canvas`);return e.style.display=`block`,e}var qe={};function Je(...e){let t=`THREE.`+e.shift();console.log(t,...e)}function Ye(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function B(...e){e=Ye(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function V(...e){e=Ye(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function Xe(...e){let t=e.join(` `);t in qe||(qe[t]=!0,B(...e))}function Ze(e,t,n){return new Promise(function(r,i){function a(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:i();break;case e.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:r()}}setTimeout(a,n)})}var Qe={0:1,2:6,4:7,3:5,1:0,6:2,7:4,5:3},$e=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n!==void 0&&n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},et=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),tt=1234567,nt=Math.PI/180,rt=180/Math.PI;function it(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(et[e&255]+et[e>>8&255]+et[e>>16&255]+et[e>>24&255]+`-`+et[t&255]+et[t>>8&255]+`-`+et[t>>16&15|64]+et[t>>24&255]+`-`+et[n&63|128]+et[n>>8&255]+`-`+et[n>>16&255]+et[n>>24&255]+et[r&255]+et[r>>8&255]+et[r>>16&255]+et[r>>24&255]).toLowerCase()}function at(e,t,n){return Math.max(t,Math.min(n,e))}function ot(e,t){return(e%t+t)%t}function st(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function ct(e,t,n){return e===t?0:(n-e)/(t-e)}function lt(e,t,n){return(1-n)*e+n*t}function ut(e,t,n,r){return lt(e,t,1-Math.exp(-n*r))}function dt(e,t=1){return t-Math.abs(ot(e,t*2)-t)}function ft(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function pt(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function mt(e,t){return e+Math.floor(Math.random()*(t-e+1))}function ht(e,t){return e+Math.random()*(t-e)}function gt(e){return e*(.5-Math.random())}function _t(e){e!==void 0&&(tt=e);let t=tt+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function vt(e){return e*nt}function yt(e){return e*rt}function bt(e){return e>0&&Number.isInteger(e)&&2**Math.round(Math.log2(e))===e}function xt(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function St(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function Ct(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),l=a((t+r)/2),u=o((t+r)/2),d=a((t-r)/2),f=o((t-r)/2),p=a((r-t)/2),m=o((r-t)/2);switch(i){case`XYX`:e.set(s*u,c*d,c*f,s*l);break;case`YZY`:e.set(c*f,s*u,c*d,s*l);break;case`ZXZ`:e.set(c*d,c*f,s*u,s*l);break;case`XZX`:e.set(s*u,c*m,c*p,s*l);break;case`YXY`:e.set(c*p,s*u,c*m,s*l);break;case`ZYZ`:e.set(c*m,c*p,s*u,s*l);break;default:B(`MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function wt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:case Uint8ClampedArray:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function Tt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}var Et={DEG2RAD:nt,RAD2DEG:rt,generateUUID:it,clamp:at,euclideanModulo:ot,mapLinear:st,inverseLerp:ct,lerp:lt,damp:ut,pingpong:dt,smoothstep:ft,smootherstep:pt,randInt:mt,randFloat:ht,randFloatSpread:gt,seededRandom:_t,degToRad:vt,radToDeg:yt,isPowerOfTwo:bt,ceilPowerOfTwo:xt,floorPowerOfTwo:St,setQuaternionFromProperEuler:Ct,normalize:Tt,denormalize:wt},H=class e{static{e.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(at(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Dt=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:B(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(at(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},U=class e{static{e.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(kt.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(kt.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this.z=at(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this.z=at(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ot.copy(this).projectOnVector(e),this.sub(Ot)}reflect(e){return this.sub(Ot.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(at(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ot=new U,kt=new Dt,W=class e{static{e.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return Xe(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(At.makeScale(e,t)),this}rotate(e){return Xe(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(At.makeRotation(-e)),this}translate(e,t){return Xe(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(At.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},At=new W,jt=new W().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Mt=new W().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Nt(){let e={enabled:!0,workingColorSpace:Le,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n||(this.spaces[t].transfer===`srgb`&&(e.r=Ft(e.r),e.g=Ft(e.g),e.b=Ft(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=It(e.r),e.g=It(e.g),e.b=It(e.b))),e},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?Re:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(t,n){return Xe(`ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().`),e.workingToColorSpace(t,n)},toWorkingColorSpace:function(t,n){return Xe(`ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().`),e.colorSpaceToWorking(t,n)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[Le]:{primaries:t,whitePoint:r,transfer:Re,toXYZ:jt,fromXYZ:Mt,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Ie},outputColorSpaceConfig:{drawingBufferColorSpace:Ie}},[Ie]:{primaries:t,whitePoint:r,transfer:ze,toXYZ:jt,fromXYZ:Mt,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Ie}}}),e}var Pt=Nt();function Ft(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function It(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}var Lt,Rt=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Lt===void 0&&(Lt=Ge(`canvas`)),Lt.width=e.width,Lt.height=e.height;let t=Lt.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=Lt}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=Ge(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=Ft(i[e]/255)*255;return n.putImageData(r,0,0),t}if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(Ft(t[e]/255)*255):t[e]=Ft(t[e]);return{data:t,width:e.width,height:e.height}}return B(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},zt=0,Bt=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:zt++}),this.uuid=it(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width,t.height,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(Vt(r[t].image)):e.push(Vt(r[t]))}else e=Vt(r);n.url=e}return t||(e.images[this.uuid]=n),n}};function Vt(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?Rt.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(B(`Texture: Unable to serialize Texture.`),{})}var Ht=0,Ut=new U,Wt=class r extends $e{constructor(e=r.DEFAULT_IMAGE,n=r.DEFAULT_MAPPING,i=t,a=t,s=o,u=c,d=w,f=l,p=r.DEFAULT_ANISOTROPY,m=``){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Ht++}),this.uuid=it(),this.name=``,this.source=new Bt(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=i,this.wrapT=a,this.magFilter=s,this.minFilter=u,this.anisotropy=p,this.format=d,this.internalFormat=null,this.type=f,this.offset=new H(0,0),this.repeat=new H(1,1),this.center=new H(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new W,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=m,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Ut).x}get height(){return this.source.getSize(Ut).y}get depth(){return this.source.getSize(Ut).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){B(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?B(`Texture.setValues(): property '${t}' does not exist.`):r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(r){if(this.mapping!==300)return r;if(r.applyMatrix3(this.matrix),r.x<0||r.x>1)switch(this.wrapS){case e:r.x-=Math.floor(r.x);break;case t:r.x=r.x<0?0:1;break;case n:Math.abs(Math.floor(r.x)%2)===1?r.x=Math.ceil(r.x)-r.x:r.x-=Math.floor(r.x)}if(r.y<0||r.y>1)switch(this.wrapT){case e:r.y-=Math.floor(r.y);break;case t:r.y=r.y<0?0:1;break;case n:Math.abs(Math.floor(r.y)%2)===1?r.y=Math.ceil(r.y)-r.y:r.y-=Math.floor(r.y)}return this.flipY&&(r.y=1-r.y),r}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};Wt.DEFAULT_IMAGE=null,Wt.DEFAULT_MAPPING=300,Wt.DEFAULT_ANISOTROPY=1;var Gt=class e{static{e.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this.z=at(this.z,e.z,t.z),this.w=at(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this.z=at(this.z,e,t),this.w=at(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Kt=class extends $e{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:o,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Gt(0,0,e,t),this.scissorTest=!1,this.viewport=new Gt(0,0,e,t),this.textures=[];let r=new Wt({width:e,height:t,depth:n.depth}),i=n.count;for(let e=0;e<i;e++)this.textures[e]=r.clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:o,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let e=0;e<this.textures.length;e++)this.textures[e].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,i=this.textures.length;r<i;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let n=Object.assign({},e.textures[t].image);this.textures[t].source=new Bt(n)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null){if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture}return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:`dispose`})}},qt=class extends Kt{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},Jt=class extends Wt{constructor(e=null,n=1,i=1,a=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:i,depth:a},this.magFilter=r,this.minFilter=r,this.wrapR=t,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},Yt=class extends Wt{constructor(e=null,n=1,i=1,a=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:i,depth:a},this.magFilter=r,this.minFilter=r,this.wrapR=t,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},Xt=class e{static{e.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/Zt.setFromMatrixColumn(e,0).length(),i=1/Zt.setFromMatrixColumn(e,1).length(),a=1/Zt.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose($t,e,en)}lookAt(e,t,n){let r=this.elements;return rn.subVectors(e,t),rn.lengthSq()===0&&(rn.z=1),rn.normalize(),tn.crossVectors(n,rn),tn.lengthSq()===0&&(Math.abs(n.z)===1?rn.x+=1e-4:rn.z+=1e-4,rn.normalize(),tn.crossVectors(n,rn)),tn.normalize(),nn.crossVectors(rn,tn),r[0]=tn.x,r[4]=nn.x,r[8]=rn.x,r[1]=tn.y,r[5]=nn.y,r[9]=rn.y,r[2]=tn.z,r[6]=nn.z,r[10]=rn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],k=r[2],A=r[6],j=r[10],M=r[14],ee=r[3],N=r[7],P=r[11],F=r[15];return i[0]=a*x+o*T+s*k+c*ee,i[4]=a*S+o*E+s*A+c*N,i[8]=a*C+o*D+s*j+c*P,i[12]=a*w+o*O+s*M+c*F,i[1]=l*x+u*T+d*k+f*ee,i[5]=l*S+u*E+d*A+f*N,i[9]=l*C+u*D+d*j+f*P,i[13]=l*w+u*O+d*M+f*F,i[2]=p*x+m*T+h*k+g*ee,i[6]=p*S+m*E+h*A+g*N,i[10]=p*C+m*D+h*j+g*P,i[14]=p*w+m*O+h*M+g*F,i[3]=_*x+v*T+y*k+b*ee,i[7]=_*S+v*E+y*A+b*N,i[11]=_*C+v*D+y*j+b*P,i[15]=_*w+v*O+y*M+b*F,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,k=_*O-v*D+y*E+b*T-x*w+S*C;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/k;return e[0]=(o*O-s*D+c*E)*A,e[1]=(r*D-n*O-i*E)*A,e[2]=(m*S-h*x+g*b)*A,e[3]=(d*x-u*S-f*b)*A,e[4]=(s*T-a*O-c*w)*A,e[5]=(t*O-r*T+i*w)*A,e[6]=(h*y-p*S-g*v)*A,e[7]=(l*S-d*y+f*v)*A,e[8]=(a*D-o*T+c*C)*A,e[9]=(n*T-t*D-i*C)*A,e[10]=(p*x-m*y+g*_)*A,e[11]=(u*y-l*x-f*_)*A,e[12]=(o*w-a*E-s*C)*A,e[13]=(t*E-n*w+r*C)*A,e[14]=(m*v-p*b-h*_)*A,e[15]=(l*b-u*v+d*_)*A,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=Zt.set(r[0],r[1],r[2]).length(),o=Zt.set(r[4],r[5],r[6]).length(),s=Zt.set(r[8],r[9],r[10]).length();i<0&&(a=-a),Qt.copy(this);let c=1/a,l=1/o,u=1/s;return Qt.elements[0]*=c,Qt.elements[1]*=c,Qt.elements[2]*=c,Qt.elements[4]*=l,Qt.elements[5]*=l,Qt.elements[6]*=l,Qt.elements[8]*=u,Qt.elements[9]*=u,Qt.elements[10]*=u,t.setFromRotationMatrix(Qt),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=He,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=He,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Zt=new U,Qt=new Xt,$t=new U(0,0,0),en=new U(1,1,1),tn=new U,nn=new U,rn=new U,an=new Xt,on=new Dt,sn=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin(at(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-at(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin(at(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-at(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(at(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-at(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:B(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return an.makeRotationFromQuaternion(e),this.setFromRotationMatrix(an,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return on.setFromEuler(this),this.setFromQuaternion(on,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};sn.DEFAULT_ORDER=`XYZ`;var cn=class{constructor(){this.mask=1}set(e){this.mask=1<<e>>>0}enable(e){this.mask|=1<<e}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e}disable(e){this.mask&=~(1<<e)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return!!(this.mask&1<<e)}},ln=0,un=new U,dn=new Dt,fn=new Xt,pn=new U,mn=new U,hn=new U,gn=new Dt,_n=new U(1,0,0),vn=new U(0,1,0),yn=new U(0,0,1),bn={type:`added`},xn={type:`removed`},Sn={type:`childadded`,child:null},Cn={type:`childremoved`,child:null},wn=class e extends $e{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:ln++}),this.uuid=it(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new U,n=new sn,r=new Dt,i=new U(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Xt},normalMatrix:{value:new W}}),this.matrix=new Xt,this.matrixWorld=new Xt,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new cn,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return dn.setFromAxisAngle(e,t),this.quaternion.multiply(dn),this}rotateOnWorldAxis(e,t){return dn.setFromAxisAngle(e,t),this.quaternion.premultiply(dn),this}rotateX(e){return this.rotateOnAxis(_n,e)}rotateY(e){return this.rotateOnAxis(vn,e)}rotateZ(e){return this.rotateOnAxis(yn,e)}translateOnAxis(e,t){return un.copy(e).applyQuaternion(this.quaternion),this.position.add(un.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(_n,e)}translateY(e){return this.translateOnAxis(vn,e)}translateZ(e){return this.translateOnAxis(yn,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(fn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?pn.copy(e):pn.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),mn.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?fn.lookAt(mn,pn,this.up):fn.lookAt(pn,mn,this.up),this.quaternion.setFromRotationMatrix(fn),r&&(fn.extractRotation(r.matrixWorld),dn.setFromRotationMatrix(fn),this.quaternion.premultiply(dn.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(V(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(bn),Sn.child=e,this.dispatchEvent(Sn),Sn.child=null):V(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(xn),Cn.child=e,this.dispatchEvent(Cn),Cn.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),fn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),fn.multiply(e.parent.matrixWorld)),e.applyMatrix4(fn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(bn),Sn.child=e,this.dispatchEvent(Sn),Sn.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(mn,e,hn),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(mn,gn,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0){if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material)}if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:`dispose`})}};wn.DEFAULT_UP=new U(0,1,0),wn.DEFAULT_MATRIX_AUTO_UPDATE=!0,wn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var G=class extends wn{constructor(){super(),this.isGroup=!0,this.type=`Group`}},Tn={type:`move`},En=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new G,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new G,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new U,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new U),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new G,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new U,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new U,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:`connected`,data:e}),this}disconnect(e){return this.dispatchEvent({type:`disconnected`,data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,i=null,a=null,o=this._targetRay,s=this._grip,c=this._hand;if(e&&t.session.visibilityState!==`visible-blurred`){if(c&&e.hand){a=!0;for(let r of e.hand.values()){let e=t.getJointPose(r,n),i=this._getHandJoint(c,r);e!==null&&(i.matrix.fromArray(e.transform.matrix),i.matrix.decompose(i.position,i.rotation,i.scale),i.matrixWorldNeedsUpdate=!0,i.jointRadius=e.radius),i.visible=e!==null}let r=c.joints[`index-finger-tip`],i=c.joints[`thumb-tip`],o=r.position.distanceTo(i.position);c.inputState.pinching&&o>.025?(c.inputState.pinching=!1,this.dispatchEvent({type:`pinchend`,handedness:e.handedness,target:this})):!c.inputState.pinching&&o<=.015&&(c.inputState.pinching=!0,this.dispatchEvent({type:`pinchstart`,handedness:e.handedness,target:this}))}else s!==null&&e.gripSpace&&(i=t.getPose(e.gripSpace,n),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.rotation,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,s.eventsEnabled&&s.dispatchEvent({type:`gripUpdated`,data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&i!==null&&(r=i),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Tn)))}return o!==null&&(o.visible=r!==null),s!==null&&(s.visible=i!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new G;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},Dn={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},On={h:0,s:0,l:0},kn={h:0,s:0,l:0};function An(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}var K=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Ie){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Pt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Pt.workingColorSpace){return this.r=e,this.g=t,this.b=n,Pt.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Pt.workingColorSpace){if(e=ot(e,1),t=at(t,0,1),n=at(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=An(i,r,e+1/3),this.g=An(i,r,e),this.b=An(i,r,e-1/3)}return Pt.colorSpaceToWorking(this,r),this}setStyle(e,t=Ie){function n(t){t!==void 0&&parseFloat(t)<1&&B(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseInt(i[1],10))/100,Math.min(100,parseInt(i[2],10))/100,Math.min(100,parseInt(i[3],10))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:B(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);B(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Ie){let n=Dn[e.toLowerCase()];return n===void 0?B(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ft(e.r),this.g=Ft(e.g),this.b=Ft(e.b),this}copyLinearToSRGB(e){return this.r=It(e.r),this.g=It(e.g),this.b=It(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ie){return Pt.workingToColorSpace(jn.copy(this),e),Math.round(at(jn.r*255,0,255))*65536+Math.round(at(jn.g*255,0,255))*256+Math.round(at(jn.b*255,0,255))}getHexString(e=Ie){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Pt.workingColorSpace){Pt.workingToColorSpace(jn.copy(this),t);let n=jn.r,r=jn.g,i=jn.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=Pt.workingColorSpace){return Pt.workingToColorSpace(jn.copy(this),t),e.r=jn.r,e.g=jn.g,e.b=jn.b,e}getStyle(e=Ie){Pt.workingToColorSpace(jn.copy(this),e);let t=jn.r,n=jn.g,r=jn.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(On),this.setHSL(On.h+e,On.s+t,On.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(On),e.getHSL(kn);let n=lt(On.h,kn.h,t),r=lt(On.s,kn.s,t),i=lt(On.l,kn.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},jn=new K;K.NAMES=Dn;var Mn=class e{constructor(e,t=1,n=1e3){this.isFog=!0,this.name=``,this.color=new K(e),this.near=t,this.far=n}clone(){return new e(this.color,this.near,this.far)}toJSON(){return{type:`Fog`,name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Nn=class extends wn{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new sn,this.environmentIntensity=1,this.environmentRotation=new sn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},Pn=new U,Fn=new U,In=new U,Ln=new U,Rn=new U,zn=new U,Bn=new U,Vn=new U,Hn=new U,Un=new U,Wn=new Gt,Gn=new Gt,Kn=new Gt,qn=class e{constructor(e=new U,t=new U,n=new U){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Pn.subVectors(e,t),r.cross(Pn);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){Pn.subVectors(r,t),Fn.subVectors(n,t),In.subVectors(e,t);let a=Pn.dot(Pn),o=Pn.dot(Fn),s=Pn.dot(In),c=Fn.dot(Fn),l=Fn.dot(In),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Ln)!==null&&Ln.x>=0&&Ln.y>=0&&Ln.x+Ln.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,Ln)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,Ln.x),s.addScaledVector(a,Ln.y),s.addScaledVector(o,Ln.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return Wn.setScalar(0),Gn.setScalar(0),Kn.setScalar(0),Wn.fromBufferAttribute(e,t),Gn.fromBufferAttribute(e,n),Kn.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Wn,i.x),a.addScaledVector(Gn,i.y),a.addScaledVector(Kn,i.z),a}static isFrontFacing(e,t,n,r){return Pn.subVectors(n,t),Fn.subVectors(e,t),Pn.cross(Fn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pn.subVectors(this.c,this.b),Fn.subVectors(this.a,this.b),Pn.cross(Fn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;Rn.subVectors(r,n),zn.subVectors(i,n),Vn.subVectors(e,n);let s=Rn.dot(Vn),c=zn.dot(Vn);if(s<=0&&c<=0)return t.copy(n);Hn.subVectors(e,r);let l=Rn.dot(Hn),u=zn.dot(Hn);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0)return a=s/(s-l),t.copy(n).addScaledVector(Rn,a);Un.subVectors(e,i);let f=Rn.dot(Un),p=zn.dot(Un);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(zn,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return Bn.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(Bn,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(Rn,a).addScaledVector(zn,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Jn=class{constructor(e=new U(1/0,1/0,1/0),t=new U(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Xn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Xn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Xn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,Xn):Xn.fromBufferAttribute(r,t),Xn.applyMatrix4(e.matrixWorld),this.expandByPoint(Xn);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),Zn.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),Zn.copy(e.boundingBox)),Zn.applyMatrix4(e.matrixWorld),this.union(Zn)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Xn),Xn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ir),ar.subVectors(this.max,ir),Qn.subVectors(e.a,ir),$n.subVectors(e.b,ir),er.subVectors(e.c,ir),tr.subVectors($n,Qn),nr.subVectors(er,$n),rr.subVectors(Qn,er);let t=[0,-tr.z,tr.y,0,-nr.z,nr.y,0,-rr.z,rr.y,tr.z,0,-tr.x,nr.z,0,-nr.x,rr.z,0,-rr.x,-tr.y,tr.x,0,-nr.y,nr.x,0,-rr.y,rr.x,0];return!cr(t,Qn,$n,er,ar)||(t=[1,0,0,0,1,0,0,0,1],!cr(t,Qn,$n,er,ar))?!1:(or.crossVectors(tr,nr),t=[or.x,or.y,or.z],cr(t,Qn,$n,er,ar))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Xn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Xn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(Yn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Yn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Yn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Yn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Yn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Yn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Yn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Yn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Yn)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},Yn=[new U,new U,new U,new U,new U,new U,new U,new U],Xn=new U,Zn=new Jn,Qn=new U,$n=new U,er=new U,tr=new U,nr=new U,rr=new U,ir=new U,ar=new U,or=new U,sr=new U;function cr(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){sr.fromArray(e,a);let o=i.x*Math.abs(sr.x)+i.y*Math.abs(sr.y)+i.z*Math.abs(sr.z),s=t.dot(sr),c=n.dot(sr),l=r.dot(sr);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}var lr=new U,ur=new H,dr=0,fr=class extends $e{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:dr++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=Ve,this.updateRanges=[],this.gpuType=h,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)ur.fromBufferAttribute(this,t),ur.applyMatrix3(e),this.setXY(t,ur.x,ur.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)lr.fromBufferAttribute(this,t),lr.applyMatrix3(e),this.setXYZ(t,lr.x,lr.y,lr.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)lr.fromBufferAttribute(this,t),lr.applyMatrix4(e),this.setXYZ(t,lr.x,lr.y,lr.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)lr.fromBufferAttribute(this,t),lr.applyNormalMatrix(e),this.setXYZ(t,lr.x,lr.y,lr.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)lr.fromBufferAttribute(this,t),lr.transformDirection(e),this.setXYZ(t,lr.x,lr.y,lr.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=wt(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Tt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=wt(t,this.array)),t}setX(e,t){return this.normalized&&(t=Tt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=wt(t,this.array)),t}setY(e,t){return this.normalized&&(t=Tt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=wt(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Tt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=wt(t,this.array)),t}setW(e,t){return this.normalized&&(t=Tt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array),r=Tt(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array),r=Tt(r,this.array),i=Tt(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:`dispose`})}},pr=class extends fr{constructor(e,t,n){super(new Uint16Array(e),t,n)}},mr=class extends fr{constructor(e,t,n){super(new Uint32Array(e),t,n)}},hr=class extends fr{constructor(e,t,n){super(new Float32Array(e),t,n)}},gr=new Jn,_r=new U,vr=new U,yr=class{constructor(e=new U,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?gr.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;_r.subVectors(e,this.center);let t=_r.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(_r,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(vr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(_r.copy(e.center).add(vr)),this.expandByPoint(_r.copy(e.center).sub(vr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},br=0,xr=new Xt,Sr=new wn,Cr=new U,wr=new Jn,Tr=new Jn,Er=new U,Dr=class e extends $e{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:br++}),this.uuid=it(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return this.index=Array.isArray(e)?new(Ue(e)?mr:pr)(e,1):e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new W().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return xr.makeRotationFromQuaternion(e),this.applyMatrix4(xr),this}rotateX(e){return xr.makeRotationX(e),this.applyMatrix4(xr),this}rotateY(e){return xr.makeRotationY(e),this.applyMatrix4(xr),this}rotateZ(e){return xr.makeRotationZ(e),this.applyMatrix4(xr),this}translate(e,t,n){return xr.makeTranslation(e,t,n),this.applyMatrix4(xr),this}scale(e,t,n){return xr.makeScale(e,t,n),this.applyMatrix4(xr),this}lookAt(e){return Sr.lookAt(e),Sr.updateMatrix(),this.applyMatrix4(Sr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Cr).negate(),this.translate(Cr.x,Cr.y,Cr.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new hr(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&B(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Jn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)V(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new U(-1/0,-1/0,-1/0),new U(1/0,1/0,1/0));else{if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];wr.setFromBufferAttribute(n),this.morphTargetsRelative?(Er.addVectors(this.boundingBox.min,wr.min),this.boundingBox.expandByPoint(Er),Er.addVectors(this.boundingBox.max,wr.max),this.boundingBox.expandByPoint(Er)):(this.boundingBox.expandByPoint(wr.min),this.boundingBox.expandByPoint(wr.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&V(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new yr);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)V(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new U,1/0);else if(e){let n=this.boundingSphere.center;if(wr.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Tr.setFromBufferAttribute(n),this.morphTargetsRelative?(Er.addVectors(wr.min,Tr.min),wr.expandByPoint(Er),Er.addVectors(wr.max,Tr.max),wr.expandByPoint(Er)):(wr.expandByPoint(Tr.min),wr.expandByPoint(Tr.max))}wr.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)Er.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(Er));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)Er.fromBufferAttribute(a,t),o&&(Cr.fromBufferAttribute(e,t),Er.add(Cr)),r=Math.max(r,n.distanceToSquared(Er))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&V(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){V(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new fr(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[];for(let e=0;e<n.count;e++)o[e]=new U,s[e]=new U;let c=new U,l=new U,u=new U,d=new H,f=new H,p=new H,m=new U,h=new U;function g(e,t,r){c.fromBufferAttribute(n,e),l.fromBufferAttribute(n,t),u.fromBufferAttribute(n,r),d.fromBufferAttribute(i,e),f.fromBufferAttribute(i,t),p.fromBufferAttribute(i,r),l.sub(c),u.sub(c),f.sub(d),p.sub(d);let a=1/(f.x*p.y-p.x*f.y);isFinite(a)&&(m.copy(l).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(a),h.copy(u).multiplyScalar(f.x).addScaledVector(l,-p.x).multiplyScalar(a),o[e].add(m),o[t].add(m),o[r].add(m),s[e].add(h),s[t].add(h),s[r].add(h))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)g(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let v=new U,y=new U,b=new U,x=new U;function S(e){b.fromBufferAttribute(r,e),x.copy(b);let t=o[e];v.copy(t),v.sub(b.multiplyScalar(b.dot(t))).normalize(),y.crossVectors(x,t);let n=y.dot(s[e])<0?-1:1;a.setXYZW(e,v.x,v.y,v.z,n)}for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)S(e.getX(t+0)),S(e.getX(t+1)),S(e.getX(t+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new fr(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new U,i=new U,a=new U,o=new U,s=new U,c=new U,l=new U,u=new U;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Er.fromBufferAttribute(e,t),Er.normalize(),e.setXYZ(t,Er.x,Er.y,Er.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new fr(a,r,i)}if(this.index===null)return B(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},Or=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e===void 0?0:e.length/t,this.usage=Ve,this.updateRanges=[],this.version=0,this.uuid=it()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,i=this.stride;r<i;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=it()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=it()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));let t={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return t.usage=this.usage,t}},kr=new U,Ar=class e{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name=``,this.data=e,this.itemSize=t,this.offset=n,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)kr.fromBufferAttribute(this,t),kr.applyMatrix4(e),this.setXYZ(t,kr.x,kr.y,kr.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)kr.fromBufferAttribute(this,t),kr.applyNormalMatrix(e),this.setXYZ(t,kr.x,kr.y,kr.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)kr.fromBufferAttribute(this,t),kr.transformDirection(e),this.setXYZ(t,kr.x,kr.y,kr.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=wt(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Tt(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=Tt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=Tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=Tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=Tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=wt(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=wt(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=wt(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=wt(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array),r=Tt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=Tt(t,this.array),n=Tt(n,this.array),r=Tt(r,this.array),i=Tt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=i,this}clone(t){if(t===void 0){Je(`InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return new fr(new this.array.constructor(e),this.itemSize,this.normalized)}return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new e(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Je(`InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.`);let e=[];for(let t=0;t<this.count;t++){let n=t*this.data.stride+this.offset;for(let t=0;t<this.itemSize;t++)e.push(this.data.array[n+t])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},jr=new U,Mr=new U,Nr=new W,Pr=class{constructor(e=new U(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=jr.subVectors(n,t).cross(Mr.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(jr),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Nr.getNormalMatrix(e),r=this.coplanarPoint(jr).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},Fr=0,Ir=class extends $e{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Fr++}),this.uuid=it(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new K(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Be,this.stencilZFail=Be,this.stencilZPass=Be,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){B(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?B(`Material: '${t}' is not a property of THREE.${this.type}.`):r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(e=>e.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new K().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(e=>new Pr().fromJSON(e))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(this.vertexColors=typeof e.vertexColors==`number`?e.vertexColors>0:e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new H().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new H().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},Lr=class extends Ir{constructor(e){super(),this.isSpriteMaterial=!0,this.type=`SpriteMaterial`,this.color=new K(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Rr,zr=new U,Br=new U,Vr=new U,Hr=new H,Ur=new H,Wr=new Xt,Gr=new U,Kr=new U,qr=new U,Jr=new H,Yr=new H,Xr=new H,Zr=class extends wn{constructor(e=new Lr){if(super(),this.isSprite=!0,this.type=`Sprite`,Rr===void 0){Rr=new Dr;let e=new Or(new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),5);Rr.setIndex([0,1,2,0,2,3]),Rr.setAttribute(`position`,new Ar(e,3,0,!1)),Rr.setAttribute(`uv`,new Ar(e,2,3,!1))}this.geometry=Rr,this.material=e,this.center=new H(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&V(`Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.`),Br.setFromMatrixScale(this.matrixWorld),Wr.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Vr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Br.multiplyScalar(-Vr.z);let n=this.material.rotation,r,i;n!==0&&(i=Math.cos(n),r=Math.sin(n));let a=this.center;Qr(Gr.set(-.5,-.5,0),Vr,a,Br,r,i),Qr(Kr.set(.5,-.5,0),Vr,a,Br,r,i),Qr(qr.set(.5,.5,0),Vr,a,Br,r,i),Jr.set(0,0),Yr.set(1,0),Xr.set(1,1);let o=e.ray.intersectTriangle(Gr,Kr,qr,!1,zr);if(o===null&&(Qr(Kr.set(-.5,.5,0),Vr,a,Br,r,i),Yr.set(0,1),o=e.ray.intersectTriangle(Gr,qr,Kr,!1,zr),o===null))return;let s=e.ray.origin.distanceTo(zr);s<e.near||s>e.far||t.push({distance:s,point:zr.clone(),uv:qn.getInterpolation(zr,Gr,Kr,qr,Jr,Yr,Xr,new H),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function Qr(e,t,n,r,i,a){Hr.subVectors(e,n).addScalar(.5).multiply(r),i===void 0?Ur.copy(Hr):(Ur.x=a*Hr.x-i*Hr.y,Ur.y=i*Hr.x+a*Hr.y),e.copy(t),e.x+=Ur.x,e.y+=Ur.y,e.applyMatrix4(Wr)}var $r=new U,ei=new U,ti=new U,ni=new U,ri=class{constructor(e=new U,t=new U(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,$r)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=$r.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):($r.copy(this.origin).addScaledVector(this.direction,t),$r.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){ei.copy(e).add(t).multiplyScalar(.5),ti.copy(t).sub(e).normalize(),ni.copy(this.origin).sub(ei);let i=e.distanceTo(t)*.5,a=-this.direction.dot(ti),o=ni.dot(this.direction),s=-ni.dot(ti),c=ni.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0){if(u=a*s-o,d=a*o-s,p=i*l,u>=0){if(d>=-p){if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c)}else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(ei).addScaledVector(ti,d),f}intersectSphere(e,t){if(e.radius<0)return null;$r.subVectors(e.center,this.origin);let n=$r.dot(this.direction),r=$r.dot($r)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,$r)!==null}intersectTriangle(e,t,n,r,i){let a=this.origin,o=this.direction,s=o.x,c=o.y,l=o.z,u=e.x-a.x,d=e.y-a.y,f=e.z-a.z,p=t.x-a.x,m=t.y-a.y,h=t.z-a.z,g=n.x-a.x,_=n.y-a.y,v=n.z-a.z,y=Math.abs(s),b=Math.abs(c),x=Math.abs(l),S,C,w,T,E,D,O,k,A,j,M,ee;if(y>=b&&y>=x?(w=s,D=u,A=p,ee=g,s>=0?(S=c,C=l,T=d,E=f,O=m,k=h,j=_,M=v):(S=l,C=c,T=f,E=d,O=h,k=m,j=v,M=_)):b>=x?(w=c,D=d,A=m,ee=_,c>=0?(S=l,C=s,T=f,E=u,O=h,k=p,j=v,M=g):(S=s,C=l,T=u,E=f,O=p,k=h,j=g,M=v)):(w=l,D=f,A=h,ee=v,l>=0?(S=s,C=c,T=u,E=d,O=p,k=m,j=g,M=_):(S=c,C=s,T=d,E=u,O=m,k=p,j=_,M=g)),w===0)return null;let N=S/w,P=C/w,F=1/w,te=T-N*D,ne=E-P*D,re=O-N*A,ie=k-P*A,ae=j-N*ee,oe=M-P*ee,se=ae*ie-oe*re,I=te*oe-ne*ae,ce=re*ne-ie*te;if(r){if(se<0||I<0||ce<0)return null}else if((se<0||I<0||ce<0)&&(se>0||I>0||ce>0))return null;let le=se+I+ce;if(le===0)return null;let ue=F*(se*D+I*A+ce*ee);return(le>0?ue<0:ue>0)?null:this.at(ue/le,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ii=class extends Ir{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new K(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new sn,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},ai=new Xt,oi=new ri,si=new yr,ci=new U,li=new U,ui=new U,di=new U,fi=new U,pi=new U,mi=new U,hi=new U,q=class extends wn{constructor(e=new Dr,t=new ii){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){pi.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(fi.fromBufferAttribute(s,e),a?pi.addScaledVector(fi,r):pi.addScaledVector(fi.sub(t),r))}t.add(pi)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),si.copy(n.boundingSphere),si.applyMatrix4(i),oi.copy(e.ray).recast(e.near),!(si.containsPoint(oi.origin)===!1&&(oi.intersectSphere(si,ci)===null||oi.origin.distanceToSquared(ci)>(e.far-e.near)**2))&&(ai.copy(i).invert(),oi.copy(e.ray).applyMatrix4(ai),(n.boundingBox===null||oi.intersectsBox(n.boundingBox)!==!1)&&this._computeIntersections(e,t,oi)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null){if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=_i(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=_i(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}}else if(s!==void 0){if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=_i(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=_i(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}}};function gi(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;hi.copy(s),hi.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(hi);return l<n.near||l>n.far?null:{distance:l,point:hi.clone(),object:e}}function _i(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,li),e.getVertexPosition(c,ui),e.getVertexPosition(l,di);let u=gi(e,t,n,r,li,ui,di,mi);if(u){let e=new U;qn.getBarycoord(mi,li,ui,di,e),i&&(u.uv=qn.getInterpolatedAttribute(i,s,c,l,e,new H)),a&&(u.uv1=qn.getInterpolatedAttribute(a,s,c,l,e,new H)),o&&(u.normal=qn.getInterpolatedAttribute(o,s,c,l,e,new U),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new U,materialIndex:0};qn.getNormal(li,ui,di,t.normal),u.face=t,u.barycoord=e}return u}var vi=class extends Wt{constructor(e=null,t=1,n=1,i,a,o,s,c,l=r,u=r,d,f){super(null,o,s,c,l,u,i,a,d,f),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},yi=class extends fr{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},bi=new Xt,xi=new Xt,Si=[],Ci=new Jn,wi=new Xt,Ti=new q,Ei=new yr,Di=class extends q{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new yi(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let e=0;e<n;e++)this.setMatrixAt(e,wi)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Jn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,bi),Ci.copy(e.boundingBox).applyMatrix4(bi),this.boundingBox.union(Ci)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new yr),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,bi),Ei.copy(e.boundingSphere).applyMatrix4(bi),this.boundingSphere.union(Ei)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,i=e*(n.length+1)+1;for(let e=0;e<n.length;e++)n[e]=r[i+e]}raycast(e,t){let n=this.matrixWorld,r=this.count;if(Ti.geometry=this.geometry,Ti.material=this.material,Ti.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ei.copy(this.boundingSphere),Ei.applyMatrix4(n),e.ray.intersectsSphere(Ei)!==!1))for(let i=0;i<r;i++){this.getMatrixAt(i,bi),xi.multiplyMatrices(n,bi),Ti.matrixWorld=xi,Ti.raycast(e,Si);for(let e=0,n=Si.length;e<n;e++){let n=Si[e];n.instanceId=i,n.object=this,t.push(n)}Si.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new yi(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new vi(new Float32Array(r*this.count),r,this.count,D,h));let i=this.morphTexture.source.data.data,a=0;for(let e=0;e<n.length;e++)a+=n[e];let o=this.geometry.morphTargetsRelative?1:1-a,s=r*e;return i[s]=o,i.set(n,s+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},Oi=new yr,ki=new H(.5,.5),Ai=new U,ji=class{constructor(e=new Pr,t=new Pr,n=new Pr,r=new Pr,i=new Pr,a=new Pr){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=He,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Oi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Oi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Oi)}intersectsSprite(e){return Oi.center.set(0,0,0),Oi.radius=.7071067811865476+ki.distanceTo(e.center),Oi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Oi)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if(Ai.x=r.normal.x>0?e.max.x:e.min.x,Ai.y=r.normal.y>0?e.max.y:e.min.y,Ai.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ai)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},Mi=class extends Ir{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new K(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Ni=new U,Pi=new U,Fi=new Xt,Ii=new ri,Li=new yr,Ri=new U,zi=new U,Bi=class extends wn{constructor(e=new Dr,t=new Mi){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)Ni.fromBufferAttribute(t,e-1),Pi.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=Ni.distanceTo(Pi);e.setAttribute(`lineDistance`,new hr(n,1))}else B(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Li.copy(n.boundingSphere),Li.applyMatrix4(r),Li.radius+=i,e.ray.intersectsSphere(Li)===!1)return;Fi.copy(r).invert(),Ii.copy(e.ray).applyMatrix4(Fi);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=Vi(this,e,Ii,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=Vi(this,e,Ii,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=Vi(this,e,Ii,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=Vi(this,e,Ii,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Vi(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(Ni.fromBufferAttribute(s,i),Pi.fromBufferAttribute(s,a),n.distanceSqToSegment(Ni,Pi,Ri,zi)>r)return;Ri.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(Ri);if(!(c<t.near||c>t.far))return{distance:c,point:zi.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var Hi=new U,Ui=new U,Wi=class extends Bi{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)Hi.fromBufferAttribute(t,e),Ui.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+Hi.distanceTo(Ui);e.setAttribute(`lineDistance`,new hr(n,1))}else B(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},Gi=class extends Ir{constructor(e){super(),this.isPointsMaterial=!0,this.type=`PointsMaterial`,this.color=new K(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Ki=new Xt,qi=new ri,Ji=new yr,Yi=new U,Xi=class extends wn{constructor(e=new Dr,t=new Gi){super(),this.isPoints=!0,this.type=`Points`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ji.copy(n.boundingSphere),Ji.applyMatrix4(r),Ji.radius+=i,e.ray.intersectsSphere(Ji)===!1)return;Ki.copy(r).invert(),qi.copy(e.ray).applyMatrix4(Ki);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=n.index,l=n.attributes.position;if(c!==null){let n=Math.max(0,a.start),i=Math.min(c.count,a.start+a.count);for(let a=n,o=i;a<o;a++){let n=c.getX(a);Yi.fromBufferAttribute(l,n),Zi(Yi,n,s,r,e,t,this)}}else{let n=Math.max(0,a.start),i=Math.min(l.count,a.start+a.count);for(let a=n,o=i;a<o;a++)Yi.fromBufferAttribute(l,a),Zi(Yi,a,s,r,e,t,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Zi(e,t,n,r,i,a,o){let s=qi.distanceSqToPoint(e);if(s<n){let n=new U;qi.closestPointToPoint(e,n),n.applyMatrix4(r);let c=i.ray.origin.distanceTo(n);if(c<i.near||c>i.far)return;a.push({distance:c,distanceToRay:Math.sqrt(s),point:n,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}var Qi=class extends Wt{constructor(e=[],t=301,n,r,i,a,o,s,c,l){super(e,t,n,r,i,a,o,s,c,l),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},$i=class extends Wt{constructor(e,t,n,r,i,a,o,s,c){super(e,t,n,r,i,a,o,s,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},ea=class extends Wt{constructor(e,t,n=m,i,a,o,s=r,c=r,l,u=T,d=1){if(u!==1026&&u!==1027)throw Error(`THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat`);super({width:e,height:t,depth:d},i,a,o,s,c,u,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Bt(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},ta=class extends ea{constructor(e,t=m,n=301,i,a,o=r,s=r,c,l=T){let u={width:e,height:e,depth:1},d=[u,u,u,u,u,u];super(e,e,t,n,i,a,o,s,c,l),this.image=d,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},na=class extends Wt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},ra=class e extends Dr{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new hr(c,3)),this.setAttribute(`normal`,new hr(l,3)),this.setAttribute(`uv`,new hr(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new U;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},ia=class e extends Dr{constructor(e=1,t=1,n=4,r=8,i=1){super(),this.type=`CapsuleGeometry`,this.parameters={radius:e,height:t,capSegments:n,radialSegments:r,heightSegments:i},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),r=Math.max(3,Math.floor(r)),i=Math.max(1,Math.floor(i));let a=[],o=[],s=[],c=[],l=t/2,u=Math.PI/2*e,d=t,f=2*u+d,p=n*2+i,m=r+1,h=new U,g=new U;for(let _=0;_<=p;_++){let v=0,y=0,b=0,x=0;if(_<=n){let t=_/n,r=t*Math.PI/2;y=-l-e*Math.cos(r),b=e*Math.sin(r),x=-e*Math.cos(r),v=t*u}else if(_<=n+i){let r=(_-n)/i;y=-l+r*t,b=e,x=0,v=u+r*d}else{let t=(_-n-i)/n,r=t*Math.PI/2;y=l+e*Math.sin(r),b=e*Math.cos(r),x=e*Math.sin(r),v=u+d+t*u}let S=Math.max(0,Math.min(1,v/f)),C=0;_===0?C=.5/r:_===p&&(C=-.5/r);for(let e=0;e<=r;e++){let t=e/r,n=t*Math.PI*2,i=Math.sin(n),a=Math.cos(n);g.x=-b*a,g.y=y,g.z=b*i,o.push(g.x,g.y,g.z),h.set(-b*a,x,b*i),h.normalize(),s.push(h.x,h.y,h.z),c.push(t+C,S)}if(_>0){let e=(_-1)*m;for(let t=0;t<r;t++){let n=e+t,r=e+t+1,i=_*m+t,o=_*m+t+1;a.push(n,r,i),a.push(r,o,i)}}}this.setIndex(a),this.setAttribute(`position`,new hr(o,3)),this.setAttribute(`normal`,new hr(s,3)),this.setAttribute(`uv`,new hr(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.height,t.capSegments,t.radialSegments,t.heightSegments)}},aa=class e extends Dr{constructor(e=1,t=32,n=0,r=Math.PI*2){super(),this.type=`CircleGeometry`,this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:r},t=Math.max(3,t);let i=[],a=[],o=[],s=[],c=new U,l=new H;a.push(0,0,0),o.push(0,0,1),s.push(.5,.5);for(let i=0,u=3;i<=t;i++,u+=3){let d=n+i/t*r;c.x=e*Math.cos(d),c.y=e*Math.sin(d),a.push(c.x,c.y,c.z),o.push(0,0,1),l.x=(a[u]/e+1)/2,l.y=(a[u+1]/e+1)/2,s.push(l.x,l.y)}for(let e=1;e<=t;e++)i.push(e,e+1,0);this.setIndex(i),this.setAttribute(`position`,new hr(a,3)),this.setAttribute(`normal`,new hr(o,3)),this.setAttribute(`uv`,new hr(s,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.segments,t.thetaStart,t.thetaLength)}},oa=class e extends Dr{constructor(e=1,t=1,n=1,r=32,i=1,a=!1,o=0,s=Math.PI*2){super(),this.type=`CylinderGeometry`,this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:i,openEnded:a,thetaStart:o,thetaLength:s};let c=this;r=Math.floor(r),i=Math.floor(i);let l=[],u=[],d=[],f=[],p=0,m=[],h=n/2,g=0;_(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(l),this.setAttribute(`position`,new hr(u,3)),this.setAttribute(`normal`,new hr(d,3)),this.setAttribute(`uv`,new hr(f,2));function _(){let a=new U,_=new U,v=0,y=(t-e)/n;for(let c=0;c<=i;c++){let l=[],g=c/i,v=g*(t-e)+e;for(let e=0;e<=r;e++){let t=e/r,i=t*s+o,c=Math.sin(i),m=Math.cos(i);_.x=v*c,_.y=-g*n+h,_.z=v*m,u.push(_.x,_.y,_.z),a.set(c,y,m).normalize(),d.push(a.x,a.y,a.z),f.push(t,1-g),l.push(p++)}m.push(l)}for(let n=0;n<r;n++)for(let r=0;r<i;r++){let a=m[r][n],o=m[r+1][n],s=m[r+1][n+1],c=m[r][n+1];(e>0||r!==0)&&(l.push(a,o,c),v+=3),(t>0||r!==i-1)&&(l.push(o,s,c),v+=3)}c.addGroup(g,v,0),g+=v}function v(n){let i=p,a=new H,m=new U,_=0,v=n===!0?e:t,y=n===!0?1:-1;for(let e=1;e<=r;e++)u.push(0,h*y,0),d.push(0,y,0),f.push(.5,.5),p++;let b=p;for(let e=0;e<=r;e++){let t=e/r*s+o,n=Math.cos(t),i=Math.sin(t);m.x=v*i,m.y=h*y,m.z=v*n,u.push(m.x,m.y,m.z),d.push(0,y,0),a.x=n*.5+.5,a.y=i*.5*y+.5,f.push(a.x,a.y),p++}for(let e=0;e<r;e++){let t=i+e,r=b+e;n===!0?l.push(r,r+1,t):l.push(r+1,r,t),_+=3}c.addGroup(g,_,n===!0?1:2),g+=_}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},sa=class e extends oa{constructor(e=1,t=1,n=32,r=1,i=!1,a=0,o=Math.PI*2){super(0,e,t,n,r,i,a,o),this.type=`ConeGeometry`,this.parameters={radius:e,height:t,radialSegments:n,heightSegments:r,openEnded:i,thetaStart:a,thetaLength:o}}static fromJSON(t){return new e(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ca=class e extends Dr{constructor(e=[],t=[],n=1,r=0){super(),this.type=`PolyhedronGeometry`,this.parameters={vertices:e,indices:t,radius:n,detail:r};let i=[],a=[];o(r),c(n),l(),this.setAttribute(`position`,new hr(i,3)),this.setAttribute(`normal`,new hr(i.slice(),3)),this.setAttribute(`uv`,new hr(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(e){let n=new U,r=new U,i=new U;for(let a=0;a<t.length;a+=3)f(t[a+0],n),f(t[a+1],r),f(t[a+2],i),s(n,r,i,e)}function s(e,t,n,r){let i=r+1,a=[];for(let r=0;r<=i;r++){a[r]=[];let o=e.clone().lerp(n,r/i),s=t.clone().lerp(n,r/i),c=i-r;for(let e=0;e<=c;e++)e===0&&r===i?a[r][e]=o:a[r][e]=o.clone().lerp(s,e/c)}for(let e=0;e<i;e++)for(let t=0;t<2*(i-e)-1;t++){let n=Math.floor(t/2);t%2==0?(d(a[e][n+1]),d(a[e+1][n]),d(a[e][n])):(d(a[e][n+1]),d(a[e+1][n+1]),d(a[e+1][n]))}}function c(e){let t=new U;for(let n=0;n<i.length;n+=3)t.x=i[n+0],t.y=i[n+1],t.z=i[n+2],t.normalize().multiplyScalar(e),i[n+0]=t.x,i[n+1]=t.y,i[n+2]=t.z}function l(){let e=new U;for(let t=0;t<i.length;t+=3){e.x=i[t+0],e.y=i[t+1],e.z=i[t+2];let n=h(e)/2/Math.PI+.5,r=g(e)/Math.PI+.5;a.push(n,1-r)}p(),u()}function u(){for(let e=0;e<a.length;e+=6){let t=a[e+0],n=a[e+2],r=a[e+4];Math.max(t,n,r)>.9&&Math.min(t,n,r)<.1&&(t<.2&&(a[e+0]+=1),n<.2&&(a[e+2]+=1),r<.2&&(a[e+4]+=1))}}function d(e){i.push(e.x,e.y,e.z)}function f(t,n){let r=t*3;n.x=e[r+0],n.y=e[r+1],n.z=e[r+2]}function p(){let e=new U,t=new U,n=new U,r=new U,o=new H,s=new H,c=new H;for(let l=0,u=0;l<i.length;l+=9,u+=6){e.set(i[l+0],i[l+1],i[l+2]),t.set(i[l+3],i[l+4],i[l+5]),n.set(i[l+6],i[l+7],i[l+8]),o.set(a[u+0],a[u+1]),s.set(a[u+2],a[u+3]),c.set(a[u+4],a[u+5]),r.copy(e).add(t).add(n).divideScalar(3);let d=h(r);m(o,u+0,e,d),m(s,u+2,t,d),m(c,u+4,n,d)}}function m(e,t,n,r){r<0&&e.x===1&&(a[t]=e.x-1),n.x===0&&n.z===0&&(a[t]=r/2/Math.PI+.5)}function h(e){return Math.atan2(e.z,-e.x)}function g(e){return Math.atan2(-e.y,Math.sqrt(e.x*e.x+e.z*e.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.vertices,t.indices,t.radius,t.detail)}},la=class e extends ca{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,r=1/n,i=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-r,-n,0,-r,n,0,r,-n,0,r,n,-r,-n,0,-r,n,0,r,-n,0,r,n,0,-n,0,-r,n,0,-r,-n,0,r,n,0,r];super(i,[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],e,t),this.type=`DodecahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},ua=class{constructor(){this.type=`Curve`,this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){B(`Curve: .getPoint() not implemented.`)}getPointAt(e,t){let n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],n,r=this.getPoint(0),i=0;t.push(0);for(let a=1;a<=e;a++)n=this.getPoint(a/e),i+=n.distanceTo(r),t.push(i),r=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){let n=this.getLengths(),r=0,i=n.length,a;a=t||e*n[i-1];let o=0,s=i-1,c;for(;o<=s;)if(r=Math.floor(o+(s-o)/2),c=n[r]-a,c<0)o=r+1;else if(c>0)s=r-1;else{s=r;break}if(r=s,n[r]===a)return r/(i-1);let l=n[r],u=n[r+1]-l,d=(a-l)/u;return(r+d)/(i-1)}getTangent(e,t){let n=1e-4,r=e-n,i=e+n;r<0&&(r=0),i>1&&(i=1);let a=this.getPoint(r),o=this.getPoint(i),s=t||(a.isVector2?new H:new U);return s.copy(o).sub(a).normalize(),s}getTangentAt(e,t){let n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){let n=new U,r=[],i=[],a=[],o=new U,s=new Xt;for(let t=0;t<=e;t++){let n=t/e;r[t]=this.getTangentAt(n,new U)}i[0]=new U,a[0]=new U;let c=Number.MAX_VALUE,l=Math.abs(r[0].x),u=Math.abs(r[0].y),d=Math.abs(r[0].z);l<=c&&(c=l,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(r[0],n).normalize(),i[0].crossVectors(r[0],o),a[0].crossVectors(r[0],i[0]);for(let t=1;t<=e;t++){if(i[t]=i[t-1].clone(),a[t]=a[t-1].clone(),o.crossVectors(r[t-1],r[t]),o.length()>2**-52){o.normalize();let e=Math.acos(at(r[t-1].dot(r[t]),-1,1));i[t].applyMatrix4(s.makeRotationAxis(o,e))}a[t].crossVectors(r[t],i[t])}if(t===!0){let t=Math.acos(at(i[0].dot(i[e]),-1,1));t/=e,r[0].dot(o.crossVectors(i[0],i[e]))>0&&(t=-t);for(let n=1;n<=e;n++)i[n].applyMatrix4(s.makeRotationAxis(r[n],t*n)),a[n].crossVectors(r[n],i[n])}return{tangents:r,normals:i,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.7,type:`Curve`,generator:`Curve.toJSON`}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},da=class extends ua{constructor(e=0,t=0,n=1,r=1,i=0,a=Math.PI*2,o=!1,s=0){super(),this.isEllipseCurve=!0,this.type=`EllipseCurve`,this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=r,this.aStartAngle=i,this.aEndAngle=a,this.aClockwise=o,this.aRotation=s}getPoint(e,t=new H){let n=t,r=Math.PI*2,i=this.aEndAngle-this.aStartAngle,a=Math.abs(i)<2**-52;for(;i<0;)i+=r;for(;i>r;)i-=r;i<2**-52&&(i=a?0:r),this.aClockwise===!0&&!a&&(i===r?i=-r:i-=r);let o=this.aStartAngle+e*i,s=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let e=Math.cos(this.aRotation),t=Math.sin(this.aRotation),n=s-this.aX,r=c-this.aY;s=n*e-r*t+this.aX,c=n*t+r*e+this.aY}return n.set(s,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},fa=class extends da{constructor(e,t,n,r,i,a){super(e,t,n,n,r,i,a),this.isArcCurve=!0,this.type=`ArcCurve`}};function pa(){let e=0,t=0,n=0,r=0;function i(i,a,o,s){e=i,t=o,n=-3*i+3*a-2*o-s,r=2*i-2*a+o+s}return{initCatmullRom:function(e,t,n,r,a){i(t,n,a*(n-e),a*(r-t))},initNonuniformCatmullRom:function(e,t,n,r,a,o,s){let c=(t-e)/a-(n-e)/(a+o)+(n-t)/o,l=(n-t)/o-(r-t)/(o+s)+(r-n)/s;c*=o,l*=o,i(t,n,c,l)},calc:function(i){let a=i*i,o=a*i;return e+t*i+n*a+r*o}}}var ma=new U,ha=new U,ga=new pa,_a=new pa,va=new pa,ya=class extends ua{constructor(e=[],t=!1,n=`centripetal`,r=.5){super(),this.isCatmullRomCurve3=!0,this.type=`CatmullRomCurve3`,this.points=e,this.closed=t,this.curveType=n,this.tension=r}getPoint(e,t=new U){let n=t,r=this.points,i=r.length,a=(i-+!this.closed)*e,o=Math.floor(a),s=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/i)+1)*i:s===0&&o===i-1&&(o=i-2,s=1);let c,l;this.closed||o>0?c=r[(o-1)%i]:(ha.subVectors(r[0],r[1]).add(r[0]),c=ha);let u=r[o%i],d=r[(o+1)%i];if(this.closed||o+2<i?l=r[(o+2)%i]:(ma.subVectors(r[i-1],r[i-2]).add(r[i-1]),l=ma),this.curveType===`centripetal`||this.curveType===`chordal`){let e=this.curveType===`chordal`?.5:.25,t=c.distanceToSquared(u)**+e,n=u.distanceToSquared(d)**+e,r=d.distanceToSquared(l)**+e;n<1e-4&&(n=1),t<1e-4&&(t=n),r<1e-4&&(r=n),ga.initNonuniformCatmullRom(c.x,u.x,d.x,l.x,t,n,r),_a.initNonuniformCatmullRom(c.y,u.y,d.y,l.y,t,n,r),va.initNonuniformCatmullRom(c.z,u.z,d.z,l.z,t,n,r)}else this.curveType===`catmullrom`&&(ga.initCatmullRom(c.x,u.x,d.x,l.x,this.tension),_a.initCatmullRom(c.y,u.y,d.y,l.y,this.tension),va.initCatmullRom(c.z,u.z,d.z,l.z,this.tension));return n.set(ga.calc(s),_a.calc(s),va.calc(s)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(new U().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function ba(e,t,n,r,i){let a=(r-t)*.5,o=(i-n)*.5,s=e*e,c=e*s;return(2*n-2*r+a+o)*c+(-3*n+3*r-2*a-o)*s+a*e+n}function xa(e,t){let n=1-e;return n*n*t}function Sa(e,t){return 2*(1-e)*e*t}function Ca(e,t){return e*e*t}function wa(e,t,n,r){return xa(e,t)+Sa(e,n)+Ca(e,r)}function Ta(e,t){let n=1-e;return n*n*n*t}function Ea(e,t){let n=1-e;return 3*n*n*e*t}function Da(e,t){return 3*(1-e)*e*e*t}function Oa(e,t){return e*e*e*t}function ka(e,t,n,r,i){return Ta(e,t)+Ea(e,n)+Da(e,r)+Oa(e,i)}var Aa=class extends ua{constructor(e=new H,t=new H,n=new H,r=new H){super(),this.isCubicBezierCurve=!0,this.type=`CubicBezierCurve`,this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new H){let n=t,r=this.v0,i=this.v1,a=this.v2,o=this.v3;return n.set(ka(e,r.x,i.x,a.x,o.x),ka(e,r.y,i.y,a.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},ja=class extends ua{constructor(e=new U,t=new U,n=new U,r=new U){super(),this.isCubicBezierCurve3=!0,this.type=`CubicBezierCurve3`,this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new U){let n=t,r=this.v0,i=this.v1,a=this.v2,o=this.v3;return n.set(ka(e,r.x,i.x,a.x,o.x),ka(e,r.y,i.y,a.y,o.y),ka(e,r.z,i.z,a.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Ma=class extends ua{constructor(e=new H,t=new H){super(),this.isLineCurve=!0,this.type=`LineCurve`,this.v1=e,this.v2=t}getPoint(e,t=new H){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new H){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Na=class extends ua{constructor(e=new U,t=new U){super(),this.isLineCurve3=!0,this.type=`LineCurve3`,this.v1=e,this.v2=t}getPoint(e,t=new U){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new U){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Pa=class extends ua{constructor(e=new H,t=new H,n=new H){super(),this.isQuadraticBezierCurve=!0,this.type=`QuadraticBezierCurve`,this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new H){let n=t,r=this.v0,i=this.v1,a=this.v2;return n.set(wa(e,r.x,i.x,a.x),wa(e,r.y,i.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Fa=class extends ua{constructor(e=new U,t=new U,n=new U){super(),this.isQuadraticBezierCurve3=!0,this.type=`QuadraticBezierCurve3`,this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new U){let n=t,r=this.v0,i=this.v1,a=this.v2;return n.set(wa(e,r.x,i.x,a.x),wa(e,r.y,i.y,a.y),wa(e,r.z,i.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ia=class extends ua{constructor(e=[]){super(),this.isSplineCurve=!0,this.type=`SplineCurve`,this.points=e}getPoint(e,t=new H){let n=t,r=this.points,i=(r.length-1)*e,a=Math.floor(i),o=i-a,s=r[a===0?a:a-1],c=r[a],l=r[a>r.length-2?r.length-1:a+1],u=r[a>r.length-3?r.length-1:a+2];return n.set(ba(o,s.x,c.x,l.x,u.x),ba(o,s.y,c.y,l.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let n=e.points[t];this.points.push(new H().fromArray(n))}return this}},La=Object.freeze({__proto__:null,ArcCurve:fa,CatmullRomCurve3:ya,CubicBezierCurve:Aa,CubicBezierCurve3:ja,EllipseCurve:da,LineCurve:Ma,LineCurve3:Na,QuadraticBezierCurve:Pa,QuadraticBezierCurve3:Fa,SplineCurve:Ia}),Ra=class extends ua{constructor(){super(),this.type=`CurvePath`,this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let n=e.isVector2===!0?`LineCurve`:`LineCurve3`;this.curves.push(new La[n](t,e))}return this}getPoint(e,t){let n=e*this.getLength(),r=this.getCurveLengths(),i=0;for(;i<r.length;){if(r[i]>=n){let e=r[i]-n,a=this.curves[i],o=a.getLength(),s=o===0?0:1-e/o;return a.getPointAt(s,t)}i++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let n=0,r=this.curves.length;n<r;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],n;for(let r=0,i=this.curves;r<i.length;r++){let a=i[r],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,s=a.getPoints(o);for(let e=0;e<s.length;e++){let r=s[e];n&&n.equals(r)||(t.push(r),n=r)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let n=e.curves[t];this.curves.push(new La[n.type]().fromJSON(n))}return this}},za=class extends Ra{constructor(e){super(),this.type=`Path`,this.currentPoint=new H,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let n=new Ma(this.currentPoint.clone(),new H(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,r){let i=new Pa(this.currentPoint.clone(),new H(e,t),new H(n,r));return this.curves.push(i),this.currentPoint.set(n,r),this}bezierCurveTo(e,t,n,r,i,a){let o=new Aa(this.currentPoint.clone(),new H(e,t),new H(n,r),new H(i,a));return this.curves.push(o),this.currentPoint.set(i,a),this}splineThru(e){let t=new Ia([this.currentPoint.clone()].concat(e));return this.curves.push(t),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,r,i,a){let o=this.currentPoint.x,s=this.currentPoint.y;return this.absarc(e+o,t+s,n,r,i,a),this}absarc(e,t,n,r,i,a){return this.absellipse(e,t,n,n,r,i,a),this}ellipse(e,t,n,r,i,a,o,s){let c=this.currentPoint.x,l=this.currentPoint.y;return this.absellipse(e+c,t+l,n,r,i,a,o,s),this}absellipse(e,t,n,r,i,a,o,s){let c=new da(e,t,n,r,i,a,o,s);if(this.curves.length>0){let e=c.getPoint(0);e.equals(this.currentPoint)||this.lineTo(e.x,e.y)}this.curves.push(c);let l=c.getPoint(1);return this.currentPoint.copy(l),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Ba=class extends za{constructor(e){super(e),this.uuid=it(),this.type=`Shape`,this.holes=[]}getPointsHoles(e){let t=[];for(let n=0,r=this.holes.length;n<r;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let n=e.holes[t];this.holes.push(new za().fromJSON(n))}return this}};function Va(e,t,n=2){let r=t&&t.length,i=r?t[0]*n:e.length,a=Ha(e,0,i,n,!0),o=[];if(!a||a.next===a.prev)return o;let s,c,l;if(r&&(a=Ya(e,t,a,n)),e.length>80*n){s=e[0],c=e[1];let t=s,r=c;for(let a=n;a<i;a+=n){let n=e[a],i=e[a+1];n<s&&(s=n),i<c&&(c=i),n>t&&(t=n),i>r&&(r=i)}l=Math.max(t-s,r-c),l=l===0?0:32767/l}return Wa(a,o,n,s,c,l,0),o}function Ha(e,t,n,r,i){let a;if(i===bo(e,t,n,r)>0)for(let i=t;i<n;i+=r)a=_o(i/r|0,e[i],e[i+1],a);else for(let i=n-r;i>=t;i-=r)a=_o(i/r|0,e[i],e[i+1],a);return a&&co(a,a.next)&&(vo(a),a=a.next),a}function Ua(e,t){if(!e)return e;t||=e;let n=e,r;do if(r=!1,!n.steiner&&(co(n,n.next)||so(n.prev,n,n.next)===0)){if(vo(n),n=t=n.prev,n===n.next)break;r=!0}else n=n.next;while(r||n!==t);return t}function Wa(e,t,n,r,i,a,o){if(!e)return;!o&&a&&eo(e,r,i,a);let s=e;for(;e.prev!==e.next;){let c=e.prev,l=e.next;if(a?Ka(e,r,i,a):Ga(e))t.push(c.i,e.i,l.i),vo(e),e=l.next,s=l.next;else if(e=l,e===s){o?o===1?(e=qa(Ua(e),t),Wa(e,t,n,r,i,a,2)):o===2&&Ja(e,t,n,r,i,a):Wa(Ua(e),t,n,r,i,a,1);break}}}function Ga(e){let t=e.prev,n=e,r=e.next;if(so(t,n,r)>=0)return!1;let i=t.x,a=n.x,o=r.x,s=t.y,c=n.y,l=r.y,u=Math.min(i,a,o),d=Math.min(s,c,l),f=Math.max(i,a,o),p=Math.max(s,c,l),m=r.next;for(;m!==t;){if(m.x>=u&&m.x<=f&&m.y>=d&&m.y<=p&&ao(i,s,a,c,o,l,m.x,m.y)&&so(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function Ka(e,t,n,r){let i=e.prev,a=e,o=e.next;if(so(i,a,o)>=0)return!1;let s=i.x,c=a.x,l=o.x,u=i.y,d=a.y,f=o.y,p=Math.min(s,c,l),m=Math.min(u,d,f),h=Math.max(s,c,l),g=Math.max(u,d,f),_=no(p,m,t,n,r),v=no(h,g,t,n,r),y=e.prevZ,b=e.nextZ;for(;y&&y.z>=_&&b&&b.z<=v;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&ao(s,u,c,d,l,f,y.x,y.y)&&so(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&ao(s,u,c,d,l,f,b.x,b.y)&&so(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=_;){if(y.x>=p&&y.x<=h&&y.y>=m&&y.y<=g&&y!==i&&y!==o&&ao(s,u,c,d,l,f,y.x,y.y)&&so(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=v;){if(b.x>=p&&b.x<=h&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&ao(s,u,c,d,l,f,b.x,b.y)&&so(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function qa(e,t){let n=e;do{let r=n.prev,i=n.next.next;!co(r,i)&&lo(r,n,n.next,i)&&mo(r,i)&&mo(i,r)&&(t.push(r.i,n.i,i.i),vo(n),vo(n.next),n=e=i),n=n.next}while(n!==e);return Ua(n)}function Ja(e,t,n,r,i,a){let o=e;do{let e=o.next.next;for(;e!==o.prev;){if(o.i!==e.i&&oo(o,e)){let s=go(o,e);o=Ua(o,o.next),s=Ua(s,s.next),Wa(o,t,n,r,i,a,0),Wa(s,t,n,r,i,a,0);return}e=e.next}o=o.next}while(o!==e)}function Ya(e,t,n,r){let i=[];for(let n=0,a=t.length;n<a;n++){let o=Ha(e,t[n]*r,n<a-1?t[n+1]*r:e.length,r,!1);o===o.next&&(o.steiner=!0),i.push(ro(o))}i.sort(Xa);for(let e=0;e<i.length;e++)n=Za(i[e],n);return n}function Xa(e,t){let n=e.x-t.x;return n===0&&(n=e.y-t.y,n===0&&(n=(e.next.y-e.y)/(e.next.x-e.x)-(t.next.y-t.y)/(t.next.x-t.x))),n}function Za(e,t){let n=Qa(e,t);if(!n)return t;let r=go(n,e);return Ua(r,r.next),Ua(n,n.next)}function Qa(e,t){let n=t,r=e.x,i=e.y,a=-1/0,o;if(co(e,n))return n;do{if(co(e,n.next))return n.next;if(i<=n.y&&i>=n.next.y&&n.next.y!==n.y){let e=n.x+(i-n.y)*(n.next.x-n.x)/(n.next.y-n.y);if(e<=r&&e>a&&(a=e,o=n.x<n.next.x?n:n.next,e===r))return o}n=n.next}while(n!==t);if(!o)return null;let s=o,c=o.x,l=o.y,u=1/0;n=o;do{if(r>=n.x&&n.x>=c&&r!==n.x&&io(i<l?r:a,i,c,l,i<l?a:r,i,n.x,n.y)){let t=Math.abs(i-n.y)/(r-n.x);mo(n,e)&&(t<u||t===u&&(n.x>o.x||n.x===o.x&&$a(o,n)))&&(o=n,u=t)}n=n.next}while(n!==s);return o}function $a(e,t){return so(e.prev,e,t.prev)<0&&so(t.next,e,e.next)<0}function eo(e,t,n,r){let i=e;do i.z===0&&(i.z=no(i.x,i.y,t,n,r)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==e);i.prevZ.nextZ=null,i.prevZ=null,to(i)}function to(e){let t,n=1;do{let r=e,i;e=null;let a=null;for(t=0;r;){t++;let o=r,s=0;for(let e=0;e<n&&(s++,o=o.nextZ,o);e++);let c=n;for(;s>0||c>0&&o;)s!==0&&(c===0||!o||r.z<=o.z)?(i=r,r=r.nextZ,s--):(i=o,o=o.nextZ,c--),a?a.nextZ=i:e=i,i.prevZ=a,a=i;r=o}a.nextZ=null,n*=2}while(t>1);return e}function no(e,t,n,r,i){return e=(e-n)*i|0,t=(t-r)*i|0,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,e|t<<1}function ro(e){let t=e,n=e;do(t.x<n.x||t.x===n.x&&t.y<n.y)&&(n=t),t=t.next;while(t!==e);return n}function io(e,t,n,r,i,a,o,s){return(i-o)*(t-s)>=(e-o)*(a-s)&&(e-o)*(r-s)>=(n-o)*(t-s)&&(n-o)*(a-s)>=(i-o)*(r-s)}function ao(e,t,n,r,i,a,o,s){return(e!==o||t!==s)&&io(e,t,n,r,i,a,o,s)}function oo(e,t){return e.next.i!==t.i&&e.prev.i!==t.i&&!po(e,t)&&(mo(e,t)&&mo(t,e)&&ho(e,t)&&(so(e.prev,e,t.prev)||so(e,t.prev,t))||co(e,t)&&so(e.prev,e,e.next)>0&&so(t.prev,t,t.next)>0)}function so(e,t,n){return(t.y-e.y)*(n.x-t.x)-(t.x-e.x)*(n.y-t.y)}function co(e,t){return e.x===t.x&&e.y===t.y}function lo(e,t,n,r){let i=fo(so(e,t,n)),a=fo(so(e,t,r)),o=fo(so(n,r,e)),s=fo(so(n,r,t));return!!(i!==a&&o!==s||i===0&&uo(e,n,t)||a===0&&uo(e,r,t)||o===0&&uo(n,e,r)||s===0&&uo(n,t,r))}function uo(e,t,n){return t.x<=Math.max(e.x,n.x)&&t.x>=Math.min(e.x,n.x)&&t.y<=Math.max(e.y,n.y)&&t.y>=Math.min(e.y,n.y)}function fo(e){return e>0?1:e<0?-1:0}function po(e,t){let n=e;do{if(n.i!==e.i&&n.next.i!==e.i&&n.i!==t.i&&n.next.i!==t.i&&lo(n,n.next,e,t))return!0;n=n.next}while(n!==e);return!1}function mo(e,t){return so(e.prev,e,e.next)<0?so(e,t,e.next)>=0&&so(e,e.prev,t)>=0:so(e,t,e.prev)<0||so(e,e.next,t)<0}function ho(e,t){let n=e,r=!1,i=(e.x+t.x)/2,a=(e.y+t.y)/2;do n.y>a!=n.next.y>a&&n.next.y!==n.y&&i<(n.next.x-n.x)*(a-n.y)/(n.next.y-n.y)+n.x&&(r=!r),n=n.next;while(n!==e);return r}function go(e,t){let n=yo(e.i,e.x,e.y),r=yo(t.i,t.x,t.y),i=e.next,a=t.prev;return e.next=t,t.prev=e,n.next=i,i.prev=n,r.next=n,n.prev=r,a.next=r,r.prev=a,r}function _o(e,t,n,r){let i=yo(e,t,n);return r?(i.next=r.next,i.prev=r,r.next.prev=i,r.next=i):(i.prev=i,i.next=i),i}function vo(e){e.next.prev=e.prev,e.prev.next=e.next,e.prevZ&&(e.prevZ.nextZ=e.nextZ),e.nextZ&&(e.nextZ.prevZ=e.prevZ)}function yo(e,t,n){return{i:e,x:t,y:n,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function bo(e,t,n,r){let i=0;for(let a=t,o=n-r;a<n;a+=r)i+=(e[o]-e[a])*(e[a+1]+e[o+1]),o=a;return i}var xo=class{static triangulate(e,t,n=2){return Va(e,t,n)}},So=class e{static area(e){let t=e.length,n=0;for(let r=t-1,i=0;i<t;r=i++)n+=e[r].x*e[i].y-e[i].x*e[r].y;return n*.5}static isClockWise(t){return e.area(t)<0}static triangulateShape(e,t){let n=[],r=[],i=[];Co(e),wo(n,e);let a=e.length;t.forEach(Co);for(let e=0;e<t.length;e++)r.push(a),a+=t[e].length,wo(n,t[e]);let o=xo.triangulate(n,r);for(let e=0;e<o.length;e+=3)i.push(o.slice(e,e+3));return i}};function Co(e){let t=e.length;t>2&&e[t-1].equals(e[0])&&e.pop()}function wo(e,t){for(let n=0;n<t.length;n++)e.push(t[n].x),e.push(t[n].y)}var To=class e extends Dr{constructor(e=new Ba([new H(.5,.5),new H(-.5,.5),new H(-.5,-.5),new H(.5,-.5)]),t={}){super(),this.type=`ExtrudeGeometry`,this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let n=this,r=[],i=[];for(let t=0,n=e.length;t<n;t++){let n=e[t];a(n)}this.setAttribute(`position`,new hr(r,3)),this.setAttribute(`uv`,new hr(i,2)),this.computeVertexNormals();function a(e){let a=[],o=t.curveSegments===void 0?12:t.curveSegments,s=t.steps===void 0?1:t.steps,c=t.depth===void 0?1:t.depth,l=t.bevelEnabled===void 0||t.bevelEnabled,u=t.bevelThickness===void 0?.2:t.bevelThickness,d=t.bevelSize===void 0?u-.1:t.bevelSize,f=t.bevelOffset===void 0?0:t.bevelOffset,p=t.bevelSegments===void 0?3:t.bevelSegments,m=t.extrudePath,h=t.UVGenerator===void 0?Eo:t.UVGenerator,g,_=!1,v,y,b,x;if(m){g=m.getSpacedPoints(s),_=!0,l=!1;let e=m.isCatmullRomCurve3?m.closed:!1;v=m.computeFrenetFrames(s,e),y=new U,b=new U,x=new U}l||(p=0,u=0,d=0,f=0);let S=e.extractPoints(o),C=S.shape,w=S.holes;if(!So.isClockWise(C)){C=C.reverse();for(let e=0,t=w.length;e<t;e++){let t=w[e];So.isClockWise(t)&&(w[e]=t.reverse())}}function T(e){let t=e[0];for(let n=1;n<=e.length;n++){let r=n%e.length,i=e[r],a=i.x-t.x,o=i.y-t.y,s=a*a+o*o,c=Math.max(Math.abs(i.x),Math.abs(i.y),Math.abs(t.x),Math.abs(t.y));s<=10000000000000001e-36*c*c?(e.splice(r,1),n--):t=i}}T(C),w.forEach(T);let E=w.length,D=C;for(let e=0;e<E;e++){let t=w[e];C=C.concat(t)}function O(e,t,n){return t||V(`ExtrudeGeometry: vec does not exist`),e.clone().addScaledVector(t,n)}let k=C.length;function A(e,t,n){let r,i,a,o=e.x-t.x,s=e.y-t.y,c=n.x-e.x,l=n.y-e.y,u=o*o+s*s,d=o*l-s*c;if(Math.abs(d)>2**-52){let d=Math.sqrt(u),f=Math.sqrt(c*c+l*l),p=t.x-s/d,m=t.y+o/d,h=n.x-l/f,g=n.y+c/f,_=((h-p)*l-(g-m)*c)/(o*l-s*c);r=p+o*_-e.x,i=m+s*_-e.y;let v=r*r+i*i;if(v<=2)return new H(r,i);a=Math.sqrt(v/2)}else{let e=!1;o>2**-52?c>2**-52&&(e=!0):o<-(2**-52)?c<-(2**-52)&&(e=!0):Math.sign(s)===Math.sign(l)&&(e=!0),e?(r=-s,i=o,a=Math.sqrt(u)):(r=o,i=s,a=Math.sqrt(u/2))}return new H(r/a,i/a)}let j=[];for(let e=0,t=D.length,n=t-1,r=e+1;e<t;e++,n++,r++)n===t&&(n=0),r===t&&(r=0),j[e]=A(D[e],D[n],D[r]);let M=[],ee,N=j.concat();for(let e=0,t=E;e<t;e++){let t=w[e];ee=[];for(let e=0,n=t.length,r=n-1,i=e+1;e<n;e++,r++,i++)r===n&&(r=0),i===n&&(i=0),ee[e]=A(t[e],t[r],t[i]);M.push(ee),N=N.concat(ee)}let P;if(p===0)P=So.triangulateShape(D,w);else{let e=[],t=[];for(let n=0;n<p;n++){let r=n/p,i=u*Math.cos(r*Math.PI/2),a=d*Math.sin(r*Math.PI/2)+f;for(let t=0,n=D.length;t<n;t++){let n=O(D[t],j[t],a);ae(n.x,n.y,-i),r===0&&e.push(n)}for(let e=0,n=E;e<n;e++){let n=w[e];ee=M[e];let o=[];for(let e=0,t=n.length;e<t;e++){let t=O(n[e],ee[e],a);ae(t.x,t.y,-i),r===0&&o.push(t)}r===0&&t.push(o)}}P=So.triangulateShape(e,t)}let F=P.length,te=d+f;for(let e=0;e<k;e++){let t=l?O(C[e],N[e],te):C[e];_?(b.copy(v.normals[0]).multiplyScalar(t.x),y.copy(v.binormals[0]).multiplyScalar(t.y),x.copy(g[0]).add(b).add(y),ae(x.x,x.y,x.z)):ae(t.x,t.y,0)}for(let e=1;e<=s;e++)for(let t=0;t<k;t++){let n=l?O(C[t],N[t],te):C[t];_?(b.copy(v.normals[e]).multiplyScalar(n.x),y.copy(v.binormals[e]).multiplyScalar(n.y),x.copy(g[e]).add(b).add(y),ae(x.x,x.y,x.z)):ae(n.x,n.y,c/s*e)}for(let e=p-1;e>=0;e--){let t=e/p,n=u*Math.cos(t*Math.PI/2),r=d*Math.sin(t*Math.PI/2)+f;for(let e=0,t=D.length;e<t;e++){let t=O(D[e],j[e],r);ae(t.x,t.y,c+n)}for(let e=0,t=w.length;e<t;e++){let t=w[e];ee=M[e];for(let e=0,i=t.length;e<i;e++){let i=O(t[e],ee[e],r);_?ae(i.x,i.y+g[s-1].y,g[s-1].x+n):ae(i.x,i.y,c+n)}}}ne(),re();function ne(){let e=r.length/3;if(l){let e=0,t=k*e;for(let e=0;e<F;e++){let n=P[e];oe(n[2]+t,n[1]+t,n[0]+t)}e=s+p*2,t=k*e;for(let e=0;e<F;e++){let n=P[e];oe(n[0]+t,n[1]+t,n[2]+t)}}else{for(let e=0;e<F;e++){let t=P[e];oe(t[2],t[1],t[0])}for(let e=0;e<F;e++){let t=P[e];oe(t[0]+k*s,t[1]+k*s,t[2]+k*s)}}n.addGroup(e,r.length/3-e,0)}function re(){let e=r.length/3,t=0;ie(D,t),t+=D.length;for(let e=0,n=w.length;e<n;e++){let n=w[e];ie(n,t),t+=n.length}n.addGroup(e,r.length/3-e,1)}function ie(e,t){let n=e.length;for(;--n>=0;){let r=n,i=n-1;i<0&&(i=e.length-1);for(let e=0,n=s+p*2;e<n;e++){let n=k*e,a=k*(e+1);se(t+r+n,t+i+n,t+i+a,t+r+a)}}}function ae(e,t,n){a.push(e),a.push(t),a.push(n)}function oe(e,t,i){I(e),I(t),I(i);let a=r.length/3,o=h.generateTopUV(n,r,a-3,a-2,a-1);ce(o[0]),ce(o[1]),ce(o[2])}function se(e,t,i,a){I(e),I(t),I(a),I(t),I(i),I(a);let o=r.length/3,s=h.generateSideWallUV(n,r,o-6,o-3,o-2,o-1);ce(s[0]),ce(s[1]),ce(s[3]),ce(s[1]),ce(s[2]),ce(s[3])}function I(e){r.push(a[e*3+0]),r.push(a[e*3+1]),r.push(a[e*3+2])}function ce(e){i.push(e.x),i.push(e.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return Do(t,n,e)}static fromJSON(t,n){let r=[];for(let e=0,i=t.shapes.length;e<i;e++){let i=n[t.shapes[e]];r.push(i)}let i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new La[i.type]().fromJSON(i)),new e(r,t.options)}},Eo={generateTopUV:function(e,t,n,r,i){let a=t[n*3],o=t[n*3+1],s=t[r*3],c=t[r*3+1],l=t[i*3],u=t[i*3+1];return[new H(a,o),new H(s,c),new H(l,u)]},generateSideWallUV:function(e,t,n,r,i,a){let o=t[n*3],s=t[n*3+1],c=t[n*3+2],l=t[r*3],u=t[r*3+1],d=t[r*3+2],f=t[i*3],p=t[i*3+1],m=t[i*3+2],h=t[a*3],g=t[a*3+1],_=t[a*3+2];return Math.abs(s-u)<Math.abs(o-l)?[new H(o,1-c),new H(l,1-d),new H(f,1-m),new H(h,1-_)]:[new H(s,1-c),new H(u,1-d),new H(p,1-m),new H(g,1-_)]}};function Do(e,t,n){if(n.shapes=[],Array.isArray(e))for(let t=0,r=e.length;t<r;t++){let r=e[t];n.shapes.push(r.uuid)}else n.shapes.push(e.uuid);return n.options=Object.assign({},t),t.extrudePath!==void 0&&(n.options.extrudePath=t.extrudePath.toJSON()),n}var Oo=class e extends ca{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1];super(r,[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type=`IcosahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},ko=class e extends ca{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type=`OctahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},Ao=class e extends Dr{constructor(e=1,t=1,n=1,r=1){super(),this.type=`PlaneGeometry`,this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};let i=e/2,a=t/2,o=Math.floor(n),s=Math.floor(r),c=o+1,l=s+1,u=e/o,d=t/s,f=[],p=[],m=[],h=[];for(let e=0;e<l;e++){let t=e*d-a;for(let n=0;n<c;n++){let r=n*u-i;p.push(r,-t,0),m.push(0,0,1),h.push(n/o),h.push(1-e/s)}}for(let e=0;e<s;e++)for(let t=0;t<o;t++){let n=t+c*e,r=t+c*(e+1),i=t+1+c*(e+1),a=t+1+c*e;f.push(n,r,a),f.push(r,i,a)}this.setIndex(f),this.setAttribute(`position`,new hr(p,3)),this.setAttribute(`normal`,new hr(m,3)),this.setAttribute(`uv`,new hr(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.widthSegments,t.heightSegments)}},jo=class e extends Dr{constructor(e=.5,t=1,n=32,r=1,i=0,a=Math.PI*2){super(),this.type=`RingGeometry`,this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:i,thetaLength:a},n=Math.max(3,n),r=Math.max(1,r);let o=[],s=[],c=[],l=[],u=e,d=(t-e)/r,f=new U,p=new H;for(let e=0;e<=r;e++){for(let e=0;e<=n;e++){let r=i+e/n*a;f.x=u*Math.cos(r),f.y=u*Math.sin(r),s.push(f.x,f.y,f.z),c.push(0,0,1),p.x=(f.x/t+1)/2,p.y=(f.y/t+1)/2,l.push(p.x,p.y)}u+=d}for(let e=0;e<r;e++){let t=e*(n+1);for(let e=0;e<n;e++){let r=e+t,i=r,a=r+n+1,s=r+n+2,c=r+1;o.push(i,a,c),o.push(a,s,c)}}this.setIndex(o),this.setAttribute(`position`,new hr(s,3)),this.setAttribute(`normal`,new hr(c,3)),this.setAttribute(`uv`,new hr(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},Mo=class e extends Dr{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new U,d=new U,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new hr(p,3)),this.setAttribute(`normal`,new hr(m,3)),this.setAttribute(`uv`,new hr(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},No=class e extends Dr{constructor(e=1,t=.4,n=12,r=48,i=Math.PI*2,a=0,o=Math.PI*2){super(),this.type=`TorusGeometry`,this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:r,arc:i,thetaStart:a,thetaLength:o},n=Math.floor(n),r=Math.floor(r);let s=[],c=[],l=[],u=[],d=new U,f=new U,p=new U;for(let s=0;s<=n;s++){let m=a+s/n*o;for(let a=0;a<=r;a++){let o=a/r*i;f.x=(e+t*Math.cos(m))*Math.cos(o),f.y=(e+t*Math.cos(m))*Math.sin(o),f.z=t*Math.sin(m),c.push(f.x,f.y,f.z),d.x=e*Math.cos(o),d.y=e*Math.sin(o),p.subVectors(f,d).normalize(),l.push(p.x,p.y,p.z),u.push(a/r),u.push(s/n)}}for(let e=1;e<=n;e++)for(let t=1;t<=r;t++){let n=(r+1)*e+t-1,i=(r+1)*(e-1)+t-1,a=(r+1)*(e-1)+t,o=(r+1)*e+t;s.push(n,i,o),s.push(i,a,o)}this.setIndex(s),this.setAttribute(`position`,new hr(c,3)),this.setAttribute(`normal`,new hr(l,3)),this.setAttribute(`uv`,new hr(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}};function Po(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(Io(i))i.isRenderTargetTexture?(B(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i)){if(Io(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice()}else t[n][r]=i}}return t}function Fo(e){let t={};for(let n=0;n<e.length;n++){let r=Po(e[n]);for(let e in r)t[e]=r[e]}return t}function Io(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function Lo(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function Ro(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Pt.workingColorSpace}var zo={clone:Po,merge:Fo},Bo=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Vo=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Ho=class extends Ir{constructor(e){super(),this.isShaderMaterial=!0,this.type=`ShaderMaterial`,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Bo,this.fragmentShader=Vo,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Po(e.uniforms),this.uniformsGroups=Lo(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:`t`,value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:`c`,value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:`v2`,value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:`v3`,value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:`v4`,value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:`m3`,value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:`m4`,value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let e in this.extensions)this.extensions[e]===!0&&(n[e]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case`t`:this.uniforms[n].value=t[r.value]||null;break;case`c`:this.uniforms[n].value=new K().setHex(r.value);break;case`v2`:this.uniforms[n].value=new H().fromArray(r.value);break;case`v3`:this.uniforms[n].value=new U().fromArray(r.value);break;case`v4`:this.uniforms[n].value=new Gt().fromArray(r.value);break;case`m3`:this.uniforms[n].value=new W().fromArray(r.value);break;case`m4`:this.uniforms[n].value=new Xt().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let t in e.extensions)this.extensions[t]=e.extensions[t];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Uo=class extends Ho{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type=`RawShaderMaterial`}},Wo=class extends Ir{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type=`MeshStandardMaterial`,this.defines={STANDARD:``},this.color=new K(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new K(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new H(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new sn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:``},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Go=class extends Ir{constructor(e){super(),this.isMeshNormalMaterial=!0,this.type=`MeshNormalMaterial`,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new H(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.flatShading=!1,this.setValues(e)}copy(e){return super.copy(e),this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.flatShading=e.flatShading,this}},Ko=class extends Ir{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type=`MeshDepthMaterial`,this.depthPacking=z,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},qo=class extends Ir{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type=`MeshDistanceMaterial`,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Jo(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function Yo(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}var Xo=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},Zo=class extends Xo{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Pe,endingEnd:Pe}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case R:i=e,o=2*t-n;break;case Fe:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case R:a=e,s=2*n-t;break;case Fe:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},Qo=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},$o=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},es=class extends Xo{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=rs(n,t,g,y,r);i[p]=ts(x,o,_,b,m)}return i}};function ts(e,t,n,r,i){let a=1-e;return a*a*a*t+3*a*a*e*n+3*a*e*e*r+e*e*e*i}function ns(e,t,n,r,i){let a=1-e;return 3*a*a*(n-t)+6*a*e*(r-n)+3*e*e*(i-r)}function rs(e,t,n,r,i){let a=(e-t)/(i-t);for(let o=0;o<8;o++){let o=ts(a,t,n,r,i)-e;if(Math.abs(o)<1e-10)break;let s=ns(a,t,n,r,i);if(Math.abs(s)<1e-10)break;a=Math.max(0,Math.min(1,a-o/s))}return a}var is=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=Jo(t,this.TimeBufferType),this.values=Jo(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Jo(e.times,Array),values:Jo(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t),Yo(e.settings)&&(n.settings={inTangents:Jo(e.settings.inTangents,Array),outTangents:Jo(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new $o(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Qo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Zo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new es(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case je:t=this.InterpolantFactoryMethodDiscrete;break;case L:t=this.InterpolantFactoryMethodLinear;break;case Me:t=this.InterpolantFactoryMethodSmooth;break;case Ne:t=this.InterpolantFactoryMethodBezier}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0){if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t)}return B(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return je;case this.InterpolantFactoryMethodLinear:return L;case this.InterpolantFactoryMethodSmooth:return Me;case this.InterpolantFactoryMethodBezier:return Ne}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e;Yo(this.settings)&&(as(this.settings.inTangents,e),as(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(V(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(V(`KeyframeTrack: Track is empty.`,this),e=!1);let a=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){V(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(a!==null&&a>r){V(`KeyframeTrack: Out of order keys.`,this,t,r,a),e=!1;break}a=r}if(r!==void 0&&We(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){V(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===Me,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0])){if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,Yo(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function as(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]*=t}is.prototype.ValueTypeName=``,is.prototype.TimeBufferType=Float32Array,is.prototype.ValueBufferType=Float32Array,is.prototype.DefaultInterpolation=L;var os=class extends is{constructor(e,t,n){super(e,t,n)}};os.prototype.ValueTypeName=`bool`,os.prototype.ValueBufferType=Array,os.prototype.DefaultInterpolation=je,os.prototype.InterpolantFactoryMethodLinear=void 0,os.prototype.InterpolantFactoryMethodSmooth=void 0;var ss=class extends is{constructor(e,t,n,r){super(e,t,n,r)}};ss.prototype.ValueTypeName=`color`;var cs=class extends is{constructor(e,t,n,r){super(e,t,n,r)}};cs.prototype.ValueTypeName=`number`;var ls=class extends Xo{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)Dt.slerpFlat(i,0,a,c-o,a,c,s);return i}},us=class extends is{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new ls(this.times,this.values,this.getValueSize(),e)}};us.prototype.ValueTypeName=`quaternion`,us.prototype.InterpolantFactoryMethodSmooth=void 0;var ds=class extends is{constructor(e,t,n){super(e,t,n)}};ds.prototype.ValueTypeName=`string`,ds.prototype.ValueBufferType=Array,ds.prototype.DefaultInterpolation=je,ds.prototype.InterpolantFactoryMethodLinear=void 0,ds.prototype.InterpolantFactoryMethodSmooth=void 0;var fs=class extends is{constructor(e,t,n,r){super(e,t,n,r)}};fs.prototype.ValueTypeName=`vector`;var ps=class extends wn{constructor(e,t=1){super(),this.isLight=!0,this.type=`Light`,this.color=new K(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},ms=class extends ps{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type=`HemisphereLight`,this.position.copy(wn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new K(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}},hs=new Xt,gs=new U,_s=new U,vs=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new H(512,512),this.mapType=l,this.map=null,this.mapPass=null,this.matrix=new Xt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new ji,this._frameExtents=new H(1,1),this._viewportCount=1,this._viewports=[new Gt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;gs.setFromMatrixPosition(e.matrixWorld),t.position.copy(gs),_s.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(_s),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){hs.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(hs,e.coordinateSystem,e.reversedDepth);let i=this._frameExtents,a=r?r.z/i.x:1,o=r?r.w/i.y:1,s=r?r.x/i.x:0,c=r?r.y/i.y:0;e.coordinateSystem===2001||e.reversedDepth?t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(hs)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},ys=new U,bs=new Dt,xs=new U,Ss=class extends wn{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new Xt,this.projectionMatrix=new Xt,this.projectionMatrixInverse=new Xt,this.coordinateSystem=He,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(ys,bs,xs),xs.x===1&&xs.y===1&&xs.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ys,bs,xs.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(ys,bs,xs),xs.x===1&&xs.y===1&&xs.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ys,bs,xs.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},Cs=new U,ws=new H,Ts=new H,Es=class extends Ss{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=rt*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(nt*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return rt*2*Math.atan(Math.tan(nt*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Cs.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Cs.x,Cs.y).multiplyScalar(-e/Cs.z),Cs.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Cs.x,Cs.y).multiplyScalar(-e/Cs.z)}getViewSize(e,t){return this.getViewBounds(e,ws,Ts),t.subVectors(Ts,ws)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(nt*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Ds=class extends vs{constructor(){super(new Es(90,1,.5,500)),this.isPointLightShadow=!0}},Os=class extends ps{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type=`PointLight`,this.distance=n,this.decay=r,this.shadow=new Ds}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}},ks=class extends Ss{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},As=class extends vs{constructor(){super(new ks(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},js=class extends ps{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type=`DirectionalLight`,this.position.copy(wn.DEFAULT_UP),this.updateMatrix(),this.target=new wn,this.shadow=new As}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}},Ms=-90,Ns=1,Ps=class extends wn{constructor(e,t,n){super(),this.type=`CubeCamera`,this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new Es(Ms,Ns,e,t);r.layers=this.layers,this.add(r);let i=new Es(Ms,Ns,e,t);i.layers=this.layers,this.add(i);let a=new Es(Ms,Ns,e,t);a.layers=this.layers,this.add(a);let o=new Es(Ms,Ns,e,t);o.layers=this.layers,this.add(o);let s=new Es(Ms,Ns,e,t);s.layers=this.layers,this.add(s);let c=new Es(Ms,Ns,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,r,i,a,o,s]=t;for(let e of t)this.remove(e);if(e===2e3)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),i.up.set(0,0,-1),i.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),s.up.set(0,1,0),s.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),i.up.set(0,0,1),i.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),s.up.set(0,-1,0),s.lookAt(0,0,-1);else throw Error(`THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: `+e);for(let e of t)this.add(e),e.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[i,a,o,s,c,l]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let h=!1;h=e.isWebGLRenderer===!0?e.state.buffers.depth.getReversed():e.reversedDepthBuffer,e.setRenderTarget(n,0,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,i),e.setRenderTarget(n,1,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,4,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},Fs=class extends Es{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}},Is=class{constructor(){this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null}connect(e){this._document=e,e.hidden!==void 0&&(this._pageVisibilityHandler=Ls.bind(this),e.addEventListener(`visibilitychange`,this._pageVisibilityHandler,!1))}disconnect(){this._pageVisibilityHandler!==null&&(this._document.removeEventListener(`visibilitychange`,this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null}getDelta(){return this._delta/1e3}getElapsed(){return this._elapsed/1e3}getTimescale(){return this._timescale}setTimescale(e){return this._timescale=e,this}reset(){return this._currentTime=performance.now()-this._startTime,this}dispose(){this.disconnect()}update(e){return this._pageVisibilityHandler!==null&&this._document.hidden===!0?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(e===void 0?performance.now():e)-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this}};function Ls(){this._document.hidden===!1&&this.reset()}var Rs=`\\[\\]\\.:\\/`,zs=RegExp(`[\\[\\]\\.:\\/]`,`g`),Bs=`[^\\[\\]\\.:\\/]`,Vs=`[^`+Rs.replace(`\\.`,``)+`]`,Hs=`((?:WC+[\\/:])*)`.replace(`WC`,Bs),Us=`(WCOD+)?`.replace(`WCOD`,Vs),Ws=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,Bs),Gs=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,Bs),Ks=RegExp(`^`+Hs+Us+Ws+Gs+`$`),qs=[`material`,`materials`,`bones`,`map`],Js=class{constructor(e,t,n){let r=n||Ys.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},Ys=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(zs,``)}static parseTrackName(e){let t=Ks.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);qs.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){B(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){V(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){V(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){V(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){V(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){V(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){V(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){V(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;V(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){V(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){V(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Ys.Composite=Js,Ys.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},Ys.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},Ys.prototype.GetterByBindingType=[Ys.prototype._getValue_direct,Ys.prototype._getValue_array,Ys.prototype._getValue_arrayElement,Ys.prototype._getValue_toArray],Ys.prototype.SetterByBindingTypeAndVersioning=[[Ys.prototype._setValue_direct,Ys.prototype._setValue_direct_setNeedsUpdate,Ys.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Ys.prototype._setValue_array,Ys.prototype._setValue_array_setNeedsUpdate,Ys.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Ys.prototype._setValue_arrayElement,Ys.prototype._setValue_arrayElement_setNeedsUpdate,Ys.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Ys.prototype._setValue_fromArray,Ys.prototype._setValue_fromArray_setNeedsUpdate,Ys.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]],class e{static{e.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}};function Xs(e,t,n,r){let i=Zs(r);switch(n){case S:return e*t;case D:return e*t/i.components*i.byteLength;case O:return e*t/i.components*i.byteLength;case k:return e*t*2/i.components*i.byteLength;case A:return e*t*2/i.components*i.byteLength;case C:return e*t*3/i.components*i.byteLength;case w:return e*t*4/i.components*i.byteLength;case j:return e*t*4/i.components*i.byteLength;case M:case ee:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case N:case P:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case te:case re:return Math.max(e,16)*Math.max(t,8)/4;case F:case ne:return Math.max(e,8)*Math.max(t,8)/2;case ie:case ae:case se:case I:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case oe:case ce:case le:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case ue:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case de:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case fe:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case pe:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case me:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case he:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case ge:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case _e:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case ve:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case ye:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case be:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case xe:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case Se:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case Ce:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case we:case Te:case Ee:return Math.ceil(e/4)*Math.ceil(t/4)*16;case De:case Oe:return Math.ceil(e/4)*Math.ceil(t/4)*8;case ke:case Ae:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function Zs(e){switch(e){case l:case u:return{byteLength:1,components:1};case f:case d:case g:return{byteLength:2,components:1};case _:case v:return{byteLength:2,components:4};case m:case p:case h:return{byteLength:4,components:1};case b:case x:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`186`}})),typeof window<`u`&&(window.__THREE__?B(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`186`);function Qs(){let e=null,t=!1,n=null,r=null;function i(t,a){r=e.requestAnimationFrame(i),n(t,a)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function $s(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var ec={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},J={common:{diffuse:{value:new K(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new W},alphaMap:{value:null},alphaMapTransform:{value:new W},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new W}},envmap:{envMap:{value:null},envMapRotation:{value:new W},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new W}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new W}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new W},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new W},normalScale:{value:new H(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new W},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new W}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new W}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new W}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new K(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new U},probesMax:{value:new U},probesResolution:{value:new U}},points:{diffuse:{value:new K(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new W},alphaTest:{value:0},uvTransform:{value:new W}},sprite:{diffuse:{value:new K(16777215)},opacity:{value:1},center:{value:new H(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new W},alphaMap:{value:null},alphaMapTransform:{value:new W},alphaTest:{value:0}}},tc={basic:{uniforms:Fo([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.fog]),vertexShader:ec.meshbasic_vert,fragmentShader:ec.meshbasic_frag},lambert:{uniforms:Fo([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.fog,J.lights,{emissive:{value:new K(0)},envMapIntensity:{value:1}}]),vertexShader:ec.meshlambert_vert,fragmentShader:ec.meshlambert_frag},phong:{uniforms:Fo([J.common,J.specularmap,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.fog,J.lights,{emissive:{value:new K(0)},specular:{value:new K(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ec.meshphong_vert,fragmentShader:ec.meshphong_frag},standard:{uniforms:Fo([J.common,J.envmap,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.roughnessmap,J.metalnessmap,J.fog,J.lights,{emissive:{value:new K(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ec.meshphysical_vert,fragmentShader:ec.meshphysical_frag},toon:{uniforms:Fo([J.common,J.aomap,J.lightmap,J.emissivemap,J.bumpmap,J.normalmap,J.displacementmap,J.gradientmap,J.fog,J.lights,{emissive:{value:new K(0)}}]),vertexShader:ec.meshtoon_vert,fragmentShader:ec.meshtoon_frag},matcap:{uniforms:Fo([J.common,J.bumpmap,J.normalmap,J.displacementmap,J.fog,{matcap:{value:null}}]),vertexShader:ec.meshmatcap_vert,fragmentShader:ec.meshmatcap_frag},points:{uniforms:Fo([J.points,J.fog]),vertexShader:ec.points_vert,fragmentShader:ec.points_frag},dashed:{uniforms:Fo([J.common,J.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ec.linedashed_vert,fragmentShader:ec.linedashed_frag},depth:{uniforms:Fo([J.common,J.displacementmap]),vertexShader:ec.depth_vert,fragmentShader:ec.depth_frag},normal:{uniforms:Fo([J.common,J.bumpmap,J.normalmap,J.displacementmap,{opacity:{value:1}}]),vertexShader:ec.meshnormal_vert,fragmentShader:ec.meshnormal_frag},sprite:{uniforms:Fo([J.sprite,J.fog]),vertexShader:ec.sprite_vert,fragmentShader:ec.sprite_frag},background:{uniforms:{uvTransform:{value:new W},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ec.background_vert,fragmentShader:ec.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new W}},vertexShader:ec.backgroundCube_vert,fragmentShader:ec.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ec.cube_vert,fragmentShader:ec.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ec.equirect_vert,fragmentShader:ec.equirect_frag},distance:{uniforms:Fo([J.common,J.displacementmap,{referencePosition:{value:new U},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ec.distance_vert,fragmentShader:ec.distance_frag},shadow:{uniforms:Fo([J.lights,J.fog,{color:{value:new K(0)},opacity:{value:1}}]),vertexShader:ec.shadow_vert,fragmentShader:ec.shadow_frag}};tc.physical={uniforms:Fo([tc.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new W},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new W},clearcoatNormalScale:{value:new H(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new W},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new W},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new W},sheen:{value:0},sheenColor:{value:new K(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new W},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new W},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new W},transmissionSamplerSize:{value:new H},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new W},attenuationDistance:{value:0},attenuationColor:{value:new K(0)},specularColor:{value:new K(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new W},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new W},anisotropyVector:{value:new H},anisotropyMap:{value:null},anisotropyMapTransform:{value:new W}}]),vertexShader:ec.meshphysical_vert,fragmentShader:ec.meshphysical_frag};var nc={r:0,b:0,g:0},rc=new Xt,ic=new W;ic.set(-1,0,0,0,1,0,0,0,1);function ac(e,t,n,r,i,a){let o=new K(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new q(new ra(1,1,1),new Ho({name:`BackgroundCubeMaterial`,uniforms:Po(tc.backgroundCube.uniforms),vertexShader:tc.backgroundCube.vertexShader,fragmentShader:tc.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(rc.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(ic),l.material.toneMapped=Pt.getTransfer(i.colorSpace)!==ze,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new q(new Ao(2,2),new Ho({name:`BackgroundMaterial`,uniforms:Po(tc.background.uniforms),vertexShader:tc.background.vertexShader,fragmentShader:tc.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=Pt.getTransfer(i.colorSpace)!==ze,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(nc,Ro(e)),n.buffers.color.setClear(nc.r,nc.g,nc.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function oc(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function sc(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function cc(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&n!==1015&&!i&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(B(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&B(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function lc(e){let t=this,n=null,r=0,i=!1,a=!1,o=new Pr,s=new W,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var uc=4,dc=6,fc=20,pc=256,mc=new ks,hc=new K,gc=null,_c=0,vc=0,yc=!1,bc=new U,xc=new U,Sc=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=bc}=i;gc=this._renderer.getRenderTarget(),_c=this._renderer.getActiveCubeFace(),vc=this._renderer.getActiveMipmapLevel(),yc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=kc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Oc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(gc,_c,vc),this._renderer.xr.enabled=yc,e.scissorTest=!1,Tc(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),gc=this._renderer.getRenderTarget(),_c=this._renderer.getActiveCubeFace(),vc=this._renderer.getActiveMipmapLevel(),yc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:o,minFilter:o,generateMipmaps:!1,type:g,format:w,colorSpace:Le,depthBuffer:!1},r=wc(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=wc(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=Cc(r)),this._blurMaterial=Dc(r,e,t),this._ggxMaterial=Ec(r,e,t)}return r}_compileMaterial(e){let t=new q(new Dr,e);this._renderer.compile(t,mc)}_sceneToCubeUV(e,t,n,r,i){let a=new Es(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(hc),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new q(new ra,new ii({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(hc),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;Tc(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=kc()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Oc());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;Tc(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,mc)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-uc?n-d+uc:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,Tc(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,mc),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,Tc(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,mc)}_blur(e,t,n,r){let i=this._pingPongRenderTarget,a=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,i,t,n,a),this._blurPass(i,e,n,n,a)}_blurPass(e,t,n,r,i){let a=this._renderer,o=this._blurMaterial,s=this._lodMeshes[r];s.material=o;let c=o.uniforms;c.envMap.value=e.texture,c.sigma.value=i,c.mipInt.value=this._lodMax-n;let l=this._sizeLods[r];Tc(t,3*l*(r>this._lodMax-uc?r-this._lodMax+uc:0),4*(this._cubeSize-l),3*l,2*l),a.setRenderTarget(t),a.render(s,mc)}};function Cc(e){let t=[],n=[],r=e,i=e-uc+1+dc;for(let e=0;e<i;e++){let e=2**r;t.push(e);let i=1/(e-2),a=-i,o=1+i,s=[a,a,o,a,o,o,a,a,o,o,a,o],c=new Float32Array(108),l=new Float32Array(108);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];c.set(r,18*e);for(let t=0;t<6;t++){let n=s[t*2]*2-1,r=s[t*2+1]*2-1;e===0?xc.set(1,r,n):e===1?xc.set(-n,1,-r):e===2?xc.set(-n,r,1):e===3?xc.set(-1,r,-n):e===4?xc.set(-n,-1,r):xc.set(n,r,-1),xc.toArray(l,(e*6+t)*3)}}let u=new Dr;u.setAttribute(`position`,new fr(c,3)),u.setAttribute(`outputDirection`,new fr(l,3)),n.push(new q(u,null)),r>uc&&r--}return{lodMeshes:n,sizeLods:t}}function wc(e,t,n){let r=new qt(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function Tc(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function Ec(e,t,n){return new Ho({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:pc,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ac(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Dc(e,t,n){return new Ho({name:`SphericalGaussianBlur`,defines:{SAMPLES:fc,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Ac(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Oc(){return new Ho({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:Ac(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function kc(){return new Ho({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ac(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Ac(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var jc=class extends qt{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Qi(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new ra(5,5,5),i=new Ho({name:`CubemapFromEquirect`,uniforms:Po(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new q(r,i),s=t.minFilter;return t.minFilter===1008&&(t.minFilter=o),new Ps(1,10,this).update(e,a),t.minFilter=s,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function Mc(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new jc(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new Sc(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new Sc(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function Nc(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&Xe(`WebGLRenderer: `+e+` extension not supported.`),t}}}function Pc(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0||(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++),t}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?mr:pr)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function Fc(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function Ic(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:V(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function Lc(e,t,n){let r=new WeakMap,i=new Gt;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let g=new Float32Array(p*m*4*u),_=new Jt(g,p,m,u);_.type=h,_.needsUpdate=!0;let v=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*v;e===!0&&(i.fromBufferAttribute(r,t),g[d+s+0]=i.x,g[d+s+1]=i.y,g[d+s+2]=i.z,g[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),g[d+s+4]=i.x,g[d+s+5]=i.y,g[d+s+6]=i.z,g[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),g[d+s+8]=i.x,g[d+s+9]=i.y,g[d+s+10]=i.z,g[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:_,size:new H(p,m)},r.set(o,d);function y(){_.dispose(),r.delete(o),o.removeEventListener(`dispose`,y)}o.addEventListener(`dispose`,y)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function Rc(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var zc={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Bc(e,t,n,r,i,a){let o=new qt(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),s=null,c=null,l=new Dr;l.setAttribute(`position`,new hr([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute(`uv`,new hr([0,2,0,0,2,0],2));let u=new Uo({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new q(l,u),f=new ks(-1,1,1,-1,0,1),p=null,m=null,h=!1,_,v=null,y=[],b=!1;this.setSize=function(e,t){o.setSize(e,t),s!==null&&s.setSize(e,t),c!==null&&c.setSize(e,t);for(let n=0;n<y.length;n++){let r=y[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){y=e,b=y.length>0&&y[0].isRenderPass===!0;let t=o.width,n=o.height;y.length>0&&s===null&&(s=new qt(t,n,{type:g,depthBuffer:!1,stencilBuffer:!1}),c=new qt(t,n,{type:g,depthBuffer:!1,stencilBuffer:!1}));for(let e=0;e<y.length;e++){let r=y[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(h||e.toneMapping===0&&y.length===0)return!1;if(v=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return b===!1&&e.setRenderTarget(o),_=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return b},this.end=function(e,t){e.toneMapping=_,h=!0;let n=o,r=s;for(let i=0;i<y.length;i++){let a=y[i];a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1&&(n=r,r=r===s?c:s))}if(p!==e.outputColorSpace||m!==e.toneMapping){p=e.outputColorSpace,m=e.toneMapping,u.defines={},Pt.getTransfer(p)===`srgb`&&(u.defines.SRGB_TRANSFER=``);let t=zc[m];t&&(u.defines[t]=``),u.needsUpdate=!0}u.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(v),e.render(d,f),v=null,h=!1},this.isCompositing=function(){return h},this.dispose=function(){o.dispose(),s!==null&&s.dispose(),c!==null&&c.dispose(),l.dispose(),u.dispose()}}var Vc=new Wt,Hc=new ea(1,1),Uc=new Jt,Wc=new Yt,Gc=new Qi,Kc=[],qc=[],Jc=new Float32Array(16),Yc=new Float32Array(9),Xc=new Float32Array(4);function Zc(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=Kc[i];if(a===void 0&&(a=new Float32Array(i),Kc[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function Qc(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function $c(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function el(e,t){let n=qc[t];n===void 0&&(n=new Int32Array(t),qc[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function tl(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function nl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Qc(n,t))return;e.uniform2fv(this.addr,t),$c(n,t)}}function rl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Qc(n,t))return;e.uniform3fv(this.addr,t),$c(n,t)}}function il(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Qc(n,t))return;e.uniform4fv(this.addr,t),$c(n,t)}}function al(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Qc(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),$c(n,t)}else{if(Qc(n,r))return;Xc.set(r),e.uniformMatrix2fv(this.addr,!1,Xc),$c(n,r)}}function ol(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Qc(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),$c(n,t)}else{if(Qc(n,r))return;Yc.set(r),e.uniformMatrix3fv(this.addr,!1,Yc),$c(n,r)}}function sl(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Qc(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),$c(n,t)}else{if(Qc(n,r))return;Jc.set(r),e.uniformMatrix4fv(this.addr,!1,Jc),$c(n,r)}}function cl(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function ll(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Qc(n,t))return;e.uniform2iv(this.addr,t),$c(n,t)}}function ul(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Qc(n,t))return;e.uniform3iv(this.addr,t),$c(n,t)}}function dl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Qc(n,t))return;e.uniform4iv(this.addr,t),$c(n,t)}}function fl(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function pl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Qc(n,t))return;e.uniform2uiv(this.addr,t),$c(n,t)}}function ml(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Qc(n,t))return;e.uniform3uiv(this.addr,t),$c(n,t)}}function hl(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Qc(n,t))return;e.uniform4uiv(this.addr,t),$c(n,t)}}function gl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(Hc.compareFunction=n.isReversedDepthBuffer()?518:515,a=Hc):a=Vc,n.setTexture2D(t||a,i)}function _l(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Wc,i)}function vl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||Gc,i)}function yl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||Uc,i)}function bl(e){switch(e){case 5126:return tl;case 35664:return nl;case 35665:return rl;case 35666:return il;case 35674:return al;case 35675:return ol;case 35676:return sl;case 5124:case 35670:return cl;case 35667:case 35671:return ll;case 35668:case 35672:return ul;case 35669:case 35673:return dl;case 5125:return fl;case 36294:return pl;case 36295:return ml;case 36296:return hl;case 35678:case 36198:case 36298:case 36306:case 35682:return gl;case 35679:case 36299:case 36307:return _l;case 35680:case 36300:case 36308:case 36293:return vl;case 36289:case 36303:case 36311:case 36292:return yl}}function xl(e,t){e.uniform1fv(this.addr,t)}function Sl(e,t){let n=Zc(t,this.size,2);e.uniform2fv(this.addr,n)}function Cl(e,t){let n=Zc(t,this.size,3);e.uniform3fv(this.addr,n)}function wl(e,t){let n=Zc(t,this.size,4);e.uniform4fv(this.addr,n)}function Tl(e,t){let n=Zc(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function El(e,t){let n=Zc(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function Dl(e,t){let n=Zc(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function Ol(e,t){e.uniform1iv(this.addr,t)}function kl(e,t){e.uniform2iv(this.addr,t)}function Al(e,t){e.uniform3iv(this.addr,t)}function jl(e,t){e.uniform4iv(this.addr,t)}function Ml(e,t){e.uniform1uiv(this.addr,t)}function Nl(e,t){e.uniform2uiv(this.addr,t)}function Pl(e,t){e.uniform3uiv(this.addr,t)}function Fl(e,t){e.uniform4uiv(this.addr,t)}function Il(e,t,n){let r=this.cache,i=t.length,a=el(n,i);Qc(r,a)||(e.uniform1iv(this.addr,a),$c(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?Hc:Vc;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function Ll(e,t,n){let r=this.cache,i=t.length,a=el(n,i);Qc(r,a)||(e.uniform1iv(this.addr,a),$c(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Wc,a[e])}function Rl(e,t,n){let r=this.cache,i=t.length,a=el(n,i);Qc(r,a)||(e.uniform1iv(this.addr,a),$c(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||Gc,a[e])}function zl(e,t,n){let r=this.cache,i=t.length,a=el(n,i);Qc(r,a)||(e.uniform1iv(this.addr,a),$c(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||Uc,a[e])}function Bl(e){switch(e){case 5126:return xl;case 35664:return Sl;case 35665:return Cl;case 35666:return wl;case 35674:return Tl;case 35675:return El;case 35676:return Dl;case 5124:case 35670:return Ol;case 35667:case 35671:return kl;case 35668:case 35672:return Al;case 35669:case 35673:return jl;case 5125:return Ml;case 36294:return Nl;case 36295:return Pl;case 36296:return Fl;case 35678:case 36198:case 36298:case 36306:case 35682:return Il;case 35679:case 36299:case 36307:return Ll;case 35680:case 36300:case 36308:case 36293:return Rl;case 36289:case 36303:case 36311:case 36292:return zl}}var Vl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=bl(t.type)}},Hl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Bl(t.type)}},Ul=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},Wl=/(\w+)(\])?(\[|\.)?/g;function Gl(e,t){e.seq.push(t),e.map[t.id]=t}function Kl(e,t,n){let r=e.name,i=r.length;for(Wl.lastIndex=0;;){let a=Wl.exec(r),o=Wl.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){Gl(n,l===void 0?new Vl(s,e,t):new Hl(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new Ul(s),Gl(n,e)),n=e}}}var ql=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);Kl(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function Jl(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var Yl=37297,Xl=0;function Zl(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var Ql=new W;function $l(e){Pt._getMatrix(Ql,Pt.workingColorSpace,e);let t=`mat3( ${Ql.elements.map(e=>e.toFixed(4))} )`;switch(Pt.getTransfer(e)){case Re:return[t,`LinearTransferOETF`];case ze:return[t,`sRGBTransferOETF`];default:return B(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function eu(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+Zl(e.getShaderSource(t),r)}return i}function tu(e,t){let n=$l(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var nu={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function ru(e,t){let n=nu[t];return n===void 0?(B(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var iu=new U;function au(){return Pt.getLuminanceCoefficients(iu),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${iu.x.toFixed(4)}, ${iu.y.toFixed(4)}, ${iu.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function ou(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(lu).join(`
`)}function su(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function cu(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function lu(e){return e!==``}function uu(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function du(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var fu=/^[ \t]*#include +<([\w\d./]+)>/gm;function pu(e){return e.replace(fu,hu)}var mu=new Map;function hu(e,t){let n=ec[t];if(n===void 0){let e=mu.get(t);if(e!==void 0)n=ec[e],B(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return pu(n)}var gu=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function _u(e){return e.replace(gu,vu)}function vu(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function yu(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var bu={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function xu(e){return bu[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var Su={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function Cu(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:Su[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var wu={302:`ENVMAP_MODE_REFRACTION`};function Tu(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:wu[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var Eu={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function Du(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:Eu[e.combine]||`ENVMAP_BLENDING_NONE`}function Ou(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function ku(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=xu(n),l=Cu(n),u=Tu(n),d=Du(n),f=Ou(n),p=ou(n),m=su(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(lu).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(lu).join(`
`),_.length>0&&(_+=`
`)):(g=[yu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(lu).join(`
`),_=[yu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.retroreflection?`#define USE_RETROREFLECTION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:ec.tonemapping_pars_fragment,n.toneMapping===0?``:ru(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,ec.colorspace_pars_fragment,tu(`linearToOutputTexel`,n.outputColorSpace),au(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(lu).join(`
`)),o=pu(o),o=uu(o,n),o=du(o,n),s=pu(s),s=uu(s,n),s=du(s,n),o=_u(o),s=_u(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=Jl(i,i.VERTEX_SHADER,y),S=Jl(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=eu(i,x,`vertex`),n=eu(i,S,`fragment`);V(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):B(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new ql(i,h),T=cu(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,Yl)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=Xl++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var Au=0,ju=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Mu(e),t.set(e,n)),n}},Mu=class{constructor(e){this.id=Au++,this.code=e,this.usedTimes=0}};function Nu(e){return e===1030||e===37490||e===36285}function Pu(e,t,n,r,i,a){let o=new cn,s=new ju,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&B(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=tc[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),M=e.state.buffers.depth.getReversed(),ee=h.isInstancedMesh===!0,N=h.isBatchedMesh===!0,P=!!i.map,F=!!i.matcap,te=!!x,ne=!!i.aoMap,re=!!i.lightMap,ie=!!i.bumpMap&&i.wireframe===!1,ae=!!i.normalMap,oe=!!i.displacementMap,se=!!i.emissiveMap,I=!!i.metalnessMap,ce=!!i.roughnessMap,le=i.anisotropy>0,ue=i.clearcoat>0,de=i.dispersion>0,fe=i.retroreflectivity>0,pe=i.iridescence>0,me=i.sheen>0,he=i.transmission>0,ge=le&&!!i.anisotropyMap,_e=ue&&!!i.clearcoatMap,ve=ue&&!!i.clearcoatNormalMap,ye=ue&&!!i.clearcoatRoughnessMap,be=pe&&!!i.iridescenceMap,xe=pe&&!!i.iridescenceThicknessMap,Se=me&&!!i.sheenColorMap,Ce=me&&!!i.sheenRoughnessMap,we=!!i.specularMap,Te=!!i.specularColorMap,Ee=!!i.specularIntensityMap,De=he&&!!i.transmissionMap,Oe=he&&!!i.thicknessMap,ke=!!i.gradientMap,Ae=!!i.alphaMap,je=i.alphaTest>0,L=!!i.alphaHash,Me=!!i.extensions,Ne=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Ne=e.toneMapping);let Pe={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:N,batchingColor:N&&h._colorsTexture!==null,instancing:ee,instancingColor:ee&&h.instanceColor!==null,instancingMorph:ee&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:Pt.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:P,matcap:F,envMap:te,envMapMode:te&&x.mapping,envMapCubeUVHeight:S,aoMap:ne,lightMap:re,bumpMap:ie,normalMap:ae,displacementMap:oe,emissiveMap:se,normalMapObjectSpace:ae&&i.normalMapType===1,normalMapTangentSpace:ae&&i.normalMapType===0,packedNormalMap:ae&&i.normalMapType===0&&Nu(i.normalMap.format),metalnessMap:I,roughnessMap:ce,anisotropy:le,anisotropyMap:ge,clearcoat:ue,clearcoatMap:_e,clearcoatNormalMap:ve,clearcoatRoughnessMap:ye,dispersion:de,retroreflection:fe,iridescence:pe,iridescenceMap:be,iridescenceThicknessMap:xe,sheen:me,sheenColorMap:Se,sheenRoughnessMap:Ce,specularMap:we,specularColorMap:Te,specularIntensityMap:Ee,transmission:he,transmissionMap:De,thicknessMap:Oe,gradientMap:ke,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Ae,alphaTest:je,alphaHash:L,combine:i.combine,mapUv:P&&m(i.map.channel),aoMapUv:ne&&m(i.aoMap.channel),lightMapUv:re&&m(i.lightMap.channel),bumpMapUv:ie&&m(i.bumpMap.channel),normalMapUv:ae&&m(i.normalMap.channel),displacementMapUv:oe&&m(i.displacementMap.channel),emissiveMapUv:se&&m(i.emissiveMap.channel),metalnessMapUv:I&&m(i.metalnessMap.channel),roughnessMapUv:ce&&m(i.roughnessMap.channel),anisotropyMapUv:ge&&m(i.anisotropyMap.channel),clearcoatMapUv:_e&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:ve&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ye&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:be&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:xe&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:Se&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:Ce&&m(i.sheenRoughnessMap.channel),specularMapUv:we&&m(i.specularMap.channel),specularColorMapUv:Te&&m(i.specularColorMap.channel),specularIntensityMapUv:Ee&&m(i.specularIntensityMap.channel),transmissionMapUv:De&&m(i.transmissionMap.channel),thicknessMapUv:Oe&&m(i.thicknessMap.channel),alphaMapUv:Ae&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(ae||le),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(P||Ae),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&ae===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:M,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numSunLights:o.sun.length,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numSunLightShadows:o.sunShadowMap.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Ne,decodeVideoTexture:P&&i.map.isVideoTexture===!0&&Pt.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:se&&i.emissiveMap.isVideoTexture===!0&&Pt.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Me&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Me&&i.extensions.multiDraw===!0||N)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return Pe.vertexUv1s=c.has(1),Pe.vertexUv2s=c.has(2),Pe.vertexUv3s=c.has(3),c.clear(),Pe}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numSunLights),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numSunLightShadows),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.retroreflection&&o.enable(24),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=tc[t];n=zo.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new ku(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function Fu(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function Iu(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Lu(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Ru(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l,u){u.reversedDepth===!0&&(c=-c);let d=s(e,t,a,o,c,l);a.transmission>0?r.push(d):a.transparent===!0?i.push(d):n.push(d)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t){n.length>1&&n.sort(e||Iu),r.length>1&&r.sort(t||Lu),i.length>1&&i.sort(t||Lu)}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function zu(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new Ru,e.set(t,[i])):n>=r.length?(i=new Ru,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function Bu(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={direction:new U,color:new K};break;case`SpotLight`:n={position:new U,direction:new U,color:new K,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new U,color:new K,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new U,skyColor:new K,groundColor:new K};break;case`RectAreaLight`:n={color:new K,position:new U,halfWidth:new U,halfHeight:new U}}return e[t.id]=n,n}}}function Vu(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new H};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new H};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new H,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var Hu=0;function Uu(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Wu(e){let t=new Bu,n=Vu(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new U);let i=new U,a=new Xt,o=new Xt;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0,y=0,b=0,x=0;i.sort(Uu);for(let e=0,S=i.length;e<S;e++){let S=i[e],C=S.color,w=S.intensity,T=S.distance,E=null;if(S.shadow&&S.shadow.map&&(E=S.shadow.map.texture.format===1030?S.shadow.map.texture:S.shadow.map.depthTexture||S.shadow.map.texture),S.isAmbientLight)a+=C.r*w,o+=C.g*w,s+=C.b*w;else if(S.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(S.sh.coefficients[e],w);x++}else if(S.isSunLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()),r.sunShadow[l]=t,r.sunShadowMap[l]=E;let i=e.getViewportCount();for(let t=0;t<i;t++)r.sunShadowMatrix[u+t]=e.getMatrix(t),r.sunShadowCascade[u+t]=e._cascadeData[t];u+=i,l++}r.sun[c]=e,c++}else if(S.isDirectionalLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[d]=t,r.directionalShadowMap[d]=E,r.directionalShadowMatrix[d]=S.shadow.matrix,g++}r.directional[d]=e,d++}else if(S.isSpotLight){let e=t.get(S);e.position.setFromMatrixPosition(S.matrixWorld),e.color.copy(C).multiplyScalar(w),e.distance=T,e.coneCos=Math.cos(S.angle),e.penumbraCos=Math.cos(S.angle*(1-S.penumbra)),e.decay=S.decay,r.spot[p]=e;let i=S.shadow;if(S.map&&(r.spotLightMap[y]=S.map,y++,i.updateMatrices(S),S.castShadow&&b++),r.spotLightMatrix[p]=i.matrix,S.castShadow){let e=n.get(S);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[p]=e,r.spotShadowMap[p]=E,v++}p++}else if(S.isRectAreaLight){let e=t.get(S);e.color.copy(C).multiplyScalar(w),e.halfWidth.set(S.width*.5,0,0),e.halfHeight.set(0,S.height*.5,0),r.rectArea[m]=e,m++}else if(S.isPointLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),e.distance=S.distance,e.decay=S.decay,S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[f]=t,r.pointShadowMap[f]=E,r.pointShadowMatrix[f]=S.shadow.matrix,_++}r.point[f]=e,f++}else if(S.isHemisphereLight){let e=t.get(S);e.skyColor.copy(S.color).multiplyScalar(w),e.groundColor.copy(S.groundColor).multiplyScalar(w),r.hemi[h]=e,h++}}m>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=J.LTC_FLOAT_1,r.rectAreaLTC2=J.LTC_FLOAT_2):(r.rectAreaLTC1=J.LTC_HALF_1,r.rectAreaLTC2=J.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let S=r.hash;(S.sunLength!==c||S.directionalLength!==d||S.pointLength!==f||S.spotLength!==p||S.rectAreaLength!==m||S.hemiLength!==h||S.numSunShadows!==l||S.numDirectionalShadows!==g||S.numPointShadows!==_||S.numSpotShadows!==v||S.numSpotMaps!==y||S.numLightProbes!==x)&&(r.sun.length=c,r.directional.length=d,r.spot.length=p,r.rectArea.length=m,r.point.length=f,r.hemi.length=h,r.sunShadow.length=l,r.sunShadowMap.length=l,r.sunShadowMatrix.length=u,r.sunShadowCascade.length=u,r.directionalShadow.length=g,r.directionalShadowMap.length=g,r.directionalShadowMatrix.length=g,r.pointShadow.length=_,r.pointShadowMap.length=_,r.pointShadowMatrix.length=_,r.spotShadow.length=v,r.spotShadowMap.length=v,r.spotLightMatrix.length=v+y-b,r.spotLightMap.length=y,r.numSpotLightShadowsWithMaps=b,r.numLightProbes=x,S.sunLength=c,S.directionalLength=d,S.pointLength=f,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=h,S.numSunShadows=l,S.numDirectionalShadows=g,S.numPointShadows=_,S.numSpotShadows=v,S.numSpotMaps=y,S.numLightProbes=x,r.version=Hu++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=0,f=t.matrixWorldInverse;for(let t=0,p=e.length;t<p;t++){let p=e[t];if(p.isSunLight){let e=r.sun[n];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),n++}else if(p.isDirectionalLight){let e=r.directional[s];e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),s++}else if(p.isSpotLight){let e=r.spot[l];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),l++}else if(p.isRectAreaLight){let e=r.rectArea[u];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),o.identity(),a.copy(p.matrixWorld),a.premultiply(f),o.extractRotation(a),e.halfWidth.set(p.width*.5,0,0),e.halfHeight.set(0,p.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),u++}else if(p.isPointLight){let e=r.point[c];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),c++}else if(p.isHemisphereLight){let e=r.hemi[d];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),d++}}}return{setup:s,setupView:c,state:r}}function Gu(e){let t=new Wu(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function Ku(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new Gu(e),t.set(n,[a])):r>=i.length?(a=new Gu(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var qu=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ju=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Yu=[new U(1,0,0),new U(-1,0,0),new U(0,1,0),new U(0,-1,0),new U(0,0,1),new U(0,0,-1)],Xu=[new U(0,-1,0),new U(0,-1,0),new U(0,0,1),new U(0,0,-1),new U(0,-1,0),new U(0,-1,0)],Zu=new Xt,Qu=new U,$u=new U;function ed(e,t,n){let i=new ji,a=new H,s=new H,c=new Gt,l=new Ko,u=new qo,d={},f=n.maxTextureSize,p={0:1,1:0,2:2},_=new Ho({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new H},radius:{value:4}},vertexShader:qu,fragmentShader:Ju}),v=_.clone();v.defines.HORIZONTAL_PASS=1;let y=new Dr;y.setAttribute(`position`,new fr(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let b=new q(y,_),x=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let S=this.type;this.render=function(t,n,l){if(x.enabled===!1||x.autoUpdate===!1&&x.needsUpdate===!1||t.length===0)return;this.type===2&&(B(`WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead.`),this.type=1);let u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),_=e.state;_.setBlending(0),_.buffers.depth.getReversed()===!0?_.buffers.color.setClear(0,0,0,0):_.buffers.color.setClear(1,1,1,1),_.buffers.depth.setTest(!0),_.setScissorTest(!1);let v=S!==this.type;v&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let u=0,d=t.length;u<d;u++){let d=t[u],p=d.shadow;if(p===void 0){B(`WebGLShadowMap:`,d,`has no shadow.`);continue}if(p.autoUpdate===!1&&p.needsUpdate===!1)continue;a.copy(p.mapSize);let y=p.getFrameExtents();a.multiply(y),s.copy(p.mapSize),(a.x>f||a.y>f)&&(a.x>f&&(s.x=Math.floor(f/y.x),a.x=s.x*y.x,p.mapSize.x=s.x),a.y>f&&(s.y=Math.floor(f/y.y),a.y=s.y*y.y,p.mapSize.y=s.y));let b=e.state.buffers.depth.getReversed();if(p.camera._reversedDepth=b,p.map===null||v===!0){if(p.map!==null&&(p.map.depthTexture!==null&&(p.map.depthTexture.dispose(),p.map.depthTexture=null),p.map.dispose()),this.type===3){if(d.isPointLight){B(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}p.map=new qt(a.x,a.y,{format:k,type:g,minFilter:o,magFilter:o,generateMipmaps:!1}),p.map.texture.name=d.name+`.shadowMap`,p.map.depthTexture=new ea(a.x,a.y,h),p.map.depthTexture.name=d.name+`.shadowMapDepth`,p.map.depthTexture.format=T,p.map.depthTexture.compareFunction=null,p.map.depthTexture.minFilter=r,p.map.depthTexture.magFilter=r}else d.isPointLight?(p.map=new jc(a.x),p.map.depthTexture=new ta(a.x,m)):(p.map=new qt(a.x,a.y),p.map.depthTexture=new ea(a.x,a.y,m)),p.map.depthTexture.name=d.name+`.shadowMap`,p.map.depthTexture.format=T,this.type===1?(p.map.depthTexture.compareFunction=b?518:515,p.map.depthTexture.minFilter=o,p.map.depthTexture.magFilter=o):(p.map.depthTexture.compareFunction=null,p.map.depthTexture.minFilter=r,p.map.depthTexture.magFilter=r);p.camera.updateProjectionMatrix()}p.map.isWebGLCubeRenderTarget!==!0&&(p.map.width!==a.x||p.map.height!==a.y)&&p.map.setSize(a.x,a.y);let x=p.map.isWebGLCubeRenderTarget?6:p.getViewportCount();d.isPointLight!==!0&&p.updateMatrices(d,l);for(let t=0;t<x;t++){let r=p.getCamera(t);if(d.isPointLight){let e=p.camera,n=p.matrix,r=d.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),Qu.setFromMatrixPosition(d.matrixWorld),e.position.copy(Qu),$u.copy(e.position),$u.add(Yu[t]),e.up.copy(Xu[t]),e.lookAt($u),e.updateMatrixWorld(),n.makeTranslation(-Qu.x,-Qu.y,-Qu.z),Zu.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),p._frustum.setFromProjectionMatrix(Zu,e.coordinateSystem,e.reversedDepth)}if(p.map.isWebGLCubeRenderTarget)e.setRenderTarget(p.map,t),e.clear();else{t===0&&(e.setRenderTarget(p.map),e.clear());let n=p.getViewport(t);c.set(s.x*n.x,s.y*n.y,s.x*n.z,s.y*n.w),_.viewport(c)}i=p.getFrustum(t),E(n,l,r,d,this.type)}p.isPointLightShadow!==!0&&this.type===3&&C(p,l),p.needsUpdate=!1}S=this.type,x.needsUpdate=!1,e.setRenderTarget(u,d,p)};function C(n,r){let i=t.update(b);_.defines.VSM_SAMPLES!==n.blurSamples&&(_.defines.VSM_SAMPLES=n.blurSamples,v.defines.VSM_SAMPLES=n.blurSamples,_.needsUpdate=!0,v.needsUpdate=!0),n.mapPass===null?n.mapPass=new qt(a.x,a.y,{format:k,type:g}):(n.mapPass.width!==n.map.width||n.mapPass.height!==n.map.height)&&n.mapPass.setSize(n.map.width,n.map.height),_.uniforms.shadow_pass.value=n.map.depthTexture,_.uniforms.resolution.value.set(n.map.width,n.map.height),_.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,i,_,b,null),v.uniforms.shadow_pass.value=n.mapPass.texture,v.uniforms.resolution.value.set(n.map.width,n.map.height),v.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,i,v,b,null)}function w(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?u:l,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=d[e];r===void 0&&(r={},d[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,D)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?p[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function E(n,r,a,o,s){if(n.visible===!1)return;if(n.layers.test(r.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||n.intersectsFrustum(i))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let i=t.update(n),c=n.material;if(Array.isArray(c)){let t=i.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=w(n,d,o,s);n.onBeforeShadow(e,n,r,a,i,t,u),e.renderBufferDirect(a,null,i,t,n,u),n.onAfterShadow(e,n,r,a,i,t,u)}}}else if(c.visible){let t=w(n,c,o,s);n.onBeforeShadow(e,n,r,a,i,t,null),e.renderBufferDirect(a,null,i,t,n,null),n.onAfterShadow(e,n,r,a,i,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)E(c[e],r,a,o,s)}function D(e){e.target.removeEventListener(`dispose`,D);for(let t in d){let n=d[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function td(e,t){function n(){let t=!1,n=new Gt,r=null,i=new Gt(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?I(e.DEPTH_TEST):ce(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=Qe[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?I(e.STENCIL_TEST):ce(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new K(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,M=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),ee=!1,N=0,P=e.getParameter(e.VERSION);P.indexOf(`WebGL`)===-1?P.indexOf(`OpenGL ES`)!==-1&&(N=parseFloat(/^OpenGL ES (\d)/.exec(P)[1]),ee=N>=2):(N=parseFloat(/^WebGL (\d)/.exec(P)[1]),ee=N>=1);let F=null,te={},ne=e.getParameter(e.SCISSOR_BOX),re=e.getParameter(e.VIEWPORT),ie=new Gt().fromArray(ne),ae=new Gt().fromArray(re);function oe(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let se={};se[e.TEXTURE_2D]=oe(e.TEXTURE_2D,e.TEXTURE_2D,1),se[e.TEXTURE_CUBE_MAP]=oe(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),se[e.TEXTURE_2D_ARRAY]=oe(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),se[e.TEXTURE_3D]=oe(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),I(e.DEPTH_TEST),o.setFunc(3),ge(!1),_e(1),I(e.CULL_FACE),me(0);function I(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function ce(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function le(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function ue(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function de(t){return h!==t&&(e.useProgram(t),h=t,!0)}let fe={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};fe[103]=e.MIN,fe[104]=e.MAX;let pe={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function me(t,n,r,i,a,o,s,c,l,u){if(t===0)g===!0&&(ce(e.BLEND),g=!1);else if(g===!1&&(I(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:V(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:V(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:V(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:V(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}}else a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(fe[n],fe[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(pe[r],pe[i],pe[o],pe[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function he(t,n){t.side===2?ce(e.CULL_FACE):I(e.CULL_FACE);let r=t.side===1;n&&(r=!r),ge(r),t.blending===1&&t.transparent===!1?me(0):me(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),ye(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?I(e.SAMPLE_ALPHA_TO_COVERAGE):ce(e.SAMPLE_ALPHA_TO_COVERAGE)}function ge(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function _e(t){t===0?ce(e.CULL_FACE):(I(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function ve(t){t!==k&&(ee&&e.lineWidth(t),k=t)}function ye(t,n,r){t?(I(e.POLYGON_OFFSET_FILL),(A!==n||j!==r)&&(A=n,j=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):ce(e.POLYGON_OFFSET_FILL)}function be(t){t?I(e.SCISSOR_TEST):ce(e.SCISSOR_TEST)}function xe(t){t===void 0&&(t=e.TEXTURE0+M-1),F!==t&&(e.activeTexture(t),F=t)}function Se(t,n,r){r===void 0&&(r=F===null?e.TEXTURE0+M-1:F);let i=te[r];i===void 0&&(i={type:void 0,texture:void 0},te[r]=i),(i.type!==t||i.texture!==n)&&(F!==r&&(e.activeTexture(r),F=r),e.bindTexture(t,n||se[t]),i.type=t,i.texture=n)}function Ce(){let t=te[F];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function we(){try{e.compressedTexImage2D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Te(){try{e.compressedTexImage3D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Ee(){try{e.texSubImage2D(...arguments)}catch(e){V(`WebGLState:`,e)}}function De(){try{e.texSubImage3D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Oe(){try{e.compressedTexSubImage2D(...arguments)}catch(e){V(`WebGLState:`,e)}}function ke(){try{e.compressedTexSubImage3D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Ae(){try{e.texStorage2D(...arguments)}catch(e){V(`WebGLState:`,e)}}function je(){try{e.texStorage3D(...arguments)}catch(e){V(`WebGLState:`,e)}}function L(){try{e.texImage2D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Me(){try{e.texImage3D(...arguments)}catch(e){V(`WebGLState:`,e)}}function Ne(t){return d[t]===void 0?e.getParameter(t):d[t]}function Pe(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function R(t){ie.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),ie.copy(t))}function Fe(t){ae.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),ae.copy(t))}function z(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function Ie(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function Le(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},F=null,te={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new K(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ie.set(0,0,e.canvas.width,e.canvas.height),ae.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:I,disable:ce,bindFramebuffer:le,drawBuffers:ue,useProgram:de,setBlending:me,setMaterial:he,setFlipSided:ge,setCullFace:_e,setLineWidth:ve,setPolygonOffset:ye,setScissorTest:be,activeTexture:xe,bindTexture:Se,unbindTexture:Ce,compressedTexImage2D:we,compressedTexImage3D:Te,texImage2D:L,texImage3D:Me,pixelStorei:Pe,getParameter:Ne,updateUBOMapping:z,uniformBlockBinding:Ie,texStorage2D:Ae,texStorage3D:je,texSubImage2D:Ee,texSubImage3D:De,compressedTexSubImage2D:Oe,compressedTexSubImage3D:ke,scissor:R,viewport:Fe,reset:Le}}function nd(l,u,d,f,p,m,h){let g=u.has(`WEBGL_multisampled_render_to_texture`)?u.get(`WEBGL_multisampled_render_to_texture`):null,_=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),v=new H,y=new WeakMap,b=new Set,x,S=new WeakMap,C=!1;try{C=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function w(e,t){return C?new OffscreenCanvas(e,t):Ge(`canvas`)}function T(e,t,n){let r=1,i=Ne(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);x===void 0&&(x=w(n,a));let o=t?w(n,a):x;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),B(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&B(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function D(e){return e.generateMipmaps}function O(e){l.generateMipmap(e)}function k(e){return e.isWebGLCubeRenderTarget?l.TEXTURE_CUBE_MAP:e.isWebGL3DRenderTarget?l.TEXTURE_3D:e.isWebGLArrayRenderTarget||e.isCompressedArrayTexture?l.TEXTURE_2D_ARRAY:l.TEXTURE_2D}function A(e,t,n,r,i,a=!1){if(e!==null){if(l[e]!==void 0)return l[e];B(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+e+`'`)}let o;r&&(o=u.get(`EXT_texture_norm16`),o||B(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let s=t;if(t===l.RED&&(n===l.FLOAT&&(s=l.R32F),n===l.HALF_FLOAT&&(s=l.R16F),n===l.UNSIGNED_BYTE&&(s=l.R8),n===l.UNSIGNED_SHORT&&o&&(s=o.R16_EXT),n===l.SHORT&&o&&(s=o.R16_SNORM_EXT)),t===l.RED_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.R8UI),n===l.UNSIGNED_SHORT&&(s=l.R16UI),n===l.UNSIGNED_INT&&(s=l.R32UI),n===l.BYTE&&(s=l.R8I),n===l.SHORT&&(s=l.R16I),n===l.INT&&(s=l.R32I)),t===l.RG&&(n===l.FLOAT&&(s=l.RG32F),n===l.HALF_FLOAT&&(s=l.RG16F),n===l.UNSIGNED_BYTE&&(s=l.RG8),n===l.UNSIGNED_SHORT&&o&&(s=o.RG16_EXT),n===l.SHORT&&o&&(s=o.RG16_SNORM_EXT)),t===l.RG_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RG8UI),n===l.UNSIGNED_SHORT&&(s=l.RG16UI),n===l.UNSIGNED_INT&&(s=l.RG32UI),n===l.BYTE&&(s=l.RG8I),n===l.SHORT&&(s=l.RG16I),n===l.INT&&(s=l.RG32I)),t===l.RGB_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RGB8UI),n===l.UNSIGNED_SHORT&&(s=l.RGB16UI),n===l.UNSIGNED_INT&&(s=l.RGB32UI),n===l.BYTE&&(s=l.RGB8I),n===l.SHORT&&(s=l.RGB16I),n===l.INT&&(s=l.RGB32I)),t===l.RGBA_INTEGER&&(n===l.UNSIGNED_BYTE&&(s=l.RGBA8UI),n===l.UNSIGNED_SHORT&&(s=l.RGBA16UI),n===l.UNSIGNED_INT&&(s=l.RGBA32UI),n===l.BYTE&&(s=l.RGBA8I),n===l.SHORT&&(s=l.RGBA16I),n===l.INT&&(s=l.RGBA32I)),t===l.RGB&&(n===l.UNSIGNED_SHORT&&o&&(s=o.RGB16_EXT),n===l.SHORT&&o&&(s=o.RGB16_SNORM_EXT),n===l.UNSIGNED_INT_5_9_9_9_REV&&(s=l.RGB9_E5),n===l.UNSIGNED_INT_10F_11F_11F_REV&&(s=l.R11F_G11F_B10F)),t===l.RGBA){let e=a?Re:Pt.getTransfer(i);n===l.FLOAT&&(s=l.RGBA32F),n===l.HALF_FLOAT&&(s=l.RGBA16F),n===l.UNSIGNED_BYTE&&(s=e===`srgb`?l.SRGB8_ALPHA8:l.RGBA8),n===l.UNSIGNED_SHORT&&o&&(s=o.RGBA16_EXT),n===l.SHORT&&o&&(s=o.RGBA16_SNORM_EXT),n===l.UNSIGNED_SHORT_4_4_4_4&&(s=l.RGBA4),n===l.UNSIGNED_SHORT_5_5_5_1&&(s=l.RGB5_A1)}return(s===l.R16F||s===l.R32F||s===l.RG16F||s===l.RG32F||s===l.RGBA16F||s===l.RGBA32F)&&u.get(`EXT_color_buffer_float`),s}function j(e,t){let n;return e?t===null||t===1014||t===1020?n=l.DEPTH24_STENCIL8:t===1015?n=l.DEPTH32F_STENCIL8:t===1012&&(n=l.DEPTH24_STENCIL8,B(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):t===null||t===1014||t===1020?n=l.DEPTH_COMPONENT24:t===1015?n=l.DEPTH_COMPONENT32F:t===1012&&(n=l.DEPTH_COMPONENT16),n}function M(e,t){return D(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function ee(e){let t=e.target;t.removeEventListener(`dispose`,ee),P(t),t.isVideoTexture&&y.delete(t),t.isHTMLTexture&&b.delete(t)}function N(e){let t=e.target;t.removeEventListener(`dispose`,N),te(t)}function P(e){let t=f.get(e);if(t.__webglInit===void 0)return;let n=e.source,r=S.get(n);if(r){let i=r[t.__cacheKey];i.usedTimes--,i.usedTimes===0&&F(e),Object.keys(r).length===0&&S.delete(n)}f.remove(e)}function F(e){let t=f.get(e);l.deleteTexture(t.__webglTexture);let n=e.source,r=S.get(n);delete r[t.__cacheKey],h.memory.textures--}function te(e){let t=f.get(e);if(e.depthTexture&&(e.depthTexture.dispose(),f.remove(e.depthTexture)),e.isWebGLCubeRenderTarget)for(let e=0;e<6;e++){if(Array.isArray(t.__webglFramebuffer[e]))for(let n=0;n<t.__webglFramebuffer[e].length;n++)l.deleteFramebuffer(t.__webglFramebuffer[e][n]);else l.deleteFramebuffer(t.__webglFramebuffer[e]);t.__webglDepthbuffer&&l.deleteRenderbuffer(t.__webglDepthbuffer[e])}else{if(Array.isArray(t.__webglFramebuffer))for(let e=0;e<t.__webglFramebuffer.length;e++)l.deleteFramebuffer(t.__webglFramebuffer[e]);else l.deleteFramebuffer(t.__webglFramebuffer);if(t.__webglDepthbuffer&&l.deleteRenderbuffer(t.__webglDepthbuffer),t.__webglMultisampledFramebuffer&&l.deleteFramebuffer(t.__webglMultisampledFramebuffer),t.__webglColorRenderbuffer)for(let e=0;e<t.__webglColorRenderbuffer.length;e++)t.__webglColorRenderbuffer[e]&&l.deleteRenderbuffer(t.__webglColorRenderbuffer[e]);t.__webglDepthRenderbuffer&&l.deleteRenderbuffer(t.__webglDepthRenderbuffer)}let n=e.textures;for(let e=0,t=n.length;e<t;e++){let t=f.get(n[e]);t.__webglTexture&&(l.deleteTexture(t.__webglTexture),h.memory.textures--),f.remove(n[e])}f.remove(e)}let ne=0;function re(){ne=0}function ie(){return ne}function ae(e){ne=e}function oe(){let e=ne;return e>=p.maxTextures&&B(`WebGLTextures: Trying to use `+(e+1)+` texture units while this GPU supports only `+p.maxTextures),ne+=1,e}function se(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function I(e,t){let n=f.get(e);if(e.isVideoTexture&&L(e),e.isRenderTargetTexture===!1&&e.isExternalTexture!==!0&&e.version>0&&n.__version!==e.version){let r=e.image;if(r===null)B(`WebGLRenderer: Texture marked for update but no image data found.`);else if(r.complete===!1)B(`WebGLRenderer: Texture marked for update but image is incomplete`);else{ve(n,e,t);return}}else e.isExternalTexture&&(n.__webglTexture=e.sourceTexture?e.sourceTexture:null);d.bindTexture(l.TEXTURE_2D,n.__webglTexture,l.TEXTURE0+t)}function ce(e,t){let n=f.get(e);e.isRenderTargetTexture===!1&&e.version>0&&n.__version!==e.version?ve(n,e,t):(e.isExternalTexture&&(n.__webglTexture=e.sourceTexture?e.sourceTexture:null),d.bindTexture(l.TEXTURE_2D_ARRAY,n.__webglTexture,l.TEXTURE0+t))}function le(e,t){let n=f.get(e);e.isRenderTargetTexture===!1&&e.version>0&&n.__version!==e.version?ve(n,e,t):d.bindTexture(l.TEXTURE_3D,n.__webglTexture,l.TEXTURE0+t)}function ue(e,t){let n=f.get(e);e.isCubeDepthTexture!==!0&&e.version>0&&n.__version!==e.version?ye(n,e,t):d.bindTexture(l.TEXTURE_CUBE_MAP,n.__webglTexture,l.TEXTURE0+t)}let de={[e]:l.REPEAT,[t]:l.CLAMP_TO_EDGE,[n]:l.MIRRORED_REPEAT},fe={[r]:l.NEAREST,[i]:l.NEAREST_MIPMAP_NEAREST,[a]:l.NEAREST_MIPMAP_LINEAR,[o]:l.LINEAR,[s]:l.LINEAR_MIPMAP_NEAREST,[c]:l.LINEAR_MIPMAP_LINEAR},pe={512:l.NEVER,519:l.ALWAYS,513:l.LESS,515:l.LEQUAL,514:l.EQUAL,518:l.GEQUAL,516:l.GREATER,517:l.NOTEQUAL};function me(e,t){if(t.type===1015&&u.has(`OES_texture_float_linear`)===!1&&(t.magFilter===1006||t.magFilter===1007||t.magFilter===1005||t.magFilter===1008||t.minFilter===1006||t.minFilter===1007||t.minFilter===1005||t.minFilter===1008)&&B(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),l.texParameteri(e,l.TEXTURE_WRAP_S,de[t.wrapS]),l.texParameteri(e,l.TEXTURE_WRAP_T,de[t.wrapT]),(e===l.TEXTURE_3D||e===l.TEXTURE_2D_ARRAY)&&l.texParameteri(e,l.TEXTURE_WRAP_R,de[t.wrapR]),l.texParameteri(e,l.TEXTURE_MAG_FILTER,fe[t.magFilter]),l.texParameteri(e,l.TEXTURE_MIN_FILTER,fe[t.minFilter]),t.compareFunction&&(l.texParameteri(e,l.TEXTURE_COMPARE_MODE,l.COMPARE_REF_TO_TEXTURE),l.texParameteri(e,l.TEXTURE_COMPARE_FUNC,pe[t.compareFunction])),u.has(`EXT_texture_filter_anisotropic`)===!0){if(t.magFilter===1003||t.minFilter!==1005&&t.minFilter!==1008||t.type===1015&&u.has(`OES_texture_float_linear`)===!1)return;if(t.anisotropy>1||f.get(t).__currentAnisotropy){let n=u.get(`EXT_texture_filter_anisotropic`);l.texParameterf(e,n.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(t.anisotropy,p.getMaxAnisotropy())),f.get(t).__currentAnisotropy=t.anisotropy}}}function he(e,t){let n=!1;e.__webglInit===void 0&&(e.__webglInit=!0,t.addEventListener(`dispose`,ee));let r=t.source,i=S.get(r);i===void 0&&(i={},S.set(r,i));let a=se(t);if(a!==e.__cacheKey){i[a]===void 0&&(i[a]={texture:l.createTexture(),usedTimes:0},h.memory.textures++,n=!0),i[a].usedTimes++;let r=i[e.__cacheKey];r!==void 0&&(i[e.__cacheKey].usedTimes--,r.usedTimes===0&&F(t)),e.__cacheKey=a,e.__webglTexture=i[a].texture}return n}function ge(e,t,n){return Math.floor(Math.floor(e/n)/t)}function _e(e,t,n,r){let i=e.updateRanges;if(i.length===0)d.texSubImage2D(l.TEXTURE_2D,0,0,0,t.width,t.height,n,r,t.data);else{i.sort((e,t)=>e.start-t.start);let a=0;for(let e=1;e<i.length;e++){let n=i[a],r=i[e],o=n.start+n.count,s=ge(r.start,t.width,4),c=ge(n.start,t.width,4);r.start<=o+1&&s===c&&ge(r.start+r.count-1,t.width,4)===s?n.count=Math.max(n.count,r.start+r.count-n.start):(++a,i[a]=r)}i.length=a+1;let o=d.getParameter(l.UNPACK_ROW_LENGTH),s=d.getParameter(l.UNPACK_SKIP_PIXELS),c=d.getParameter(l.UNPACK_SKIP_ROWS);d.pixelStorei(l.UNPACK_ROW_LENGTH,t.width);for(let e=0,a=i.length;e<a;e++){let a=i[e],o=Math.floor(a.start/4),s=Math.ceil(a.count/4),c=o%t.width,u=Math.floor(o/t.width),f=s;d.pixelStorei(l.UNPACK_SKIP_PIXELS,c),d.pixelStorei(l.UNPACK_SKIP_ROWS,u),d.texSubImage2D(l.TEXTURE_2D,0,c,u,f,1,n,r,t.data)}e.clearUpdateRanges(),d.pixelStorei(l.UNPACK_ROW_LENGTH,o),d.pixelStorei(l.UNPACK_SKIP_PIXELS,s),d.pixelStorei(l.UNPACK_SKIP_ROWS,c)}}function ve(e,t,n){let r=l.TEXTURE_2D;(t.isDataArrayTexture||t.isCompressedArrayTexture)&&(r=l.TEXTURE_2D_ARRAY),t.isData3DTexture&&(r=l.TEXTURE_3D);let i=he(e,t),a=t.source;d.bindTexture(r,e.__webglTexture,l.TEXTURE0+n);let o=f.get(a);if(a.version!==o.__version||i===!0){if(d.activeTexture(l.TEXTURE0+n),!(typeof ImageBitmap<`u`&&t.image instanceof ImageBitmap)){let e=Pt.getPrimaries(Pt.workingColorSpace),n=t.colorSpace===``?null:Pt.getPrimaries(t.colorSpace),r=t.colorSpace===``||e===n?l.NONE:l.BROWSER_DEFAULT_WEBGL;d.pixelStorei(l.UNPACK_FLIP_Y_WEBGL,t.flipY),d.pixelStorei(l.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),d.pixelStorei(l.UNPACK_COLORSPACE_CONVERSION_WEBGL,r)}d.pixelStorei(l.UNPACK_ALIGNMENT,t.unpackAlignment);let e=T(t.image,!1,p.maxTextureSize);e=Me(t,e);let s=m.convert(t.format,t.colorSpace),c=m.convert(t.type),u=A(t.internalFormat,s,c,t.normalized,t.colorSpace,t.isVideoTexture);me(r,t);let f,h=t.mipmaps,g=t.isVideoTexture!==!0,_=o.__version===void 0||i===!0,v=a.dataReady,y=M(t,e);if(t.isDepthTexture)u=j(t.format===E,t.type),_&&(g?d.texStorage2D(l.TEXTURE_2D,1,u,e.width,e.height):d.texImage2D(l.TEXTURE_2D,0,u,e.width,e.height,0,s,c,null));else if(t.isDataTexture){if(h.length>0){g&&_&&d.texStorage2D(l.TEXTURE_2D,y,u,h[0].width,h[0].height);for(let e=0,t=h.length;e<t;e++)f=h[e],g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,c,f.data):d.texImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,s,c,f.data);t.generateMipmaps=!1}else g?(_&&d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height),v&&_e(t,e,s,c)):d.texImage2D(l.TEXTURE_2D,0,u,e.width,e.height,0,s,c,e.data)}else if(t.isCompressedTexture){if(t.isCompressedArrayTexture){g&&_&&d.texStorage3D(l.TEXTURE_2D_ARRAY,y,u,h[0].width,h[0].height,e.depth);for(let n=0,r=h.length;n<r;n++)if(f=h[n],t.format!==1023){if(s!==null){if(g){if(v){if(t.layerUpdates.size>0){let e=Xs(f.width,f.height,t.format,t.type);for(let r of t.layerUpdates){let t=f.data.subarray(r*e/f.data.BYTES_PER_ELEMENT,(r+1)*e/f.data.BYTES_PER_ELEMENT);d.compressedTexSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,r,f.width,f.height,1,s,t)}}else d.compressedTexSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,0,f.width,f.height,e.depth,s,f.data)}}else d.compressedTexImage3D(l.TEXTURE_2D_ARRAY,n,u,f.width,f.height,e.depth,0,f.data,0,0)}else B(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else g?v&&d.texSubImage3D(l.TEXTURE_2D_ARRAY,n,0,0,0,f.width,f.height,e.depth,s,c,f.data):d.texImage3D(l.TEXTURE_2D_ARRAY,n,u,f.width,f.height,e.depth,0,s,c,f.data);t.layerUpdates.size>0&&t.clearLayerUpdates()}else{g&&_&&d.texStorage2D(l.TEXTURE_2D,y,u,h[0].width,h[0].height);for(let e=0,n=h.length;e<n;e++)f=h[e],t.format===1023?g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,c,f.data):d.texImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,s,c,f.data):s===null?B(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):g?v&&d.compressedTexSubImage2D(l.TEXTURE_2D,e,0,0,f.width,f.height,s,f.data):d.compressedTexImage2D(l.TEXTURE_2D,e,u,f.width,f.height,0,f.data)}}else if(t.isDataArrayTexture){if(g){if(_&&d.texStorage3D(l.TEXTURE_2D_ARRAY,y,u,e.width,e.height,e.depth),v){if(t.layerUpdates.size>0){let n=Xs(e.width,e.height,t.format,t.type);for(let r of t.layerUpdates){let t=e.data.subarray(r*n/e.data.BYTES_PER_ELEMENT,(r+1)*n/e.data.BYTES_PER_ELEMENT);d.texSubImage3D(l.TEXTURE_2D_ARRAY,0,0,0,r,e.width,e.height,1,s,c,t)}t.clearLayerUpdates()}else d.texSubImage3D(l.TEXTURE_2D_ARRAY,0,0,0,0,e.width,e.height,e.depth,s,c,e.data)}}else d.texImage3D(l.TEXTURE_2D_ARRAY,0,u,e.width,e.height,e.depth,0,s,c,e.data)}else if(t.isData3DTexture)g?(_&&d.texStorage3D(l.TEXTURE_3D,y,u,e.width,e.height,e.depth),v&&d.texSubImage3D(l.TEXTURE_3D,0,0,0,0,e.width,e.height,e.depth,s,c,e.data)):d.texImage3D(l.TEXTURE_3D,0,u,e.width,e.height,e.depth,0,s,c,e.data);else if(t.isFramebufferTexture){if(_){if(g)d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height);else{let t=e.width,n=e.height;for(let e=0;e<y;e++)d.texImage2D(l.TEXTURE_2D,e,u,t,n,0,s,c,null),t>>=1,n>>=1}}}else if(t.isHTMLTexture){if(`texElementImage2D`in l){let n=l.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),e.parentNode!==n){n.appendChild(e),b.add(t),n.onpaint=e=>{let t=e.changedElements;for(let e of b)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(l.texElementImage2D.length===3)l.texElementImage2D(l.TEXTURE_2D,l.RGBA8,e);else{let t=l.RGBA,n=l.RGBA,r=l.UNSIGNED_BYTE;l.texElementImage2D(l.TEXTURE_2D,0,t,n,r,e)}l.texParameteri(l.TEXTURE_2D,l.TEXTURE_MIN_FILTER,l.LINEAR),l.texParameteri(l.TEXTURE_2D,l.TEXTURE_WRAP_S,l.CLAMP_TO_EDGE),l.texParameteri(l.TEXTURE_2D,l.TEXTURE_WRAP_T,l.CLAMP_TO_EDGE)}}else if(h.length>0){if(g&&_){let e=Ne(h[0]);d.texStorage2D(l.TEXTURE_2D,y,u,e.width,e.height)}for(let e=0,t=h.length;e<t;e++)f=h[e],g?v&&d.texSubImage2D(l.TEXTURE_2D,e,0,0,s,c,f):d.texImage2D(l.TEXTURE_2D,e,u,s,c,f);t.generateMipmaps=!1}else if(g){if(_){let t=Ne(e);d.texStorage2D(l.TEXTURE_2D,y,u,t.width,t.height)}v&&d.texSubImage2D(l.TEXTURE_2D,0,0,0,s,c,e)}else d.texImage2D(l.TEXTURE_2D,0,u,s,c,e);D(t)&&O(r),o.__version=a.version,t.onUpdate&&t.onUpdate(t)}e.__version=t.version}function ye(e,t,n){if(t.image.length!==6)return;let r=he(e,t),i=t.source;d.bindTexture(l.TEXTURE_CUBE_MAP,e.__webglTexture,l.TEXTURE0+n);let a=f.get(i);if(i.version!==a.__version||r===!0){d.activeTexture(l.TEXTURE0+n);let e=Pt.getPrimaries(Pt.workingColorSpace),o=t.colorSpace===``?null:Pt.getPrimaries(t.colorSpace),s=t.colorSpace===``||e===o?l.NONE:l.BROWSER_DEFAULT_WEBGL;d.pixelStorei(l.UNPACK_FLIP_Y_WEBGL,t.flipY),d.pixelStorei(l.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),d.pixelStorei(l.UNPACK_ALIGNMENT,t.unpackAlignment),d.pixelStorei(l.UNPACK_COLORSPACE_CONVERSION_WEBGL,s);let c=t.isCompressedTexture||t.image[0].isCompressedTexture,u=t.image[0]&&t.image[0].isDataTexture,f=[];for(let e=0;e<6;e++)!c&&!u?f[e]=T(t.image[e],!0,p.maxCubemapSize):f[e]=u?t.image[e].image:t.image[e],f[e]=Me(t,f[e]);let h=f[0],g=m.convert(t.format,t.colorSpace),_=m.convert(t.type),v=A(t.internalFormat,g,_,t.normalized,t.colorSpace),y=t.isVideoTexture!==!0,b=a.__version===void 0||r===!0,x=i.dataReady,S=M(t,h);me(l.TEXTURE_CUBE_MAP,t);let C;if(c){y&&b&&d.texStorage2D(l.TEXTURE_CUBE_MAP,S,v,h.width,h.height);for(let e=0;e<6;e++){C=f[e].mipmaps;for(let n=0;n<C.length;n++){let r=C[n];t.format===1023?y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,0,0,r.width,r.height,g,_,r.data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,v,r.width,r.height,0,g,_,r.data):g===null?B(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):y?x&&d.compressedTexSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,0,0,r.width,r.height,g,r.data):d.compressedTexImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,n,v,r.width,r.height,0,r.data)}}}else{if(C=t.mipmaps,y&&b){C.length>0&&S++;let e=Ne(f[0]);d.texStorage2D(l.TEXTURE_CUBE_MAP,S,v,e.width,e.height)}for(let e=0;e<6;e++)if(u){y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,0,0,f[e].width,f[e].height,g,_,f[e].data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,v,f[e].width,f[e].height,0,g,_,f[e].data);for(let t=0;t<C.length;t++){let n=C[t].image[e].image;y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,0,0,n.width,n.height,g,_,n.data):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,v,n.width,n.height,0,g,_,n.data)}}else{y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,0,0,g,_,f[e]):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,0,v,g,_,f[e]);for(let t=0;t<C.length;t++){let n=C[t];y?x&&d.texSubImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,0,0,g,_,n.image[e]):d.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+e,t+1,v,g,_,n.image[e])}}}D(t)&&O(l.TEXTURE_CUBE_MAP),a.__version=i.version,t.onUpdate&&t.onUpdate(t)}e.__version=t.version}function be(e,t,n,r,i,a){let o=m.convert(n.format,n.colorSpace),s=m.convert(n.type),c=A(n.internalFormat,o,s,n.normalized,n.colorSpace),u=f.get(t),p=f.get(n);if(p.__renderTarget=t,!u.__hasExternalTextures){let e=Math.max(1,t.width>>a),n=Math.max(1,t.height>>a);i===l.TEXTURE_3D||i===l.TEXTURE_2D_ARRAY?d.texImage3D(i,a,c,e,n,t.depth,0,o,s,null):d.texImage2D(i,a,c,e,n,0,o,s,null)}d.bindFramebuffer(l.FRAMEBUFFER,e),je(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,r,i,p.__webglTexture,0,Ae(t)):(i===l.TEXTURE_2D||i>=l.TEXTURE_CUBE_MAP_POSITIVE_X&&i<=l.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&l.framebufferTexture2D(l.FRAMEBUFFER,r,i,p.__webglTexture,a),d.bindFramebuffer(l.FRAMEBUFFER,null)}function xe(e,t,n){if(l.bindRenderbuffer(l.RENDERBUFFER,e),t.depthBuffer){let r=t.depthTexture,i=r&&r.isDepthTexture?r.type:null,a=j(t.stencilBuffer,i),o=t.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;je(t)?g.renderbufferStorageMultisampleEXT(l.RENDERBUFFER,Ae(t),a,t.width,t.height):n?l.renderbufferStorageMultisample(l.RENDERBUFFER,Ae(t),a,t.width,t.height):l.renderbufferStorage(l.RENDERBUFFER,a,t.width,t.height),l.framebufferRenderbuffer(l.FRAMEBUFFER,o,l.RENDERBUFFER,e)}else{let e=t.textures;for(let r=0;r<e.length;r++){let i=e[r],a=m.convert(i.format,i.colorSpace),o=m.convert(i.type),s=A(i.internalFormat,a,o,i.normalized,i.colorSpace);je(t)?g.renderbufferStorageMultisampleEXT(l.RENDERBUFFER,Ae(t),s,t.width,t.height):n?l.renderbufferStorageMultisample(l.RENDERBUFFER,Ae(t),s,t.width,t.height):l.renderbufferStorage(l.RENDERBUFFER,s,t.width,t.height)}}l.bindRenderbuffer(l.RENDERBUFFER,null)}function Se(e,t,n){let r=t.isWebGLCubeRenderTarget===!0;if(d.bindFramebuffer(l.FRAMEBUFFER,e),!(t.depthTexture&&t.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let i=f.get(t.depthTexture);if(i.__renderTarget=t,(!i.__webglTexture||t.depthTexture.image.width!==t.width||t.depthTexture.image.height!==t.height)&&(t.depthTexture.image.width=t.width,t.depthTexture.image.height=t.height,t.depthTexture.needsUpdate=!0),r){if(i.__webglInit===void 0&&(i.__webglInit=!0,t.depthTexture.addEventListener(`dispose`,ee)),i.__webglTexture===void 0){i.__webglTexture=l.createTexture(),d.bindTexture(l.TEXTURE_CUBE_MAP,i.__webglTexture),me(l.TEXTURE_CUBE_MAP,t.depthTexture);let e=m.convert(t.depthTexture.format),n=m.convert(t.depthTexture.type),r;t.depthTexture.format===1026?r=l.DEPTH_COMPONENT24:t.depthTexture.format===1027&&(r=l.DEPTH24_STENCIL8);for(let i=0;i<6;i++)l.texImage2D(l.TEXTURE_CUBE_MAP_POSITIVE_X+i,0,r,t.width,t.height,0,e,n,null)}}else I(t.depthTexture,0);let a=i.__webglTexture,o=Ae(t),s=r?l.TEXTURE_CUBE_MAP_POSITIVE_X+n:l.TEXTURE_2D,c=t.depthTexture.format===1027?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;if(t.depthTexture.format===1026)je(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,c,s,a,0,o):l.framebufferTexture2D(l.FRAMEBUFFER,c,s,a,0);else if(t.depthTexture.format===1027)je(t)?g.framebufferTexture2DMultisampleEXT(l.FRAMEBUFFER,c,s,a,0,o):l.framebufferTexture2D(l.FRAMEBUFFER,c,s,a,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function Ce(e){let t=f.get(e),n=e.isWebGLCubeRenderTarget===!0;if(t.__boundDepthTexture!==e.depthTexture){let n=e.depthTexture;if(t.__depthDisposeCallback&&t.__depthDisposeCallback(),n){let e=()=>{delete t.__boundDepthTexture,delete t.__depthDisposeCallback,n.removeEventListener(`dispose`,e)};n.addEventListener(`dispose`,e),t.__depthDisposeCallback=e}t.__boundDepthTexture=n}if(e.depthTexture&&!t.__autoAllocateDepthBuffer){if(n)for(let n=0;n<6;n++)Se(t.__webglFramebuffer[n],e,n);else{let n=e.texture.mipmaps;n&&n.length>0?Se(t.__webglFramebuffer[0],e,0):Se(t.__webglFramebuffer,e,0)}}else if(n){t.__webglDepthbuffer=[];for(let n=0;n<6;n++)if(d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer[n]),t.__webglDepthbuffer[n]===void 0)t.__webglDepthbuffer[n]=l.createRenderbuffer(),xe(t.__webglDepthbuffer[n],e,!1);else{let r=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,i=t.__webglDepthbuffer[n];l.bindRenderbuffer(l.RENDERBUFFER,i),l.framebufferRenderbuffer(l.FRAMEBUFFER,r,l.RENDERBUFFER,i)}}else{let n=e.texture.mipmaps;if(n&&n.length>0?d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer[0]):d.bindFramebuffer(l.FRAMEBUFFER,t.__webglFramebuffer),t.__webglDepthbuffer===void 0)t.__webglDepthbuffer=l.createRenderbuffer(),xe(t.__webglDepthbuffer,e,!1);else{let n=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,r=t.__webglDepthbuffer;l.bindRenderbuffer(l.RENDERBUFFER,r),l.framebufferRenderbuffer(l.FRAMEBUFFER,n,l.RENDERBUFFER,r)}}d.bindFramebuffer(l.FRAMEBUFFER,null)}function we(e,t,n){let r=f.get(e);t!==void 0&&be(r.__webglFramebuffer,e,e.texture,l.COLOR_ATTACHMENT0,l.TEXTURE_2D,0),n!==void 0&&Ce(e)}function Te(e){let t=e.texture,n=f.get(e),r=f.get(t);e.addEventListener(`dispose`,N);let i=e.textures,a=e.isWebGLCubeRenderTarget===!0,o=i.length>1;if(o||(r.__webglTexture===void 0&&(r.__webglTexture=l.createTexture()),r.__version=t.version,h.memory.textures++),a){n.__webglFramebuffer=[];for(let e=0;e<6;e++)if(t.mipmaps&&t.mipmaps.length>0){n.__webglFramebuffer[e]=[];for(let r=0;r<t.mipmaps.length;r++)n.__webglFramebuffer[e][r]=l.createFramebuffer()}else n.__webglFramebuffer[e]=l.createFramebuffer()}else{if(t.mipmaps&&t.mipmaps.length>0){n.__webglFramebuffer=[];for(let e=0;e<t.mipmaps.length;e++)n.__webglFramebuffer[e]=l.createFramebuffer()}else n.__webglFramebuffer=l.createFramebuffer();if(o)for(let e=0,t=i.length;e<t;e++){let t=f.get(i[e]);t.__webglTexture===void 0&&(t.__webglTexture=l.createTexture(),h.memory.textures++)}if(e.samples>0&&je(e)===!1){n.__webglMultisampledFramebuffer=l.createFramebuffer(),n.__webglColorRenderbuffer=[],d.bindFramebuffer(l.FRAMEBUFFER,n.__webglMultisampledFramebuffer);for(let t=0;t<i.length;t++){let r=i[t];n.__webglColorRenderbuffer[t]=l.createRenderbuffer(),l.bindRenderbuffer(l.RENDERBUFFER,n.__webglColorRenderbuffer[t]);let a=m.convert(r.format,r.colorSpace),o=m.convert(r.type),s=A(r.internalFormat,a,o,r.normalized,r.colorSpace,e.isXRRenderTarget===!0),c=Ae(e);l.renderbufferStorageMultisample(l.RENDERBUFFER,c,s,e.width,e.height),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+t,l.RENDERBUFFER,n.__webglColorRenderbuffer[t])}l.bindRenderbuffer(l.RENDERBUFFER,null),e.depthBuffer&&(n.__webglDepthRenderbuffer=l.createRenderbuffer(),xe(n.__webglDepthRenderbuffer,e,!0)),d.bindFramebuffer(l.FRAMEBUFFER,null)}}if(a){d.bindTexture(l.TEXTURE_CUBE_MAP,r.__webglTexture),me(l.TEXTURE_CUBE_MAP,t);for(let r=0;r<6;r++)if(t.mipmaps&&t.mipmaps.length>0)for(let i=0;i<t.mipmaps.length;i++)be(n.__webglFramebuffer[r][i],e,t,l.COLOR_ATTACHMENT0,l.TEXTURE_CUBE_MAP_POSITIVE_X+r,i);else be(n.__webglFramebuffer[r],e,t,l.COLOR_ATTACHMENT0,l.TEXTURE_CUBE_MAP_POSITIVE_X+r,0);D(t)&&O(l.TEXTURE_CUBE_MAP),d.unbindTexture()}else if(o){for(let t=0,r=i.length;t<r;t++){let r=i[t],a=f.get(r),o=l.TEXTURE_2D;(e.isWebGL3DRenderTarget||e.isWebGLArrayRenderTarget)&&(o=e.isWebGL3DRenderTarget?l.TEXTURE_3D:l.TEXTURE_2D_ARRAY),d.bindTexture(o,a.__webglTexture),me(o,r),be(n.__webglFramebuffer,e,r,l.COLOR_ATTACHMENT0+t,o,0),D(r)&&O(o)}d.unbindTexture()}else{let i=l.TEXTURE_2D;if((e.isWebGL3DRenderTarget||e.isWebGLArrayRenderTarget)&&(i=e.isWebGL3DRenderTarget?l.TEXTURE_3D:l.TEXTURE_2D_ARRAY),d.bindTexture(i,r.__webglTexture),me(i,t),t.mipmaps&&t.mipmaps.length>0)for(let r=0;r<t.mipmaps.length;r++)be(n.__webglFramebuffer[r],e,t,l.COLOR_ATTACHMENT0,i,r);else be(n.__webglFramebuffer,e,t,l.COLOR_ATTACHMENT0,i,0);D(t)&&O(i),d.unbindTexture()}e.depthBuffer&&Ce(e)}function Ee(e){let t=e.textures;for(let n=0,r=t.length;n<r;n++){let r=t[n];if(D(r)){let t=k(e),n=f.get(r).__webglTexture;d.bindTexture(t,n),O(t),d.unbindTexture()}}}let De=[],Oe=[];function ke(e){if(e.samples>0){if(je(e)===!1){let t=e.textures,n=e.width,r=e.height,i=l.COLOR_BUFFER_BIT,a=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT,o=f.get(e),s=t.length>1;if(s)for(let e=0;e<t.length;e++)d.bindFramebuffer(l.FRAMEBUFFER,o.__webglMultisampledFramebuffer),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.RENDERBUFFER,null),d.bindFramebuffer(l.FRAMEBUFFER,o.__webglFramebuffer),l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.TEXTURE_2D,null,0);d.bindFramebuffer(l.READ_FRAMEBUFFER,o.__webglMultisampledFramebuffer);let c=e.texture.mipmaps;c&&c.length>0?d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglFramebuffer[0]):d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglFramebuffer);for(let c=0;c<t.length;c++){if(e.resolveDepthBuffer&&(e.depthBuffer&&(i|=l.DEPTH_BUFFER_BIT),e.stencilBuffer&&e.resolveStencilBuffer&&(i|=l.STENCIL_BUFFER_BIT)),s){l.framebufferRenderbuffer(l.READ_FRAMEBUFFER,l.COLOR_ATTACHMENT0,l.RENDERBUFFER,o.__webglColorRenderbuffer[c]);let e=f.get(t[c]).__webglTexture;l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0,l.TEXTURE_2D,e,0)}l.blitFramebuffer(0,0,n,r,0,0,n,r,i,l.NEAREST),_===!0&&(De.length=0,Oe.length=0,De.push(l.COLOR_ATTACHMENT0+c),e.depthBuffer&&e.storeMultisampledDepthBuffer===!1&&(De.push(a),Oe.push(a),l.invalidateFramebuffer(l.DRAW_FRAMEBUFFER,Oe)),l.invalidateFramebuffer(l.READ_FRAMEBUFFER,De))}if(d.bindFramebuffer(l.READ_FRAMEBUFFER,null),d.bindFramebuffer(l.DRAW_FRAMEBUFFER,null),s)for(let e=0;e<t.length;e++){d.bindFramebuffer(l.FRAMEBUFFER,o.__webglMultisampledFramebuffer),l.framebufferRenderbuffer(l.FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.RENDERBUFFER,o.__webglColorRenderbuffer[e]);let n=f.get(t[e]).__webglTexture;d.bindFramebuffer(l.FRAMEBUFFER,o.__webglFramebuffer),l.framebufferTexture2D(l.DRAW_FRAMEBUFFER,l.COLOR_ATTACHMENT0+e,l.TEXTURE_2D,n,0)}d.bindFramebuffer(l.DRAW_FRAMEBUFFER,o.__webglMultisampledFramebuffer)}else if(e.depthBuffer&&e.storeMultisampledDepthBuffer===!1&&_){let t=e.stencilBuffer?l.DEPTH_STENCIL_ATTACHMENT:l.DEPTH_ATTACHMENT;l.invalidateFramebuffer(l.DRAW_FRAMEBUFFER,[t])}}}function Ae(e){return Math.min(p.maxSamples,e.samples)}function je(e){let t=f.get(e);return e.samples>0&&u.has(`WEBGL_multisampled_render_to_texture`)===!0&&t.__useRenderToTexture!==!1}function L(e){let t=h.render.frame;y.get(e)!==t&&(y.set(e,t),e.update())}function Me(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(Pt.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&B(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):V(`WebGLTextures: Unsupported texture color space:`,n)),t}function Ne(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(v.width=e.naturalWidth||e.width,v.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(v.width=e.displayWidth,v.height=e.displayHeight):(v.width=e.width,v.height=e.height),v}this.allocateTextureUnit=oe,this.resetTextureUnits=re,this.getTextureUnits=ie,this.setTextureUnits=ae,this.setTexture2D=I,this.setTexture2DArray=ce,this.setTexture3D=le,this.setTextureCube=ue,this.rebindTextures=we,this.setupRenderTarget=Te,this.updateRenderTargetMipmap=Ee,this.updateMultisampleRenderTarget=ke,this.setupDepthRenderbuffer=Ce,this.setupFrameBufferTexture=be,this.useMultisampledRTT=je,this.isReversedDepthBuffer=function(){return d.buffers.depth.getReversed()}}function rd(e,t){function n(n,r=``){let i,a=Pt.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var id=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ad=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,od=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new na(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Ho({vertexShader:id,fragmentShader:ad,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new q(new Ao(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},sd=class extends $e{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,u=null,d=null,f=null,p=null,h=null,g=typeof XRWebGLBinding<`u`,_=new od,v={},b=t.getContextAttributes(),x=null,S=null,C=[],D=[],O=new H,k=null,A=null,j=new Es;j.viewport=new Gt;let M=new Es;M.viewport=new Gt;let ee=[j,M],N=new Fs,P=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=C[e];return t===void 0&&(t=new En,C[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=C[e];return t===void 0&&(t=new En,C[e]=t),t.getGripSpace()},this.getHand=function(e){let t=C[e];return t===void 0&&(t=new En,C[e]=t),t.getHandSpace()};function te(e){let t=D.indexOf(e.inputSource);if(t===-1)return;let n=C[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function ne(){r.removeEventListener(`select`,te),r.removeEventListener(`selectstart`,te),r.removeEventListener(`selectend`,te),r.removeEventListener(`squeeze`,te),r.removeEventListener(`squeezestart`,te),r.removeEventListener(`squeezeend`,te),r.removeEventListener(`end`,ne),r.removeEventListener(`inputsourceschange`,re);for(let e=0;e<C.length;e++){let t=D[e];t!==null&&(D[e]=null,C[e].disconnect(t))}P=null,F=null,_.reset();for(let e in v)delete v[e];if(e.setRenderTarget(x),p=null,f=null,d=null,r=null,S=null,ue.stop(),n.isPresenting=!1,e.setPixelRatio(k),e.setSize(O.width,O.height,!1),A!==null){let e=A.camera;e.fov=A.fov,e.zoom=A.zoom,e.updateProjectionMatrix(),A=null}n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&B(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&B(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return f===null?p:f},this.getBinding=function(){return d===null&&g&&(d=new XRWebGLBinding(r,t)),d},this.getFrame=function(){return h},this.getSession=function(){return r},this.setSession=async function(u){if(r=u,r!==null){if(x=e.getRenderTarget(),r.addEventListener(`select`,te),r.addEventListener(`selectstart`,te),r.addEventListener(`selectend`,te),r.addEventListener(`squeeze`,te),r.addEventListener(`squeezestart`,te),r.addEventListener(`squeezeend`,te),r.addEventListener(`end`,ne),r.addEventListener(`inputsourceschange`,re),b.xrCompatible!==!0&&await t.makeXRCompatible(),k=e.getPixelRatio(),e.getSize(O),g&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;b.depth&&(o=b.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=b.stencil?E:T,a=b.stencil?y:m);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};d=this.getBinding(),f=d.createProjectionLayer(s),r.updateRenderState({layers:[f]}),e.setPixelRatio(1),e.setSize(f.textureWidth,f.textureHeight,!1),S=new qt(f.textureWidth,f.textureHeight,{format:w,type:l,depthTexture:new ea(f.textureWidth,f.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:b.stencil,colorSpace:e.outputColorSpace,samples:b.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}else{let n={antialias:b.antialias,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:i};p=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),S=new qt(p.framebufferWidth,p.framebufferHeight,{format:w,type:l,colorSpace:e.outputColorSpace,stencilBuffer:b.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1,storeMultisampledDepthBuffer:p.ignoreDepthValues===!1,storeMultisampledStencilBuffer:p.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),ue.setContext(r),ue.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function re(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=D.indexOf(n);r>=0&&(D[r]=null,C[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=D.indexOf(n);if(r===-1){for(let e=0;e<C.length;e++)if(e>=D.length){D.push(n),r=e;break}else if(D[e]===null){D[e]=n,r=e;break}if(r===-1)break}let i=C[r];i&&i.connect(n)}}let ie=new U,ae=new U;function oe(e,t,n){ie.setFromMatrixPosition(t.matrixWorld),ae.setFromMatrixPosition(n.matrixWorld);let r=ie.distanceTo(ae),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function se(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;_.texture!==null&&(_.depthNear>0&&(t=_.depthNear),_.depthFar>0&&(n=_.depthFar)),N.near=M.near=j.near=t,N.far=M.far=j.far=n,(P!==N.near||F!==N.far)&&(r.updateRenderState({depthNear:N.near,depthFar:N.far}),P=N.near,F=N.far),N.layers.mask=e.layers.mask|6,j.layers.mask=N.layers.mask&-5,M.layers.mask=N.layers.mask&-3;let i=e.parent,a=N.cameras;se(N,i);for(let e=0;e<a.length;e++)se(a[e],i);a.length===2?oe(N,j,M):N.projectionMatrix.copy(j.projectionMatrix),A===null&&e.isPerspectiveCamera&&(A={camera:e,fov:e.fov,zoom:e.zoom}),I(e,N,i)};function I(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=rt*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return N},this.getFoveation=function(){if(f!==null||p!==null)return s},this.setFoveation=function(e){s=e,f!==null&&(f.fixedFoveation=e),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=e)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(N)},this.getCameraTexture=function(e){return v[e]};let ce=null;function le(t,i){if(u=i.getViewerPose(c||a),h=i,u!==null){let t=u.views;p!==null&&(e.setRenderTargetFramebuffer(S,p.framebuffer),e.setRenderTarget(S));let i=!1;t.length!==N.cameras.length&&(N.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(p!==null)a=p.getViewport(r);else{let t=d.getViewSubImage(f,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(S,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(S))}let o=ee[n];o===void 0&&(o=new Es,o.layers.enable(n),o.viewport=new Gt,ee[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(N.matrix.copy(o.matrix),N.matrix.decompose(N.position,N.quaternion,N.scale)),i===!0&&N.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&g){d=n.getBinding();let e=d.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&_.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&g){e.state.unbindTexture(),d=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=v[n];e||(e=new na,v[n]=e);let t=d.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<C.length;e++){let t=D[e],n=C[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}ce&&ce(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),h=null}let ue=new Qs;ue.setAnimationLoop(le),this.setAnimationLoop=function(e){ce=e},this.dispose=function(){}}},cd=new Xt,ld=new W;ld.set(-1,0,0,0,1,0,0,0,1);function ud(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,Ro(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(cd.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(ld),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.retroreflectivity>0&&(e.retroreflectivity.value=t.retroreflectivity),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function dd(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return V(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return r[a]=typeof i==`number`||typeof i==`boolean`?i:ArrayBuffer.isView(i)?i.slice():i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?B(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):B(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var fd=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),pd=null;function md(){return pd===null&&(pd=new vi(fd,16,16,k,g),pd.name=`DFG_LUT`,pd.minFilter=o,pd.magFilter=o,pd.wrapS=t,pd.wrapT=t,pd.generateMipmaps=!1,pd.needsUpdate=!0),pd}var hd=class{constructor(e={}){let{canvas:t=Ke(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:u=!1,powerPreference:d=`default`,failIfMajorPerformanceCaveat:p=!1,reversedDepthBuffer:h=!1,outputBufferType:b=l}=e;this.isWebGLRenderer=!0;let x;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);x=n.getContextAttributes().alpha}else x=a;let S=b,C=new Set([j,A,O]),w=new Set([l,m,f,y,_,v]),T=new Uint32Array(4),E=new Int32Array(4),D=new U,k=null,M=null,ee=[],N=[],P=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let F=this,te=!1,ne=null,re=null,ie=null,ae=null;this._outputColorSpace=Ie;let oe=0,se=0,I=null,ce=-1,le=null,ue=new Gt,de=new Gt,fe=null,pe=new K(0),me=0,he=t.width,ge=t.height,_e=1,ve=null,ye=null,be=new Gt(0,0,he,ge),xe=new Gt(0,0,he,ge),Se=!1,Ce=new ji,we=!1,Te=!1,Ee=new Xt,De=new U,Oe=new Gt,ke={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},Ae=!1;function je(){return I===null?_e:1}let L=n;function Me(e,n){return t.getContext(e,n)}let Ne,Pe,R,Fe,z,Le,Re,ze,Be,Ve,Ue,We,Ge,qe,Ye,Xe,Qe,$e,et,tt,nt,rt,it;try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:u,powerPreference:d,failIfMajorPerformanceCaveat:p};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r186`),t.addEventListener(`webglcontextlost`,st,!1),t.addEventListener(`webglcontextrestored`,ct,!1),t.addEventListener(`webglcontextcreationerror`,lt,!1),L===null){let t=`webgl2`;if(L=Me(t,e),L===null)throw Me(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}at()}catch(e){throw t.removeEventListener(`webglcontextlost`,st,!1),t.removeEventListener(`webglcontextrestored`,ct,!1),t.removeEventListener(`webglcontextcreationerror`,lt,!1),V(`WebGLRenderer: `+e.message),e}function at(){Ne=new Nc(L),Ne.init(),nt=new rd(L,Ne),Pe=new cc(L,Ne,e,nt),R=new td(L,Ne),Pe.reversedDepthBuffer&&h&&R.buffers.depth.setReversed(!0),re=L.createFramebuffer(),ie=L.createFramebuffer(),ae=L.createFramebuffer(),Fe=new Ic(L),z=new Fu,Le=new nd(L,Ne,R,z,Pe,nt,Fe),Re=new Mc(F),ze=new $s(L),rt=new oc(L,ze),Be=new Pc(L,ze,Fe,rt),Ve=new Rc(L,Be,ze,rt,Fe),$e=new Lc(L,Pe,Le),Ye=new lc(z),Ue=new Pu(F,Re,Ne,Pe,rt,Ye),We=new ud(F,z),Ge=new zu,qe=new Ku(Ne),Qe=new ac(F,Re,R,Ve,x,s),Xe=new ed(F,Ve,Pe),it=new dd(L,Fe,Pe,R),et=new sc(L,Ne,Fe),tt=new Fc(L,Ne,Fe),Fe.programs=Ue.programs,F.capabilities=Pe,F.extensions=Ne,F.properties=z,F.renderLists=Ge,F.shadowMap=Xe,F.state=R,F.info=Fe}S!==1009&&(P=new Bc(S,t.width,t.height,o,r,i));let ot=new sd(F,L);this.xr=ot,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){let e=Ne.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=Ne.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return _e},this.setPixelRatio=function(e){e!==void 0&&(_e=e,this.setSize(he,ge,!1))},this.getSize=function(e){return e.set(he,ge)},this.setSize=function(e,n,r=!0){ot.isPresenting?B(`WebGLRenderer: Can't change size while VR device is presenting.`):(he=e,ge=n,t.width=Math.floor(e*_e),t.height=Math.floor(n*_e),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),P!==null&&P.setSize(t.width,t.height),this.setViewport(0,0,e,n))},this.getDrawingBufferSize=function(e){return e.set(he*_e,ge*_e).floor()},this.setDrawingBufferSize=function(e,n,r){he=e,ge=n,_e=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(S===1009)V(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);else{if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){B(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}P.setEffects(e||[])}},this.getCurrentViewport=function(e){return e.copy(ue)},this.getViewport=function(e){return e.copy(be)},this.setViewport=function(e,t,n,r){e.isVector4?be.set(e.x,e.y,e.z,e.w):be.set(e,t,n,r),R.viewport(ue.copy(be).multiplyScalar(_e).round())},this.getScissor=function(e){return e.copy(xe)},this.setScissor=function(e,t,n,r){e.isVector4?xe.set(e.x,e.y,e.z,e.w):xe.set(e,t,n,r),R.scissor(de.copy(xe).multiplyScalar(_e).round())},this.getScissorTest=function(){return Se},this.setScissorTest=function(e){R.setScissorTest(Se=e)},this.setOpaqueSort=function(e){ve=e},this.setTransparentSort=function(e){ye=e},this.getClearColor=function(e){return e.copy(Qe.getClearColor())},this.setClearColor=function(){Qe.setClearColor(...arguments)},this.getClearAlpha=function(){return Qe.getClearAlpha()},this.setClearAlpha=function(){Qe.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(I!==null){let t=I.texture.format;e=C.has(t)}if(e){let e=I.texture.type,t=w.has(e),n=Qe.getClearColor(),r=Qe.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(T[0]=i,T[1]=a,T[2]=o,T[3]=r,L.clearBufferuiv(L.COLOR,0,T)):(E[0]=i,E[1]=a,E[2]=o,E[3]=r,L.clearBufferiv(L.COLOR,0,E))}else r|=L.COLOR_BUFFER_BIT}t&&(r|=L.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&L.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),ne=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,st,!1),t.removeEventListener(`webglcontextrestored`,ct,!1),t.removeEventListener(`webglcontextcreationerror`,lt,!1),Qe.dispose(),Ge.dispose(),qe.dispose(),z.dispose(),Re.dispose(),Ve.dispose(),rt.dispose(),it.dispose(),Ue.dispose(),ot.dispose(),ot.removeEventListener(`sessionstart`,gt),ot.removeEventListener(`sessionend`,_t),vt.stop()};function st(e){e.preventDefault(),Je(`WebGLRenderer: Context Lost.`),te=!0}function ct(){Je(`WebGLRenderer: Context Restored.`),te=!1;let e=Fe.autoReset,t=Xe.enabled,n=Xe.autoUpdate,r=Xe.needsUpdate,i=Xe.type;at(),Fe.autoReset=e,Xe.enabled=t,Xe.autoUpdate=n,Xe.needsUpdate=r,Xe.type=i}function lt(e){V(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function ut(e){let t=e.target;t.removeEventListener(`dispose`,ut),dt(t)}function dt(e){ft(e),z.remove(e)}function ft(e){let t=z.get(e).programs;t!==void 0&&(t.forEach(function(e){Ue.releaseProgram(e)}),e.isShaderMaterial&&Ue.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=ke);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=Dt(e,t,n,r,i);R.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=Be.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;rt.setup(i,r,s,n,c);let h,g=et;if(c!==null&&(h=ze.get(c),g=tt,g.setIndex(h)),i.isMesh)r.wireframe===!0?(R.setLineWidth(r.wireframeLinewidth*je()),g.setMode(L.LINES)):g.setMode(L.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),R.setLineWidth(e*je()),i.isLineSegments?g.setMode(L.LINES):i.isLineLoop?g.setMode(L.LINE_LOOP):g.setMode(L.LINE_STRIP)}else i.isPoints?g.setMode(L.POINTS):i.isSprite&&g.setMode(L.TRIANGLES);if(i.isBatchedMesh){if(Ne.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?ze.get(c).bytesPerElement:1,o=z.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(L,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function pt(e,t,n,r){ne!==null&&e.isNodeMaterial&&ne.setObject(r,e),we===!0&&Ye.setState(e,n,!1),e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,wt(e,t,r),e.side=0,e.needsUpdate=!0,wt(e,t,r),e.side=2):wt(e,t,r)}this.compile=function(e,t,n=null){n===null&&(n=e),ne!==null&&ne.renderStart(e,t,n),M=qe.get(n),M.init(t),N.push(M),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(M.pushLight(e),e.castShadow&&M.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(M.pushLight(e),e.castShadow&&M.pushShadow(e))}),M.setupLights(),ne!==null&&ne.updateLights(M.state.lightsArray),Te=this.localClippingEnabled,we=Ye.init(this.clippingPlanes,Te),we===!0&&Ye.setGlobalState(this.clippingPlanes,t),ne!==null&&Xe.render(M.state.shadowsArray,n,t);let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let i=e.material;if(i){if(Array.isArray(i))for(let a=0;a<i.length;a++){let o=i[a];pt(o,n,t,e),r.add(o)}else pt(i,n,t,e),r.add(i)}}),M=N.pop(),ne!==null&&ne.renderEnd(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){r.forEach(function(e){let t=z.get(e).currentProgram;(t===void 0||t.isReady())&&r.delete(e)}),r.size===0?t(e):setTimeout(n,10)}Ne.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let mt=null;function ht(e){mt&&mt(e)}function gt(){vt.stop()}function _t(){vt.start()}let vt=new Qs;vt.setAnimationLoop(ht),typeof self<`u`&&vt.setContext(self),this.setAnimationLoop=function(e){mt=e,ot.setAnimationLoop(e),e===null?vt.stop():vt.start()},ot.addEventListener(`sessionstart`,gt),ot.addEventListener(`sessionend`,_t),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){V(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(te===!0)return;ne!==null&&ne.renderStart(e,t);let n=ot.enabled===!0&&ot.isPresenting===!0,r=P!==null&&(I===null||n)&&P.begin(F,I);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),ot.enabled===!0&&ot.isPresenting===!0&&(P===null||P.isCompositing()===!1)&&(ot.cameraAutoUpdate===!0&&ot.updateCamera(t),t=ot.getCamera()),e.isScene===!0&&e.onBeforeRender(F,e,t,I),M=qe.get(e,N.length),M.init(t),M.state.textureUnits=Le.getTextureUnits(),N.push(M),Ee.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),Ce.setFromProjectionMatrix(Ee,He,t.reversedDepth),Te=this.localClippingEnabled,we=Ye.init(this.clippingPlanes,Te),k=Ge.get(e,ee.length),k.init(),ee.push(k),ot.enabled===!0&&ot.isPresenting===!0){let e=F.xr.getDepthSensingMesh();e!==null&&yt(e,t,-1/0,F.sortObjects)}yt(e,t,0,F.sortObjects),k.finish(),ne!==null&&ne.updateLights(M.state.lightsArray),F.sortObjects===!0&&k.sort(ve,ye),Ae=ot.enabled===!1||ot.isPresenting===!1||ot.hasDepthSensing()===!1,Ae&&Qe.addToRenderList(k,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),we===!0&&Ye.beginShadows();let i=M.state.shadowsArray;if(Xe.render(i,e,t),we===!0&&Ye.endShadows(),(r&&P.hasRenderPass())===!1){let n=k.opaque,r=k.transmissive;if(M.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];xt(n,r,e,a)}Ae&&Qe.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];bt(k,e,n,n.viewport)}}else r.length>0&&xt(n,r,e,t),Ae&&Qe.render(e),bt(k,e,t)}I!==null&&se===0&&(Le.updateMultisampleRenderTarget(I),Le.updateRenderTargetMipmap(I)),r&&P.end(F),e.isScene===!0&&e.onAfterRender(F,e,t),rt.resetDefaultState(),ce=-1,le=null,N.pop(),N.length>0?(M=N[N.length-1],Le.setTextureUnits(M.state.textureUnits),we===!0&&Ye.setGlobalState(F.clippingPlanes,M.state.camera)):M=null,ee.pop(),k=ee.length>0?ee[ee.length-1]:null,ne!==null&&ne.renderEnd()};function yt(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)M.pushLightProbeGrid(e);else if(e.isLight)M.pushLight(e),e.castShadow&&M.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||e.intersectsFrustum(Ce)){r&&Oe.setFromMatrixPosition(e.matrixWorld).applyMatrix4(Ee);let i=Ve.update(e),a=e.material;a.visible&&k.push(e,i,a,n,Oe.z,null,t)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||e.intersectsFrustum(Ce))){let i=Ve.update(e),a=e.material;if(r&&(e.boundingSphere===void 0?(i.boundingSphere===null&&i.computeBoundingSphere(),Oe.copy(i.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),Oe.copy(e.boundingSphere.center)),Oe.applyMatrix4(e.matrixWorld).applyMatrix4(Ee)),Array.isArray(a)){let r=i.groups;for(let o=0,s=r.length;o<s;o++){let s=r[o],c=a[s.materialIndex];c&&c.visible&&k.push(e,i,c,n,Oe.z,s,t)}}else a.visible&&k.push(e,i,a,n,Oe.z,null,t)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)yt(i[e],t,n,r)}function bt(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;M.setupLightsView(n),we===!0&&Ye.setGlobalState(F.clippingPlanes,n),r&&R.viewport(ue.copy(r)),i.length>0&&St(i,t,n),a.length>0&&St(a,t,n),o.length>0&&St(o,t,n),R.buffers.depth.setTest(!0),R.buffers.depth.setMask(!0),R.buffers.color.setMask(!0),R.setPolygonOffset(!1)}function xt(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(M.state.transmissionRenderTarget[r.id]===void 0){let e=Ne.has(`EXT_color_buffer_half_float`)||Ne.has(`EXT_color_buffer_float`);M.state.transmissionRenderTarget[r.id]=new qt(1,1,{generateMipmaps:!0,type:e?g:l,minFilter:c,samples:Math.max(4,Pe.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Pt.workingColorSpace})}let a=M.state.transmissionRenderTarget[r.id],o=r.viewport||ue;a.setSize(o.z*F.transmissionResolutionScale,o.w*F.transmissionResolutionScale);let s=F.getRenderTarget(),u=F.getActiveCubeFace(),d=F.getActiveMipmapLevel();F.setRenderTarget(a),F.getClearColor(pe),me=F.getClearAlpha(),me<1&&F.setClearColor(16777215,.5),F.clear(),Ae&&Qe.render(n);let f=F.toneMapping;F.toneMapping=0;let p=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),M.setupLightsView(r),we===!0&&Ye.setGlobalState(F.clippingPlanes,r),St(e,n,r),Le.updateMultisampleRenderTarget(a),Le.updateRenderTargetMipmap(a),Ne.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,Ct(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(Le.updateMultisampleRenderTarget(a),Le.updateRenderTargetMipmap(a))}F.setRenderTarget(s,u,d),F.setClearColor(pe,me),p!==void 0&&(r.viewport=p),F.toneMapping=f}function St(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&Ct(o,t,n,s,l,c)}}function Ct(e,t,n,r,i,a){ne!==null&&i.isNodeMaterial&&ne.setObject(e,i),e.onBeforeRender(F,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(F,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,F.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,F.renderBufferDirect(n,t,r,i,e,a),i.side=2):F.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(F,t,n,r,i,a)}function wt(e,t,n){t.isScene!==!0&&(t=ke);let r=z.get(e),i=M.state.lights,a=M.state.shadowsArray,o=i.state.version,s=Ue.getParameters(e,i.state,a,t,n,M.state.lightProbeGridArray),c=Ue.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=Re.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,ut),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return Et(e,s),d}else s.uniforms=Ue.getUniforms(e),ne!==null&&e.isNodeMaterial&&ne.build(e,n,s),e.onBeforeCompile(s,F),d=Ue.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=Ye.uniform),Et(e,s),r.needsLights=kt(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.sunLights.value=i.state.sun,f.sunLightShadows.value=i.state.sunShadow,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.sunShadowMatrix.value=i.state.sunShadowMatrix,f.sunShadowCascade.value=i.state.sunShadowCascade,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=M.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function Tt(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=ql.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function Et(e,t){let n=z.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function H(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];D.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(D))return n}return null}function Dt(e,t,n,r,i){t.isScene!==!0&&(t=ke),Le.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=I===null?F.outputColorSpace:I.isXRRenderTarget===!0?I.texture.colorSpace:Pt.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=Re.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(I===null||I.isXRRenderTarget===!0)&&(h=F.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=z.get(r),y=M.state.lights;if(we===!0&&(Te===!0||e!==le)){let t=e===le&&r.id===ce;Ye.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i._colorsTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i._colorsTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==Ye.numPlanes||v.numIntersection!==Ye.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=M.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let x=v.currentProgram;b===!0&&(x=wt(r,t,i),ne&&r.isNodeMaterial&&ne.onUpdateProgram(r,x,v));let S=!1,C=!1,w=!1,T=x.getUniforms(),E=v.uniforms;if(R.useProgram(x.program)&&(S=!0,C=!0,w=!0),r.id!==ce&&(ce=r.id,C=!0),v.needsLights){let e=H(M.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,C=!0)}if(S||le!==e){R.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),T.setValue(L,`projectionMatrix`,e.projectionMatrix),T.setValue(L,`viewMatrix`,e.matrixWorldInverse);let t=T.map.cameraPosition;t!==void 0&&t.setValue(L,De.setFromMatrixPosition(e.matrixWorld)),Pe.logarithmicDepthBuffer&&T.setValue(L,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&T.setValue(L,`isOrthographic`,e.isOrthographicCamera===!0),le!==e&&(le=e,C=!0,w=!0)}if(v.needsLights&&(y.state.sunShadowMap.length>0&&T.setValue(L,`sunShadowMap`,y.state.sunShadowMap,Le),y.state.directionalShadowMap.length>0&&T.setValue(L,`directionalShadowMap`,y.state.directionalShadowMap,Le),y.state.spotShadowMap.length>0&&T.setValue(L,`spotShadowMap`,y.state.spotShadowMap,Le),y.state.pointShadowMap.length>0&&T.setValue(L,`pointShadowMap`,y.state.pointShadowMap,Le)),i.isSkinnedMesh){T.setOptional(L,i,`bindMatrix`),T.setOptional(L,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),T.setValue(L,`boneTexture`,e.boneTexture,Le))}i.isBatchedMesh&&(T.setOptional(L,i,`batchingTexture`),T.setValue(L,`batchingTexture`,i._matricesTexture,Le),T.setOptional(L,i,`batchingIdTexture`),T.setValue(L,`batchingIdTexture`,i._indirectTexture,Le),T.setOptional(L,i,`batchingColorTexture`),i._colorsTexture!==null&&T.setValue(L,`batchingColorTexture`,i._colorsTexture,Le));let D=n.morphAttributes;if((D.position!==void 0||D.normal!==void 0||D.color!==void 0)&&$e.update(i,n,x),(C||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,T.setValue(L,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(E.envMapIntensity.value=t.environmentIntensity),E.dfgLUT!==void 0&&(E.dfgLUT.value=md()),C){if(T.setValue(L,`toneMappingExposure`,F.toneMappingExposure),v.needsLights&&Ot(E,w),a&&r.fog===!0&&We.refreshFogUniforms(E,a),We.refreshMaterialUniforms(E,r,_e,ge,M.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;E.probesSH.value=e.texture,E.probesMin.value.copy(e.boundingBox.min),E.probesMax.value.copy(e.boundingBox.max),E.probesResolution.value.copy(e.resolution)}ql.upload(L,Tt(v),E,Le)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(ql.upload(L,Tt(v),E,Le),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&T.setValue(L,`center`,i.center),T.setValue(L,`modelViewMatrix`,i.modelViewMatrix),T.setValue(L,`normalMatrix`,i.normalMatrix),T.setValue(L,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];it.update(n,x),it.bind(n,x)}}return x}function Ot(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.sunLights.needsUpdate=t,e.sunLightShadows.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function kt(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return oe},this.getActiveMipmapLevel=function(){return se},this.getRenderTarget=function(){return I},this.setRenderTargetTextures=function(e,t,n){let r=z.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),z.get(e.texture).__webglTexture=t,z.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=z.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){I=e,oe=t,se=n;let r=null,i=!1,a=!1;if(e){let o=z.get(e);if(o.__useDefaultFramebuffer!==void 0){R.bindFramebuffer(L.FRAMEBUFFER,o.__webglFramebuffer),ue.copy(e.viewport),de.copy(e.scissor),fe=e.scissorTest,R.viewport(ue),R.scissor(de),R.setScissorTest(fe),ce=-1;return}if(o.__webglFramebuffer===void 0)Le.setupRenderTarget(e);else if(o.__hasExternalTextures)Le.rebindTextures(e,z.get(e.texture).__webglTexture,z.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&z.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);Le.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=z.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&Le.useMultisampledRTT(e)===!1?z.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,ue.copy(e.viewport),de.copy(e.scissor),fe=e.scissorTest}else ue.copy(be).multiplyScalar(_e).floor(),de.copy(xe).multiplyScalar(_e).floor(),fe=Se;if(n!==0&&(r=re),R.bindFramebuffer(L.FRAMEBUFFER,r)&&R.drawBuffers(e,r),R.viewport(ue),R.scissor(de),R.setScissorTest(fe),i){let r=z.get(e.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=z.get(e.textures[t]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=z.get(e.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,t.__webglTexture,n)}ce=-1};function W(e){let t=z.get(e);return(t.__readFormat!==e.format||t.__readType!==e.type)&&(t.__readFormat=e.format,t.__readType=e.type,t.__formatReadable=Pe.textureFormatReadable(e.format),t.__typeReadable=Pe.textureTypeReadable(e.type)),t}this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){V(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=z.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){R.bindFramebuffer(L.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;e.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+s);let u=W(o);if(u.__formatReadable===!1){V(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(u.__typeReadable===!1){V(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&L.readPixels(t,n,r,i,nt.convert(c),nt.convert(l),a)}finally{let e=I===null?null:z.get(I).__webglFramebuffer;R.bindFramebuffer(L.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=z.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){R.bindFramebuffer(L.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;e.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+s);let d=W(o);if(d.__formatReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(d.__typeReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let f=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,f),L.bufferData(L.PIXEL_PACK_BUFFER,a.byteLength,L.STREAM_READ),L.readPixels(t,n,r,i,nt.convert(l),nt.convert(u),0),L.bindBuffer(L.PIXEL_PACK_BUFFER,null);let p=I===null?null:z.get(I).__webglFramebuffer;R.bindFramebuffer(L.FRAMEBUFFER,p);let m=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await Ze(L,m,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,f),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,a),L.bindBuffer(L.PIXEL_PACK_BUFFER,null),L.deleteBuffer(f),L.deleteSync(m),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;Le.setTexture2D(e,0),L.copyTexSubImage2D(L.TEXTURE_2D,n,0,0,o,s,i,a),R.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=nt.convert(t.format),_=nt.convert(t.type),v;t.isData3DTexture?(Le.setTexture3D(t,0),v=L.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(Le.setTexture2DArray(t,0),v=L.TEXTURE_2D_ARRAY):(Le.setTexture2D(t,0),v=L.TEXTURE_2D),R.activeTexture(L.TEXTURE0),R.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,t.flipY),R.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),R.pixelStorei(L.UNPACK_ALIGNMENT,t.unpackAlignment);let y=R.getParameter(L.UNPACK_ROW_LENGTH),b=R.getParameter(L.UNPACK_IMAGE_HEIGHT),x=R.getParameter(L.UNPACK_SKIP_PIXELS),S=R.getParameter(L.UNPACK_SKIP_ROWS),C=R.getParameter(L.UNPACK_SKIP_IMAGES);R.pixelStorei(L.UNPACK_ROW_LENGTH,h.width),R.pixelStorei(L.UNPACK_IMAGE_HEIGHT,h.height),R.pixelStorei(L.UNPACK_SKIP_PIXELS,l),R.pixelStorei(L.UNPACK_SKIP_ROWS,u),R.pixelStorei(L.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=z.get(e),r=z.get(t),h=z.get(n.__renderTarget),g=z.get(r.__renderTarget);R.bindFramebuffer(L.READ_FRAMEBUFFER,h.__webglFramebuffer),R.bindFramebuffer(L.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,z.get(e).__webglTexture,i,d+n),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,z.get(t).__webglTexture,a,m+n)),L.blitFramebuffer(l,u,o,s,f,p,o,s,L.DEPTH_BUFFER_BIT,L.NEAREST);R.bindFramebuffer(L.READ_FRAMEBUFFER,null),R.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||z.has(e)){let n=z.get(e),r=z.get(t);R.bindFramebuffer(L.READ_FRAMEBUFFER,ie),R.bindFramebuffer(L.DRAW_FRAMEBUFFER,ae);for(let e=0;e<c;e++)w?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,n.__webglTexture,i),T?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,r.__webglTexture,a),i===0?T?L.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):L.copyTexSubImage2D(v,a,f,p,l,u,o,s):L.blitFramebuffer(l,u,o,s,f,p,o,s,L.COLOR_BUFFER_BIT,L.NEAREST);R.bindFramebuffer(L.READ_FRAMEBUFFER,null),R.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?L.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?L.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):L.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):L.texSubImage2D(L.TEXTURE_2D,a,f,p,o,s,g,_,h);R.pixelStorei(L.UNPACK_ROW_LENGTH,y),R.pixelStorei(L.UNPACK_IMAGE_HEIGHT,b),R.pixelStorei(L.UNPACK_SKIP_PIXELS,x),R.pixelStorei(L.UNPACK_SKIP_ROWS,S),R.pixelStorei(L.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&L.generateMipmap(v),R.unbindTexture()},this.initRenderTarget=function(e){z.get(e).__webglFramebuffer===void 0&&Le.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?Le.setTextureCube(e,0):e.isData3DTexture?Le.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?Le.setTexture2DArray(e,0):Le.setTexture2D(e,0),R.unbindTexture()},this.resetState=function(){oe=0,se=0,I=null,R.reset(),rt.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return He}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=Pt._getDrawingBufferColorSpace(e),t.unpackColorSpace=Pt._getUnpackColorSpace()}};function gd(e){let t=e>>>0;return function(){t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function _d(e,t,n=0){let r=Math.imul((e|0)^668265261,374761393)^Math.imul((t|0)+n*7919,2246822507);return r=Math.imul(r^r>>>15,739982445),r=Math.imul(r^r>>>12,695872825),((r^r>>>15)>>>0)/4294967296}function vd(e=1){let t=gd(e),n=new Uint8Array(256);for(let e=0;e<256;e++)n[e]=e;for(let e=255;e>0;e--){let r=Math.floor(t()*(e+1)),i=n[e];n[e]=n[r],n[r]=i}let r=new Uint8Array(512);for(let e=0;e<512;e++)r[e]=n[e&255];let i=[1,-1,1,-1,1,-1,0,0],a=[1,1,-1,-1,0,0,1,-1],o=.5*(Math.sqrt(3)-1),s=(3-Math.sqrt(3))/6;return function(e,t){let n=(e+t)*o,c=Math.floor(e+n),l=Math.floor(t+n),u=(c+l)*s,d=e-(c-u),f=t-(l-u),p=+(d>f),m=d>f?0:1,h=d-p+s,g=f-m+s,_=d-1+2*s,v=f-1+2*s,y=c&255,b=l&255,x=0,S=.5-d*d-f*f;if(S>0){let e=r[y+r[b]]&7;S*=S,x+=S*S*(i[e]*d+a[e]*f)}let C=.5-h*h-g*g;if(C>0){let e=r[y+p+r[b+m]]&7;C*=C,x+=C*C*(i[e]*h+a[e]*g)}let w=.5-_*_-v*v;if(w>0){let e=r[y+1+r[b+1]]&7;w*=w,x+=w*w*(i[e]*_+a[e]*v)}return 70*x}}function yd(e,t,n,r=4){let i=1,a=1,o=0,s=0;for(let c=0;c<r;c++)o+=i*e(t*a,n*a),s+=i,i*=.5,a*=2.03;return o/s}var bd=(e,t,n)=>e<t?t:e>n?n:e,xd=(e,t,n)=>e+(t-e)*n;function Sd(e,t,n){let r=bd((n-e)/(t-e),0,1);return r*r*(3-2*r)}function Cd(e,t,n){let r=(t-e+Math.PI)%(Math.PI*2)-Math.PI;return r<-Math.PI&&(r+=Math.PI*2),e+r*n}function wd(e,t,n,r){return xd(e,t,1-Math.exp(-n*r))}var Td={晨风草原:`Breezy Meadows`,迷雾森林:`Misty Woods`,红岩峡谷:`Red Rock Canyon`,珊瑚海岸:`Coral Coast`,水晶湖:`Crystal Lake`,霜顶雪山:`Frostpeak`,瞭望丘:`Lookout Hill`,星野天文台:`Hoshino Observatory`,古代遗迹:`Ancient Ruins`,搁浅的沉船:`Stranded Shipwreck`,红石拱门:`Red Stone Arch`,千年古树:`Thousand-Year Tree`,渔夫码头:`Fisher's Pier`,羊圈:`Sheep Pen`,村庄营火:`Village Campfire`,森林营火:`Forest Campfire`,峡谷营火:`Canyon Campfire`,海岸营火:`Coast Campfire`,湖畔营火:`Lakeside Campfire`,山脚营火:`Foothill Campfire`,峰顶营火:`Summit Campfire`,翠屿草原:`Verdant Isles`,雾隐林海:`Fogwood Sea`,赤岩荒地:`Redrock Badlands`,霜原:`Frost Plains`,晶辉海滩:`Crystal Shores`,"藏宝图上画着一座红色的石拱门，拱门西南方向不远处画着一个叉。":`The treasure map shows a red stone arch, with an X drawn a short way southwest of it.`,"地图上是一片沙滩和一艘歪倒的船，叉画在船的西北方、营火附近的沙地上。":`The map shows a beach and a toppled ship. The X is on the sand northwest of the ship, near a campfire.`,"地图上画着一座圆顶的观星台，叉在它的东北方，靠近一块平地。":`The map shows a domed observatory. The X is to its northeast, near a patch of flat ground.`,动物:`Animals`,绵羊:`Sheep`,"草原上最常见的居民，毛茸茸的，喜欢成群结队。":`The most common residents of the meadows. Fluffy, and fond of a crowd.`,团子:`Dumpling`,"村里的橘猫，整天在艾拉奶奶家门口晒太阳。":`The village's ginger cat. Spends all day sunbathing at Granny Aila's door.`,赤狐:`Red Fox`,"森林里机灵的小狐狸，总在你靠近时跑开。":`A clever little forest fox that always scampers off when you get close.`,星光狐:`Starlight Fox`,"浑身泛着微光的狐狸，据说会把人引向星屑。":`A softly glowing fox. They say it leads travelers to stardust shards.`,梅花鹿:`Spotted Deer`,"胆小的森林居民，一有动静就会跑远。":`A timid forest dweller that bolts at the slightest sound.`,寄居蟹:`Hermit Crab`,"在沙滩上横着走的小家伙。":`A little fellow scuttling sideways across the sand.`,海鸥:`Seagull`,"在海岸上空盘旋，时不时发出嘎嘎的叫声。":`Circles above the coast, squawking every now and then.`,花蝴蝶:`Butterfly`,"白天在花丛中飞舞。":`Dances among the flowers by day.`,夜枭:`Night Owl`,"只在夜晚的森林里出现，眼睛像两盏小灯。":`Appears only in the woods at night, eyes like two little lamps.`,雨蛙:`Rain Frog`,"下雨天会出现在水晶湖边呱呱叫。":`Croaks along the shores of Crystal Lake when it rains.`,岩羊:`Mountain Goat`,"雪山悬崖上的攀岩高手。":`An expert climber of the snowy cliffs.`,红岩蜥:`Redrock Lizard`,"在峡谷的岩石上晒太阳。":`Basks on the warm rocks of the canyon.`,座头鲸:`Humpback Whale`,"偶尔在东边的海面上浮起换气，非常罕见。":`Very rare. Now and then it surfaces for air in the eastern sea.`,萤火虫:`Fireflies`,"夜晚迷雾森林里的点点亮光。":`Tiny lights drifting through the Misty Woods at night.`,植物:`Plants`,橡树:`Oak`,"草原和森林边缘的阔叶树。":`A broadleaf tree of the meadows and forest edges.`,松树:`Pine`,"耐寒的针叶树，长在湖边和山脚。":`A hardy conifer growing by the lake and in the foothills.`,雾松:`Mist Pine`,"迷雾森林里高大的深色松树。":`Tall, dark pines of the Misty Woods.`,雪松:`Snow Pine`,"枝头挂着积雪的松树，只长在雪山高处。":`Snow-laden pines that grow only high on the mountain.`,椰子树:`Palm Tree`,"海边的标志，树顶挂着椰子。":`A seaside icon with coconuts hanging up top.`,仙人掌:`Cactus`,"峡谷里的耐旱植物，有时会开粉色的花。":`A drought-proof canyon plant that sometimes blooms pink.`,野花:`Wildflowers`,"草原上五颜六色的小花。":`Colorful little flowers dotting the meadows.`,向日葵:`Sunflower`,"总是朝着太阳的方向。":`Always turned toward the sun.`,红蘑菇:`Red Mushroom`,"森林地面上的蘑菇，别乱吃。":`Grows on the forest floor. Don't eat it!`,芦苇:`Reeds`,"湖边浅水里的植物。":`Plants of the lake shallows.`,湖晶:`Lake Crystal`,"水晶湖周围自然生长的发光晶体。":`Glowing crystals that grow naturally around Crystal Lake.`,地标:`Landmarks`,老风车:`Old Windmill`,"村庄的标志，阳台上能看到整片草原。":`The village landmark. Its balcony overlooks the whole meadow.`,星屑灯塔:`Stardust Lighthouse`,"雪山顶上熄灭的灯塔，群岛的守护者。":`The dark lighthouse atop Frostpeak, the isles' guardian.`,"星野先生观测星空的地方。":`Where Mr. Hoshino watches the stars.`,"不知是谁留下的石柱和地砖。":`Stone pillars and tiles left by no one knows who.`,沉船:`Shipwreck`,"很久以前搁浅在海岸边的帆船。":`A sailing ship that ran aground long ago.`,"峡谷里被风雕刻出的天然拱门。":`A natural arch carved by the canyon winds.`,"森林里最古老的树，树干上长满了蘑菇台阶。":`The oldest tree in the forest, its trunk ringed with mushroom steps.`,鱼类:`Fish`,海鲈鱼:`Sea Bass`,"码头边最常见的鱼。":`The most common catch at the pier.`,青花鱼:`Mackerel`,"游得很快的海鱼。":`A fast-swimming sea fish.`,河豚:`Pufferfish`,"被钓上来就会鼓成一个球。":`Puffs up into a ball the moment it is caught.`,金鳞鱼:`Goldscale`,"传说中的鱼，鳞片像星屑一样闪光。":`A legendary fish whose scales shimmer like stardust.`,灯笼鱼:`Lanternfish`,"只在夜里浮上来的发光小鱼。":`A small glowing fish that rises only at night.`,虹鳟:`Rainbow Trout`,"水晶湖里的冷水鱼。":`A cold-water fish of Crystal Lake.`,水晶鲤:`Crystal Carp`,"身体半透明的鲤鱼，只在水晶湖里有。":`A see-through carp found only in Crystal Lake.`,鲑鱼:`Salmon`,"在河里逆流而上的鱼。":`Swims upstream against the river current.`,鲶鱼:`Catfish`,"长着胡子的河底大鱼。":`A big whiskered fish of the riverbed.`,相机:`Camera`,滑翔翼:`Glider`,提灯:`Lantern`,钓竿:`Fishing Rod`,脚蹼:`Flippers`,小铁铲:`Little Shovel`,"能在藏宝图标记的地方挖宝。":`Dig up treasure where a treasure map marks the spot.`,弹跳靴:`Bounce Boots`,"在空中再按一次空格可以二段跳。":`Press Space again in mid-air to double jump.`,星屑罗盘:`Stardust Compass`,"指向最近的、还没找到的星屑。":`Points to the nearest stardust shard you have not found yet.`,热可可:`Hot Cocoa`,"暖暖的一杯，适合送给怕冷的人。":`A warm mug, perfect for someone who feels the cold.`,草帽:`Straw Hat`,"夏天必备。":`A summer essential.`,花环:`Flower Crown`,"用草原上的野花编的。":`Woven from meadow wildflowers.`,厨师帽:`Chef's Hat`,"戴上它感觉自己会做饭了。":`Wearing it, you feel like you can cook.`,海盗帽:`Pirate Hat`,巫师帽:`Wizard Hat`,毛线帽:`Beanie`,跑步帽:`Running Cap`,星之王冠:`Star Crown`},Ed={艾拉奶奶:`Granny Aila`,皮普博士:`Dr. Pip`,货郎阿贝:`Abe the Peddler`,牧羊人米娅:`Mia the Shepherd`,渔夫老海:`Old Hai`,采菇人菇菇:`Kuku the Forager`,跳跳:`Hops`,天文学家星野:`Hoshino the Astronomer`,登山者阿峰:`Feng the Climber`,"和{0}说话":`Talk to {0}`,摸摸团子:`Pet Dumpling`,"团子舒服地眯起了眼睛 😺":`Dumpling squints happily 😺`,"（随便聊聊）":`(Just chat)`,再见:`Goodbye`,"（想跟对方说点什么？回车发送，Esc 结束聊天）":`(What would you like to say? Enter to send, Esc to stop chatting)`,"哎呀，你醒啦！昨晚那场流星雨可真吓人，你就是在那时候被冲上岸的吧？":`Oh my, you're awake! That meteor shower last night was frightful. Is that when you washed ashore?`,"我叫艾拉，以前是雪山顶上那座灯塔的守塔人。你看——北边最高的那座山，山顶上的灯塔已经熄灭了。":`I'm Aila. I used to keep the lighthouse up on the snowy peak. Look - the tallest mountain to the north. Its light has gone out.`,"流星雨把灯塔里的星星打碎了，碎片变成了「星屑」，散落在群岛的各个角落。":`The meteors shattered the star inside the lighthouse. Its pieces became "stardust shards," scattered all over the isles.`,"只要收集到 20 颗星屑，就能重新点亮灯塔。我老了，爬不动雪山……你愿意帮帮我吗？":`Gather 20 shards and the lighthouse can shine again. I'm too old to climb that mountain... Will you help me?`,"交给我吧！":`Leave it to me!`,"星屑长什么样？":`What do shards look like?`,"金灿灿的，像一颗小星星，会自己发光。靠近了就能捡起来。":`Golden, like a tiny star, and they glow on their own. Just walk up to one to pick it up.`,"太好了！村子附近就有几颗：一颗在老风车的阳台上，踩着木箱就能跳上去；东边还有一排石柱，最高那根的顶上也有一颗。":`Wonderful! There are a few near the village: one on the old windmill's balcony - hop up the wooden crates - and one atop the tallest of the stone pillars to the east.`,"先找到 3 颗星屑再回来找我，我把年轻时用的滑翔翼送给你。有了它，你就能飞过河去更远的地方了。":`Find 3 shards and come back. I will give you the glider I used when I was young. With it you can fly across the river and much farther.`,"对了，旁边的皮普博士在研究岛上的动植物，去跟他打个招呼吧。":`Oh, and Dr. Pip next door studies the island's plants and animals. Go say hello.`,"哇，已经找到 3 颗星屑了！你真能干。":`Goodness, 3 shards already! Aren't you capable.`,"来，这是我年轻时的滑翔翼。在空中再按一次空格就能展开，一直按住空格就会一直滑翔。":`Here, the glider from my youth. Press Space again in mid-air to open it, and hold Space to keep gliding.`,"去村子东边的瞭望丘试试吧，从山顶起跳能一直滑过河，去对岸的红岩峡谷。":`Try it from Lookout Hill east of the village. Jump from the top and you can glide all the way across the river to Red Rock Canyon.`,"哦，还有：看到营火的话记得点亮它。点亮的营火可以在地图上快速旅行，还能在旁边休息。":`And remember to light any campfire you find. You can fast-travel to lit campfires from the map, and rest beside them.`,"现在有 {0} 颗星屑了，还差 {1} 颗。风车阳台、东边的石柱顶，还有南边遗迹里好像也藏着一颗。":`You have {0} shards now, {1} more to go. Try the windmill balcony and the top of the eastern pillars - and I think one is hidden in the southern ruins.`,"灯塔又亮起来了……每天晚上看着那道光扫过海面，我就想起你。谢谢你。":`The lighthouse shines again... Every night, watching that beam sweep the sea, I think of you. Thank you.`,"还想到处逛逛吗？群岛上应该还有没找到的星屑呢。":`Still feel like wandering? There must be shards nobody has found yet.`,讲讲灯塔的故事:`Tell me about the lighthouse`,"你已经找到 {0} 颗星屑了，还差 {1} 颗就能点亮灯塔。":`You have found {0} shards. {1} more and the lighthouse can be lit.`,"有什么建议吗？":`Any advice?`,"很久以前，群岛的夜晚总有迷路的船。第一代守塔人从天上请下了一颗星星，放进了雪山顶的灯塔里。":`Long ago, ships were always getting lost around the isles at night. The first keeper asked a star to come down from the sky, and set it in the lighthouse on the peak.`,"从那以后，灯塔的光每晚都会扫过海面，指引出海的人回家。我守了那座灯塔四十年。":`Ever since, its light has swept the sea each night, guiding sailors home. I kept that lighthouse for forty years.`,"直到那天晚上的流星雨……星核碎了，灯也熄了。不过只要星屑还在，光就一定能回来。":`Until the meteor shower that night... The star core broke and the light went out. But as long as the shards remain, the light will surely return.`,"西北边羊圈的米娅好像遇到麻烦了，去看看她吧。":`Mia at the sheep pen to the northwest seems to be in trouble. Go see her.`,"米娅的羊找齐了吗？她说找到就送你提灯。":`Found all of Mia's sheep yet? She said she'd give you a lantern.`,"南边码头的老海整天在钓鱼，他年轻时可是游泳好手。":`Old Hai fishes on the southern pier all day. He was quite the swimmer in his youth.`,"老海让你钓 3 种不同的鱼？海边、湖里、河里的鱼都不一样哦。":`Hai wants 3 kinds of fish? The sea, the lake and the river all have different ones.`,"你有藏宝图了？那得先去阿贝那里买把铲子。":`You have a treasure map? You'll need a shovel from Abe first.`,"雪山的悬崖很高，多收集一些金羽毛吧。高处、小岛上、森林深处都藏着羽毛。":`The cliffs on Frostpeak are tall - gather more golden feathers. They hide up high, on little islands and deep in the woods.`,"找不到星屑的话，阿贝那里有一个星屑罗盘，会指向最近的星屑。":`If you can't find shards, Abe sells a Stardust Compass that points to the nearest one.`,"去雪山看看吧！营火边可以休息，晚上天文台的星野可能也有事找你。":`Go take a look at Frostpeak! Rest by the campfires - and Hoshino at the observatory may need you at night.`,"哦哦！新面孔！我是皮普，研究动植物的博士。我正在编写《星屑群岛图鉴》！":`Ooh! A new face! I'm Pip, doctor of plants and animals. I'm writing the Stardust Isles Field Guide!`,"可惜我腿脚慢，岛上好多地方都去不了。这台相机送给你，帮我拍下你见到的动物、植物和地标吧！":`Sadly I'm slow on my feet and can't reach half the island. Take this camera and snap the animals, plants and landmarks you find!`,"按 C 拿出相机，对准目标点一下左键就能拍照。拍到新东西就会自动登记进图鉴。鱼就得靠钓上来才算啦。":`Press C for the camera, aim, and left-click to take a photo. New things go straight into the field guide. Fish only count once you catch them, though.`,"图鉴每凑满 10 条就来找我，我有奖励给你——是星屑哦！":`Come see me for every 10 entries. I have a reward for you - a stardust shard!`,"图鉴已经有 {0} 条了？！太棒了！这是约定好的奖励！":`{0} entries already?! Fantastic! Here is the reward I promised!`,"图鉴现在有 {0} 条。凑到 {1} 条的时候再来找我吧！":`The guide has {0} entries. Come back when you reach {1}!`,"图鉴研究已经很完整了，你真是个了不起的探险家！":`The field guide is practically complete. You're a remarkable explorer!`,"有什么没拍到的吗？":`Anything I still need?`,"嗯……比如「{0}」：{1}":`Hmm... like the "{0}": {1}`,"全拍到了！你太厉害了！":`You've photographed everything! Incredible!`,"欢迎光临！我是货郎阿贝，岛上的东西我这里都有卖。用贝壳币付款就行——路边那些粉色的贝壳就是。":`Welcome! I'm Abe the Peddler - if it's on the island, I sell it. Pay in shell coins, those pink shells by the roadside.`,"{0} — {1} 贝壳币":`{0} - {1} shell coins`,"把鱼都卖掉（{0} 条）":`Sell all fish ({0})`,不买了:`Nothing, thanks`,"想要点什么？（你有 {0} 枚贝壳币）":`What will it be? (You have {0} shell coins)`,"慢走！欢迎再来！":`Take care! Come again!`,"一共 {0} 枚贝壳币，拿好！":`That's {0} shell coins. Here you go!`,"{0}要 {1} 枚贝壳币，你的钱好像不够哦。":`The {0} costs {1} shell coins. Looks like you're a bit short.`,"{0}：{1}\n要买吗？":`{0}: {1}
Buy it?`,"买！":`Buy!`,再想想:`Let me think`,"获得 热可可 ×1":`Got Hot Cocoa ×1`,"谢谢惠顾！":`Thanks for your business!`,"呜呜……你好。我是米娅，这些羊都是我养的。":`*sniff*... Hi. I'm Mia. I look after these sheep.`,"昨晚的流星雨把它们吓坏了，有三只跑丢了，到现在还没回来……":`The meteor shower scared them silly last night. Three ran off and haven't come back...`,"你能帮我把它们找回来吗？":`Could you help me find them?`,"好，我去找找看":`Sure, I'll look`,"它们往哪边跑了？":`Which way did they go?`,"我好像看到一只往东边的河边跑了，一只往南边的遗迹那边，还有一只钻进了西边森林的边上。":`I think one ran east to the river, one south toward the ruins, and one slipped into the edge of the western forest.`,"走到它身边按 E，它就会乖乖跟着你。把它带回这个羊圈就好！":`Walk up and press E and it will follow you. Just bring it back to the pen!`,"三只都回来了！谢谢你，谢谢你！":`All three are back! Thank you, thank you!`,"这盏提灯送给你。西边的迷雾森林深处特别黑，没有灯是走不进去的。":`Please take this lantern. The heart of the Misty Woods is pitch dark - you can't go in without a light.`,"还有这个……是我在羊圈里捡到的，亮晶晶的，应该就是你在找的东西吧？":`And this... I found it in the pen, all sparkly. It's what you're looking for, isn't it?`,"已经回来 {0} 只了，还差 {1} 只。东边河边、南边遗迹、西边森林边上，再找找看吧！":`{0} are back, {1} still missing. Try by the eastern river, the southern ruins and the edge of the western forest!`,"羊儿们今天都很乖。提灯好用吗？":`The sheep are behaving today. Is the lantern working well?`,"森林里有什么？":`What's in the forest?`,"听说森林最深处的古树下住着发光的蘑菇，晚上还有萤火虫。菇菇常在森林营火那边采蘑菇。":`They say glowing mushrooms grow under the old trees deep in the forest, and fireflies come out at night. Kuku often forages near the forest campfire.`,"嗯？年轻人，会钓鱼吗？不会也没关系，我老海教你。":`Hm? Can you fish, youngster? No matter - old Hai will teach you.`,"这根钓竿拿去。看到水面上有涟漪的地方，走过去按 E 甩竿。":`Take this rod. Find ripples on the water, walk over, and press E to cast.`,"等鱼咬钩了会有提示，按 E 提竿，然后在指针走到绿色区域时按 E 收线，三次成功就钓上来了。":`When a fish bites you'll know. Press E to hook it, then press E whenever the needle is in the green zone. Three good reels and it's yours.`,"钓到 3 种不同的鱼再来找我。到时候我送你一样好东西——没有它，你可没法在这冰冷的海里游泳。":`Catch 3 different kinds of fish and come back. I'll give you something good - without it, you won't last a minute swimming in this cold sea.`,"哈哈，3 种了！你是个好渔夫。":`Ha ha, three kinds! You're a fine fisher.`,"这双脚蹼是我年轻时用的。穿上它就能在海里和湖里游泳了，按住 Shift 还能游得更快。":`These flippers served me when I was young. With them you can swim in the sea and the lake - hold Shift to swim faster.`,"还有这个，是上周从一条鱼肚子里找到的。我留着也没用，给你吧。":`And this - found it in a fish's belly last week. No use to me. It's yours.`,"你已经钓到 {0} 种鱼了，还差 {1} 种。海边、水晶湖、河里的鱼都不一样哦。":`You've caught {0} kinds so far, {1} to go. The sea, Crystal Lake and the river each have their own.`,"今天的海风真舒服。":`Lovely sea breeze today.`,钓鱼的诀窍:`Fishing tips`,"码头和海岸边能钓到海鱼，晚上还会有灯笼鱼浮上来。水晶湖有水晶鲤，河里有鲑鱼和鲶鱼。":`Sea fish bite at the pier and the coast, and lanternfish rise at night. Crystal Lake has crystal carp; the river has salmon and catfish.`,"传说海里还有一种金鳞鱼，鳞片像星屑一样亮……我钓了一辈子也只见过一次。":`Legend says the sea holds a goldscale, its scales bright as stardust... I have seen it only once in all my years.`,"嘘——小声点，你会吓跑蘑菇的。……开玩笑啦，我是菇菇。":`Shhh - quiet, you'll scare the mushrooms. ...Just kidding! I'm Kuku.`,"森林最深处长着一种会发蓝光的蘑菇，可好看了。可是里面太黑了，我一进去就迷路。":`Deep in the forest grows a mushroom that glows blue. So pretty! But it is so dark in there, I get lost every time.`,"咦，你有提灯！能帮我采 5 个发光蘑菇吗？走过去就能捡起来。":`Oh, you have a lantern! Could you gather 5 glowing mushrooms for me? Just walk over them to pick them up.`,"如果你有提灯的话，能帮我采 5 个回来吗？听说牧羊人米娅有一盏提灯。":`If you had a lantern, could you bring me 5? I hear Mia the shepherd has one.`,"哇——5 个发光蘑菇！它们在你手里一闪一闪的，真漂亮！":`Wow - 5 glowing mushrooms! Look how they twinkle in your hands!`,"作为谢礼，这个给你。我在蘑菇丛里找到的，它比蘑菇还亮呢。":`As thanks, have this. I found it in a mushroom patch - it shines even brighter than they do.`,"现在有 {0} 个，还差 {1} 个。都在森林最黑的那片地方。":`{0} so far, {1} to go. They're all in the darkest part of the forest.`,"森林今天也很安静呢。":`The forest is quiet today too.`,"附近有什么好玩的？":`Anything fun nearby?`,"北边那棵千年古树的树干上长满了大蘑菇，像台阶一样能一直爬到树顶！还有一只狐狸总在附近跑来跑去，好像想带人去什么地方。":`The Thousand-Year Tree up north has giant mushrooms on its trunk - you can climb them like stairs right to the top! And a fox keeps running around nearby, like it wants to lead someone somewhere.`,"嘿！你也是来探险的吗？我叫跳跳，是峡谷里跑得最快的人！":`Hey! You're an explorer too? I'm Hops, the fastest runner in the canyon!`,"上次输给你了，我每天都在练习！":`I lost to you last time, so I've been practicing every day!`,"峡谷里有什么？":`What's in the canyon?`,"峡谷的台地上有风铃柱，按 E 敲一下会出现一串光环。用滑翔翼按顺序穿过光环就能得到奖励！还有，那些旋转的风会把你往上吹哦。":`The mesas have wind-chime posts. Ring one with E and a trail of rings appears. Glide through them in order to win a prize! And those swirling winds will lift you up.`,"再比一次！":`Rematch!`,"要不要比赛？从这里出发，谁先跑到红石拱门下面谁赢！":`Wanna race? From here - first one under the Red Stone Arch wins!`,"来比！":`You're on!`,下次吧:`Maybe later`,"好！对话结束就开始倒数，准备好！":`Okay! The countdown starts when we finish talking. Get ready!`,"胆小鬼～我随时奉陪！":`Scaredy-cat~ I'm ready anytime!`,"你好啊，旅人。我是星野，在这里观测星空已经三十年了。":`Greetings, traveler. I am Hoshino. I have watched the stars from here for thirty years.`,"那场流星雨……其实是灯塔里的「星核」碎掉了。它的碎片落到群岛各处，就是你在找的星屑。":`That meteor shower... was really the lighthouse's star core breaking apart. Its pieces fell across the isles - the shards you seek.`,"今晚的星星格外亮。":`The stars are especially bright tonight.`,聊聊星星:`Let's talk about stars`,"天鹅座、猎户座、北斗七星……古人用石台记下了它们。灯塔重新亮起来的时候，星星也会更亮吧。":`Cygnus, Orion, the Big Dipper... The ancients recorded them on stone altars. When the lighthouse shines again, perhaps the stars will too.`,"天文台外面有三座古老的石台，分别刻着天鹅座、猎户座和北斗七星。":`Outside the observatory stand three ancient altars, carved with Cygnus, Orion and the Big Dipper.`,"夜晚按照「天鹅 → 猎户 → 北斗」的顺序点亮它们，星空就会回应你。顺序错了就要重来。":`Light them at night in the order Cygnus → Orion → Big Dipper, and the sky will answer. Get the order wrong and you must start over.`,"不过现在是白天，石台不会有反应。你可以去营火旁边休息到晚上再来。":`But it is daytime; the altars will not respond. Rest at a campfire until nightfall and come back.`,"哈——欠！你好……我叫阿峰，想登上霜顶雪山的山顶，结果爬到这里就冻得动不了了。":`Ah-choo! H-hi... I'm Feng. I wanted to summit Frostpeak, but I got this far and froze stiff.`,"这座山有四层悬崖，一层比一层高。攀爬会消耗体力，体力不够的话爬到一半就会滑下来。":`The mountain has four tiers of cliffs, each taller than the last. Climbing uses stamina - run out halfway and you slide right back down.`,"收集金羽毛可以提升体力上限。我估计至少要五六根才能爬到山顶。":`Golden feathers raise your max stamina. I'd guess you need five or six to reach the top.`,"喝了热可可，浑身都暖和了！":`That cocoa warmed me right up!`,"有什么攀登技巧？":`Any climbing tips?`,"爬到一半体力快没了的时候，可以按空格往上蹬一大步，不过会消耗很多体力。悬崖之间的平台上可以休息恢复体力。":`If you are running low mid-climb, press Space to kick up a big step - it costs a lot of stamina, though. Rest on the ledges between cliffs to recover.`,"那是……热可可的香味？！":`Is that... the smell of hot cocoa?!`,把热可可送给阿峰:`Give Feng the hot cocoa`,不给:`Keep it`,"啊——活过来了！太谢谢你了！":`Ahh - I'm alive again! Thank you so much!`,"这根金羽毛是我在悬崖上捡的，送给你。有了它你能爬得更高！":`I found this golden feather on the cliffs. Take it - it will help you climb higher!`,"爬悬崖时体力快没了可以按空格往上蹬一步。祝你登顶顺利！":`When your stamina runs low on a cliff, press Space to kick upward. Good luck on the summit!`,"呜……好吧……":`Aww... okay...`,"好冷啊……要是有一杯热可可就好了。村里的阿贝好像有卖……":`So cold... If only I had a cup of hot cocoa. I think Abe in the village sells some...`},Dd={星屑群岛:`Stardust Isles`,"Stardust Isles":`— an island adventure —`,"正在生成群岛…":`Generating the isles…`,继续旅程:`Continue Journey`,新的旅程:`New Journey`,"一款探索收集小游戏 · 所有模型、音乐和音效均由代码生成":`An exploration & collection game · every model, tune and sound is generated in code`,"WASD 移动 · 空格 跳跃 · Shift 冲刺 · 左键/J 攻击 · Q 翻滚 · E 互动 · Tab 菜单 · 点击画面锁定视角":`WASD move · Space jump · Shift sprint · LMB/J attack · Q roll · E interact · Tab menu · click to lock the camera`,"左键 拍照 · 滚轮 变焦 · C 退出":`LMB snap · wheel zoom · C exit`,"想说什么？（回车发送，Esc 结束）":`Say something… (Enter to send, Esc to stop)`,"Tab / Esc 关闭":`Tab / Esc to close`,"加载失败：":`Failed to load: `,"确定覆盖存档？再点一次":`Overwrite your save? Click again`,"第{0}天 {1}:{2}":`Day {0} {1}:{2}`,"{0} 米":`{0} m`,'<span class="thinking">（思考中…）</span>':`<span class="thinking">(thinking…)</span>`,"按 C 拍照，登记图鉴":`Press C to take photos for the field guide`,"在空中再按一次空格展开，按住保持滑翔":`Press Space again in mid-air to open it; hold to keep gliding`,可以走进漆黑的迷雾森林深处了:`Now you can venture into the pitch-dark heart of the Misty Woods`,"在有涟漪的水面附近按 E 钓鱼":`Press E near rippling water to fish`,"现在可以在水里游泳了，按住 Shift 游得更快":`You can swim now. Hold Shift to swim faster`,"在藏宝图标记的地点按 E 挖宝":`Press E at the spot marked on a treasure map to dig`,在空中再按一次空格可以二段跳:`Press Space again in mid-air to double jump`,右上角会指向最近的星屑:`The top-right corner points to the nearest shard`,流星雨过后的第一个早晨:`The first morning after the meteor shower`,"前面那位老奶奶好像有话要说。走到她身边按 E。":`The old lady up ahead seems to want a word. Walk up to her and press E.`,"欢迎回来！":`Welcome back!`,"获得 {0}！":`Got the {0}!`,"来到了 {0}":`Arrived at {0}`,"休息得很好，精神饱满！":`You feel well rested!`,"营火（休息 / 快速旅行）":`Campfire (rest / fast travel)`,点亮营火:`Light the campfire`,"点亮了 {0}":`Lit the {0}`,"可以在地图上快速旅行到这里，也可以在营火旁休息":`You can fast-travel here from the map, or rest by the fire`,"火光暖洋洋的。要做什么？":`The fire is warm and cozy. What will you do?`,"休息到早晨（6:00）":`Rest until morning (6:00)`,"休息到中午（12:00）":`Rest until noon (12:00)`,"休息到黄昏（18:00）":`Rest until dusk (18:00)`,"休息到深夜（22:00）":`Rest until late night (22:00)`,"打开地图（快速旅行）":`Open the map (fast travel)`,离开:`Leave`,点亮灯塔:`Light the lighthouse`,"灯塔的大门（星屑 {0}/{1}）":`Lighthouse door (shards {0}/{1})`,"门上有一个星形的凹槽，还需要 {0} 颗星屑才能打开。":`There is a star-shaped hollow in the door. You need {0} more shards to open it.`,"灯塔重新亮起来了！":`The lighthouse shines again!`,光芒再次照亮了星屑群岛:`Its light once more watches over the Stardust Isles`,"灯塔的光芒扫过海面，艾拉奶奶站在村口，久久地望着雪山顶。":`The lighthouse beam sweeps across the sea. Granny Aila stands at the edge of the village, gazing up at the peak for a long while.`,"谢谢你，旅人。群岛的夜晚再也不会迷路了。":`Thank you, traveler. No one will lose their way in the island nights again.`,金羽毛:`Golden Feathers`,"还有没找到的星屑？群岛一直在这里等你。":`Shards still out there? The isles will be waiting for you.`,继续探索:`Keep Exploring`,"体力耗尽了！收集金羽毛可以提升体力上限。":`Out of stamina! Golden feathers raise your max stamina.`,"水太冷了！没有脚蹼的话没法游泳。":`The water's too cold! You can't swim without flippers.`,"太黑了，前面什么都看不见……也许需要一盏提灯。":`It's too dark to see anything ahead... Maybe a lantern would help.`,"还没有相机。村里的皮普博士也许能帮忙。":`You don't have a camera yet. Dr. Pip in the village might help.`,"空格 二段跳":`Space: double jump`,"空格 展开滑翔翼（按住）":`Space: open glider (hold)`,"松开空格 收起滑翔翼 · S 减速":`Release Space to fold the glider · S to slow down`,"空格 向上蹬（消耗体力）· S 向下爬":`Space: kick upward (costs stamina) · S: climb down`,"水太冷了！快上岸":`Too cold! Get out of the water!`,"C 相机":`C camera`,"Tab 菜单":`Tab menu`,"M 地图":`M map`,"远方群岛 · {0}":`Far Isles · {0}`,无尽之海:`Endless Sea`,远方群岛:`The Far Isles`,"离家越远，蚀影越强，宝藏也越丰厚。":`The farther from home, the stronger the gloom - and the richer the treasure.`,"下雨了……雨天会有特别的动物出现。":`It started raining... Special animals come out in the rain.`,低:`Low`,中:`Medium`,高:`High`,极致:`Ultra`,地图:`Map`,任务:`Quests`,收集:`Collection`,图鉴:`Field Guide`,装扮:`Wardrobe`,设置:`Settings`,"你在地图之外：距离群岛中心 <b>{0} 米</b>":`You are off the map: <b>{0} m</b> from the center of the isles`,"走出海岸，沿着沙洲栈道就能到达。":`Walk out past the coast along a sandbar causeway to reach them.`,"最远到过 {0} 米":`Farthest reached: {0} m`,图例:`Legend`,"营火：":`Campfires: `,点击已点亮的营火快速旅行:`Click a lit campfire to fast travel`,现在不能快速旅行:`You can't fast travel right now`,认识的居民:`Residents you have met`,藏宝图标记:`Treasure map marks`,"已点亮营火 {0}/{1}":`Campfires lit {0}/{1}`,"还没有点亮任何营火。走到营火旁按 E 点亮。":`You haven't lit any campfires yet. Walk up to one and press E.`,"？？？":`???`,进度:`Progress`,星屑:`Stardust shards`,"金羽毛（体力上限）":`Golden feathers (max stamina)`,贝壳币:`Shell coins`,营火:`Campfires`,钓到的鱼:`Fish caught`,打开的宝箱:`Chests opened`,游戏时间:`Play time`,"{0} 分钟":`{0} min`,道具:`Tools`,背包:`Bag`,藏宝图:`Treasure Map`,发光蘑菇:`Glowing Mushroom`,"按 C 打开相机，对准目标点击拍照即可登记。鱼类需要钓上来才会登记。已登记 {0} / {1}":`Press C for the camera and click to photograph a subject. Fish are recorded when caught. Recorded {0} / {1}`,用钓竿钓上来:`Catch it with a rod`,用相机拍下来:`Photograph it`,"点击切换帽子。帽子可以在商店买到，或者藏在宝箱里。已收集 {0} / {1}":`Click to change hats. Hats are sold in the shop or hidden in chests. Collected {0} / {1}`,不戴帽子:`No hat`,"语言 / Language":`Language`,切换后会保存并重新载入:`Switching saves and reloads the game`,音效音量:`Sound volume`,音乐音量:`Music volume`,鼠标灵敏度:`Mouse sensitivity`,"反转 Y 轴":`Invert Y axis`,画质:`Graphics`,"高：泛光、柔和阴影、茂密草地 · 极致：再加环境光遮蔽":`High: bloom, soft shadows, dense grass · Ultra: adds ambient occlusion`,阴影:`Shadows`,关闭可以提升帧率:`Turn off for a higher frame rate`,"AI 闲聊":`AI chat`,"已连接：和居民对话时可以选择“随便聊聊”":`Connected: choose "Just chat" when talking to residents`,"服务器未配置 API Key，此功能不可用":`Unavailable: the server has no API key configured`,操作说明:`Controls`,"WASD / 方向键 移动 · 鼠标 转动视角（点击画面锁定，或按住右键拖动）· 滚轮 缩放":`WASD / arrow keys move · mouse turns the camera (click to lock, or drag with the right button) · wheel zooms`,"空格 跳跃；在空中再按一次：二段跳（弹跳靴）或展开滑翔翼（按住保持滑翔）":`Space jumps; press again in mid-air to double jump (Bounce Boots) or open the glider (hold to keep gliding)`,"朝着陡坡移动就会攀爬，消耗体力；体力用完会滑下来。收集金羽毛可以提升体力上限":`Walk into a steep slope to climb it. Climbing costs stamina, and you slide down when it runs out. Golden feathers raise your max stamina`,"Shift 冲刺 · E 互动 · C 相机 · Tab / M 菜单和地图":`Shift sprint · E interact · C camera · Tab / M menu and map`,"左键 / J 攻击（连按打出三段连击，空中按下是下落重击）· Q 翻滚闪避（有无敌时间，消耗体力）":`LMB / J attack (keep pressing for a 3-hit combo; in mid-air it becomes a plunge attack) · Q dodge roll (brief invulnerability, costs stamina)`,"走出主岛的海岸（沙洲栈道、游泳或滑翔）就是无限延伸的远方群岛：越远越危险，宝箱也越丰厚":`Beyond the main island's coast (via sandbar causeways, swimming or gliding) lie the endless Far Isles: the farther you go, the more dangerous - and the richer the chests`,保存游戏:`Save game`,保存并返回标题:`Save and return to title`,已保存:`Saved`,点亮星屑灯塔:`Light the Stardust Lighthouse`,"你点亮了灯塔，群岛重新有了光。":`You lit the lighthouse, and the isles have their light back.`,"收集星屑（{0}/{1}），登上霜顶雪山顶，打开灯塔的门。":`Collect shards ({0}/{1}), climb to the top of Frostpeak and open the lighthouse door.`,艾拉的礼物:`Aila's Gift`,"你得到了滑翔翼：在空中再按一次空格展开。":`You got the glider: press Space again in mid-air to open it.`,"先在村子附近找到 3 颗星屑，再回去找艾拉奶奶（{0}/3）。":`Find 3 shards around the village, then return to Granny Aila ({0}/3).`,皮普的图鉴:`Pip's Field Guide`,"图鉴研究完成！":`Field guide research complete!`,"按 C 打开相机拍摄动植物和地标。图鉴 {0}/{1}，凑满 10 / 20 / 30 条去找皮普博士领奖励。":`Press C to photograph plants, animals and landmarks. Field guide {0}/{1}; visit Dr. Pip at 10 / 20 / 30 entries for rewards.`,走失的羊:`Lost Sheep`,"米娅送了你一盏提灯。":`Mia gave you a lantern.`,"把走失的 3 只羊带回羊圈（{0}/3）。走到羊身边按 E，它就会跟着你。":`Bring the 3 lost sheep back to the pen ({0}/3). Press E next to a sheep and it will follow you.`,老海的钓鱼课:`Old Hai's Fishing Lesson`,"老海送了你一双脚蹼，现在可以下海游泳了。":`Hai gave you flippers. Now you can swim in the sea.`,"钓到 3 种不同的鱼，然后回码头找老海（{0}/3）。":`Catch 3 different kinds of fish, then return to Hai at the pier ({0}/3).`,传说中的金鳞鱼:`The Legendary Goldscale`,"你钓到了金鳞鱼！":`You caught the goldscale!`,"老海说海里有一种会发光的金鳞鱼，非常难钓。":`Hai says a glowing goldscale lives in the sea, and it is very hard to catch.`,"菇菇很开心。":`Kuku is delighted.`,"在迷雾森林深处找到 5 个发光蘑菇（{0}/5），需要提灯才能进去。":`Find 5 glowing mushrooms deep in the Misty Woods ({0}/5). You need a lantern to get in.`,"你赢了跳跳！":`You beat Hops!`,"和跳跳比赛，看谁先跑到红石拱门下面。":`Race Hops to see who reaches the Red Stone Arch first.`,星空的秘密:`Secret of the Stars`,"三座石台都点亮了。":`All three altars are lit.`,"夜晚按照星野说的顺序点亮天文台外的三座石台：天鹅、猎户、北斗。":`At night, light the three altars outside the observatory in the order Hoshino described: Cygnus, Orion, Big Dipper.`,怕冷的登山者:`The Chilly Climber`,"阿峰把他的金羽毛送给了你。":`Feng gave you his golden feather.`,"阿峰想要一杯热可可。村里的阿贝那里有卖。":`Feng wants a cup of hot cocoa. Abe sells it in the village.`,"宝藏已经挖出来了。":`The treasure has been dug up.`,"（拿着铲子在那里按 E 挖掘）":`(Press E there with a shovel to dig)`,"（需要先买一把铲子）":`(You need to buy a shovel first)`,"{0}：{1}":`{0}: {1}`,"峡谷光环 · 北":`Canyon Rings · North`,"峡谷光环 · 东":`Canyon Rings · East`,海岸光环:`Coast Rings`,"敲响风铃（再挑战一次）":`Ring the chime (try again)`,敲响风铃:`Ring the chime`,"光环飘在半空中……需要滑翔翼才能穿过它们。":`The rings float in mid-air... You need a glider to fly through them.`,"在时间内按顺序穿过所有光环！":`Fly through every ring in order before time runs out!`,"挑战成功！":`Challenge complete!`,"时间到了……回到风铃柱再试一次吧。":`Time is up... Go back to the chime post and try again.`,重置石箱:`Reset the stone blocks`,"石箱回到了原位。":`The stone blocks slid back into place.`,"遗迹的祭坛亮了起来！":`The ruins altar lights up!`,转动镜子:`Turn the mirror`,"光束点亮了水晶！":`The beam lights up the crystal!`,天鹅座:`Cygnus`,猎户座:`Orion`,北斗七星:`the Big Dipper`,"触摸石台（{0}）":`Touch the altar ({0})`,"石台上刻着{0}。白天它没有任何反应。":`The altar is carved with {0}. It does nothing during the day.`,"星光熄灭了……顺序好像不对。":`The starlight fades... The order seems wrong.`,"三道星光连成了一线！":`Three beams of starlight join as one!`,"星光狐消失了，它留下了什么东西……":`The starlight fox vanished, leaving something behind...`,带上走失的羊:`Lead the lost sheep`,"羊跟在你身后了，把它带回米娅的羊圈吧。":`The sheep is following you. Take it back to Mia's pen.`,"羊回到了羊圈（{0}/3）":`A sheep is back in the pen ({0}/3)`,"三只羊都回来了！去告诉米娅吧。":`All three sheep are back! Go tell Mia.`,"目标：红石拱门":`Goal: Red Stone Arch`,"出发！":`Go!`,峡谷赛跑:`Canyon Race`,"你赢了！用时 {0} 秒":`You win! Time: {0}s`,"跳跳把他的跑步帽送给了你！":`Hops gave you his running cap!`,"跳跳：「哈哈，我赢啦！不服再来！」":`Hops: "Ha ha, I win! Try me again if you dare!"`,打开宝箱:`Open chest`,挖掘:`Dig`,"挖到宝藏了！":`You dug up treasure!`,"获得星屑！":`Stardust shard!`,"已经有 3 颗星屑了，回村里找艾拉奶奶吧！":`You have 3 shards. Head back to Granny Aila in the village!`,"星屑够了！去霜顶雪山顶点亮灯塔吧！":`You have enough shards! Go light the lighthouse atop Frostpeak!`,"全部星屑收集完成！":`Every shard collected!`,"获得了「星之王冠」，去菜单的装扮里戴上吧":`You got the Star Crown. Put it on in the Wardrobe menu`,"获得金羽毛！":`Golden feather!`,"体力上限提升 · {0} / 15":`Max stamina up · {0} / 15`,"获得 {0} 枚贝壳币":`Got {0} shell coins`,"获得帽子：{0}":`New hat: {0}`,"在菜单的「装扮」里可以戴上":`Wear it from the Wardrobe menu`,"获得藏宝图！":`Treasure map!`,去地图上标记的地方挖宝吧:`Dig at the spot marked on the map`,"需要一把铲子才能挖宝（阿贝的店里有卖）":`You need a shovel to dig (Abe's shop sells one)`,"发光蘑菇 {0}/5":`Glowing mushrooms {0}/5`,钓鱼:`Fish`,"等待鱼儿上钩……":`Waiting for a bite…`,"按 E 收竿":`Press E to reel in`,"！！！ 咬钩了！":`!!! A bite!`,"快按 E！":`Press E now!`,"鱼跑掉了……下次要快一点按 E。":`It got away... Press E faster next time.`,"线断了，鱼逃走了！":`The line snapped and the fish escaped!`,"收线！":`Reel it in!`,"指针在绿色区域时按 E · 成功 {0}/3 · 失误 {1}/2":`Press E while the needle is in the green · hits {0}/3 · misses {1}/2`,"钓到了 {0}！":`Caught a {0}!`,图鉴新增一条:`New field guide entry`,"金鳞鱼的嘴里衔着一颗星屑！":`The goldscale has a shard in its mouth!`,"、":`, `,"图鉴新增：{0}（{1}/{2}）":`New in the field guide: {0} ({1}/{2})`,"这些都已经登记过了。":`All of these are already recorded.`,"没拍到什么特别的东西。靠近一点，对准目标试试。":`Nothing special in the shot. Get closer and aim at your subject.`,"击败了 Lv.{0} {1}！":`Defeated Lv.{0} {1}!`,闪避:`DODGE`,"你倒下了……":`You collapsed…`,星光会指引你回到营火旁:`Starlight will guide you back to a campfire`,"在{0}醒来了。{1}":`You woke up at the {0}. {1}`,"遗失了 {0} 枚贝壳币。":`Lost {0} shell coins.`,打开远方宝箱:`Open far-isle chest`,"远方宝箱里有 {0} 枚贝壳币！":`The far-isle chest held {0} shell coins!`,小鹿:`Deer`,狐狸:`Fox`,山羊:`Goat`,螃蟹:`Crab`,青蛙:`Frog`,蜥蜴:`Lizard`,蚀影史莱姆:`Gloom Slime`,蚀影狼:`Shade Wolf`,晶甲魔像:`Crystal Golem`,"{0}点":`{0}:00`,海上:`at sea`,"（对方好像没听清你在说什么。）":`(They didn't seem to catch what you said.)`},Od={...Td,...Ed,...Dd},kd=`stardust-isles-lang`,Ad={en:Od},jd={zh:`中文`,en:`English`};function Md(){try{let e=localStorage.getItem(kd);if(e&&(e===`zh`||Ad[e]))return e}catch{}return`zh`}var Nd=Md(),Pd=Ad[Nd]||null,Fd=new Set;function Y(e,t){let n=e;if(Pd){let t=Pd[e];t===void 0?Fd.has(e)||(Fd.add(e),typeof window<`u`&&(window.__i18nMissing||=[]).push(e)):n=t}return(t||n.includes(`{{`))&&(n=n.replace(/\{\{|\}\}|\{(\d+)\}/g,(e,n)=>e===`{{`?`{`:e===`}}`?`}`:String(t?.[+n]??``))),n}function Id(e){try{localStorage.setItem(kd,e)}catch{}}function Ld(e=document){for(let t of e.querySelectorAll(`[data-i18n]`))t.textContent=Y(t.dataset.i18n);for(let t of e.querySelectorAll(`[data-i18n-ph]`))t.placeholder=Y(t.dataset.i18nPh);document.documentElement.lang=Nd===`en`?`en`:`zh-CN`}var Rd={meadow:{name:Y(`晨风草原`),x:0,z:140,r:230},forest:{name:Y(`迷雾森林`),x:-240,z:10,r:170},canyon:{name:Y(`红岩峡谷`),x:235,z:-30,r:170},coast:{name:Y(`珊瑚海岸`),x:190,z:215,r:140},lake:{name:Y(`水晶湖`),x:-190,z:-150,r:110},mountain:{name:Y(`霜顶雪山`),x:0,z:-235,r:165}},zd={x:0,z:150,r:42,h:5.5},Bd={x:-190,z:-150,r:60,level:14},Vd={x:-265,z:0,r:80},Hd={x:0,z:-235,summitR:20,base:150},Ud=[{r:120,h:8},{r:88,h:12},{r:58,h:15},{r:32,h:22}],Wd={x:118,amp:12,freq:.018,start:-135},Gd={lookout:{x:70,z:92,r:28,h:21,name:Y(`瞭望丘`)},observatory:{x:108,z:-142,r:22,h:8,name:Y(`星野天文台`)},ruins:{x:-115,z:245,name:Y(`古代遗迹`)},shipwreck:{x:285,z:285,name:Y(`搁浅的沉船`)},arch:{x:230,z:55,name:Y(`红石拱门`)},giantTree:{x:-175,z:95,name:Y(`千年古树`)},dock:{x:-10,z:318,name:Y(`渔夫码头`)},pen:{x:-70,z:95,name:Y(`羊圈`)}},Kd=[{x:-115,z:245,r:14,h:4.4}],qd=[{x:372,z:168,r:26,h:7},{x:318,z:372,r:30,h:6},{x:-300,z:335,r:24,h:6}],Jd=[{x:-215,z:-165,r:12,h:17},{x:-165,z:-175,r:10,h:16.6},{x:-185,z:-120,r:11,h:16.8},{x:-220,z:-125,r:8,h:16.4}],Yd=[{id:`village`,x:22,z:172,name:Y(`村庄营火`)},{id:`forest`,x:-170,z:30,name:Y(`森林营火`)},{id:`canyon`,x:180,z:-10,name:Y(`峡谷营火`)},{id:`coast`,x:195,z:215,name:Y(`海岸营火`)},{id:`lake`,x:-125,z:-135,name:Y(`湖畔营火`)},{id:`mountain`,x:55,z:-95,name:Y(`山脚营火`)},{id:`summit`,x:12,z:-228,name:Y(`峰顶营火`)}],Xd={start:425,full:520,landFrom:470,landFull:660},Zd=[-.5,Math.PI+.15,-2.25],Qd={meadow:{name:Y(`翠屿草原`),bt:0,bm:-.05},forest:{name:Y(`雾隐林海`),bt:-.1,bm:.35},canyon:{name:Y(`赤岩荒地`),bt:.4,bm:-.3},snow:{name:Y(`霜原`),bt:-.45,bm:-.2},crystal:{name:Y(`晶辉海滩`),bt:.35,bm:.35}},$d=vd(1337),ef=vd(4242),tf=vd(99),nf=vd(8081),rf=vd(6262),af=vd(1717),of=vd(2929),sf=Object.keys(Qd),cf=900/360,lf=361,uf=Object.keys(Rd);function df(e,t,n,r){let i=Math.hypot(t-r.x,n-r.z);if(i>=r.r)return e;let a=1-i/r.r;return Math.max(e,r.h*Sd(0,1,a*1.6))}function ff(e,t){let n={},r=0;for(let i of uf){let a=Rd[i],o=Math.hypot(e-a.x,t-a.z),s=Sd(a.r,a.r*.75,o);i===`meadow`&&(s+=.05),n[i]=s,r+=s}for(let e of uf)n[e]/=r;return n}function pf(e,t){let n=Math.hypot(e,t),r=Math.atan2(t,e),i=348+yd(ef,Math.cos(r)*1.5+3,Math.sin(r)*1.5+3,3)*45;return Sd(i+26,i-40,n)}function mf(e){return Wd.x+Wd.amp*Math.sin(e*Wd.freq)}function hf(e,t){let n=ff(e,t),r=4.5+yd($d,e*.011,t*.011,4)*5.5,i=10+yd($d,e*.013+40,t*.013,4)*7,a=yd(tf,e*.016,t*.016,3),o=7+Sd(-.02,.05,a)*19+Sd(.26,.32,a)*13+yd($d,e*.05,t*.05,2)*1.2,s=2.8+yd($d,e*.02,t*.02,3)*2.2,c=Math.hypot(e-Bd.x,t-Bd.z),l=xd(6,21+yd($d,e*.03,t*.03,2)*2.5,Sd(50,72,c)),u=Math.hypot(e-Hd.x,t-Hd.z),d=Math.atan2(t-Hd.z,e-Hd.x),f=10+Math.max(0,Hd.base-u)*.075+yd($d,e*.04,t*.04,2)*1.2;for(let e of Ud){let t=e.r+yd(ef,Math.cos(d)*2+e.r,Math.sin(d)*2,2)*8;f+=Sd(t+1.6,t-1.6,u)*e.h}u<Hd.summitR&&(f=xd(f,10+Hd.base*.075+57+.4,Sd(Hd.summitR,8,u)));let p=r*n.meadow+i*n.forest+o*n.canyon+s*n.coast+l*n.lake+f*n.mountain,m=Sd(21,8,Math.abs(e-mf(t)))*Sd(Wd.start-20,Wd.start+25,t);p=xd(p,-3.5,m);let h=Math.hypot(e-zd.x,t-zd.z);p=xd(p,zd.h,Sd(zd.r+18,zd.r,h));for(let n of Kd){let r=Math.hypot(e-n.x,t-n.z);r<n.r+10&&(p=xd(p,n.h,Sd(n.r+10,n.r,r)))}p=df(p,e,t,Gd.lookout),p=df(p,e,t,Gd.observatory);for(let n of Jd)p=df(p,e,t,n);let g=pf(e,t);return p=xd(-12+yd(tf,e*.01,t*.01,2)*3,p,g),p}function gf(e,t){return Sd(Xd.start,Xd.full,Math.hypot(e,t))}function _f(e,t,n={}){let r=yd(af,e*.0011+11,t*.0011,2),i=yd(of,e*.0013,t*.0013+7,2),a=0;for(let e of sf){let t=Qd[e],o=(r-t.bt)**2+(i-t.bm)**2,s=Math.exp(-o*22);n[e]=s,a+=s}for(let e of sf)n[e]/=a;return n}function vf(e,t){let n=_f(e,t),r=`meadow`,i=-1;for(let e of sf)n[e]>i&&(i=n[e],r=e);return r}var yf={};function bf(e,t){let n=Math.hypot(e,t),r=yd(nf,e*.0024,t*.0024,3),i=yd(rf,e*.011,t*.011,3);return r*1.5+i*.32+.06-(1-Sd(Xd.landFrom,Xd.landFull,n))*.7}function xf(e,t){let n=bf(e,t);if(n<0){let e=xd(.4,-.45,Sd(0,-.06,n));return e-=Sd(-.12,-.3,n)*.5,e-=Sd(-.38,-.7,n)*7.5,e}let r=_f(e,t,yf),i=Sd(0,.65,n),a=yd(rf,e*.03+5,t*.03,2),o=0;if(o+=r.meadow*(i*9+a*1.6*i),o+=r.forest*(i*13+a*2.5*i),r.canyon>.01){let e=i*26+a*2,t=6.5,n=e/t,s=n-Math.floor(n);o+=r.canyon*((Math.floor(n)+Sd(.55,.9,s))*t)}if(r.snow>.01){let n=1-Math.abs(yd(nf,e*.012+3,t*.012-9,3));o+=r.snow*(i*26+n*n*16*i)}return o+=r.crystal*(i*5+a*1.2*i),.4+o+Sd(0,.05,n)*.3}function Sf(e,t){let n=gf(e,t),r=n>=1?xf(e,t):n<=0?hf(e,t):xd(hf(e,t),xf(e,t),n);for(let n of qd)r=df(r,e,t,n);let i=Math.hypot(e,t);if(i>300&&i<900)for(let n of Zd){let i=Math.cos(n),a=Math.sin(n),o=e*i+t*a;if(o<300)continue;let s=Math.abs(-e*a+t*i+Math.sin(o*.03)*6);if(s>9)continue;let c=.35+yd(rf,e*.08,t*.08,2)*.12,l=Sd(9,4,s)*Sd(300,330,o)*Sd(900,820,o);r<c&&(r=xd(r,c,l))}return r}var Cf=null,wf=null;function Tf(){Cf=new Float32Array(lf*lf);for(let e=0;e<lf;e++){let t=-450+e*cf;for(let n=0;n<lf;n++){let r=-450+n*cf;Cf[e*lf+n]=Sf(r,t)}}wf=new Float32Array(lf*lf*3);for(let e=0;e<lf;e++)for(let t=0;t<lf;t++){let n=Cf[e*lf+Math.max(0,t-1)],r=Cf[e*lf+Math.min(360,t+1)],i=Cf[Math.max(0,e-1)*lf+t],a=Cf[Math.min(360,e+1)*lf+t],o=n-r,s=2*cf,c=i-a,l=Math.hypot(o,s,c);wf[(e*lf+t)*3]=o/l,wf[(e*lf+t)*3+1]=s/l,wf[(e*lf+t)*3+2]=c/l}return{heights:Cf,normals:wf,N:lf,CELL:cf}}var Ef=new Map,Df=0;function Of(e,t){let n=e*65536+t,r=Ef.get(n);if(r)return r.t=Df,r.h;let i=new Float32Array(900);for(let n=0;n<30;n++){let r=-450+(t*30+n)*cf;for(let t=0;t<30;t++)i[n*30+t]=Sf(-450+(e*30+t)*cf,r)}if(Ef.set(n,{h:i,t:Df}),Ef.size>2e3)for(let[e,t]of Ef)Df-t.t>600&&Ef.delete(e);return i}function kf(){Df++}function Af(e,t){if(e>=0&&t>=0&&e<=360&&t<=360)return Cf[t*lf+e];let n=Math.floor(e/30),r=Math.floor(t/30);return Of(n,r)[(t-r*30)*30+(e-n*30)]}function jf(e,t){return Af(e,t)}function Mf(e,t,n=[0,1,0]){if(e>0&&t>0&&e<360&&t<360){let r=(t*lf+e)*3;return n[0]=wf[r],n[1]=wf[r+1],n[2]=wf[r+2],n}let r=Af(e-1,t)-Af(e+1,t),i=2*cf,a=Af(e,t-1)-Af(e,t+1),o=Math.hypot(r,i,a);return n[0]=r/o,n[1]=i/o,n[2]=a/o,n}function Nf(e,t,n){let r=(e+450)/cf,i=(t+450)/cf,a=Math.floor(r),o=Math.floor(i);if(n.fx=r-a,n.fz=i-o,a>=0&&o>=0&&a<360&&o<360){let e=o*lf+a;n.h00=Cf[e],n.h10=Cf[e+1],n.h01=Cf[e+lf],n.h11=Cf[e+lf+1]}else n.h00=Af(a,o),n.h10=Af(a+1,o),n.h01=Af(a,o+1),n.h11=Af(a+1,o+1);return n}var Pf={fx:0,fz:0,h00:0,h10:0,h01:0,h11:0};function X(e,t){let{fx:n,fz:r,h00:i,h10:a,h01:o,h11:s}=Nf(e,t,Pf);return r>n?i+(s-o)*n+(o-i)*r:i+(a-i)*n+(s-a)*r}function Ff(e,t,n={x:0,y:1,z:0}){let{fx:r,fz:i,h00:a,h10:o,h01:s,h11:c}=Nf(e,t,Pf),l,u;i>r?(l=(c-s)/cf,u=(s-a)/cf):(l=(o-a)/cf,u=(c-o)/cf);let d=Math.hypot(l,1,u);return n.x=-l/d,n.y=1/d,n.z=-u/d,n}function If(e,t){return Math.hypot(e-Bd.x,t-Bd.z)<Bd.r+8?Bd.level:0}function Lf(e,t){if(gf(e,t)>.5)return X(e,t)<-.6?`farsea`:`far:`+vf(e,t);let n=ff(e,t),r=`meadow`,i=-1;for(let e of uf)n[e]>i&&(i=n[e],r=e);return pf(e,t)<.5&&r!==`coast`&&X(e,t)<0?`sea`:r}function Rf(e,t,n,r=cf){let i={x:e,z:t,y:-1/0};for(let a=t-n;a<=t+n;a+=r)for(let o=e-n;o<=e+n;o+=r){if(Math.hypot(o-e,a-t)>n)continue;let r=X(o,a);r>i.y&&(i={x:o,z:a,y:r})}return i}function zf(e,t,n,r=.5){let i=null,a=-1,o={x:0,y:1,z:0};for(let s=t-n;s<=t+n;s+=cf)for(let c=e-n;c<=e+n;c+=cf){let l=X(c,s);if(l<r)continue;Ff(c,s,o);let u=o.y-Math.hypot(c-e,s-t)/(n*20);u>a&&(a=u,i={x:c,z:s,y:l})}return i||{x:e,z:t,y:X(e,t)}}function Bf(e,t=!1){let n=e[0].index!==null,r=new Set(Object.keys(e[0].attributes)),i=new Set(Object.keys(e[0].morphAttributes)),a={},o={},s=e[0].morphTargetsRelative,c=new Dr,l=0;for(let u=0;u<e.length;++u){let d=e[u],f=0;if(n!==(d.index!==null))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.`),null;for(let e in d.attributes){if(!r.has(e))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. All geometries must have compatible attributes; make sure "`+e+`" attribute exists among all geometries, or in none of them.`),null;a[e]===void 0&&(a[e]=[]),a[e].push(d.attributes[e]),f++}if(f!==r.size)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. Make sure all geometries have the same number of attributes.`),null;if(s!==d.morphTargetsRelative)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. .morphTargetsRelative must be consistent throughout all geometries.`),null;for(let e in d.morphAttributes){if(!i.has(e))return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`.  .morphAttributes must be consistent throughout all geometries.`),null;o[e]===void 0&&(o[e]=[]),o[e].push(d.morphAttributes[e])}if(t){let e;if(n)e=d.index.count;else if(d.attributes.position!==void 0)e=d.attributes.position.count;else return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index `+u+`. The geometry must have either an index or a position attribute`),null;c.addGroup(l,e,u),l+=e}}if(n){let t=0,n=[];for(let r=0;r<e.length;++r){let i=e[r].index;for(let e=0;e<i.count;++e)n.push(i.getX(e)+t);t+=e[r].attributes.position.count}c.setIndex(n)}for(let e in a){let t=Vf(a[e]);if(!t)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` attribute.`),null;c.setAttribute(e,t)}for(let e in o){let t=o[e][0].length;if(t!==0){c.morphAttributes=c.morphAttributes||{},c.morphAttributes[e]=[];for(let n=0;n<t;++n){let t=[];for(let r=0;r<o[e].length;++r)t.push(o[e][r][n]);let r=Vf(t);if(!r)return console.error(`THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the `+e+` morphAttribute.`),null;c.morphAttributes[e].push(r)}}}return c}function Vf(e){let t,n,r,i=-1,a=0;for(let o=0;o<e.length;++o){let s=e[o];if(t===void 0&&(t=s.array.constructor),t!==s.array.constructor)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.`),null;if(n===void 0&&(n=s.itemSize),n!==s.itemSize)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.`),null;if(r===void 0&&(r=s.normalized),r!==s.normalized)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.`),null;if(i===-1&&(i=s.gpuType),i!==s.gpuType)return console.error(`THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.`),null;a+=s.count*n}let o=new t(a),s=new fr(o,n,r),c=0;for(let t=0;t<e.length;++t){let r=e[t];if(r.isInterleavedBufferAttribute){let e=c/n;for(let t=0,i=r.count;t<i;t++)for(let i=0;i<n;i++){let n=r.getComponent(t,i);s.setComponent(t+e,i,n)}}else o.set(r.array,c);c+=r.count*n}return i!==void 0&&(s.gpuType=i),s}var Hf=new Xt,Uf=new Dt,Wf=new sn,Gf=new U,Kf=new U;function qf(e){let t=e.parameters||{};return e.type===`CylinderGeometry`||e.type===`ConeGeometry`?t.radialSegments<7:e.type===`SphereGeometry`&&t.widthSegments<7}function Z(e,t,n={}){let r=n.flat??qf(e),i=e.index?e.toNonIndexed():e;e!==i&&e.dispose(),i.attributes.uv&&i.deleteAttribute(`uv`),i.attributes.uv1&&i.deleteAttribute(`uv1`),Wf.set(n.rx||0,n.ry||0,n.rz||0,`YXZ`),Uf.setFromEuler(Wf);let a=n.s??1;Gf.set(n.sx??a,n.sy??a,n.sz??a),Kf.set(n.x||0,n.y||0,n.z||0),Hf.compose(Kf,Uf,Gf),n.jitter&&Yf(i,n.jitter,n.seed||1),i.applyMatrix4(Hf),n.round?Jf(i,Kf):(r||n.jitter||!i.attributes.normal)&&i.computeVertexNormals();let o=new K(t),s=i.attributes.position.count,c=new Float32Array(s*3);for(let e=0;e<s;e++)c[e*3]=o.r,c[e*3+1]=o.g,c[e*3+2]=o.b;return i.setAttribute(`color`,new fr(c,3)),i}function Jf(e,t){let n=e.attributes.position,r=new Float32Array(n.count*3);for(let e=0;e<n.count;e++){let i=n.getX(e)-t.x,a=(n.getY(e)-t.y)*.8+.25,o=n.getZ(e)-t.z,s=Math.hypot(i,a,o)||1;r[e*3]=i/s,r[e*3+1]=a/s,r[e*3+2]=o/s}e.setAttribute(`normal`,new fr(r,3))}function Yf(e,t,n){let r=e.attributes.position;for(let e=0;e<r.count;e++){let i=r.getX(e),a=r.getY(e),o=r.getZ(e),s=Math.round(i*1e3),c=Math.round(a*1e3),l=Math.round(o*1e3);r.setXYZ(e,i+(_d(s,c+l*3,n)-.5)*t,a+(_d(c,l+s*5,n+1)-.5)*t,o+(_d(l,s+c*7,n+2)-.5)*t)}}function Q(e){let t=Bf(e,!1);return e.forEach(e=>e.dispose()),t.computeBoundingSphere(),t.computeBoundingBox(),t}function Xf(e,t=16774364,n=.35,r=3){let i=e.onBeforeCompile;return e.onBeforeCompile=(a,o)=>{i?.call(e,a,o),a.fragmentShader=a.fragmentShader.replace(`#include <emissivemap_fragment>`,`#include <emissivemap_fragment>
      { float rim = pow(1.0 - abs(dot(normalize(vViewPosition), normal)), ${r.toFixed(2)});
        totalEmissiveRadiance += vec3(${new K(t).toArray().map(e=>e.toFixed(3)).join(`,`)}) * rim * ${n.toFixed(3)} * diffuseColor.rgb; }`)},e.userData.rim=`${t}/${n}/${r}`,e.customProgramCacheKey=()=>JSON.stringify(e.userData),e}var Zf={uTime:{value:0},uDir:{value:new H(.8,.6)},uStrength:{value:1}};function Qf(e,t=`instanced`,n=1){let r=e.onBeforeCompile;return e.userData.wind=t+n,e.onBeforeCompile=(i,a)=>{r?.call(e,i,a),i.uniforms.uWindTime=Zf.uTime,i.uniforms.uWindDir=Zf.uDir,i.uniforms.uWindStr=Zf.uStrength;let o=`uniform float uWindTime; uniform vec2 uWindDir; uniform float uWindStr;${t===`attr`?` attribute float aH;`:``}`,s=t===`attr`?`aH`:`max(0.0, position.y - 0.25)`,c=t===`attr`?`position.xz`:`(instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xz`;i.vertexShader=i.vertexShader.replace(`#include <common>`,`#include <common>
`+o).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        { float hh = ${s}; vec2 bp = ${c};
          float ph = dot(bp, vec2(0.11, 0.07)) + uWindTime * 1.7;
          float gust = 0.6 + 0.4 * sin(dot(bp, uWindDir) * 0.02 - uWindTime * 0.9);
          float sway = (sin(ph) * 0.6 + sin(ph * 2.3 + 1.7) * 0.25) * gust * uWindStr * ${(.035*n).toFixed(4)} * hh * hh;
          transformed.x += uWindDir.x * sway; transformed.z += uWindDir.y * sway;
          transformed.y -= abs(sway) * 0.15; }`)},e.customProgramCacheKey=()=>JSON.stringify(e.userData),e}var $f=Xf(new Wo({vertexColors:!0,roughness:.82,metalness:0}),16774364,.18),ep=(e,t=1.6)=>new Wo({vertexColors:!0,emissive:e,emissiveIntensity:t,roughness:.5}),tp=Qf(Xf(new Wo({vertexColors:!0,roughness:.9,metalness:0}),15794128,.22),`instanced`),np=(e,t,n,r=6)=>new oa(e,t,n,r),rp=(e,t,n=6)=>new sa(e,t,n),ip=(e,t=0)=>new Oo(e,t),ap=e=>new la(e,0),op=(e,t,n)=>new ra(e,t,n),sp=(e,t=8,n=6)=>new Mo(e,t,n),cp={Cyl:np,Cone:rp,Ico:ip,Dode:ap,Box:op,Sph:sp};function lp(e=1,t=7122506){let n=gd(e),r=[Z(np(.22,.36,2.6,6),8017206,{y:1.3})],i=3+Math.floor(n()*2);for(let a=0;a<i;a++){let o=a/i*Math.PI*2+n(),s=new K(t).offsetHSL((n()-.5)*.03,0,(n()-.5)*.08);r.push(Z(ip(1.3+n()*.5,1),s,{x:Math.cos(o)*.9,y:3.2+n()*.8,z:Math.sin(o)*.9,jitter:.3,seed:e+a,round:!0}))}return r.push(Z(ip(1.5,1),new K(t).offsetHSL(0,.02,.05),{y:4.3,jitter:.28,seed:e+9,round:!0})),Q(r)}function up(e=1,t=4160842,n=!1,r=1){let i=gd(e),a=[Z(np(.18,.3,1.6*r,5),7031344,{y:.8*r})],o=3+ +(r>1.2);for(let e=0;e<o;e++){let o=(1.9-e*.4)*(.9+i()*.2),s=(1.4+e*1.25)*r;a.push(Z(rp(o,2.2*r,9),new K(t).offsetHSL(0,0,e*.025),{y:s,ry:i()*3,round:!0})),n&&a.push(Z(rp(o*.55,.9*r,7),15922938,{y:s+.75*r,ry:i()*3}))}return Q(a)}function dp(e=1){let t=gd(e),n=[],r=0,i=0,a=.12+t()*.12;for(let e=0;e<6;e++)n.push(Z(np(.2-e*.015,.24-e*.015,.95,6),e%2?10122832:9070404,{x:r,y:i+.45,rz:-a*e*.4})),r+=Math.sin(a*e*.4)*.95,i+=.92;for(let e=0;e<7;e++){let t=e/7*Math.PI*2;n.push(Z(op(.5,.08,2.8),e%2?5216830:6073159,{x:r+Math.cos(t)*1.2,y:i-.25,z:Math.sin(t)*1.2,ry:-t+Math.PI/2,rx:.45}))}return n.push(Z(ip(.22),7031338,{x:r+.2,y:i-.3})),n.push(Z(ip(.22),7031338,{x:r-.15,y:i-.35,z:.2})),Q(n)}function fp(e=1){let t=gd(e),n=2+t()*1.5,r=[Z(np(.35,.4,n,7),6003542,{y:n/2}),Z(sp(.35,7,4),6003542,{y:n})],i=1+Math.floor(t()*2);for(let e=0;e<i;e++){let n=e?-1:1,i=.8+t()*.8;r.push(Z(np(.22,.22,.7,6),6003542,{x:n*.55,y:i,rz:Math.PI/2})),r.push(Z(np(.22,.22,1,6),6003542,{x:n*.85,y:i+.45})),r.push(Z(sp(.22,6,4),6003542,{x:n*.85,y:i+.95}))}return r.push(Z(ip(.14),15756443,{y:n+.32})),Q(r)}function pp(e=1){let t=gd(e),n=[Z(np(.12,.25,2.8,5),9071180,{y:1.4,rz:(t()-.5)*.2})];for(let e=0;e<3;e++){let r=t()*6.28;n.push(Z(np(.05,.1,1.3,4),9071180,{x:Math.cos(r)*.4,y:2+e*.3,z:Math.sin(r)*.4,rx:Math.sin(r)*.8,rz:-Math.cos(r)*.8}))}return Q(n)}function mp(e=1,t=6200901,n=!1){let r=gd(e),i=[];for(let n=0;n<3;n++)i.push(Z(ip(.6+r()*.3,1),new K(t).offsetHSL(0,0,(r()-.5)*.08),{x:(r()-.5)*.8,y:.45,z:(r()-.5)*.8,jitter:.18,seed:e+n,round:!0}));if(n)for(let e=0;e<5;e++)i.push(Z(ip(.09),14169162,{x:(r()-.5)*1.2,y:.6+r()*.4,z:(r()-.5)*1.2}));return Q(i)}function hp(e=1,t=10130830,n=1){return Q([Z(ap(1),t,{sy:.7*n,jitter:.45,seed:e})])}function gp(e=8372047){let t=[];for(let n=0;n<4;n++){let r=n/4*Math.PI*2;t.push(Z(rp(.07,.6,3),new K(e).offsetHSL(0,0,n%2*.05),{x:Math.cos(r)*.12,y:.28,z:Math.sin(r)*.12,rx:Math.sin(r)*.25,rz:-Math.cos(r)*.25}))}return Q(t)}function _p(e=16242506){let t=[];for(let n=0;n<3;n++){let r=(n-1)*.25,i=n%2*.2;t.push(Z(np(.02,.02,.45,3),5147194,{x:r,y:.22,z:i})),t.push(Z(ip(.11),e,{x:r,y:.48,z:i,sy:.6})),t.push(Z(ip(.05),16777215,{x:r,y:.52,z:i}))}return Q(t)}function vp(){return Q([Z(np(.04,.05,1.6,4),5147194,{y:.8}),Z(np(.32,.32,.06,10),16106776,{y:1.65,rx:1.2}),Z(np(.15,.15,.08,8),7028509,{y:1.67,z:.03,rx:1.2}),Z(op(.4,.04,.15),5147194,{y:.8,x:.2,rz:.3})])}function yp(e=14172987){return Q([Z(np(.08,.1,.35,6),15919317,{y:.17}),Z(sp(.24,7,4),e,{y:.36,sy:.6}),Z(ip(.04),16777215,{y:.47,x:.08}),Z(ip(.04),16777215,{y:.45,x:-.1,z:.05})])}function bp(){let e=[];for(let t=0;t<5;t++){let n=Math.sin(t*2.4)*.3,r=Math.cos(t*1.7)*.3;e.push(Z(np(.025,.03,1.4,3),8034890,{x:n,y:.7,z:r,rz:(t-2)*.06})),t%2==0&&e.push(Z(np(.06,.06,.3,5),7031338,{x:n,y:1.35,z:r}))}return Q(e)}function xp(e=1,t=11832575){let n=gd(e),r=[];for(let e=0;e<4;e++){let e=.8+n()*1.4;r.push(Z(rp(.28,e,5),t,{x:(n()-.5)*.8,y:e/2,z:(n()-.5)*.8,rx:(n()-.5)*.6,rz:(n()-.5)*.6}))}return Q(r)}function Sp(e=1){let t=gd(e),n=[16744319,16755038,13855702],r=[];for(let e=0;e<4;e++)r.push(Z(np(.06,.12,.9,5),n[e%3],{x:(t()-.5)*.6,y:.4,z:(t()-.5)*.6,rx:(t()-.5)*.7,rz:(t()-.5)*.7}));return Q(r)}var Cp=30,wp=Cp*cf,Tp=vd(777),Ep=e=>new K(e),Dp={meadow:Ep(9226586),forest:Ep(5147203),canyon:Ep(13605470),coast:Ep(12046195),lake:Ep(6797182),mountain:Ep(8822890)},Op={meadow:Ep(8963930),forest:Ep(4620098),canyon:Ep(13209429),snow:Ep(10991517),crystal:Ep(8176804)},kp=Ep(15325350),Ap=Ep(12101244),jp=Ep(6130324),Mp=Ep(9407365),Np=Ep(11821371),Pp=Ep(15988731),Fp=Ep(11965542),Ip=Ep(15261429),Lp=new K,Rp=new K,zp=[0,1,0],Bp={};function Vp(e,t,n,r,i,a=kp){let o=If(e,t);i.lerp(a,Sd(o+2.6,o+1.2,n)*Sd(.6,.8,r)),n<o&&(Lp.copy(Ap).lerp(jp,Sd(o-1,o-9,n)),i.lerp(Lp,Sd(o,o-1.5,n)))}function Hp(e,t,n,r,i){let a=ff(e,t);i.setRGB(0,0,0);for(let e in Dp)i.r+=Dp[e].r*a[e],i.g+=Dp[e].g*a[e],i.b+=Dp[e].b*a[e];let o=Tp(e*.03,t*.03)*.07+Tp(e*.2,t*.2)*.03;i.offsetHSL(0,0,o);let s=Math.hypot(e-zd.x,t-zd.z);return s<zd.r+6&&i.lerp(Fp,Sd(zd.r+6,zd.r-10,s)*(.35+Tp(e*.08,t*.08)*.3)),Lp.copy(Mp).lerp(Np,Math.min(1,a.canyon*1.4)),i.lerp(Lp,Sd(.8,.62,r)),i.lerp(Pp,Sd(47,55,n)*Sd(.5,.7,r)),Vp(e,t,n,r,i),i}function Up(e,t,n,r,i){let a=_f(e,t,Bp);i.setRGB(0,0,0);for(let e in Op)i.r+=Op[e].r*a[e],i.g+=Op[e].g*a[e],i.b+=Op[e].b*a[e];return i.offsetHSL(0,0,Tp(e*.03,t*.03)*.07+Tp(e*.2,t*.2)*.03),Lp.copy(Mp).lerp(Np,Math.min(1,a.canyon*1.4)),i.lerp(Lp,Sd(.8,.62,r)),i.lerp(Pp,a.snow*Sd(6,14,n)*Sd(.55,.75,r)),Rp.copy(kp).lerp(Ip,a.crystal),Vp(e,t,n,r,i,Rp),i}function Wp(e,t,n,r,i){let a=gf(e,t);if(a<=0)return Hp(e,t,n,r,i);if(a>=1)return Up(e,t,n,r,i);Hp(e,t,n,r,i);let o=i.r,s=i.g,c=i.b;return Up(e,t,n,r,i),i.setRGB(o+(i.r-o)*a,s+(i.g-s)*a,c+(i.b-c)*a),i}var Gp=`
  float tHash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  float tNoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(tHash(i), tHash(i + vec2(1,0)), f.x), mix(tHash(i + vec2(0,1)), tHash(i + vec2(1,1)), f.x), f.y); }
`;function Kp(){let e=new Wo({vertexColors:!0,roughness:.93,metalness:0});return e.onBeforeCompile=e=>{e.uniforms.uTime=Zf.uTime,e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
varying vec3 vWPos; varying vec3 vWN;`).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz; vWN = normalize(mat3(modelMatrix) * objectNormal);`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
varying vec3 vWPos; varying vec3 vWN; uniform float uTime;
`+Gp).replace(`#include <color_fragment>`,`#include <color_fragment>
        {
          vec2 p = vWPos.xz;
          float n1 = tNoise(p * 0.18), n2 = tNoise(p * 0.9), n3 = tNoise(p * 4.3);
          float slope = 1.0 - smoothstep(0.62, 0.86, vWN.y);
          // grass mottling and fine speckle
          vec3 c = diffuseColor.rgb;
          c *= 0.9 + n1 * 0.16 + (n2 - 0.5) * 0.08 + (n3 - 0.5) * 0.06;
          // dry patches / lush patches
          c = mix(c, c * vec3(1.08, 1.02, 0.86), smoothstep(0.62, 0.8, n1) * (1.0 - slope) * 0.6);
          // rock strata on slopes
          float strata = sin(vWPos.y * 2.6 + n1 * 3.0 + n2 * 1.2) * 0.5 + 0.5;
          c *= mix(1.0, 0.82 + strata * 0.3, slope);
          // underwater caustics in the sea shallows
          float depth = -vWPos.y;
          if (depth > 0.05 && depth < 9.0 && vWPos.y < 0.0) {
            vec2 q = p * 0.55;
            float ca = sin(q.x * 2.1 + uTime * 1.3 + sin(q.y * 1.7 + uTime)) * sin(q.y * 2.3 - uTime * 1.1 + sin(q.x * 1.3 - uTime * 0.7));
            ca = pow(abs(ca), 3.0);
            c += vec3(0.55, 0.75, 0.8) * ca * 0.45 * smoothstep(9.0, 0.5, depth);
          }
          diffuseColor.rgb = c;
        }`)},e.customProgramCacheKey=()=>`terrain-v2`,e}var qp=Kp();function Jp(e,t,n=1){let r=Cp/n,i=r+1,a=i*i+i*4,o=new Float32Array(a*3),s=new Float32Array(a*3),c=new Float32Array(a*3),l=new K,u=(e,t,n,r)=>{let i=-450+t*cf,a=-450+n*cf,u=jf(t,n);Mf(t,n,zp),o[e*3]=i,o[e*3+1]=u-r,o[e*3+2]=a,c[e*3]=zp[0],c[e*3+1]=zp[1],c[e*3+2]=zp[2],Wp(i,a,u,zp[1],l),s[e*3]=l.r,s[e*3+1]=l.g,s[e*3+2]=l.b};for(let r=0;r<i;r++)for(let a=0;a<i;a++)u(r*i+a,e*Cp+a*n,t*Cp+r*n,0);let d=[];for(let e=0;e<r;e++)for(let t=0;t<r;t++){let n=e*i+t,r=n+1,a=n+i,o=a+1;d.push(n,a,o,n,o,r)}let f=i*i,p=[e=>[e,0],e=>[r,e],e=>[r-e,r],e=>[0,r-e]];for(let a of p){let o=f;for(let r=0;r<i;r++){let[i,o]=a(r);u(f++,e*Cp+i*n,t*Cp+o*n,3)}for(let e=0;e<r;e++){let[t,n]=a(e),[r,s]=a(e+1),c=n*i+t,l=s*i+r,u=o+e,f=o+e+1;d.push(c,f,u,c,l,f)}}let m=new Dr;m.setAttribute(`position`,new fr(o,3)),m.setAttribute(`normal`,new fr(c,3)),m.setAttribute(`color`,new fr(s,3)),m.setIndex(d),m.computeBoundingSphere();let h=new q(m,qp);return h.receiveShadow=!0,h.castShadow=!0,h}function Yp(){let e=new G,t=360/Cp;for(let n=0;n<t;n++)for(let r=0;r<t;r++)e.add(Jp(r,n,1));return e}var Xp={uTime:{value:0},uSunDir:{value:new U(0,1,0)},uSunCol:{value:new K(1,1,1)},uSunI:{value:1},uSkyTop:{value:new K(5217256)},uSkyHor:{value:new K(12575743)},uAmb:{value:.7},uFogCol:{value:new K},uFogNear:{value:60},uFogFar:{value:520},uNight:{value:0}},Zp=`
  uniform float uTime; uniform float uLevel;
  attribute float aDepth;
  varying vec3 vW; varying float vDepth;
  float wave(vec2 p){ return sin(p.x * 0.15 + uTime * 1.3) * 0.16 + cos(p.y * 0.12 + uTime * 1.1) * 0.16 + sin((p.x + p.y) * 0.31 - uTime * 1.9) * 0.05; }
  void main(){
    vec4 w = modelMatrix * vec4(position, 1.0);
    float calm = smoothstep(0.0, 3.0, aDepth);
    w.y += wave(w.xz) * (0.35 + 0.65 * calm);
    vW = w.xyz; vDepth = aDepth;
    gl_Position = projectionMatrix * viewMatrix * w;
  }`,Qp=`
  uniform float uTime; uniform vec3 uSunDir; uniform vec3 uSunCol; uniform float uSunI; uniform vec3 uSkyTop; uniform vec3 uSkyHor;
  uniform float uAmb; uniform vec3 uFogCol; uniform float uFogNear; uniform float uFogFar; uniform float uNight;
  uniform vec3 uShallow; uniform vec3 uDeep; uniform vec3 uHole;
  varying vec3 vW; varying float vDepth;
  float h21(vec2 p){ p = fract(p * vec2(234.34, 435.345)); p += dot(p, p + 34.23); return fract(p.x * p.y); }
  float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
    return mix(mix(h21(i), h21(i+vec2(1,0)), f.x), mix(h21(i+vec2(0,1)), h21(i+vec2(1,1)), f.x), f.y); }
  float hgt(vec2 p){
    float t = uTime;
  #ifdef LOW
    return vn(p * 0.5 + vec2(t * 0.35, t * 0.2)) * 0.8;
  #else
    return vn(p * 0.35 + vec2(t * 0.35, t * 0.2)) * 0.5 + vn(p * 0.9 - vec2(t * 0.25, -t * 0.4)) * 0.3 + vn(p * 2.3 + vec2(t * 0.6, t * 0.5)) * 0.12;
  #endif
  }
  void main(){
    if (uHole.z > 0.0 && abs(vW.x - uHole.x) < uHole.z && abs(vW.z - uHole.y) < uHole.z) discard;
    vec2 p = vW.xz;
    float e = 0.15;
    float h0 = hgt(p);
    vec3 n = normalize(vec3((h0 - hgt(p + vec2(e, 0.0))) * 2.2, 1.0, (h0 - hgt(p + vec2(0.0, e))) * 2.2));
    vec3 V = normalize(cameraPosition - vW);
    float dist = length(cameraPosition - vW);
    n = normalize(mix(n, vec3(0.0, 1.0, 0.0), smoothstep(60.0, 400.0, dist) * 0.8));
    float fres = 0.03 + 0.97 * pow(1.0 - max(dot(n, V), 0.0), 5.0);
    vec3 R = reflect(-V, n);
    vec3 sky = mix(uSkyHor, uSkyTop, pow(clamp(R.y, 0.0, 1.0), 0.6));
    float depth = max(vDepth, 0.0);
    vec3 body = mix(uShallow, uDeep, smoothstep(0.3, 9.0, depth));
    float ndl = max(dot(n, uSunDir), 0.0);
    body *= uAmb * 0.9 + ndl * uSunI * 0.22;
    // sub-surface glow on wave flanks facing the sun
    body += uShallow * pow(max(dot(V, -uSunDir) * 0.5 + 0.5, 0.0), 4.0) * (h0 - 0.35) * 0.6 * uSunI * 0.2;
    vec3 col = mix(body, sky, fres * 0.85);
    float spec = pow(max(dot(R, uSunDir), 0.0), 380.0) * 2.2 + pow(max(dot(R, uSunDir), 0.0), 40.0) * 0.12;
    col += uSunCol * spec * uSunI * (1.0 - uNight * 0.6);
    // moon glints at night
    col += vec3(0.6, 0.7, 1.0) * pow(max(dot(R, -uSunDir), 0.0), 200.0) * uNight * 2.0;
    // shoreline foam: animated bands that roll in towards the beach
    float shore = smoothstep(0.32, 0.0, depth);
    float bands = smoothstep(0.6, 0.95, sin(depth * 11.0 - uTime * 2.2 + vn(p * 0.6) * 4.0) * 0.5 + 0.5) * smoothstep(0.9, 0.15, depth) * 0.6;
    float foamN = vn(p * 3.0 + uTime * 0.4);
    float foam = clamp(shore * (0.45 + foamN * 0.55) + bands * foamN, 0.0, 1.0) * 0.85;
    // crest foam in open water
    foam += smoothstep(0.78, 0.92, h0) * 0.25 * smoothstep(2.0, 6.0, depth);
    col = mix(col, vec3(0.92, 0.96, 1.0) * min(1.1, uAmb * 0.8 + uSunI * 0.18), clamp(foam, 0.0, 1.0));
    float alpha = mix(0.32, 0.94, smoothstep(0.0, 3.5, depth));
    alpha = max(alpha, fres);
    alpha = max(alpha, foam);
    float fogF = smoothstep(uFogNear, uFogFar, dist);
    col = min(col, vec3(3.0));
    col = mix(col, uFogCol, fogF);
    alpha = mix(alpha, 1.0, fogF);
    gl_FragColor = vec4(col, alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }`;function $p(e,t){return new Ho({uniforms:{...Xp,uShallow:{value:new K(e)},uDeep:{value:new K(t)},uLevel:{value:0},uHole:{value:new U(0,0,0)}},vertexShader:Zp,fragmentShader:Qp,transparent:!0,depthWrite:!0})}function em(e,t){let n=new Ao(e,e,t,t).rotateX(-Math.PI/2);return n.setAttribute(`aDepth`,new fr(new Float32Array(n.attributes.position.count),1)),n}function tm(e,t){let n=e.geometry.attributes.position,r=e.geometry.attributes.aDepth,i=e.position.x,a=e.position.z;for(let e=0;e<n.count;e++)r.array[e]=t-X(n.getX(e)+i,n.getZ(e)+a);r.needsUpdate=!0}function nm(e){let t=new q(em(320,160),$p(4641480,937850));t.position.y=-.05,t.renderOrder=1,t.frustumCulled=!1,e.add(t);let n=new q(em(3600,90),$p(4641480,937850));n.position.y=-.12,n.renderOrder=2,n.frustumCulled=!1,e.add(n);let r=new q(new aa(Bd.r+14,96).rotateX(-Math.PI/2),$p(6283476,1798026));r.geometry.setAttribute(`aDepth`,new fr(new Float32Array(r.geometry.attributes.position.count),1)),r.position.set(Bd.x,Bd.level-.05,Bd.z),r.renderOrder=1,e.add(r),tm(r,Bd.level);let i={x:NaN,z:NaN},a={x:NaN,z:NaN};return{meshes:[t,n,r],setQuality(e){for(let i of[t,n,r])e===`low`?i.material.defines.LOW=1:delete i.material.defines.LOW,i.material.needsUpdate=!0},update(e,r,o,s){if(Xp.uTime.value=e,r){let e=Math.round(r.x/24)*24,o=Math.round(r.z/24)*24;(e!==i.x||o!==i.z)&&(i.x=e,i.z=o,t.position.x=e,t.position.z=o,tm(t,0),n.material.uniforms.uHole.value.set(e,o,158));let s=Math.round(r.x/200)*200,c=Math.round(r.z/200)*200;(s!==a.x||c!==a.z)&&(a.x=s,a.z=c,n.position.x=s,n.position.z=c,tm(n,0))}if(o){let e=o.uniforms;Xp.uSunDir.value.copy(e.sunDir.value),Xp.uSunCol.value.copy(e.sunCol.value),Xp.uSunI.value=o.sunIntensity??1,Xp.uSkyTop.value.copy(e.top.value),Xp.uSkyHor.value.copy(e.hor.value),Xp.uAmb.value=o.hemi.intensity,Xp.uNight.value=o.night}s&&(Xp.uFogCol.value.copy(s.color),Xp.uFogNear.value=s.near,Xp.uFogFar.value=s.far)}}}var rm=[{t:0,top:725040,hor:1844560,fog:1317948,sun:4872858,sunI:0,amb:.32,hemiG:1712176},{t:5,top:1712976,hor:4276335,fog:3093344,sun:8425664,sunI:0,amb:.36,hemiG:2435648},{t:6.5,top:5930948,hor:16757642,fog:15185306,sun:16757370,sunI:1,amb:.5,hemiG:6969928},{t:9,top:5217256,hor:12575743,fog:12573936,sun:16773590,sunI:2.4,amb:.75,hemiG:8030810},{t:16,top:5217256,hor:13166335,fog:13033714,sun:16773328,sunI:2.4,amb:.75,hemiG:8030810},{t:18.3,top:5926840,hor:16751210,fog:14916224,sun:16751194,sunI:1.2,amb:.55,hemiG:6965824},{t:19.6,top:1909848,hor:5917306,fog:3815520,sun:7372992,sunI:0,amb:.38,hemiG:2435648},{t:24,top:725040,hor:1844560,fog:1317948,sun:4872858,sunI:0,amb:.32,hemiG:1712176}],im=e=>new K(e);for(let e of rm)for(let t of[`top`,`hor`,`fog`,`sun`,`hemiG`])e[t]=im(e[t]);function am(e){let t=rm[0],n=rm[1];for(let r=0;r<rm.length-1;r++)if(e>=rm[r].t&&e<=rm[r+1].t){t=rm[r],n=rm[r+1];break}let r=(e-t.t)/Math.max(1e-6,n.t-t.t);return{a:t,b:n,f:r}}var om=class{constructor(e,t){this.scene=e,this.renderer=t,this.uniforms={top:{value:new K},hor:{value:new K},sunDir:{value:new U(0,1,0)},sunCol:{value:new K},night:{value:0},time:{value:0},cover:{value:0}};let n=new Ho({uniforms:this.uniforms,side:1,depthWrite:!1,fog:!1,vertexShader:`varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = modelViewMatrix * vec4(position,1.0); gl_Position = projectionMatrix * p; gl_Position.z = gl_Position.w; }`,fragmentShader:`uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; uniform float night; uniform float time; uniform float cover;
        varying vec3 vDir;
        float h21(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
        float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
          return mix(mix(h21(i), h21(i+vec2(1,0)), f.x), mix(h21(i+vec2(0,1)), h21(i+vec2(1,1)), f.x), f.y); }
        float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++){ s += a * vn(p); p = p * 2.03 + vec2(1.7, 9.2); a *= 0.5; } return s; }
        void main(){
          vec3 d = normalize(vDir);
          float h = clamp(d.y, -0.2, 1.0);
          vec3 c = mix(hor, top, pow(max(h,0.0), 0.55));
          if (h < 0.0) c = hor;
          float s = max(dot(d, sunDir), 0.0);
          float day = 1.0 - night;
          c += sunCol * (pow(s, 900.0) * 6.0 + pow(s, 64.0) * 0.35 + pow(s, 8.0) * 0.18) * day;
          vec3 md = -sunDir;
          float m = max(dot(d, md), 0.0);
          c += vec3(0.85,0.9,1.0) * (smoothstep(0.9993, 0.9996, m) * 1.6 + pow(m, 40.0) * 0.12) * night;
          // Cloud layer: flat plane projection, two drifting fbm layers.
          if (d.y > 0.0) {
            vec2 uv = d.xz / (d.y + 0.12) * 1.6;
            vec2 wind = vec2(time * 0.012, time * 0.006);
            float n = fbm(uv + wind) * 0.75 + fbm(uv * 2.7 - wind * 1.7) * 0.35;
            float cov = mix(0.62, 0.32, cover);
            float dens = smoothstep(cov, cov + 0.28, n);
            float thick = smoothstep(cov, cov + 0.55, n);
            float fade = smoothstep(0.0, 0.18, d.y);
            float toward = pow(s, 6.0);
            vec3 lit = mix(vec3(1.0), sunCol, 0.45) * (0.85 + toward * 0.6);
            vec3 shade = mix(hor, top, 0.35) * 0.75;
            vec3 cc = mix(lit, shade, thick * 0.75);
            cc += sunCol * pow(s, 12.0) * (1.0 - thick) * 1.2 * day;   // silver lining
            cc = mix(cc, vec3(0.13, 0.16, 0.26) + hor * 0.3, night * 0.85);
            cc = mix(cc, vec3(0.55, 0.58, 0.62), cover * 0.55 * day);
            c = mix(c, cc, dens * fade * 0.92);
          }
          gl_FragColor = vec4(c, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`});this.dome=new q(new Mo(900,48,24),n),this.dome.frustumCulled=!1,this.dome.renderOrder=-10,e.add(this.dome);let r=gd(42),i=[];for(let e=0;e<1600;e++){let e=r()*2-1,t=r()*Math.PI*2,n=Math.abs(e)*.95+.05,a=Math.sqrt(1-n*n);i.push(Math.cos(t)*a*850,n*850,Math.sin(t)*a*850)}let a=new Dr;a.setAttribute(`position`,new hr(i,3)),this.starMat=new Gi({color:16777215,size:2.2,sizeAttenuation:!1,transparent:!0,opacity:0,fog:!1,depthWrite:!1}),this.stars=new Xi(a,this.starMat),this.stars.frustumCulled=!1,e.add(this.stars),this.sun=new js(16777215,2),this.sun.castShadow=!0,this.sun.shadow.mapSize.set(4096,4096);let o=this.sun.shadow.camera;o.left=-70,o.right=70,o.top=70,o.bottom=-70,o.near=1,o.far=400,this.sun.shadow.bias=-4e-4,this.sun.shadow.normalBias=.35,this.sun.shadow.radius=3,this.sun.shadow.blurSamples=12,e.add(this.sun),e.add(this.sun.target),this.hemi=new ms(12573951,8030810,.7),e.add(this.hemi),e.fog=new Mn(12573936,60,520),this.fogNear=60,this.fogFar=520,this.night=0,this.rain=0,this.rainTarget=0,this.extraFog=0,this._buildRain()}_buildRain(){let e=2500,t=new Float32Array(e*6);this.rainSeeds=new Float32Array(e*3);let n=gd(7);for(let t=0;t<e;t++)this.rainSeeds[t*3]=n()*60-30,this.rainSeeds[t*3+1]=n()*30,this.rainSeeds[t*3+2]=n()*60-30;let r=new Dr;r.setAttribute(`position`,new fr(t,3)),this.rainLines=new Wi(r,new Mi({color:11191517,transparent:!0,opacity:0,depthWrite:!1})),this.rainLines.frustumCulled=!1,this.scene.add(this.rainLines)}update(e,t,n,r,i){let{a,b:o,f:s}=am(t),c=this.uniforms;c.top.value.copy(a.top).lerp(o.top,s),c.hor.value.copy(a.hor).lerp(o.hor,s);let l=a.fog.clone().lerp(o.fog,s),u=a.sun.clone().lerp(o.sun,s),d=xd(a.sunI,o.sunI,s),f=xd(a.amb,o.amb,s),p=(t-6)/12*Math.PI,m=new U(Math.cos(p),Math.sin(p),-.35).normalize();this.night=Sd(18.8,20,t)+Sd(6,5,t),this.night=Math.min(1,this.night),c.sunDir.value.copy(m),c.sunCol.value.copy(u),c.night.value=this.night,this.rain+=(this.rainTarget-this.rain)*Math.min(1,e*.3);let h=new K(9082531);c.top.value.lerp(h,this.rain*.6),c.hor.value.lerp(h,this.rain*.5),l.lerp(h.clone().multiplyScalar(xd(1,.35,this.night)),this.rain*.6),d*=1-this.rain*.65;let g=this.night>.5?m.clone().negate():m.clone();g.y<.15&&(g.y=.15),g.normalize();let _=this.night*.55;this.sun.intensity=Math.max(d,_),this.sunIntensity=d,c.time.value=i,c.cover.value=this.rain,this.sun.color.copy(this.night>.5?new K(10466559):u),this.sun.position.copy(n).addScaledVector(g,200),this.sun.target.position.copy(n),this.hemi.intensity=f,this.hemi.color.copy(c.top.value).lerp(new K(16777215),.35),this.hemi.groundColor.copy(a.hemiG).lerp(o.hemiG,s),this.scene.fog.color.copy(l),c.hor.value.lerp(l,.85);let v=xd(this.fogNear,10,this.extraFog)*(1-this.rain*.4),y=xd(this.fogFar,70,this.extraFog)*(1-this.rain*.45);this.scene.fog.near=v,this.scene.fog.far=y,this.dome.position.copy(r),this.stars.position.copy(r),this.stars.rotation.y=i*.005,this.starMat.opacity=this.night*(1-this.rain);let b=this.rain;if(this.rainLines.material.opacity=b*.55,this.rainLines.visible=b>.02,this.rainLines.visible){let e=this.rainLines.geometry.attributes.position.array,t=this.rainSeeds,n=t.length/3;for(let a=0;a<n;a++){let n=((t[a*3+1]-i*28)%30+30)%30,o=r.x+t[a*3],s=r.z+t[a*3+2],c=r.y-10+n;e[a*6]=o,e[a*6+1]=c,e[a*6+2]=s,e[a*6+3]=o+.08,e[a*6+4]=c+.9,e[a*6+5]=s}this.rainLines.geometry.attributes.position.needsUpdate=!0}}},sm=12,cm=class e{constructor(){this.grid=new Map,this.dynamic=new Set,this._seen=new Set,this._out=[]}_key(e,t){return e*100003+t}_insert(e){let t=e.bound,n=Math.floor((e.x-t)/sm),r=Math.floor((e.x+t)/sm),i=Math.floor((e.z-t)/sm),a=Math.floor((e.z+t)/sm);for(let t=n;t<=r;t++)for(let n=i;n<=a;n++){let r=this._key(t,n),i=this.grid.get(r);i||this.grid.set(r,i=[]),i.push(e)}}addCylinder(e,t,n,r,i,a={}){let o={type:`cyl`,x:e,z:t,r:n,y0:r,y1:i,bound:n,walkable:!!a.walkable,tag:a.tag,enabled:!0};return a.dynamic?this.dynamic.add(o):this._insert(o),o}addBox(e,t,n,r,i,a,o=0,s={}){let c={type:`box`,x:e,z:t,hx:n,hz:r,y0:i,y1:a,yaw:o,cos:Math.cos(o),sin:Math.sin(o),bound:Math.hypot(n,r),walkable:s.walkable!==!1,tag:s.tag,enabled:!0};return s.dynamic?this.dynamic.add(c):this._insert(c),c}setYaw(e,t){e.yaw=t,e.cos=Math.cos(t),e.sin=Math.sin(t)}remove(e){e.enabled=!1,this.dynamic.delete(e)}removeStatic(e){e.enabled=!1;let t=e.bound,n=Math.floor((e.x-t)/sm),r=Math.floor((e.x+t)/sm),i=Math.floor((e.z-t)/sm),a=Math.floor((e.z+t)/sm);for(let t=n;t<=r;t++)for(let n=i;n<=a;n++){let r=this._key(t,n),i=this.grid.get(r);if(!i)continue;let a=i.indexOf(e);a>=0&&i.splice(a,1),i.length||this.grid.delete(r)}}query(e,t,n){let r=this._out;r.length=0;let i=this._seen;i.clear();let a=Math.floor((e-n)/sm),o=Math.floor((e+n)/sm),s=Math.floor((t-n)/sm),c=Math.floor((t+n)/sm);for(let l=a;l<=o;l++)for(let a=s;a<=c;a++){let o=this.grid.get(this._key(l,a));if(o)for(let a of o)a.enabled&&!i.has(a)&&(i.add(a),Math.abs(a.x-e)<a.bound+n&&Math.abs(a.z-t)<a.bound+n&&r.push(a))}for(let i of this.dynamic)i.enabled&&Math.abs(i.x-e)<i.bound+n&&Math.abs(i.z-t)<i.bound+n&&r.push(i);return r}static local(e,t,n){let r=t-e.x,i=n-e.z;return[r*e.cos-i*e.sin,r*e.sin+i*e.cos]}supportHeight(t,n,r,i){let a=-1/0;for(let o of this.query(t,n,r)){if(!o.walkable||o.y1>i)continue;let s;if(o.type===`cyl`)s=Math.hypot(t-o.x,n-o.z)<o.r+r*.5;else{let[i,a]=e.local(o,t,n);s=Math.abs(i)<o.hx+r*.5&&Math.abs(a)<o.hz+r*.5}s&&o.y1>a&&(a=o.y1)}return a}resolve(t,n,r){let i=!1;for(let a of this.query(t.x,t.z,n))if(!(t.y>=a.y1-.05||t.y+r<=a.y0)){if(a.type===`cyl`){let e=t.x-a.x,r=t.z-a.z,o=Math.hypot(e,r),s=a.r+n;if(o<s){let n=o>1e-5?e/o:1,c=o>1e-5?r/o:0;t.x=a.x+n*s,t.z=a.z+c*s,i=!0}}else{let[r,o]=e.local(a,t.x,t.z),s=Math.max(-a.hx,Math.min(a.hx,r)),c=Math.max(-a.hz,Math.min(a.hz,o)),l=r-s,u=o-c,d=Math.hypot(l,u),f,p;if(d<1e-5){let e=a.hx-Math.abs(r),t=a.hz-Math.abs(o);e<t?(f=Math.sign(r)||1,p=0,d=-e):(f=0,p=Math.sign(o)||1,d=-t)}else f=l/d,p=u/d;if(d<n){let e=n-d,s=r+f*e,c=o+p*e;t.x=a.x+s*a.cos+c*a.sin,t.z=a.z-s*a.sin+c*a.cos,i=!0}}}return i}},{Cyl:lm,Cone:um,Ico:dm,Dode:fm,Box:pm,Sph:mm}=cp;function hm(e,t,n=2){let r=X(e,t);for(let i=0;i<6;i++)r=Math.min(r,X(e+Math.cos(i)*n,t+Math.sin(i)*n));return r}function gm(e,t,n,r,i=0){return e.position.set(t,n,r),e.rotation.y=i,e.castShadow=!0,e.receiveShadow=!0,e}var _m=class{constructor(e,t,n){this.scene=e,this.col=t,this.excl=n,this.animated=[]}add(e,t,n,r,i=0,a=$f){let o=gm(new q(e,a),t,n,r,i);return this.scene.add(o),o}exclude(e,t,n){this.excl.push({x:e,z:t,r:n})}house(e,t,n,r={}){let i=r.w||6,a=r.d||5,o=r.wallH||3.2,s=r.wall||15983555,c=r.roof||13129021,l=hm(e,t,Math.max(i,a)/2),u=[Z(pm(i+.4,.5,a+.4),10195850,{y:.25}),Z(pm(i,o,a),s,{y:.5+o/2}),Z(lm(1e-4,Math.hypot(i,a)*.62,2.4,4),c,{y:.5+o+1.2,ry:Math.PI/4,sz:a/i}),Z(pm(1.1,1.9,.12),8014634,{y:1.45,z:a/2+.05}),Z(pm(.9,.9,.1),10474480,{x:-i/2+1.2,y:2.2,z:a/2+.05}),Z(pm(.9,.9,.1),10474480,{x:i/2-1.2,y:2.2,z:a/2+.05}),Z(pm(.6,1.6,.6),9076596,{x:i/4,y:.5+o+1.6,z:-a/6})];r.flowerBox&&u.push(Z(pm(1.1,.25,.3),8014634,{x:-i/2+1.2,y:1.65,z:a/2+.2}),Z(pm(1,.2,.2),15825574,{x:-i/2+1.2,y:1.85,z:a/2+.2}));let d=this.add(Q(u),e,l,t,n);return this.col.addBox(e,t,i/2+.1,a/2+.1,l,l+.5+o+2.4,n,{walkable:!1}),this.exclude(e,t,Math.max(i,a)*.8+1),d}windmill(e,t){let n=hm(e,t,3.4),r=[Z(lm(3.4,3.4,5,10),14272419,{y:2.5}),Z(lm(3.6,3.6,.3,10),8017206,{y:5}),Z(lm(1.6,2.1,7,8),15787730,{y:8.5}),Z(um(2,2.4,8),10963509,{y:13.2}),Z(pm(1.1,1.9,.2),8014634,{y:1,z:3.38})];for(let e=0;e<10;e++){let t=e/10*Math.PI*2;r.push(Z(lm(.06,.06,.9,4),8017206,{x:Math.cos(t)*3.5,y:5.6,z:Math.sin(t)*3.5}))}this.add(Q(r),e,n,t);let i=new G,a=[Z(lm(.35,.35,.8,8),8017206,{rx:Math.PI/2})];for(let e=0;e<4;e++){let t=e/4*Math.PI*2;a.push(Z(pm(.25,5.2,.1),8017206,{x:Math.cos(t)*2.6,y:Math.sin(t)*2.6,rz:t-Math.PI/2})),a.push(Z(pm(1.1,4,.06),16249315,{x:Math.cos(t)*3+Math.cos(t+Math.PI/2)*.6,y:Math.sin(t)*3+Math.sin(t+Math.PI/2)*.6,z:.08,rz:t-Math.PI/2}))}let o=new q(Q(a),$f);o.castShadow=!0,i.add(o),i.position.set(e,n+11,t+2.4),this.scene.add(i),this.animated.push(e=>{o.rotation.z+=e*.6}),this.col.addCylinder(e,t,3.5,n,n+5.15,{walkable:!0}),this.col.addCylinder(e,t,2.1,n+5.15,n+14,{});for(let[r,i,a]of[[5.4,0,1.1],[6.6,1.3,2.2],[6.2,3,3.3],[4.8,4.4,4.3]])this.crate(e+r,t+i,n,a);return this.exclude(e,t,9),{x:e,y:n,z:t,top:n+5.15}}crate(e,t,n,r,i=1.2){let a=r-n,o=Q([Z(pm(i,a,i),11896655,{y:a/2}),Z(pm(i+.04,.12,i+.04),9069112,{y:a-.06}),Z(pm(i+.04,.12,i+.04),9069112,{y:.06})]);this.add(o,e,n,t),this.col.addBox(e,t,i/2,i/2,n,r,0,{walkable:!0})}stall(e,t,n){let r=hm(e,t,2.5),i=[Z(pm(3.6,1,1.4),11039039,{y:.5})];for(let[e,t]of[[-1.7,-.6],[1.7,-.6],[-1.7,1.2],[1.7,1.2]])i.push(Z(lm(.08,.08,2.8,5),8017206,{x:e,y:1.4,z:t}));for(let e=0;e<6;e++)i.push(Z(pm(.62,.08,2.4),e%2?16777215:4891615,{x:-1.55+e*.62,y:2.85,z:.3,rx:-.25}));i.push(Z(dm(.25),14697786,{x:-1,y:1.2,z:-.2}),Z(dm(.25),15905076,{x:-.4,y:1.2,z:-.3}),Z(pm(.5,.4,.4),9069112,{x:.8,y:1.2})),this.add(Q(i),e,r,t,n),this.col.addBox(e,t,1.9,.8,r,r+1,n,{walkable:!0}),this.exclude(e,t,4)}well(e,t){let n=hm(e,t,1.5),r=[Z(lm(1.3,1.4,1,10),10195850,{y:.5}),Z(lm(1.05,1.05,.05,10),4030118,{y:.85})];r.push(Z(lm(.08,.08,2.2,4),8017206,{x:-1.1,y:1.6}),Z(lm(.08,.08,2.2,4),8017206,{x:1.1,y:1.6})),r.push(Z(lm(1e-4,1.6,.8,4),13129021,{y:3,ry:Math.PI/4,sz:.6})),this.add(Q(r),e,n,t),this.col.addCylinder(e,t,1.4,n,n+1,{walkable:!0}),this.exclude(e,t,3)}lampPost(e,t){let n=X(e,t);this.add(Q([Z(lm(.08,.1,2.6,5),3881787,{y:1.3}),Z(pm(.4,.1,.4),3881787,{y:2.65})]),e,n,t);let r=new q(Q([Z(pm(.3,.35,.3),16770979,{y:2.45})]),ep(16762970,.2));return gm(r,e,n,t),this.scene.add(r),this.col.addCylinder(e,t,.15,n,n+2.7),r}fenceRing(e,t,n,r=0,i=.5){let a=Math.floor(Math.PI*2*n/2.2),o=[],s=[];for(let e=0;e<=a;e++){let t=e/a*Math.PI*2,n=Math.abs((t-r+Math.PI*3)%(Math.PI*2)-Math.PI);s.push({a:t,skip:n<i})}let c=X(e,t);for(let r=0;r<a;r++){let i=s[r],a=s[r+1];if(i.skip||a.skip)continue;let l=e+Math.cos(i.a)*n,u=t+Math.sin(i.a)*n,d=e+Math.cos(a.a)*n,f=t+Math.sin(a.a)*n,p=X(l,u)-c,m=X(d,f)-c,h=(l+d)/2-e,g=(u+f)/2-t,_=Math.hypot(d-l,f-u),v=-Math.atan2(f-u,d-l);o.push(Z(pm(.15,1.1,.15),9069112,{x:l-e,y:p+.55,z:u-t})),o.push(Z(pm(_,.1,.08),11039039,{x:h,y:(p+m)/2+.85,z:g,ry:v})),o.push(Z(pm(_,.1,.08),11039039,{x:h,y:(p+m)/2+.45,z:g,ry:v})),this.col.addBox(e+h,t+g,_/2,.12,c+Math.min(p,m),c+Math.max(p,m)+1,v,{walkable:!1})}this.add(Q(o),e,c,t)}campfire(e,t){let n=X(e,t),r=[];for(let e=0;e<8;e++){let t=e/8*Math.PI*2;r.push(Z(fm(.28),9407365,{x:Math.cos(t)*.85,y:.12,z:Math.sin(t)*.85,jitter:.1,seed:e}))}for(let e=0;e<3;e++)r.push(Z(lm(.1,.12,1.2,5),7031338,{y:.2,ry:e/3*Math.PI,rz:Math.PI/2-.25}));r.push(Z(lm(.25,.28,1.8,6),8017206,{x:2,y:.25,rz:Math.PI/2,ry:.4})),this.add(Q(r),e,n,t);let i=new q(Q([Z(um(.45,1.1,5),16747050,{y:.6}),Z(um(.25,.8,5),16769126,{y:.55,x:.05})]),ep(16742938,2.2));return gm(i,e,n,t),i.castShadow=!1,i.visible=!1,this.scene.add(i),this.animated.push((n,r)=>{i.visible&&(i.scale.set(1+Math.sin(r*13+e)*.08,1+Math.sin(r*9.3+t)*.15,1+Math.cos(r*11+e)*.08),i.rotation.y+=n*2)}),this.exclude(e,t,3.5),{x:e,y:n,z:t,fire:i}}lighthouse(e,t){let n=hm(e,t,4),r=[Z(lm(4.6,5,1.2,12),10195850,{y:.6})];for(let e=0;e<6;e++)r.push(Z(lm(3.4-(e+1)*.15,3.4-e*.15,2.4,12),e%2?14238778:16249834,{y:1.2+e*2.4+1.2}));let i=1.2+6*2.4;r.push(Z(lm(3.3,3.3,.4,12),3881787,{y:15.799999999999997}));for(let e=0;e<12;e++){let t=e/12*Math.PI*2;r.push(Z(lm(.05,.05,1,4),3881787,{x:Math.cos(t)*3.2,y:16.499999999999996,z:Math.sin(t)*3.2}))}r.push(Z(lm(1.9,1.9,2.6,10),13625589,{y:17.299999999999997})),r.push(Z(um(2.3,2,10),14238778,{y:19.599999999999998})),r.push(Z(mm(.35),15911244,{y:20.799999999999997})),r.push(Z(pm(1.4,2.4,.3),5913122,{y:2.4,z:3.25})),this.add(Q(r),e,n,t);let a=new q(Q([Z(dm(1,1),16774064,{y:17.299999999999997})]),ep(16769674,.15));gm(a,e,n,t),a.castShadow=!1,this.scene.add(a);let o=new q(new oa(.4,9,140,16,1,!0).translate(0,70,0).rotateZ(-Math.PI/2),new ii({color:16773560,transparent:!0,opacity:.18,depthWrite:!1,side:2,blending:2}));return o.position.set(e,n+i+1.7,t),o.visible=!1,this.scene.add(o),this.animated.push(e=>{o.visible&&(o.rotation.y+=e*.5)}),this.col.addCylinder(e,t,4.8,n,n+1.2,{walkable:!0}),this.col.addCylinder(e,t,3.4,n+1.2,n+i+6),this.exclude(e,t,10),{x:e,y:n,z:t,lamp:a,beam:o,door:{x:e,z:t+4.4,y:n+1.2}}}observatory(e,t){let n=hm(e,t,5),r=[Z(lm(4.4,4.6,.6,12),10195850,{y:.3}),Z(lm(3.6,3.6,4.2,12),15262422,{y:2.7}),Z(mm(3.8,12,6),5992360,{y:4.8,sy:.85}),Z(pm(.9,4.2,.2),3095395,{y:6.2,z:2.4,rx:-.5}),Z(lm(.35,.45,4.2,8),13215050,{y:7.2,z:1.9,rx:-.9}),Z(pm(1.2,2,.2),5913122,{y:1.6,z:3.55})];return this.add(Q(r),e,n,t),this.col.addCylinder(e,t,3.8,n,n+8.5),this.exclude(e,t,14),{x:e,y:n,z:t}}ruins(e,t){let n=hm(e,t,8),r=gd(5),i=[Z(pm(15.2,.4,15.2),12169892,{y:.2})];for(let a=0;a<8;a++){let o=a/8*Math.PI*2+.2,s=1.5+r()*4;i.push(Z(lm(.55,.65,s,8),13616820,{x:Math.cos(o)*10.5,y:s/2,z:Math.sin(o)*10.5})),this.col.addCylinder(e+Math.cos(o)*10.5,t+Math.sin(o)*10.5,.65,n,n+s,{walkable:!0}),r()>.5&&i.push(Z(pm(1.6,.5,.8),13616820,{x:Math.cos(o)*12.3,y:.25,z:Math.sin(o)*12.3,ry:r()*3,rz:.2}))}return i.push(Z(pm(2.4,1.2,2.4),10787980,{z:-10.5,y:.6})),this.add(Q(i),e,n,t),this.col.addBox(e,t,7.6,7.6,n-2,n+.4,0,{walkable:!0}),this.col.addBox(e,t-10.5,1.2,1.2,n,n+1.2,0,{walkable:!0}),this.exclude(e,t,15),{x:e,y:n+.4,z:t,altar:{x:e,z:t-10.5,y:n+1.2}}}shipwreck(e,t,n){let r=X(e,t),i=[];for(let e=0;e<7;e++){let t=e/6-.5,n=4.2*(1-Math.abs(t)*.9);i.push(Z(pm(n,2.6,2.1),e%2?7031338:8017206,{z:t*13,y:1}))}i.push(Z(pm(3.6,.2,11),10122832,{y:2.4})),i.push(Z(lm(.18,.24,9,6),7031338,{y:6.5,z:-1,rz:.15})),i.push(Z(pm(.15,3.2,4),15327695,{y:7.5,z:-1,x:.6,rz:.15,ry:.2})),i.push(Z(pm(2.6,1.2,3),8017206,{z:5,y:3}));let a=Q(i),o=this.add(a,e,r-.6,t,n);o.rotation.z=.12,this.col.addBox(e,t,1.8,6.4,r-1,r+1.85,n,{walkable:!0});let s=e+Math.sin(n)*5,c=t+Math.cos(n)*5;return this.col.addBox(s,c,1.3,1.5,r-1,r+3,n,{walkable:!0}),this.exclude(e,t,9),{x:e,y:r+1.85,z:t,bow:{x:s,z:c,y:r+3}}}arch(e,t,n){let r=X(e,t),i=Q([Z(new No(7,1.8,6,12,Math.PI),11821371,{y:0,jitter:.6,seed:3}),Z(fm(2.4),10900789,{x:-7,y:.5,jitter:.5,seed:4}),Z(fm(2.4),10900789,{x:7,y:.5,jitter:.5,seed:5})]);this.add(i,e,r,t,n);let a=Math.cos(n),o=Math.sin(n);return this.col.addCylinder(e+7*a,t-7*o,2.2,r-2,r+6),this.col.addCylinder(e-7*a,t+7*o,2.2,r-2,r+6),this.exclude(e,t,11),{x:e,y:r,z:t}}giantTree(e,t){let n=hm(e,t,3),r=[Z(lm(2.2,3.4,20,9),7031344,{y:10,jitter:.3,seed:11})];for(let e=0;e<6;e++){let t=e/6*Math.PI*2;r.push(Z(lm(.3,.9,5,5),7031344,{x:Math.cos(t)*3.2,y:.6,z:Math.sin(t)*3.2,rx:Math.sin(t)*1.2,rz:-Math.cos(t)*1.2}))}let i=gd(17);for(let e=0;e<9;e++){let t=i()*Math.PI*2,n=3+i()*6;r.push(Z(dm(4+i()*2.5,0),new K(4160826).offsetHSL(0,0,(i()-.5)*.08),{x:Math.cos(t)*n,y:21+i()*4,z:Math.sin(t)*n,jitter:1.2,seed:20+e}))}this.add(Q(r),e,n,t),this.col.addCylinder(e,t,3,n-1,n+19.5);let a=[];for(let r=0;r<15;r++){let i=r*.75,o=1+r*1.15,s=3.9,c=e+Math.cos(i)*s,l=t+Math.sin(i)*s;a.push(Z(lm(1.25,1,.35,8),r%3==0?14723162:14260810,{x:Math.cos(i)*s,y:o,z:Math.sin(i)*s,sz:.85})),this.col.addCylinder(c,l,1.2,n+o-.35,n+o+.17,{walkable:!0})}let o=18.85;return a.push(Z(lm(4.2,3.6,.6,10),8017206,{y:o})),this.col.addCylinder(e,t,4.2,n+o-.6,n+o+.3,{walkable:!0}),this.add(Q(a),e,n,t),this.exclude(e,t,12),{x:e,y:n,z:t,top:n+o+.3}}dock(e,t,n,r=18){let i=[];for(let e=0;e<r/1.2;e++)i.push(Z(pm(3,.18,1.1),e%2?11039039:10119738,{z:e*1.2,y:0}));for(let e=0;e<r/3;e++)for(let t of[-1.4,1.4])i.push(Z(lm(.15,.15,6,5),7031338,{x:t,z:e*3,y:-2.9}));let a=Q(i);this.add(a,e,1.6,t,n);let o=Math.cos(n),s=Math.sin(n),c=r/2-.6;return this.col.addBox(e+s*c,t+o*c,1.5,r/2,-4.4,1.6900000000000002,n,{walkable:!0}),{x:e,z:t,y:1.6900000000000002,end:{x:e+s*(r-1),z:t+o*(r-1)}}}flag(e,t,n=15289916){let r=X(e,t),i=Q([Z(lm(.06,.08,5,5),14540253,{y:2.5})]);this.add(i,e,r,t);let a=new q(Q([Z(pm(1.6,1,.04),n,{x:.8})]),$f);a.position.set(e,r+4.4,t),this.scene.add(a),this.animated.push((t,n)=>{a.rotation.y=Math.sin(n*2.1+e)*.35}),this.col.addCylinder(e,t,.1,r,r+5)}bench(e,t,n){let r=X(e,t);this.add(Q([Z(pm(2,.12,.6),11039039,{y:.5}),Z(pm(2,.5,.1),11039039,{y:.85,z:-.28}),Z(pm(.1,.5,.5),5913122,{x:-.85,y:.25}),Z(pm(.1,.5,.5),5913122,{x:.85,y:.25})]),e,r,t,n),this.col.addBox(e,t,1,.3,r,r+.56,n,{walkable:!0})}signpost(e,t,n){let r=X(e,t);this.add(Q([Z(lm(.08,.1,2.2,5),8017206,{y:1.1}),Z(pm(1.3,.35,.08),13214315,{y:1.85,x:.4}),Z(pm(1.1,.35,.08),13214315,{y:1.4,x:-.35,ry:.4})]),e,r,t,n),this.col.addCylinder(e,t,.12,r,r+2.2)}pillar(e,t,n,r=1.3,i=13616820){let a=hm(e,t,r);return this.add(Q([Z(lm(r,r*1.1,n,8),i,{y:n/2,jitter:.08,seed:Math.floor(e*7+t)})]),e,a,t),this.col.addCylinder(e,t,r,a-1,a+n,{walkable:!0}),this.exclude(e,t,r+1),a+n}plank(e,t,n,r,i=4,a=1.4){this.add(Q([Z(pm(a,.25,i),11039039,{}),Z(pm(a+.1,.1,.2),8017206,{y:.1,z:i/2-.2}),Z(pm(a+.1,.1,.2),8017206,{y:.1,z:-i/2+.2})]),e,t,n,r),this.col.addBox(e,n,a/2,i/2,t-.4,t+.125,r,{walkable:!0})}},vm=150,ym=vd(31337),bm=vd(5151),xm=null;function Sm(){return xm||=Cm()}function Cm(){return{oak:{sway:!0,variants:[lp(1),lp(2),lp(3,8239183)],col:.45,shadow:!0,codex:`oak`},pine:{sway:!0,variants:[up(1),up(2,3831110)],col:.35,shadow:!0,codex:`pine`},darkpine:{sway:!0,variants:[up(3,2907717,!1,1.5),up(4,2774336,!1,1.35)],col:.4,shadow:!0,codex:`darkpine`},snowpine:{sway:!0,variants:[up(5,3497802,!0,1.1),up(6,3827280,!0,.9)],col:.35,shadow:!0,codex:`snowpine`},palm:{sway:!0,variants:[dp(1),dp(2)],col:.3,shadow:!0,codex:`palm`},cactus:{variants:[fp(1),fp(2),fp(3)],col:.45,shadow:!0,codex:`cactus`},deadtree:{variants:[pp(1),pp(2)],col:.25,shadow:!0},bush:{sway:!0,variants:[mp(1),mp(2,5214014,!0)],shadow:!0},rock:{variants:[hp(1),hp(2),hp(3,9078142,.6)],col:.8,shadow:!0},redrock:{variants:[hp(4,11821371),hp(5,10900789,.7)],col:.8,shadow:!0},grass:{sway:!0,variants:[gp(8372047),gp(6266437)],shadow:!1},flowers:{sway:!0,variants:[_p(16242506),_p(15825574),_p(10139903),_p(16777215)],shadow:!1,codex:`flower`},sunflower:{sway:!0,variants:[vp()],shadow:!1,codex:`sunflower`},mushroom:{variants:[yp(),yp(13073710)],shadow:!1,codex:`mushroom`},reeds:{sway:!0,variants:[bp()],shadow:!1,codex:`reeds`},crystal:{variants:[xp(1),xp(2,9425919)],col:.5,shadow:!0,glow:10120191,codex:`crystal`},coral:{variants:[Sp(1),Sp(2)],shadow:!1,codex:`coral`}}}function wm(e,t,n,r){let i=Sm(),a=new Map,o={x:0,y:1,z:0},s=(e,t,r=0)=>{for(let i of n)if(Math.hypot(e-i.x,t-i.z)<i.r+r)return!0;return!1},c=(e,n,o,s,c,l=0)=>{let u=i[e],d=Math.floor(_d(c,7)*u.variants.length),f=`${e}|${d}|${Math.floor((n+450)/vm)}|${Math.floor((o+450)/vm)}`,p=a.get(f);p||a.set(f,p={type:e,v:d,items:[]});let m=X(n,o)+l;p.items.push({x:n,y:m,z:o,s,r:_d(c,13)*Math.PI*2,tint:(_d(c,17)-.5)*.12}),u.col&&t.addCylinder(n,o,u.col*s,m-.5,m+3*s),u.codex&&r&&_d(c,23)<.08&&r.push({id:u.codex,x:n,y:m+1.5*s,z:o})},l=3.2,u=0;for(let e=-446;e<446;e+=l)for(let t=-446;t<446;t+=l){u++;let n=t+(_d(u,1)-.5)*l*.9,r=e+(_d(u,2)-.5)*l*.9;if(gf(n,r)>=.6)continue;let i=X(n,r),a=If(n,r),d=_d(u,3),f=_d(u,4);if(i<a-.3){i>a-6&&i<a-1.2&&a===0&&d<.02&&c(`coral`,n,r,.8+f*.8,u);continue}Ff(n,r,o);let p=ff(n,r),m=i<a+1.6,h=o.y<.8;if(s(n,r,1.5))continue;let g=ym(n*.02,r*.02),_=bm(n*.05,r*.05);if(m){a>0&&d<.12&&i<a+.8?c(`reeds`,n,r,.9+f*.5,u):p.coast+p.meadow>.5&&d<.02&&i>a+.4&&pf(n,r)>.2?c(`palm`,n,r,.9+f*.4,u):d>.985&&c(`rock`,n,r,.4+f*.8,u);continue}if(h){d<.03&&c(p.canyon>.4?`redrock`:`rock`,n,r,.6+f*1.2,u,-.2);continue}let v=i>47,y=p.forest*(.16+Math.max(0,g)*.18),b=p.meadow*Math.max(0,g-.25)*.12,x=p.lake*(.03+Math.max(0,_)*.06),S=p.mountain*(.02+Math.max(0,g)*.06),C=p.coast*.012,w=p.canyon*.012,T=d;T<y?c(Math.hypot(n-Vd.x,r-Vd.z)<Vd.r+10||f<.55?`darkpine`:`oak`,n,r,.9+f*.6,u):(T-=y,T<b?c(f<.8?`oak`:`pine`,n,r,.8+f*.5,u):(T-=b,T<x?c(`pine`,n,r,.8+f*.5,u):(T-=x,T<S?c(v?`snowpine`:`pine`,n,r,.8+f*.5,u):(T-=S,T<C?c(`palm`,n,r,.9+f*.4,u):(T-=C,T<w?c(f<.7?`cactus`:`deadtree`,n,r,.8+f*.5,u):(T-=w,T<.012?c(p.canyon>.5?`redrock`:`rock`,n,r,.3+f*.7,u,-.1):(T-=.012,T<.03*(p.meadow+p.forest+p.lake)&&!v?c(`bush`,n,r,.7+f*.6,u):(T-=.03,p.forest>.4&&T<.025?c(`mushroom`,n,r,.8+f*.8,u):p.lake>.5&&T<.012?c(`crystal`,n,r,.6+f*.8,u):p.meadow>.5&&_>.35&&T<.25?c(f<.15?`sunflower`:`flowers`,n,r,.9+f*.4,u):!v&&p.canyon<.5&&T<.5*(1-p.canyon)&&c(`grass`,n,r,.8+f*.7,u)))))))))}let d=new wn,f=new K,p={},m=[];for(let t of a.values()){let n=i[t.type],r=n.sway?tp:$f;n.glow&&(r=p[t.type]||(p[t.type]=ep(n.glow,1.6)));let a=new Di(n.variants[t.v],r,t.items.length);t.items.forEach((e,t)=>{d.position.set(e.x,e.y,e.z),d.rotation.set(0,e.r,0),d.scale.setScalar(e.s),d.updateMatrix(),a.setMatrixAt(t,d.matrix),f.setRGB(1+e.tint,1+e.tint,1+e.tint),a.setColorAt(t,f)}),a.castShadow=n.shadow,a.receiveShadow=!0,a.computeBoundingSphere(),a.userData.kind=t.type,e.add(a),m.push(a)}return{meshes:m,lib:i}}var Tm=360/Cp,Em=(e,t)=>e>=0&&t>=0&&e<Tm&&t<Tm,Dm=3.2,Om=vd(4711),km=Qf(Xf(new Wo({vertexColors:!0,roughness:.88,metalness:0}),15794128,.2),`attr`),Am=$f,jm=ep(10120191,1.6);function Mm(e,t,n,r,i,a,o,s){if(n<.15)return null;if(r<.8)return a<.04?[i.canyon>.4?`redrock`:`rock`,.6+o*1.3]:null;if(n<1.1)return i.meadow+i.crystal>.4&&a<.03?[`palm`,.9+o*.4]:i.crystal>.5&&a>.95?[`crystal`,.5+o*.6]:a>.985?[`rock`,.4+o*.6]:null;let c=a,l=[[`forest`,i.forest*(.14+Math.max(0,s)*.22),()=>o<.45?`darkpine`:o<.8?`pine`:`oak`,.9+o*.6],[`meadow`,i.meadow*Math.max(0,s-.15)*.14,()=>o<.85?`oak`:`pine`,.85+o*.5],[`snow`,i.snow*(.03+Math.max(0,s)*.08),()=>`snowpine`,.8+o*.6],[`canyon`,i.canyon*.02,()=>o<.7?`cactus`:`deadtree`,.8+o*.5],[`crystal`,i.crystal*.035,()=>o<.6?`crystal`:`palm`,.6+o*.8]];for(let[,e,t,n]of l){if(c<e)return[t(),n];c-=e}return c<.012?[i.canyon>.5?`redrock`:`rock`,.3+o*.8]:(c-=.012,c<.035*(i.meadow+i.forest+i.crystal)?[`bush`,.7+o*.6]:(c-=.035,i.forest>.4&&c<.02?[`mushroom`,.8+o*.8]:i.meadow>.4&&s>.25&&c<.12?[o<.15?`sunflower`:`flowers`,.9+o*.4]:null))}var Nm=new Xt,Pm=new Dt,Fm=new U,Im=new U,Lm=new U(0,1,0),Rm=new W;function zm(e,t,n){let r=0;for(let n of e)r+=t[n.type].variants[n.v].attributes.position.count;if(!r)return null;let i=new Float32Array(r*3),a=new Float32Array(r*3),o=new Float32Array(r*3),s=n?new Float32Array(r):null,c=0;for(let n of e){let e=t[n.type],r=e.variants[n.v],l=r.attributes.position.array,u=r.attributes.normal.array,d=r.attributes.color.array,f=r.attributes.position.count;Pm.setFromAxisAngle(Lm,n.r),Nm.compose(Fm.set(n.x,n.y,n.z),Pm,Im.setScalar(n.s)),Rm.getNormalMatrix(Nm);let p=Nm.elements,m=Rm.elements,h=1+n.tint;for(let t=0;t<f;t++){let n=l[t*3],r=l[t*3+1],f=l[t*3+2];i[c*3]=p[0]*n+p[4]*r+p[8]*f+p[12],i[c*3+1]=p[1]*n+p[5]*r+p[9]*f+p[13],i[c*3+2]=p[2]*n+p[6]*r+p[10]*f+p[14];let g=u[t*3],_=u[t*3+1],v=u[t*3+2];a[c*3]=m[0]*g+m[3]*_+m[6]*v,a[c*3+1]=m[1]*g+m[4]*_+m[7]*v,a[c*3+2]=m[2]*g+m[5]*_+m[8]*v,o[c*3]=d[t*3]*h,o[c*3+1]=d[t*3+1]*h,o[c*3+2]=d[t*3+2]*h,s&&(s[c]=e.sway?Math.max(0,r-.25):0),c++}}let l=new Dr;return l.setAttribute(`position`,new fr(i,3)),l.setAttribute(`normal`,new fr(a,3)),l.setAttribute(`color`,new fr(o,3)),s&&l.setAttribute(`aH`,new fr(s,1)),l.computeBoundingSphere(),l}var Bm=class{constructor(e,t){this.scene=e,this.col=t,this.chunks=new Map,this.radius=6,this.vegRadius=3,this.onEnter=null,this.onLeave=null,this.group=new G,e.add(this.group),this.lib=Sm()}setQuality(e){this.radius={low:4,medium:5,high:6,ultra:7}[e]??6,this.vegRadius={low:2,medium:3,high:3,ultra:4}[e]??3}_coreHasFar(e,t){let n=0;for(let[r,i]of[[0,0],[1,0],[0,1],[1,1]]){let a=-450+(e+r)*wp,o=-450+(t+i)*wp;n=Math.max(n,gf(a,o))}return n>.6}chunkAt(e,t){return[Math.floor((e+450)/wp),Math.floor((t+450)/wp)]}update(e,t,n=5,r=!1){kf();let[i,a]=this.chunkAt(e,t),o=this.radius,s=[];for(let n=-o;n<=o;n++)for(let r=-o;r<=o;r++){let c=i+r,l=a+n,u=Em(c,l);if(u&&!this._coreHasFar(c,l))continue;let d=-450+(c+.5)*wp,f=-450+(l+.5)*wp,p=Math.hypot(d-e,f-t)/wp;if(p>o+.5)continue;let m=u?0:p<2.2?1:p<4.2?2:3,h=p<this.vegRadius+.5,g=c*65536+l,_=this.chunks.get(g);!_||_.lod!==m||_.wantVeg!==h?s.push({key:g,ci:c,cj:l,lod:m,veg:h,d:p,c:_}):_.seen=!0}s.sort((e,t)=>e.d-t.d);let c=performance.now();for(let e of s){if(!r&&performance.now()-c>n&&e!==s[0])break;this._build(e)}for(let[n,r]of this.chunks){let i=-450+(r.ci+.5)*wp,a=-450+(r.cj+.5)*wp;Math.hypot(i-e,a-t)/wp>o+1.5&&this._unload(n,r)}return s.length}_build(e){let t=e.c;t||(t={ci:e.ci,cj:e.cj,lod:0,wantVeg:!1,terrain:null,veg:[],cols:[],entered:!1,data:{}},this.chunks.set(e.key,t)),t.lod!==e.lod&&e.lod>0&&(t.terrain&&(this.group.remove(t.terrain),t.terrain.geometry.dispose()),t.terrain=Jp(e.ci,e.cj,e.lod),t.terrain.castShadow=e.lod===1,this.group.add(t.terrain),t.lod=e.lod),e.veg&&!t.wantVeg?this._buildVeg(t):!e.veg&&t.wantVeg&&this._dropVeg(t),t.wantVeg=e.veg}_buildVeg(e){let t=this.lib,n=-450+e.ci*wp,r=-450+e.cj*wp,i=[],a=[],o=[],s={x:0,y:1,z:0},c={},l=[],u=Math.ceil(n/Dm),d=Math.ceil(r/Dm);for(let f=d;f*Dm<r+wp;f++)for(let r=u;r*Dm<n+wp;r++){let n=r*Dm+(_d(r,f,1)-.5)*Dm*.9,u=f*Dm+(_d(r,f,2)-.5)*Dm*.9;if(gf(n,u)<.6)continue;let d=X(n,u);if(d<If(n,u)+.15)continue;Ff(n,u,s),_f(n,u,c);let p=_d(r,f,3),m=_d(r,f,4),h=Mm(n,u,d,s.y,c,p,m,Om(n*.02,u*.02));if(!h){s.y>.85&&d>1&&p>.93&&l.push({x:n,y:d,z:u,w:{...c}});continue}let[g,_]=h,v=t[g],y={type:g,v:Math.floor(_d(r,f,7)*v.variants.length),x:n,y:d-(g.includes(`rock`)?.2:0),z:u,s:_,r:_d(r,f,13)*Math.PI*2,tint:(_d(r,f,17)-.5)*.12};(v.glow?o:v.sway?i:a).push(y),v.col&&e.cols.push(this.col.addCylinder(n,u,v.col*_,d-.5,d+3*_))}let f=(n,r,i)=>{let a=zm(n,t,i);if(!a)return;let o=new q(a,r);o.castShadow=!0,o.receiveShadow=!0,this.group.add(o),e.veg.push(o)};f(i,km,!0),f(a,Am,!1),f(o,jm,!1),e.data.spots=l,e.data.rng=gd(e.ci*73856093^e.cj*19349663),e.entered||(e.entered=!0,this.onEnter?.(e))}_dropVeg(e){for(let t of e.veg)this.group.remove(t),t.geometry.dispose();e.veg.length=0;for(let t of e.cols)this.col.removeStatic(t);e.cols.length=0}_unload(e,t){this._dropVeg(t),t.terrain&&(this.group.remove(t.terrain),t.terrain.geometry.dispose()),t.entered&&this.onLeave?.(t),this.chunks.delete(e)}},Vm=24;function Hm(){let e=[.05,.042,.028,0],t=[0,.36,.7,1],n=[],r=[],i=[],a=[];for(let a=0;a<4;a++){let o=t[a]*t[a]*.18;a<3?n.push(-e[a],t[a],o,e[a],t[a],o):n.push(0,t[a],o);let s=.68+t[a]*.5,c=a<3?2:1;for(let e=0;e<c;e++)r.push(s,s,s),i.push(0,1,.25)}for(let e=0;e<2;e++){let t=e*2;a.push(t,t+1,t+3,t,t+3,t+2)}a.push(4,5,6);let o=new Dr;return o.setAttribute(`position`,new hr(n,3)),o.setAttribute(`color`,new hr(r,3)),o.setAttribute(`normal`,new hr(i,3)),o.setIndex(a),o}var Um={};function Wm(e,t,n,r){if(r<.8)return 0;let i=If(e,t);if(n<i+.35)return 0;let a=Sd(i+.35,i+1.8,n),o=gf(e,t),s=0,c=0;if(o<1){let r=ff(e,t);s=r.meadow+r.forest*.75+r.lake*.9+r.coast*.45+r.mountain*.7*Sd(42,30,n)+r.canyon*.06;let i=Math.hypot(e-zd.x,t-zd.z);s*=.08+.92*Sd(zd.r-10,zd.r+6,i)}if(o>0){let r=_f(e,t,Um);c=r.meadow+r.forest*.75+r.crystal*.55+r.canyon*.08+r.snow*.7*Sd(12,5,n)}return(s+(c-s)*o)*a}var Gm=class{constructor(e,t){this.scene=e,this.col=t,this.geo=Hm(),this.uPlayer={value:new U(0,-999,0)};let n=new Wo({vertexColors:!0,roughness:.75,metalness:0,side:2});n.onBeforeCompile=e=>{e.uniforms.uWindTime=Zf.uTime,e.uniforms.uWindDir=Zf.uDir,e.uniforms.uWindStr=Zf.uStrength,e.uniforms.uPlayer=this.uPlayer,e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
uniform float uWindTime; uniform vec2 uWindDir; uniform float uWindStr; uniform vec3 uPlayer;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
          {
            vec3 base = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
            float hh = position.y;
            float ph = dot(base.xz, vec2(0.21, 0.13)) + uWindTime * 2.1;
            float gust = 0.55 + 0.45 * sin(dot(base.xz, uWindDir) * 0.045 - uWindTime * 1.3);
            float sway = (sin(ph) * 0.5 + sin(ph * 2.7 + 1.3) * 0.2 + 0.35) * gust * uWindStr * 0.32 * hh * hh;
            // local-space push: convert world wind into the instance frame via the inverse of its rotation
            mat3 rot = mat3(instanceMatrix);
            vec3 wl = transpose(rot) * vec3(uWindDir.x, 0.0, uWindDir.y);
            transformed.xz += wl.xz * sway / max(length(rot[0]), 0.001) * 1.0;
            vec2 away = base.xz - uPlayer.xz;
            float dp = length(away);
            float push = smoothstep(1.5, 0.2, dp) * step(abs(base.y - uPlayer.y), 1.6);
            vec3 pl = transpose(rot) * vec3(normalize(away + 1e-4).x, 0.0, normalize(away + 1e-4).y);
            transformed.xz += pl.xz * push * hh * 0.75 / max(length(rot[0]), 0.001);
            transformed.y -= (push * 0.45 + abs(sway) * 0.2) * hh;
          }`),e.fragmentShader=e.fragmentShader.replace(`#include <normal_fragment_begin>`,`#include <normal_fragment_begin>
 normal = normalize(vNormal);`)},this.mat=n,this.tiles=new Map,this.pool=[],this.rings=3,this.density=5,this.enabled=!0,this._color=new K,this._n={x:0,y:1,z:0}}setQuality(e){this.rings={low:1,medium:2,high:3,ultra:3}[e]??3,this.density={low:3,medium:5,high:7,ultra:9}[e]??7,this.enabled=e!==`low`;for(let e of this.tiles.values())this._release(e);this.tiles.clear()}_acquire(e){let t=this.pool.find(t=>t.instanceMatrix.count>=e);return t?this.pool.splice(this.pool.indexOf(t),1):(t=new Di(this.geo,this.mat,Math.max(e,512)),t.receiveShadow=!0,t.castShadow=!1,t.frustumCulled=!0,t.setColorAt(0,this._color.set(1,1,1))),this.scene.add(t),t}_release(e){this.scene.remove(e.mesh),this.pool.push(e.mesh)}_buildTile(e,t,n){let r=e*Vm,i=t*Vm,a=this.density*(n<=1?1:n===2?.5:.25),o=Math.floor(576*a),s=this._acquire(o),c=new Xt,l=new Dt,u=new sn,d=new U,f=new U,p=new Map,m=0,h=e*92821^t*68917;for(let e=0;e<o;e++){let t=r+_d(e,h,1)*Vm,n=i+_d(e,h,2)*Vm,a=X(t,n);Ff(t,n,this._n);let o=Wm(t,n,a,this._n.y);if(_d(e,h,3)>o)continue;let g=!1;for(let e of this.col.query(t,n,0))if(!(e.y0>a+.6||e.y1<a)&&(e.type===`cyl`?Math.hypot(t-e.x,n-e.z)<e.r+.1:(()=>{let r=t-e.x,i=n-e.z,a=r*e.cos-i*e.sin,o=r*e.sin+i*e.cos;return Math.abs(a)<e.hx+.1&&Math.abs(o)<e.hz+.1})())){g=!0;break}if(g)continue;let _=Math.round(t/cf),v=Math.round(n/cf),y=_*100003+v,b=p.get(y);b||(b=Wp(_*cf,v*cf,a,this._n.y,new K),p.set(y,b));let x=_d(e,h,4),S=_d(e,h,5);u.set((S-.5)*.3,x*Math.PI*2,(_d(e,h,6)-.5)*.3),l.setFromEuler(u);let C=.32+S*.42*(.6+o*.4);c.compose(d.set(t,a-.03,n),l,f.set(1+x*.5,C,1)),s.setMatrixAt(m,c),this._color.copy(b).offsetHSL((x-.5)*.03,.06,.04+(S-.5)*.08),s.setColorAt(m,this._color),m++}return s.count=m,s.instanceMatrix.needsUpdate=!0,s.instanceColor&&(s.instanceColor.needsUpdate=!0),s.boundingSphere=new yr(new U(r+Vm/2,X(r+Vm/2,i+Vm/2),i+Vm/2),24),{mesh:s,ring:n}}update(e,t=3){if(this.uPlayer.value.copy(e),!this.enabled)return;let n=Math.floor(e.x/Vm),r=Math.floor(e.z/Vm),i=this.rings,a=new Map;for(let e=-i;e<=i;e++)for(let t=-i;t<=i;t++){let i=Math.max(Math.abs(t),Math.abs(e));a.set((n+t)*65536+(r+e),{ti:n+t,tj:r+e,ring:i})}for(let[e,t]of this.tiles){let n=a.get(e);(!n||n.ring<=1!=t.ring<=1||n.ring===2!=(t.ring===2))&&(this._release(t),this.tiles.delete(e))}let o=[...a.entries()].filter(([e])=>!this.tiles.has(e)).sort((e,t)=>e[1].ring-t[1].ring),s=performance.now();for(let[e,n]of o){if(performance.now()-s>t&&n.ring>0)break;this.tiles.set(e,this._buildTile(n.ti,n.tj,n.ring))}}},Km=420,qm=36,Jm=class{constructor(e){let t=gd(99);this.seed=new Float32Array(Km*4);for(let e=0;e<Km;e++)this.seed[e*4]=t()*qm,this.seed[e*4+1]=t()*14,this.seed[e*4+2]=t()*qm,this.seed[e*4+3]=t();this.pos=new Float32Array(Km*3),this.alpha=new Float32Array(Km);let n=new Dr;n.setAttribute(`position`,new fr(this.pos,3)),n.setAttribute(`alpha`,new fr(this.alpha,1)),this.mat=new Ho({uniforms:{uCol:{value:new K},uSize:{value:1}},vertexShader:`attribute float alpha; varying float vA; uniform float uSize; void main(){ vA = alpha; vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = uSize * 180.0 / max(0.5, -mv.z); gl_Position = projectionMatrix * mv; }`,fragmentShader:`uniform vec3 uCol; varying float vA; void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; float a = smoothstep(0.5, 0.0, d); gl_FragColor = vec4(uCol * (0.5 + a * 1.5), a * vA); }`,transparent:!0,depthWrite:!1,blending:2}),this.points=new Xi(n,this.mat),this.points.frustumCulled=!1,e.add(this.points),this.mode=`day`,this._w={}}update(e,t,n){let r=n.night,i=n.rain,a=t.x,o=t.z,s=gf(a,o),c=(s>.5?_f(a,o,this._w).snow>.5:X(a,o)>45)?`snow`:r>.5?`firefly`:`day`,l=s>.5?1:(()=>{let e=ff(a,o);return e.meadow+e.forest+e.lake})(),u=this.mat.uniforms.uCol.value,d;c===`snow`?(u.setRGB(.9,.95,1),this.mat.uniforms.uSize.value=.7,d=.6):c===`firefly`?(u.setRGB(.75,1,.35),this.mat.uniforms.uSize.value=.9,d=(1-i)*Math.min(1,l)):(u.setRGB(1,.92,.7),this.mat.uniforms.uSize.value=.35,d=.35*(1-i)*Math.min(1,.3+l));let f=c===`snow`?1.6:0;for(let t=0;t<Km;t++){let n=this.seed[t*4],r=this.seed[t*4+1],i=this.seed[t*4+2],s=this.seed[t*4+3],l=e*(.2+s*.3)+s*40,u=((n+Math.sin(l)*2+e*.4-a)%qm+qm)%qm+a-qm/2,p=((i+Math.cos(l*.8)*2+e*.25-o)%qm+qm)%qm+o-qm/2,m=X(u,p),h=c===`snow`?((r-e*f)%14+14)%14:r*(c===`firefly`?.25:.5)+Math.sin(l*1.3)*.6;this.pos[t*3]=u,this.pos[t*3+1]=m+.3+h,this.pos[t*3+2]=p;let g=d;c===`firefly`&&(g*=Math.max(0,Math.sin(e*(1.5+s*2)+s*30))**3);let _=u-a,v=p-o;g*=Math.max(0,1-Math.hypot(_,v)/(qm*.5)),this.alpha[t]=g}this.points.geometry.attributes.position.needsUpdate=!0,this.points.geometry.attributes.alpha.needsUpdate=!0}},Ym=(e,t,n=1.2)=>({x:e,y:X(e,t)+n,z:t}),Xm=(e,t,n,r)=>[e+Math.cos(r)*n,t+Math.sin(r)*n];function Zm(e,t,n,r,i){let a=Math.hypot(n,r);n/=a,r/=a;for(let a=0;a<500;a++)if(e+=n,t+=r,X(e,t)<i)return{x:e,z:t};return{x:e,z:t}}function Qm(){let e={},t=zd;e.village={well:{x:t.x,z:t.z},houses:[{id:`aila`,x:-20,z:130,yaw:Math.atan2(20,20),roof:13129021,flowerBox:!0},{id:`pip`,x:22,z:131,yaw:Math.atan2(-22,19),roof:4882369,w:6.5},{id:`h3`,x:-29,z:160,yaw:Math.PI/2+.25,roof:6989903,flowerBox:!0},{id:`h4`,x:29,z:160,yaw:-Math.PI/2-.2,roof:14262330},{id:`h5`,x:-10,z:180,yaw:Math.PI,roof:10247093,w:5,d:4.5}],stall:{x:9,z:141,yaw:0},windmill:{x:-36,z:108},lamps:[[-10,140],[10,160],[-14,162],[14,126],[0,170],[-30,140],[30,145]],benches:[{x:6,z:156,yaw:Math.PI},{x:-7,z:157,yaw:Math.PI+.3}]},e.pillarCourse=[[44,128,1.4],[46.5,125.5,2.8],[49.5,124,4.2],[52.5,125.5,5.6],[54.5,128.5,7]],e.pen={x:Gd.pen.x,z:Gd.pen.z,r:7,gap:Math.atan2(55,70)},e.lookout={x:Gd.lookout.x,z:Gd.lookout.z};let n=Zm(-10,150,0,1,.8);e.dock={x:n.x,z:n.z-3,yaw:0,len:18},e.ruins={x:Gd.ruins.x,z:Gd.ruins.z},e.giantTree={x:Gd.giantTree.x,z:Gd.giantTree.z},e.observatory={x:Gd.observatory.x,z:Gd.observatory.z},e.arch={x:Gd.arch.x,z:Gd.arch.z,yaw:.6};let r=Zm(205,228,.75,.66,-.6);e.shipwreck={x:r.x,z:r.z,yaw:.9};let i=Zm(r.x,r.z,.2,1,-2.5);e.seaStack={x:i.x,z:i.z,h:9},e.riverPillar={x:mf(20),z:20,h:8},e.lighthouse={x:-6,z:-242},e.campfires=Yd.map(e=>{let t=zf(e.x,e.z,10,1);return{...e,x:t.x,z:t.z}}),e.mesaS=Rf(255,92,12),e.hoodooPeak={x:252,z:77,h:Math.max(8,e.mesaS.y-6-X(252,77))},e.hoodoos=[{x:262,z:70,h:12},{x:255,z:65,h:18}];let a=[],o=(e,t,n={})=>a.push({id:e,...t,...n}),s=e.pillarCourse[e.pillarCourse.length-1];o(`windmill`,null,{anchor:`windmill`}),o(`pillars`,{x:s[0],y:X(s[0],s[1])+s[2]+1.2,z:s[1]},{anchor:`pillarTop`}),o(`giant_tree`,null,{anchor:`treeTop`}),o(`fox`,null,{hidden:!0}),o(`firefly`,Ym(-292,18,1.4),{night:!0}),o(`kuku`,null,{reward:!0}),o(`mia`,null,{reward:!0});let c=Rf(300,-15,15);o(`mesa_top`,{x:c.x,y:c.y+1.2,z:c.z}),o(`ring_canyon1`,null,{reward:!0}),o(`ring_canyon2`,null,{reward:!0}),o(`race`,null,{reward:!0}),o(`hoodoo`,null,{anchor:`hoodooPeak`}),o(`ring_coast`,null,{reward:!0}),o(`shipwreck`,null,{anchor:`wreckBow`}),o(`hai_fish`,null,{reward:!0}),o(`golden_fish`,null,{reward:!0}),o(`mirror1`,null,{reward:!0}),o(`mirror2`,null,{reward:!0}),o(`lake_island`,Ym(Jd[3].x,Jd[3].z,1.3)),o(`stars`,null,{reward:!0}),o(`mtn_ledge`,Ym(-6,-309,1.3)),o(`summit`,Ym(12,-246,1.3)),o(`pip1`,null,{reward:!0}),o(`pip2`,null,{reward:!0}),o(`pip3`,null,{reward:!0}),o(`ruins_puzzle`,null,{anchor:`ruinsAltar`,hidden:!0}),o(`dig1`,null,{hidden:!0}),o(`dig2`,null,{hidden:!0}),o(`dig3`,null,{hidden:!0}),e.shards=a,e.feathers=[{id:`f_village`,...Ym(-27,124,1)},{id:`f_ruins`,anchor:`ruinsPillar`},{id:`f_tree`,anchor:`treeMid`},{id:`f_dark`,...Ym(-306,-18,1.2)},{id:`f_mesaW`,...(()=>{let e=Rf(195,-57,10);return{x:e.x+3,y:X(e.x+3,e.z)+1.2,z:e.z}})()},{id:`f_hoodoo`,anchor:`hoodoo2`},{id:`f_isletSW`,...Ym(qd[2].x+4,qd[2].z,1.2)},{id:`f_stack`,anchor:`seaStack`},{id:`f_lakeisl`,...Ym(Jd[1].x,Jd[1].z,1.2)},{id:`f_lakerim`,...(()=>{let e=Rf(-190,-222,18);return{x:e.x,y:e.y+1.2,z:e.z}})()},{id:`f_band1`,...Ym(-62,-153,1.2)},{id:`f_band2`,...Ym(64,-253,1.2)},{id:`f_band3`,...Ym(-38,-257,1.2)},{id:`f_feng`,reward:!0},{id:`f_river`,anchor:`riverPillar`}],e.chests=[{id:`c_ruins`,...Ym(-131,262,0),reward:{coins:30}},{id:`c_tree`,anchor:`treeTopChest`,reward:{hat:`wizard`}},{id:`c_dark`,...Ym(-252,-32,0),reward:{map:`map3`}},{id:`c_mesaW`,...(()=>{let e=Rf(195,-57,10);return{x:e.x-2,y:X(e.x-2,e.z+2),z:e.z+2}})(),reward:{map:`map1`}},{id:`c_hoodoo`,...Ym(266,64,0),reward:{coins:40}},{id:`c_wreck`,anchor:`wreckDeck`,reward:{hat:`pirate`}},{id:`c_isletSW`,...Ym(qd[2].x-3,qd[2].z+2,0),reward:{map:`map2`}},{id:`c_lakeisl`,...Ym(Jd[2].x,Jd[2].z,0),reward:{coins:40}},{id:`c_band3`,...Ym(42,-229,0),reward:{hat:`beanie`}},{id:`c_islet`,...Ym(qd[0].x-4,qd[0].z+3,0),reward:{coins:50}}],e.digs=[{id:`dig1`,map:`map1`,...Ym(222,78,0),clue:Y(`藏宝图上画着一座红色的石拱门，拱门西南方向不远处画着一个叉。`)},{id:`dig2`,map:`map2`,...Ym(196,236,0),clue:Y(`地图上是一片沙滩和一艘歪倒的船，叉画在船的西北方、营火附近的沙地上。`)},{id:`dig3`,map:`map3`,...Ym(122,-126,0),clue:Y(`地图上画着一座圆顶的观星台，叉在它的东北方，靠近一块平地。`)}];let l=[[[0,160],[0,176],[10,186]],[[12,140],[40,122],[60,102],[70,92]],[[-20,140],[-50,120],[-66,103]],[[-40,150],[-90,140],[-140,110],[-165,60],[-170,30]],[[-5,190],[-10,240],[-10,320]],[[-60,200],[-100,235]],[[-170,20],[-150,-40],[-130,-100],[-125,-135]],[[-160,-165],[-145,-195],[-170,-220],[-210,-218]],[[60,40],[80,-40],[70,-90],[55,-95]],[[150,-20],[180,-10],[205,20],[230,55]],[[190,200],[210,230],[235,220],[250,205]],[[140,140],[175,180],[195,215]],[[60,-120],[95,-135]],[[-20,-130],[-45,-140],[-70,-170]],[[20,-150],[50,-170],[62,-200]],[[-25,-275],[5,-290],[30,-280]]],u=[],d=0;for(let e of l)for(let t=0;t<e.length-1;t++){let[n,r]=e[t],[i,a]=e[t+1],o=Math.hypot(i-n,a-r),s=Math.max(1,Math.floor(o/5));for(let e=0;e<s;e++){let t=n+(i-n)*e/s,o=r+(a-r)*e/s,c=X(t,o);c<If(t,o)+.2||u.push({id:`k`+d++,x:t,y:c+1,z:o})}}let f=(e,t,n,r,i=1)=>{for(let a=0;a<r;a++){let[o,s]=Xm(e,t,n,a/r*Math.PI*2),c=X(o,s);c>If(o,s)+.2&&u.push({id:`k`+d++,x:o,y:c+i,z:s})}};return f(Gd.lookout.x,Gd.lookout.z,6,10),f(Gd.ruins.x,Gd.ruins.z,13,14),f(Bd.x,Bd.z,Bd.r+14,26),f(Hd.x,Hd.z,104,24),f(Hd.x,Hd.z,72,18),f(Vd.x,Vd.z,40,14),f(e.arch.x,e.arch.z,14,10),e.coins=u,e.npcs={aila:{x:-4,z:145,yaw:.4},pip:{x:17,z:136,yaw:-.6},abe:{x:9,z:139.2,yaw:Math.PI},mia:{x:e.pen.x+Math.cos(e.pen.gap)*9,z:e.pen.z+Math.sin(e.pen.gap)*9,yaw:e.pen.gap+Math.PI},hai:{anchor:`dockMid`},kuku:{x:e.campfires.find(e=>e.id===`forest`).x-5,z:e.campfires.find(e=>e.id===`forest`).z-3,yaw:1},tiao:{x:e.campfires.find(e=>e.id===`canyon`).x+4,z:e.campfires.find(e=>e.id===`canyon`).z+2,yaw:-1},hoshino:{x:Gd.observatory.x-2,z:Gd.observatory.z+7,yaw:0},feng:{x:8,z:-127,yaw:Math.PI}},e.lostSheep=[Ym(96,128,0),Ym(-150,205,0),Ym(-140,150,0)],e.foxTrail=[[-150,62],[-168,40],[-192,22],[-205,-10],[-190,-40],[-178,-62]].map(([e,t])=>Ym(e,t,0)),e.glowMushrooms=[[-250,20],[-280,-30],[-300,40],[-240,-50],[-320,0]].map(([e,t],n)=>({id:`gm`+n,...Ym(e,t,0)})),e.pedestals=[`swan`,`hunter`,`dipper`].map((e,t)=>{let n=-Math.PI/2+(t-1)*.9,[r,i]=Xm(Gd.observatory.x,Gd.observatory.z,10,n+Math.PI);return{id:e,x:r,z:i}}),e.fishing=[{id:`sea`,kind:`sea`,anchor:`dockEndWater`},{id:`sea2`,kind:`sea`,...Zm(215,215,1,0,-1.5)},{id:`lake`,kind:`lake`,x:Bd.x+40,z:Bd.z+30},{id:`river`,kind:`river`,x:mf(-30),z:-30}],e.updrafts=[{x:e.seaStack.x-5,z:e.seaStack.z,r:3.5,top:16},{x:232,z:72,r:3.5,top:34},{x:mf(92)-4,z:92,r:4.5,top:25}],e}var $m=[{id:`sheep`,cat:Y(`动物`),name:Y(`绵羊`),desc:Y(`草原上最常见的居民，毛茸茸的，喜欢成群结队。`)},{id:`cat`,cat:Y(`动物`),name:Y(`团子`),desc:Y(`村里的橘猫，整天在艾拉奶奶家门口晒太阳。`)},{id:`fox`,cat:Y(`动物`),name:Y(`赤狐`),desc:Y(`森林里机灵的小狐狸，总在你靠近时跑开。`)},{id:`spiritfox`,cat:Y(`动物`),name:Y(`星光狐`),desc:Y(`浑身泛着微光的狐狸，据说会把人引向星屑。`)},{id:`deer`,cat:Y(`动物`),name:Y(`梅花鹿`),desc:Y(`胆小的森林居民，一有动静就会跑远。`)},{id:`crab`,cat:Y(`动物`),name:Y(`寄居蟹`),desc:Y(`在沙滩上横着走的小家伙。`)},{id:`seagull`,cat:Y(`动物`),name:Y(`海鸥`),desc:Y(`在海岸上空盘旋，时不时发出嘎嘎的叫声。`)},{id:`butterfly`,cat:Y(`动物`),name:Y(`花蝴蝶`),desc:Y(`白天在花丛中飞舞。`)},{id:`owl`,cat:Y(`动物`),name:Y(`夜枭`),desc:Y(`只在夜晚的森林里出现，眼睛像两盏小灯。`)},{id:`frog`,cat:Y(`动物`),name:Y(`雨蛙`),desc:Y(`下雨天会出现在水晶湖边呱呱叫。`)},{id:`goat`,cat:Y(`动物`),name:Y(`岩羊`),desc:Y(`雪山悬崖上的攀岩高手。`)},{id:`lizard`,cat:Y(`动物`),name:Y(`红岩蜥`),desc:Y(`在峡谷的岩石上晒太阳。`)},{id:`whale`,cat:Y(`动物`),name:Y(`座头鲸`),desc:Y(`偶尔在东边的海面上浮起换气，非常罕见。`)},{id:`firefly`,cat:Y(`动物`),name:Y(`萤火虫`),desc:Y(`夜晚迷雾森林里的点点亮光。`)},{id:`oak`,cat:Y(`植物`),name:Y(`橡树`),desc:Y(`草原和森林边缘的阔叶树。`)},{id:`pine`,cat:Y(`植物`),name:Y(`松树`),desc:Y(`耐寒的针叶树，长在湖边和山脚。`)},{id:`darkpine`,cat:Y(`植物`),name:Y(`雾松`),desc:Y(`迷雾森林里高大的深色松树。`)},{id:`snowpine`,cat:Y(`植物`),name:Y(`雪松`),desc:Y(`枝头挂着积雪的松树，只长在雪山高处。`)},{id:`palm`,cat:Y(`植物`),name:Y(`椰子树`),desc:Y(`海边的标志，树顶挂着椰子。`)},{id:`cactus`,cat:Y(`植物`),name:Y(`仙人掌`),desc:Y(`峡谷里的耐旱植物，有时会开粉色的花。`)},{id:`flower`,cat:Y(`植物`),name:Y(`野花`),desc:Y(`草原上五颜六色的小花。`)},{id:`sunflower`,cat:Y(`植物`),name:Y(`向日葵`),desc:Y(`总是朝着太阳的方向。`)},{id:`mushroom`,cat:Y(`植物`),name:Y(`红蘑菇`),desc:Y(`森林地面上的蘑菇，别乱吃。`)},{id:`reeds`,cat:Y(`植物`),name:Y(`芦苇`),desc:Y(`湖边浅水里的植物。`)},{id:`crystal`,cat:Y(`植物`),name:Y(`湖晶`),desc:Y(`水晶湖周围自然生长的发光晶体。`)},{id:`windmill`,cat:Y(`地标`),name:Y(`老风车`),desc:Y(`村庄的标志，阳台上能看到整片草原。`)},{id:`lighthouse`,cat:Y(`地标`),name:Y(`星屑灯塔`),desc:Y(`雪山顶上熄灭的灯塔，群岛的守护者。`)},{id:`observatory`,cat:Y(`地标`),name:Y(`星野天文台`),desc:Y(`星野先生观测星空的地方。`)},{id:`ruins`,cat:Y(`地标`),name:Y(`古代遗迹`),desc:Y(`不知是谁留下的石柱和地砖。`)},{id:`shipwreck`,cat:Y(`地标`),name:Y(`沉船`),desc:Y(`很久以前搁浅在海岸边的帆船。`)},{id:`arch`,cat:Y(`地标`),name:Y(`红石拱门`),desc:Y(`峡谷里被风雕刻出的天然拱门。`)},{id:`giantTree`,cat:Y(`地标`),name:Y(`千年古树`),desc:Y(`森林里最古老的树，树干上长满了蘑菇台阶。`)},{id:`bass`,cat:Y(`鱼类`),name:Y(`海鲈鱼`),desc:Y(`码头边最常见的鱼。`),fish:!0},{id:`mackerel`,cat:Y(`鱼类`),name:Y(`青花鱼`),desc:Y(`游得很快的海鱼。`),fish:!0},{id:`puffer`,cat:Y(`鱼类`),name:Y(`河豚`),desc:Y(`被钓上来就会鼓成一个球。`),fish:!0},{id:`golden`,cat:Y(`鱼类`),name:Y(`金鳞鱼`),desc:Y(`传说中的鱼，鳞片像星屑一样闪光。`),fish:!0},{id:`lanternfish`,cat:Y(`鱼类`),name:Y(`灯笼鱼`),desc:Y(`只在夜里浮上来的发光小鱼。`),fish:!0},{id:`trout`,cat:Y(`鱼类`),name:Y(`虹鳟`),desc:Y(`水晶湖里的冷水鱼。`),fish:!0},{id:`crystalcarp`,cat:Y(`鱼类`),name:Y(`水晶鲤`),desc:Y(`身体半透明的鲤鱼，只在水晶湖里有。`),fish:!0},{id:`salmon`,cat:Y(`鱼类`),name:Y(`鲑鱼`),desc:Y(`在河里逆流而上的鱼。`),fish:!0},{id:`catfish`,cat:Y(`鱼类`),name:Y(`鲶鱼`),desc:Y(`长着胡子的河底大鱼。`),fish:!0}],eh={sea:[{id:`bass`,w:45,diff:.3,price:8},{id:`mackerel`,w:35,diff:.4,price:10},{id:`puffer`,w:14,diff:.55,price:18},{id:`golden`,w:6,diff:.75,price:60},{id:`lanternfish`,w:25,diff:.5,price:20,night:!0}],lake:[{id:`trout`,w:65,diff:.4,price:12},{id:`crystalcarp`,w:35,diff:.6,price:25}],river:[{id:`salmon`,w:60,diff:.45,price:14},{id:`catfish`,w:40,diff:.5,price:16}]},th=[{id:`shovel`,name:Y(`小铁铲`),price:60,desc:Y(`能在藏宝图标记的地方挖宝。`),ability:`shovel`},{id:`boots`,name:Y(`弹跳靴`),price:150,desc:Y(`在空中再按一次空格可以二段跳。`),ability:`boots`},{id:`compass`,name:Y(`星屑罗盘`),price:120,desc:Y(`指向最近的、还没找到的星屑。`),ability:`compass`},{id:`cocoa`,name:Y(`热可可`),price:15,desc:Y(`暖暖的一杯，适合送给怕冷的人。`),item:`cocoa`},{id:`straw`,name:Y(`草帽`),price:30,desc:Y(`夏天必备。`),hat:`straw`},{id:`flower`,name:Y(`花环`),price:50,desc:Y(`用草原上的野花编的。`),hat:`flower`},{id:`chef`,name:Y(`厨师帽`),price:80,desc:Y(`戴上它感觉自己会做饭了。`),hat:`chef`}],nh={straw:Y(`草帽`),flower:Y(`花环`),chef:Y(`厨师帽`),pirate:Y(`海盗帽`),wizard:Y(`巫师帽`),beanie:Y(`毛线帽`),cap:Y(`跑步帽`),crown:Y(`星之王冠`)},rh={camera:Y(`相机`),glider:Y(`滑翔翼`),lantern:Y(`提灯`),rod:Y(`钓竿`),fins:Y(`脚蹼`),shovel:Y(`小铁铲`),boots:Y(`弹跳靴`),compass:Y(`星屑罗盘`)};function ih(e,t){Tf();let n=Qm(),r=new cm,i=[],a=[],o=new om(e,t);e.add(Yp());let s=nm(e),c=new _m(e,r,i),l={},u=n.village;c.well(u.well.x,u.well.z);for(let e of u.houses)c.house(e.x,e.z,e.yaw,e);c.stall(u.stall.x,u.stall.z,u.stall.yaw);let d=c.windmill(u.windmill.x,u.windmill.z);l.windmill={x:d.x+2.6,y:d.top+1.2,z:d.z+1.6},a.push({id:`windmill`,x:d.x,y:d.y+8,z:d.z,big:!0});let f=u.lamps.map(([e,t])=>c.lampPost(e,t));for(let e of u.benches)c.bench(e.x,e.z,e.yaw);i.push({x:u.well.x,z:u.well.z,r:40});for(let[e,t,r]of n.pillarCourse)c.pillar(e,t,r,1);let p=n.pillarCourse[n.pillarCourse.length-1];l.pillarTop={x:p[0],y:hm(p[0],p[1],1)+p[2]+1.2,z:p[1]},c.fenceRing(n.pen.x,n.pen.z,n.pen.r,n.pen.gap,.45),i.push({x:n.pen.x,z:n.pen.z,r:n.pen.r+3}),c.flag(n.lookout.x,n.lookout.z,15911244),c.bench(n.lookout.x+2.5,n.lookout.z+1,.8),i.push({x:n.lookout.x,z:n.lookout.z,r:6});let m=c.dock(n.dock.x,n.dock.z,n.dock.yaw,n.dock.len);l.dockEnd={x:m.end.x,y:m.y,z:m.end.z-1.5},l.dockMid={x:m.end.x-.9,y:m.y,z:m.end.z-8},l.dockEndWater={x:m.end.x+4,y:0,z:m.end.z+3},i.push({x:n.dock.x,z:n.dock.z,r:6});let h=c.ruins(n.ruins.x,n.ruins.z);l.ruins=h,l.ruinsAltar={x:h.altar.x,y:h.altar.y+1.3,z:h.altar.z},a.push({id:`ruins`,x:h.x,y:h.y+2,z:h.z,big:!0});{let e=null;for(let t of r.query(h.x,h.z,12))t.type===`cyl`&&t.walkable&&(!e||t.y1>e.y1)&&(e=t);l.ruinsPillar=e?{x:e.x,y:e.y1+1.2,z:e.z}:{x:h.x,y:h.y+3,z:h.z}}let g=c.giantTree(n.giantTree.x,n.giantTree.z);l.treeTop={x:g.x+1.5,y:g.top+1.2,z:g.z},l.treeTopChest={x:g.x-1.8,y:g.top,z:g.z+1},l.treeMid={x:g.x+Math.cos(6)*3.9,y:g.y+10.2+.17+1.2,z:g.z+Math.sin(6)*3.9},a.push({id:`giantTree`,x:g.x,y:g.y+10,z:g.z,big:!0});let _=c.arch(n.arch.x,n.arch.z,n.arch.yaw);a.push({id:`arch`,x:_.x,y:_.y+5,z:_.z,big:!0}),l.arch=_;let v=n.hoodooPeak,y=c.pillar(v.x,v.z,v.h,1.6,11821371);l.hoodooPeak={x:v.x,y:y+1.2,z:v.z},n.hoodoos.forEach((e,t)=>{let n=c.pillar(e.x,e.z,e.h,1.5,10900789);l[`hoodoo`+(t+1)]={x:e.x,y:n+1.2,z:e.z}});let b=c.shipwreck(n.shipwreck.x,n.shipwreck.z,n.shipwreck.yaw);l.wreckBow={x:b.bow.x,y:b.bow.y+1.2,z:b.bow.z},l.wreckDeck={x:b.x,y:b.y,z:b.z},a.push({id:`shipwreck`,x:b.x,y:b.y,z:b.z,big:!0});let x=n.seaStack,S=c.pillar(x.x,x.z,x.h-X(x.x,x.z),1.8,9407365);l.seaStack={x:x.x,y:S+1.2,z:x.z};let C=n.riverPillar,w=c.pillar(C.x,C.z,C.h-X(C.x,C.z),1.6,10130830);l.riverPillar={x:C.x,y:w+1.2,z:C.z};let T=c.lighthouse(n.lighthouse.x,n.lighthouse.z);a.push({id:`lighthouse`,x:T.x,y:T.y+10,z:T.z,big:!0});let E=c.observatory(n.observatory.x,n.observatory.z);return a.push({id:`observatory`,x:E.x,y:E.y+4,z:E.z,big:!0}),{content:n,colliders:r,sky:o,water:s,structures:c,anchors:l,lighthouse:T,campfires:n.campfires.map(e=>({...e,...c.campfire(e.x,e.z)})),codexSpots:a,lamps:f,scatter:wm(e,r,i,a),frontier:new Bm(e,r),grass:new Gm(e,r),ambient:new Jm(e)}}function ah(e,t){if(e.anchor){let n=t[e.anchor];if(!n)throw Error(`missing anchor `+e.anchor);return{...e,x:n.x,y:n.y,z:n.z}}return e}var oh={name:`CopyShader`,uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`},sh=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error(`THREE.Pass: .render() must be implemented in derived pass.`)}dispose(){}},ch=new ks(-1,1,1,-1,0,1),lh=new class extends Dr{constructor(){super(),this.setAttribute(`position`,new hr([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute(`uv`,new hr([0,2,0,0,2,0],2))}},uh=class{constructor(e){this._mesh=new q(lh,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,ch)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}},dh=class extends sh{constructor(e,t=`tDiffuse`){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof Ho?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=zo.clone(e.uniforms),this.material=new Ho({name:e.name===void 0?`unspecified`:e.name,defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new uh(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},fh=class extends sh{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){let r=e.getContext(),i=e.state;i.buffers.color.setMask(!1),i.buffers.depth.setMask(!1),i.buffers.color.setLocked(!0),i.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),i.buffers.stencil.setTest(!0),i.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),i.buffers.stencil.setFunc(r.ALWAYS,a,4294967295),i.buffers.stencil.setClear(o),i.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),i.buffers.color.setLocked(!1),i.buffers.depth.setLocked(!1),i.buffers.color.setMask(!0),i.buffers.depth.setMask(!0),i.buffers.stencil.setLocked(!1),i.buffers.stencil.setFunc(r.EQUAL,1,4294967295),i.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),i.buffers.stencil.setLocked(!0)}},ph=class extends sh{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}},mh=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let n=e.getSize(new H);this._width=n.width,this._height=n.height,t=new qt(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:g}),t.texture.name=`EffectComposer.rt1`}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name=`EffectComposer.rt2`,this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new dh(oh),this.copyPass.material.blending=0,this.timer=new Is}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());let t=this.renderer.getRenderTarget(),n=!1;for(let t=0,r=this.passes.length;t<r;t++){let r=this.passes[t];if(r.enabled!==!1){if(r.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(t),r.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),r.needsSwap){if(n){let t=this.renderer.getContext(),n=this.renderer.state.buffers.stencil;n.setFunc(t.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),n.setFunc(t.EQUAL,1,4294967295)}this.swapBuffers()}fh!==void 0&&(r instanceof fh?n=!0:r instanceof ph&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new H);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let e=0;e<this.passes.length;e++)this.passes[e].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}},hh=class extends sh{constructor(e,t,n=null,r=null,i=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=i,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new K}render(e,t,n){let r=e.autoClear;e.autoClear=!1;let i,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(i=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==1&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(i),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=r}},gh={name:`LuminosityHighPassShader`,uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new K(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`},_h=class e extends sh{constructor(e,t=1,n,r){super(),this.strength=t,this.radius=n,this.threshold=r,this.resolution=e===void 0?new H(256,256):new H(e.x,e.y),this.clearColor=new K(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new qt(i,a,{type:g,depthBuffer:!1}),this.renderTargetBright.texture.name=`UnrealBloomPass.bright`,this.renderTargetBright.texture.generateMipmaps=!1;for(let e=0;e<this.nMips;e++){let t=new qt(i,a,{type:g,depthBuffer:!1});t.texture.name=`UnrealBloomPass.h`+e,t.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(t);let n=new qt(i,a,{type:g,depthBuffer:!1});n.texture.name=`UnrealBloomPass.v`+e,n.texture.generateMipmaps=!1,this.renderTargetsVertical.push(n),i=Math.round(i/2),a=Math.round(a/2)}let o=gh;this.highPassUniforms=zo.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Ho({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let s=[6,10,14,18,22];i=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let e=0;e<this.nMips;e++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(s[e])),this.separableBlurMaterials[e].uniforms.invSize.value=new H(1/i,1/a),i=Math.round(i/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=zo.clone(oh.uniforms),this.blendMaterial=new Ho({uniforms:this.copyUniforms,vertexShader:oh.vertexShader,fragmentShader:oh.fragmentShader,premultipliedAlpha:!0,blending:2,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new K,this._oldClearAlpha=1,this._basic=new ii,this._fsQuad=new uh(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let e=0;e<this.nMips;e++)this.renderTargetsHorizontal[e].setSize(n,r),this.renderTargetsVertical[e].setSize(n,r),this.separableBlurMaterials[e].uniforms.invSize.value=new H(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(t,n,r,i,a){t.getClearColor(this._oldClearColor),this._oldClearAlpha=t.getClearAlpha();let o=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),a&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=r.texture,t.setRenderTarget(null),t.clear(),this._fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=r.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this._fsQuad.render(t);let s=this.renderTargetBright;for(let n=0;n<this.nMips;n++)this._fsQuad.material=this.separableBlurMaterials[n],this.separableBlurMaterials[n].uniforms.colorTexture.value=s.texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[n]),t.clear(),this._fsQuad.render(t),this.separableBlurMaterials[n].uniforms.colorTexture.value=this.renderTargetsHorizontal[n].texture,this.separableBlurMaterials[n].uniforms.direction.value=e.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[n]),t.clear(),this._fsQuad.render(t),s=this.renderTargetsVertical[n];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this._fsQuad.render(t),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,a&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this._fsQuad.render(t)):(t.setRenderTarget(r),this._fsQuad.render(t)),t.setClearColor(this._oldClearColor,this._oldClearAlpha),t.autoClear=o}_getSeparableBlurMaterial(e){let t=[],n=e/3;for(let r=0;r<e;r++)t.push(.39894*Math.exp(-.5*r*r/(n*n))/n);let r=[],i=[];for(let n=1;n<e;n+=2){let a=t[n],o=n+1<e?t[n+1]:0,s=a+o;r.push((n*a+(n+1)*o)/s),i.push(s)}return new Ho({defines:{KERNEL_PAIRS:r.length},uniforms:{colorTexture:{value:null},invSize:{value:new H(.5,.5)},direction:{value:new H(.5,.5)},centerWeight:{value:t[0]},gaussianOffsets:{value:r},gaussianWeights:{value:i}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float centerWeight;
				uniform float gaussianOffsets[KERNEL_PAIRS];
				uniform float gaussianWeights[KERNEL_PAIRS];

				void main() {

					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * centerWeight;

					for ( int i = 0; i < KERNEL_PAIRS; i ++ ) {

						vec2 uvOffset = direction * invSize * gaussianOffsets[ i ];
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * gaussianWeights[ i ];

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new Ho({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}};_h.BlurDirectionX=new H(1,0),_h.BlurDirectionY=new H(0,1);var vh={name:`GTAOShader`,defines:{PERSPECTIVE_CAMERA:1,SAMPLES:16,NORMAL_VECTOR_TYPE:1,DEPTH_SWIZZLING:`x`,SCREEN_SPACE_RADIUS:0,SCREEN_SPACE_RADIUS_SCALE:100,SCENE_CLIP_BOX:0},uniforms:{tNormal:{value:null},tDepth:{value:null},tNoise:{value:null},resolution:{value:new H},cameraNear:{value:null},cameraFar:{value:null},cameraProjectionMatrix:{value:new Xt},cameraProjectionMatrixInverse:{value:new Xt},cameraWorldMatrix:{value:new Xt},radius:{value:.25},distanceExponent:{value:1},thickness:{value:1},distanceFallOff:{value:1},scale:{value:1},sceneBoxMin:{value:new U(-1,-1,-1)},sceneBoxMax:{value:new U(1,1,1)}},vertexShader:`

		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		varying vec2 vUv;
		uniform highp sampler2D tNormal;
		uniform highp sampler2D tDepth;
		uniform sampler2D tNoise;
		uniform vec2 resolution;
		uniform float cameraNear;
		uniform float cameraFar;
		uniform mat4 cameraProjectionMatrix;
		uniform mat4 cameraProjectionMatrixInverse;
		uniform mat4 cameraWorldMatrix;
		uniform float radius;
		uniform float distanceExponent;
		uniform float thickness;
		uniform float distanceFallOff;
		uniform float scale;
		#if SCENE_CLIP_BOX == 1
			uniform vec3 sceneBoxMin;
			uniform vec3 sceneBoxMax;
		#endif

		#include <common>
		#include <packing>

		#ifndef FRAGMENT_OUTPUT
		#define FRAGMENT_OUTPUT vec4(vec3(ao), 1.)
		#endif

		vec3 getViewPosition( const in vec2 screenPosition, const in float depth ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				vec4 clipSpacePosition = vec4( vec2( screenPosition ) * 2.0 - 1.0, depth, 1.0 );
			#else
				vec4 clipSpacePosition = vec4( vec3( screenPosition, depth ) * 2.0 - 1.0, 1.0 );
			#endif
			vec4 viewSpacePosition = cameraProjectionMatrixInverse * clipSpacePosition;
			return viewSpacePosition.xyz / viewSpacePosition.w;
		}

		float getDepth(const vec2 uv) {
			return textureLod(tDepth, uv.xy, 0.0).DEPTH_SWIZZLING;
		}

		float fetchDepth(const ivec2 uv) {
			return texelFetch(tDepth, uv.xy, 0).DEPTH_SWIZZLING;
		}

		float getViewZ(const in float depth) {
			#if PERSPECTIVE_CAMERA == 1
				return perspectiveDepthToViewZ(depth, cameraNear, cameraFar);
			#else
				return orthographicDepthToViewZ(depth, cameraNear, cameraFar);
			#endif
		}

		vec3 computeNormalFromDepth(const vec2 uv) {
			vec2 size = vec2(textureSize(tDepth, 0));
			ivec2 p = ivec2(uv * size);
			float c0 = fetchDepth(p);
			float l2 = fetchDepth(p - ivec2(2, 0));
			float l1 = fetchDepth(p - ivec2(1, 0));
			float r1 = fetchDepth(p + ivec2(1, 0));
			float r2 = fetchDepth(p + ivec2(2, 0));
			float b2 = fetchDepth(p - ivec2(0, 2));
			float b1 = fetchDepth(p - ivec2(0, 1));
			float t1 = fetchDepth(p + ivec2(0, 1));
			float t2 = fetchDepth(p + ivec2(0, 2));
			float dl = abs((2.0 * l1 - l2) - c0);
			float dr = abs((2.0 * r1 - r2) - c0);
			float db = abs((2.0 * b1 - b2) - c0);
			float dt = abs((2.0 * t1 - t2) - c0);
			vec3 ce = getViewPosition(uv, c0).xyz;
			vec3 dpdx = (dl < dr) ? ce - getViewPosition((uv - vec2(1.0 / size.x, 0.0)), l1).xyz : -ce + getViewPosition((uv + vec2(1.0 / size.x, 0.0)), r1).xyz;
			vec3 dpdy = (db < dt) ? ce - getViewPosition((uv - vec2(0.0, 1.0 / size.y)), b1).xyz : -ce + getViewPosition((uv + vec2(0.0, 1.0 / size.y)), t1).xyz;
			return normalize(cross(dpdx, dpdy));
		}

		vec3 getViewNormal(const vec2 uv) {
			#if NORMAL_VECTOR_TYPE == 2
				return normalize(textureLod(tNormal, uv, 0.).rgb);
			#elif NORMAL_VECTOR_TYPE == 1
				return unpackRGBToNormal(textureLod(tNormal, uv, 0.).rgb);
			#else
				return computeNormalFromDepth(uv);
			#endif
		}

		vec3 getSceneUvAndDepth(vec3 sampleViewPos) {
			vec4 sampleClipPos = cameraProjectionMatrix * vec4(sampleViewPos, 1.);
			vec2 sampleUv = sampleClipPos.xy / sampleClipPos.w * 0.5 + 0.5;
			float sampleSceneDepth = getDepth(sampleUv);
			return vec3(sampleUv, sampleSceneDepth);
		}

		void main() {
			float depth = getDepth(vUv.xy);

			#ifdef USE_REVERSED_DEPTH_BUFFER
				if (depth <= 0.0) {
					discard;
					return;
				}
			#else
				if (depth >= 1.0) {
					discard;
					return;
				}
			#endif
			
			vec3 viewPos = getViewPosition(vUv, depth);
			vec3 viewNormal = getViewNormal(vUv);

			float radiusToUse = radius;
			float distanceFalloffToUse = thickness;
			#if SCREEN_SPACE_RADIUS == 1
				float radiusScale = getViewPosition(vec2(0.5 + float(SCREEN_SPACE_RADIUS_SCALE) / resolution.x, 0.0), depth).x;
				radiusToUse *= radiusScale;
				distanceFalloffToUse *= radiusScale;
			#endif

			#if SCENE_CLIP_BOX == 1
				vec3 worldPos = (cameraWorldMatrix * vec4(viewPos, 1.0)).xyz;
				float boxDistance = length(max(vec3(0.0), max(sceneBoxMin - worldPos, worldPos - sceneBoxMax)));
				if (boxDistance > radiusToUse) {
					discard;
					return;
				}
			#endif

			vec2 noiseResolution = vec2(textureSize(tNoise, 0));
			vec2 noiseUv = vUv * resolution / noiseResolution;
			vec4 noiseTexel = textureLod(tNoise, noiseUv, 0.0);
			vec3 randomVec = noiseTexel.xyz * 2.0 - 1.0;
			vec3 tangent = normalize(vec3(randomVec.xy, 0.));
			vec3 bitangent = vec3(-tangent.y, tangent.x, 0.);
			mat3 kernelMatrix = mat3(tangent, bitangent, vec3(0., 0., 1.));

			const int DIRECTIONS = SAMPLES < 30 ? 3 : 5;
			const int STEPS = (SAMPLES + DIRECTIONS - 1) / DIRECTIONS;
			float ao = 0.0;
			for (int i = 0; i < DIRECTIONS; ++i) {

				float angle = float(i) / float(DIRECTIONS) * PI;
				vec4 sampleDir = vec4(cos(angle), sin(angle), 0., 0.5 + 0.5 * noiseTexel.w);
				sampleDir.xyz = normalize(kernelMatrix * sampleDir.xyz);

				vec3 viewDir = normalize(-viewPos.xyz);
				vec3 sliceBitangent = normalize(cross(sampleDir.xyz, viewDir));
				vec3 sliceTangent = cross(sliceBitangent, viewDir);
				vec3 normalInSlice = normalize(viewNormal - sliceBitangent * dot(viewNormal, sliceBitangent));

				vec3 tangentToNormalInSlice = cross(normalInSlice, sliceBitangent);
				vec2 cosHorizons = vec2(dot(viewDir, tangentToNormalInSlice), dot(viewDir, -tangentToNormalInSlice));

				for (int j = 0; j < STEPS; ++j) {
					vec3 sampleViewOffset = sampleDir.xyz * radiusToUse * sampleDir.w * pow(float(j + 1) / float(STEPS), distanceExponent);

					vec3 sampleSceneUvDepth = getSceneUvAndDepth(viewPos + sampleViewOffset);
					vec3 sampleSceneViewPos = getViewPosition(sampleSceneUvDepth.xy, sampleSceneUvDepth.z);
					vec3 viewDelta = sampleSceneViewPos - viewPos;
					if (abs(viewDelta.z) < thickness) {
						float sampleCosHorizon = dot(viewDir, normalize(viewDelta));
						cosHorizons.x += max(0., (sampleCosHorizon - cosHorizons.x) * mix(1., 2. / float(j + 2), distanceFallOff));
					}

					sampleSceneUvDepth = getSceneUvAndDepth(viewPos - sampleViewOffset);
					sampleSceneViewPos = getViewPosition(sampleSceneUvDepth.xy, sampleSceneUvDepth.z);
					viewDelta = sampleSceneViewPos - viewPos;
					if (abs(viewDelta.z) < thickness) {
						float sampleCosHorizon = dot(viewDir, normalize(viewDelta));
						cosHorizons.y += max(0., (sampleCosHorizon - cosHorizons.y) * mix(1., 2. / float(j + 2), distanceFallOff));
					}
				}

				vec2 sinHorizons = sqrt(1. - cosHorizons * cosHorizons);
				float nx = dot(normalInSlice, sliceTangent);
				float ny = dot(normalInSlice, viewDir);
				float nxb = 1. / 2. * (acos(cosHorizons.y) - acos(cosHorizons.x) + sinHorizons.x * cosHorizons.x - sinHorizons.y * cosHorizons.y);
				float nyb = 1. / 2. * (2. - cosHorizons.x * cosHorizons.x - cosHorizons.y * cosHorizons.y);
				float occlusion = nx * nxb + ny * nyb;
				ao += occlusion;
			}

			ao = clamp(ao / float(DIRECTIONS), 0., 1.);
		#if SCENE_CLIP_BOX == 1
			ao = mix(ao, 1., smoothstep(0., radiusToUse, boxDistance));
		#endif
			ao = pow(ao, scale);

			gl_FragColor = FRAGMENT_OUTPUT;
		}`},yh={name:`GTAODepthShader`,defines:{PERSPECTIVE_CAMERA:1},uniforms:{tDepth:{value:null},cameraNear:{value:null},cameraFar:{value:null}},vertexShader:`
		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		uniform sampler2D tDepth;
		uniform float cameraNear;
		uniform float cameraFar;
		varying vec2 vUv;

		#include <packing>

		float getLinearDepth( const in vec2 screenPosition ) {
			#if PERSPECTIVE_CAMERA == 1
				float fragCoordZ = texture2D( tDepth, screenPosition ).x;
				float viewZ = perspectiveDepthToViewZ( fragCoordZ, cameraNear, cameraFar );
				return viewZToOrthographicDepth( viewZ, cameraNear, cameraFar );
			#else
				return texture2D( tDepth, screenPosition ).x;
			#endif
		}

		void main() {
			float depth = getLinearDepth( vUv );
			gl_FragColor = vec4( vec3( 1.0 - depth ), 1.0 );

		}`},bh={name:`GTAOBlendShader`,uniforms:{tDiffuse:{value:null},intensity:{value:1}},vertexShader:`
		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		uniform float intensity;
		uniform sampler2D tDiffuse;
		varying vec2 vUv;

		void main() {
			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = vec4(mix(vec3(1.), texel.rgb, intensity), texel.a);
		}`};function xh(t=5){let n=Math.floor(t)%2==0?Math.floor(t)+1:Math.floor(t),r=Sh(n),i=r.length,a=new Uint8Array(i*4);for(let e=0;e<i;++e){let t=r[e],n=2*Math.PI*t/i,o=new U(Math.cos(n),Math.sin(n),0).normalize();a[e*4]=(o.x*.5+.5)*255,a[e*4+1]=(o.y*.5+.5)*255,a[e*4+2]=127,a[e*4+3]=255}let o=new vi(a,n,n);return o.wrapS=e,o.wrapT=e,o.needsUpdate=!0,o}function Sh(e){let t=Math.floor(e)%2==0?Math.floor(e)+1:Math.floor(e),n=t*t,r=Array(n).fill(0),i=Math.floor(t/2),a=t-1;for(let e=1;e<=n;)i===-1&&a===t?(a=t-2,i=0):(a===t&&(a=0),i<0&&(i=t-1)),r[i*t+a]===0?(r[i*t+a]=e++,a++,i--):(a-=2,i++);return r}var Ch={name:`PoissonDenoiseShader`,defines:{SAMPLES:16,SAMPLE_VECTORS:wh(16,2,1),NORMAL_VECTOR_TYPE:1,DEPTH_VALUE_SOURCE:0},uniforms:{tDiffuse:{value:null},tNormal:{value:null},tDepth:{value:null},tNoise:{value:null},resolution:{value:new H},cameraProjectionMatrixInverse:{value:new Xt},lumaPhi:{value:5},depthPhi:{value:5},normalPhi:{value:5},radius:{value:4},index:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`

		varying vec2 vUv;

		uniform sampler2D tDiffuse;
		uniform sampler2D tNormal;
		uniform sampler2D tDepth;
		uniform sampler2D tNoise;
		uniform vec2 resolution;
		uniform mat4 cameraProjectionMatrixInverse;
		uniform float lumaPhi;
		uniform float depthPhi;
		uniform float normalPhi;
		uniform float radius;
		uniform int index;

		#include <common>
		#include <packing>

		#ifndef SAMPLE_LUMINANCE
		#define SAMPLE_LUMINANCE dot(vec3(0.2125, 0.7154, 0.0721), a)
		#endif

		#ifndef FRAGMENT_OUTPUT
		#define FRAGMENT_OUTPUT vec4(denoised, 1.)
		#endif

		float getLuminance(const in vec3 a) {
			return SAMPLE_LUMINANCE;
		}

		const vec3 poissonDisk[SAMPLES] = SAMPLE_VECTORS;

		vec3 getViewPosition( const in vec2 screenPosition, const in float depth ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				vec4 clipSpacePosition = vec4( vec2( screenPosition ) * 2.0 - 1.0, depth, 1.0 );
			#else
				vec4 clipSpacePosition = vec4( vec3( screenPosition, depth ) * 2.0 - 1.0, 1.0 );
			#endif
			vec4 viewSpacePosition = cameraProjectionMatrixInverse * clipSpacePosition;
			return viewSpacePosition.xyz / viewSpacePosition.w;
		}

		float getDepth(const vec2 uv) {
		#if DEPTH_VALUE_SOURCE == 1
			return textureLod(tDepth, uv.xy, 0.0).a;
		#else
			return textureLod(tDepth, uv.xy, 0.0).r;
		#endif
		}

		float fetchDepth(const ivec2 uv) {
			#if DEPTH_VALUE_SOURCE == 1
				return texelFetch(tDepth, uv.xy, 0).a;
			#else
				return texelFetch(tDepth, uv.xy, 0).r;
			#endif
		}

		vec3 computeNormalFromDepth(const vec2 uv) {
			vec2 size = vec2(textureSize(tDepth, 0));
			ivec2 p = ivec2(uv * size);
			float c0 = fetchDepth(p);
			float l2 = fetchDepth(p - ivec2(2, 0));
			float l1 = fetchDepth(p - ivec2(1, 0));
			float r1 = fetchDepth(p + ivec2(1, 0));
			float r2 = fetchDepth(p + ivec2(2, 0));
			float b2 = fetchDepth(p - ivec2(0, 2));
			float b1 = fetchDepth(p - ivec2(0, 1));
			float t1 = fetchDepth(p + ivec2(0, 1));
			float t2 = fetchDepth(p + ivec2(0, 2));
			float dl = abs((2.0 * l1 - l2) - c0);
			float dr = abs((2.0 * r1 - r2) - c0);
			float db = abs((2.0 * b1 - b2) - c0);
			float dt = abs((2.0 * t1 - t2) - c0);
			vec3 ce = getViewPosition(uv, c0).xyz;
			vec3 dpdx = (dl < dr) ?  ce - getViewPosition((uv - vec2(1.0 / size.x, 0.0)), l1).xyz
									: -ce + getViewPosition((uv + vec2(1.0 / size.x, 0.0)), r1).xyz;
			vec3 dpdy = (db < dt) ?  ce - getViewPosition((uv - vec2(0.0, 1.0 / size.y)), b1).xyz
									: -ce + getViewPosition((uv + vec2(0.0, 1.0 / size.y)), t1).xyz;
			return normalize(cross(dpdx, dpdy));
		}

		vec3 getViewNormal(const vec2 uv) {
		#if NORMAL_VECTOR_TYPE == 2
			return normalize(textureLod(tNormal, uv, 0.).rgb);
		#elif NORMAL_VECTOR_TYPE == 1
			return unpackRGBToNormal(textureLod(tNormal, uv, 0.).rgb);
		#else
			return computeNormalFromDepth(uv);
		#endif
		}

		void denoiseSample(in vec3 center, in vec3 viewNormal, in vec3 viewPos, in vec2 sampleUv, inout vec3 denoised, inout float totalWeight) {
			vec4 sampleTexel = textureLod(tDiffuse, sampleUv, 0.0);
			float sampleDepth = getDepth(sampleUv);
			vec3 sampleNormal = getViewNormal(sampleUv);
			vec3 neighborColor = sampleTexel.rgb;
			vec3 viewPosSample = getViewPosition(sampleUv, sampleDepth);

			float normalDiff = dot(viewNormal, sampleNormal);
			float normalSimilarity = pow(max(normalDiff, 0.), normalPhi);
			float lumaDiff = abs(getLuminance(neighborColor) - getLuminance(center));
			float lumaSimilarity = max(1.0 - lumaDiff / lumaPhi, 0.0);
			float depthDiff = abs(dot(viewPos - viewPosSample, viewNormal));
			float depthSimilarity = max(1. - depthDiff / depthPhi, 0.);
			float w = lumaSimilarity * depthSimilarity * normalSimilarity;

			denoised += w * neighborColor;
			totalWeight += w;
		}

		void main() {
			float depth = getDepth(vUv.xy);
			vec3 viewNormal = getViewNormal(vUv);
			if (depth == 1. || dot(viewNormal, viewNormal) == 0.) {
				discard;
				return;
			}
			vec4 texel = textureLod(tDiffuse, vUv, 0.0);
			vec3 center = texel.rgb;
			vec3 viewPos = getViewPosition(vUv, depth);

			vec2 noiseResolution = vec2(textureSize(tNoise, 0));
			vec2 noiseUv = vUv * resolution / noiseResolution;
			vec4 noiseTexel = textureLod(tNoise, noiseUv, 0.0);
      		vec2 noiseVec = vec2(sin(noiseTexel[index % 4] * 2. * PI), cos(noiseTexel[index % 4] * 2. * PI));
    		mat2 rotationMatrix = mat2(noiseVec.x, -noiseVec.y, noiseVec.x, noiseVec.y);

			float totalWeight = 1.0;
			vec3 denoised = texel.rgb;
			for (int i = 0; i < SAMPLES; i++) {
				vec3 sampleDir = poissonDisk[i];
				vec2 offset = rotationMatrix * (sampleDir.xy * (1. + sampleDir.z * (radius - 1.)) / resolution);
				vec2 sampleUv = vUv + offset;
				denoiseSample(center, viewNormal, viewPos, sampleUv, denoised, totalWeight);
			}

			if (totalWeight > 0.) {
				denoised /= totalWeight;
			}
			gl_FragColor = FRAGMENT_OUTPUT;
		}`};function wh(e,t,n){let r=Th(e,t,n),i=`vec3[SAMPLES](`;for(let t=0;t<e;t++){let n=r[t];i+=`vec3(${n.x}, ${n.y}, ${n.z})${t<e-1?`,`:`)`}`}return i}function Th(e,t,n){let r=[];for(let i=0;i<e;i++){let a=2*Math.PI*t*i/e,o=(i/(e-1))**n;r.push(new U(Math.cos(a),Math.sin(a),o))}return r}var Eh=class{constructor(e=Math){this.grad3=[[1,1,0],[-1,1,0],[1,-1,0],[-1,-1,0],[1,0,1],[-1,0,1],[1,0,-1],[-1,0,-1],[0,1,1],[0,-1,1],[0,1,-1],[0,-1,-1]],this.grad4=[[0,1,1,1],[0,1,1,-1],[0,1,-1,1],[0,1,-1,-1],[0,-1,1,1],[0,-1,1,-1],[0,-1,-1,1],[0,-1,-1,-1],[1,0,1,1],[1,0,1,-1],[1,0,-1,1],[1,0,-1,-1],[-1,0,1,1],[-1,0,1,-1],[-1,0,-1,1],[-1,0,-1,-1],[1,1,0,1],[1,1,0,-1],[1,-1,0,1],[1,-1,0,-1],[-1,1,0,1],[-1,1,0,-1],[-1,-1,0,1],[-1,-1,0,-1],[1,1,1,0],[1,1,-1,0],[1,-1,1,0],[1,-1,-1,0],[-1,1,1,0],[-1,1,-1,0],[-1,-1,1,0],[-1,-1,-1,0]],this.p=[];for(let t=0;t<256;t++)this.p[t]=Math.floor(e.random()*256);this.perm=[];for(let e=0;e<512;e++)this.perm[e]=this.p[e&255];this.simplex=[[0,1,2,3],[0,1,3,2],[0,0,0,0],[0,2,3,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,2,3,0],[0,2,1,3],[0,0,0,0],[0,3,1,2],[0,3,2,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,3,2,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,2,0,3],[0,0,0,0],[1,3,0,2],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,3,0,1],[2,3,1,0],[1,0,2,3],[1,0,3,2],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,0,3,1],[0,0,0,0],[2,1,3,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,0,1,3],[0,0,0,0],[0,0,0,0],[0,0,0,0],[3,0,1,2],[3,0,2,1],[0,0,0,0],[3,1,2,0],[2,1,0,3],[0,0,0,0],[0,0,0,0],[0,0,0,0],[3,1,0,2],[0,0,0,0],[3,2,0,1],[3,2,1,0]]}noise(e,t){let n,r,i,a=.5*(Math.sqrt(3)-1),o=(e+t)*a,s=Math.floor(e+o),c=Math.floor(t+o),l=(3-Math.sqrt(3))/6,u=(s+c)*l,d=s-u,f=c-u,p=e-d,m=t-f,h,g;p>m?(h=1,g=0):(h=0,g=1);let _=p-h+l,v=m-g+l,y=p-1+2*l,b=m-1+2*l,x=s&255,S=c&255,C=this.perm[x+this.perm[S]]%12,w=this.perm[x+h+this.perm[S+g]]%12,T=this.perm[x+1+this.perm[S+1]]%12,E=.5-p*p-m*m;E<0?n=0:(E*=E,n=E*E*this._dot(this.grad3[C],p,m));let D=.5-_*_-v*v;D<0?r=0:(D*=D,r=D*D*this._dot(this.grad3[w],_,v));let O=.5-y*y-b*b;return O<0?i=0:(O*=O,i=O*O*this._dot(this.grad3[T],y,b)),70*(n+r+i)}noise3d(e,t,n){let r,i,a,o,s=(e+t+n)*(1/3),c=Math.floor(e+s),l=Math.floor(t+s),u=Math.floor(n+s),d=1/6,f=(c+l+u)*d,p=c-f,m=l-f,h=u-f,g=e-p,_=t-m,v=n-h,y,b,x,S,C,w;g>=_?_>=v?(y=1,b=0,x=0,S=1,C=1,w=0):g>=v?(y=1,b=0,x=0,S=1,C=0,w=1):(y=0,b=0,x=1,S=1,C=0,w=1):_<v?(y=0,b=0,x=1,S=0,C=1,w=1):g<v?(y=0,b=1,x=0,S=0,C=1,w=1):(y=0,b=1,x=0,S=1,C=1,w=0);let T=g-y+d,E=_-b+d,D=v-x+d,O=g-S+2*d,k=_-C+2*d,A=v-w+2*d,j=g-1+3*d,M=_-1+3*d,ee=v-1+3*d,N=c&255,P=l&255,F=u&255,te=this.perm[N+this.perm[P+this.perm[F]]]%12,ne=this.perm[N+y+this.perm[P+b+this.perm[F+x]]]%12,re=this.perm[N+S+this.perm[P+C+this.perm[F+w]]]%12,ie=this.perm[N+1+this.perm[P+1+this.perm[F+1]]]%12,ae=.6-g*g-_*_-v*v;ae<0?r=0:(ae*=ae,r=ae*ae*this._dot3(this.grad3[te],g,_,v));let oe=.6-T*T-E*E-D*D;oe<0?i=0:(oe*=oe,i=oe*oe*this._dot3(this.grad3[ne],T,E,D));let se=.6-O*O-k*k-A*A;se<0?a=0:(se*=se,a=se*se*this._dot3(this.grad3[re],O,k,A));let I=.6-j*j-M*M-ee*ee;return I<0?o=0:(I*=I,o=I*I*this._dot3(this.grad3[ie],j,M,ee)),32*(r+i+a+o)}noise4d(e,t,n,r){let i=this.grad4,a=this.simplex,o=this.perm,s=(Math.sqrt(5)-1)/4,c=(5-Math.sqrt(5))/20,l,u,d,f,p,m=(e+t+n+r)*s,h=Math.floor(e+m),g=Math.floor(t+m),_=Math.floor(n+m),v=Math.floor(r+m),y=(h+g+_+v)*c,b=h-y,x=g-y,S=_-y,C=v-y,w=e-b,T=t-x,E=n-S,D=r-C,O=w>T?32:0,k=w>E?16:0,A=T>E?8:0,j=w>D?4:0,M=T>D?2:0,ee=+(E>D),N=O+k+A+j+M+ee,P=+(a[N][0]>=3),F=+(a[N][1]>=3),te=+(a[N][2]>=3),ne=+(a[N][3]>=3),re=+(a[N][0]>=2),ie=+(a[N][1]>=2),ae=+(a[N][2]>=2),oe=+(a[N][3]>=2),se=+(a[N][0]>=1),I=+(a[N][1]>=1),ce=+(a[N][2]>=1),le=+(a[N][3]>=1),ue=w-P+c,de=T-F+c,fe=E-te+c,pe=D-ne+c,me=w-re+2*c,he=T-ie+2*c,ge=E-ae+2*c,_e=D-oe+2*c,ve=w-se+3*c,ye=T-I+3*c,be=E-ce+3*c,xe=D-le+3*c,Se=w-1+4*c,Ce=T-1+4*c,we=E-1+4*c,Te=D-1+4*c,Ee=h&255,De=g&255,Oe=_&255,ke=v&255,Ae=o[Ee+o[De+o[Oe+o[ke]]]]%32,je=o[Ee+P+o[De+F+o[Oe+te+o[ke+ne]]]]%32,L=o[Ee+re+o[De+ie+o[Oe+ae+o[ke+oe]]]]%32,Me=o[Ee+se+o[De+I+o[Oe+ce+o[ke+le]]]]%32,Ne=o[Ee+1+o[De+1+o[Oe+1+o[ke+1]]]]%32,Pe=.6-w*w-T*T-E*E-D*D;Pe<0?l=0:(Pe*=Pe,l=Pe*Pe*this._dot4(i[Ae],w,T,E,D));let R=.6-ue*ue-de*de-fe*fe-pe*pe;R<0?u=0:(R*=R,u=R*R*this._dot4(i[je],ue,de,fe,pe));let Fe=.6-me*me-he*he-ge*ge-_e*_e;Fe<0?d=0:(Fe*=Fe,d=Fe*Fe*this._dot4(i[L],me,he,ge,_e));let z=.6-ve*ve-ye*ye-be*be-xe*xe;z<0?f=0:(z*=z,f=z*z*this._dot4(i[Me],ve,ye,be,xe));let Ie=.6-Se*Se-Ce*Ce-we*we-Te*Te;return Ie<0?p=0:(Ie*=Ie,p=Ie*Ie*this._dot4(i[Ne],Se,Ce,we,Te)),27*(l+u+d+f+p)}_dot(e,t,n){return e[0]*t+e[1]*n}_dot3(e,t,n,r){return e[0]*t+e[1]*n+e[2]*r}_dot4(e,t,n,r,i){return e[0]*t+e[1]*n+e[2]*r+e[3]*i}},Dh=class t extends sh{constructor(e,t,n=512,r=512,i,a,o){super(),this.width=n,this.height=r,this.clear=!0,this.camera=t,this.scene=e,this.output=0,this._renderGBuffer=!0,this._visibilityCache=[],this.blendIntensity=1,this.pdRings=2,this.pdRadiusExponent=2,this.pdSamples=16,this.gtaoNoiseTexture=xh(),this.pdNoiseTexture=this._generateNoise(),this.gtaoRenderTarget=new qt(this.width,this.height,{type:g,depthBuffer:!1}),this.pdRenderTarget=this.gtaoRenderTarget.clone(),this.gtaoMaterial=new Ho({defines:Object.assign({},vh.defines),uniforms:zo.clone(vh.uniforms),vertexShader:vh.vertexShader,fragmentShader:vh.fragmentShader,blending:0,depthTest:!1,depthWrite:!1}),this.gtaoMaterial.defines.PERSPECTIVE_CAMERA=+!!this.camera.isPerspectiveCamera,this.gtaoMaterial.uniforms.tNoise.value=this.gtaoNoiseTexture,this.gtaoMaterial.uniforms.resolution.value.set(this.width,this.height),this.gtaoMaterial.uniforms.cameraNear.value=this.camera.near,this.gtaoMaterial.uniforms.cameraFar.value=this.camera.far,this.normalMaterial=new Go,this.normalMaterial.blending=0,this.pdMaterial=new Ho({defines:Object.assign({},Ch.defines),uniforms:zo.clone(Ch.uniforms),vertexShader:Ch.vertexShader,fragmentShader:Ch.fragmentShader,depthTest:!1,depthWrite:!1}),this.pdMaterial.uniforms.tDiffuse.value=this.gtaoRenderTarget.texture,this.pdMaterial.uniforms.tNoise.value=this.pdNoiseTexture,this.pdMaterial.uniforms.resolution.value.set(this.width,this.height),this.pdMaterial.uniforms.lumaPhi.value=10,this.pdMaterial.uniforms.depthPhi.value=2,this.pdMaterial.uniforms.normalPhi.value=3,this.pdMaterial.uniforms.radius.value=8,this.depthRenderMaterial=new Ho({defines:Object.assign({},yh.defines),uniforms:zo.clone(yh.uniforms),vertexShader:yh.vertexShader,fragmentShader:yh.fragmentShader,blending:0}),this.depthRenderMaterial.uniforms.cameraNear.value=this.camera.near,this.depthRenderMaterial.uniforms.cameraFar.value=this.camera.far,this.copyMaterial=new Ho({uniforms:zo.clone(oh.uniforms),vertexShader:oh.vertexShader,fragmentShader:oh.fragmentShader,transparent:!0,depthTest:!1,depthWrite:!1,blendSrc:208,blendDst:200,blendEquation:100,blendSrcAlpha:206,blendDstAlpha:200,blendEquationAlpha:100}),this.blendMaterial=new Ho({uniforms:zo.clone(bh.uniforms),vertexShader:bh.vertexShader,fragmentShader:bh.fragmentShader,transparent:!0,depthTest:!1,depthWrite:!1,blending:5,blendSrc:208,blendDst:200,blendEquation:100,blendSrcAlpha:206,blendDstAlpha:200,blendEquationAlpha:100}),this._fsQuad=new uh(null),this._originalClearColor=new K,this.setGBuffer(i?i.depthTexture:void 0,i?i.normalTexture:void 0),a!==void 0&&this.updateGtaoMaterial(a),o!==void 0&&this.updatePdMaterial(o)}setSize(e,t){this.width=e,this.height=t,this.gtaoRenderTarget.setSize(e,t),this.normalRenderTarget.setSize(e,t),this.pdRenderTarget.setSize(e,t),this.gtaoMaterial.uniforms.resolution.value.set(e,t),this.gtaoMaterial.uniforms.cameraProjectionMatrix.value.copy(this.camera.projectionMatrix),this.gtaoMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this.pdMaterial.uniforms.resolution.value.set(e,t),this.pdMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse)}dispose(){this.gtaoNoiseTexture.dispose(),this.pdNoiseTexture.dispose(),this.normalRenderTarget.dispose(),this.gtaoRenderTarget.dispose(),this.pdRenderTarget.dispose(),this.normalMaterial.dispose(),this.pdMaterial.dispose(),this.copyMaterial.dispose(),this.depthRenderMaterial.dispose(),this._fsQuad.dispose()}get gtaoMap(){return this.pdRenderTarget.texture}setGBuffer(e,t){e===void 0?(this.depthTexture=new ea,this.depthTexture.format=E,this.depthTexture.type=y,this.normalRenderTarget=new qt(this.width,this.height,{minFilter:r,magFilter:r,type:g,depthTexture:this.depthTexture}),this.normalTexture=this.normalRenderTarget.texture,this._renderGBuffer=!0):(this.depthTexture=e,this.normalTexture=t,this._renderGBuffer=!1);let n=+!!this.normalTexture,i=this.depthTexture===this.normalTexture?`w`:`x`;this.gtaoMaterial.defines.NORMAL_VECTOR_TYPE=n,this.gtaoMaterial.defines.DEPTH_SWIZZLING=i,this.gtaoMaterial.uniforms.tNormal.value=this.normalTexture,this.gtaoMaterial.uniforms.tDepth.value=this.depthTexture,this.pdMaterial.defines.NORMAL_VECTOR_TYPE=n,this.pdMaterial.defines.DEPTH_SWIZZLING=i,this.pdMaterial.uniforms.tNormal.value=this.normalTexture,this.pdMaterial.uniforms.tDepth.value=this.depthTexture,this.depthRenderMaterial.uniforms.tDepth.value=this.normalRenderTarget.depthTexture}setSceneClipBox(e){e?(this.gtaoMaterial.needsUpdate=this.gtaoMaterial.defines.SCENE_CLIP_BOX!==1,this.gtaoMaterial.defines.SCENE_CLIP_BOX=1,this.gtaoMaterial.uniforms.sceneBoxMin.value.copy(e.min),this.gtaoMaterial.uniforms.sceneBoxMax.value.copy(e.max)):(this.gtaoMaterial.needsUpdate=this.gtaoMaterial.defines.SCENE_CLIP_BOX===0,this.gtaoMaterial.defines.SCENE_CLIP_BOX=0)}updateGtaoMaterial(e){e.radius!==void 0&&(this.gtaoMaterial.uniforms.radius.value=e.radius),e.distanceExponent!==void 0&&(this.gtaoMaterial.uniforms.distanceExponent.value=e.distanceExponent),e.thickness!==void 0&&(this.gtaoMaterial.uniforms.thickness.value=e.thickness),e.distanceFallOff!==void 0&&(this.gtaoMaterial.uniforms.distanceFallOff.value=e.distanceFallOff,this.gtaoMaterial.needsUpdate=!0),e.scale!==void 0&&(this.gtaoMaterial.uniforms.scale.value=e.scale),e.samples!==void 0&&e.samples!==this.gtaoMaterial.defines.SAMPLES&&(this.gtaoMaterial.defines.SAMPLES=e.samples,this.gtaoMaterial.needsUpdate=!0),e.screenSpaceRadius!==void 0&&+!!e.screenSpaceRadius!==this.gtaoMaterial.defines.SCREEN_SPACE_RADIUS&&(this.gtaoMaterial.defines.SCREEN_SPACE_RADIUS=+!!e.screenSpaceRadius,this.gtaoMaterial.needsUpdate=!0)}updatePdMaterial(e){let t=!1;e.lumaPhi!==void 0&&(this.pdMaterial.uniforms.lumaPhi.value=e.lumaPhi),e.depthPhi!==void 0&&(this.pdMaterial.uniforms.depthPhi.value=e.depthPhi),e.normalPhi!==void 0&&(this.pdMaterial.uniforms.normalPhi.value=e.normalPhi),e.radius!==void 0&&e.radius!==this.radius&&(this.pdMaterial.uniforms.radius.value=e.radius),e.radiusExponent!==void 0&&e.radiusExponent!==this.pdRadiusExponent&&(this.pdRadiusExponent=e.radiusExponent,t=!0),e.rings!==void 0&&e.rings!==this.pdRings&&(this.pdRings=e.rings,t=!0),e.samples!==void 0&&e.samples!==this.pdSamples&&(this.pdSamples=e.samples,t=!0),t&&(this.pdMaterial.defines.SAMPLES=this.pdSamples,this.pdMaterial.defines.SAMPLE_VECTORS=wh(this.pdSamples,this.pdRings,this.pdRadiusExponent),this.pdMaterial.needsUpdate=!0)}render(e,n,r){switch(this._renderGBuffer&&(this._overrideVisibility(),this._renderOverride(e,this.normalMaterial,this.normalRenderTarget,7829503,1),this._restoreVisibility()),this.gtaoMaterial.uniforms.cameraNear.value=this.camera.near,this.gtaoMaterial.uniforms.cameraFar.value=this.camera.far,this.gtaoMaterial.uniforms.cameraProjectionMatrix.value.copy(this.camera.projectionMatrix),this.gtaoMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this.gtaoMaterial.uniforms.cameraWorldMatrix.value.copy(this.camera.matrixWorld),this._renderPass(e,this.gtaoMaterial,this.gtaoRenderTarget,16777215,1),this.pdMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this._renderPass(e,this.pdMaterial,this.pdRenderTarget,16777215,1),this.output){case t.OUTPUT.Off:break;case t.OUTPUT.Diffuse:this.copyMaterial.uniforms.tDiffuse.value=r.texture,this.copyMaterial.blending=0,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:n);break;case t.OUTPUT.AO:this.copyMaterial.uniforms.tDiffuse.value=this.gtaoRenderTarget.texture,this.copyMaterial.blending=0,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:n);break;case t.OUTPUT.Denoise:this.copyMaterial.uniforms.tDiffuse.value=this.pdRenderTarget.texture,this.copyMaterial.blending=0,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:n);break;case t.OUTPUT.Depth:this.depthRenderMaterial.uniforms.cameraNear.value=this.camera.near,this.depthRenderMaterial.uniforms.cameraFar.value=this.camera.far,this._renderPass(e,this.depthRenderMaterial,this.renderToScreen?null:n);break;case t.OUTPUT.Normal:this.copyMaterial.uniforms.tDiffuse.value=this.normalRenderTarget.texture,this.copyMaterial.blending=0,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:n);break;case t.OUTPUT.Default:this.copyMaterial.uniforms.tDiffuse.value=r.texture,this.copyMaterial.blending=0,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:n),this.blendMaterial.uniforms.intensity.value=this.blendIntensity,this.blendMaterial.uniforms.tDiffuse.value=this.pdRenderTarget.texture,this._renderPass(e,this.blendMaterial,this.renderToScreen?null:n);break;default:console.warn(`THREE.GTAOPass: Unknown output type.`)}}_renderPass(e,t,n,r,i){e.getClearColor(this._originalClearColor);let a=e.getClearAlpha(),o=e.autoClear;e.setRenderTarget(n),e.autoClear=!1,r!=null&&(e.setClearColor(r),e.setClearAlpha(i||0),e.clear()),this._fsQuad.material=t,this._fsQuad.render(e),e.autoClear=o,e.setClearColor(this._originalClearColor),e.setClearAlpha(a)}_renderOverride(e,t,n,r,i){e.getClearColor(this._originalClearColor);let a=e.getClearAlpha(),o=e.autoClear;e.setRenderTarget(n),e.autoClear=!1,r=t.clearColor||r,i=t.clearAlpha||i,r!=null&&(e.setClearColor(r),e.setClearAlpha(i||0),e.clear()),this.scene.overrideMaterial=t,e.render(this.scene,this.camera),this.scene.overrideMaterial=null,e.autoClear=o,e.setClearColor(this._originalClearColor),e.setClearAlpha(a)}_overrideVisibility(){let e=this.scene,t=this._visibilityCache;e.traverse(function(e){(e.isPoints||e.isLine||e.isLine2)&&e.visible&&(e.visible=!1,t.push(e))})}_restoreVisibility(){let e=this._visibilityCache;for(let t=0;t<e.length;t++)e[t].visible=!0;e.length=0}_generateNoise(t=64){let n=new Eh,r=t*t*4,i=new Uint8Array(r);for(let e=0;e<t;e++)for(let r=0;r<t;r++){let a=e,o=r;i[(e*t+r)*4]=(n.noise(a,o)*.5+.5)*255,i[(e*t+r)*4+1]=(n.noise(a+t,o)*.5+.5)*255,i[(e*t+r)*4+2]=(n.noise(a,o+t)*.5+.5)*255,i[(e*t+r)*4+3]=(n.noise(a+t,o+t)*.5+.5)*255}let a=new vi(i,t,t,w,l);return a.wrapS=e,a.wrapT=e,a.needsUpdate=!0,a}};Dh.OUTPUT={Off:-1,Default:0,Diffuse:1,Depth:2,Normal:3,AO:4,Denoise:5};var Oh={name:`SMAAEdgesShader`,defines:{SMAA_THRESHOLD:`0.1`},uniforms:{tDiffuse:{value:null},resolution:{value:new H(1/1024,1/512)}},vertexShader:`

		uniform vec2 resolution;

		varying vec2 vUv;
		varying vec4 vOffset[ 3 ];

		void SMAAEdgeDetectionVS( vec2 texcoord ) {
			vOffset[ 0 ] = texcoord.xyxy + resolution.xyxy * vec4( -1.0, 0.0, 0.0,  1.0 ); // WebGL port note: Changed sign in W component
			vOffset[ 1 ] = texcoord.xyxy + resolution.xyxy * vec4(  1.0, 0.0, 0.0, -1.0 ); // WebGL port note: Changed sign in W component
			vOffset[ 2 ] = texcoord.xyxy + resolution.xyxy * vec4( -2.0, 0.0, 0.0,  2.0 ); // WebGL port note: Changed sign in W component
		}

		void main() {

			vUv = uv;

			SMAAEdgeDetectionVS( vUv );

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;

		varying vec2 vUv;
		varying vec4 vOffset[ 3 ];

		vec4 SMAAColorEdgeDetectionPS( vec2 texcoord, vec4 offset[3], sampler2D colorTex ) {
			vec2 threshold = vec2( SMAA_THRESHOLD, SMAA_THRESHOLD );

			// Calculate color deltas:
			vec4 delta;
			vec3 C = texture2D( colorTex, texcoord ).rgb;

			vec3 Cleft = texture2D( colorTex, offset[0].xy ).rgb;
			vec3 t = abs( C - Cleft );
			delta.x = max( max( t.r, t.g ), t.b );

			vec3 Ctop = texture2D( colorTex, offset[0].zw ).rgb;
			t = abs( C - Ctop );
			delta.y = max( max( t.r, t.g ), t.b );

			// We do the usual threshold:
			vec2 edges = step( threshold, delta.xy );

			// Then discard if there is no edge:
			if ( dot( edges, vec2( 1.0, 1.0 ) ) == 0.0 )
				discard;

			// Calculate right and bottom deltas:
			vec3 Cright = texture2D( colorTex, offset[1].xy ).rgb;
			t = abs( C - Cright );
			delta.z = max( max( t.r, t.g ), t.b );

			vec3 Cbottom  = texture2D( colorTex, offset[1].zw ).rgb;
			t = abs( C - Cbottom );
			delta.w = max( max( t.r, t.g ), t.b );

			// Calculate the maximum delta in the direct neighborhood:
			float maxDelta = max( max( max( delta.x, delta.y ), delta.z ), delta.w );

			// Calculate left-left and top-top deltas:
			vec3 Cleftleft  = texture2D( colorTex, offset[2].xy ).rgb;
			t = abs( C - Cleftleft );
			delta.z = max( max( t.r, t.g ), t.b );

			vec3 Ctoptop = texture2D( colorTex, offset[2].zw ).rgb;
			t = abs( C - Ctoptop );
			delta.w = max( max( t.r, t.g ), t.b );

			// Calculate the final maximum delta:
			maxDelta = max( max( maxDelta, delta.z ), delta.w );

			// Local contrast adaptation in action:
			edges.xy *= step( 0.5 * maxDelta, delta.xy );

			return vec4( edges, 0.0, 0.0 );
		}

		void main() {

			gl_FragColor = SMAAColorEdgeDetectionPS( vUv, vOffset, tDiffuse );

		}`},kh={name:`SMAAWeightsShader`,defines:{SMAA_MAX_SEARCH_STEPS:`8`,SMAA_AREATEX_MAX_DISTANCE:`16`,SMAA_AREATEX_PIXEL_SIZE:`( 1.0 / vec2( 160.0, 560.0 ) )`,SMAA_AREATEX_SUBTEX_SIZE:`( 1.0 / 7.0 )`},uniforms:{tDiffuse:{value:null},tArea:{value:null},tSearch:{value:null},resolution:{value:new H(1/1024,1/512)}},vertexShader:`

		uniform vec2 resolution;

		varying vec2 vUv;
		varying vec4 vOffset[ 3 ];
		varying vec2 vPixcoord;

		void SMAABlendingWeightCalculationVS( vec2 texcoord ) {
			vPixcoord = texcoord / resolution;

			// We will use these offsets for the searches later on (see @PSEUDO_GATHER4):
			vOffset[ 0 ] = texcoord.xyxy + resolution.xyxy * vec4( -0.25, 0.125, 1.25, 0.125 ); // WebGL port note: Changed sign in Y and W components
			vOffset[ 1 ] = texcoord.xyxy + resolution.xyxy * vec4( -0.125, 0.25, -0.125, -1.25 ); // WebGL port note: Changed sign in Y and W components

			// And these for the searches, they indicate the ends of the loops:
			vOffset[ 2 ] = vec4( vOffset[ 0 ].xz, vOffset[ 1 ].yw ) + vec4( -2.0, 2.0, -2.0, 2.0 ) * resolution.xxyy * float( SMAA_MAX_SEARCH_STEPS );

		}

		void main() {

			vUv = uv;

			SMAABlendingWeightCalculationVS( vUv );

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		#define SMAASampleLevelZeroOffset( tex, coord, offset ) texture2D( tex, coord + float( offset ) * resolution, 0.0 )

		uniform sampler2D tDiffuse;
		uniform sampler2D tArea;
		uniform sampler2D tSearch;
		uniform vec2 resolution;

		varying vec2 vUv;
		varying vec4 vOffset[3];
		varying vec2 vPixcoord;

		#if __VERSION__ == 100
		vec2 round( vec2 x ) {
			return sign( x ) * floor( abs( x ) + 0.5 );
		}
		#endif

		float SMAASearchLength( sampler2D searchTex, vec2 e, float bias, float scale ) {
			// Not required if searchTex accesses are set to point:
			// float2 SEARCH_TEX_PIXEL_SIZE = 1.0 / float2(66.0, 33.0);
			// e = float2(bias, 0.0) + 0.5 * SEARCH_TEX_PIXEL_SIZE +
			//     e * float2(scale, 1.0) * float2(64.0, 32.0) * SEARCH_TEX_PIXEL_SIZE;
			e.r = bias + e.r * scale;
			return 255.0 * texture2D( searchTex, e, 0.0 ).r;
		}

		float SMAASearchXLeft( sampler2D edgesTex, sampler2D searchTex, vec2 texcoord, float end ) {
			/**
				* @PSEUDO_GATHER4
				* This texcoord has been offset by (-0.25, -0.125) in the vertex shader to
				* sample between edge, thus fetching four edges in a row.
				* Sampling with different offsets in each direction allows to disambiguate
				* which edges are active from the four fetched ones.
				*/
			vec2 e = vec2( 0.0, 1.0 );

			for ( int i = 0; i < SMAA_MAX_SEARCH_STEPS; i ++ ) { // WebGL port note: Changed while to for
				e = texture2D( edgesTex, texcoord, 0.0 ).rg;
				texcoord -= vec2( 2.0, 0.0 ) * resolution;
				if ( ! ( texcoord.x > end && e.g > 0.8281 && e.r == 0.0 ) ) break;
			}

			// We correct the previous (-0.25, -0.125) offset we applied:
			texcoord.x += 0.25 * resolution.x;

			// The searches are bias by 1, so adjust the coords accordingly:
			texcoord.x += resolution.x;

			// Disambiguate the length added by the last step:
			texcoord.x += 2.0 * resolution.x; // Undo last step
			texcoord.x -= resolution.x * SMAASearchLength(searchTex, e, 0.0, 0.5);

			return texcoord.x;
		}

		float SMAASearchXRight( sampler2D edgesTex, sampler2D searchTex, vec2 texcoord, float end ) {
			vec2 e = vec2( 0.0, 1.0 );

			for ( int i = 0; i < SMAA_MAX_SEARCH_STEPS; i ++ ) { // WebGL port note: Changed while to for
				e = texture2D( edgesTex, texcoord, 0.0 ).rg;
				texcoord += vec2( 2.0, 0.0 ) * resolution;
				if ( ! ( texcoord.x < end && e.g > 0.8281 && e.r == 0.0 ) ) break;
			}

			texcoord.x -= 0.25 * resolution.x;
			texcoord.x -= resolution.x;
			texcoord.x -= 2.0 * resolution.x;
			texcoord.x += resolution.x * SMAASearchLength( searchTex, e, 0.5, 0.5 );

			return texcoord.x;
		}

		float SMAASearchYUp( sampler2D edgesTex, sampler2D searchTex, vec2 texcoord, float end ) {
			vec2 e = vec2( 1.0, 0.0 );

			for ( int i = 0; i < SMAA_MAX_SEARCH_STEPS; i ++ ) { // WebGL port note: Changed while to for
				e = texture2D( edgesTex, texcoord, 0.0 ).rg;
				texcoord += vec2( 0.0, 2.0 ) * resolution; // WebGL port note: Changed sign
				if ( ! ( texcoord.y > end && e.r > 0.8281 && e.g == 0.0 ) ) break;
			}

			texcoord.y -= 0.25 * resolution.y; // WebGL port note: Changed sign
			texcoord.y -= resolution.y; // WebGL port note: Changed sign
			texcoord.y -= 2.0 * resolution.y; // WebGL port note: Changed sign
			texcoord.y += resolution.y * SMAASearchLength( searchTex, e.gr, 0.0, 0.5 ); // WebGL port note: Changed sign

			return texcoord.y;
		}

		float SMAASearchYDown( sampler2D edgesTex, sampler2D searchTex, vec2 texcoord, float end ) {
			vec2 e = vec2( 1.0, 0.0 );

			for ( int i = 0; i < SMAA_MAX_SEARCH_STEPS; i ++ ) { // WebGL port note: Changed while to for
				e = texture2D( edgesTex, texcoord, 0.0 ).rg;
				texcoord -= vec2( 0.0, 2.0 ) * resolution; // WebGL port note: Changed sign
				if ( ! ( texcoord.y < end && e.r > 0.8281 && e.g == 0.0 ) ) break;
			}

			texcoord.y += 0.25 * resolution.y; // WebGL port note: Changed sign
			texcoord.y += resolution.y; // WebGL port note: Changed sign
			texcoord.y += 2.0 * resolution.y; // WebGL port note: Changed sign
			texcoord.y -= resolution.y * SMAASearchLength( searchTex, e.gr, 0.5, 0.5 ); // WebGL port note: Changed sign

			return texcoord.y;
		}

		vec2 SMAAArea( sampler2D areaTex, vec2 dist, float e1, float e2, float offset ) {
			// Rounding prevents precision errors of bilinear filtering:
			vec2 texcoord = float( SMAA_AREATEX_MAX_DISTANCE ) * round( 4.0 * vec2( e1, e2 ) ) + dist;

			// We do a scale and bias for mapping to texel space:
			texcoord = SMAA_AREATEX_PIXEL_SIZE * texcoord + ( 0.5 * SMAA_AREATEX_PIXEL_SIZE );

			// Move to proper place, according to the subpixel offset:
			texcoord.y += SMAA_AREATEX_SUBTEX_SIZE * offset;

			return texture2D( areaTex, texcoord, 0.0 ).rg;
		}

		vec4 SMAABlendingWeightCalculationPS( vec2 texcoord, vec2 pixcoord, vec4 offset[ 3 ], sampler2D edgesTex, sampler2D areaTex, sampler2D searchTex, ivec4 subsampleIndices ) {
			vec4 weights = vec4( 0.0, 0.0, 0.0, 0.0 );

			vec2 e = texture2D( edgesTex, texcoord ).rg;

			if ( e.g > 0.0 ) { // Edge at north
				vec2 d;

				// Find the distance to the left:
				vec2 coords;
				coords.x = SMAASearchXLeft( edgesTex, searchTex, offset[ 0 ].xy, offset[ 2 ].x );
				coords.y = offset[ 1 ].y; // offset[1].y = texcoord.y - 0.25 * resolution.y (@CROSSING_OFFSET)
				d.x = coords.x;

				// Now fetch the left crossing edges, two at a time using bilinear
				// filtering. Sampling at -0.25 (see @CROSSING_OFFSET) enables to
				// discern what value each edge has:
				float e1 = texture2D( edgesTex, coords, 0.0 ).r;

				// Find the distance to the right:
				coords.x = SMAASearchXRight( edgesTex, searchTex, offset[ 0 ].zw, offset[ 2 ].y );
				d.y = coords.x;

				// We want the distances to be in pixel units (doing this here allow to
				// better interleave arithmetic and memory accesses):
				d = d / resolution.x - pixcoord.x;

				// SMAAArea below needs a sqrt, as the areas texture is compressed
				// quadratically:
				vec2 sqrt_d = sqrt( abs( d ) );

				// Fetch the right crossing edges:
				coords.y -= 1.0 * resolution.y; // WebGL port note: Added
				float e2 = SMAASampleLevelZeroOffset( edgesTex, coords, ivec2( 1, 0 ) ).r;

				// Ok, we know how this pattern looks like, now it is time for getting
				// the actual area:
				weights.rg = SMAAArea( areaTex, sqrt_d, e1, e2, float( subsampleIndices.y ) );
			}

			if ( e.r > 0.0 ) { // Edge at west
				vec2 d;

				// Find the distance to the top:
				vec2 coords;

				coords.y = SMAASearchYUp( edgesTex, searchTex, offset[ 1 ].xy, offset[ 2 ].z );
				coords.x = offset[ 0 ].x; // offset[1].x = texcoord.x - 0.25 * resolution.x;
				d.x = coords.y;

				// Fetch the top crossing edges:
				float e1 = texture2D( edgesTex, coords, 0.0 ).g;

				// Find the distance to the bottom:
				coords.y = SMAASearchYDown( edgesTex, searchTex, offset[ 1 ].zw, offset[ 2 ].w );
				d.y = coords.y;

				// We want the distances to be in pixel units:
				d = d / resolution.y - pixcoord.y;

				// SMAAArea below needs a sqrt, as the areas texture is compressed
				// quadratically:
				vec2 sqrt_d = sqrt( abs( d ) );

				// Fetch the bottom crossing edges:
				coords.y -= 1.0 * resolution.y; // WebGL port note: Added
				float e2 = SMAASampleLevelZeroOffset( edgesTex, coords, ivec2( 0, 1 ) ).g;

				// Get the area for this direction:
				weights.ba = SMAAArea( areaTex, sqrt_d, e1, e2, float( subsampleIndices.x ) );
			}

			return weights;
		}

		void main() {

			gl_FragColor = SMAABlendingWeightCalculationPS( vUv, vPixcoord, vOffset, tDiffuse, tArea, tSearch, ivec4( 0.0 ) );

		}`},Ah={name:`SMAABlendShader`,uniforms:{tDiffuse:{value:null},tColor:{value:null},resolution:{value:new H(1/1024,1/512)}},vertexShader:`

		uniform vec2 resolution;

		varying vec2 vUv;
		varying vec4 vOffset[ 2 ];

		void SMAANeighborhoodBlendingVS( vec2 texcoord ) {
			vOffset[ 0 ] = texcoord.xyxy + resolution.xyxy * vec4( -1.0, 0.0, 0.0, 1.0 ); // WebGL port note: Changed sign in W component
			vOffset[ 1 ] = texcoord.xyxy + resolution.xyxy * vec4( 1.0, 0.0, 0.0, -1.0 ); // WebGL port note: Changed sign in W component
		}

		void main() {

			vUv = uv;

			SMAANeighborhoodBlendingVS( vUv );

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform sampler2D tColor;
		uniform vec2 resolution;

		varying vec2 vUv;
		varying vec4 vOffset[ 2 ];

		vec4 SMAANeighborhoodBlendingPS( vec2 texcoord, vec4 offset[ 2 ], sampler2D colorTex, sampler2D blendTex ) {
			// Fetch the blending weights for current pixel:
			vec4 a;
			a.xz = texture2D( blendTex, texcoord ).xz;
			a.y = texture2D( blendTex, offset[ 1 ].zw ).g;
			a.w = texture2D( blendTex, offset[ 1 ].xy ).a;

			// Is there any blending weight with a value greater than 0.0?
			if ( dot(a, vec4( 1.0, 1.0, 1.0, 1.0 )) < 1e-5 ) {
				return texture2D( colorTex, texcoord, 0.0 );
			} else {
				// Up to 4 lines can be crossing a pixel (one through each edge). We
				// favor blending by choosing the line with the maximum weight for each
				// direction:
				vec2 offset;
				offset.x = a.a > a.b ? a.a : -a.b; // left vs. right
				offset.y = a.g > a.r ? -a.g : a.r; // top vs. bottom // WebGL port note: Changed signs

				// Then we go in the direction that has the maximum weight:
				if ( abs( offset.x ) > abs( offset.y )) { // horizontal vs. vertical
					offset.y = 0.0;
				} else {
					offset.x = 0.0;
				}

				// Fetch the opposite color and lerp by hand:
				vec4 C = texture2D( colorTex, texcoord, 0.0 );
				texcoord += sign( offset ) * resolution;
				vec4 Cop = texture2D( colorTex, texcoord, 0.0 );
				float s = abs( offset.x ) > abs( offset.y ) ? abs( offset.x ) : abs( offset.y );

				// WebGL port note: Added gamma correction
				C.xyz = pow(C.xyz, vec3(2.2));
				Cop.xyz = pow(Cop.xyz, vec3(2.2));
				vec4 mixed = mix(C, Cop, s);
				mixed.xyz = pow(mixed.xyz, vec3(1.0 / 2.2));

				return mixed;
			}
		}

		void main() {

			gl_FragColor = SMAANeighborhoodBlendingPS( vUv, vOffset, tColor, tDiffuse );

		}`},jh=class extends sh{constructor(){super(),this._edgesRT=new qt(1,1,{depthBuffer:!1,type:g}),this._edgesRT.texture.name=`SMAAPass.edges`,this._weightsRT=new qt(1,1,{depthBuffer:!1,type:g}),this._weightsRT.texture.name=`SMAAPass.weights`;let e=this,t=new Image;t.src=this._getAreaTexture(),t.onload=function(){e._areaTexture.needsUpdate=!0},this._areaTexture=new Wt,this._areaTexture.name=`SMAAPass.area`,this._areaTexture.image=t,this._areaTexture.minFilter=o,this._areaTexture.generateMipmaps=!1,this._areaTexture.flipY=!1;let n=new Image;n.src=this._getSearchTexture(),n.onload=function(){e._searchTexture.needsUpdate=!0},this._searchTexture=new Wt,this._searchTexture.name=`SMAAPass.search`,this._searchTexture.image=n,this._searchTexture.magFilter=r,this._searchTexture.minFilter=r,this._searchTexture.generateMipmaps=!1,this._searchTexture.flipY=!1,this._uniformsEdges=zo.clone(Oh.uniforms),this._materialEdges=new Ho({defines:Object.assign({},Oh.defines),uniforms:this._uniformsEdges,vertexShader:Oh.vertexShader,fragmentShader:Oh.fragmentShader}),this._uniformsWeights=zo.clone(kh.uniforms),this._uniformsWeights.tDiffuse.value=this._edgesRT.texture,this._uniformsWeights.tArea.value=this._areaTexture,this._uniformsWeights.tSearch.value=this._searchTexture,this._materialWeights=new Ho({defines:Object.assign({},kh.defines),uniforms:this._uniformsWeights,vertexShader:kh.vertexShader,fragmentShader:kh.fragmentShader}),this._uniformsBlend=zo.clone(Ah.uniforms),this._uniformsBlend.tDiffuse.value=this._weightsRT.texture,this._materialBlend=new Ho({uniforms:this._uniformsBlend,vertexShader:Ah.vertexShader,fragmentShader:Ah.fragmentShader}),this._fsQuad=new uh(null)}render(e,t,n){this._uniformsEdges.tDiffuse.value=n.texture,this._fsQuad.material=this._materialEdges,e.setRenderTarget(this._edgesRT),this.clear&&e.clear(),this._fsQuad.render(e),this._fsQuad.material=this._materialWeights,e.setRenderTarget(this._weightsRT),this.clear&&e.clear(),this._fsQuad.render(e),this._uniformsBlend.tColor.value=n.texture,this._fsQuad.material=this._materialBlend,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(),this._fsQuad.render(e))}setSize(e,t){this._edgesRT.setSize(e,t),this._weightsRT.setSize(e,t),this._materialEdges.uniforms.resolution.value.set(1/e,1/t),this._materialWeights.uniforms.resolution.value.set(1/e,1/t),this._materialBlend.uniforms.resolution.value.set(1/e,1/t)}dispose(){this._edgesRT.dispose(),this._weightsRT.dispose(),this._areaTexture.dispose(),this._searchTexture.dispose(),this._materialEdges.dispose(),this._materialWeights.dispose(),this._materialBlend.dispose(),this._fsQuad.dispose()}_getAreaTexture(){return`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAIwCAIAAACOVPcQAACBeklEQVR42u39W4xlWXrnh/3WWvuciIzMrKxrV8/0rWbY0+SQFKcb4owIkSIFCjY9AC1BT/LYBozRi+EX+cV+8IMsYAaCwRcBwjzMiw2jAWtgwC8WR5Q8mDFHZLNHTarZGrLJJllt1W2qKrsumZWZcTvn7L3W54e1vrXX3vuciLPPORFR1XE2EomorB0nVuz//r71re/y/1eMvb4Cb3N11xV/PP/2v4UBAwJG/7H8urx6/25/Gf8O5hypMQ0EEEQwAqLfoN/Z+97f/SW+/NvcgQk4sGBJK6H7N4PFVL+K+e0N11yNfkKvwUdwdlUAXPHHL38oa15f/i/46Ih6SuMSPmLAYAwyRKn7dfMGH97jaMFBYCJUgotIC2YAdu+LyW9vvubxAP8kAL8H/koAuOKP3+q6+xGnd5kdYCeECnGIJViwGJMAkQKfDvB3WZxjLKGh8VSCCzhwEWBpMc5/kBbjawT4HnwJfhr+pPBIu7uu+OOTo9vsmtQcniMBGkKFd4jDWMSCRUpLjJYNJkM+IRzQ+PQvIeAMTrBS2LEiaiR9b/5PuT6Ap/AcfAFO4Y3dA3DFH7/VS+M8k4baEAQfMI4QfbVDDGIRg7GKaIY52qAjTAgTvGBAPGIIghOCYAUrGFNgzA7Q3QhgCwfwAnwe5vDejgG44o/fbm1C5ZlYQvQDARPAIQGxCWBM+wWl37ZQESb4gImexGMDouhGLx1Cst0Saa4b4AqO4Hk4gxo+3DHAV/nx27p3JziPM2pVgoiia5MdEzCGULprIN7gEEeQ5IQxEBBBQnxhsDb5auGmAAYcHMA9eAAz8PBol8/xij9+C4Djlim4gJjWcwZBhCBgMIIYxGAVIkH3ZtcBuLdtRFMWsPGoY9rN+HoBji9VBYdwD2ZQg4cnO7OSq/z4rU5KKdwVbFAjNojCQzTlCLPFSxtamwh2jMUcEgg2Wm/6XgErIBhBckQtGN3CzbVacERgCnfgLswhnvqf7QyAq/z4rRZm1YglYE3affGITaZsdIe2FmMIpnOCap25I6jt2kCwCW0D1uAD9sZctNGXcQIHCkINDQgc78aCr+zjtw3BU/ijdpw3zhCwcaONwBvdeS2YZKkJNJsMPf2JKEvC28RXxxI0ASJyzQCjCEQrO4Q7sFArEzjZhaFc4cdv+/JFdKULM4px0DfUBI2hIsy06BqLhGTQEVdbfAIZXYMPesq6VoCHICzUyjwInO4Y411//LYLs6TDa9wvg2CC2rElgAnpTBziThxaL22MYhzfkghz6GAs2VHbbdM91VZu1MEEpupMMwKyVTb5ij9+u4VJG/5EgEMMmFF01cFai3isRbKbzb+YaU/MQbAm2XSMoUPAmvZzbuKYRIFApbtlrfFuUGd6vq2hXNnH78ZLh/iFhsQG3T4D1ib7k5CC6vY0DCbtrohgLEIClXiGtl10zc0CnEGIhhatLBva7NP58Tvw0qE8yWhARLQ8h4+AhQSP+I4F5xoU+VilGRJs6wnS7ruti/4KvAY/CfdgqjsMy4pf8fodQO8/gnuX3f/3xi3om1/h7THr+co3x93PP9+FBUfbNUjcjEmhcrkT+8K7ml7V10Jo05mpIEFy1NmCJWx9SIKKt+EjAL4Ez8EBVOB6havuT/rByPvHXK+9zUcfcbb254+9fydJknYnRr1oGfdaiAgpxu1Rx/Rek8KISftx3L+DfsLWAANn8Hvw0/AFeAGO9DFV3c6D+CcWbL8Dj9e7f+T1k8AZv/d7+PXWM/Z+VvdCrIvuAKO09RpEEQJM0Ci6+B4xhTWr4cZNOvhktabw0ta0rSJmqz3Yw5/AKXwenod7cAhTmBSPKf6JBdvH8IP17h95pXqw50/+BFnj88fev4NchyaK47OPhhtI8RFSvAfDSNh0Ck0p2gLxGkib5NJj/JWCr90EWQJvwBzO4AHcgztwAFN1evHPUVGwfXON+0debT1YeGON9Yy9/63X+OguiwmhIhQhD7l4sMqlG3D86Suc3qWZ4rWjI1X7u0Ytw6x3rIMeIOPDprfe2XzNgyj6PahhBjO4C3e6puDgXrdg+/5l948vF3bqwZetZ+z9Rx9zdIY5pInPK4Nk0t+l52xdK2B45Qd87nM8fsD5EfUhIcJcERw4RdqqH7Yde5V7m1vhNmtedkz6EDzUMF/2jJYWbC+4fzzA/Y+/8PPH3j9dcBAPIRP8JLXd5BpAu03aziOL3VVHZzz3CXWDPWd+SH2AnxIqQoTZpo9Ckc6HIrFbAbzNmlcg8Ag8NFDDAhbJvTBZXbC94P7t68EXfv6o+21gUtPETU7bbkLxvNKRFG2+KXzvtObonPP4rBvsgmaKj404DlshFole1Glfh02fE7bYR7dZ82oTewIBGn1Md6CG6YUF26X376oevOLzx95vhUmgblI6LBZwTCDY7vMq0op5WVXgsObOXJ+1x3qaBl9j1FeLxbhU9w1F+Wiba6s1X/TBz1LnUfuYDi4r2C69f1f14BWfP+p+W2GFKuC9phcELMYRRLur9DEZTUdEH+iEqWdaM7X4WOoPGI+ZYD2+wcQ+y+ioHUZ9dTDbArzxmi/bJI9BND0Ynd6lBdve/butBw8+f/T9D3ABa3AG8W3VPX4hBin+bj8dMMmSpp5pg7fJ6xrBFE2WQQEWnV8Qg3FbAWzYfM1rREEnmvkN2o1+acG2d/9u68GDzx91v3mAjb1zkpqT21OipPKO0b9TO5W0nTdOmAQm0TObts3aBKgwARtoPDiCT0gHgwnbArzxmtcLc08HgF1asN0C4Ms/fvD5I+7PhfqyXE/b7RbbrGyRQRT9ARZcwAUmgdoz0ehJ9Fn7QAhUjhDAQSw0bV3T3WbNa59jzmiP6GsWbGXDX2ytjy8+f9T97fiBPq9YeLdBmyuizZHaqXITnXiMUEEVcJ7K4j3BFPurtB4bixW8wTpweL8DC95szWMOqucFYGsWbGU7p3TxxxefP+r+oTVktxY0v5hbq3KiOKYnY8ddJVSBxuMMVffNbxwIOERShst73HZ78DZrHpmJmH3K6sGz0fe3UUj0eyRrSCGTTc+rjVNoGzNSv05srAxUBh8IhqChiQgVNIIBH3AVPnrsnXQZbLTm8ammv8eVXn/vWpaTem5IXRlt+U/LA21zhSb9cye6jcOfCnOwhIAYXAMVTUNV0QhVha9xjgA27ODJbLbmitt3tRN80lqG6N/khgot4ZVlOyO4WNg3OIMzhIZQpUEHieg2im6F91hB3I2tubql6BYNN9Hj5S7G0G2tahslBWKDnOiIvuAEDzakDQKDNFQT6gbn8E2y4BBubM230YIpBnDbMa+y3dx0n1S0BtuG62lCCXwcY0F72T1VRR3t2ONcsmDjbmzNt9RFs2LO2hQNyb022JisaI8rAWuw4HI3FuAIhZdOGIcdjLJvvObqlpqvWTJnnQbyi/1M9O8UxWhBs//H42I0q1Yb/XPGONzcmm+ri172mHKvZBpHkJaNJz6v9jxqiklDj3U4CA2ugpAaYMWqNXsdXbmJNd9egCnJEsphXNM+MnK3m0FCJ5S1kmJpa3DgPVbnQnPGWIDspW9ozbcO4K/9LkfaQO2KHuqlfFXSbdNzcEcwoqNEFE9zcIXu9/6n/ym/BC/C3aJLzEKPuYVlbFnfhZ8kcWxV3dbv4bKl28566wD+8C53aw49lTABp9PWbsB+knfc/Li3eVizf5vv/xmvnPKg5ihwKEwlrcHqucuVcVOxEv8aH37E3ZqpZypUulrHEtIWKUr+txHg+ojZDGlwnqmkGlzcVi1dLiNSJiHjfbRNOPwKpx9TVdTn3K05DBx4psIk4Ei8aCkJahRgffk4YnEXe07T4H2RR1u27E6wfQsBDofUgjFUFnwC2AiVtA+05J2zpiDK2Oa0c5fmAecN1iJzmpqFZxqYBCYhFTCsUNEmUnIcZ6aEA5rQVhEywG6w7HSW02XfOoBlQmjwulOFQAg66SvJblrTEX1YtJ3uG15T/BH1OfOQeuR8g/c0gdpT5fx2SKbs9EfHTKdM8A1GaJRHLVIwhcGyydZsbifAFVKl5EMKNU2Hryo+06BeTgqnxzYjThVySDikbtJPieco75lYfKAJOMEZBTjoITuWHXXZVhcUDIS2hpiXHV9Ku4u44bN5OYLDOkJo8w+xJSMbhBRHEdEs9JZUCkQrPMAvaHyLkxgkEHxiNkx/x2YB0mGsQ8EUWj/stW5YLhtS5SMu+/YBbNPDCkGTUybN8krRLBGPlZkVOA0j+a1+rkyQKWGaPHPLZOkJhioQYnVZ2hS3zVxMtgC46KuRwbJNd9nV2PHgb36F194ecf/Yeu2vAFe5nm/bRBFrnY4BauE8ERmZRFUn0k8hbftiVYSKMEme2dJCJSCGYAlNqh87bXOPdUkGy24P6d1ll21MBqqx48Fvv8ZHH8HZFY7j/uAq1xMJUFqCSUlJPmNbIiNsmwuMs/q9CMtsZsFO6SprzCS1Z7QL8xCQClEelpjTduDMsmWD8S1PT152BtvmIGvUeDA/yRn83u/x0/4qxoPHjx+PXY9pqX9bgMvh/Nz9kpP4pOe1/fYf3axUiMdHLlPpZCNjgtNFAhcHEDxTumNONhHrBduW+vOyY++70WWnPXj98eA4kOt/mj/5E05l9+O4o8ePx67HFqyC+qSSnyselqjZGaVK2TadbFLPWAQ4NBhHqDCCV7OTpo34AlSSylPtIdd2AJZlyzYQrDJ5lcWGNceD80CunPLGGzsfD+7wRb95NevJI5docQ3tgCyr5bGnyaPRlmwNsFELViOOx9loebGNq2moDOKpHLVP5al2cymWHbkfzGXL7kfRl44H9wZy33tvt+PB/Xnf93e+nh5ZlU18wCiRUa9m7kib9LYuOk+hudQNbxwm0AQqbfloimaB2lM5fChex+ylMwuTbfmXQtmWlenZljbdXTLuOxjI/fDDHY4Hjx8/Hrse0zXfPFxbUN1kKqSCCSk50m0Ajtx3ub9XHBKHXESb8iO6E+qGytF4nO0OG3SXzbJlhxBnKtKyl0NwybjvYCD30aMdjgePHz8eu56SVTBbgxJMliQ3Oauwg0QHxXE2Ez/EIReLdQj42Gzb4CLS0YJD9xUx7bsi0vJi5mUbW1QzL0h0PFk17rtiIPfJk52MB48fPx67npJJwyrBa2RCCQRTbGZSPCxTPOiND4G2pYyOQ4h4jINIJh5wFU1NFZt+IsZ59LSnDqBjZ2awbOku+yInunLcd8VA7rNnOxkPHj9+PGY9B0MWJJNozOJmlglvDMXDEozdhQWbgs/U6oBanGzLrdSNNnZFjOkmbi5bNt1lX7JLLhn3vXAg9/h4y/Hg8ePHI9dzQMEkWCgdRfYykYKnkP7D4rIujsujaKPBsB54vE2TS00ccvFY/Tth7JXeq1hz+qgVy04sAJawTsvOknHfCwdyT062HA8eP348Zj0vdoXF4pilKa2BROed+9fyw9rWRXeTFXESMOanvDZfJuJaSXouQdMdDJZtekZcLLvEeK04d8m474UDuaenW44Hjx8/Xns9YYqZpszGWB3AN/4VHw+k7WSFtJ3Qicuqb/NlVmgXWsxh570xg2UwxUw3WfO6B5nOuO8aA7lnZxuPB48fPx6znm1i4bsfcbaptF3zNT78eFPtwi1OaCNOqp1x3zUGcs/PN++AGD1+fMXrSVm2baTtPhPahbPhA71wIHd2bXzRa69nG+3CraTtPivahV/55tXWg8fyRY/9AdsY8VbSdp8V7cKrrgdfM//z6ILQFtJ2nxHtwmuoB4/kf74+gLeRtvvMaBdeSz34+vifx0YG20jbfTa0C6+tHrwe//NmOG0L8EbSdp8R7cLrrQe/996O+ai3ujQOskpTNULa7jOjXXj99eCd8lHvoFiwsbTdZ0a78PrrwTvlo966pLuRtB2fFe3Cm6oHP9kNH/W2FryxtN1nTLvwRurBO+Kj3pWXHidtx2dFu/Bm68Fb81HvykuPlrb7LGkX3mw9eGs+6h1Y8MbSdjegXcguQLjmevDpTQLMxtJ2N6NdyBZu9AbrwVvwUW+LbteULUpCdqm0HTelXbhNPe8G68Gb8lFvVfYfSNuxvrTdTWoXbozAzdaDZzfkorOj1oxVxlIMlpSIlpLrt8D4hrQL17z+c3h6hU/wv4Q/utps4+bm+6P/hIcf0JwQ5oQGPBL0eKPTYEXTW+eL/2DKn73J9BTXYANG57hz1cEMviVf/4tf5b/6C5pTQkMIWoAq7hTpOJjtAM4pxKu5vg5vXeUrtI09/Mo/5H+4z+Mp5xULh7cEm2QbRP2tFIKR7WM3fPf/jZ3SWCqLM2l4NxID5zB72HQXv3jj/8mLR5xXNA5v8EbFQEz7PpRfl1+MB/hlAN65qgDn3wTgH13hK7T59bmP+NIx1SHHU84nLOITt3iVz8mNO+lPrjGAnBFqmioNn1mTyk1ta47R6d4MrX7tjrnjYUpdUbv2rVr6YpVfsGG58AG8Ah9eyUN8CX4WfgV+G8LVWPDGb+Zd4cU584CtqSbMKxauxTg+dyn/LkVgA+IR8KHtejeFKRtTmLLpxN6mYVLjYxwXf5x2VofiZcp/lwKk4wGOpYDnoIZPdg/AAbwMfx0+ge9dgZvYjuqKe4HnGnykYo5TvJbG0Vj12JagRhwKa44H95ShkZa5RyLGGdfYvG7aw1TsF6iapPAS29mNS3NmsTQZCmgTzFwgL3upCTgtBTRwvGMAKrgLn4evwin8+afJRcff+8izUGUM63GOOuAs3tJkw7J4kyoNreqrpO6cYLQeFUd7TTpr5YOTLc9RUUogUOVJQ1GYJaFLAW0oTmKyYS46ZooP4S4EON3xQ5zC8/CX4CnM4c1PE8ApexpoYuzqlP3d4S3OJP8ZDK7cKWNaTlqmgDiiHwl1YsE41w1zT4iRTm3DBqxvOUsbMKKDa/EHxagtnta072ejc3DOIh5ojvh8l3tk1JF/AV6FU6jh3U8HwEazLgdCLYSQ+MYiAI2ltomkzttUb0gGHdSUUgsIYjTzLG3mObX4FBRaYtpDVNZrih9TgTeYOBxsEnN1gOCTM8Bsw/ieMc75w9kuAT6A+/AiHGvN/+Gn4KRkiuzpNNDYhDGFndWRpE6SVfm8U5bxnSgVV2jrg6JCKmneqey8VMFgq2+AM/i4L4RUbfSi27lNXZ7R7W9RTcq/q9fk4Xw3AMQd4I5ifAZz8FcVtm9SAom/dyN4lczJQW/kC42ZrHgcCoIf1oVMKkVItmMBi9cOeNHGLqOZk+QqQmrbc5YmYgxELUUN35z2iohstgfLIFmcMV7s4CFmI74L9+EFmGsi+tGnAOD4Yk9gIpo01Y4cA43BWGygMdr4YZekG3OBIUXXNukvJS8tqa06e+lSDCtnqqMFu6hWHXCF+WaYt64m9QBmNxi7Ioy7D+fa1yHw+FMAcPt7SysFLtoG4PXAk7JOA3aAxBRqUiAdU9Yp5lK3HLSRFtOim0sa8euEt08xvKjYjzeJ2GU7YawexrnKI9tmobInjFXCewpwriY9+RR4aaezFhMhGCppKwom0ChrgFlKzyPKkGlTW1YQrE9HJqu8hKGgMc6hVi5QRq0PZxNfrYNgE64utmRv6KKHRpxf6VDUaOvNP5jCEx5q185My/7RKz69UQu2im5k4/eownpxZxNLwiZ1AZTO2ZjWjkU9uaB2HFn6Q3u0JcsSx/qV9hTEApRzeBLDJQXxYmTnq7bdLa3+uqFrxLJ5w1TehnNHx5ECvCh2g2c3hHH5YsfdaSKddztfjQ6imKFGSyFwlLzxEGPp6r5IevVjk1AMx3wMqi1NxDVjLBiPs9tbsCkIY5we5/ML22zrCScFxnNtzsr9Wcc3CnD+pYO+4VXXiDE0oc/vQQ/fDK3oPESJMYXNmJa/DuloJZkcTpcYE8lIH8Dz8DJMiynNC86Mb2lNaaqP/+L7f2fcE/yP7/Lde8xfgSOdMxvOixZf/9p3+M4hT1+F+zApxg9XfUvYjc8qX2lfOOpK2gNRtB4flpFu9FTKCp2XJRgXnX6olp1zyYjTKJSkGmLE2NjUr1bxFM4AeAAHBUFIeSLqXR+NvH/M9fOnfHzOD2vCSyQJKzfgsCh+yi/Mmc35F2fUrw7miW33W9hBD1vpuUojFphIyvg7aTeoymDkIkeW3XLHmguMzbIAJejN6B5MDrhipE2y6SoFRO/AK/AcHHZHNIfiWrEe/C6cr3f/yOvrQKB+zMM55/GQdLDsR+ifr5Fiuu+/y+M78LzOE5dsNuXC3PYvYWd8NXvphLSkJIasrlD2/HOqQ+RjcRdjKTGWYhhVUm4yxlyiGPuMsZR7sMCHUBeTuNWA7if+ifXgc/hovftHXs/DV+Fvwe+f8shzMiMcweFgBly3//vwJfg5AN4450fn1Hd1Rm1aBLu22Dy3y3H2+OqMemkbGZ4jozcDjJf6596xOLpC0eMTHbKnxLxH27uZ/bMTGs2jOaMOY4m87CfQwF0dw53oa1k80JRuz/XgS+8fX3N9Af4qPIMfzKgCp4H5TDGe9GGeFPzSsZz80SlPTxXjgwJmC45njzgt2vbQ4b4OAdUK4/vWhO8d8v6EE8fMUsfakXbPpFJeLs2ubM/qdm/la3WP91uWhxXHjoWhyRUq2iJ/+5mA73zwIIo+LoZ/SgvIRjAd1IMvvn98PfgOvAJfhhm8scAKVWDuaRaK8aQ9f7vuPDH6Bj47ZXau7rqYJ66mTDwEDU6lLbCjCK0qTXyl5mnDoeNRxanj3FJbaksTk0faXxHxLrssgPkWB9LnA/MFleXcJozzjwsUvUG0X/QCve51qkMDXp9mtcyOy3rwBfdvVJK7D6/ACSzg3RoruIq5UDeESfEmVclDxnniU82vxMLtceD0hGZWzBNPMM/jSPne2OVatiTKUpY5vY7gc0LdUAWeWM5tH+O2I66AOWw9xT2BuyRVLGdoDHUsVRXOo/c+ZdRXvFfnxWyIV4upFLCl9eAL7h8Zv0QH8Ry8pA2cHzQpGesctVA37ZtklBTgHjyvdSeKY/RZw/kJMk0Y25cSNRWSigQtlULPTw+kzuJPeYEkXjQRpoGZobYsLF79pyd1dMRHInbgFTZqNLhDqiIsTNpoex2WLcy0/X6rHcdMMQvFSd5dWA++4P7xv89deACnmr36uGlL69bRCL6BSZsS6c0TU2TKK5gtWCzgAOOwQcurqk9j8whvziZSMLcq5hbuwBEsYjopUBkqw1yYBGpLA97SRElEmx5MCInBY5vgLk94iKqSWmhIGmkJ4Bi9m4L645J68LyY4wsFYBfUg5feP/6gWWm58IEmKQM89hq7KsZNaKtP5TxxrUZZVkNmMJtjbKrGxLNEbHPJxhqy7lAmbC32ZqeF6lTaknRWcYaFpfLUBh/rwaQycCCJmW15Kstv6jRHyJFry2C1ahkkIW0LO75s61+owxK1y3XqweX9m5YLM2DPFeOjn/iiqCKJ+yKXF8t5Yl/kNsqaSCryxPq5xWTFIaP8KSW0RYxqupaUf0RcTNSSdJZGcKYdYA6kdtrtmyBckfKXwqk0pHpUHlwWaffjNRBYFPUDWa8e3Lt/o0R0CdisKDM89cX0pvRHEfM8ca4t0s2Xx4kgo91MPQJ/0c9MQYq0co8MBh7bz1fio0UUHLR4aAIOvOmoYO6kwlEVODSSTliWtOtH6sPkrtctF9ZtJ9GIerBskvhdVS5cFNv9s1BU0AbdUgdK4FG+dRnjFmDTzniRMdZO1QhzMK355vigbdkpz9P6qjUGE5J2qAcXmwJ20cZUiAD0z+pGMx6xkzJkmEf40Hr4qZfVg2XzF9YOyoV5BjzVkUJngKf8lgNYwKECEHrCNDrWZzMlflS3yBhr/InyoUgBc/lKT4pxVrrC6g1YwcceK3BmNxZcAtz3j5EIpqguh9H6wc011YN75cKDLpFDxuwkrPQmUwW4KTbj9mZTwBwLq4aQMUZbHm1rylJ46dzR0dua2n3RYCWZsiHROeywyJGR7mXKlpryyCiouY56sFkBWEnkEB/raeh/Sw4162KeuAxMQpEkzy5alMY5wamMsWKKrtW2WpEWNnReZWONKWjrdsKZarpFjqCslq773PLmEhM448Pc3+FKr1+94vv/rfw4tEcu+lKTBe4kZSdijBrykwv9vbCMPcLQTygBjzVckSLPRVGslqdunwJ4oegtFOYb4SwxNgWLCmD7T9kVjTv5YDgpo0XBmN34Z/rEHp0sgyz7lngsrm4lvMm2Mr1zNOJYJ5cuxuQxwMGJq/TP5emlb8fsQBZviK4t8hFL+zbhtlpwaRSxQRWfeETjuauPsdGxsBVdO7nmP4xvzSoT29pRl7kGqz+k26B3Oy0YNV+SXbbQas1ctC/GarskRdFpKczVAF1ZXnLcpaMuzVe6lZ2g/1ndcvOVgRG3sdUAY1bKD6achijMPdMxV4muKVorSpiDHituH7rSTs7n/4y5DhRXo4FVBN4vO/zbAcxhENzGbHCzU/98Mcx5e7a31kWjw9FCe/zNeYyQjZsWb1uc7U33pN4Mji6hCLhivqfa9Ss6xLg031AgfesA/l99m9fgvnaF9JoE6bYKmkGNK3aPbHB96w3+DnxFm4hs0drLsk7U8kf/N/CvwQNtllna0rjq61sH8L80HAuvwH1tvBy2ChqWSCaYTaGN19sTvlfzFD6n+iKTbvtayfrfe9ueWh6GJFoxLdr7V72a5ZpvHcCPDzma0wTO4EgbLyedxstO81n57LYBOBzyfsOhUKsW1J1BB5vr/tz8RyqOFylQP9Tvst2JALsC5lsH8PyQ40DV4ANzYa4dedNiKNR1s+x2wwbR7q4/4cTxqEk4LWDebfisuo36JXLiWFjOtLrlNWh3K1rRS4xvHcDNlFnNmWBBAl5SWaL3oPOfnvbr5pdjVnEaeBJSYjuLEkyLLsWhKccadmOphZkOPgVdalj2QpSmfOsADhMWE2ZBu4+EEJI4wKTAuCoC4xwQbWXBltpxbjkXJtKxxabo9e7tyhlgb6gNlSbUpMh+l/FaqzVwewGu8BW1Zx7pTpQDJUjb8tsUTW6+GDXbMn3mLbXlXJiGdggxFAoUrtPS3wE4Nk02UZG2OOzlk7fRs7i95QCLo3E0jtrjnM7SR3uS1p4qtS2nJ5OwtQVHgOvArLBFijZUV9QtSl8dAY5d0E0hM0w3HS2DpIeB6m/A1+HfhJcGUq4sOxH+x3f5+VO+Ds9rYNI7zPXOYWPrtf8bYMx6fuOAX5jzNR0PdsuON+X1f7EERxMJJoU6GkTEWBvVolVlb5lh3tKCg6Wx1IbaMDdJ+9sUCc5KC46hKGCk3IVOS4TCqdBNfUs7Kd4iXf2RjnT/LLysJy3XDcHLh/vde3x8DoGvwgsa67vBk91G5Pe/HbOe7xwym0NXbtiuuDkGO2IJDh9oQvJ4cY4vdoqLDuoH9Zl2F/ofsekn8lkuhIlhQcffUtSjytFyp++p6NiE7Rqx/lodgKVoceEp/CP4FfjrquZaTtj2AvH5K/ywpn7M34K/SsoYDAdIN448I1/0/wveW289T1/lX5xBzc8N5IaHr0XMOQdHsIkDuJFifj20pBm5jzwUv9e2FhwRsvhAbalCIuIw3bhJihY3p6nTFFIZgiSYjfTf3aXuOjmeGn4bPoGvwl+CFzTRczBIuHBEeImHc37/lGfwZR0cXzVDOvaKfNHvwe+suZ771K/y/XcBlsoN996JpBhoE2toYxOznNEOS5TJc6Id5GEXLjrWo+LEWGNpPDU4WAwsIRROu+1vM+0oW37z/MBN9kqHnSArwPfgFJ7Cq/Ai3Ie7g7ncmI09v8sjzw9mzOAEXoIHxURueaAce5V80f/DOuuZwHM8vsMb5wBzOFWM7wymTXPAEvm4vcFpZ2ut0VZRjkiP2MlmLd6DIpbGSiHOjdnUHN90hRYmhTnmvhzp1iKDNj+b7t5hi79lWGwQ+HN9RsfFMy0FXbEwhfuczKgCbyxYwBmcFhhvo/7a44v+i3XWcwDP86PzpGQYdWh7csP5dBvZ1jNzdxC8pBGuxqSW5vw40nBpj5JhMwvOzN0RWqERHMr4Lv1kWX84xLR830G3j6yqZ1a8UstTlW+qJPOZ+sZ7xZPKTJLhiNOAFd6tk+jrTH31ncLOxid8+nzRb128HhUcru/y0Wn6iT254YPC6FtVSIMoW2sk727AhvTtrWKZTvgsmckfXYZWeNRXx/3YQ2OUxLDrbHtN11IwrgXT6c8dATDwLniYwxzO4RzuQqTKSC5gAofMZ1QBK3zQ4JWobFbcvJm87FK+6JXrKahLn54m3p+McXzzYtP8VF/QpJuh1OwieElEoI1pRxPS09FBrkq2tWCU59+HdhNtTIqKm8EBrw2RTOEDpG3IKo2Y7mFdLm3ZeVjYwVw11o/oznceMve4CgMfNym/utA/d/ILMR7gpXzRy9eDsgLcgbs8O2Va1L0zzIdwGGemTBuwROHeoMShkUc7P+ISY3KH5ZZeWqO8mFTxQYeXTNuzvvK5FGPdQfuu00DwYFY9dyhctEt+OJDdnucfpmyhzUJzfsJjr29l8S0bXBfwRS9ZT26tmMIdZucch5ZboMz3Nio3nIOsYHCGoDT4kUA9MiXEp9Xsui1S8th/kbWIrMBxDGLodWUQIWcvnXy+9M23xPiSMOiRPqM+YMXkUN3gXFrZJwXGzUaMpJfyRS9ZT0lPe8TpScuRlbMHeUmlaKDoNuy62iWNTWNFYjoxFzuJs8oR+RhRx7O4SVNSXpa0ZJQ0K1LAHDQ+D9IepkMXpcsq5EVCvClBUIzDhDoyKwDw1Lc59GbTeORivugw1IcuaEOaGWdNm+Ps5fQ7/tm0DjMegq3yM3vb5j12qUId5UZD2oxDSEWOZMSqFl/W+5oynWDa/aI04tJRQ2eTXusg86SQVu/nwSYwpW6wLjlqIzwLuxGIvoAvul0PS+ZNz0/akp/pniO/8JDnGyaCkzbhl6YcqmK/69prxPqtpx2+Km9al9sjL+rwMgHw4jE/C8/HQ3m1vBuL1fldbzd8mOueVJ92syqdEY4KJjSCde3mcRw2TA6szxedn+zwhZMps0XrqEsiUjnC1hw0TELC2Ek7uAAdzcheXv1BYLagspxpzSAoZZUsIzIq35MnFQ9DOrlNB30jq3L4pkhccKUAA8/ocvN1Rzx9QyOtERs4CVsJRK/DF71kPYrxYsGsm6RMh4cps5g1DOmM54Ly1ii0Hd3Y/BMk8VWFgBVmhqrkJCPBHAolwZaWzLR9Vb7bcWdX9NyUYE+uB2BKfuaeBUcjDljbYVY4DdtsVWvzRZdWnyUzDpjNl1Du3aloAjVJTNDpcIOVVhrHFF66lLfJL1zJr9PQ2nFJSBaKoDe+sAvLufZVHVzYh7W0h/c6AAZ+7Tvj6q9j68G/cTCS/3n1vLKHZwNi+P+pS0WkZNMBMUl+LDLuiE4omZy71r3UFMwNJV+VJ/GC5ixVUkBStsT4gGKh0Gm4Oy3qvq7Lbmq24nPdDuDR9deR11XzP4vFu3TYzfnIyiSVmgizUYGqkIXNdKTY9pgb9D2Ix5t0+NHkVzCdU03suWkkVZAoCONCn0T35gAeW38de43mf97sMOpSvj4aa1KYUm58USI7Wxxes03bAZdRzk6UtbzMaCQ6IxO0dy7X+XsjoD16hpsBeGz9dfzHj+R/Hp8nCxZRqkEDTaCKCSywjiaoMJ1TITE9eg7Jqnq8HL6gDwiZb0u0V0Rr/rmvqjxKuaLCX7ZWXTvAY+uvm3z8CP7nzVpngqrJpZKwWnCUjIviYVlirlGOzPLI3SMVyp/elvBUjjDkNhrtufFFErQ8pmdSlbK16toBHlt/HV8uHMX/vEGALkV3RJREiSlopxwdMXOZPLZ+ix+kAHpMKIk8UtE1ygtquttwxNhphrIZ1IBzjGF3IIGxGcBj6q8bHJBG8T9vdsoWrTFEuebEZuVxhhClH6P5Zo89OG9fwHNjtNQTpD0TG9PJLEYqvEY6Rlxy+ZZGfL0Aj62/bnQCXp//eeM4KzfQVJbgMQbUjlMFIm6TpcfWlZje7NBSV6IsEVmumWIbjiloUzQX9OzYdo8L1wjw2PrrpimONfmfNyzKklrgnEkSzT5QWYQW40YShyzqsRmMXbvVxKtGuYyMKaU1ugenLDm5Ily4iT14fP11Mx+xJv+zZ3MvnfdFqxU3a1W/FTB4m3Qfsyc1XUcdVhDeUDZXSFHHLQj/Y5jtC7ZqM0CXGwB4bP11i3LhOvzPGygYtiUBiwQV/4wFO0majijGsafHyRLu0yG6q35cL1rOpVxr2s5cM2jJYMCdc10Aj6q/blRpWJ//+dmm5psMl0KA2+AFRx9jMe2WbC4jQxnikd4DU8TwUjRVacgdlhmr3bpddzuJ9zXqr2xnxJfzP29RexdtjDVZqzkqa6PyvcojGrfkXiJ8SEtml/nYskicv0ivlxbqjemwUjMw5evdg8fUX9nOiC/lf94Q2i7MURk9nW1MSj5j8eAyV6y5CN2S6qbnw3vdA1Iwq+XOSCl663udN3IzLnrt+us25cI1+Z83SXQUldqQq0b5XOT17bGpLd6ssN1VMPf8c+jG8L3NeCnMdF+Ra3fRa9dft39/LuZ/3vwHoHrqGmQFafmiQw6eyzMxS05K4bL9uA+SKUQzCnSDkqOGokXyJvbgJ/BHI+qvY69//4rl20NsmK2ou2dTsyIALv/91/8n3P2Aao71WFGi8KKv1fRC5+J67Q/507/E/SOshqN5TsmYIjVt+kcjAx98iz/4SaojbIV1rexE7/C29HcYD/DX4a0rBOF5VTu7omsb11L/AWcVlcVZHSsqGuXLLp9ha8I//w3Mv+T4Ew7nTBsmgapoCrNFObIcN4pf/Ob/mrvHTGqqgAupL8qWjWPS9m/31jAe4DjA+4+uCoQoT/zOzlrNd3qd4SdphFxsUvYwGWbTWtISc3wNOWH+kHBMfc6kpmpwPgHWwqaSUG2ZWWheYOGQGaHB+eQ/kn6b3pOgLV+ODSn94wDvr8Bvb70/LLuiPPEr8OGVWfDmr45PZyccEmsVXZGe1pRNX9SU5+AVQkNTIVPCHF/jGmyDC9j4R9LfWcQvfiETmgMMUCMN1uNCakkweZsowdYobiMSlnKA93u7NzTXlSfe+SVbfnPQXmg9LpYAQxpwEtONyEyaueWM4FPjjyjG3uOaFmBTWDNgBXGEiQpsaWhnAqIijB07Dlsy3fUGeP989xbWkyf+FF2SNEtT1E0f4DYYVlxFlbaSMPIRMk/3iMU5pME2SIWJvjckciebkQuIRRyhUvkHg/iUljG5kzVog5hV7vIlCuBrmlhvgPfNHQM8lCf+FEGsYbMIBC0qC9a0uuy2wLXVbLBaP5kjHokCRxapkQyzI4QEcwgYHRZBp+XEFTqXFuNVzMtjXLJgX4gAid24Hjwc4N3dtVSe+NNiwTrzH4WVUOlDobUqr1FuAgYllc8pmzoVrELRHSIW8ViPxNy4xwjBpyR55I6J220qQTZYR4guvUICJiSpr9gFFle4RcF/OMB7BRiX8sSfhpNSO3lvEZCQfLUVTKT78Ek1LRLhWN+yLyTnp8qWUZ46b6vxdRGXfHVqx3eI75YaLa4iNNiK4NOW7wPW6lhbSOF9/M9qw8e/aoB3d156qTzxp8pXx5BKAsYSTOIIiPkp68GmTq7sZtvyzBQaRLNxIZ+paozHWoLFeExIhRBrWitHCAHrCF7/thhD8JhYz84wg93QRV88wLuLY8zF8sQ36qF1J455bOlgnELfshKVxYOXKVuKx0jaj22sczTQqPqtV/XDgpswmGTWWMSDw3ssyUunLLrVPGjYRsH5ggHeHSWiV8kT33ycFSfMgkoOK8apCye0J6VW6GOYvffgU9RWsukEi2kUV2nl4dOYUzRik9p7bcA4ggdJ53LxKcEe17B1R8eqAd7dOepV8sTXf5lhejoL85hUdhDdknPtKHFhljOT+bdq0hxbm35p2nc8+Ja1Iw+tJykgp0EWuAAZYwMVwac5KzYMslhvgHdHRrxKnvhTYcfKsxTxtTETkjHO7rr3zjoV25lAQHrqpV7bTiy2aXMmUhTBnKS91jhtR3GEoF0oLnWhWNnYgtcc4N0FxlcgT7yz3TgNIKkscx9jtV1ZKpWW+Ub1tc1eOv5ucdgpx+FJy9pgbLE7xDyXb/f+hLHVGeitHOi6A7ybo3sF8sS7w7cgdk0nJaOn3hLj3uyD0Zp5pazFIUXUpuTTU18d1EPkDoX8SkmWTnVIozEdbTcZjoqxhNHf1JrSS/AcvHjZ/SMHhL/7i5z+POsTUh/8BvNfYMTA8n+yU/MlTZxSJDRStqvEuLQKWwDctMTQogUDyQRoTQG5Kc6oQRE1yV1jCA7ri7jdZyK0sYTRjCR0Hnnd+y7nHxNgTULqw+8wj0mQKxpYvhjm9uSUxg+TTy7s2GtLUGcywhXSKZN275GsqlclX90J6bRI1aouxmgL7Q0Nen5ziM80SqMIo8cSOo+8XplT/5DHNWsSUr/6lLN/QQ3rDyzLruEW5enpf7KqZoShEduuSFOV7DLX7Ye+GmXb6/hnNNqKsVXuMDFpb9Y9eH3C6NGEzuOuI3gpMH/I6e+zDiH1fXi15t3vA1czsLws0TGEtmPEJdiiFPwlwKbgLHAFk4P6ZyPdymYYHGE0dutsChQBl2JcBFlrEkY/N5bQeXQ18gjunuMfMfsBlxJSx3niO485fwO4fGD5T/+3fPQqkneWVdwnw/3bMPkW9Wbqg+iC765Zk+xcT98ibKZc2EdgHcLoF8cSOo/Oc8fS+OyEULF4g4sJqXVcmfMfsc7A8v1/yfGXmL9I6Fn5pRwZhsPv0TxFNlAfZCvG+Oohi82UC5f/2IsJo0cTOm9YrDoKhFPEUr/LBYTUNht9zelHXDqwfPCIw4owp3mOcIQcLttWXFe3VZ/j5H3cIc0G6oPbCR+6Y2xF2EC5cGUm6wKC5tGEzhsWqw5hNidUiKX5gFWE1GXh4/Qplw4sVzOmx9QxU78g3EF6wnZlEN4FzJ1QPSLEZz1KfXC7vd8ssGdIbNUYpVx4UapyFUHzJoTOo1McSkeNn1M5MDQfs4qQuhhX5vQZFw8suwWTcyYTgioISk2YdmkhehG4PkE7w51inyAGGaU+uCXADabGzJR1fn3lwkty0asIo8cROm9Vy1g0yDxxtPvHDAmpu+PKnM8Ix1wwsGw91YJqhteaWgjYBmmQiebmSpwKKzE19hx7jkzSWOm66oPbzZ8Yj6kxVSpYjVAuvLzYMCRo3oTQecOOjjgi3NQ4l9K5/hOGhNTdcWVOTrlgYNkEXINbpCkBRyqhp+LdRB3g0OU6rMfW2HPCFFMV9nSp+uB2woepdbLBuJQyaw/ZFysXrlXwHxI0b0LovEkiOpXGA1Ijagf+KUNC6rKNa9bQnLFqYNkEnMc1uJrg2u64ELPBHpkgWbmwKpJoDhMwNbbGzAp7Yg31wS2T5rGtzit59PrKhesWG550CZpHEzpv2NGRaxlNjbMqpmEIzygJqQfjypycs2pg2cS2RY9r8HUqkqdEgKTWtWTKoRvOBPDYBltja2SO0RGjy9UHtxwRjA11ujbKF+ti5cIR9eCnxUg6owidtyoU5tK4NLji5Q3HCtiyF2IqLGYsHViOXTXOYxucDqG0HyttqYAKqYo3KTY1ekyDXRAm2AWh9JmsVh/ccg9WJ2E8YjG201sPq5ULxxX8n3XLXuMInbft2mk80rRGjCGctJ8/GFdmEQ9Ug4FlE1ll1Y7jtiraqm5Fe04VV8lvSVBL8hiPrfFVd8+7QH3Qbu2ipTVi8cvSGivc9cj8yvH11YMHdNSERtuOslM97feYFOPKzGcsI4zW0YGAbTAOaxCnxdfiYUmVWslxiIblCeAYr9VYR1gM7GmoPrilunSxxeT3DN/2eBQ9H11+nk1adn6VK71+5+Jfct4/el10/7KBZfNryUunWSCPxPECk1rdOv1WVSrQmpC+Tl46YD3ikQYcpunSQgzVB2VHFhxHVGKDgMEY5GLlQnP7FMDzw7IacAWnO6sBr12u+XanW2AO0wQ8pknnFhsL7KYIqhkEPmEXFkwaN5KQphbkUmG72wgw7WSm9RiL9QT925hkjiVIIhphFS9HKI6/8QAjlpXqg9W2C0apyaVDwKQwrwLY3j6ADR13ZyUNByQXHQu6RY09Hu6zMqXRaNZGS/KEJs0cJEe9VH1QdvBSJv9h09eiRmy0V2uJcqHcShcdvbSNg5fxkenkVprXM9rDVnX24/y9MVtncvbKY706anNl3ASll9a43UiacVquXGhvq4s2FP62NGKfQLIQYu9q1WmdMfmUrDGt8eDS0cXozH/fjmUH6Jruvm50hBDSaEU/2Ru2LEN/dl006TSc/g7tfJERxGMsgDUEr104pfWH9lQaN+M4KWQjwZbVc2rZVNHsyHal23wZtIs2JJqtIc/WLXXRFCpJkfE9jvWlfFbsNQ9pP5ZBS0zKh4R0aMFj1IjTcTnvi0Zz2rt7NdvQb2mgbju1plsH8MmbnEk7KbK0b+wC2iy3aX3szW8xeZvDwET6hWZYwqTXSSG+wMETKum0Dq/q+x62gt2ua2ppAo309TRk9TPazfV3qL9H8z7uhGqGqxNVg/FKx0HBl9OVUORn8Q8Jx9gFttGQUDr3tzcXX9xGgN0EpzN9mdZ3GATtPhL+CjxFDmkeEU6x56kqZRusLzALXVqkCN7zMEcqwjmywDQ6OhyUe0Xao1Qpyncrg6wKp9XfWDsaZplElvQ/b3sdweeghorwBDlHzgk1JmMc/wiERICVy2VJFdMjFuLQSp3S0W3+sngt2njwNgLssFGVQdJ0tu0KH4ky1LW4yrbkuaA6Iy9oz/qEMMXMMDWyIHhsAyFZc2peV9hc7kiKvfULxCl9iddfRK1f8kk9qvbdOoBtOg7ZkOZ5MsGrSHsokgLXUp9y88smniwWyuFSIRVmjplga3yD8Uij5QS1ZiM4U3Qw5QlSm2bXjFe6jzzBFtpg+/YBbLAWG7OPynNjlCw65fukGNdkJRf7yM1fOxVzbxOJVocFoYIaGwH22mIQkrvu1E2nGuebxIgW9U9TSiukPGU+Lt++c3DJPKhyhEEbXCQLUpae2exiKy6tMPe9mDRBFCEMTWrtwxN8qvuGnt6MoihKWS5NSyBhbH8StXoAz8PLOrRgLtOT/+4vcu+7vDLnqNvztOq7fmd8sMmY9Xzn1zj8Dq8+XVdu2Nv0IIySgEdQo3xVHps3Q5i3fLFsV4aiqzAiBhbgMDEd1uh8qZZ+lwhjkgokkOIv4xNJmyncdfUUzgB4oFMBtiu71Xumpz/P+cfUP+SlwFExwWW62r7b+LSPxqxn/gvMZ5z9C16t15UbNlq+jbGJtco7p8wbYlL4alSyfWdeuu0j7JA3JFNuVAwtst7F7FhWBbPFNKIUORndWtLraFLmMu7KFVDDOzqkeaiN33YAW/r76wR4XDN/yN1z7hejPau06EddkS/6XThfcz1fI/4K736fO48vlxt2PXJYFaeUkFS8U15XE3428xdtn2kc8GQlf1vkIaNRRnOMvLTWrZbElEHeLWi1o0dlKPAh1MVgbbVquPJ5+Cr8LU5/H/+I2QlHIU2ClXM9G8v7Rr7oc/hozfUUgsPnb3D+I+7WF8kNO92GY0SNvuxiE+2Bt8prVJTkzE64sfOstxuwfxUUoyk8VjcTlsqe2qITSFoSj6Epd4KsT6BZOWmtgE3hBfir8IzZDwgV4ZTZvD8VvPHERo8v+vL1DASHTz/i9OlKueHDjK5Rnx/JB1Vb1ioXdBra16dmt7dgik10yA/FwJSVY6XjA3oy4SqM2frqDPPSRMex9qs3XQtoWxMj7/Er8GWYsXgjaVz4OYumP2+9kbxvny/6kvWsEBw+fcb5bInc8APdhpOSs01tEqIkoiZjbAqKMruLbJYddHuHFRIyJcbdEdbl2sVLaySygunutBg96Y2/JjKRCdyHV+AEFtTvIpbKIXOamknYSiB6KV/0JetZITgcjjk5ZdaskBtWO86UF0ap6ozGXJk2WNiRUlCPFir66lzdm/SLSuK7EUdPz8f1z29Skq6F1fXg8+5UVR6bszncP4Tn4KUkkdJ8UFCY1zR1i8RmL/qQL3rlei4THG7OODlnKko4oI01kd3CaM08Ia18kC3GNoVaO9iDh+hWxSyTXFABXoau7Q6q9OxYg/OVEMw6jdbtSrJ9cBcewGmaZmg+bvkUnUUaGr+ZfnMH45Ivevl61hMcXsxYLFTu1hTm2zViCp7u0o5l+2PSUh9bDj6FgYypufBDhqK2+oXkiuHFHR3zfj+9PtA8oR0xnqX8qn+sx3bFODSbbF0X8EUvWQ8jBIcjo5bRmLOljDNtcqNtOe756h3l0VhKa9hDd2l1eqmsnh0MNMT/Cqnx6BInumhLT8luljzQ53RiJeA/0dxe5NK0o2fA1+GLXr6eNQWHNUOJssQaTRlGpLHKL9fD+IrQzTOMZS9fNQD4AnRNVxvTdjC+fJdcDDWQcyB00B0t9BDwTxXgaAfzDZ/DBXzRnfWMFRwuNqocOmX6OKNkY63h5n/fFcB28McVHqnXZVI27K0i4rDLNE9lDKV/rT+udVbD8dFFu2GGZ8mOt0kAXcoX3ZkIWVtw+MNf5NjR2FbivROHmhV1/pj2egv/fMGIOWTIWrV3Av8N9imV9IWml36H6cUjqEWNv9aNc+veb2sH46PRaHSuMBxvtW+twxctq0z+QsHhux8Q7rCY4Ct8lqsx7c6Sy0dl5T89rIeEuZKoVctIk1hNpfavER6yyH1Vvm3MbsUHy4ab4hWr/OZPcsRBphnaV65/ZcdYPNNwsjN/djlf9NqCw9U5ExCPcdhKxUgLSmfROpLp4WSUr8ojdwbncbvCf+a/YzRaEc6QOvXcGO256TXc5Lab9POvB+AWY7PigWYjzhifbovuunzRawsO24ZqQQAqguBtmpmPB7ysXJfyDDaV/aPGillgz1MdQg4u5MYaEtBNNHFjkRlSpd65lp4hd2AVPTfbV7FGpyIOfmNc/XVsPfg7vzaS/3nkvLL593ANLvMuRMGpQIhiF7kUEW9QDpAUbTWYBcbp4WpacHHY1aacqQyjGZS9HI3yCBT9kUZJhVOD+zUDvEH9ddR11fzPcTDQ5TlgB0KwqdXSavk9BC0pKp0WmcuowSw07VXmXC5guzSa4p0UvRw2lbDiYUx0ExJJRzWzi6Gm8cnEkfXXsdcG/M/jAJa0+bmCgdmQ9CYlNlSYZOKixmRsgiFxkrmW4l3KdFKv1DM8tk6WxPYJZhUUzcd8Kdtgrw/gkfXXDT7+avmfVak32qhtkg6NVdUS5wgkru1YzIkSduTW1FDwVWV3JQVJVuieTc0y4iDpFwc7/BvSalvKdQM8sv662cevz/+8sQVnjVAT0W2wLllw1JiMhJRxgDjCjLQsOzSFSgZqx7lAW1JW0e03yAD3asC+GD3NbQhbe+mN5GXH1F83KDOM4n/e5JIuH4NpdQARrFPBVptUNcjj4cVMcFSRTE2NpR1LEYbYMmfWpXgP9KejaPsLUhuvLCsVXznAG9dfx9SR1ud/3hZdCLHb1GMdPqRJgqDmm76mHbvOXDtiO2QPUcKo/TWkQ0i2JFXpBoo7vij1i1Lp3ADAo+qvG3V0rM//vFnnTE4hxd5Ka/Cor5YEdsLVJyKtDgVoHgtW11pWSjolPNMnrlrVj9Fv2Qn60twMwKPqr+N/wvr8z5tZcDsDrv06tkqyzESM85Ycv6XBWA2birlNCXrI6VbD2lx2L0vQO0QVTVVLH4SE67fgsfVXv8n7sz7/85Z7cMtbE6f088wSaR4kCkCm10s6pKbJhfqiUNGLq+0gLWC6eUAZFPnLjwqtKd8EwGvWX59t7iPW4X/eAN1svgRVSY990YZg06BD1ohLMtyFTI4pKTJsS9xREq9EOaPWiO2gpms7397x6nQJkbh+Fz2q/rqRROX6/M8bJrqlVW4l6JEptKeUFuMYUbtCQ7CIttpGc6MY93x1r1vgAnRXvY5cvwWPqb9uWQm+lP95QxdNMeWhOq1x0Db55C7GcUv2ZUuN6n8iKzsvOxibC//Yfs9Na8r2Rlz02vXXDT57FP/zJi66/EJSmsJKa8QxnoqW3VLQ+jZVUtJwJ8PNX1NQCwfNgdhhHD9on7PdRdrdGPF28rJr1F+3LBdeyv+8yYfLoMYet1vX4upNAjVvwOUWnlNXJXlkzk5Il6kqeoiL0C07qno+/CYBXq/+utlnsz7/Mzvy0tmI4zm4ag23PRN3t/CWryoUVJGm+5+K8RJ0V8Hc88/XHUX/HfiAq7t+BH+x6v8t438enWmdJwFA6ZINriLGKv/95f8lT9/FnyA1NMVEvQyaXuu+gz36f/DD73E4pwqpLcvm/o0Vle78n//+L/NPvoefp1pTJye6e4A/D082FERa5/opeH9zpvh13cNm19/4v/LDe5xMWTi8I0Ta0qKlK27AS/v3/r+/x/2GO9K2c7kVMonDpq7//jc5PKCxeNPpFVzaRr01wF8C4Pu76hXuX18H4LduTr79guuFD3n5BHfI+ZRFhY8w29TYhbbLi/bvBdqKE4fUgg1pBKnV3FEaCWOWyA+m3WpORZr/j+9TKJtW8yBTF2/ZEODI9/QavHkVdGFp/Pjn4Q+u5hXapsP5sOH+OXXA1LiKuqJxiMNbhTkbdJTCy4llEt6NnqRT4dhg1V3nbdrm6dYMecA1yTOL4PWTE9L5VzPFlLBCvlG58AhehnN4uHsAYinyJ+AZ/NkVvELbfOBUuOO5syBIEtiqHU1k9XeISX5bsimrkUUhnGDxourN8SgUsCZVtKyGbyGzHXdjOhsAvOAswSRyIBddRdEZWP6GZhNK/yjwew9ehBo+3jEADu7Ay2n8mDc+TS7awUHg0OMzR0LABhqLD4hJEh/BEGyBdGlSJoXYXtr+3HS4ijzVpgi0paWXtdruGTknXBz+11qT1Q2inxaTzQCO46P3lfLpyS4fou2PH/PupwZgCxNhGlj4IvUuWEsTkqMWm6i4xCSMc9N1RDQoCVcuGItJ/MRWefais+3synowi/dESgJjkilnWnBTGvRWmaw8oR15257t7CHmCf8HOn7cwI8+NQBXMBEmAa8PMRemrNCEhLGEhDQKcGZWS319BX9PFBEwGTbRBhLbDcaV3drFcDqk5kCTd2JF1Wp0HraqBx8U0wwBTnbpCadwBA/gTH/CDrcCs93LV8E0YlmmcyQRQnjBa8JESmGUfIjK/7fkaDJpmD2QptFNVJU1bbtIAjjWQizepOKptRjbzR9Kag6xZmMLLjHOtcLT3Tx9o/0EcTT1XN3E45u24AiwEypDJXihKjQxjLprEwcmRKclaDNZCVqr/V8mYWyFADbusiY5hvgFoU2vio49RgJLn5OsReRFN6tabeetiiy0V7KFHT3HyZLx491u95sn4K1QQSPKM9hNT0wMVvAWbzDSVdrKw4zRjZMyJIHkfq1VAVCDl/bUhNKlGq0zGr05+YAceXVPCttVk0oqjVwMPt+BBefx4yPtGVkUsqY3CHDPiCM5ngupUwCdbkpd8kbPrCWHhkmtIKLEetF2499eS1jZlIPGYnlcPXeM2KD9vLS0bW3ktYNqUllpKLn5ZrsxlIzxvDu5eHxzGLctkZLEY4PgSOg2IUVVcUONzUDBEpRaMoXNmUc0tFZrTZquiLyKxrSm3DvIW9Fil+AkhXu5PhEPx9mUNwqypDvZWdKlhIJQY7vn2OsnmBeOWnYZ0m1iwbbw1U60by5om47iHRV6fOgzjMf/DAZrlP40Z7syxpLK0lJ0gqaAK1c2KQKu7tabTXkLFz0sCftuwX++MyNeNn68k5Buq23YQhUh0SNTJa1ioQ0p4nUG2y0XilF1JqODqdImloPS4Bp111DEWT0jJjVv95uX9BBV7eB3bUWcu0acSVM23YZdd8R8UbQUxJ9wdu3oMuhdt929ME+mh6JXJ8di2RxbTi6TbrDquqV4aUKR2iwT6aZbyOwEXN3DUsWr8Hn4EhwNyHuXHh7/pdaUjtR7vnDh/d8c9xD/s5f501eQ1+CuDiCvGhk1AN/4Tf74RfxPwD3toLarR0zNtsnPzmS64KIRk861dMWCU8ArasG9T9H0ZBpsDGnjtAOM2+/LuIb2iIUGXNgl5ZmKD/Tw8TlaAuihaFP5yrw18v4x1898zIdP+DDAX1bM3GAMvPgRP/cJn3zCW013nrhHkrITyvYuwOUkcHuKlRSW5C6rzIdY4ppnF7J8aAJbQepgbJYBjCY9usGXDKQxq7RZfh9eg5d1UHMVATRaD/4BHK93/1iAgYZ/+jqPn8Dn4UExmWrpa3+ZOK6MvM3bjwfzxNWA2dhs8+51XHSPJiaAhGSpWevEs5xHLXcEGFXYiCONySH3fPWq93JIsBiSWvWyc3CAN+EcXoT7rCSANloPPoa31rt/5PUA/gp8Q/jDD3hyrjzlR8VkanfOvB1XPubt17vzxAfdSVbD1pzAnfgyF3ycadOTOTXhpEUoLC1HZyNGW3dtmjeXgr2r56JNmRwdNNWaQVBddd6rh4MhviEB9EFRD/7RGvePvCbwAL4Mx/D6M541hHO4D3e7g6PafdcZVw689z7NGTwo5om7A8sPhccT6qKcl9NJl9aM/9kX+e59Hh1yPqGuCCZxuITcsmNaJ5F7d0q6J3H48TO1/+M57085q2icdu2U+W36Ldllz9Agiv4YGljoEN908EzvDOrBF98/vtJwCC/BF2AG75xxEmjmMIcjxbjoaxqOK3/4hPOZzhMPBpYPG44CM0dTVm1LjLtUWWVz1Bcf8tEx0zs8O2A2YVHRxKYOiy/aOVoAaMu0i7ubu43njjmd4ibMHU1sIDHaQNKrZND/FZYdk54oCXetjq7E7IVl9eAL7t+oHnwXXtLx44czzoRFHBztYVwtH1d+NOMkupZ5MTM+gUmq90X+Bh9zjRlmaQ+m7YMqUL/veemcecAtOJ0yq1JnVlN27di2E0+Klp1tAJ4KRw1eMI7aJjsO3R8kPSI3fUFXnIOfdQe86sIIVtWDL7h//Ok6vj8vwDk08NEcI8zz7OhBy+WwalzZeZ4+0XniRfst9pAJqQHDGLzVQ2pheZnnv1OWhwO43/AgcvAEXEVVpa4db9sGvNK8wjaENHkfFQ4Ci5i7dqnQlPoLQrHXZDvO3BIXZbJOBrOaEbML6sFL798I4FhKihjHMsPjBUZYCMFr6nvaArxqXPn4lCa+cHfSa2cP27g3Z3ziYTRrcbQNGLQmGF3F3cBdzzzX7AILx0IB9rbwn9kx2G1FW3Inic+ZLIsVvKR8Zwfj0l1fkqo8LWY1M3IX14OX3r9RKTIO+d9XzAI8qRPGPn/4NC2n6o4rN8XJ82TOIvuVA8zLKUHRFgBCetlDZlqR1gLKjS39xoE7Bt8UvA6BxuEDjU3tFsEijgA+615tmZkXKqiEENrh41iLDDZNq4pKTWR3LZfnos81LOuNa15cD956vLMsJd1rqYp51gDUQqMYm2XsxnUhD2jg1DM7SeuJxxgrmpfISSXVIJIS5qJJSvJPEQ49DQTVIbYWJ9QWa/E2+c/oPK1drmC7WSfJRNKBO5Yjvcp7Gc3dmmI/Xh1kDTEuiSnWqQf37h+fTMhGnDf6dsS8SQfQWlqqwXXGlc/PEZ/SC5mtzIV0nAshlQdM/LvUtYutrEZ/Y+EAFtq1k28zQhOwLr1AIeANzhF8t9qzTdZf2qRKO6MWE9ohBYwibbOmrFtNmg3mcS+tB28xv2uKd/agYCvOP+GkSc+0lr7RXzyufL7QbkUpjLjEWFLqOIkAGu2B0tNlO9Eau2W1qcOUvVRgKzypKIQZ5KI3q0MLzqTNRYqiZOqmtqloIRlmkBHVpHmRYV6/HixbO6UC47KOFJnoMrVyr7wYz+SlW6GUaghYbY1I6kkxA2W1fSJokUdSh2LQ1GAimRGm0MT+uu57H5l7QgOWxERpO9moLRPgTtquWCfFlGlIjQaRly9odmzMOWY+IBO5tB4sW/0+VWGUh32qYk79EidWKrjWuiLpiVNGFWFRJVktyeXWmbgBBzVl8anPuXyNJlBJOlKLTgAbi/EYHVHxWiDaVR06GnHQNpJcWcK2jJtiCfG2sEHLzuI66sGrMK47nPIInPnu799935aOK2cvmvubrE38ZzZjrELCmXM2hM7UcpXD2oC3+ECVp7xtIuxptJ0jUr3sBmBS47TVxlvJ1Sqb/E0uLdvLj0lLr29ypdd/eMX3f6lrxGlKwKQxEGvw0qHbkbwrF3uHKwVENbIV2wZ13kNEF6zD+x24aLNMfDTCbDPnEikZFyTNttxWBXDaBuM8KtI2rmaMdUY7cXcUPstqTGvBGSrFWIpNMfbdea990bvAOC1YX0qbc6smDS1mPxSJoW4fwEXvjMmhlijDRq6qale6aJEuFGoppYDoBELQzLBuh/mZNx7jkinv0EtnUp50lO9hbNK57lZaMAWuWR5Yo9/kYwcYI0t4gWM47Umnl3YmpeBPqSyNp3K7s2DSAS/39KRuEN2bS4xvowV3dFRMx/VFcp2Yp8w2nTO9hCXtHG1kF1L4KlrJr2wKfyq77R7MKpFKzWlY9UkhYxyHWW6nBWPaudvEAl3CGcNpSXPZ6R9BbBtIl6cHL3gIBi+42CYXqCx1gfGWe7Ap0h3luyXdt1MKy4YUT9xSF01G16YEdWsouW9mgDHd3veyA97H+Ya47ZmEbqMY72oPztCGvK0onL44AvgC49saZKkWRz4veWljE1FHjbRJaWv6ZKKtl875h4CziFCZhG5rx7tefsl0aRT1bMHZjm8dwL/6u7wCRysaQblQoG5yAQN5zpatMNY/+yf8z+GLcH/Qn0iX2W2oEfXP4GvwQHuIL9AYGnaO3zqAX6946nkgqZNnUhx43DIdQtMFeOPrgy/y3Yd85HlJWwjLFkU3kFwq28xPnuPhMWeS+tDLV9Otllq7pQCf3uXJDN9wFDiUTgefHaiYbdfi3b3u8+iY6TnzhgehI1LTe8lcd7s1wJSzKbahCRxKKztTLXstGAiu3a6rPuQs5pk9TWAan5f0BZmGf7Ylxzzk/A7PAs4QPPPAHeFQ2hbFHszlgZuKZsJcUmbDC40sEU403cEjczstOEypa+YxevL4QBC8oRYqWdK6b7sK25tfE+oDZgtOQ2Jg8T41HGcBE6fTWHn4JtHcu9S7uYgU5KSCkl/mcnq+5/YBXOEr6lCUCwOTOM1taOI8mSxx1NsCXBEmLKbMAg5MkwbLmpBaFOPrNSlO2HnLiEqW3tHEwd8AeiQLmn+2gxjC3k6AxREqvKcJbTEzlpLiw4rNZK6oJdidbMMGX9FULKr0AkW+2qDEPBNNm5QAt2Ik2nftNWHetubosHLo2nG4vQA7GkcVCgVCgaDixHqo9UUn1A6OshapaNR/LPRYFV8siT1cCtJE0k/3WtaNSuUZYKPnsVIW0xXWnMUxq5+En4Kvw/MqQmVXnAXj9Z+9zM98zM/Agy7F/qqj2Nh67b8HjFnPP3iBn/tkpdzwEJX/whIcQUXOaikeliCRGUk7tiwF0rItwMEhjkZ309hikFoRAmLTpEXWuHS6y+am/KB/fM50aLEhGnSMwkpxzOov4H0AvgovwJ1iGzDLtJn/9BU+fAINfwUe6FHSLhu83viV/+/HrOePX+STT2B9uWGbrMHHLldRBlhS/CJQmcRxJFqZica01XixAZsYiH1uolZxLrR/SgxVIJjkpQP4PE9sE59LKLr7kltSBogS5tyszzH8Fvw8/AS8rNOg0xUS9fIaHwb+6et8Q/gyvKRjf5OusOzGx8evA/BP4IP11uN/grca5O0lcsPLJ5YjwI4QkJBOHa0WdMZYGxPbh2W2nR9v3WxEWqgp/G3+6VZbRLSAAZ3BhdhAaUL33VUSw9yjEsvbaQ9u4A/gGXwZXoEHOuU1GSj2chf+Mo+f8IcfcAxfIKVmyunRbYQVnoevwgfw3TXXcw++xNuP4fhyueEUNttEduRVaDttddoP0eSxLe2LENk6itYxlrxBNBYrNNKSQmeaLcm9c8UsaB5WyO6675yyQIAWSDpBVoA/gxmcwEvwoDv0m58UE7gHn+fJOa8/Ywan8EKRfjsopF83eCglX/Sfr7OeaRoQfvt1CGvIDccH5BCvw1sWIzRGC/66t0VTcLZQZtm6PlAasbOJ9iwWtUo7biktTSIPxnR24jxP1ZKaqq+2RcXM9OrBAm/AAs7hDJ5bNmGb+KIfwCs8a3jnjBrOFeMjHSCdbKr+2uOLfnOd9eiA8Hvvwwq54VbP2OqwkB48Ytc4YEOiH2vTXqodabfWEOzso4qxdbqD5L6tbtNPECqbhnA708DZH4QOJUXqScmUlks7Ot6FBuZw3n2mEbaUX7kDzxHOOQk8nKWMzAzu6ZZ8sOFw4RK+6PcuXo9tB4SbMz58ApfKDXf3szjNIIbGpD5TKTRxGkEMLjLl+K3wlWXBsCUxIDU+jbOiysESqAy1MGUJpXgwbTWzNOVEziIXZrJ+VIztl1PUBxTSo0dwn2bOmfDRPD3TRTGlfbCJvO9KvuhL1hMHhB9wPuPRLGHcdOWG2xc0U+5bQtAJT0nRTewXL1pgk2+rZAdeWmz3jxAqfNQQdzTlbF8uJ5ecEIWvTkevAHpwz7w78QujlD/Lr491bD8/1vhM2yrUQRrWXNQY4fGilfctMWYjL72UL/qS9eiA8EmN88nbNdour+PBbbAjOjIa4iBhfFg6rxeKdEGcL6p3EWR1Qq2Qkhs2DrnkRnmN9tG2EAqmgPw6hoL7Oza7B+3SCrR9tRftko+Lsf2F/mkTndN2LmzuMcKTuj/mX2+4Va3ki16+nnJY+S7MefpkidxwnV+4wkXH8TKnX0tsYzYp29DOOoSW1nf7nTh2akYiWmcJOuTidSaqESrTYpwjJJNVGQr+rLI7WsqerHW6Kp/oM2pKuV7T1QY9gjqlZp41/WfKpl56FV/0kvXQFRyeQ83xaTu5E8p5dNP3dUF34ihyI3GSpeCsywSh22ZJdWto9winhqifb7VRvgktxp13vyjrS0EjvrRfZ62uyqddSWaWYlwTPAtJZ2oZ3j/Sgi/mi+6vpzesfAcWNA0n8xVyw90GVFGuZjTXEQy+6GfLGLMLL523f5E0OmxVjDoOuRiH91RKU+vtoCtH7TgmvBLvtFXWLW15H9GTdVw8ow4IlRLeHECN9ym1e9K0I+Cbnhgv4Yu+aD2HaQJ80XDqOzSGAV4+4yCqBxrsJAX6ZTIoX36QnvzhhzzMfFW2dZVLOJfo0zbce5OvwXMFaZ81mOnlTVXpDZsQNuoYWveketKb5+6JOOsgX+NTm7H49fUTlx+WLuWL7qxnOFh4BxpmJx0p2gDzA/BUARuS6phR+pUsY7MMboAHx5xNsSVfVZcYSwqCKrqon7zM+8ecCkeS4nm3rINuaWvVNnMRI1IRpxTqx8PZUZ0Br/UEduo3B3hNvmgZfs9gQPj8vIOxd2kndir3awvJ6BLvoUuOfFWNYB0LR1OQJoUySKb9IlOBx74q1+ADC2G6rOdmFdJcD8BkfualA+BdjOOzP9uUhGUEX/TwhZsUduwRr8wNuXKurCixLBgpQI0mDbJr9dIqUuV+92ngkJZ7xduCk2yZKbfWrH1VBiTg9VdzsgRjW3CVXCvAwDd+c1z9dWw9+B+8MJL/eY15ZQ/HqvTwVdsZn5WQsgRRnMaWaecu3jFvMBEmgg+FJFZsnSl0zjB9OqPYaBD7qmoVyImFvzi41usesV0julaAR9dfR15Xzv9sEruRDyk1nb+QaLU67T885GTls6YgcY+UiMa25M/pwGrbCfzkvR3e0jjtuaFtnwuagHTSb5y7boBH119HXhvwP487jJLsLJ4XnUkHX5sLbS61dpiAXRoZSCrFJ+EjpeU3puVfitngYNo6PJrAigKktmwjyQdZpfq30mmtulaAx9Zfx15Xzv+cyeuiBFUs9zq8Kq+XB9a4PVvph3GV4E3y8HENJrN55H1X2p8VyqSKwVusJDKzXOZzplWdzBUFK9e+B4+uv468xvI/b5xtSAkBHQaPvtqWzllVvEOxPbuiE6+j2pvjcKsbvI7txnRErgfH7LdXqjq0IokKzga14GzQ23SSbCQvO6r+Or7SMIr/efOkkqSdMnj9mBx2DRsiY29Uj6+qK9ZrssCKaptR6HKURdwUYeUWA2kPzVKQO8ku2nU3Anhs/XWkBx3F/7wJtCTTTIKftthue1ty9xvNYLY/zo5KSbIuKbXpbEdSyeRyYdAIwKY2neyoc3+k1XUaufYga3T9daMUx/r8z1s10ITknIO0kuoMt+TB8jK0lpayqqjsJ2qtXAYwBU932zinimgmd6mTRDnQfr88q36NAI+tv24E8Pr8zxtasBqx0+xHH9HhlrwsxxNUfKOHQaZBITNf0uccj8GXiVmXAuPEAKSdN/4GLHhs/XWj92dN/uetNuBMnVR+XWDc25JLjo5Mg5IZIq226tmCsip2zZliL213YrTlL2hcFjpCduyim3M7/eB16q/blQsv5X/esDRbtJeabLIosWy3ycavwLhtxdWzbMmHiBTiVjJo6lCLjXZsi7p9PEPnsq6X6wd4bP11i0rD5fzPm/0A6brrIsllenZs0lCJlU4abakR59enZKrKe3BZihbTxlyZ2zl1+g0wvgmA166/bhwDrcn/7Ddz0eWZuJvfSESug6NzZsox3Z04FIxz0mUjMwVOOVTq1CQ0AhdbBGVdjG/CgsfUX7esJl3K/7ytWHRv683praW/8iDOCqWLLhpljDY1ZpzK75QiaZoOTpLKl60auHS/97oBXrv+umU9+FL+5+NtLFgjqVLCdbmj7pY5zPCPLOHNCwXGOcLquOhi8CmCWvbcuO73XmMUPab+ug3A6/A/78Bwe0bcS2+tgHn4J5pyS2WbOck0F51Vq3LcjhLvZ67p1ABbaL2H67bg78BfjKi/jr3+T/ABV3ilLmNXTI2SpvxWBtt6/Z//D0z/FXaGbSBgylzlsEGp+5//xrd4/ae4d8DUUjlslfIYS3t06HZpvfQtvv0N7AHWqtjP2pW08QD/FLy//da38vo8PNlKHf5y37Dxdfe/oj4kVIgFq3koLReSR76W/bx//n9k8jonZxzWTANVwEniDsg87sOSd/z7//PvMp3jQiptGVWFX2caezzAXwfgtzYUvbr0iozs32c3Uge7varH+CNE6cvEYmzbPZ9hMaYDdjK4V2iecf6EcEbdUDVUARda2KzO/JtCuDbNQB/iTeL0EG1JSO1jbXS+nLxtPMDPw1fh5+EPrgSEKE/8Gry5A73ui87AmxwdatyMEBCPNOCSKUeRZ2P6Myb5MRvgCHmA9ywsMifU+AYXcB6Xa5GibUC5TSyerxyh0j6QgLVpdyhfArRTTLqQjwe4HOD9s92D4Ap54odXAPBWLAwB02igG5Kkc+piN4lvODIFGAZgT+EO4Si1s7fjSR7vcQETUkRm9O+MXyo9OYhfe4xt9STQ2pcZRLayCV90b4D3jR0DYAfyxJ+eywg2IL7NTMXna7S/RpQ63JhWEM8U41ZyQGjwsVS0QBrEKLu8xwZsbi4wLcCT+OGidPIOCe1PiSc9Qt+go+vYqB7cG+B9d8cAD+WJPz0Am2gxXgU9IneOqDpAAXOsOltVuMzpdakJXrdPCzXiNVUpCeOos5cxnpQT39G+XVLhs1osQVvJKPZyNq8HDwd4d7pNDuWJPxVX7MSzqUDU6gfadKiNlUFTzLeFHHDlzO4kpa7aiKhBPGKwOqxsBAmYkOIpipyXcQSPlRTf+Tii0U3EJGaZsDER2qoB3h2hu0qe+NNwUooYU8y5mILbJe6OuX+2FTKy7bieTDAemaQyQ0CPthljSWO+xmFDIYiESjM5xKd6Ik5lvLq5GrQ3aCMLvmCA9wowLuWJb9xF59hVVP6O0CrBi3ZjZSNOvRy+I6klNVRJYRBaEzdN+imiUXQ8iVF8fsp+W4JXw7WISW7fDh7lptWkCwZ4d7QTXyBPfJMYK7SijjFppGnlIVJBJBYj7eUwtiP1IBXGI1XCsjNpbjENVpSAJ2hq2LTywEly3hUYazt31J8w2+aiLx3g3fohXixPfOMYm6zCGs9LVo9MoW3MCJE7R5u/WsOIjrqBoHUO0bJE9vxBpbhsd3+Nb4/vtPCZ4oZYCitNeYuC/8UDvDvy0qvkiW/cgqNqRyzqSZa/s0mqNGjtKOoTm14zZpUauiQgVfqtQiZjq7Q27JNaSK5ExRcrGCXO1FJYh6jR6CFqK7bZdQZ4t8g0rSlPfP1RdBtqaa9diqtzJkQ9duSryi2brQXbxDwbRUpFMBHjRj8+Nt7GDKgvph9okW7LX47gu0SpGnnFQ1S1lYldOsC7hYteR574ZuKs7Ei1lBsfdz7IZoxzzCVmmVqaSySzQbBVAWDek+N4jh9E/4VqZrJjPwiv9BC1XcvOWgO8275CVyBPvAtTVlDJfZkaZGU7NpqBogAj/xEHkeAuJihWYCxGN6e8+9JtSegFXF1TrhhLGP1fak3pebgPz192/8gB4d/6WT7+GdYnpH7hH/DJzzFiYPn/vjW0SgNpTNuPIZoAEZv8tlGw4+RLxy+ZjnKa5NdFoC7UaW0aduoYse6+bXg1DLg6UfRYwmhGEjqPvF75U558SANrElK/+MdpXvmqBpaXOa/MTZaa1DOcSiLaw9j0NNNst3c+63c7EKTpkvKHzu6bPbP0RkuHAVcbRY8ijP46MIbQeeT1mhA+5PV/inyDdQipf8LTvMXbwvoDy7IruDNVZKTfV4CTSRUYdybUCnGU7KUTDxLgCknqUm5aAW6/1p6eMsOYsphLzsHrE0Y/P5bQedx1F/4yPHnMB3/IOoTU9+BL8PhtjuFKBpZXnYNJxTuv+2XqolKR2UQgHhS5novuxVySJhBNRF3SoKK1XZbbXjVwWNyOjlqWJjrWJIy+P5bQedyldNScP+HZ61xKSK3jyrz+NiHG1hcOLL/+P+PDF2gOkekKGiNWKgJ+8Z/x8Iv4DdQHzcpZyF4v19I27w9/yPGDFQvmEpKtqv/TLiWMfn4sofMm9eAH8Ao0zzh7h4sJqYtxZd5/D7hkYPneDzl5idlzNHcIB0jVlQ+8ULzw/nc5/ojzl2juE0apD7LRnJxe04dMz2iOCFNtGFpTuXA5AhcTRo8mdN4kz30nVjEC4YTZQy4gpC7GlTlrePKhGsKKgeXpCYeO0MAd/GH7yKQUlXPLOasOH3FnSphjHuDvEu4gB8g66oNbtr6eMbFIA4fIBJkgayoXriw2XEDQPJrQeROAlY6aeYOcMf+IVYTU3XFlZufMHinGywaW3YLpObVBAsbjF4QJMsVUSayjk4voPsHJOQfPWDhCgDnmDl6XIRerD24HsGtw86RMHOLvVSHrKBdeVE26gKB5NKHzaIwLOmrqBWJYZDLhASG16c0Tn+CdRhWDgWXnqRZUTnPIHuMJTfLVpkoYy5CzylHVTGZMTwkGAo2HBlkQplrJX6U+uF1wZz2uwS1SQ12IqWaPuO4baZaEFBdukksJmkcTOm+YJSvoqPFzxFA/YUhIvWxcmSdPWTWwbAKVp6rxTtPFUZfKIwpzm4IoMfaYQLWgmlG5FME2gdBgm+J7J+rtS/XBbaVLsR7bpPQnpMFlo2doWaVceHk9+MkyguZNCJ1He+kuHTWyQAzNM5YSUg/GlTk9ZunAsg1qELVOhUSAK0LABIJHLKbqaEbHZLL1VA3VgqoiOKXYiS+HRyaEKgsfIqX64HYWbLRXy/qWoylIV9gudL1OWBNgBgTNmxA6b4txDT4gi3Ri7xFSLxtXpmmYnzAcWDZgY8d503LFogz5sbonDgkKcxGsWsE1OI+rcQtlgBBCSOKD1mtqYpIU8cTvBmAT0yZe+zUzeY92fYjTtGipXLhuR0ePoHk0ofNWBX+lo8Z7pAZDk8mEw5L7dVyZZoE/pTewbI6SNbiAL5xeygW4xPRuLCGbhcO4RIeTMFYHEJkYyEO9HmJfXMDEj/LaH781wHHZEtqSQ/69UnGpzH7LKIAZEDSPJnTesJTUa+rwTepI9dLJEawYV+ZkRn9g+QirD8vF8Mq0jFQ29js6kCS3E1+jZIhgPNanHdHFqFvPJLHqFwQqbIA4jhDxcNsOCCQLDomaL/dr5lyJaJU6FxPFjO3JOh3kVMcROo8u+C+jo05GjMF3P3/FuDLn5x2M04xXULPwaS6hBYki+MrMdZJSgPHlcB7nCR5bJ9Kr5ACUn9jk5kivdd8tk95SOGrtqu9lr2IhK65ZtEl7ZKrp7DrqwZfRUSN1el7+7NJxZbywOC8neNKTch5vsTEMNsoCCqHBCqIPRjIPkm0BjvFODGtto99rCl+d3wmHkW0FPdpZtC7MMcVtGFQjJLX5bdQ2+x9ypdc313uj8xlsrfuLgWXz1cRhZvJYX0iNVBRcVcmCXZs6aEf3RQF2WI/TcCbKmGU3IOoDJGDdDub0+hYckt6PlGu2BcxmhbTdj/klhccLGJMcqRjMJP1jW2ETqLSWJ/29MAoORluJ+6LPffBZbi5gqi5h6catQpmOT7/OFf5UorRpLzCqcMltBLhwd1are3kztrSzXO0LUbXRQcdLh/RdSZ+swRm819REDrtqzC4es6Gw4JCKlSnjYVpo0xeq33PrADbFLL3RuCmObVmPN+24kfa+AojDuM4umKe2QwCf6EN906HwjujaitDs5o0s1y+k3lgbT2W2i7FJdnwbLXhJUBq/9liTctSmFC/0OqUinb0QddTWamtjbHRFuWJJ6NpqZ8vO3fZJ37Db+2GkaPYLGHs7XTTdiFQJ68SkVJFVmY6McR5UycflNCsccHFaV9FNbR4NttLxw4pQ7wJd066Z0ohVbzihaxHVExd/ay04oxUKWt+AsdiQ9OUyZ2krzN19IZIwafSTFgIBnMV73ADj7V/K8u1MaY2sJp2HWm0f41tqwajEvdHWOJs510MaAqN4aoSiPCXtN2KSi46dUxHdaMquar82O1x5jqhDGvqmoE9LfxcY3zqA7/x3HA67r9ZG4O6Cuxu12/+TP+eLP+I+HErqDDCDVmBDO4larujNe7x8om2rMug0MX0rL1+IWwdwfR+p1TNTyNmVJ85ljWzbWuGv8/C7HD/izjkHNZNYlhZcUOKVzKFUxsxxN/kax+8zPWPSFKw80rJr9Tizyj3o1gEsdwgWGoxPezDdZ1TSENE1dLdNvuKL+I84nxKesZgxXVA1VA1OcL49dFlpFV5yJMhzyCmNQ+a4BqusPJ2bB+xo8V9u3x48VVIEPS/mc3DvAbXyoYr6VgDfh5do5hhHOCXMqBZUPhWYbWZECwVJljLgMUWOCB4MUuMaxGNUQDVI50TQ+S3kFgIcu2qKkNSHVoM0SHsgoZxP2d5HH8B9woOk4x5bPkKtAHucZsdykjxuIpbUrSILgrT8G7G5oCW+K0990o7E3T6AdW4TilH5kDjds+H64kS0mz24grtwlzDHBJqI8YJQExotPvoC4JBq0lEjjQkyBZ8oH2LnRsQ4Hu1QsgDTJbO8fQDnllitkxuVskoiKbRF9VwzMDvxHAdwB7mD9yCplhHFEyUWHx3WtwCbSMMTCUCcEmSGlg4gTXkHpZXWQ7kpznK3EmCHiXInqndkQjunG5kxTKEeGye7jWz9cyMR2mGiFQ15ENRBTbCp+Gh86vAyASdgmJq2MC6hoADQ3GosP0QHbnMHjyBQvQqfhy/BUbeHd5WY/G/9LK/8Ka8Jd7UFeNWEZvzPb458Dn8DGLOe3/wGL/4xP+HXlRt+M1PE2iLhR8t+lfgxsuh7AfO2AOf+owWhSZRYQbd622hbpKWKuU+XuvNzP0OseRDa+mObgDHJUSc/pKx31QdKffQ5OIJpt8GWjlgTwMc/w5MPCR/yl1XC2a2Yut54SvOtMev55Of45BOat9aWG27p2ZVORRvnEk1hqWMVUmqa7S2YtvlIpspuF1pt0syuZS2NV14mUidCSfzQzg+KqvIYCMljIx2YK2AO34fX4GWdu5xcIAb8MzTw+j/lyWM+Dw/gjs4GD6ehNgA48kX/AI7XXM/XAN4WHr+9ntywqoCakCqmKP0rmQrJJEErG2Upg1JObr01lKQy4jskWalKYfJ/EDLMpjNSHFEUAde2fltaDgmrNaWQ9+AAb8I5vKjz3L1n1LriB/BXkG/wwR9y/oRX4LlioHA4LzP2inzRx/DWmutRweFjeP3tNeSGlaE1Fde0OS11yOpmbIp2u/jF1n2RRZviJM0yBT3IZl2HWImKjQOxIyeU325b/qWyU9Moj1o07tS0G7qJDoGHg5m8yeCxMoEH8GU45tnrNM84D2l297DQ9t1YP7jki/7RmutRweEA77/HWXOh3HCxkRgldDQkAjNTMl2Iloc1qN5JfJeeTlyTRzxURTdn1Ixv2uKjs12AbdEWlBtmVdk2k7FFwj07PCZ9XAwW3dG+8xKzNFr4EnwBZpy9Qzhh3jDXebBpYcpuo4fQ44u+fD1dweEnHzI7v0xuuOALRUV8rXpFyfSTQYkhd7IHm07jpyhlkCmI0ALYqPTpUxXS+z4jgDj1Pflvmz5ecuItpIBxyTHpSTGWd9g1ApfD/bvwUhL4nT1EzqgX7cxfCcNmb3mPL/qi9SwTHJ49oj5ZLjccbTG3pRmlYi6JCG0mQrAt1+i2UXTZ2dv9IlQpN5naMYtviaXlTrFpoMsl3bOAFEa8sqPj2WCMrx3Yjx99qFwO59Aw/wgx+HlqNz8oZvA3exRDvuhL1jMQHPaOJ0+XyA3fp1OfM3qObEVdhxjvynxNMXQV4+GJyvOEFqeQBaIbbO7i63rpxCltdZShPFxkjM2FPVkn3TG+Rp9pO3l2RzFegGfxGDHIAh8SteR0C4HopXzRF61nheDw6TFN05Ebvq8M3VKKpGjjO6r7nhudTEGMtYM92HTDaR1FDMXJ1eThsbKfywyoWwrzRSXkc51flG3vIid62h29bIcFbTGhfV+faaB+ohj7dPN0C2e2lC96+XouFByen9AsunLDJZ9z7NExiUc0OuoYW6UZkIyx2YUR2z6/TiRjyKMx5GbbjLHvHuf7YmtKghf34LJfx63Yg8vrvN2zC7lY0x0tvKezo4HmGYDU+Gab6dFL+KI761lDcNifcjLrrr9LWZJctG1FfU1uwhoQE22ObjdfkSzY63CbU5hzs21WeTddH2BaL11Gi7lVdlxP1nkxqhnKhVY6knS3EPgVGg1JpN5cP/hivujOelhXcPj8HC/LyI6MkteVjlolBdMmF3a3DbsuAYhL44dxzthWSN065xxUd55Lmf0wRbOYOqH09/o9WbO2VtFdaMb4qBgtFJoT1SqoN8wPXMoXLb3p1PUEhxfnnLzGzBI0Ku7FxrKsNJj/8bn/H8fPIVOd3rfrklUB/DOeO+nkghgSPzrlPxluCMtOnDL4Yml6dK1r3vsgMxgtPOrMFUZbEUbTdIzii5beq72G4PD0DKnwjmBULUVFmy8t+k7fZ3pKc0Q4UC6jpVRqS9Umv8bxw35flZVOU1X7qkjnhZlsMbk24qQ6Hz7QcuL6sDC0iHHki96Uh2UdvmgZnjIvExy2TeJdMDZNSbdZyAHe/Yd1xsQhHiKzjh7GxQ4yqMPaywPkjMamvqrYpmO7Knad+ZQC5msCuAPWUoxrxVhrGv7a+KLXFhyONdTMrZ7ke23qiO40ZJUyzgYyX5XyL0mV7NiUzEs9mjtbMN0dERqwyAJpigad0B3/zRV7s4PIfXSu6YV/MK7+OrYe/JvfGMn/PHJe2fyUdtnFrKRNpXV0Y2559aWPt/G4BlvjTMtXlVIWCnNyA3YQBDmYIodFz41PvXPSa6rq9lWZawZ4dP115HXV/M/tnFkkrBOdzg6aP4pID+MZnTJ1SuuB6iZlyiox4HT2y3YBtkUKWooacBQUDTpjwaDt5poBHl1/HXltwP887lKKXxNUEyPqpGTyA699UqY/lt9yGdlUKra0fFWS+36iylVWrAyd7Uw0CZM0z7xKTOduznLIjG2Hx8cDPLb+OvK6Bv7n1DYci4CxUuRxrjBc0bb4vD3rN5Zz36ntLb83eVJIB8LiIzCmn6SMPjlX+yNlTjvIGjs+QzHPf60Aj62/jrzG8j9vYMFtm1VoRWCJdmw7z9N0t+c8cxZpPeK4aTRicS25QhrVtUp7U578chk4q04Wx4YoQSjFryUlpcQ1AbxZ/XVMknIU//OGl7Q6z9Zpxi0+3yFhSkjUDpnCIUhLWVX23KQ+L9vKvFKI0ZWFQgkDLvBoylrHNVmaw10zwCPrr5tlodfnf94EWnQ0lFRWy8pW9LbkLsyUVDc2NSTHGDtnD1uMtchjbCeb1mpxFP0YbcClhzdLu6lfO8Bj6q+bdT2sz/+8SZCV7VIxtt0DUn9L7r4cLYWDSXnseEpOGFuty0qbOVlS7NNzs5FOGJUqQpl2Q64/yBpZf90sxbE+//PGdZ02HSipCbmD6NItmQ4Lk5XUrGpDMkhbMm2ZVheNYV+VbUWTcv99+2NyX1VoafSuC+AN6q9bFIMv5X/eagNWXZxEa9JjlMwNWb00akGUkSoepp1/yRuuqHGbUn3UdBSTxBU6SEVklzWRUkPndVvw2PrrpjvxOvzPmwHc0hpmq82npi7GRro8dXp0KXnUQmhZbRL7NEVp1uuZmO45vuzKsHrktS3GLWXODVjw+vXXLYx4Hf7njRPd0i3aoAGX6W29GnaV5YdyDj9TFkakje7GHYzDoObfddHtOSpoi2SmzJHrB3hM/XUDDEbxP2/oosszcRlehWXUvzHv4TpBVktHqwenFo8uLVmy4DKLa5d3RtLrmrM3aMFr1183E4sewf+85VWeg1c5ag276NZrM9IJVNcmLEvDNaV62aq+14IAOGFsBt973Ra8Xv11YzXwNfmft7Jg2oS+XOyoC8/cwzi66Dhmgk38kUmP1CUiYWOX1bpD2zWXt2FCp7uq8703APAa9dfNdscR/M/bZLIyouVxqJfeWvG9Je+JVckHQ9+CI9NWxz+blX/KYYvO5n2tAP/vrlZ7+8/h9y+9qeB/Hnt967e5mevX10rALDWK//FaAT5MXdBXdP0C/BAes792c40H+AiAp1e1oH8HgH94g/Lttx1gp63op1eyoM/Bvw5/G/7xFbqJPcCXnmBiwDPb/YKO4FX4OjyCb289db2/Noqicw4i7N6TVtoz8tNwDH+8x/i6Ae7lmaQVENzJFb3Di/BFeAwz+Is9SjeQySpPqbLFlNmyz47z5a/AF+AYFvDmHqibSXTEzoT4Gc3OALaqAP4KPFUJ6n+1x+rGAM6Zd78bgJ0a8QN4GU614vxwD9e1Amy6CcskNrczLx1JIp6HE5UZD/DBHrFr2oNlgG4Odv226BodoryjGJ9q2T/AR3vQrsOCS0ctXZi3ruLlhpFDJYl4HmYtjQCP9rhdn4suySLKDt6wLcC52h8xPlcjju1fn+yhuw4LZsAGUuo2b4Fx2UwQu77uqRHXGtg92aN3tQCbFexc0uk93vhTXbct6y7MulLycoUljx8ngDMBg1tvJjAazpEmOtxlzclvj1vQf1Tx7QlPDpGpqgtdSKz/d9/hdy1vTfFHSmC9dGDZbLiezz7Ac801HirGZsWjydfZyPvHXL/Y8Mjzg8BxTZiuwKz4Eb8sBE9zznszmjvFwHKPIWUnwhqfVRcd4Ck0K6ate48m1oOfrX3/yOtvAsJ8zsPAM89sjnddmuLuDPjX9Bu/L7x7xpMzFk6nWtyQfPg278Gn4Aekz2ZgOmU9eJ37R14vwE/BL8G3aibCiWMWWDQ0ZtkPMnlcGeAu/Ag+8ZyecU5BPuy2ILD+sQqyZhAKmn7XZd+jIMTN9eBL7x95xVLSX4On8EcNlXDqmBlqS13jG4LpmGbkF/0CnOi3H8ETOIXzmnmtb0a16Tzxj1sUvQCBiXZGDtmB3KAefPH94xcUa/6vwRn80GOFyjEXFpba4A1e8KQfFF+259tx5XS4egYn8fQsLGrqGrHbztr+uByTahWuL1NUGbDpsnrwBfePPwHHIf9X4RnM4Z2ABWdxUBlqQ2PwhuDxoS0vvqB1JzS0P4h2nA/QgTrsJFn+Y3AOjs9JFC07CGWX1oNX3T/yHOzgDjwPn1PM3g9Jk9lZrMEpxnlPmBbjyo2+KFXRU52TJM/2ALcY57RUzjObbjqxVw++4P6RAOf58pcVsw9Daje3htriYrpDOonre3CudSe6bfkTEgHBHuDiyu5MCsc7BHhYDx7ePxLjqigXZsw+ijMHFhuwBmtoTPtOxOrTvYJDnC75dnUbhfwu/ZW9AgYd+peL68HD+0emKquiXHhWjJg/UrkJYzuiaL3E9aI/ytrCvAd4GcYZMCkSQxfUg3v3j8c4e90j5ZTPdvmJJGHnOCI2nHS8081X013pHuBlV1gB2MX1YNmWLHqqGN/TWmG0y6clJWthxNUl48q38Bi8vtMKyzzpFdSDhxZ5WBA5ZLt8Jv3895DduBlgbPYAj8C4B8hO68FDkoh5lydC4FiWvBOVqjYdqjiLv92t8yPDjrDaiHdUD15qkSURSGmXJwOMSxWAXYwr3zaAufJ66l+94vv3AO+vPcD7aw/w/toDvL/2AO+vPcD7aw/wHuD9tQd4f+0B3l97gPfXHuD9tQd4f+0B3l97gG8LwP8G/AL8O/A5OCq0Ys2KIdv/qOIXG/4mvFAMF16gZD+2Xvu/B8as5+8bfllWyg0zaNO5bfXj6vfhhwD86/Aq3NfRS9t9WPnhfnvCIw/CT8GLcFTMnpntdF/z9V+PWc/vWoIH+FL3Znv57PitcdGP4R/C34avw5fgRVUInCwbsn1yyA8C8zm/BH8NXoXnVE6wVPjdeCI38kX/3+Ct9dbz1pTmHFRu+Hm4O9Ch3clr99negxfwj+ER/DR8EV6B5+DuQOnTgUw5rnkY+FbNU3gNXh0o/JYTuWOvyBf9FvzX663HH/HejO8LwAl8Hl5YLTd8q7sqA3wbjuExfAFegQdwfyDoSkWY8swzEf6o4Qyewefg+cHNbqMQruSL/u/WWc+E5g7vnnEXgDmcDeSGb/F4cBcCgT+GGRzDU3hZYburAt9TEtHgbM6JoxJ+6NMzzTcf6c2bycv2+KK/f+l6LBzw5IwfqZJhA3M472pWT/ajKxnjv4AFnMEpnBTPND6s2J7qHbPAqcMK74T2mZ4VGB9uJA465It+/eL1WKhYOD7xHOkr1ajK7d0C4+ke4Hy9qXZwpgLr+Znm/uNFw8xQOSy8H9IzjUrd9+BIfenYaylf9FsXr8fBAadnPIEDna8IBcwlxnuA0/Wv6GAWPd7dDIKjMdSWueAsBj4M7TOd06qBbwDwKr7oleuxMOEcTuEZTHWvDYUO7aHqAe0Bbq+HEFRzOz7WVoTDQkVds7A4sIIxfCQdCefFRoIOF/NFL1mPab/nvOakSL/Q1aFtNpUb/nFOVX6gzyg/1nISyDfUhsokIzaBR9Kxm80s5mK+6P56il1jXic7nhQxsxSm3OwBHl4fFdLqi64nDQZvqE2at7cWAp/IVvrN6/BFL1mPhYrGMBfOi4PyjuSGf6wBBh7p/FZTghCNWGgMzlBbrNJoPJX2mW5mwZfyRffXo7OFi5pZcS4qZUrlViptrXtw+GQoyhDPS+ANjcGBNRiLCQDPZPMHuiZfdFpPSTcQwwKYdRNqpkjm7AFeeT0pJzALgo7g8YYGrMHS0iocy+YTm2vyRUvvpXCIpQ5pe666TJrcygnScUf/p0NDs/iAI/nqDHC8TmQT8x3NF91l76oDdQGwu61Z6E0ABv7uO1dbf/37Zlv+Zw/Pbh8f1s4Avur6657/+YYBvur6657/+YYBvur6657/+YYBvur6657/+aYBvuL6657/+VMA8FXWX/f8zzcN8BXXX/f8zzcNMFdbf93zP38KLPiK6697/uebtuArrr/u+Z9vGmCusP6653/+1FjwVdZf9/zPN7oHX339dc//fNMu+irrr3v+50+Bi+Zq6697/uebA/jz8Pudf9ht/fWv517J/XUzAP8C/BAeX9WCDrUpZ3/dEMBxgPcfbtTVvsYV5Yn32u03B3Ac4P3b8I+vxNBKeeL9dRMAlwO83959qGO78sT769oB7g3w/vGVYFzKE++v6wV4OMD7F7tckFkmT7y/rhHgpQO8b+4Y46XyxPvrugBeNcB7BRiX8sT767oAvmCA9woAHsoT76+rBJjLBnh3txOvkifeX1dswZcO8G6N7sXyxPvr6i340gHe3TnqVfLE++uKAb50gHcXLnrX8sR7gNdPRqwzwLu7Y/FO5Yn3AK9jXCMGeHdgxDuVJ75VAI8ljP7PAb3/RfjcZfePHBB+79dpfpH1CanN30d+mT1h9GqAxxJGM5LQeeQ1+Tb+EQJrElLb38VHQ94TRq900aMIo8cSOo+8Dp8QfsB8zpqE1NO3OI9Zrj1h9EV78PqE0WMJnUdeU6E+Jjyk/hbrEFIfeWbvId8H9oTRFwdZaxJGvziW0Hn0gqYB/wyZ0PwRlxJST+BOw9m77Amj14ii1yGM/txYQudN0qDzGe4EqfA/5GJCagsHcPaEPWH0esekSwmjRxM6b5JEcZ4ww50ilvAOFxBSx4yLW+A/YU8YvfY5+ALC6NGEzhtmyZoFZoarwBLeZxUhtY4rc3bKnjB6TKJjFUHzJoTOozF2YBpsjcyxDgzhQ1YRUse8+J4wenwmaylB82hC5w0zoRXUNXaRBmSMQUqiWSWkLsaVqc/ZE0aPTFUuJWgeTei8SfLZQeMxNaZSIzbII4aE1Nmr13P2hNHjc9E9guYNCZ032YlNwESMLcZiLQHkE4aE1BFg0yAR4z1h9AiAGRA0jyZ03tyIxWMajMPWBIsxYJCnlITU5ShiHYdZ94TR4wCmSxg9jtB5KyPGYzymAYexWEMwAPIsAdYdV6aObmNPGD0aYLoEzaMJnTc0Ygs+YDw0GAtqxBjkuP38bMRWCHn73xNGjz75P73WenCEJnhwyVe3AEe8TtKdJcYhBl97wuhNAObK66lvD/9J9NS75v17wuitAN5fe4D31x7g/bUHeH/tAd5fe4D3AO+vPcD7aw/w/toDvL/2AO+vPcD7aw/w/toDvAd4f/24ABzZ8o+KLsSLS+Pv/TqTb3P4hKlQrTGh+fbIBT0Axqznnb+L/V2mb3HkN5Mb/nEHeK7d4IcDld6lmDW/iH9E+AH1MdOw/Jlu2T1xNmY98sv4wHnD7D3uNHu54WUuOsBTbQuvBsPT/UfzNxGYzwkP8c+Yz3C+r/i6DcyRL/rZ+utRwWH5PmfvcvYEt9jLDS/bg0/B64DWKrQM8AL8FPwS9beQCe6EMKNZYJol37jBMy35otdaz0Bw2H/C2Smc7+WGB0HWDELBmOByA3r5QONo4V+DpzR/hFS4U8wMW1PXNB4TOqYz9urxRV++ntWCw/U59Ty9ebdWbrgfRS9AYKKN63ZokZVygr8GZ/gfIhZXIXPsAlNjPOLBby5c1eOLvmQ9lwkOy5x6QV1j5TYqpS05JtUgUHUp5toHGsVfn4NX4RnMCe+AxTpwmApTYxqMxwfCeJGjpXzRF61nbcHhUBPqWze9svwcHJ+S6NPscKrEjug78Dx8Lj3T8D4YxGIdxmJcwhi34fzZUr7olevZCw5vkOhoClq5zBPZAnygD/Tl9EzDh6kl3VhsHYcDEb+hCtJSvuiV69kLDm+WycrOTArHmB5/VYyP6jOVjwgGawk2zQOaTcc1L+aLXrKeveDwZqlKrw8U9Y1p66uK8dEzdYwBeUQAY7DbyYNezBfdWQ97weEtAKYQg2xJIkuveAT3dYeLGH+ShrWNwZgN0b2YL7qznr3g8JYAo5bQBziPjx7BPZ0d9RCQp4UZbnFdzBddor4XHN4KYMrB2qHFRIzzcLAHQZ5the5ovui94PCWAPefaYnxIdzRwdHCbuR4B+tbiy96Lzi8E4D7z7S0mEPd+eqO3cT53Z0Y8SV80XvB4Z0ADJi/f7X113f+7p7/+UYBvur6657/+YYBvur6657/+aYBvuL6657/+aYBvuL6657/+aYBvuL6657/+aYBvuL6657/+VMA8FXWX/f8z58OgK+y/rrnf75RgLna+uue//lTA/CV1V/3/M837aKvvv6653++UQvmauuve/7nTwfAV1N/3fM/fzr24Cuuv+75nz8FFnxl9dc9//MOr/8/glixwRuUfM4AAAAASUVORK5CYII=`}_getSearchTexture(){return`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAhCAAAAABIXyLAAAAAOElEQVRIx2NgGAWjYBSMglEwEICREYRgFBZBqDCSLA2MGPUIVQETE9iNUAqLR5gIeoQKRgwXjwAAGn4AtaFeYLEAAAAASUVORK5CYII=`}},Mh={name:`OutputShader`,uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`},Nh=class extends sh{constructor(){super(),this.isOutputPass=!0,this.uniforms=zo.clone(Mh.uniforms),this.material=new Uo({name:Mh.name,uniforms:this.uniforms,vertexShader:Mh.vertexShader,fragmentShader:Mh.fragmentShader}),this._fsQuad=new uh(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Pt.getTransfer(this._outputColorSpace)===`srgb`&&(this.material.defines.SRGB_TRANSFER=``),this._toneMapping===1?this.material.defines.LINEAR_TONE_MAPPING=``:this._toneMapping===2?this.material.defines.REINHARD_TONE_MAPPING=``:this._toneMapping===3?this.material.defines.CINEON_TONE_MAPPING=``:this._toneMapping===4?this.material.defines.ACES_FILMIC_TONE_MAPPING=``:this._toneMapping===6?this.material.defines.AGX_TONE_MAPPING=``:this._toneMapping===7?this.material.defines.NEUTRAL_TONE_MAPPING=``:this._toneMapping===5&&(this.material.defines.CUSTOM_TONE_MAPPING=``),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}},Ph={low:{label:Y(`低`),post:!1,ao:!1,msaa:0,smaa:!1,shadow:1024,pr:1},medium:{label:Y(`中`),post:!0,ao:!1,msaa:0,smaa:!0,shadow:2048,pr:1.25},high:{label:Y(`高`),post:!0,ao:!1,msaa:4,smaa:!1,shadow:4096,pr:1.5},ultra:{label:Y(`极致`),post:!0,ao:!0,msaa:4,smaa:!1,shadow:4096,pr:2}},Fh=class extends Dh{_overrideVisibility(){super._overrideVisibility();let e=this._visibilityCache;this.scene.traverse(t=>{let n=t.material;t.visible&&(t.isSprite||n&&!Array.isArray(n)&&n.transparent&&!n.depthWrite)&&(e.push(t),t.visible=!1)})}},Ih={uniforms:{tDiffuse:{value:null},uTime:{value:0},uVignette:{value:.32},uSat:{value:1.12},uLift:{value:new U(.006,.01,.022)},uGain:{value:new U(1.03,1,.96)},uCA:{value:.0016},uGrain:{value:.018},uHurt:{value:0},uFlash:{value:0}},vertexShader:`varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`uniform sampler2D tDiffuse; uniform float uTime; uniform float uVignette; uniform float uSat; uniform vec3 uLift; uniform vec3 uGain;
    uniform float uCA; uniform float uGrain; uniform float uHurt; uniform float uFlash;
    varying vec2 vUv;
    float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    void main(){
      vec2 c = vUv - 0.5;
      float r2 = dot(c, c);
      vec2 off = c * r2 * uCA * 8.0;
      vec3 col;
      col.r = texture2D(tDiffuse, vUv - off).r;
      col.g = texture2D(tDiffuse, vUv).g;
      col.b = texture2D(tDiffuse, vUv + off).b;
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, uSat);
      col = col * uGain + uLift * (1.0 - smoothstep(0.0, 0.6, l));
      float vig = smoothstep(0.85, 0.2, r2 * (1.0 + uVignette * 2.0));
      col *= mix(1.0, vig, uVignette * 1.6);
      col = mix(col, col * vec3(1.4, 0.35, 0.3), uHurt * smoothstep(0.05, 0.5, r2));
      col += vec3(1.0, 0.95, 0.85) * uFlash;
      col += (h(vUv * 917.0 + fract(uTime) * 31.0) - 0.5) * uGrain * (0.4 + l);
      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }`},Lh=class{constructor(e,t,n){this.renderer=e,this.scene=t,this.camera=n,this.quality=`high`,this.composer=null,this.hurt=0,this.flash=0}setQuality(e,t){let n=Ph[e]||Ph.high;this.quality=e;let r=this.renderer;if(r.setPixelRatio(Math.min(devicePixelRatio,n.pr)),t&&(t.shadow.mapSize.set(n.shadow,n.shadow),t.shadow.map?.dispose(),t.shadow.map=null),this.composer?.dispose?.(),this.composer=null,!n.post)return;let i=r.getDrawingBufferSize(new H),a=new mh(r,new qt(i.x,i.y,{type:g,samples:n.msaa}));if(a.setPixelRatio(r.getPixelRatio()),a.setSize(innerWidth,innerHeight),a.addPass(new hh(this.scene,this.camera)),n.ao){let e=new Fh(this.scene,this.camera,innerWidth,innerHeight);e.blendIntensity=.85,e.updateGtaoMaterial({radius:1.6,distanceExponent:1.2,thickness:1.5,scale:1,samples:12}),e.updatePdMaterial({lumaPhi:10,depthPhi:2,normalPhi:3,radius:6,rings:2,samples:12}),a.addPass(e)}this.bloom=new _h(new H(innerWidth,innerHeight),.42,.5,1.5),a.addPass(this.bloom),this.grade=new dh(Ih),a.addPass(this.grade),a.addPass(new Nh),n.smaa&&a.addPass(new jh),this.composer=a}resize(){this.composer?.setPixelRatio(this.renderer.getPixelRatio()),this.composer?.setSize(innerWidth,innerHeight)}render(e,t){if(this.hurt=Math.max(0,this.hurt-e*1.6),this.flash=Math.max(0,this.flash-e*4),!this.composer){this.renderer.render(this.scene,this.camera);return}let n=this.grade.uniforms;n.uTime.value=t,n.uHurt.value=this.hurt,n.uFlash.value=this.flash,this.composer.render(e)}},Rh={slime:{name:Y(`蚀影史莱姆`),hp:40,dmg:8,speed:3.4,aggro:14,radius:.7,height:1.2,coins:3,reach:2.8,windup:.5},wolf:{name:Y(`蚀影狼`),hp:70,dmg:13,speed:6.6,aggro:20,radius:.8,height:1.3,coins:6,reach:6,windup:.65},golem:{name:Y(`晶甲魔像`),hp:280,dmg:26,speed:2.3,aggro:17,radius:1.5,height:3.6,coins:30,reach:4.2,windup:1.1,elite:!0}},zh={meadow:{body:3877466,glow:16732120},forest:{body:2046515,glow:6160304},canyon:{body:4858904,glow:16747050},snow:{body:2768222,glow:8378623},crystal:{body:3811942,glow:11832575}},Bh=e=>Xf(new Wo(e),14207231,.5,2.4);function Vh(e,t,n,r=0,i=0,a=0){let o=new q(e,t);return o.position.set(r,i,a),o.castShadow=!0,n.add(o),o}function Hh(e){let t=new G,n=new G;t.add(n);let r=Bh({color:e.body,roughness:.12,metalness:0,transparent:!0,opacity:.86,emissive:e.glow,emissiveIntensity:.12}),i=new Wo({color:0,emissive:e.glow,emissiveIntensity:3.2}),a=new Wo({color:16777215,emissive:16777215,emissiveIntensity:1.4}),o=new Wo({color:656914});Vh(new Mo(.62,28,20),r,n,0,.55,0).scale.set(1,.85,1),Vh(new Mo(.42,20,14),r,n,0,.98,-.05).scale.set(1,.7,1),Vh(new Oo(.2,1),i,n,0,.6,0);for(let e of[-1,1])Vh(new Mo(.11,14,10),a,n,e*.2,.78,.5).scale.set(.9,1.2,.5),Vh(new Mo(.055,10,8),o,n,e*.19,.76,.56);return t.userData.anim={body:n,eyes:a,core:i},t}function Uh(e){let t=new G,n=Bh({color:e.body,roughness:.65}),r=Bh({color:1183516,roughness:.7}),i=new Wo({color:0,emissive:e.glow,emissiveIntensity:2.4}),a=new Wo({color:0,emissive:16726634,emissiveIntensity:2}),o=new G;o.position.y=.85,t.add(o),Vh(new Mo(.34,20,14),n,o,0,0,0).scale.set(1,.95,2),Vh(new Mo(.36,18,12),r,o,0,.12,.38).scale.set(1.05,1,1);for(let e=0;e<5;e++){let t=Vh(new sa(.07,.36,8),e%2?i:r,o,0,.36-e*.02,.4-e*.2);t.rotation.x=-.6}let s=new G;s.position.set(0,.28,.82),o.add(s),Vh(new Mo(.24,18,14),n,s).scale.set(1,.95,1.15),Vh(new sa(.13,.36,14),n,s,0,-.06,.3).rotation.x=Math.PI/2,Vh(new Mo(.05,8,6),r,s,0,-.05,.48);for(let e of[-1,1])Vh(new sa(.08,.24,10),r,s,e*.13,.22,-.02).rotation.z=-e*.25,Vh(new Mo(.045,10,8),a,s,e*.11,.06,.2).scale.set(1.3,.7,.6);let c=new G;c.position.set(0,.1,-.66),o.add(c),Vh(new sa(.12,.7,12),r,c,0,0,-.3).rotation.x=-Math.PI/2-.4;let l=[];for(let[e,t]of[[-.18,.45],[.18,.45],[-.18,-.45],[.18,-.45]]){let i=new G;i.position.set(e,-.08,t),o.add(i),Vh(new oa(.06,.08,.72,10),n,i,0,-.36,0),Vh(new Mo(.08,10,8),r,i,0,-.74,.04).scale.set(1,.6,1.4),l.push(i)}return t.userData.anim={body:o,head:s,tail:c,legs:l,eyes:a,glow:i},t}function Wh(e){let t=new G,n=Bh({color:6117478,roughness:.92,flatShading:!0}),r=Bh({color:4867666,roughness:.95,flatShading:!0}),i=new Wo({color:1714746,emissive:e.glow,emissiveIntensity:2.2,roughness:.2,metalness:.1}),a=new G;a.position.y=1.9,t.add(a),Vh(new la(1.05,0),n,a).scale.set(1.15,1,.9),Vh(new la(.55,0),r,a,0,1.05,.15),Vh(new ko(.32,0),i,a,0,.1,.82);for(let e of[-1,1])Vh(new Mo(.07,8,6),i,a,e*.18,1.1,.62);for(let e=0;e<6;e++)Vh(new sa(.18+e%2*.08,.9+e%3*.3,6),i,a,(e-2.5)*.32,.75+e%2*.2,-.55).rotation.set(-.5,0,(e-2.5)*.25);let o=[];for(let e of[-1,1]){let t=new G;t.position.set(e*1.25,.45,0),a.add(t),Vh(new la(.45,0),r,t,0,-.35,0),Vh(new la(.62,0),n,t,0,-1.15,.1),Vh(new sa(.12,.5,6),i,t,e*.25,-.1,-.1).rotation.z=-e*.8,o.push(t)}let s=[];for(let e of[-1,1]){let t=new G;t.position.set(e*.55,-.8,0),a.add(t),Vh(new la(.5,0),r,t,0,-.55,0),s.push(t)}return t.userData.anim={body:a,arms:o,legs:s,glow:i},t}var Gh={slime:Hh,wolf:Uh,golem:Wh},Kh=new jo(.85,1,48).rotateX(-Math.PI/2),qh=new aa(1,48).rotateX(-Math.PI/2),Jh=class{constructor(e,t,n,r,i=1,a=`meadow`){let o=Rh[t];if(this.g=e,this.kind=t,this.def=o,this.level=i,this.maxHp=Math.round(o.hp*(1+(i-1)*.35)),this.hp=this.maxHp,this.dmg=Math.round(o.dmg*(1+(i-1)*.2)),this.name=o.name,this.radius=o.radius,this.height=o.height,this.hostile=!0,this.alive=!0,this.elite=!!o.elite,this.obj=Gh[t](zh[a]||zh.meadow),this.obj.position.set(n,X(n,r),r),this.obj.rotation.y=Math.random()*6.28,this.pos=this.obj.position,this.home={x:n,z:r},this.state=`idle`,this.t=Math.random()*3,this.k=0,this.vel=new U,this.atkDir=new U,this.hitDone=!1,this.seenT=0,this.lastHit=-99,this.wander=null,this.phase=Math.random()*10,this.anim=this.obj.userData.anim,e.scene.add(this.obj),t===`golem`){this.tele=new G;let t=new ii({color:16726586,transparent:!0,opacity:.8,depthWrite:!1,blending:2,polygonOffset:!0,polygonOffsetFactor:-4}),n=new ii({color:16726586,transparent:!0,opacity:.18,depthWrite:!1,blending:2,polygonOffset:!0,polygonOffsetFactor:-4});this.teleRing=new q(Kh,t),this.teleFill=new q(qh,n),this.tele.add(this.teleRing,this.teleFill),this.tele.visible=!1,e.scene.add(this.tele)}}get aggroed(){return this.alive&&(this.state===`chase`||this.state===`windup`||this.state===`attack`||this.state===`recover`||this.state===`hurt`)}dispose(){this.g.scene.remove(this.obj),this.tele&&this.g.scene.remove(this.tele)}onHit(e,t,n){this.hp-=e,this.lastHit=this.g.clock;let r=(n.knock??6)*(this.elite?.25:1);this.vel.x+=t.x*r,this.vel.z+=t.z*r,this.hp<=0?this.die():((!this.elite||n.heavy)&&(this.state!==`attack`||!this.elite)&&(this.state=`hurt`,this.t=this.elite?.35:.28),this.state===`idle`&&(this.state=`chase`),this.tele&&this.state===`hurt`&&(this.tele.visible=!1))}die(){this.alive=!1,this.state=`dead`,this.t=.7,this.tele&&(this.tele.visible=!1)}update(e){let t=this.g,n=t.player,r=n.pos,i=this.obj,a=this.anim;if(this.phase+=e,this.state===`dead`){this.t-=e;let t=Math.max(.01,this.t/.7);return i.scale.setScalar(this.kind===`slime`?t:.4+t*.6),i.position.y+=e*(this.kind===`slime`?-.5:.6),i.rotation.y+=e*4,this.t>0}let o=r.x-i.position.x,s=r.z-i.position.z,c=Math.hypot(o,s),l=this.def,u=t.combat.playerAlive&&!t.busyForCombat();this.t-=e;let d=0,f=null;switch(this.state){case`idle`:if(u&&c<l.aggro&&Math.abs(r.y-i.position.y)<8){this.state=`chase`,t.audio.play(this.kind===`wolf`?`growl`:`gloom`);break}if(this.t<=0){this.t=2+Math.random()*4;let e=Math.random()*6.28,t=Math.random()*8;this.wander=Math.random()<.6?{x:this.home.x+Math.cos(e)*t,z:this.home.z+Math.sin(e)*t}:null}if(this.wander){let e=this.wander.x-i.position.x,t=this.wander.z-i.position.z;Math.hypot(e,t)>.5?(d=l.speed*.3,f=Math.atan2(e,t)):this.wander=null}break;case`chase`:{let e=Math.hypot(i.position.x-this.home.x,i.position.z-this.home.z);if(!u||c>l.aggro*2.4||e>70){this.state=`idle`,this.wander={x:this.home.x,z:this.home.z},this.t=6;break}if(f=Math.atan2(o,s),c<l.reach&&this.t<=0){this.state=`windup`,this.t=l.windup,this.atkDir.set(o/(c||1),0,s/(c||1)),t.audio.play(this.kind===`golem`?`golemCharge`:`windup`);break}d=this.kind===`wolf`&&c<4?-l.speed*.25:c>this.radius+1.1?l.speed:0;break}case`windup`:f=Math.atan2(o,s),this.kind!==`golem`&&this.atkDir.set(o/(c||1),0,s/(c||1)),this.t<=0&&(this.state=`attack`,this.hitDone=!1,this.kind===`slime`?(this.t=.5,this.vel.set(this.atkDir.x*8.5,0,this.atkDir.z*8.5)):this.kind===`wolf`?(this.t=.38,this.vel.set(this.atkDir.x*15,0,this.atkDir.z*15),t.audio.play(`bite`)):(this.t=.5,this._slam()));break;case`attack`:this.kind!==`golem`&&!this.hitDone&&c<this.radius+.75&&Math.abs(r.y-i.position.y)<1.6&&(this.hitDone=!0,t.combat.hurtPlayer(this.dmg,i.position,this.kind===`wolf`?9:7)),this.t<=0&&(this.state=`recover`,this.t=this.kind===`golem`?1.4:.7+Math.random()*.6);break;case`recover`:this.t<=0&&(this.state=`chase`,this.t=.4+Math.random()*.8);break;case`hurt`:this.t<=0&&(this.state=`chase`,this.t=.5)}f!==null&&(i.rotation.y=Cd(i.rotation.y,f,Math.min(1,e*(this.state===`windup`?3:7))));let p=Math.sin(i.rotation.y),m=Math.cos(i.rotation.y),h=this.vel.x+p*d,g=this.vel.z+m*d;this.kind===`wolf`&&this.state===`chase`&&c<4.5&&(h+=-m*l.speed*.5*Math.sign(Math.sin(this.phase*.7)),g+=p*l.speed*.5*Math.sign(Math.sin(this.phase*.7)));let _=i.position.x+h*e,v=i.position.z+g*e,y=X(_,v);y>If(_,v)-.5&&y-X(i.position.x,i.position.z)<1.2?(i.position.x=_,i.position.z=v):(this.vel.set(0,0,0),this.wander=null),t.world.colliders.resolve(i.position,this.radius*.7,this.height);let b=this.state===`attack`?1.5:7;this.vel.x*=Math.max(0,1-e*b),this.vel.z*=Math.max(0,1-e*b);let x=X(i.position.x,i.position.z);if(this.kind===`slime`){let e=d>.5||this.state===`attack`,t=this.phase*(this.state===`attack`?0:2.6)%1,n=1,r=0;if(this.state===`windup`)n=.65+Math.sin(this.phase*40)*.03;else if(this.state===`attack`){let e=1-this.t/.5;r=Math.sin(Math.min(1,e)*Math.PI)*1.5,n=1.25}else e?(r=Math.sin(t*Math.PI)*.45,n=1+Math.sin(t*Math.PI)*.18-(t<.1?.2:0)):n=1+Math.sin(this.phase*3)*.04;a.body.scale.set(1/Math.sqrt(n),n,1/Math.sqrt(n)),x+=r,a.core.emissiveIntensity=this.state===`windup`?6:3.2}else if(this.kind===`wolf`){let e=Math.hypot(h,g),t=Math.min(1,e/6);a.legs.forEach((n,r)=>{n.rotation.x=Math.sin(this.phase*(6+e*1.2)+(r%2?Math.PI:0)+(r>1?.6:0))*.7*t}),a.body.position.y=.85+Math.abs(Math.sin(this.phase*(6+e)))*.06*t-(this.state===`windup`?.22:0),a.body.rotation.x=this.state===`windup`?.15:this.state===`attack`?-.2:0,a.tail.rotation.y=Math.sin(this.phase*6)*.4,a.eyes.emissiveIntensity=this.state===`windup`?5+Math.sin(this.phase*50)*2:2,a.head.rotation.x=this.state===`idle`?Math.sin(this.phase)*.1+.15:-.05}else{let e=Math.hypot(h,g);a.legs.forEach((t,n)=>{t.rotation.x=Math.sin(this.phase*3+n*Math.PI)*.35*Math.min(1,e/2)}),a.body.position.y=1.9+Math.abs(Math.sin(this.phase*3))*.08*Math.min(1,e/2);let t=this.state===`windup`?1-Math.max(0,this.t)/this.def.windup:0,n=+(this.state===`attack`);if(a.arms.forEach(e=>{e.rotation.x=this.state===`windup`?-2.6*t:n?.4:Math.sin(this.phase*1.5)*.15}),a.glow.emissiveIntensity=this.state===`windup`?2.5+t*5:2.2,this.tele&&(this.tele.visible=this.state===`windup`,this.tele.visible)){let e=i.position.x+this.atkDir.x*1.5,n=i.position.z+this.atkDir.z*1.5;this.tele.position.set(e,X(e,n)+.15,n),this.teleRing.scale.setScalar(4.2),this.teleFill.scale.setScalar(Math.max(.05,t)*4.2)}}if(i.position.y=x,n.mode!==`swim`&&c<this.radius+.45&&Math.abs(r.y-x)<1.5){let e=this.radius+.45-c;r.x+=o/(c||1)*e,r.z+=s/(c||1)*e}return!0}_slam(){let e=this.g,t=this.obj,n=t.position.x+this.atkDir.x*1.5,r=t.position.z+this.atkDir.z*1.5,i=X(n,r);e.combat.shockwave(n,i,r,4.6,16751210),e.fx.emit(n,i+.3,r,50,{color:12166282,speed:7,gravity:9,size:.7,up:1.2,life:1}),e.audio.play(`slam`);let a=e.player.pos;Math.hypot(a.x-n,a.z-r)<4.4&&a.y<i+1.3&&e.combat.hurtPlayer(this.dmg,{x:n,y:i,z:r},14),e.cam.shake=Math.max(e.cam.shake,Math.hypot(a.x-n,a.z-r)<20?.9:0)}};function Yh(e,t){return bd(1+Math.floor(Math.max(0,Math.hypot(e,t)-460)/260),1,30)}var Xh=e=>document.querySelector(e),Zh={atk1:{dur:.34,hitAt:.42,dmg:14,arc:.3,reach:2.5,knock:5},atk2:{dur:.34,hitAt:.42,dmg:16,arc:.3,reach:2.5,knock:6},atk3:{dur:.56,hitAt:.5,dmg:26,arc:-1.1,reach:2.9,knock:11,heavy:!0}},Qh=[`atk1`,`atk2`,`atk3`],$h=new ii({color:16777215}),eg=class{constructor(e){this.N=18,this.base=[],this.tip=[],this.age=[];let t=new Dr;this.pos=new Float32Array(this.N*2*3),this.alpha=new Float32Array(this.N*2),this.side=new Float32Array(this.N*2);for(let e=0;e<this.N;e++)this.side[e*2]=0,this.side[e*2+1]=1;t.setAttribute(`position`,new fr(this.pos,3)),t.setAttribute(`alpha`,new fr(this.alpha,1)),t.setAttribute(`side`,new fr(this.side,1));let n=[];for(let e=0;e<this.N-1;e++){let t=e*2;n.push(t,t+1,t+3,t,t+3,t+2)}t.setIndex(n),this.mat=new Ho({uniforms:{uCol:{value:new K(9430271)}},vertexShader:`attribute float alpha; attribute float side; varying float vA; varying float vS; void main(){ vA = alpha; vS = side; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`uniform vec3 uCol; varying float vA; varying float vS; void main(){ float a = vA * smoothstep(0.0, 1.0, vS); vec3 c = mix(uCol, vec3(1.0), vS * vS) * (1.5 + vS * 2.5); gl_FragColor = vec4(c * a, a); }`,transparent:!0,depthWrite:!1,blending:2,side:2}),this.mesh=new q(t,this.mat),this.mesh.frustumCulled=!1,e.add(this.mesh)}push(e,t){this.base.unshift(e.clone()),this.tip.unshift(t.clone()),this.age.unshift(0),this.base.length>this.N&&(this.base.pop(),this.tip.pop(),this.age.pop())}update(e,t){t&&this.mat.uniforms.uCol.value.set(t);for(let t=0;t<this.age.length;t++)this.age[t]+=e;for(;this.age.length&&this.age[this.age.length-1]>.16;)this.base.pop(),this.tip.pop(),this.age.pop();let n=this.base.length;this.mesh.visible=n>1;for(let e=0;e<this.N;e++){let t=Math.min(e,n-1),r=this.base[t],i=this.tip[t];if(!r)continue;this.pos.set([r.x,r.y,r.z,i.x,i.y,i.z],e*6);let a=e<n?(1-this.age[t]/.16)*(1-e/this.N):0;this.alpha[e*2]=a,this.alpha[e*2+1]=a}this.mesh.geometry.attributes.position.needsUpdate=!0,this.mesh.geometry.attributes.alpha.needsUpdate=!0}},tg=class{constructor(e){this.g=e,this.enemies=[],this.hp=this.maxHp,this.playerAlive=!0,this.invuln=0,this.lastHurt=-99,this.armedT=0,this.swing=null,this.queued=!1,this.comboStep=0,this.comboT=0,this.dodge=null,this.plunge=!1,this.trail=new eg(e.scene),this.rings=[],this.orbs=[],this.flashes=[],this.chests=[],this.nightT=2,this.inCombat=!1,this._v1=new U,this._v2=new U,this._v3=new U,this.hpFill=Xh(`#hp-fill`),this.hpGhost=Xh(`#hp-ghost`),this.hpText=Xh(`#hp-text`),this.barLayer=Xh(`#bars`),this.dmgLayer=Xh(`#dmg-layer`),this.barPool=[],this.dmgNums=[],this._ghost=1,this.ringGeo=new jo(.82,1,64).rotateX(-Math.PI/2);let t=document.createElement(`canvas`);t.width=t.height=64;let n=t.getContext(`2d`),r=n.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,`rgba(255,255,255,1)`),r.addColorStop(.25,`rgba(140,255,170,0.9)`),r.addColorStop(1,`rgba(80,255,140,0)`),n.fillStyle=r,n.fillRect(0,0,64,64),this.orbMat=new Lr({map:new $i(t),blending:2,depthWrite:!1,transparent:!0}),this.chestGeo=Q([Z(cp.Box(1.1,.6,.75),4864602,{y:.3}),Z(cp.Box(1.14,.1,.79),10474495,{y:.5}),Z(cp.Box(1.1,.3,.75),3811914,{y:.75}),Z(cp.Box(1.14,.08,.79),10474495,{y:.88}),Z(cp.Box(.15,.2,.05),15911244,{y:.62,z:.4})]);let i=e.world.frontier;i.onEnter=e=>this._chunkEnter(e),i.onLeave=e=>this._chunkLeave(e)}get maxHp(){return 100+this.g.state.data.feathers.length*6}get dmgMult(){return 1+this.g.state.data.shards.length*.045}targets(){let e=[];for(let t of this.enemies)t.alive&&e.push(t);for(let t of this.g.creatures.targets())e.push(t);return e}update(e,t){let n=this.g,r=n.input,i=n.player;n.state.data;let a=this.playerAlive&&!n.busy()&&!i.frozen;if(this.invuln=Math.max(0,this.invuln-e),this.armedT=Math.max(0,this.armedT-e),a){let e=r.wasPressed(`KeyJ`)||r.attackClick;r.wasPressed(`KeyQ`)&&this._startDodge(),e&&((i.mode===`air`||i.mode===`glide`)&&i.pos.y-X(i.pos.x,i.pos.z)>1.6&&!this.plunge?this._startPlunge():i.mode===`ground`&&!this.dodge&&(this.swing?this.swing.t/this.swing.dur>.3&&(this.queued=!0):this._startSwing(Qh[this.comboT>0?this.comboStep:0])))}if(this.swing){let t=this.swing;t.t+=e;let n=t.t/t.dur;if(!t.hit&&n>=t.def.hitAt&&(t.hit=!0,this._resolveSwing(t)),i.atkPose={kind:t.kind,k:Math.min(1,n)},n>=1){let e=Qh.indexOf(t.kind);this.swing=null,i.moveScale=1,this.queued&&e<2&&i.mode===`ground`?(this.queued=!1,this._startSwing(Qh[e+1])):(this.queued=!1,this.comboStep=e>=2?0:e+1,this.comboT=e>=2?0:.45,i.atkPose=null)}i.mode!==`ground`&&this.swing&&(this.swing=null,i.atkPose=null,i.moveScale=1)}else this.comboT>0&&(this.comboT-=e,this.comboT<=0&&(this.comboStep=0));this.dodge&&(this.dodge.t+=e,i.atkPose={kind:`roll`,k:this.dodge.t/this.dodge.dur},this.dodge.t>=this.dodge.dur&&(this.dodge=null,i.atkPose=null)),this.plunge&&(i.atkPose={kind:`plunge`,k:.15},(i.mode===`swim`||i.mode===`climb`)&&(this.plunge=!1,i.atkPose=null)),i.char.setArmed(this.armedT>0||!!this.swing||this.plunge),(this.swing&&this.swing.t/this.swing.dur>.08&&this.swing.t/this.swing.dur<.9||this.plunge)&&(i.char.swordBase.getWorldPosition(this._v1),i.char.swordTip.getWorldPosition(this._v2),this.trail.push(this._v1,this._v2)),this.trail.update(t,this.swing?.kind===`atk3`?16767082:9430271),this.playerAlive&&n.clock-this.lastHurt>5&&this.hp<this.maxHp&&(this.hp=Math.min(this.maxHp,this.hp+e*(this.inCombat?2:7)));let o=!1,s=i.pos;for(let t=this.enemies.length-1;t>=0;t--){let n=this.enemies[t],r=Math.hypot(n.pos.x-s.x,n.pos.z-s.z);if(r>170&&n.alive){n.obj.visible=r<400;continue}n.obj.visible=!0;let i=n.update(e);n.aggroed&&r<45&&(o=!0),i||(n.dispose(),this.enemies.splice(t,1))}this.inCombat=o,this._effects(e,t),this._nightSpawns(e),this._chestsUpdate(),this._ui(e)}_aimDir(){let e=this.g,t=e.player,n=e.input.axis(),r=e.cam.forward(),i=e.cam.right(),a=r.x*n.y+i.x*n.x,o=r.z*n.y+i.z*n.x,s=Math.hypot(a,o);return s>.1?{x:a/s,z:o/s}:{x:Math.sin(t.yaw),z:Math.cos(t.yaw)}}_startSwing(e){let t=this.g,n=t.player,r=Zh[e];this.swing={kind:e,def:r,dur:r.dur,t:0,hit:!1},this.armedT=4,n.moveScale=.12;let i=this._aimDir(),a=null,o=1/0;for(let e of this.targets()){let t=e.obj.position.x-n.pos.x,r=e.obj.position.z-n.pos.z,s=Math.hypot(t,r);if(s>6+e.radius||Math.abs(e.obj.position.y-n.pos.y)>3)continue;let c=(t*i.x+r*i.z)/(s||1);if(c<.2&&s>2)continue;let l=s-c*2-(e.hostile?1.5:0);l<o&&(o=l,a={dx:t,dz:r,d:s,t:e})}let s=i;a&&(s={x:a.dx/(a.d||1),z:a.dz/(a.d||1)}),n.yaw=Math.atan2(s.x,s.z),n.char.root.rotation.y=n.yaw;let c=a?bd(a.d-a.t.radius-1.2,0,3)*7:3.5;n.dash={vx:s.x*c,vz:s.z*c,t:.12},t.audio.play(`swing`,+(e===`atk3`))}_startPlunge(){let e=this.g,t=e.player;this.plunge=!0,this.armedT=4,t.vel.y=-34,t.vel.x*=.2,t.vel.z*=.2,t.mode===`glide`&&(t.mode=`air`),e.audio.play(`swing`,1)}_startDodge(){let e=this.g,t=e.player;if(this.dodge||t.mode!==`ground`||t.stamina<.8)return;let n=e.input.axis(),r=this._aimDir();Math.hypot(n.x,n.y)<.1&&(r={x:-Math.sin(t.yaw),z:-Math.cos(t.yaw)}),this.swing=null,this.queued=!1,t.moveScale=1,this.dodge={t:0,dur:.42},this.invuln=Math.max(this.invuln,.34),t.stamina-=.9,t.yaw=Math.atan2(r.x,r.z),t.dash={vx:r.x*13,vz:r.z*13,t:.36},e.audio.play(`dodge`),e.fx.emit(t.pos.x,t.pos.y+.2,t.pos.z,10,{color:14207144,speed:2.5,gravity:1,size:.5,up:.3})}onLand(){if(!this.plunge)return;let e=this.g,t=e.player;this.plunge=!1,t.atkPose=null;let n=t.pos;this.shockwave(n.x,n.y,n.z,4.2,9430271),e.fx.emit(n.x,n.y+.3,n.z,50,{color:10479871,speed:8,gravity:6,size:.55,up:1}),e.fx.emit(n.x,n.y+.2,n.z,30,{color:14207144,speed:5,gravity:8,size:.7,up:.8}),e.cam.shake=.8,e.audio.play(`slam`);for(let e of this.targets()){let t=e.obj.position.x-n.x,r=e.obj.position.z-n.z,i=Math.hypot(t,r);i>4+e.radius||Math.abs(e.obj.position.y-n.y)>2.5||this._damage(e,30,{x:t/(i||1),z:r/(i||1)},{knock:12,heavy:!0})}this.hitstop(.08)}_resolveSwing(e){let t=this.g.player,n=t.pos,r=Math.sin(t.yaw),i=Math.cos(t.yaw),a=0;for(let t of this.targets()){let o=t.obj.position.x-n.x,s=t.obj.position.z-n.z,c=Math.hypot(o,s);c>e.def.reach+t.radius||Math.abs(t.obj.position.y-n.y)>2.2||(o*r+s*i)/(c||1)<e.def.arc&&c>t.radius+.4||(this._damage(t,e.def.dmg,{x:o/(c||1),z:s/(c||1)},e.def),a++)}a&&this.hitstop(e.kind===`atk3`?.09:.055)}_damage(e,t,n,r){let i=this.g,a=Math.random()<.15,o=Math.max(1,Math.round(t*this.dmgMult*(.9+Math.random()*.2)*(a?1.8:1))),s=e.alive;e.onHit(o,n,r);let c=e.obj.position,l=c.y+e.height*.6;i.fx.emit(c.x,l,c.z,a?26:14,{color:a?16769658:12579071,speed:a?9:6,gravity:6,size:.32,life:.45}),i.fx.emit(c.x,l,c.z,6,{color:16777215,speed:2,gravity:0,size:.9,life:.18}),this.flash(e.obj),this.number(c.x,l+.6,c.z,o,a?`crit`:`hit`),i.cam.shake=Math.max(i.cam.shake,a?.45:.25),i.audio.play(a?`crit`:`hit`),a&&(i.post.flash=.08),s&&!e.alive&&this._killed(e)}_killed(e){let t=this.g,n=e.obj.position;if(e instanceof Jh){let r=e.def.coins*e.level+Math.floor(Math.random()*3);t.state.addCoins(r),this.number(n.x,n.y+e.height+.6,n.z,`+${r} 🐚`,`coin`),t.fx.emit(n.x,n.y+e.height*.5,n.z,60,{color:11832575,speed:6,gravity:-1.5,size:.5,life:1.2}),t.fx.emit(n.x,n.y+e.height*.5,n.z,30,{color:16777215,speed:3,gravity:-3,size:.35,life:1.4}),t.audio.play(`enemyDie`),Math.random()<(e.elite?1:.3)&&this._dropOrb(n.x,n.y+1,n.z,e.elite?40:15),e.elite&&(t.hud.toast(Y(`击败了 Lv.{0} {1}！`,[e.level,e.name])),this.hitstop(.15))}else t.state.addCoins(1),this.number(n.x,n.y+e.height+.4,n.z,`+1 🐚`,`coin`),t.audio.play(`poof`)}hitstop(e){this.g.hitstop=Math.max(this.g.hitstop||0,e)}flash(e){let t=[];e.traverse(e=>{e.isMesh&&!e.userData.flashing&&(e.userData.flashing=!0,t.push([e,e.material]),e.material=$h)}),t.length&&this.flashes.push({list:t,t:.075})}hurtPlayer(e,t,n=6){let r=this.g,i=r.player;if(!this.playerAlive||r.cutscene)return;if(this.invuln>0){this.dodge&&(this.number(i.pos.x,i.pos.y+2.2,i.pos.z,Y(`闪避`),`dodge`),r.audio.play(`perfect`));return}this.hp-=e,this.lastHurt=r.clock,this.invuln=.6,this.swing=null,this.queued=!1,i.moveScale=1;let a=i.pos.x-t.x,o=i.pos.z-t.z,s=Math.hypot(a,o)||1;i.dash={vx:a/s*n,vz:o/s*n,t:.18},i.hurtT=.32,r.post.hurt=1,r.cam.shake=Math.max(r.cam.shake,.55),r.audio.play(`hurt`),this.number(i.pos.x,i.pos.y+2.2,i.pos.z,e,`player`),r.fx.emit(i.pos.x,i.pos.y+1.1,i.pos.z,16,{color:16738922,speed:5,gravity:6,size:.35,life:.5}),this.hp<=0&&this._die()}async _die(){let e=this.g,t=e.player,n=e.state.data;this.hp=0,this.playerAlive=!1,this.swing=null,this.dodge=null,this.plunge=!1,t.frozen=!0,t.animOverride=`down`,t.atkPose=null,e.audio.play(`die`),e.hud.banner(Y(`你倒下了……`),Y(`星光会指引你回到营火旁`),2400),await e.wait(2.2),await e.fade(!0);let r=e.world.campfires.filter(e=>n.campfires.includes(e.id)),i=r[0]||e.world.campfires[0],a=1/0;for(let e of r){let n=Math.hypot(e.x-t.pos.x,e.z-t.pos.z);n<a&&(a=n,i=e)}let o=Math.min(n.coins,Math.min(50,Math.max(5,Math.floor(n.coins*.1))));e.state.addCoins(-o);for(let e of this.enemies)e.alive&&(e.state=`idle`,e.hp=e.maxHp);t.animOverride=null,await e.fastTravel(i,!0),this.hp=this.maxHp,this.playerAlive=!0,t.frozen=!1,e.hud.toast(Y(`在{0}醒来了。{1}`,[i.name,o?Y(`遗失了 {0} 枚贝壳币。`,[o]):``]),4e3)}shockwave(e,t,n,r,i){let a=new q(this.ringGeo,new ii({color:i,transparent:!0,opacity:1,blending:2,depthWrite:!1,side:2}));a.position.set(e,t+.2,n),this.g.scene.add(a),this.rings.push({m:a,t:0,dur:.4,r})}_dropOrb(e,t,n,r){let i=new Zr(this.orbMat);i.scale.setScalar(.9),i.position.set(e,t,n),this.g.scene.add(i),this.orbs.push({s:i,heal:r,t:0,vy:4})}_effects(e,t){let n=this.g,r=n.player.pos;for(let e=this.rings.length-1;e>=0;e--){let r=this.rings[e];r.t+=t;let i=r.t/r.dur;r.m.scale.setScalar(.3+i*r.r),r.m.material.opacity=1-i,i>=1&&(n.scene.remove(r.m),r.m.material.dispose(),this.rings.splice(e,1))}for(let e=this.flashes.length-1;e>=0;e--){let n=this.flashes[e];if(n.t-=t,n.t<=0){for(let[e,t]of n.list)e.material=t,e.userData.flashing=!1;this.flashes.splice(e,1)}}for(let t=this.orbs.length-1;t>=0;t--){let i=this.orbs[t],a=i.s;i.t+=e;let o=X(a.position.x,a.position.z)+.8;i.vy-=9*e,a.position.y=Math.max(o,a.position.y+i.vy*e),a.position.y<=o&&(i.vy=Math.abs(i.vy)*.4),a.scale.setScalar(.8+Math.sin(i.t*6)*.12);let s=r.x-a.position.x,c=r.y+1-a.position.y,l=r.z-a.position.z,u=Math.hypot(s,c,l);if(u<5&&this.playerAlive){let t=Math.min(u,e*(6+(5-u)*4));a.position.x+=s/u*t,a.position.y+=c/u*t,a.position.z+=l/u*t}u<.9&&this.playerAlive?(this.hp=Math.min(this.maxHp,this.hp+i.heal),this.number(r.x,r.y+2.2,r.z,`+${i.heal}`,`heal`),n.audio.play(`heal`),n.fx.emit(r.x,r.y+1,r.z,20,{color:9306032,speed:2.5,gravity:-3,size:.4,life:.9}),n.scene.remove(a),this.orbs.splice(t,1)):i.t>25&&(n.scene.remove(a),this.orbs.splice(t,1))}}spawn(e,t,n,r,i,a){let o=new Jh(this.g,e,t,n,r,i);return o.tag=a,this.enemies.push(o),o}_chunkEnter(e){let t=e.data.rng,n=e.data.spots||[],r=-450+(e.ci+.5)*wp,i=-450+(e.cj+.5)*wp;if(e.data.tag=`${e.ci},${e.cj}`,!n.length||gf(r,i)<.85)return;let a=Yh(r,i),o=this.g,s=()=>n.splice(Math.floor(t()*n.length),1)[0],c=t()<.45?t()<.25?2:1:0;for(let r=0;r<c&&n.length;r++){let n=s(),r=vf(n.x,n.z),i=t();if(i<.16&&a>=2||i<.08&&[`canyon`,`crystal`,`snow`].includes(r))this.spawn(`golem`,n.x,n.z,a+1,r,e.data.tag);else if(i<.55&&r!==`crystal`){let i=1+Math.floor(t()*2.5);for(let o=0;o<i;o++)this.spawn(`wolf`,n.x+(t()-.5)*6,n.z+(t()-.5)*6,a,r,e.data.tag)}else{let i=2+Math.floor(t()*2);for(let o=0;o<i;o++)this.spawn(`slime`,n.x+(t()-.5)*7,n.z+(t()-.5)*7,a,r,e.data.tag)}}if(n.length&&t()<.6){let n=s(),r={meadow:[`sheep`,`deer`],forest:[`deer`,`fox`],snow:[`goat`],canyon:[`lizard`,`goat`],crystal:[`crab`,`frog`]}[vf(n.x,n.z)]||[`sheep`],i=r[Math.floor(t()*r.length)],a=1+Math.floor(t()*3);for(let r=0;r<a;r++)o.creatures.spawnWild(i,n.x+(t()-.5)*8,n.z+(t()-.5)*8,e.data.tag)}if(n.length&&t()<.16){let t=s(),n=`fc${e.ci},${e.cj}`;o.state.data.farChests.includes(n)||this._addChest(n,t.x,t.y,t.z,a,e.data.tag)}}_chunkLeave(e){let t=e.data.tag;if(t){for(let e=this.enemies.length-1;e>=0;e--)this.enemies[e].tag===t&&(this.enemies[e].dispose(),this.enemies.splice(e,1));this.g.creatures.despawnTag(t);for(let e=this.chests.length-1;e>=0;e--)this.chests[e].tag===t&&this._removeChest(this.chests[e])}}_addChest(e,t,n,r,i,a){let o=this.g,s=new q(this.chestGeo,$f);s.position.set(t,n,r),s.rotation.y=Math.random()*6.28,s.castShadow=!0,o.scene.add(s);let c=new Zr(this.orbMat);c.scale.setScalar(2.2),c.position.set(t,n+1,r),c.material=this.orbMat.clone(),c.material.color.set(10474495),o.scene.add(c);let l={id:e,m:s,light:c,tag:a,lvl:i};l.it=o.interact.add({pos:{x:t,y:n,z:r},radius:2.4,label:()=>this.enemies.some(e=>e.alive&&e.aggroed&&Math.hypot(e.pos.x-t,e.pos.z-r)<25)?null:Y(`打开远方宝箱`),action:async()=>{let a=(25+Math.floor(Math.random()*30))*i;o.state.addCoins(a),o.state.data.farChests.push(e),o.audio.play(`chest`),o.fx.emit(t,n+1,r,50,{color:10474495,speed:5,gravity:3,size:.45,life:1.2}),this.number(t,n+1.6,r,`+${a} 🐚`,`coin`),Math.random()<.5&&this._dropOrb(t,n+1.4,r,30),o.hud.toast(Y(`远方宝箱里有 {0} 枚贝壳币！`,[a])),this._removeChest(l),o.state.save()}}),this.chests.push(l)}_removeChest(e){let t=this.g;t.scene.remove(e.m),t.scene.remove(e.light),t.interact.remove(e.it),this.chests.splice(this.chests.indexOf(e),1)}_chestsUpdate(){for(let e of this.chests)e.light.material.opacity=.55+Math.sin(this.g.clock*3+e.m.position.x)*.25}_nightSpawns(e){let t=this.g,n=t.player.pos;if(this.nightT-=e,this.nightT>0)return;this.nightT=2.5;let r=t.sky.night,i=this.enemies.filter(e=>e.tag===`night`);if(r<.3){for(let e of i)e.alive&&!e.aggroed&&e.die();return}if(r<.8||i.length>=3||gf(n.x,n.z)>.3||Math.hypot(n.x-zd.x,n.z-zd.z)<zd.r+55)return;let a={x:0,y:1,z:0};for(let e=0;e<8;e++){let e=Math.random()*6.28,r=32+Math.random()*22,i=n.x+Math.cos(e)*r,o=n.z+Math.sin(e)*r;if(!(X(i,o)<If(i,o)+.5)&&!(Ff(i,o,a).y<.85)&&!(Math.hypot(i-zd.x,o-zd.z)<zd.r+40)&&!(Math.hypot(i-Vd.x,o-Vd.z)<Vd.r-20&&!t.state.data.abilities.lantern)){this.spawn(`slime`,i,o,1,`meadow`,`night`);break}}}number(e,t,n,r,i){let a=document.createElement(`div`);a.className=`dmg `+i,a.textContent=r,this.dmgLayer.appendChild(a),this.dmgNums.push({el:a,x:e+(Math.random()-.5)*.6,y:t,z:n,t:0,vx:(Math.random()-.5)*30})}_ui(e){let t=this.g,n=t.camera,r=this._v3,i=bd(this.hp/this.maxHp,0,1);this._ghost=Math.max(i,this._ghost-e*.35),this.hpFill.style.width=(i*100).toFixed(1)+`%`,this.hpGhost.style.width=(this._ghost*100).toFixed(1)+`%`,this.hpText.textContent=`${Math.ceil(this.hp)} / ${this.maxHp}`,Xh(`#hp-wrap`).classList.toggle(`low`,i<.3);for(let t=this.dmgNums.length-1;t>=0;t--){let i=this.dmgNums[t];if(i.t+=e,r.set(i.x,i.y+i.t*1.4,i.z).project(n),r.z>1||i.t>.95){i.el.remove(),this.dmgNums.splice(t,1);continue}let a=(r.x*.5+.5)*innerWidth+i.vx*i.t,o=(-r.y*.5+.5)*innerHeight,s=i.t<.12?1.4-i.t*3:1;i.el.style.transform=`translate(${a}px, ${o}px) translate(-50%, -50%) scale(${s})`,i.el.style.opacity=i.t>.6?1-(i.t-.6)/.35:1}let a=t.player.pos,o=[];if(!t.photo?.active)for(let e of this.targets()){let i=e.obj.position,s=Math.hypot(i.x-a.x,i.z-a.z),c=t.clock-(e.lastHit??-99)<6;(e.hostile?s<(e.elite?40:26):c&&s<30||s<5)&&(!e.hostile&&!c&&e.hp>=e.maxHp&&s>=5||(r.set(i.x,i.y+e.height+.55,i.z).project(n),!(r.z>1||Math.abs(r.x)>1.1||Math.abs(r.y)>1.1)&&o.push({t:e,x:(r.x*.5+.5)*innerWidth,y:(-r.y*.5+.5)*innerHeight,dd:s})))}for(o.sort((e,t)=>e.dd-t.dd);this.barPool.length<Math.min(o.length,14);){let e=document.createElement(`div`);e.className=`tbar`,e.innerHTML=`<div class="tname"></div><div class="ttrack"><div class="tghost"></div><div class="tfill"></div></div>`,this.barLayer.appendChild(e),this.barPool.push({el:e,name:e.querySelector(`.tname`),fill:e.querySelector(`.tfill`),ghost:e.querySelector(`.tghost`),key:null,g:1})}for(let t=0;t<this.barPool.length;t++){let n=this.barPool[t],r=o[t];if(!r){n.el.style.display=`none`,n.key=null;continue}let i=r.t,a=bd(i.hp/i.maxHp,0,1);n.key!==i&&(n.key=i,n.g=a,n.name.textContent=`${i.hostile?`Lv.${i.level} `:``}${i.name}`,n.el.className=`tbar `+(i.hostile?i.elite?`elite`:`enemy`:`animal`)),n.g=Math.max(a,n.g-e*.6),n.el.style.display=``;let s=bd(1.25-r.dd/40,.65,1.1);n.el.style.transform=`translate(${r.x}px, ${r.y}px) translate(-50%, -100%) scale(${s})`,n.fill.style.width=(a*100).toFixed(1)+`%`,n.ghost.style.width=(n.g*100).toFixed(1)+`%`}}},ng=`stardust-isles-save-v1`;function rg(){return{version:1,pos:null,yaw:0,time:8.5,day:1,playTime:0,shards:[],feathers:[],coins:0,coinsTaken:[],chests:[],abilities:{camera:!1,glider:!1,lantern:!1,rod:!1,fins:!1,shovel:!1,boots:!1,compass:!1},items:{cocoa:0,mushrooms:0,fish:{},fishSold:0},quests:{},flags:{},codex:[],campfires:[],hats:[],hat:null,maps:[],dug:[],reveal:``,met:[],farChests:[],farthest:0,ending:!1,settings:{volume:.8,music:.5,sensitivity:1,invertY:!1,shadows:!0,aiChat:!0,quality:`high`}}}var ig=class{constructor(){this.data=rg(),this.listeners=new Set}static hasSave(){try{return!!localStorage.getItem(ng)}catch{return!1}}load(){try{let e=localStorage.getItem(ng);if(!e)return!1;let t=JSON.parse(e),n=rg();return this.data={...n,...t,abilities:{...n.abilities,...t.abilities},items:{...n.items,...t.items},settings:{...n.settings,...t.settings}},!0}catch{return!1}}save(){try{return localStorage.setItem(ng,JSON.stringify(this.data)),!0}catch{return!1}}reset(){let e=this.data.settings;this.data=rg(),this.data.settings=e;try{localStorage.removeItem(ng)}catch{}}on(e){return this.listeners.add(e),()=>this.listeners.delete(e)}emit(e,t){for(let n of this.listeners)n(e,t)}has(e,t){return this.data[e].includes(t)}add(e,t){return!this.data[e].includes(t)&&(this.data[e].push(t),this.emit(e,t),!0)}addCoins(e){this.data.coins=Math.max(0,this.data.coins+e),this.emit(`coins`,e)}grant(e){this.data.abilities[e]||(this.data.abilities[e]=!0,this.emit(`ability`,e))}quest(e){return this.data.quests[e]||(this.data.quests[e]={stage:0})}flag(e,t){return t===void 0?this.data.flags[e]:(this.data.flags[e]=t,this.emit(`flag`,e),t)}},ag=class{constructor(e){this.canvas=e,this.down=new Set,this.pressed=new Set,this._pending=new Set,this.mouseDX=0,this.mouseDY=0,this.wheel=0,this.clicked=!1,this.attackClick=!1,this._atk=!1,this._dx=0,this._dy=0,this._wheel=0,this._click=!1,this.enabled=!0,this.locked=!1,this.wantLock=!0,addEventListener(`keydown`,e=>{(!e.target||e.target.tagName!==`INPUT`&&e.target.tagName!==`TEXTAREA`)&&([`Space`,`Tab`,`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`].includes(e.code)&&e.preventDefault(),e.repeat||this._pending.add(e.code),this.down.add(e.code))}),addEventListener(`keyup`,e=>this.down.delete(e.code)),addEventListener(`blur`,()=>this.down.clear()),e.addEventListener(`mousedown`,t=>{t.button===0&&(this._click=!0),t.button===0&&this.locked&&(this._atk=!0),this.wantLock&&!this.locked&&t.button===0&&e.requestPointerLock?.()?.catch?.(()=>{})}),document.addEventListener(`pointerlockchange`,()=>{this.locked=document.pointerLockElement===e}),addEventListener(`mousemove`,e=>{(this.locked||e.buttons&2)&&(this._dx+=e.movementX,this._dy+=e.movementY)}),e.addEventListener(`contextmenu`,e=>e.preventDefault()),e.addEventListener(`wheel`,e=>{this._wheel+=Math.sign(e.deltaY),e.preventDefault()},{passive:!1})}beginFrame(){this.pressed=this._pending,this._pending=new Set,this.mouseDX=this._dx,this.mouseDY=this._dy,this.wheel=this._wheel,this.clicked=this._click,this.attackClick=this.enabled&&this._atk,this._dx=0,this._dy=0,this._wheel=0,this._click=!1,this._atk=!1}isDown(...e){return this.enabled&&e.some(e=>this.down.has(e))}wasPressed(...e){return this.enabled&&e.some(e=>this.pressed.has(e))}hit(...e){return e.some(e=>this.pressed.has(e))}axis(){if(!this.enabled)return{x:0,y:0};let e=0,t=0;(this.down.has(`KeyW`)||this.down.has(`ArrowUp`))&&(t+=1),(this.down.has(`KeyS`)||this.down.has(`ArrowDown`))&&--t,(this.down.has(`KeyA`)||this.down.has(`ArrowLeft`))&&--e,(this.down.has(`KeyD`)||this.down.has(`ArrowRight`))&&(e+=1);let n=Math.hypot(e,t);return n>1?{x:e/n,y:t/n}:{x:e,y:t}}look(){return this.enabled?{dx:this.mouseDX,dy:this.mouseDY,wheel:this.wheel}:{dx:0,dy:0,wheel:0}}unlock(){document.pointerLockElement&&document.exitPointerLock()}},og=3e3,sg=class{constructor(e){this.pos=new Float32Array(og*3),this.col=new Float32Array(og*3),this.size=new Float32Array(og),this.alpha=new Float32Array(og),this.vel=new Float32Array(og*3),this.life=new Float32Array(og),this.maxLife=new Float32Array(og),this.grav=new Float32Array(og),this.baseSize=new Float32Array(og),this.cursor=0;let t=new Dr;t.setAttribute(`position`,new fr(this.pos,3)),t.setAttribute(`color`,new fr(this.col,3)),t.setAttribute(`size`,new fr(this.size,1)),t.setAttribute(`alpha`,new fr(this.alpha,1));let n=new Ho({transparent:!0,depthWrite:!1,blending:2,vertexShader:`attribute float size; attribute float alpha; attribute vec3 color; varying vec3 vC; varying float vA;
        void main(){ vC = color; vA = alpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = size * (320.0 / max(0.1,-mv.z)); gl_Position = projectionMatrix * mv; }`,fragmentShader:`varying vec3 vC; varying float vA;
        void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d); if (r > 0.5) discard; float a = smoothstep(0.5, 0.0, r); gl_FragColor = vec4(vC * (0.6 + a), a * vA); }`});this.points=new Xi(t,n),this.points.frustumCulled=!1,e.add(this.points)}emit(e,t,n,r,i={}){let a=new K(i.color??16773800),o=i.speed??3,s=i.life??.9,c=i.size??.35,l=i.spread??.2;for(let u=0;u<r;u++){let r=this.cursor;this.cursor=(this.cursor+1)%og,this.pos[r*3]=e+(Math.random()-.5)*l,this.pos[r*3+1]=t+(Math.random()-.5)*l,this.pos[r*3+2]=n+(Math.random()-.5)*l;let u=Math.random()*Math.PI*2,d=Math.acos(Math.random()*2-1),f=o*(.4+Math.random()*.6);this.vel[r*3]=Math.sin(d)*Math.cos(u)*f,this.vel[r*3+1]=Math.abs(Math.cos(d))*f*(i.up??1)+(i.lift??0),this.vel[r*3+2]=Math.sin(d)*Math.sin(u)*f,this.col[r*3]=a.r,this.col[r*3+1]=a.g,this.col[r*3+2]=a.b,this.life[r]=this.maxLife[r]=s*(.6+Math.random()*.4),this.grav[r]=i.gravity??2,this.baseSize[r]=c*(.6+Math.random()*.8)}}update(e){for(let t=0;t<og;t++){if(this.life[t]<=0){this.alpha[t]!==0&&(this.alpha[t]=0,this.size[t]=0);continue}this.life[t]-=e;let n=Math.max(0,this.life[t]/this.maxLife[t]);this.vel[t*3+1]-=this.grav[t]*e,this.vel[t*3]*=1-e*1.5,this.vel[t*3+2]*=1-e*1.5,this.pos[t*3]+=this.vel[t*3]*e,this.pos[t*3+1]+=this.vel[t*3+1]*e,this.pos[t*3+2]+=this.vel[t*3+2]*e,this.alpha[t]=n,this.size[t]=this.baseSize[t]*(.4+n*.6)}let t=this.points.geometry.attributes;t.position.needsUpdate=!0,t.alpha.needsUpdate=!0,t.size.needsUpdate=!0,t.color.needsUpdate=!0}},cg=class{constructor(){this.ctx=null,this.musicVol=.5,this.sfxVol=.8,this.mood=`day`,this.ambience={sea:0,wind:.2,rain:0,night:0,birds:0}}init(){if(this.ctx){this.ctx.resume();return}let e=window.AudioContext||window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.gain.value=1,this.master.connect(t.destination),this.sfx=t.createGain(),this.sfx.gain.value=this.sfxVol,this.sfx.connect(this.master),this.music=t.createGain(),this.music.gain.value=this.musicVol*.5,this.music.connect(this.master),this.delay=t.createDelay(1),this.delay.delayTime.value=.42,this.fb=t.createGain(),this.fb.gain.value=.32;let n=t.createBiquadFilter();n.type=`lowpass`,n.frequency.value=2200,this.delay.connect(n),n.connect(this.fb),this.fb.connect(this.delay),n.connect(this.music),this.noiseBuf=this._noise(2),this._ambienceInit(),this._musicStart()}setVolumes(e,t){this.sfxVol=e,this.musicVol=t,this.ctx&&(this.sfx.gain.value=e,this.music.gain.value=t*.5,this.ambGain.gain.value=e*.9)}_noise(e){let t=this.ctx.createBuffer(1,this.ctx.sampleRate*e,this.ctx.sampleRate),n=t.getChannelData(0);for(let e=0;e<n.length;e++)n[e]=Math.random()*2-1;return t}tone(e,t=.15,n={}){if(!this.ctx)return;let r=this.ctx,i=r.currentTime+(n.delay||0),a=r.createOscillator();a.type=n.type||`sine`,a.frequency.setValueAtTime(e,i),n.slide&&a.frequency.exponentialRampToValueAtTime(n.slide,i+t);let o=r.createGain(),s=n.vol??.25;o.gain.setValueAtTime(1e-4,i),o.gain.exponentialRampToValueAtTime(s,i+(n.attack??.005)),o.gain.exponentialRampToValueAtTime(1e-4,i+t),a.connect(o),o.connect(n.dest||this.sfx),n.echo&&o.connect(this.delay),a.start(i),a.stop(i+t+.05)}noise(e=.2,t={}){if(!this.ctx)return;let n=this.ctx,r=n.currentTime+(t.delay||0),i=n.createBufferSource();i.buffer=this.noiseBuf,i.playbackRate.value=t.rate||1;let a=n.createBiquadFilter();a.type=t.filter||`lowpass`,a.frequency.setValueAtTime(t.freq||1200,r),t.sweep&&a.frequency.exponentialRampToValueAtTime(t.sweep,r+e),a.Q.value=t.q||.7;let o=n.createGain();o.gain.setValueAtTime(1e-4,r),o.gain.exponentialRampToValueAtTime(t.vol??.2,r+(t.attack??.01)),o.gain.exponentialRampToValueAtTime(1e-4,r+e),i.connect(a),a.connect(o),o.connect(this.sfx),i.start(r,Math.random()),i.stop(r+e+.05)}play(e,t){if(!this.ctx)return;let n=e=>440*2**((e-69)/12);switch(e){case`coin`:this.tone(n(88),.08,{type:`square`,vol:.06}),this.tone(n(95),.18,{type:`square`,vol:.06,delay:.06});break;case`shard`:[72,76,79,84,88].forEach((e,t)=>{this.tone(n(e),.6,{type:`triangle`,vol:.16,delay:t*.09,echo:!0}),this.tone(n(e+12),.4,{vol:.05,delay:t*.09})});break;case`feather`:for(let e=0;e<8;e++)this.tone(n(79+e*2),.25,{vol:.07,delay:e*.035,echo:!0});break;case`jump`:this.tone(330,.12,{type:`square`,vol:.04,slide:620});break;case`djump`:this.tone(440,.14,{type:`square`,vol:.04,slide:880}),this.noise(.15,{freq:3e3,filter:`highpass`,vol:.05});break;case`land`:this.noise(.12,{freq:400,vol:Math.min(.35,.06+(t||0)*.012)});break;case`step`:this.noise(.05,{freq:t===`water`?1800:700,vol:.035,rate:.8+Math.random()*.4});break;case`climbstep`:this.noise(.06,{freq:1e3,vol:.05});break;case`stroke`:this.noise(.3,{freq:900,sweep:300,vol:.06});break;case`glide`:this.noise(.5,{freq:400,sweep:1600,filter:`bandpass`,vol:.12,q:2});break;case`grab`:this.noise(.08,{freq:1200,vol:.06});break;case`splash`:this.noise(.5,{freq:3e3,sweep:300,vol:.2});break;case`exhausted`:this.tone(300,.3,{type:`sawtooth`,vol:.04,slide:150});break;case`click`:this.tone(1200,.04,{type:`square`,vol:.03});break;case`open`:this.tone(n(76),.1,{vol:.08}),this.tone(n(83),.15,{vol:.08,delay:.06});break;case`close`:this.tone(n(83),.1,{vol:.08}),this.tone(n(76),.15,{vol:.08,delay:.06});break;case`blip`:this.tone((t||500)*(.9+Math.random()*.25),.05,{type:`triangle`,vol:.05});break;case`chest`:[67,71,74,79].forEach((e,t)=>this.tone(n(e),.4,{type:`triangle`,vol:.12,delay:t*.07}));break;case`fanfare`:[[72,0],[76,.12],[79,.24],[84,.36],[79,.54],[84,.66]].forEach(([e,t])=>{this.tone(n(e),.45,{type:`square`,vol:.06,delay:t}),this.tone(n(e-12),.45,{type:`triangle`,vol:.1,delay:t})});break;case`fail`:[67,63,60].forEach((e,t)=>this.tone(n(e),.25,{type:`triangle`,vol:.1,delay:t*.12}));break;case`shutter`:this.noise(.04,{freq:5e3,filter:`highpass`,vol:.2}),this.noise(.05,{freq:3e3,filter:`highpass`,vol:.15,delay:.07});break;case`bite`:this.tone(n(84),.12,{type:`square`,vol:.08}),this.tone(n(91),.15,{type:`square`,vol:.08,delay:.1}),this.noise(.2,{freq:2e3,vol:.1});break;case`reel`:this.tone(n(79+(t||0)*3),.1,{type:`triangle`,vol:.1});break;case`dig`:this.noise(.15,{freq:600,vol:.2}),this.noise(.12,{freq:900,vol:.15,delay:.18});break;case`ring`:this.tone(n(84),.3,{vol:.12,echo:!0}),this.tone(n(91),.3,{vol:.08,delay:.05});break;case`fire`:this.noise(.8,{freq:300,sweep:2e3,vol:.2});break;case`sheep`:this.tone(420,.35,{type:`sawtooth`,vol:.04,slide:380}),this.tone(424,.35,{type:`sawtooth`,vol:.03});break;case`meow`:this.tone(700,.3,{type:`triangle`,vol:.06,slide:500});break;case`mirror`:this.tone(n(77),.2,{type:`triangle`,vol:.08});break;case`tick`:this.tone(n(81),.1,{type:`square`,vol:.05});break;case`go`:this.tone(n(88),.4,{type:`square`,vol:.07});break;case`push`:this.noise(.25,{freq:250,vol:.18});break;case`plate`:this.tone(n(64),.3,{type:`triangle`,vol:.12}),this.tone(n(71),.3,{type:`triangle`,vol:.1,delay:.1});break;case`star`:[84,88,91,96].forEach((e,t)=>this.tone(n(e),.8,{vol:.08,delay:t*.15,echo:!0}));break;case`ability`:[60,64,67,72,76,79,84].forEach((e,t)=>this.tone(n(e),.5,{type:`triangle`,vol:.11,delay:t*.08,echo:!0}));break;case`swing`:this.noise(t?.3:.18,{freq:900,sweep:t?5200:4200,filter:`bandpass`,q:1.4,vol:t?.22:.16,attack:.02});break;case`hit`:this.noise(.09,{freq:2600,filter:`bandpass`,q:.9,vol:.32}),this.tone(170,.12,{type:`square`,vol:.07,slide:70}),this.tone(n(84),.08,{type:`triangle`,vol:.04});break;case`crit`:this.noise(.14,{freq:3500,filter:`bandpass`,q:.8,vol:.36}),this.tone(220,.18,{type:`square`,vol:.09,slide:60}),[88,95].forEach((e,t)=>this.tone(n(e),.25,{type:`triangle`,vol:.07,delay:t*.05,echo:!0}));break;case`hurt`:this.noise(.18,{freq:500,vol:.3}),this.tone(260,.22,{type:`sawtooth`,vol:.06,slide:120});break;case`die`:[64,60,57,52].forEach((e,t)=>this.tone(n(e),.5,{type:`triangle`,vol:.1,delay:t*.18,echo:!0}));break;case`enemyDie`:this.noise(.5,{freq:3e3,sweep:400,vol:.18}),[79,83,86,91].forEach((e,t)=>this.tone(n(e),.3,{vol:.05,delay:.05+t*.05,echo:!0}));break;case`poof`:this.noise(.3,{freq:2500,sweep:6e3,filter:`highpass`,vol:.1}),[84,88,91].forEach((e,t)=>this.tone(n(e),.25,{vol:.05,delay:t*.06,echo:!0}));break;case`heal`:[72,76,79,84].forEach((e,t)=>this.tone(n(e),.35,{type:`triangle`,vol:.07,delay:t*.05,echo:!0}));break;case`dodge`:this.noise(.22,{freq:600,sweep:2400,filter:`bandpass`,q:1.2,vol:.12});break;case`perfect`:this.tone(n(91),.3,{type:`triangle`,vol:.09,echo:!0}),this.tone(n(98),.3,{vol:.06,delay:.06});break;case`slam`:this.noise(.5,{freq:250,sweep:60,vol:.45}),this.tone(90,.4,{type:`sine`,vol:.25,slide:35});break;case`growl`:this.tone(110,.6,{type:`sawtooth`,vol:.05,slide:80}),this.noise(.6,{freq:300,vol:.06});break;case`gloom`:this.tone(180,.4,{type:`triangle`,vol:.06,slide:120}),this.tone(n(61),.4,{vol:.04,delay:.1});break;case`windup`:this.tone(300,.35,{type:`triangle`,vol:.05,slide:600});break;case`golemCharge`:this.noise(1,{freq:120,sweep:600,vol:.2}),this.tone(70,1,{type:`sawtooth`,vol:.05,slide:140})}}_ambienceInit(){let e=this.ctx;this.ambGain=e.createGain(),this.ambGain.gain.value=this.sfxVol*.9,this.ambGain.connect(this.master);let t=(t,n,r=.7)=>{let i=e.createBufferSource();i.buffer=this.noiseBuf,i.loop=!0;let a=e.createBiquadFilter();a.type=n,a.frequency.value=t,a.Q.value=r;let o=e.createGain();return o.gain.value=0,i.connect(a),a.connect(o),o.connect(this.ambGain),i.start(),{g:o,f:a}};this.windL=t(500,`lowpass`),this.seaL=t(700,`lowpass`),this.rainL=t(4e3,`highpass`),this._chirpT=0}updateAmbience(e,t){if(!this.ctx)return;let n=this.ctx.currentTime,r=(e,t)=>e.g.gain.setTargetAtTime(t,n,.5);if(r(this.windL,.03+t.wind*.12),this.windL.f.frequency.setTargetAtTime(350+Math.sin(n*.3)*150+t.wind*300,n,.5),r(this.seaL,t.sea*(.08+Math.max(0,Math.sin(n*.7))*.08)),r(this.rainL,t.rain*.1),this._chirpT-=e,this._chirpT<=0){if(this._chirpT=.4+Math.random()*2.5,t.night>.5&&t.rain<.3)for(let e=0;e<3;e++)this.tone(4200+Math.random()*300,.04,{vol:.012,delay:e*.07,dest:this.ambGain});else if(t.birds>.2&&t.rain<.3&&Math.random()<t.birds){let e=2200+Math.random()*1500,t=2+Math.floor(Math.random()*3);for(let n=0;n<t;n++)this.tone(e*(1+(Math.random()-.5)*.2),.09,{vol:.02,delay:n*.12,slide:e*1.3,dest:this.ambGain})}}}setMood(e){this.mood=e}_musicStart(){let e=this.ctx,t=e=>440*2**((e-69)/12),n={day:{chords:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]],scale:[72,74,76,79,81,84,86],bpm:76,density:.55},night:{chords:[[57,60,64],[53,57,60],[55,59,62],[52,55,59]],scale:[69,72,74,76,79,81],bpm:60,density:.3},rain:{chords:[[57,60,64],[55,59,62],[53,57,60],[53,57,60]],scale:[69,72,74,76,79],bpm:64,density:.25},tense:{chords:[[57,60,64],[57,60,64],[55,58,62],[55,58,62]],scale:[69,71,72,74,76,77],bpm:120,density:.9},ending:{chords:[[60,64,67,71],[57,60,64,67],[53,57,60,64],[55,59,62,65]],scale:[72,76,79,83,84,88],bpm:70,density:.8}},r=0,i=e.currentTime+.5,a=(n,r,i)=>{for(let a of n)for(let n of[-4,4]){let o=e.createOscillator();o.type=`triangle`,o.frequency.value=t(a-12),o.detune.value=n;let s=e.createGain();s.gain.setValueAtTime(1e-4,r),s.gain.linearRampToValueAtTime(.035,r+i*.3),s.gain.linearRampToValueAtTime(1e-4,r+i);let c=e.createBiquadFilter();c.type=`lowpass`,c.frequency.value=900,o.connect(c),c.connect(s),s.connect(this.music),o.start(r),o.stop(r+i+.1)}},o=(n,r,i=.07)=>{let a=e.createOscillator();a.type=`sine`,a.frequency.value=t(n);let o=e.createOscillator();o.type=`triangle`,o.frequency.value=t(n)*2;let s=e.createGain();s.gain.setValueAtTime(1e-4,r),s.gain.exponentialRampToValueAtTime(i,r+.01),s.gain.exponentialRampToValueAtTime(1e-4,r+1.2);let c=e.createGain();c.gain.value=.15,a.connect(s),o.connect(c),c.connect(s),s.connect(this.music),s.connect(this.delay),a.start(r),o.start(r),a.stop(r+1.3),o.stop(r+1.3)},s=()=>{if(!this.ctx)return;let t=n[this.mood]||n.day,s=60/t.bpm;for(;i<e.currentTime+.3;){let e=Math.floor(r/4)%t.chords.length;if(r%4==0&&(a(t.chords[e],i,s*4.2),o(t.chords[e][0]-12,i,.05)),Math.random()<t.density){let e=t.scale[Math.floor(Math.random()*t.scale.length)];o(e,i+(Math.random()<.3?s/2:0),.045)}r++,i+=s}};this._musicTimer=setInterval(s,100)}},{Cyl:lg,Cone:ug,Ico:dg,Box:fg,Sph:$}=cp,pg=new Map,mg=(e,t={})=>{let n=e+JSON.stringify(t);return pg.has(n)||pg.set(n,Xf(new Wo({color:e,roughness:t.rough??.72,metalness:t.metal??0,emissive:t.emissive??0,emissiveIntensity:t.ei??1}),16773596,t.rim??.32,2.6)),pg.get(n)},hg=(e,t)=>new K(e).offsetHSL(0,0,t).getHex();function gg(e){let t;switch(e){case`straw`:t=Q([Z(lg(.62,.62,.06,12),15255666,{}),Z(lg(.3,.36,.3,10),15255666,{y:.17}),Z(lg(.37,.37,.07,10),13649210,{y:.06})]);break;case`flower`:{let e=[Z(new No(.34,.06,5,12),6068798,{rx:Math.PI/2})],n=[15825574,16242506,16777215,10139903];for(let t=0;t<8;t++){let r=t/8*Math.PI*2;e.push(Z(dg(.09),n[t%4],{x:Math.cos(r)*.34,y:.05,z:Math.sin(r)*.34}))}t=Q(e);break}case`pirate`:t=Q([Z(lg(.5,.5,.08,3),2829099,{ry:Math.PI/6,sx:1.2}),Z(lg(.28,.34,.38,8),2829099,{y:.2}),Z(dg(.07),16777215,{y:.22,z:.33})]);break;case`beanie`:t=Q([Z($(.39,16,10),4159689,{y:-.02,sy:.8}),Z(dg(.12),16777215,{y:.3})]);break;case`crown`:{let e=[Z(lg(.32,.32,.22,10),15911244,{y:.1})];for(let t=0;t<5;t++){let n=t/5*Math.PI*2;e.push(Z(ug(.08,.22,4),15911244,{x:Math.cos(n)*.28,y:.3,z:Math.sin(n)*.28}))}e.push(Z(dg(.07),8378623,{y:.15,z:.32})),t=Q(e);break}case`chef`:t=Q([Z(lg(.34,.32,.3,16),16777215,{y:.12}),Z($(.4,16,10),16777215,{y:.38,sy:.7})]);break;case`cap`:t=Q([Z($(.39,16,10),13649210,{y:0,sy:.6}),Z(fg(.5,.05,.35),13649210,{y:-.05,z:.35})]);break;case`wizard`:t=Q([Z(lg(.55,.55,.05,12),3816074,{}),Z(ug(.33,1,10),3816074,{y:.5,rz:.15}),Z(dg(.08),15911244,{y:.55,x:.1,z:.3})]);break;case`helmet`:t=Q([Z($(.4,16,10),12169892,{y:0,sy:.75}),Z(lg(.1,.1,.1,6),15911244,{y:.3})]);break;default:return null}let n=new q(t,$f);return n.castShadow=!0,n}function _g(){return Q([Z(lg(.035,.04,.26,10),5913122,{y:0}),Z($(.055,12,8),15911244,{y:.15}),Z(fg(.34,.05,.07),15911244,{y:-.15}),Z($(.04,10,8),8378623,{y:-.15,z:.04}),Z(fg(.085,.86,.022),14674421,{y:-.6}),Z(fg(.03,.84,.03),12175578,{y:-.6}),Z(ug(.06,.16,4),14674421,{y:-1.11,rx:Math.PI,ry:Math.PI/4,sz:.4})])}var vg=Xf(new Wo({vertexColors:!0,roughness:.28,metalness:.55,emissive:5224703,emissiveIntensity:0}),12577023,.6,2.2);function yg(e={}){let t={body:e.body??4165592,skin:e.skin??16766896,scarf:e.scarf??15289916,legs:e.legs??2964058,hair:e.hair??4861984,pack:e.pack??11896655,boots:e.boots??5913122,eyes:e.eyes??3811866},n=e.scale??1,r=new G,i=new G;i.scale.setScalar(n),r.add(i);let a=(e,t,n,r=0,i=0,a=0,o)=>{let s=new q(e,mg(t,o));return s.position.set(r,i,a),s.castShadow=!0,n.add(s),s},o=(e,t=20,n=14)=>new Mo(e,t,n),s=new G;s.position.y=.72,i.add(s);let c=new G;s.add(c),a(new ia(.31,.36,8,20),t.body,c,0,.3,0),a(new oa(.33,.37,.2,20,1,!0),hg(t.body,-.06),c,0,.02,0).material.side=2,a(new No(.315,.035,8,28),4863012,c,0,.14,0).rotation.x=Math.PI/2,a(new ra(.1,.08,.04),15911244,c,0,.14,.33,{metal:.6,rough:.35}),e.skirt&&(a(new sa(.5,.58,20,1,!0),t.body,c,0,.04,0).material.side=2);let l=new G;if(l.position.y=.94,c.add(l),a(o(.36,28,20),t.skin,l,0,.05,0),a(o(.075,12,10),t.skin,l,-.35,.03,0).scale.set(.6,1,1),a(o(.075,12,10),t.skin,l,.35,.03,0).scale.set(.6,1,1),e.hairStyle!==`bald`){let e=a(new Mo(.385,28,16,0,Math.PI*2,0,Math.PI*.52),t.hair,l,0,.08,-.02);e.rotation.x=-.28;for(let e=0;e<5;e++){let n=(e-2)*.32;a(new sa(.09,.26,10),t.hair,l,Math.sin(n)*.3,.26,Math.cos(n)*.3).rotation.set(Math.PI-.5,n,0)}a(o(.12,12,10),t.hair,l,-.3,.02,-.08).scale.set(.7,1.4,1),a(o(.12,12,10),t.hair,l,.3,.02,-.08).scale.set(.7,1.4,1),a(o(.3,16,12),t.hair,l,0,0,-.13).scale.set(1.1,1.05,.9)}e.beard&&a(o(.26,16,12),e.beard,l,0,-.18,.16).scale.set(1,.9,.8);let u=[];for(let n of[-1,1]){let r=new G;r.position.set(n*.13,.06,.305),l.add(r),a(o(.072,14,10),16777215,r).scale.set(1,1.15,.45),a(o(.05,12,10),t.eyes,r,0,-.005,.022).scale.set(1,1.2,.5),a(o(.018,8,6),16777215,r,n*-.015,.025,.045,{emissive:16777215,ei:.6}),u.push(r);let i=a(new ra(.11,.022,.03),e.hairStyle===`bald`?7035466:hg(t.hair,-.05),l,n*.13,.17,.32);i.rotation.z=n*-.12}a(o(.03,10,8),hg(t.skin,-.06),l,0,-.02,.36);let d=a(new No(.04,.011,6,14,Math.PI),10107450,l,0,-.09,.335);d.rotation.z=Math.PI,a(o(.055,10,8),16751242,l,-.22,-.04,.27,{rim:0}).scale.set(1,.6,.4),a(o(.055,10,8),16751242,l,.22,-.04,.27,{rim:0}).scale.set(1,.6,.4),e.glasses&&(a(new No(.085,.014,8,20),3355443,l,-.13,.06,.345,{metal:.6}),a(new No(.085,.014,8,20),3355443,l,.13,.06,.345,{metal:.6}),a(new ra(.08,.015,.015),3355443,l,0,.07,.35));let f=new G;f.position.y=.36,l.add(f);let p=new G;p.position.y=.68,c.add(p),a(new No(.27,.095,10,24),t.scarf,p).rotation.x=Math.PI/2;let m=a(new ra(.17,.05,.52,1,1,4),t.scarf,p,.12,0,-.42);if(m.geometry.translate(0,0,.1),a(new ra(.19,.06,.06),hg(t.scarf,-.1),m,0,0,-.17),e.pack!==!1){a(new ra(.46,.5,.25,2,2,2),t.pack,c,0,.36,-.34),a(new ra(.48,.16,.27),hg(t.pack,-.08),c,0,.55,-.34),a(new oa(.1,.1,.56,14),13218954,c,0,.68,-.36).rotation.z=Math.PI/2;for(let e of[-1,1])a(new ra(.06,.62,.04),4863012,c,e*.17,.38,.29).rotation.x=-.12}let h=null;if(e.sword){h=new G;let e=new q(_g(),vg);e.castShadow=!0,h.add(e),h.position.set(.18,.95,-.5),h.rotation.set(.15,0,2.5),c.add(h)}let g=(e,t,n,r,i,o)=>{let s=new G;return s.position.set(i,o,0),r.add(s),a(new ia(t,e,6,12),n,s,0,-e/2-t*.5,0),s},_=g(.32,.1,t.body,c,-.4,.56),v=g(.32,.1,t.body,c,.4,.56),y=e.gloves??t.skin;for(let e of[_,v])a(new No(.1,.03,8,16),hg(t.body,-.08),e,0,-.4,0).rotation.x=Math.PI/2,a(o(.105,14,10),y,e,0,-.52,0);let b=g(.3,.12,t.legs,s,-.16,0),x=g(.3,.12,t.legs,s,.16,0);for(let e of[b,x])a(new ia(.115,.12,6,12),t.boots,e,0,-.5,.03).scale.set(1.05,.8,1.25),a(new oa(.135,.135,.045,14),2759956,e,0,-.6,.06).scale.set(1,1,1.45);let S=new G,C=new q(_g(),vg);C.castShadow=!0,S.add(C),S.position.set(0,-.53,.02),S.visible=!1,v.add(S);let w=new wn;w.position.set(0,-1.18,0),S.add(w);let T=new wn;T.position.set(0,-.2,0),S.add(T);let E=new G,D=new q(Q([Z(ug(1.6,.5,4),15911244,{ry:Math.PI/4,sx:1.4,sz:.7,y:.25}),Z(ug(1.45,.42,4),13649210,{ry:Math.PI/4,sx:1.4,sz:.7,y:.22,s:.55}),Z(lg(.03,.03,1.4,6),8017206,{y:-.45})]),$f);D.castShadow=!0,E.add(D),E.position.y=2.35,E.visible=!1,i.add(E);let O=new G,k=new q(Q([Z(fg(.18,.24,.18),16770979,{}),Z(ug(.14,.1,4),3881787,{y:.17,ry:Math.PI/4})]),new Wo({vertexColors:!0,emissive:16762970,emissiveIntensity:2.5}));O.add(k),O.position.set(0,-.55,.12),_.add(O),O.visible=!1;let A=new G,j=new q(Q([Z(lg(.02,.035,2.4,6),8017206,{y:1.1})]),$f);A.add(j),A.position.set(0,-.5,.05),A.rotation.x=1.1,v.add(A),A.visible=!1;let M=null,ee=e=>1-(1-Math.min(1,Math.max(0,e)))**3;return{root:r,rig:i,head:l,torso:c,hips:s,armL:_,armR:v,legL:b,legR:x,glider:E,lantern:O,rod:A,tail:m,sword:S,sheathed:h,swordTip:w,swordBase:T,phase:0,blink:2,setHat(e){M&&=(f.remove(M),null),e&&(M=gg(e),M&&f.add(M))},setArmed(e){S.visible=e,h&&(h.visible=!e)},animate(e){let{mode:t,speed:r=0,dt:a,t:o}=e;this.phase+=a*(r>.2?3+r*1.15:0);let d=this.phase,f=Math.min(1,a*14),p=(e,t,n)=>{e.rotation[t]+=(n-e.rotation[t])*f},h=.72,g=0,y=0,S=0,C=0,w=0,T=.1,D=-.1,O=0,k=0,A=0;switch(E.visible=t===`glide`,t){case`walk`:{let e=Math.min(1,r/7)*.9;C=Math.sin(d)*e,w=-C,y=-C*.8,S=-w*.8,h=.72+Math.abs(Math.cos(d))*.06*e,g=Math.min(.25,r*.02),k=Math.sin(d)*.12*e;break}case`air`:C=-.6,w=.3,y=-2.4,S=-2.4,T=.6,D=-.6;break;case`glide`:y=-3,S=-3,T=.15,D=-.15,C=.25,w=.35,g=.25;break;case`climb`:{let e=Math.sin(o*7)*+(r>.1);y=-2.6+e*.5,S=-2.6-e*.5,C=-.6-e*.4,w=-.6+e*.4,g=-.2;break}case`slide`:y=-1.2,S=-1.2,T=.9,D=-.9,C=.4,w=-.2,g=-.3;break;case`swim`:{let e=Math.sin(o*5);y=-2.2+e,S=-2.2-e,C=.4+e*.4,w=.4-e*.4,g=1.1,h=.9;break}case`fish`:S=-.9,y=-.5;break;case`wave`:S=-2.6+Math.sin(o*8)*.3,D=-.4;break;case`sit`:C=-1.5,w=-1.5,h=.45,y=-.3,S=-.3;break;case`cheer`:y=-2.9,S=-2.9,T=.4+Math.sin(o*10)*.2,D=-.4-Math.sin(o*10)*.2,h=.72+Math.abs(Math.sin(o*6))*.25;break;case`hurt`:g=-.35,y=-.6,S=-.6,T=.7,D=-.7,O=-.3;break;case`down`:g=-1.4,h=.35,y=-2.5,S=-2.5,C=-.3,w=-.2;break;default:{let e=Math.sin(o*2)*.03;h=.72+e*.3,y=e,S=-e,O=Math.sin(o*.7)*.05}}s.position.y+=(h-s.position.y)*f,p(c,`x`,g),p(c,`y`,k),p(_,`x`,y),p(v,`x`,S),p(_,`z`,T),p(v,`z`,D),p(b,`x`,C),p(x,`x`,w),p(l,`x`,O);let j=e.atk;if(j){let e=ee(j.k);switch(j.kind){case`atk1`:v.rotation.set(-1.45,0,1.75-e*3.1),c.rotation.y=.55-e*1.1,_.rotation.set(-.6,0,.5),g=.15;break;case`atk2`:v.rotation.set(-1.65+e*.5,0,-1.4+e*3),c.rotation.y=-.5+e*1,_.rotation.set(-.4,0,.7);break;case`atk3`:v.rotation.set(-1.5,0,1.5),_.rotation.set(-1.5,0,-1.5),A=e*Math.PI*2,b.rotation.x=.4,x.rotation.x=-.4;break;case`plunge`:v.rotation.set(-2.9+e*2.3,0,.1),_.rotation.set(-2.6+e*2,0,-.2),b.rotation.x=-.9,x.rotation.x=-.4;break;case`roll`:A=0,c.rotation.x=0,s.position.y=.45,i.rotation.x=e*Math.PI*2,_.rotation.set(-1.2,0,.3),v.rotation.set(-1.2,0,-.3),b.rotation.x=-1.4,x.rotation.x=-1.4}j.kind!==`roll`&&(i.rotation.x=0),i.rotation.y=A,c.rotation.x=g;let t=i.rotation.x,r=.7*n;i.position.set(0,r-r*Math.cos(t),-r*Math.sin(t))}else{let e=e=>e-Math.round(e/(Math.PI*2))*Math.PI*2;i.rotation.x=e(i.rotation.x),i.rotation.y=e(i.rotation.y),i.rotation.x+=(0-i.rotation.x)*f,i.rotation.y+=(0-i.rotation.y)*f,i.position.multiplyScalar(1-f)}m.rotation.x=.3+Math.sin(o*6)*.15+Math.min(.8,r*.06),m.rotation.y=Math.sin(o*3.3)*.2,this.blink-=a;let M=this.blink<.12;for(let e of u)e.scale.y=M?.12:1;this.blink<0&&(this.blink=2+Math.random()*3)}}}function bg(e){let t=new G,n=new q(Q(e),$f);return n.castShadow=!0,t.add(n),t}var xg=(e,t,n,r=.05,i=1)=>[Z($(r,12,8),1447446,{x:e,y:t,z:n}),Z($(r*.35,8,6),16777215,{x:e+r*.25*i,y:t+r*.35,z:n+r*.6})];function Sg(e){let t,n=[],r=(e,t,r,i,a,o)=>{for(let[s,c]of t){let t=new G;t.position.set(s,r,c);let l=[Z(lg(i*.8,i*1.15,r,10),a,{y:-r/2})];o&&l.push(Z(lg(i*.95,i*1.05,r*.12,10),o,{y:-r+r*.06}));let u=new q(Q(l),$f);u.castShadow=!0,t.add(u),e.add(t),n.push(t)}};switch(e){case`sheep`:{let e=[];for(let t=0;t<14;t++){let n=t*2.4,r=.22+t%3*.05;e.push(Z(dg(.3+t%2*.06,1),16184298,{x:Math.cos(n)*r,y:.86+Math.sin(t*1.7)*.12,z:(t/13-.5)*.85,round:!0,jitter:.05,seed:t}))}e.push(Z($(.2,14,10),3814192,{y:.98,z:.62,sz:1.3})),e.push(Z(dg(.17,1),16184298,{y:1.13,z:.56,round:!0})),e.push(Z($(.08,10,8),3814192,{x:.2,y:1,z:.56,sx:1.6,sz:.6,ry:-.3}),Z($(.08,10,8),3814192,{x:-.2,y:1,z:.56,sx:1.6,sz:.6,ry:.3})),e.push(...xg(.1,1.03,.82,.035),...xg(-.1,1.03,.82,.035,-1)),e.push(Z($(.05,8,6),14262432,{y:.92,z:.87})),t=bg(e),r(t,[[-.2,-.28],[.2,-.28],[-.2,.28],[.2,.28]],.6,.065,3814192,2235418);break}case`fox`:case`spiritfox`:{let n=e===`fox`?15234092:10479359,i=e===`fox`?3811872:14284543;t=bg([Z($(.24,16,12),n,{y:.58,sz:1.9}),Z($(.17,14,10),16777215,{y:.52,z:.25,sz:1.2}),Z($(.2,16,12),n,{y:.8,z:.5,sx:1.05}),Z(ug(.09,.26,12),16777215,{y:.75,z:.72,rx:Math.PI/2}),Z($(.035,8,6),1447446,{y:.75,z:.86}),...xg(-.09,.86,.66,.035,-1),...xg(.09,.86,.66,.035),Z(ug(.08,.22,10),n,{x:-.11,y:1.04,z:.47,rz:.15}),Z(ug(.08,.22,10),n,{x:.11,y:1.04,z:.47,rz:-.15}),Z(ug(.05,.14,8),i,{x:-.11,y:1.1,z:.48,rz:.15}),Z(ug(.05,.14,8),i,{x:.11,y:1.1,z:.48,rz:-.15}),Z($(.17,14,10),n,{y:.66,z:-.68,sz:2.4,rx:-.5}),Z($(.1,12,8),16777215,{y:.86,z:-1.08,sz:1.6,rx:-.5})]),r(t,[[-.12,-.26],[.12,-.26],[-.12,.26],[.12,.26]],.42,.045,i);break}case`deer`:{let e=11038782,n=[Z($(.3,18,12),e,{y:1.2,sz:1.9}),Z($(.2,14,10),15324856,{y:1.08,z:.1,sz:1.8,sx:1.2}),Z(lg(.11,.16,.62,12),e,{y:1.55,z:.55,rx:.45}),Z($(.15,14,10),e,{y:1.86,z:.72,sz:1.5}),Z($(.06,8,6),1447446,{y:1.82,z:.94}),...xg(-.1,1.9,.8,.032,-1),...xg(.1,1.9,.8,.032),Z($(.06,10,8),e,{x:-.15,y:1.98,z:.66,sx:.5,sy:1.6,rz:.9}),Z($(.06,10,8),e,{x:.15,y:1.98,z:.66,sx:.5,sy:1.6,rz:-.9}),Z($(.08,10,8),16777215,{y:1.32,z:-.58})];for(let e of[-1,1])n.push(Z(lg(.022,.03,.42,6),15128248,{x:e*.09,y:2.15,z:.66,rz:-e*.35})),n.push(Z(lg(.018,.022,.22,6),15128248,{x:e*.2,y:2.32,z:.72,rz:-e*.9,rx:.3})),n.push(Z(lg(.016,.02,.2,6),15128248,{x:e*.15,y:2.38,z:.6,rz:-e*.2,rx:-.5}));t=bg(n),r(t,[[-.16,-.38],[.16,-.38],[-.16,.38],[.16,.38]],.95,.05,8016434,2759956);break}case`crab`:t=bg([Z($(.3,16,10),14697786,{y:.2,sy:.5,sx:1.2}),Z($(.11,12,8),14697786,{x:-.4,y:.25,z:.22,sx:1.4}),Z($(.11,12,8),14697786,{x:.4,y:.25,z:.22,sx:1.4}),Z(ug(.06,.14,8),15755866,{x:-.52,y:.27,z:.3,rx:Math.PI/2,rz:.4}),Z(ug(.06,.14,8),15755866,{x:.52,y:.27,z:.3,rx:Math.PI/2,rz:-.4}),Z(lg(.015,.015,.15,6),2236962,{x:-.08,y:.36,z:.18}),Z(lg(.015,.015,.15,6),2236962,{x:.08,y:.36,z:.18}),Z($(.035,8,6),1447446,{x:-.08,y:.45,z:.18}),Z($(.035,8,6),1447446,{x:.08,y:.45,z:.18}),...[-1,1].flatMap(e=>[0,1,2].map(t=>Z(lg(.02,.02,.3,5),12728880,{x:e*.33,y:.12,z:-.12+t*.12,rz:e*1})))]);break;case`seagull`:{t=bg([Z($(.2,14,10),16777215,{sz:1.8}),Z($(.11,12,8),16777215,{y:.08,z:.34}),Z(ug(.04,.16,8),15905076,{y:.06,z:.5,rx:Math.PI/2}),Z($(.025,6,4),1447446,{x:-.07,y:.12,z:.4}),Z($(.025,6,4),1447446,{x:.07,y:.12,z:.4}),Z(fg(.16,.03,.2),10134702,{z:-.38})]);let e=e=>{let r=new G,i=new q(Q([Z(fg(.7,.03,.3),14541802,{x:e*.35}),Z(fg(.25,.035,.28),5922920,{x:e*.6})]),$f);r.add(i),t.add(r),n.push(r)};e(-1),e(1);break}case`owl`:t=bg([Z($(.3,16,12),9071180,{y:.35,sy:1.2}),Z($(.22,14,10),14271648,{y:.3,z:.12,sy:1.1}),Z($(.1,12,8),15787728,{x:-.1,y:.5,z:.22}),Z($(.1,12,8),15787728,{x:.1,y:.5,z:.22}),...xg(-.1,.5,.3,.05,-1),...xg(.1,.5,.3,.05),Z(ug(.04,.1,8),15905076,{y:.42,z:.31,rx:Math.PI/2+.4}),Z(ug(.06,.15,8),9071180,{x:-.15,y:.72}),Z(ug(.06,.15,8),9071180,{x:.15,y:.72})]);break;case`frog`:t=bg([Z($(.2,14,10),6076490,{y:.15,sy:.7}),Z($(.14,12,8),14215328,{y:.1,z:.06,sy:.5}),Z($(.07,10,8),6076490,{x:-.09,y:.27,z:.1}),Z($(.07,10,8),6076490,{x:.09,y:.27,z:.1}),...xg(-.1,.29,.14,.04,-1),...xg(.1,.29,.14,.04),Z($(.07,10,8),5152830,{x:-.18,y:.07,z:-.05,sz:1.6}),Z($(.07,10,8),5152830,{x:.18,y:.07,z:-.05,sz:1.6})]);break;case`goat`:{let e=15921126;t=bg([Z($(.28,16,12),e,{y:.92,sz:1.75}),Z($(.17,14,10),e,{y:1.25,z:.55,sz:1.35}),Z(ug(.045,.36,8),9076596,{x:-.09,y:1.46,z:.42,rx:-.75}),Z(ug(.045,.36,8),9076596,{x:.09,y:1.46,z:.42,rx:-.75}),Z($(.07,10,8),e,{x:-.18,y:1.28,z:.5,sx:1.6,sz:.6}),Z($(.07,10,8),e,{x:.18,y:1.28,z:.5,sx:1.6,sz:.6}),...xg(-.1,1.32,.71,.03,-1),...xg(.1,1.32,.71,.03),Z(ug(.06,.2,8),14472904,{y:1,z:.7,rx:Math.PI}),Z($(.05,8,6),14266528,{y:1.18,z:.77})]),r(t,[[-.15,-.32],[.15,-.32],[-.15,.32],[.15,.32]],.65,.055,14472904,4866104);break}case`lizard`:t=bg([Z($(.09,12,8),5222538,{y:.06,sz:3.2}),Z(ug(.05,.45,10),5222538,{y:.06,z:-.45,rx:-Math.PI/2}),Z($(.07,12,8),6275738,{y:.08,z:.32,sz:1.4}),...xg(-.05,.12,.36,.022,-1),...xg(.05,.12,.36,.022),...[-1,1].flatMap(e=>[-1,1].map(t=>Z(lg(.015,.015,.14,5),4168310,{x:e*.1,y:.04,z:t*.14,rz:e*1.2})))]);break;case`butterfly`:{t=new G;let e=[16228804,16242506,10139903][Math.floor(Math.random()*3)];for(let r of[-1,1]){let i=new G,a=new q(Q([Z($(.11,10,6),e,{x:r*.11,sy:.08,sz:.85}),Z($(.07,10,6),hg(e,-.1),{x:r*.09,z:-.1,sy:.08})]),$f);i.add(a),t.add(i),n.push(i)}break}case`whale`:t=bg([Z($(2.2,20,14),4020864,{sz:2.6,sy:.8}),Z(fg(3,.2,1.2),4020864,{z:-5.8,y:.3}),Z($(1.6,16,10),14148591,{y:-.9,sz:2.2,sy:.4}),...xg(-1.5,.2,3.6,.18,-1),...xg(1.5,.2,3.6,.18)]);break;case`cat`:t=bg([Z($(.17,14,10),15902298,{y:.36,sz:1.9}),Z($(.17,14,10),15902298,{y:.56,z:.34}),Z(ug(.07,.15,8),15902298,{x:-.09,y:.73,z:.33}),Z(ug(.07,.15,8),15902298,{x:.09,y:.73,z:.33}),...xg(-.07,.6,.48,.03,-1),...xg(.07,.6,.48,.03),Z($(.025,6,4),14252666,{y:.54,z:.51}),Z(lg(.035,.045,.5,8),15902298,{y:.6,z:-.4,rx:-.6})]),r(t,[[-.1,-.2],[.1,-.2],[-.1,.2],[.1,.2]],.22,.04,15902298);break;default:t=bg([Z(dg(.3),16711935,{})])}return t.userData.legs=n,t}var Cg=26,wg=.62,Tg=7,Eg=10.5,Dg=2.6,Og=10.5,kg=class{constructor(e,t,n){this.state=n,this.col=t,this.char=yg({sword:!0,gloves:7031344}),e.add(this.char.root),this.pos=new U,this.vel=new U,this.yaw=0,this.mode=`ground`,this.radius=.38,this.height=1.7,this.stamina=this.maxStamina,this.lastSafe=new U,this.safeTimer=0,this.cold=0,this.jumps=0,this.frozen=!1,this.animOverride=null,this.onEvent=()=>{},this.restrict=null,this.updrafts=[],this.time=0,this.stepPhase=0,this.airTime=0,this._n={x:0,y:1,z:0},this.lanternOn=!1,this.dash=null,this.moveScale=1,this.atkPose=null,this.hurtT=0}get maxStamina(){return 4.5+this.state.data.feathers.length*1.1}teleport(e,t,n){this.pos.set(e,t??X(e,n),n),this.vel.set(0,0,0),this.mode=`ground`,this.lastSafe.copy(this.pos),this.char.root.position.copy(this.pos)}floorAt(e,t,n){let r=X(e,t),i=this.col.supportHeight(e,t,this.radius,n);return i>r?{h:i,terrain:!1}:{h:r,terrain:!0}}steepAt(e,t){return Ff(e,t,this._n).y<wg}respawn(e){this.onEvent(`respawn`,e),this.teleport(this.lastSafe.x,this.lastSafe.y,this.lastSafe.z),this.cold=0,this.stamina=this.maxStamina}update(e,t,n,r=!0){this.time+=e;let i=this.state.data.abilities,a=this.maxStamina;if(this.frozen){this.vel.set(0,0,0),this.char.animate({mode:this.animOverride||`idle`,speed:0,dt:e,t:this.time,atk:this.atkPose}),this._syncModel(e);return}let o=t.axis(),s=n.forward(),c=n.right(),l=s.x*o.y+c.x*o.x,u=s.z*o.y+c.z*o.x,d=Math.hypot(l,u),f=r&&t.wasPressed(`Space`),p=t.isDown(`Space`),m=t.isDown(`ShiftLeft`,`ShiftRight`),h=this.pos,g=this.vel,_=If(h.x,h.z),v=`idle`,y=0;switch(this.mode){case`ground`:{let t=_-h.y,n=(m?Eg:Tg)*(t>.55?.6:1)*this.moveScale;g.x=wd(g.x,l*n,12,e),g.z=wd(g.z,u*n,12,e),this.dash&&(g.x=this.dash.vx,g.z=this.dash.vz);let r=h.x+g.x*e,i=h.z+g.z*e,o=this.floorAt(r,i,h.y+.6);if(o.terrain&&o.h>h.y+.04&&this.steepAt(r,i)){if(d>.1&&this.stamina>.05){h.x=r,h.z=i,h.y=o.h,this.mode=`climb`,this.onEvent(`grab`);break}r=h.x,i=h.z,g.x=0,g.z=0}h.x=r,h.z=i,this.col.resolve(h,this.radius,this.height);let s=this.floorAt(h.x,h.z,h.y+.6);if(s.h<h.y-.65){this.mode=`air`,g.y=0,this.jumps=1,this.airTime=0;break}if(h.y=s.h,g.y=0,s.terrain&&this.steepAt(h.x,h.z)){this.mode=`slide`;break}d>.1&&!this.dash&&this.moveScale>.5&&(this.yaw=Cd(this.yaw,Math.atan2(l,u),Math.min(1,e*12))),this.stamina=Math.min(a,this.stamina+e*3),y=Math.hypot(g.x,g.z),v=y>.4?`walk`:`idle`,this.stepPhase+=y*e,this.stepPhase>1.6&&(this.stepPhase=0,this.onEvent(`step`,t>.2?`water`:`ground`)),f&&!this.dash&&(g.y=9.2,this.mode=`air`,this.jumps=1,this.airTime=0,this.onEvent(`jump`)),t>1.15&&(this.mode=`swim`,this.onEvent(`splash`)),this.safeTimer+=e,this.safeTimer>.5&&t<.1&&!this.steepAt(h.x,h.z)&&(this.safeTimer=0,(!this.restrict||this.restrict(h,!0)!==!1)&&this.lastSafe.copy(h));break}case`air`:case`glide`:{if(this.airTime+=e,this.mode===`air`){let t=g.y>0&&p?Cg*.62:Cg;g.y-=t*e;let n=m?Eg:Tg;g.x=wd(g.x,l*n,d>.1?5:1.5,e),g.z=wd(g.z,u*n,d>.1?5:1.5,e),d>.1&&(this.yaw=Cd(this.yaw,Math.atan2(l,u),Math.min(1,e*8))),f&&(i.boots&&this.jumps<2?(g.y=8.6,this.jumps=2,this.onEvent(`djump`)):i.glider&&(this.mode=`glide`,this.onEvent(`glide`))),v=`air`}else{if(!p){this.mode=`air`;break}let t=-2.4;for(let e of this.updrafts)Math.hypot(h.x-e.x,h.z-e.z)<e.r&&h.y<e.top&&(t=7.5);g.y=g.y>t?Math.max(t,g.y-Cg*e):wd(g.y,t,t>0?3:6,e),d>.1&&(this.yaw=Cd(this.yaw,Math.atan2(l,u),Math.min(1,e*2.6)));let n=o.y<-.5?.55:1;g.x=wd(g.x,Math.sin(this.yaw)*Og*n,3,e),g.z=wd(g.z,Math.cos(this.yaw)*Og*n,3,e),v=`glide`}let t=h.x+g.x*e,n=h.z+g.z*e,r=X(t,n);if(r>h.y+.3&&this.steepAt(t,n)){if(d>.1&&this.stamina>.05){h.x=t,h.z=n,h.y=Math.max(h.y,r),this.mode=`climb`,g.set(0,0,0),this.onEvent(`grab`);break}t=h.x,n=h.z,g.x=0,g.z=0}h.x=t,h.z=n,h.y+=g.y*e,this.col.resolve(h,this.radius,this.height);let a=this.floorAt(h.x,h.z,h.y+(g.y<=0?.35:.05));if(h.y<=a.h){if(g.y<=0){let e=-g.y;h.y=a.h,g.y=0,this.mode=a.terrain&&this.steepAt(h.x,h.z)?d>.1&&this.stamina>.05?`climb`:`slide`:`ground`,this.onEvent(`land`,e),this.jumps=0}else h.y=a.h}this.mode!==`ground`&&h.y<_-1.15&&(this.mode=`swim`,g.y=0,this.onEvent(`splash`));break}case`climb`:{let t=Ff(h.x,h.z,this._n),n=this.floorAt(h.x,h.z,h.y+.3);if(t.y>=wg||!n.terrain){this.mode=`ground`;break}let r=Math.hypot(t.x,t.z),i=-t.x/r,a=-t.z/r,s=r/t.y,c=-a,l=i,u=o.y,d=o.x,p=i*(u*Dg/s)+c*(d*Dg*.8),m=a*(u*Dg/s)+l*(d*Dg*.8),b=h.x+p*e,x=h.z+m*e,S=Math.abs(u)+Math.abs(d)>.1;h.x=b,h.z=x;let C=h.y;if(h.y=X(h.x,h.z),this.col.resolve(h,this.radius,this.height),this.stamina-=e*(S?1:.35),this.yaw=Cd(this.yaw,Math.atan2(i,a),Math.min(1,e*10)),v=`climb`,y=+!!S,S&&Math.abs(h.y-C)>0&&(this.stepPhase+=e,this.stepPhase>.35&&(this.stepPhase=0,this.onEvent(`climbstep`))),this.stamina<=0){this.stamina=0,this.mode=`slide`,this.onEvent(`exhausted`);break}f&&this.stamina>.6&&(this.stamina-=1.2,g.set(i*1.2,7.5,a*1.2),this.mode=`air`,this.jumps=2,this.airTime=0,this.onEvent(`jump`)),h.y<_-1.15&&(this.mode=`swim`);break}case`slide`:{let t=Ff(h.x,h.z,this._n);if(t.y>=wg){this.mode=`ground`;break}let n=Math.hypot(t.x,t.z)||1,r=t.x/n,i=t.z/n;g.x=wd(g.x,r*8,4,e),g.z=wd(g.z,i*8,4,e),h.x+=g.x*e,h.z+=g.z*e,this.col.resolve(h,this.radius,this.height);let a=this.floorAt(h.x,h.z,h.y+.6);if(a.h<h.y-.8){this.mode=`air`,g.y=0;break}h.y=a.h,v=`slide`,d>.1&&l*-r+u*-i>.3&&this.stamina>.5&&(this.mode=`climb`),h.y<_-1.15&&(this.mode=`swim`,this.onEvent(`splash`));break}case`swim`:{let t=i.fins,n=t?m?8:6:3.2;g.x=wd(g.x,l*n,4,e),g.z=wd(g.z,u*n,4,e);let r=h.x+g.x*e,o=h.z+g.z*e,s=X(r,o),c=If(r,o);if(s>c-1.1){if(this.steepAt(r,o)&&s>c-.2){if(d>.1&&this.stamina>.05){h.x=r,h.z=o,h.y=s,this.mode=`climb`;break}r=h.x,o=h.z}else{h.x=r,h.z=o,h.y=Math.max(s,c-1.05),this.mode=`ground`;break}}if(h.x=r,h.z=o,this.col.resolve(h,this.radius,this.height),h.y=c-1.05+Math.sin(this.time*2.2)*.06,d>.1&&(this.yaw=Cd(this.yaw,Math.atan2(l,u),Math.min(1,e*6))),v=`swim`,y=Math.hypot(g.x,g.z),this.stamina=Math.min(a,this.stamina+e),t)this.cold=0;else if(this.cold+=e,this.cold>1.5){this.respawn(`cold`);return}this.stepPhase+=y*e,this.stepPhase>2.2&&(this.stepPhase=0,this.onEvent(`stroke`));break}}this.mode!==`swim`&&(this.cold=0),this.dash&&(this.dash.t-=e,this.dash.t<=0&&(this.dash=null)),this.restrict&&this.restrict(h,!1),this.hurtT>0&&(this.hurtT-=e,this.atkPose||(v=`hurt`)),this.animOverride&&(v=this.animOverride),this.char.animate({mode:v,speed:y,dt:e,t:this.time,atk:this.atkPose}),this._syncModel(e)}_syncModel(e){let t=this.char.root;t.position.copy(this.pos),t.rotation.y=Cd(t.rotation.y,this.yaw,Math.min(1,e*20)),this.char.lantern.visible=this.lanternOn}},Ag=class{constructor(e){this.cam=e,this.yaw=Math.PI,this.pitch=.32,this.dist=8,this.wantDist=8,this.target=new U,this.photo=!1,this.fovBase=60,this.photoFov=45,this.shake=0,this.override=null}forward(){return{x:-Math.sin(this.yaw),z:-Math.cos(this.yaw)}}right(){return{x:Math.cos(this.yaw),z:-Math.sin(this.yaw)}}update(e,t,n,r){let i=.0025*(r?.sensitivity??1),a=n.look();if(this.yaw-=a.dx*i,this.pitch+=a.dy*i*(r?.invertY?-1:1),this.pitch=bd(this.pitch,-.45,1.25),this.photo?this.photoFov=bd(this.photoFov+a.wheel*4,15,70):this.wantDist=bd(this.wantDist+a.wheel*.8,3.5,16),this.override){let t=this.override;this.cam.position.lerp(t.pos,1-Math.exp(-e*(t.speed||2))),this.target.lerp(t.look,1-Math.exp(-e*(t.speed||2))),this.cam.lookAt(this.target),this.cam.fov=wd(this.cam.fov,t.fov||this.fovBase,4,e),this.cam.updateProjectionMatrix();return}let o=this.photo?new U(t.x,t.y+1.7,t.z):new U(t.x,t.y+1.5,t.z);this.target.x=wd(this.target.x,o.x,14,e),this.target.y=wd(this.target.y,o.y,8,e),this.target.z=wd(this.target.z,o.z,14,e);let s=this.photo?.01:this.wantDist,c=Math.cos(this.pitch),l=Math.sin(this.pitch),u=Math.sin(this.yaw)*c,d=l,f=Math.cos(this.yaw)*c;if(!this.photo)for(let e=.15;e<=1;e+=.08){let t=s*e,n=this.target.x+u*t,r=this.target.y+d*t;if(X(n,this.target.z+f*t)+.35>r){s=Math.max(1.2,t-.4);break}}this.dist=s<this.dist?wd(this.dist,s,18,e):wd(this.dist,s,4,e);let p=this.cam.position;p.set(this.target.x+u*this.dist,this.target.y+d*this.dist,this.target.z+f*this.dist);let m=X(p.x,p.z)+.4;if(p.y<m&&(p.y=m),this.shake>0&&(this.shake=Math.max(0,this.shake-e*2),p.x+=(Math.random()-.5)*this.shake*.3,p.y+=(Math.random()-.5)*this.shake*.3),this.photo){this.cam.position.set(this.target.x,this.target.y,this.target.z);let e=new U(this.target.x-u,this.target.y-d,this.target.z-f);this.cam.lookAt(e)}else this.cam.lookAt(this.target);let h=this.photo?this.photoFov:this.fovBase;Math.abs(this.cam.fov-h)>.01&&(this.cam.fov=wd(this.cam.fov,h,10,e),this.cam.updateProjectionMatrix())}},jg=e=>document.querySelector(e),Mg=class{constructor(){this.root=jg(`#hud`),this.shard=jg(`#c-shard b`),this.feather=jg(`#c-feather b`),this.coin=jg(`#c-coin b`),jg(`#c-shard i`).textContent=`/30`,jg(`#c-feather i`).textContent=`/15`,this.clockText=jg(`#clock-text`),this.clockIcon=jg(`#clock-icon`),this.weather=jg(`#weather`),this.stamina=jg(`#stamina`),this.staminaFg=jg(`#stamina-fg`),this.prompt=jg(`#prompt`),this.promptText=jg(`#prompt span`),this.region=jg(`#region-banner`),this.toasts=jg(`#toasts`),this.big=jg(`#big-banner`),this.compass=jg(`#compass`),this.compassArrow=jg(`#compass-arrow`),this.compassDist=jg(`#compass-dist`),this.race=jg(`#race-hud`),this.raceTitle=jg(`#race-title`),this.raceTime=jg(`#race-time`),this.keysHint=jg(`#keys-hint`),this.toolsHint=jg(`#tools-hint`),this.vignette=jg(`#dark-vignette`),this._last={},this._regionTimer=null,this._bigTimer=null,this._v=new U;let e=2*Math.PI*22;this.staminaFg.style.strokeDasharray=e,this.circ=e}show(e){this.root.hidden=!e}pop(e){e.parentElement.classList.add(`pop`),setTimeout(()=>e.parentElement.classList.remove(`pop`),200)}update(e){let t=e.state.data,n=(e,t,n)=>{this._last[e]!==n&&(this._last[e]!==void 0&&this.pop(t),this._last[e]=n,t.textContent=n)};n(`s`,this.shard,t.shards.length),n(`f`,this.feather,t.feathers.length),n(`c`,this.coin,t.coins);let r=Math.floor(t.time),i=Math.floor((t.time-r)*60),a=Y(`第{0}天 {1}:{2}`,[t.day,String(r).padStart(2,`0`),String(Math.floor(i/10)*10).padStart(2,`0`)]);this._last.clock!==a&&(this._last.clock=a,this.clockText.textContent=a);let o=e.sky.night>.5?`🌙`:t.time<7||t.time>18?`🌅`:`☀️`;this._last.icon!==o&&(this._last.icon=o,this.clockIcon.textContent=o);let s=e.sky.rainTarget>0?`🌧️`:``;this._last.w!==s&&(this._last.w=s,this.weather.textContent=s);let c=e.player,l=c.stamina/c.maxStamina,u=l<.999||c.mode===`climb`;if(this.stamina.hidden=!u,u){this._v.set(c.pos.x,c.pos.y+1.9,c.pos.z).project(e.camera);let t=(this._v.x*.5+.5)*innerWidth+46,n=(-this._v.y*.5+.5)*innerHeight;this.stamina.style.left=t+`px`,this.stamina.style.top=n+`px`,this.staminaFg.style.strokeDashoffset=this.circ*(1-l),this.stamina.classList.toggle(`low`,l<.25)}}setPrompt(e){this._last.prompt!==e&&(this._last.prompt=e,this.prompt.hidden=!e,e&&(this.promptText.textContent=e))}toast(e,t=2600){let n=document.createElement(`div`);for(n.className=`toast`,n.textContent=e,this.toasts.appendChild(n);this.toasts.children.length>4;)this.toasts.firstChild.remove();setTimeout(()=>n.classList.add(`out`),t),setTimeout(()=>n.remove(),t+600)}banner(e,t=``,n=2600){this.big.querySelector(`.t1`).textContent=e,this.big.querySelector(`.t2`).textContent=t,this.big.classList.add(`show`),clearTimeout(this._bigTimer),this._bigTimer=setTimeout(()=>this.big.classList.remove(`show`),n)}showRegion(e){this.region.textContent=e,this.region.classList.add(`show`),clearTimeout(this._regionTimer),this._regionTimer=setTimeout(()=>this.region.classList.remove(`show`),2600)}setCompass(e,t){e===null?this.compass.hidden=!0:(this.compass.hidden=!1,this.compassArrow.style.transform=`rotate(${e-Math.PI/2}rad)`,this.compassDist.textContent=Y(`{0} 米`,[Math.round(t)]))}setRace(e,t){e===null?this.race.hidden=!0:(this.race.hidden=!1,this.raceTitle.textContent=e,this.raceTime.textContent=t)}setDarkness(e){this.vignette.style.opacity=e}setToolsHint(e){this._last.tools!==e&&(this._last.tools=e,this.toolsHint.textContent=e)}},Ng=(e,t=document)=>t.querySelector(e),Pg=class{constructor(e){this.audio=e,this.el=Ng(`#dialog`),this.nameEl=Ng(`.name`,this.el),this.textEl=Ng(`.text`,this.el),this.choicesEl=Ng(`.choices`,this.el),this.nextEl=Ng(`.next`,this.el),this.chatEl=Ng(`.chat`,this.el),this.inputEl=Ng(`input`,this.chatEl),this.active=!1,this._resolve=null,this._typing=null,this._choice=-1,this.voice=500,addEventListener(`keydown`,e=>this._key(e)),this.el.addEventListener(`mousedown`,e=>{e.target.classList.contains(`choice`)||e.target.tagName===`INPUT`||this._advance()})}open(e=500){this.active=!0,this.voice=e,this.el.hidden=!1}close(){this.active=!1,this.el.hidden=!0,this.closedAt=performance.now()}_key(e){if(this.active){if(this.chatEl.hidden===!1){if(e.code===`Enter`){e.preventDefault();let t=this.inputEl.value.trim();this.inputEl.value=``,this._finish(t||null)}else e.code===`Escape`&&(e.preventDefault(),this._finish(null))}else if(this._choice>=0){let t=this.choicesEl.children.length;[`ArrowUp`,`KeyW`].includes(e.code)?(this._select((this._choice-1+t)%t),e.preventDefault()):[`ArrowDown`,`KeyS`].includes(e.code)?(this._select((this._choice+1)%t),e.preventDefault()):[`Space`,`KeyE`,`Enter`].includes(e.code)&&(e.preventDefault(),this._typing?this._completeTyping():this._finish(this._choice))}else[`Space`,`KeyE`,`Enter`].includes(e.code)&&(e.preventDefault(),this._advance())}}_advance(){this._typing?this._completeTyping():this._choice>=0||this._finish(!0)}_finish(e){let t=this._resolve;this._resolve=null,this._choice=-1,this.choicesEl.innerHTML=``,this.chatEl.hidden=!0,t&&(this.audio?.play(`click`),t(e))}_type(e){this.textEl.textContent=``,this.nextEl.hidden=!0;let t=0;return new Promise(n=>{let r=()=>{this._typing&&(t+=1,this.textEl.textContent=e.slice(0,t),t%2==0&&e[t-1]!==` `&&this.audio?.play(`blip`,this.voice),t>=e.length?(this._typing=null,this.nextEl.hidden=!1,n()):this._typing.timer=setTimeout(r,/[，。！？…、.,!?]/.test(e[t-1])?110:28))};this._typing={text:e,done:n,timer:setTimeout(r,30)}})}_completeTyping(){if(!this._typing)return;clearTimeout(this._typing.timer);let{text:e,done:t}=this._typing;this._typing=null,this.textEl.textContent=e,this.nextEl.hidden=this._choice>=0,t()}say(e,t){return this.nameEl.textContent=e,this.nameEl.hidden=!e,new Promise(e=>{this._resolve=e,this._type(t)})}choose(e,t,n){return this.nameEl.textContent=e,this.nameEl.hidden=!e,new Promise(e=>{this._resolve=e,this._choice=0,this._type(t).then(()=>{this.nextEl.hidden=!0}),this.choicesEl.innerHTML=``,n.forEach((e,t)=>{let n=document.createElement(`div`);n.className=`choice`,n.textContent=e,n.style.pointerEvents=`auto`,n.onmouseenter=()=>this._select(t),n.onclick=()=>this._finish(t),this.choicesEl.appendChild(n)}),this._select(0)})}_select(e){this._choice=e,[...this.choicesEl.children].forEach((t,n)=>t.classList.toggle(`sel`,n===e))}chat(e,t){return this.nameEl.textContent=e,this.textEl.textContent=t,this.nextEl.hidden=!0,this.chatEl.hidden=!1,setTimeout(()=>this.inputEl.focus(),30),new Promise(e=>{this._resolve=e})}thinking(e){this.nameEl.textContent=e,this.textEl.innerHTML=Y(`<span class="thinking">（思考中…）</span>`),this.nextEl.hidden=!0}};function Fg(e,t){let n=e.data,r=e=>n.quests[e]?.stage||0,i=[];if(i.push({title:Y(`点亮星屑灯塔`),desc:n.ending?Y(`你点亮了灯塔，群岛重新有了光。`):Y(`收集星屑（{0}/{1}），登上霜顶雪山顶，打开灯塔的门。`,[n.shards.length,20]),done:n.ending,main:!0}),n.met.includes(`aila`)&&i.push({title:Y(`艾拉的礼物`),desc:n.abilities.glider?Y(`你得到了滑翔翼：在空中再按一次空格展开。`):Y(`先在村子附近找到 3 颗星屑，再回去找艾拉奶奶（{0}/3）。`,[Math.min(3,n.shards.length)]),done:n.abilities.glider}),n.met.includes(`pip`)){let e=n.codex.length,t=n.shards.includes(`pip3`);i.push({title:Y(`皮普的图鉴`),desc:t?Y(`图鉴研究完成！`):Y(`按 C 打开相机拍摄动植物和地标。图鉴 {0}/{1}，凑满 10 / 20 / 30 条去找皮普博士领奖励。`,[e,$m.length]),done:t})}if(r(`mia`)>=1){let e=n.quests.mia?.penned?.length||0;i.push({title:Y(`走失的羊`),desc:r(`mia`)>=2?Y(`米娅送了你一盏提灯。`):Y(`把走失的 3 只羊带回羊圈（{0}/3）。走到羊身边按 E，它就会跟着你。`,[e]),done:r(`mia`)>=2})}if(r(`hai`)>=1){let e=$m.filter(e=>e.fish&&n.codex.includes(e.id)).length;i.push({title:Y(`老海的钓鱼课`),desc:r(`hai`)>=2?Y(`老海送了你一双脚蹼，现在可以下海游泳了。`):Y(`钓到 3 种不同的鱼，然后回码头找老海（{0}/3）。`,[Math.min(3,e)]),done:r(`hai`)>=2}),i.push({title:Y(`传说中的金鳞鱼`),desc:n.shards.includes(`golden_fish`)?Y(`你钓到了金鳞鱼！`):Y(`老海说海里有一种会发光的金鳞鱼，非常难钓。`),done:n.shards.includes(`golden_fish`)})}r(`kuku`)>=1&&i.push({title:Y(`发光蘑菇`),desc:r(`kuku`)>=2?Y(`菇菇很开心。`):Y(`在迷雾森林深处找到 5 个发光蘑菇（{0}/5），需要提灯才能进去。`,[n.items.mushrooms]),done:r(`kuku`)>=2}),n.met.includes(`tiao`)&&i.push({title:Y(`峡谷赛跑`),desc:n.shards.includes(`race`)?Y(`你赢了跳跳！`):Y(`和跳跳比赛，看谁先跑到红石拱门下面。`),done:n.shards.includes(`race`)}),n.met.includes(`hoshino`)&&i.push({title:Y(`星空的秘密`),desc:n.shards.includes(`stars`)?Y(`三座石台都点亮了。`):Y(`夜晚按照星野说的顺序点亮天文台外的三座石台：天鹅、猎户、北斗。`),done:n.shards.includes(`stars`)}),n.met.includes(`feng`)&&i.push({title:Y(`怕冷的登山者`),desc:n.feathers.includes(`f_feng`)?Y(`阿峰把他的金羽毛送给了你。`):Y(`阿峰想要一杯热可可。村里的阿贝那里有卖。`),done:n.feathers.includes(`f_feng`)});for(let e of t.digs){if(!n.maps.includes(e.map))continue;let t=n.dug.includes(e.id);i.push({title:Y(`藏宝图`),desc:t?Y(`宝藏已经挖出来了。`):e.clue+(n.abilities.shovel?Y(`（拿着铲子在那里按 E 挖掘）`):Y(`（需要先买一把铲子）`)),done:t})}return i}function Ig(e,t){return Fg(e,t).filter(e=>!e.done).map(e=>Y(`{0}：{1}`,[e.title,e.desc])).join(`
`)}var Lg=(e,t=document)=>t.querySelector(e),Rg=[[`map`,Y(`地图`)],[`quests`,Y(`任务`)],[`collect`,Y(`收集`)],[`codex`,Y(`图鉴`)],[`wardrobe`,Y(`装扮`)],[`settings`,Y(`设置`)]];function zg(e=256){let t=document.createElement(`canvas`);t.width=t.height=e;let n=t.getContext(`2d`),r=n.createImageData(e,e),i=new K,a=900/e;for(let t=0;t<e;t++)for(let n=0;n<e;n++){let o=-450+(n+.5)*a,s=-450+(t+.5)*a,c=X(o,s),l=If(o,s);if(c<l){let e=Math.min(1,(l-c)/12);i.setRGB(.38-e*.2,.72-e*.25,.85-e*.15)}else{let e=X(o-a,s-a);Wp(o,s,c,.9,i),i.convertLinearToSRGB();let t=Math.max(-.25,Math.min(.25,(c-e)*.05));i.offsetHSL(0,0,t),c>l&&c<l+.6&&i.lerp(new K(.95,.93,.8),.4)}let u=(t*e+n)*4;r.data[u]=i.r*255,r.data[u+1]=i.g*255,r.data[u+2]=i.b*255,r.data[u+3]=255}return n.putImageData(r,0,0),t}var Bg=class{constructor(e){this.game=e,this.el=Lg(`#menu`),this.tabsEl=Lg(`.tabs`,this.el),this.body=Lg(`.tab-body`,this.el),this.tab=`map`,this.open_=!1,this.mapImg=null;for(let[e,t]of Rg){let n=document.createElement(`div`);n.className=`tab`,n.textContent=t,n.dataset.id=e,n.onclick=()=>{this.game.audio.play(`click`),this.show(e)},this.tabsEl.appendChild(n)}}get isOpen(){return this.open_}open(e=this.tab,t={}){this.open_=!0,this.travelOnly=!!t.travel,this.el.hidden=!1,this.game.input.unlock(),this.game.audio.play(`open`),this.show(e)}close(){this.open_=!1,this.el.hidden=!0,this.game.audio.play(`close`),this.game.state.save()}show(e){this.tab=e,[...this.tabsEl.children].forEach(t=>t.classList.toggle(`active`,t.dataset.id===e)),this.body.innerHTML=``,this[`_`+e]()}_map(){let e=this.game,t=e.state.data;this.mapImg||=zg(256);let n=document.createElement(`div`);n.className=`map-wrap`;let r=document.createElement(`canvas`);r.width=r.height=640;let i=document.createElement(`div`);i.className=`map-side`,n.append(r,i),this.body.appendChild(n);let a=r.getContext(`2d`),o=(e,t)=>[(e+450)/900*640,(t+450)/900*640];a.imageSmoothingEnabled=!0,a.drawImage(this.mapImg,0,0,640,640);let s=t.reveal;a.fillStyle=`rgba(235, 228, 210, 0.92)`;for(let e=0;e<64;e++)for(let t=0;t<64;t++)s[e*64+t]!==`1`&&a.fillRect(t*10-.5,e*10-.5,11,11);let c=(e,t)=>{let n=Math.floor((e+450)/900*64),r=Math.floor((t+450)/900*64);return s[r*64+n]===`1`};a.font=`bold 15px sans-serif`,a.textAlign=`center`;for(let e of Object.values(Rd)){if(!c(e.x,e.z))continue;let[t,n]=o(e.x,e.z);a.fillStyle=`rgba(255,255,255,0.9)`,a.strokeStyle=`rgba(0,0,0,.4)`,a.lineWidth=3,a.strokeText(e.name,t,n),a.fillText(e.name,t,n)}for(let n of e.content.digs){if(!t.maps.includes(n.map)||t.dug.includes(n.id))continue;let[e,r]=o(n.x+9,n.z-6);a.strokeStyle=`#d0453a`,a.lineWidth=3,a.setLineDash([6,5]),a.beginPath(),a.arc(e,r,22,0,Math.PI*2),a.stroke(),a.setLineDash([]),a.fillStyle=`#d0453a`,a.fillText(`✕`,e,r+5)}a.font=`18px sans-serif`;for(let n of e.npcs.list){if(!t.met.includes(n.id))continue;let[e,r]=o(n.pos.x,n.pos.z);a.fillText(`💬`,e,r+6)}{let[t,n]=o(e.world.lighthouse.x,e.world.lighthouse.z);a.fillText(`🗼`,t,n+6)}this._fireHit=[];for(let n of e.world.campfires){let e=t.campfires.includes(n.id);if(!e&&!c(n.x,n.z))continue;let[r,i]=o(n.x,n.z);a.beginPath(),a.arc(r,i,11,0,Math.PI*2),a.fillStyle=e?`#ff9a3c`:`#9a9a9a`,a.fill(),a.lineWidth=2,a.strokeStyle=`#fff`,a.stroke(),a.font=`13px sans-serif`,a.fillStyle=`#fff`,a.fillText(`🔥`,r,i+5),e&&this._fireHit.push({c:n,cx:r,cz:i})}let[l,u]=o(e.player.pos.x,e.player.pos.z),d=l<0||u<0||l>640||u>640;l=Math.max(12,Math.min(628,l)),u=Math.max(12,Math.min(628,u)),a.save(),a.translate(l,u),a.rotate(-e.player.yaw+Math.PI),a.beginPath(),a.moveTo(0,-12),a.lineTo(8,9),a.lineTo(0,4),a.lineTo(-8,9),a.closePath(),a.fillStyle=`#e94e3c`,a.fill(),a.strokeStyle=`#fff`,a.lineWidth=2,a.stroke(),a.restore();let f=e.canTravel(),p=`<div class="sec">${Y(`远方群岛`)}</div><div>${d?Y(`你在地图之外：距离群岛中心 <b>{0} 米</b>`,[Math.round(Math.hypot(e.player.pos.x,e.player.pos.z))]):Y(`走出海岸，沿着沙洲栈道就能到达。`)}<br>${Y(`最远到过 {0} 米`,[Math.round(t.farthest||0)])}</div>`;i.innerHTML=`<div class="sec">${Y(`图例`)}</div>
      <div>🔥 ${Y(`营火：`)}${f?`<b>${Y(`点击已点亮的营火快速旅行`)}</b>`:Y(`现在不能快速旅行`)}</div>
      <div>💬 ${Y(`认识的居民`)}</div><div>🗼 ${Y(`星屑灯塔`)}</div><div style="color:#d0453a">✕ ${Y(`藏宝图标记`)}</div>
      <div class="sec">${Y(`已点亮营火 {0}/{1}`,[t.campfires.length,e.world.campfires.length])}</div>
      <div>${e.world.campfires.filter(e=>t.campfires.includes(e.id)).map(e=>e.name).join(`<br>`)||Y(`还没有点亮任何营火。走到营火旁按 E 点亮。`)}</div>${p}`,r.onclick=t=>{if(!f)return;let n=r.getBoundingClientRect(),i=(t.clientX-n.left)/n.width*640,a=(t.clientY-n.top)/n.height*640;for(let t of this._fireHit)if(Math.hypot(i-t.cx,a-t.cz)<16){this.close(),e.fastTravel(t.c);return}}}_quests(){let e=Fg(this.game.state,this.game.content);e.sort((e,t)=>e.done-t.done||+!!t.main-!!e.main),this.body.innerHTML=e.map(e=>`<div class="quest ${e.done?`done`:``}"><div class="t">${e.done?`✔ `:``}${e.title}</div><div class="d">${e.desc}</div></div>`).join(``)}_collect(){let e=this.game.state.data,t=Object.entries(rh).map(([t,n])=>`<div class="card ${e.abilities[t]?``:`locked`}"><div class="t">${e.abilities[t]?n:Y(`？？？`)}</div></div>`).join(``),n=Object.values(e.items.fish).reduce((e,t)=>e+t,0),r=Math.floor(e.playTime/60),i=(e,t)=>`<div class="stat"><span>${e}</span><b>${t}</b></div>`,a=Object.entries(e.items.fish).map(([e,t])=>`<div class="card"><div class="t">🐟 ${$m.find(t=>t.id===e)?.name||e} × ${t}</div></div>`).join(``),o=e.maps.map(e=>`<div class="card"><div class="t">🗺️ ${Y(`藏宝图`)}</div><div class="d">${this.game.content.digs.find(t=>t.map===e)?.clue||``}</div></div>`).join(``);this.body.innerHTML=`
      <div class="sec">${Y(`进度`)}</div>
      ${i(`⭐ `+Y(`星屑`),`${e.shards.length} / 30`)}
      ${i(`🪶 `+Y(`金羽毛（体力上限）`),`${e.feathers.length} / 15`)}
      ${i(`🐚 `+Y(`贝壳币`),e.coins)}
      ${i(`📖 `+Y(`图鉴`),`${e.codex.length} / ${$m.length}`)}
      ${i(`🔥 `+Y(`营火`),`${e.campfires.length} / ${this.game.world.campfires.length}`)}
      ${i(`🎣 `+Y(`钓到的鱼`),n)}
      ${i(`📦 `+Y(`打开的宝箱`),`${e.chests.length} / ${this.game.content.chests.length}`)}
      ${i(`⏱ `+Y(`游戏时间`),Y(`{0} 分钟`,[r]))}
      <div class="sec">${Y(`道具`)}</div><div class="grid">${t}</div>
      <div class="sec">${Y(`背包`)}</div>
      <div class="grid">
        <div class="card"><div class="t">☕ ${Y(`热可可`)} × ${e.items.cocoa}</div></div>
        <div class="card"><div class="t">🍄 ${Y(`发光蘑菇`)} × ${e.items.mushrooms}</div></div>
        ${a}
        ${o}
      </div>`}_codex(){let e=this.game.state.data,t=[...new Set($m.map(e=>e.cat))];this.body.innerHTML=`<div style="color:#8a7c68">${Y(`按 C 打开相机，对准目标点击拍照即可登记。鱼类需要钓上来才会登记。已登记 {0} / {1}`,[e.codex.length,$m.length])}</div>`+t.map(t=>`<div class="sec">${t}</div><div class="grid">${$m.filter(e=>e.cat===t).map(t=>{let n=e.codex.includes(t.id);return`<div class="card ${n?``:`locked`}"><div class="t">${n?t.name:Y(`？？？`)}</div><div class="d">${n?t.desc:t.fish?Y(`用钓竿钓上来`):Y(`用相机拍下来`)}</div></div>`}).join(``)}</div>`).join(``)}_wardrobe(){let e=this.game.state.data,t=[`__none`,...e.hats];this.body.innerHTML=`<div style="color:#8a7c68">${Y(`点击切换帽子。帽子可以在商店买到，或者藏在宝箱里。已收集 {0} / {1}`,[e.hats.length,Object.keys(nh).length])}</div><div class="grid" style="margin-top:12px"></div>`;let n=Lg(`.grid`,this.body);for(let r of t){let t=document.createElement(`div`);t.className=`card clickable`+((e.hat||`__none`)===r?` sel`:``),t.style.pointerEvents=`auto`,t.innerHTML=`<div class="t">${r===`__none`?Y(`不戴帽子`):nh[r]}</div>`,t.onclick=()=>{e.hat=r===`__none`?null:r,this.game.player.char.setHat(e.hat),this.game.audio.play(`click`),this.show(`wardrobe`)},n.appendChild(t)}for(let t of Object.keys(nh))if(!e.hats.includes(t)){let e=document.createElement(`div`);e.className=`card locked`,e.innerHTML=`<div class="t">${Y(`？？？`)}</div>`,n.appendChild(e)}}_settings(){let e=this.game,t=e.state.data.settings,n=[`WASD / 方向键 移动 · 鼠标 转动视角（点击画面锁定，或按住右键拖动）· 滚轮 缩放`,`空格 跳跃；在空中再按一次：二段跳（弹跳靴）或展开滑翔翼（按住保持滑翔）`,`朝着陡坡移动就会攀爬，消耗体力；体力用完会滑下来。收集金羽毛可以提升体力上限`,`Shift 冲刺 · E 互动 · C 相机 · Tab / M 菜单和地图`,`左键 / J 攻击（连按打出三段连击，空中按下是下落重击）· Q 翻滚闪避（有无敌时间，消耗体力）`,`走出主岛的海岸（沙洲栈道、游泳或滑翔）就是无限延伸的远方群岛：越远越危险，宝箱也越丰厚`].map(e=>Y(e)).join(`<br>`),r=e=>`<span style="color:#8a7c68;font-size:13px">${e}</span>`;this.body.innerHTML=`
      <div class="row"><label>${Y(`语言 / Language`)}</label><select id="s-lang">${Object.entries(jd).map(([e,t])=>`<option value="${e}" ${Nd===e?`selected`:``}>${t}</option>`).join(``)}</select>${r(Y(`切换后会保存并重新载入`))}</div>
      <div class="row"><label>${Y(`音效音量`)}</label><input type="range" min="0" max="1" step="0.05" id="s-vol" value="${t.volume}"></div>
      <div class="row"><label>${Y(`音乐音量`)}</label><input type="range" min="0" max="1" step="0.05" id="s-music" value="${t.music}"></div>
      <div class="row"><label>${Y(`鼠标灵敏度`)}</label><input type="range" min="0.3" max="2.5" step="0.1" id="s-sens" value="${t.sensitivity}"></div>
      <div class="row"><label>${Y(`反转 Y 轴`)}</label><input type="checkbox" id="s-inv" ${t.invertY?`checked`:``}></div>
      <div class="row"><label>${Y(`画质`)}</label><select id="s-quality">${Object.entries(Ph).map(([e,n])=>`<option value="${e}" ${t.quality===e?`selected`:``}>${n.label}</option>`).join(``)}</select>${r(Y(`高：泛光、柔和阴影、茂密草地 · 极致：再加环境光遮蔽`))}</div>
      <div class="row"><label>${Y(`阴影`)}</label><input type="checkbox" id="s-shadow" ${t.shadows?`checked`:``}>${r(Y(`关闭可以提升帧率`))}</div>
      <div class="row"><label>${Y(`AI 闲聊`)}</label><input type="checkbox" id="s-ai" ${t.aiChat?`checked`:``}>${r(e.ai.available?Y(`已连接：和居民对话时可以选择“随便聊聊”`):Y(`服务器未配置 API Key，此功能不可用`))}</div>
      <div class="sec">${Y(`操作说明`)}</div>
      <div class="d" style="line-height:1.9;color:#8a7c68">${n}</div>
      <div class="row" style="margin-top:20px"><button class="btn ghost" id="s-save">${Y(`保存游戏`)}</button><button class="btn ghost" id="s-title">${Y(`保存并返回标题`)}</button></div>`;let i=(e,t)=>{let n=Lg(e,this.body);n.style.pointerEvents=`auto`,n.oninput=n.onchange=()=>t(n)};i(`#s-lang`,t=>{t.value!==Nd&&(e.state.save(),Id(t.value),location.reload())}),i(`#s-vol`,n=>{t.volume=+n.value,e.applySettings()}),i(`#s-music`,n=>{t.music=+n.value,e.applySettings()}),i(`#s-sens`,e=>{t.sensitivity=+e.value}),i(`#s-inv`,e=>{t.invertY=e.checked}),i(`#s-shadow`,n=>{t.shadows=n.checked,e.applySettings()}),i(`#s-quality`,n=>{t.quality=n.value,e.applySettings()}),i(`#s-ai`,e=>{t.aiChat=e.checked});let a=Lg(`#s-save`,this.body);a.style.pointerEvents=`auto`,a.onclick=()=>{e.state.save(),e.hud.toast(Y(`已保存`))};let o=Lg(`#s-title`,this.body);o.style.pointerEvents=`auto`,o.onclick=()=>{e.state.save(),location.reload()}}},Vg=class{constructor(e){this.game=e,this.list=[],this.current=null,this.running=!1}add(e){return this.list.push(e),e}remove(e){let t=this.list.indexOf(e);t>=0&&this.list.splice(t,1)}update(){let e=this.game;if(this.running||e.busy()){e.hud.setPrompt(null),this.current=null;return}let t=e.player.pos,n=null,r=1/0;for(let e of this.list){if(e.enabled===!1)continue;let i=typeof e.pos==`function`?e.pos():e.pos,a=i.x-t.x,o=i.z-t.z,s=(i.y??t.y)-t.y,c=Math.hypot(a,o);if(c>(e.radius||2.5)||Math.abs(s)>(e.height||3))continue;let l=e.label();if(!l)continue;let u=c-(e.priority||0);u<r&&(r=u,n={it:e,label:l})}this.current=n?.it||null,e.hud.setPrompt(n?n.label:null),n&&e.input.wasPressed(`KeyE`)&&performance.now()-(e.dialog.closedAt||0)>250&&this.run(n.it)}async run(e){this.running=!0;try{await e.action()}catch(e){console.error(e)}this.running=!1}},{Cyl:Hg,Cone:Ug,Box:Wg,Ico:Gg}=cp;function Kg(){let e=new Ba;for(let t=0;t<10;t++){let n=t%2?.22:.5,r=t/10*Math.PI*2+Math.PI/2,i=Math.cos(r)*n,a=Math.sin(r)*n;t?e.lineTo(i,a):e.moveTo(i,a)}let t=new To(e,{depth:.16,bevelEnabled:!0,bevelThickness:.06,bevelSize:.05,bevelSegments:1});return t.center(),t}function qg(){let e=document.createElement(`canvas`);e.width=e.height=64;let t=e.getContext(`2d`),n=t.createRadialGradient(32,32,0,32,32,32);return n.addColorStop(0,`rgba(255,240,170,1)`),n.addColorStop(.3,`rgba(255,220,120,0.5)`),n.addColorStop(1,`rgba(255,200,80,0)`),t.fillStyle=n,t.fillRect(0,0,64,64),new $i(e)}var Jg=class{constructor(e){this.g=e;let{scene:t,state:n,content:r,world:i}=e,a=i.anchors;this.items=[];let o=Kg(),s=new Wo({color:16767050,emissive:16758812,emissiveIntensity:1.2,roughness:.3,metalness:.2}),c=new Lr({map:qg(),transparent:!0,depthWrite:!1,blending:2}),l=Q([Z(Ug(.18,1,6),16769162,{sx:.5,sz:.12,y:.1}),Z(Hg(.02,.02,1.1,4),13212206,{y:0})]),u=new Wo({vertexColors:!0,emissive:16761402,emissiveIntensity:.9,flatShading:!0}),d=e=>{let n=new G,r=new q(o,s);r.castShadow=!0,n.add(r);let i=new Zr(c);return i.scale.setScalar(2.4),n.add(i),n.position.set(e.x,e.y,e.z),t.add(n),n};for(let e of r.shards){if((e.reward||!e.x&&!e.anchor)&&!e.hidden)continue;let t=e.anchor?ah(e,a):e,n={kind:`shard`,id:t.id,def:t,mesh:null,night:!!t.night,hidden:!!t.hidden};t.x!==void 0&&(n.mesh=d(t)),this.items.push(n)}this._makeShard=d;for(let e of r.feathers){if(e.reward)continue;let n=e.anchor?ah(e,a):e,r=new G,i=new q(l,u);i.rotation.z=.4,i.castShadow=!0,r.add(i);let o=new Zr(c);o.scale.setScalar(1.6),r.add(o),r.position.set(n.x,n.y,n.z),t.add(r),this.items.push({kind:`feather`,id:n.id,def:n,mesh:r})}let f=Q([Z(Ug(.32,.16,8),16757697,{rx:Math.PI/2}),Z(Ug(.2,.1,8),16770273,{rx:Math.PI/2,z:.05})]),p=new Wo({vertexColors:!0,emissive:16748456,emissiveIntensity:.35,flatShading:!0});this.coins=r.coins.filter(e=>!n.data.coinsTaken.includes(e.id)).map(e=>({...e,alive:!0})),this.coinMesh=new Di(f,p,Math.max(1,this.coins.length)),this.coinMesh.frustumCulled=!1,t.add(this.coinMesh),this._dummy=new wn,this.chests=[];for(let i of r.chests){let r=i.anchor?ah(i,a):i,o=n.data.chests.includes(r.id),s=new G,c=new q(Q([Z(Wg(1.1,.6,.75),10119738,{y:.3}),Z(Wg(1.14,.1,.79),14262330,{y:.5}),Z(Wg(.15,.2,.05),14262330,{y:.45,z:.4})]),$f),l=new G;l.position.set(0,.6,-.375);let u=new q(Q([Z(Wg(1.1,.3,.75),9067054,{y:.15,z:.375}),Z(Wg(1.14,.08,.79),14262330,{y:.28,z:.375})]),$f);l.add(u),c.castShadow=u.castShadow=!0,s.add(c,l);let d=r.y??X(r.x,r.z);s.position.set(r.x,d,r.z),s.rotation.y=Math.atan2(-r.x,-r.z),o&&(l.rotation.x=-1.9),t.add(s);let f={def:r,grp:s,lid:l,opened:o};this.chests.push(f),e.interact.add({pos:{x:r.x,y:d,z:r.z},radius:2.2,label:()=>f.opened?null:Y(`打开宝箱`),action:()=>this.openChest(f)}),e.world.colliders.addBox(r.x,r.z,.55,.4,d,d+.9,s.rotation.y,{walkable:!0})}let m=Q([Z(Hg(.06,.08,.3,5),14284543,{y:.15}),Z(cp.Sph(.2,7,4),7337983,{y:.32,sy:.6})]),h=new Wo({vertexColors:!0,emissive:4186367,emissiveIntensity:1.6});this.glow=r.glowMushrooms.filter(e=>!n.data.flags[`gm_`+e.id]).map(e=>{let n=new q(m,h);return n.position.set(e.x,e.y,e.z),n.scale.setScalar(1.6),t.add(n),{...e,mesh:n,alive:!0}});for(let t of r.digs)e.interact.add({pos:{x:t.x,y:t.y,z:t.z},radius:3.5,priority:-1,label:()=>{let e=n.data;return e.dug.includes(t.id)||!e.maps.includes(t.map)?null:e.abilities.shovel?Y(`挖掘`):null},action:async()=>{n.add(`dug`,t.id),e.audio.play(`dig`),e.fx.emit(t.x,t.y+.3,t.z,30,{color:10122832,speed:4,gravity:9,size:.4}),e.player.animOverride=`cheer`,await e.wait(.6),e.player.animOverride=null,this.spawnShard(t.id,{x:t.x,y:t.y+1.4,z:t.z}),e.hud.toast(Y(`挖到宝藏了！`))}});for(let e of this.items)if(e.kind===`shard`&&e.hidden&&n.data.flags[`spawn_`+e.id]&&!n.has(`shards`,e.id)){let t=n.data.flags[`spawn_`+e.id];this.spawnShard(e.id,t,!0)}this.syncVisibility()}syncVisibility(){let e=this.g.state.data;for(let t of this.items){if(!t.mesh)continue;let n=t.kind===`shard`?e.shards.includes(t.id):e.feathers.includes(t.id);t.taken=n,t.mesh.visible=!n&&!(t.night&&this.g.sky.night<.5)}}spawnShard(e,t,n=!1){let r=this.items.find(t=>t.id===e&&t.kind===`shard`);r||(r={kind:`shard`,id:e,def:{id:e}},this.items.push(r)),!this.g.state.has(`shards`,e)&&(r.def={...r.def,...t},r.mesh&&this.g.scene.remove(r.mesh),r.mesh=this._makeShard(r.def),r.hidden=!1,r.taken=!1,this.g.state.data.flags[`spawn_`+e]={x:t.x,y:t.y,z:t.z},n||(this.g.audio.play(`star`),this.g.fx.emit(t.x,t.y,t.z,50,{color:16769126,speed:6,gravity:1,life:1.4})))}awardShard(e,t){if(this.g.state.has(`shards`,e))return!1;let n=t||this.g.player.pos;return this.g.fx.emit(n.x,n.y+1.5,n.z,60,{color:16769126,speed:6,gravity:1,life:1.4}),this.collectShard(e),!0}collectShard(e){let t=this.g,n=t.state;if(!n.add(`shards`,e))return;let r=n.data.shards.length;t.audio.play(`shard`),t.hud.banner(Y(`获得星屑！`),`${r} / 30`),r===3&&!n.data.abilities.glider&&setTimeout(()=>t.hud.toast(Y(`已经有 3 颗星屑了，回村里找艾拉奶奶吧！`),4e3),2600),r===20&&setTimeout(()=>t.hud.toast(Y(`星屑够了！去霜顶雪山顶点亮灯塔吧！`),5e3),2600),r===30&&!n.data.hats.includes(`crown`)&&(n.add(`hats`,`crown`),setTimeout(()=>t.hud.banner(Y(`全部星屑收集完成！`),Y(`获得了「星之王冠」，去菜单的装扮里戴上吧`),4500),3e3)),n.save()}collectFeather(e){let t=this.g,n=t.state;n.add(`feathers`,e)&&(t.audio.play(`feather`),t.player.stamina=t.player.maxStamina,t.hud.banner(Y(`获得金羽毛！`),Y(`体力上限提升 · {0} / 15`,[n.data.feathers.length])),n.save())}async openChest(e){let t=this.g,n=t.state,r=e.def.reward;e.opened=!0,n.add(`chests`,e.def.id),t.audio.play(`chest`);let i=performance.now();await new Promise(t=>{let n=()=>{let r=Math.min(1,(performance.now()-i)/400);e.lid.rotation.x=-1.9*r,r<1?requestAnimationFrame(n):t()};n()});let a=e.grp.position;if(t.fx.emit(a.x,a.y+.8,a.z,40,{color:16767050,speed:4,gravity:3}),r.coins&&(n.addCoins(r.coins),t.hud.banner(Y(`获得 {0} 枚贝壳币`,[r.coins]),``),t.audio.play(`coin`)),r.hat&&(n.add(`hats`,r.hat),t.hud.banner(Y(`获得帽子：{0}`,[nh[r.hat]]),Y(`在菜单的「装扮」里可以戴上`))),r.map){n.add(`maps`,r.map);let e=t.content.digs.find(e=>e.map===r.map);t.hud.banner(Y(`获得藏宝图！`),n.data.abilities.shovel?Y(`去地图上标记的地方挖宝吧`):Y(`需要一把铲子才能挖宝（阿贝的店里有卖）`),4e3),setTimeout(()=>t.hud.toast(e.clue,6e3),1500)}n.save()}update(e,t){let n=this.g,r=n.player.pos,i=n.state.data,a=r.y+.9,o=n.sky.night>.5;for(let i of this.items){if(!i.mesh||i.taken)continue;let s=!(i.night&&!o);if(i.mesh.visible=s,!s)continue;let c=i.mesh;c.children[0].rotation.y+=e*2,c.position.y=i.def.y+Math.sin(t*2+i.def.x)*.15;let l=c.position.x-r.x,u=c.position.y-a,d=c.position.z-r.z;l*l+d*d<2.6&&Math.abs(u)<1.8?(i.taken=!0,c.visible=!1,n.fx.emit(c.position.x,c.position.y,c.position.z,40,{color:i.kind===`shard`?16769126:16761402,speed:5,gravity:1}),i.kind===`shard`?this.collectShard(i.id):this.collectFeather(i.id)):Math.random()<e*2&&n.fx.emit(c.position.x,c.position.y,c.position.z,1,{color:16773800,speed:.6,gravity:-.5,size:.25,spread:1.2})}let s=this._dummy,c=0;for(let e of this.coins){if(!e.alive)continue;let o=e.x-r.x,l=e.z-r.z,u=e.y-a;o*o+l*l<2&&Math.abs(u)<1.6?(e.alive=!1,i.coinsTaken.push(e.id),n.state.addCoins(1),n.audio.play(`coin`),n.fx.emit(e.x,e.y,e.z,8,{color:16757697,speed:2.5,size:.25})):(s.position.set(e.x,e.y+Math.sin(t*3+e.x)*.1,e.z),s.rotation.set(0,t*2+e.z,0),s.updateMatrix(),this.coinMesh.setMatrixAt(c++,s.matrix))}this.coinMesh.count=c,this.coinMesh.instanceMatrix.needsUpdate=!0;for(let t of this.glow)t.alive&&(t.mesh.rotation.y+=e,Math.hypot(t.x-r.x,t.z-r.z)<1.6&&(t.alive=!1,t.mesh.visible=!1,i.flags[`gm_`+t.id]=!0,i.items.mushrooms++,n.audio.play(`feather`),n.fx.emit(t.x,t.y+.4,t.z,20,{color:7337983,speed:3}),n.hud.toast(Y(`发光蘑菇 {0}/5`,[i.items.mushrooms]))));for(let t of n.content.digs)i.maps.includes(t.map)&&!i.dug.includes(t.id)&&Math.hypot(t.x-r.x,t.z-r.z)<14&&Math.random()<e*4&&n.fx.emit(t.x,t.y+.2,t.z,1,{color:16773800,speed:1,size:.3,spread:1.5,gravity:-1})}nearestShard(e){let t=null,n=1/0;for(let r of this.items){if(r.kind!==`shard`||!r.mesh||r.taken||!r.mesh.visible)continue;let i=Math.hypot(r.def.x-e.x,r.def.z-e.z);i<n&&(n=i,t=r)}return t?{x:t.def.x,z:t.def.z,d:n}:null}},Yg={aila:{name:Y(`艾拉奶奶`),voice:380,look:{body:9071541,hair:14606046,scarf:15911244,skirt:!0,legs:5917306,pack:!1,glasses:!0}},pip:{name:Y(`皮普博士`),voice:620,look:{body:4882369,hair:7028509,scarf:16777215,glasses:!0,pack:8017206},hat:`helmet`},abe:{name:Y(`货郎阿贝`),voice:470,look:{body:14262330,hair:2829099,scarf:4891615,beard:2829099},hat:`cap`},mia:{name:Y(`牧羊人米娅`),voice:700,look:{body:6989903,hair:13204026,scarf:15825574,skirt:!0},hat:`straw`},hai:{name:Y(`渔夫老海`),voice:330,look:{body:3104650,hair:10132122,scarf:16767050,beard:14606046,legs:3881787},anim:`fish`,hat:`beanie`},kuku:{name:Y(`采菇人菇菇`),voice:760,look:{body:14172987,hair:4861984,scarf:16777215,skirt:!0,scale:.85},anim:`sit`},tiao:{name:Y(`跳跳`),voice:820,look:{body:15903035,hair:2829099,scarf:5222538,scale:.75}},hoshino:{name:Y(`天文学家星野`),voice:540,look:{body:3095395,hair:1776427,scarf:11832575,glasses:!0},hat:`wizard`},feng:{name:Y(`登山者阿峰`),voice:420,look:{body:13649210,hair:4861984,scarf:4159689,beard:4861984,pack:4159689},anim:`sit`,hat:`beanie`}},Xg=class{constructor(e){this.g=e,this.list=[],this.history={};for(let[t,n]of Object.entries(Yg)){let r=ah(e.content.npcs[t],e.world.anchors),i=yg(n.look);n.hat&&i.setHat(n.hat);let a=r.y??X(r.x,r.z);i.root.position.set(r.x,a,r.z),i.root.rotation.y=r.yaw||0,e.scene.add(i.root);let o={id:t,...n,ch:i,pos:i.root.position,baseYaw:r.yaw||0,talking:!1,t:Math.random()*10};t===`hai`&&(i.rod.visible=!0),this.list.push(o),e.world.colliders.addCylinder(r.x,r.z,.45,a,a+1.8),e.interact.add({pos:o.pos,radius:2.8,priority:.5,label:()=>Y(`和{0}说话`,[o.name]),action:()=>this.talk(o)})}this.cat=Sg(`cat`),this.cat.position.set(-14,X(-14,136),136),e.scene.add(this.cat),e.codexLive.push({id:`cat`,obj:this.cat}),e.interact.add({pos:this.cat.position,radius:2,label:()=>Y(`摸摸团子`),action:async()=>{e.audio.play(`meow`);let t=this.cat.position;for(let n=0;n<5;n++)setTimeout(()=>e.fx.emit(t.x,t.y+.9,t.z,2,{color:16743080,speed:1,gravity:-1.5,size:.4}),n*120);e.hud.toast(Y(`团子舒服地眯起了眼睛 😺`)),await e.wait(.6)}})}get(e){return this.list.find(t=>t.id===e)}update(e,t){let n=this.g.player.pos;for(let t of this.list){t.t+=e;let r=Math.hypot(n.x-t.pos.x,n.z-t.pos.z),i=t.talking||r<6&&!t.anim;if(t.override!==`walk`){let r=i?Math.atan2(n.x-t.pos.x,n.z-t.pos.z):t.baseYaw;t.ch.root.rotation.y=Cd(t.ch.root.rotation.y,r,Math.min(1,e*5))}let a=t.override||(t.talking?t.anim===`sit`?`sit`:`idle`:t.anim||`idle`);t.ch.animate({mode:a,speed:t.animSpeed||0,dt:e,t:t.t})}this.cat.rotation.y+=Math.sin(t*.3)*e*.3}async talk(e){let t=this.g;e.talking=!0,t.beginDialog(e);let n={say:n=>t.dialog.say(e.name,n),choose:(n,r)=>t.dialog.choose(e.name,n,r),menu:async(n,r)=>{let i=[...r];t.ai.enabled()&&i.push({label:Y(`（随便聊聊）`),fn:()=>this.chat(e)}),i.push({label:Y(`再见`),fn:null});let a=await t.dialog.choose(e.name,n,i.map(e=>e.label));return i[a].fn?(await i[a].fn(),!0):!1}},r=!t.state.data.met.includes(e.id);r&&t.state.add(`met`,e.id);try{await Zg[e.id](t,e,n,r)}catch(e){console.error(e)}e.talking=!1,e.override=null,t.endDialog(),t.state.save()}async chat(e){let t=this.g,n=this.history[e.id]||=[];for(;;){let r=await t.dialog.chat(e.name,Y(`（想跟对方说点什么？回车发送，Esc 结束聊天）`));if(!r)return;t.dialog.thinking(e.name);let i=await t.ai.chat(e,n,r);n.push({role:`user`,content:r},{role:`assistant`,content:i}),n.length>12&&n.splice(0,n.length-12),await t.dialog.say(e.name,i)}}},Zg={async aila(e,t,n,r){let i=e.state.data;if(r){await n.say(Y(`哎呀，你醒啦！昨晚那场流星雨可真吓人，你就是在那时候被冲上岸的吧？`)),await n.say(Y(`我叫艾拉，以前是雪山顶上那座灯塔的守塔人。你看——北边最高的那座山，山顶上的灯塔已经熄灭了。`)),await n.say(Y(`流星雨把灯塔里的星星打碎了，碎片变成了「星屑」，散落在群岛的各个角落。`)),await n.choose(Y(`只要收集到 20 颗星屑，就能重新点亮灯塔。我老了，爬不动雪山……你愿意帮帮我吗？`),[Y(`交给我吧！`),Y(`星屑长什么样？`)])===1&&await n.say(Y(`金灿灿的，像一颗小星星，会自己发光。靠近了就能捡起来。`)),await n.say(Y(`太好了！村子附近就有几颗：一颗在老风车的阳台上，踩着木箱就能跳上去；东边还有一排石柱，最高那根的顶上也有一颗。`)),await n.say(Y(`先找到 3 颗星屑再回来找我，我把年轻时用的滑翔翼送给你。有了它，你就能飞过河去更远的地方了。`)),await n.say(Y(`对了，旁边的皮普博士在研究岛上的动植物，去跟他打个招呼吧。`));return}if(!i.abilities.glider){if(i.shards.length>=3){await n.say(Y(`哇，已经找到 3 颗星屑了！你真能干。`)),await n.say(Y(`来，这是我年轻时的滑翔翼。在空中再按一次空格就能展开，一直按住空格就会一直滑翔。`)),e.grantAbility(`glider`),await n.say(Y(`去村子东边的瞭望丘试试吧，从山顶起跳能一直滑过河，去对岸的红岩峡谷。`)),await n.say(Y(`哦，还有：看到营火的话记得点亮它。点亮的营火可以在地图上快速旅行，还能在旁边休息。`));return}await n.say(Y(`现在有 {0} 颗星屑了，还差 {1} 颗。风车阳台、东边的石柱顶，还有南边遗迹里好像也藏着一颗。`,[i.shards.length,3-i.shards.length]));return}if(i.ending){await n.say(Y(`灯塔又亮起来了……每天晚上看着那道光扫过海面，我就想起你。谢谢你。`)),await n.menu(Y(`还想到处逛逛吗？群岛上应该还有没找到的星屑呢。`),[{label:Y(`讲讲灯塔的故事`),fn:()=>Qg(n)}]);return}let a=$g(e);await n.menu(Y(`你已经找到 {0} 颗星屑了，还差 {1} 颗就能点亮灯塔。`,[i.shards.length,Math.max(0,20-i.shards.length)]),[{label:Y(`有什么建议吗？`),fn:()=>n.say(a)},{label:Y(`讲讲灯塔的故事`),fn:()=>Qg(n)}])},async pip(e,t,n,r){let i=e.state.data;if(r){await n.say(Y(`哦哦！新面孔！我是皮普，研究动植物的博士。我正在编写《星屑群岛图鉴》！`)),await n.say(Y(`可惜我腿脚慢，岛上好多地方都去不了。这台相机送给你，帮我拍下你见到的动物、植物和地标吧！`)),e.grantAbility(`camera`),await n.say(Y(`按 C 拿出相机，对准目标点一下左键就能拍照。拍到新东西就会自动登记进图鉴。鱼就得靠钓上来才算啦。`)),await n.say(Y(`图鉴每凑满 10 条就来找我，我有奖励给你——是星屑哦！`));return}let a=i.codex.length,o=[[10,`pip1`],[20,`pip2`],[30,`pip3`]];for(let[r,s]of o)if(a>=r&&!i.shards.includes(s)){await n.say(Y(`图鉴已经有 {0} 条了？！太棒了！这是约定好的奖励！`,[a])),e.collect.awardShard(s,t.pos);return}let s=o.find(([e,t])=>!i.shards.includes(t)),c=$m.filter(e=>!e.fish&&!i.codex.includes(e.id)),l=c[Math.floor(Math.random()*c.length)];await n.menu(s?Y(`图鉴现在有 {0} 条。凑到 {1} 条的时候再来找我吧！`,[a,s[0]]):Y(`图鉴研究已经很完整了，你真是个了不起的探险家！`),[{label:Y(`有什么没拍到的吗？`),fn:()=>n.say(l?Y(`嗯……比如「{0}」：{1}`,[l.name,l.desc]):Y(`全拍到了！你太厉害了！`))}])},async abe(e,t,n,r){let i=e.state.data;for(r&&await n.say(Y(`欢迎光临！我是货郎阿贝，岛上的东西我这里都有卖。用贝壳币付款就行——路边那些粉色的贝壳就是。`));;){let t=th.filter(e=>!(e.ability&&i.abilities[e.ability])&&!(e.hat&&i.hats.includes(e.hat))),r=Object.values(i.items.fish).reduce((e,t)=>e+t,0),a=t.map(e=>Y(`{0} — {1} 贝壳币`,[e.name,e.price]));r&&a.push(Y(`把鱼都卖掉（{0} 条）`,[r])),a.push(Y(`不买了`));let o=await n.choose(Y(`想要点什么？（你有 {0} 枚贝壳币）`,[i.coins]),a);if(o===a.length-1){await n.say(Y(`慢走！欢迎再来！`));return}if(r&&o===a.length-2){let t=0;for(let[e,n]of Object.entries(i.items.fish)){let r=Object.values(eh).flat().find(t=>t.id===e);t+=(r?.price||8)*n}i.items.fish={},e.state.addCoins(t),e.audio.play(`coin`),await n.say(Y(`一共 {0} 枚贝壳币，拿好！`,[t]));continue}let s=t[o];i.coins<s.price?await n.say(Y(`{0}要 {1} 枚贝壳币，你的钱好像不够哦。`,[s.name,s.price])):await n.choose(Y(`{0}：{1}
要买吗？`,[s.name,s.desc]),[Y(`买！`),Y(`再想想`)])===0&&(e.state.addCoins(-s.price),e.audio.play(`chest`),s.ability&&e.grantAbility(s.ability),s.hat&&(e.state.add(`hats`,s.hat),e.hud.toast(Y(`获得帽子：{0}`,[nh[s.hat]]))),s.item===`cocoa`&&(i.items.cocoa++,e.hud.toast(Y(`获得 热可可 ×1`))),await n.say(Y(`谢谢惠顾！`)))}},async mia(e,t,n,r){let i=e.state.quest(`mia`);if(i.stage===0)await n.say(Y(`呜呜……你好。我是米娅，这些羊都是我养的。`)),await n.say(Y(`昨晚的流星雨把它们吓坏了，有三只跑丢了，到现在还没回来……`)),await n.choose(Y(`你能帮我把它们找回来吗？`),[Y(`好，我去找找看`),Y(`它们往哪边跑了？`)]),await n.say(Y(`我好像看到一只往东边的河边跑了，一只往南边的遗迹那边，还有一只钻进了西边森林的边上。`)),await n.say(Y(`走到它身边按 E，它就会乖乖跟着你。把它带回这个羊圈就好！`)),i.stage=1,i.penned=i.penned||[];else if(i.stage===1){let r=i.penned.length;if(r>=3){await n.say(Y(`三只都回来了！谢谢你，谢谢你！`)),await n.say(Y(`这盏提灯送给你。西边的迷雾森林深处特别黑，没有灯是走不进去的。`)),e.grantAbility(`lantern`),await n.say(Y(`还有这个……是我在羊圈里捡到的，亮晶晶的，应该就是你在找的东西吧？`)),e.collect.awardShard(`mia`,t.pos),i.stage=2;return}await n.say(Y(`已经回来 {0} 只了，还差 {1} 只。东边河边、南边遗迹、西边森林边上，再找找看吧！`,[r,3-r]))}else await n.menu(Y(`羊儿们今天都很乖。提灯好用吗？`),[{label:Y(`森林里有什么？`),fn:()=>n.say(Y(`听说森林最深处的古树下住着发光的蘑菇，晚上还有萤火虫。菇菇常在森林营火那边采蘑菇。`))}])},async hai(e,t,n,r){let i=e.state.data,a=e.state.quest(`hai`),o=$m.filter(e=>e.fish&&i.codex.includes(e.id)).length;if(a.stage===0)await n.say(Y(`嗯？年轻人，会钓鱼吗？不会也没关系，我老海教你。`)),await n.say(Y(`这根钓竿拿去。看到水面上有涟漪的地方，走过去按 E 甩竿。`)),e.grantAbility(`rod`),await n.say(Y(`等鱼咬钩了会有提示，按 E 提竿，然后在指针走到绿色区域时按 E 收线，三次成功就钓上来了。`)),await n.say(Y(`钓到 3 种不同的鱼再来找我。到时候我送你一样好东西——没有它，你可没法在这冰冷的海里游泳。`)),a.stage=1;else if(a.stage===1){if(o>=3){await n.say(Y(`哈哈，3 种了！你是个好渔夫。`)),await n.say(Y(`这双脚蹼是我年轻时用的。穿上它就能在海里和湖里游泳了，按住 Shift 还能游得更快。`)),e.grantAbility(`fins`),await n.say(Y(`还有这个，是上周从一条鱼肚子里找到的。我留着也没用，给你吧。`)),e.collect.awardShard(`hai_fish`,t.pos),a.stage=2;return}await n.say(Y(`你已经钓到 {0} 种鱼了，还差 {1} 种。海边、水晶湖、河里的鱼都不一样哦。`,[o,3-o]))}else await n.menu(Y(`今天的海风真舒服。`),[{label:Y(`钓鱼的诀窍`),fn:async()=>{await n.say(Y(`码头和海岸边能钓到海鱼，晚上还会有灯笼鱼浮上来。水晶湖有水晶鲤，河里有鲑鱼和鲶鱼。`)),await n.say(Y(`传说海里还有一种金鳞鱼，鳞片像星屑一样亮……我钓了一辈子也只见过一次。`))}}])},async kuku(e,t,n,r){let i=e.state.data,a=e.state.quest(`kuku`);if(a.stage===0)await n.say(Y(`嘘——小声点，你会吓跑蘑菇的。……开玩笑啦，我是菇菇。`)),await n.say(Y(`森林最深处长着一种会发蓝光的蘑菇，可好看了。可是里面太黑了，我一进去就迷路。`)),await n.say(i.abilities.lantern?Y(`咦，你有提灯！能帮我采 5 个发光蘑菇吗？走过去就能捡起来。`):Y(`如果你有提灯的话，能帮我采 5 个回来吗？听说牧羊人米娅有一盏提灯。`)),a.stage=1;else if(a.stage===1){if(i.items.mushrooms>=5){await n.say(Y(`哇——5 个发光蘑菇！它们在你手里一闪一闪的，真漂亮！`)),i.items.mushrooms-=5,await n.say(Y(`作为谢礼，这个给你。我在蘑菇丛里找到的，它比蘑菇还亮呢。`)),e.collect.awardShard(`kuku`,t.pos),a.stage=2;return}await n.say(Y(`现在有 {0} 个，还差 {1} 个。都在森林最黑的那片地方。`,[i.items.mushrooms,5-i.items.mushrooms]))}else await n.menu(Y(`森林今天也很安静呢。`),[{label:Y(`附近有什么好玩的？`),fn:()=>n.say(Y(`北边那棵千年古树的树干上长满了大蘑菇，像台阶一样能一直爬到树顶！还有一只狐狸总在附近跑来跑去，好像想带人去什么地方。`))}])},async tiao(e,t,n,r){let i=e.state.data;r&&await n.say(Y(`嘿！你也是来探险的吗？我叫跳跳，是峡谷里跑得最快的人！`)),i.shards.includes(`race`)?await n.menu(Y(`上次输给你了，我每天都在练习！`),[{label:Y(`峡谷里有什么？`),fn:()=>n.say(Y(`峡谷的台地上有风铃柱，按 E 敲一下会出现一串光环。用滑翔翼按顺序穿过光环就能得到奖励！还有，那些旋转的风会把你往上吹哦。`))},{label:Y(`再比一次！`),fn:()=>e.challenges.startRace(t)}]):await n.choose(Y(`要不要比赛？从这里出发，谁先跑到红石拱门下面谁赢！`),[Y(`来比！`),Y(`下次吧`)])===0?(await n.say(Y(`好！对话结束就开始倒数，准备好！`)),e.challenges.startRace(t)):await n.say(Y(`胆小鬼～我随时奉陪！`))},async hoshino(e,t,n,r){let i=e.state.data;r&&(await n.say(Y(`你好啊，旅人。我是星野，在这里观测星空已经三十年了。`)),await n.say(Y(`那场流星雨……其实是灯塔里的「星核」碎掉了。它的碎片落到群岛各处，就是你在找的星屑。`))),i.shards.includes(`stars`)?await n.menu(Y(`今晚的星星格外亮。`),[{label:Y(`聊聊星星`),fn:()=>n.say(Y(`天鹅座、猎户座、北斗七星……古人用石台记下了它们。灯塔重新亮起来的时候，星星也会更亮吧。`))}]):(await n.say(Y(`天文台外面有三座古老的石台，分别刻着天鹅座、猎户座和北斗七星。`)),await n.say(Y(`夜晚按照「天鹅 → 猎户 → 北斗」的顺序点亮它们，星空就会回应你。顺序错了就要重来。`)),e.sky.night<.5&&await n.say(Y(`不过现在是白天，石台不会有反应。你可以去营火旁边休息到晚上再来。`)))},async feng(e,t,n,r){let i=e.state.data;if(r&&(await n.say(Y(`哈——欠！你好……我叫阿峰，想登上霜顶雪山的山顶，结果爬到这里就冻得动不了了。`)),await n.say(Y(`这座山有四层悬崖，一层比一层高。攀爬会消耗体力，体力不够的话爬到一半就会滑下来。`)),await n.say(Y(`收集金羽毛可以提升体力上限。我估计至少要五六根才能爬到山顶。`))),i.feathers.includes(`f_feng`))await n.menu(Y(`喝了热可可，浑身都暖和了！`),[{label:Y(`有什么攀登技巧？`),fn:()=>n.say(Y(`爬到一半体力快没了的时候，可以按空格往上蹬一大步，不过会消耗很多体力。悬崖之间的平台上可以休息恢复体力。`))}]);else if(i.items.cocoa>0){if(await n.choose(Y(`那是……热可可的香味？！`),[Y(`把热可可送给阿峰`),Y(`不给`)])===0){i.items.cocoa--,t.override=`cheer`,await n.say(Y(`啊——活过来了！太谢谢你了！`)),await n.say(Y(`这根金羽毛是我在悬崖上捡的，送给你。有了它你能爬得更高！`)),t.override=null,e.collect.collectFeather(`f_feng`),await n.say(Y(`爬悬崖时体力快没了可以按空格往上蹬一步。祝你登顶顺利！`));return}await n.say(Y(`呜……好吧……`))}else await n.say(Y(`好冷啊……要是有一杯热可可就好了。村里的阿贝好像有卖……`))}};async function Qg(e){await e.say(Y(`很久以前，群岛的夜晚总有迷路的船。第一代守塔人从天上请下了一颗星星，放进了雪山顶的灯塔里。`)),await e.say(Y(`从那以后，灯塔的光每晚都会扫过海面，指引出海的人回家。我守了那座灯塔四十年。`)),await e.say(Y(`直到那天晚上的流星雨……星核碎了，灯也熄了。不过只要星屑还在，光就一定能回来。`))}function $g(e){let t=e.state.data,n=e=>t.quests[e]?.stage||0;return t.abilities.lantern?t.abilities.fins?!t.abilities.shovel&&t.maps.length?Y(`你有藏宝图了？那得先去阿贝那里买把铲子。`):t.feathers.length<5?Y(`雪山的悬崖很高，多收集一些金羽毛吧。高处、小岛上、森林深处都藏着羽毛。`):t.abilities.compass?Y(`去雪山看看吧！营火边可以休息，晚上天文台的星野可能也有事找你。`):Y(`找不到星屑的话，阿贝那里有一个星屑罗盘，会指向最近的星屑。`):n(`hai`)===0?Y(`南边码头的老海整天在钓鱼，他年轻时可是游泳好手。`):Y(`老海让你钓 3 种不同的鱼？海边、湖里、河里的鱼都不一样哦。`):n(`mia`)===0?Y(`西北边羊圈的米娅好像遇到麻烦了，去看看她吧。`):Y(`米娅的羊找齐了吗？她说找到就送你提灯。`)}var{Cyl:e_,Cone:t_,Box:n_,Ico:r_,Sph:i_}=cp,a_=(e,t,n=0)=>({x:e,y:X(e,t)+n,z:t}),o_=class{constructor(e){this.g=e,this.activeCourse=null,this.race=null,this.pendingRace=null,this._buildUpdrafts(),this._buildCourses(),this._buildBoxPuzzle(),this._buildMirrors(),this._buildPedestals(),this._buildFox(),this._buildSheep()}_buildUpdrafts(){this.drafts=[];for(let e of this.g.content.updrafts)this.addUpdraft(e)}addUpdraft(e){let t=X(e.x,e.z);e.base=Math.max(t,0);let n=e.top-e.base+4,r=new q(new oa(e.r,e.r*.8,n,16,1,!0),new ii({color:13629183,transparent:!0,opacity:.06,side:2,depthWrite:!1,blending:2}));r.position.set(e.x,e.base+n/2,e.z),this.g.scene.add(r),e.mesh=r,this.drafts.push(e),this.g.player.updrafts.push(e)}_buildCourses(){let e=this.g,t=[{id:`ring_canyon1`,name:Y(`峡谷光环 · 北`),start:Rf(212,-67,10),to:{x:262,z:10},n:6},{id:`ring_canyon2`,name:Y(`峡谷光环 · 东`),start:Rf(298,-15,10),to:{x:225,z:50},n:6},{id:`ring_coast`,name:Y(`海岸光环`),start:e.content.mesaS,to:{x:qd[0].x,z:qd[0].z},n:7}];this.courses=t.map(e=>this._makeCourse(e))}_makeCourse(e){let t=this.g,n=e.start,r=e.to.x-n.x,i=e.to.z-n.z,a=Math.hypot(r,i),o=r/a,s=i/a,c=Math.min(26,(a-6)/e.n),l=[],u=n.y+2.5;for(let t=1;t<=e.n;t++){let r=n.x+o*c*t,i=n.z+s*c*t,a=0;for(let e=0;e<=6;e++){let t=e/6;a=Math.max(a,X(r-o*c*(1-t),i-s*c*(1-t)))}let d=u-c*.22;if(d<a+4.5){d=a+7;let t=r-o*c*.55,n=i-s*c*.55;this.addUpdraft({x:t,z:n,r:3.5,top:d+3,course:e.id})}l.push({x:r,y:d,z:i,passed:!1}),u=d}let d=n.x-o*2.5,f=n.z-s*2.5,p=X(d,f),m=new q(Q([Z(e_(.18,.22,2.6,6),8017206,{y:1.3}),Z(n_(1.4,.12,.12),8017206,{y:2.5}),Z(t_(.18,.35,6),15911244,{x:-.55,y:2.2}),Z(t_(.18,.35,6),8378623,{x:0,y:2.15}),Z(t_(.18,.35,6),15911244,{x:.55,y:2.2})]),$f);m.position.set(d,p,f),m.rotation.y=Math.atan2(o,s),m.castShadow=!0,t.scene.add(m),t.world.colliders.addCylinder(d,f,.3,p,p+2.6);let h=new Wo({color:10482687,emissive:4182271,emissiveIntensity:1.4,transparent:!0,opacity:.85}),g=new No(2.8,.22,6,24);for(let e of l)e.mesh=new q(g,h.clone()),e.mesh.position.set(e.x,e.y,e.z),e.mesh.rotation.y=Math.atan2(o,s),e.mesh.visible=!1,t.scene.add(e.mesh);let _=c*e.n,v={...e,rings:l,ux:o,uz:s,limit:Math.ceil(_/9+10),totem:{x:d,y:p,z:f}};return t.interact.add({pos:{x:d,y:p,z:f},radius:3,label:()=>this.activeCourse?null:t.state.has(`shards`,e.id)?Y(`敲响风铃（再挑战一次）`):Y(`敲响风铃`),action:async()=>this.startCourse(v)}),v}async startCourse(e){let t=this.g;if(!t.state.data.abilities.glider)t.hud.toast(Y(`光环飘在半空中……需要滑翔翼才能穿过它们。`));else{this.activeCourse=e,e.next=0,e.time=e.limit;for(let t of e.rings)t.passed=!1,t.mesh.visible=!0,t.mesh.material.color.set(10482687),t.prevSide=null;t.audio.play(`ring`),t.audio.setMood(`tense`),t.hud.toast(Y(`在时间内按顺序穿过所有光环！`))}}_endCourse(e){let t=this.g,n=this.activeCourse;this.activeCourse=null,t.hud.setRace(null),t.audio.setMood(t.moodNow());for(let e of n.rings)e.mesh.visible=!1;if(e){t.audio.play(`fanfare`);let e=n.rings[n.rings.length-1];t.collect.awardShard(n.id,e)||t.hud.banner(Y(`挑战成功！`),``)}else t.audio.play(`fail`),t.hud.toast(Y(`时间到了……回到风铃柱再试一次吧。`))}_updateCourse(e){let t=this.activeCourse;if(!t)return;let n=this.g,r=n.player.pos;t.time-=e,n.hud.setRace(`${t.name} · ${t.next}/${t.rings.length}`,t.time.toFixed(1));let i=t.rings[t.next],a=r.x-i.x,o=r.y+.9-i.y,s=r.z-i.z,c=a*t.ux+s*t.uz,l=Math.hypot(a-c*t.ux,o,s-c*t.uz);if(i.prevSide!==null&&i.prevSide<0&&c>=0&&l<3.4&&(i.passed=!0,i.mesh.material.color.set(16769126),n.audio.play(`ring`),n.fx.emit(i.x,i.y,i.z,30,{color:10482687,speed:5,gravity:0}),t.next++,t.next>=t.rings.length))this._endCourse(!0);else{i.prevSide=c;for(let n of t.rings)n.mesh.visible&&(n.mesh.rotation.z+=e*(n===i?1.5:.3));t.time<=0&&this._endCourse(!1)}}_buildBoxPuzzle(){let e=this.g,t=e.world.anchors.ruins,n=2.4,r=(e,r)=>({x:t.x+(e-2.5)*n,z:t.z+(r-2.5)*n}),i=this.puzzle={CELL:n,N:6,cell:r,boxes:[],plates:[[4,1],[1,4]],walls:[[3,1],[1,3]],solved:!!e.state.flag(`ruins_solved`)},a=t.y;for(let[t,o]of i.walls){let i=r(t,o),s=new q(Q([Z(n_(n,1.2,n),10787980,{y:.6,jitter:.05,seed:t*7+o})]),$f);s.position.set(i.x,a,i.z),s.castShadow=s.receiveShadow=!0,e.scene.add(s),e.world.colliders.addBox(i.x,i.z,n/2,n/2,a,a+1.2,0,{walkable:!0})}i.plateMeshes=i.plates.map(([t,n])=>{let i=r(t,n),o=new q(Q([Z(e_(1,1,.12,12),16777215,{y:.06})]),new Wo({color:9417673,emissive:4169983,emissiveIntensity:.1}));return o.position.set(i.x,a,i.z),e.scene.add(o),o});let o=i.solved?i.plates:[[2,2],[3,3]];for(let[t,n]of o){let o=r(t,n),s=new q(Q([Z(n_(2,1.6,2),13218954,{y:.8}),Z(n_(2.06,.14,2.06),9076596,{y:1.55}),Z(n_(.7,.7,2.08),14262330,{y:.8})]),$f);s.position.set(o.x,a,o.z),s.castShadow=s.receiveShadow=!0,e.scene.add(s);let c=e.world.colliders.addBox(o.x,o.z,1,1,a,a+1.6,0,{walkable:!0,dynamic:!0});i.boxes.push({i:t,j:n,mesh:s,col:c,start:[t,n],anim:null,push:0})}i.y0=a,e.interact.add({pos:{x:t.altar.x,y:t.altar.y-1,z:t.altar.z+1.6},radius:2.6,label:()=>i.solved?null:Y(`重置石箱`),action:async()=>{this._resetBoxes(),e.audio.play(`push`),e.hud.toast(Y(`石箱回到了原位。`))}}),this._checkPlates(!0)}_resetBoxes(){let e=this.puzzle;for(let t of e.boxes){[t.i,t.j]=t.start;let n=e.cell(t.i,t.j);t.mesh.position.x=t.col.x=n.x,t.mesh.position.z=t.col.z=n.z,t.anim=null}this._checkPlates(!0)}_checkPlates(e){let t=this.puzzle,n=this.g,r=!0;t.plates.forEach(([i,a],o)=>{let s=t.boxes.some(e=>e.i===i&&e.j===a),c=t.plateMeshes[o].material;s&&c.emissiveIntensity<1&&!e&&n.audio.play(`plate`),c.emissiveIntensity=s?1.6:.1,r&&=s}),r&&!t.solved&&(t.solved=!0,n.state.flag(`ruins_solved`,!0),n.audio.play(`fanfare`),n.hud.toast(Y(`遗迹的祭坛亮了起来！`)),n.collect.spawnShard(`ruins_puzzle`,n.world.anchors.ruinsAltar))}_updateBoxes(e){let t=this.puzzle,n=this.g,r=n.player;if(t.solved)return;let i=r.pos;if(!(Math.hypot(i.x-n.world.anchors.ruins.x,i.z-n.world.anchors.ruins.z)>16))for(let a of t.boxes){if(a.anim){a.anim.t+=e/.3;let t=Math.min(1,a.anim.t),n=a.anim.fx+(a.anim.tx-a.anim.fx)*t,r=a.anim.fz+(a.anim.tz-a.anim.fz)*t;a.mesh.position.x=a.col.x=n,a.mesh.position.z=a.col.z=r,t>=1&&(a.anim=null,this._checkPlates(!1));continue}if(r.mode!==`ground`||Math.abs(i.y-t.y0)>.6){a.push=0;continue}let o=r.vel.x,s=r.vel.z;if(Math.hypot(o,s)<1.5){a.push=0;continue}let c=a.mesh.position.x-i.x,l=a.mesh.position.z-i.z,u=0,d=0;if(Math.abs(o)>Math.abs(s)*1.5&&Math.abs(l)<.9&&Math.abs(c)<1.6&&Math.sign(c)===Math.sign(o)?u=Math.sign(o):Math.abs(s)>Math.abs(o)*1.5&&Math.abs(c)<.9&&Math.abs(l)<1.6&&Math.sign(l)===Math.sign(s)&&(d=Math.sign(s)),!u&&!d){a.push=0;continue}if(a.push+=e,a.push<.3)continue;a.push=0;let f=a.i+u,p=a.j+d;if(f<0||p<0||f>=t.N||p>=t.N||t.walls.some(([e,t])=>e===f&&t===p)||t.boxes.some(e=>e!==a&&e.i===f&&e.j===p))continue;let m=t.cell(a.i,a.j),h=t.cell(f,p);a.i=f,a.j=p,a.anim={t:0,fx:m.x,fz:m.z,tx:h.x,tz:h.z},n.audio.play(`push`),n.fx.emit(m.x,t.y0+.2,m.z,10,{color:13218954,speed:2,size:.5,gravity:1})}}_buildMirrors(){let e=this.g,t=Bd,n=Jd,r=(e,t,n,r)=>({id:e,kind:r,...a_(t,n,0)}),i=[{id:`mirror1`,nodes:[r(`S`,t.x,t.z+62,`source`),r(`A`,n[2].x,n[2].z,`mirror`),r(`B`,n[3].x,n[3].z,`mirror`),r(`T`,t.x-64,t.z+4,`target`)],src:`A`,opts:{A:[`B`,`D:north`,`D:east`,`D:west`],B:[`D:south`,`T`,`A`,`D:north`]}},{id:`mirror2`,nodes:[r(`S`,t.x-4,t.z-63,`source`),r(`C`,n[0].x,n[0].z,`mirror`),r(`D`,n[1].x,n[1].z,`mirror`),r(`E`,t.x+64,t.z-2,`mirror`),r(`T`,t.x+46,t.z+44,`target`)],src:`C`,opts:{C:[`D:west`,`D`,`D:south`,`D:north`],D:[`C`,`D:south`,`E`,`D:north`],E:[`D:north`,`D`,`D:east`,`T`]}}];this.mirrorSets=[];let a=new ii({color:16773544,transparent:!0,opacity:.75,blending:2,depthWrite:!1});for(let t of i){let n=e.state.has(`shards`,t.id)||e.state.flag(t.id+`_solved`),r={...t,sel:{},beams:[],solved:n},i=e=>r.nodes.find(t=>t.id===e);for(let t of r.nodes){t.headY=t.y+1.8;let i;if(t.kind===`source`)i=new q(Q([Z(e_(.5,.7,1.2,6),10195850,{y:.6}),Z(r_(.45),16773544,{y:1.8})]),ep(16767050,.9));else if(t.kind===`target`)i=new q(Q([Z(e_(.5,.7,1.2,6),10195850,{y:.6}),Z(r_(.6,1),11832575,{y:1.9})]),ep(10120191,n?2:.1));else{i=new G;let a=new q(Q([Z(e_(.15,.4,1.4,6),8017206,{y:.7})]),$f),o=new q(Q([Z(e_(.75,.75,.08,16),14674418,{rx:Math.PI/2}),Z(e_(.85,.85,.06,16),13215050,{rx:Math.PI/2,z:-.05})]),new Wo({vertexColors:!0,metalness:.6,roughness:.2}));o.position.y=1.8,i.add(a,o),t.disc=o,r.sel[t.id]=n?r.opts[t.id].findIndex(e=>!e.startsWith(`D:`)&&this._isSolution(r,t.id,e)):0,r.sel[t.id]<0&&(r.sel[t.id]=0),e.interact.add({pos:{x:t.x,y:t.y,z:t.z},radius:2.4,label:()=>r.solved?null:Y(`转动镜子`),action:async()=>{r.sel[t.id]=(r.sel[t.id]+1)%r.opts[t.id].length,e.audio.play(`mirror`),this._traceMirrors(r)}})}i.position.set(t.x,t.y,t.z),i.traverse?.(e=>{e.castShadow=!0}),e.scene.add(i),t.mesh=i,e.world.colliders.addCylinder(t.x,t.z,.5,t.y,t.y+2.2)}for(let t=0;t<8;t++){let t=new q(new oa(.09,.09,1,6,1,!0).rotateX(Math.PI/2),a);t.visible=!1,e.scene.add(t),r.beams.push(t)}r.byId=i,this.mirrorSets.push(r),this._traceMirrors(r,!0)}}_isSolution(e,t,n){return{mirror1:{A:`B`,B:`T`},mirror2:{C:`D`,D:`E`,E:`T`}}[e.id][t]===n}_dirOf(e,t,n){if(n.startsWith(`D:`)){let e={north:[0,-1],south:[0,1],east:[1,0],west:[-1,0]}[n.slice(2)];return{dx:e[0],dz:e[1],to:null}}let r=e.byId(n),i=r.x-t.x,a=r.z-t.z,o=Math.hypot(i,a);return{dx:i/o,dz:a/o,to:r}}_traceMirrors(e,t=!1){let n=this.g,r=e.nodes.find(e=>e.kind===`source`),i=e.byId(e.src),a=0,o=new Set,s=!1,c=(t,n,r,i)=>{let o=e.beams[a++];if(!o)return;let s=t.x,c=t.headY,l=t.z,u=Math.hypot(n-s,r-c,i-l);o.visible=!0,o.position.set((s+n)/2,(c+r)/2,(l+i)/2),o.scale.set(1,1,u),o.lookAt(n,r,i)};for(let t=0;t<8&&i;t++){if(c(r,i.x,i.headY,i.z),i.kind===`target`){s=!0;break}if(o.has(i.id))break;o.add(i.id);let t=e.opts[i.id][e.sel[i.id]],n=this._dirOf(e,i,t);if(i.disc&&(i.disc.rotation.y=Math.atan2(n.dx,n.dz)+(r?Math.atan2(r.x-i.x,r.z-i.z)-Math.atan2(n.dx,n.dz):0)/2),!n.to){c(i,i.x+n.dx*45,i.headY,i.z+n.dz*45);break}r=i,i=n.to}for(let t=a;t<e.beams.length;t++)e.beams[t].visible=!1;let l=e.nodes.find(e=>e.kind===`target`);l.mesh.material.emissiveIntensity=s?2.2:.1,s&&!e.solved&&(e.solved=!0,n.state.flag(e.id+`_solved`,!0),t||(n.audio.play(`fanfare`),n.hud.toast(Y(`光束点亮了水晶！`)),this.g.collect.awardShard(e.id,{x:l.x,y:l.y+2,z:l.z})))}_buildPedestals(){let e=this.g,t={swan:Y(`天鹅座`),hunter:Y(`猎户座`),dipper:Y(`北斗七星`)},n=[`swan`,`hunter`,`dipper`];this.ped={seq:[],list:[]};for(let r of e.content.pedestals){let i=X(r.x,r.z),a=new q(Q([Z(r_(.45,0),14674431,{y:1.75})]),ep(9419007,.1)),o=new q(Q([Z(e_(.8,1,1.3,8),10195850,{y:.65}),Z(e_(.9,.9,.15,8),8024680,{y:1.35})]),$f);o.castShadow=!0;let s=new q(new oa(.25,.25,120,8,1,!0),new ii({color:12572927,transparent:!0,opacity:.35,blending:2,depthWrite:!1}));s.position.y=62,s.visible=!1;let c=new G;c.add(o,a,s),c.position.set(r.x,i,r.z),e.scene.add(c),e.world.colliders.addCylinder(r.x,r.z,.9,i,i+1.4,{walkable:!0});let l={...r,y:i,top:a,beam:s,on:!1};this.ped.list.push(l),e.interact.add({pos:{x:r.x,y:i,z:r.z},radius:2.4,label:()=>e.state.has(`shards`,`stars`)?null:Y(`触摸石台（{0}）`,[t[r.id]]),action:async()=>{if(e.sky.night<.5){e.hud.toast(Y(`石台上刻着{0}。白天它没有任何反应。`,[t[r.id]]));return}if(l.on)return;let i=n[this.ped.seq.length];if(r.id!==i){e.audio.play(`fail`),e.hud.toast(Y(`星光熄灭了……顺序好像不对。`)),this.ped.seq=[];for(let e of this.ped.list)e.on=!1,e.top.material.emissiveIntensity=.1,e.beam.visible=!1}else if(l.on=!0,this.ped.seq.push(r.id),l.top.material.emissiveIntensity=2.4,l.beam.visible=!0,e.audio.play(`star`),this.ped.seq.length===3){e.hud.toast(Y(`三道星光连成了一线！`));let t=e.content.observatory;await e.wait(.8),e.collect.awardShard(`stars`,{x:t.x,y:X(t.x,t.z)+9,z:t.z})}}})}}_buildFox(){let e=this.g,t=e.content.foxTrail;this.fox={obj:Sg(`spiritfox`),i:0,moving:!1,done:!!e.state.flag(`fox_done`),t:0};let n=this.fox;n.obj.position.set(t[0].x,t[0].y,t[0].z),n.obj.visible=!n.done,e.scene.add(n.obj),e.codexLive.push({id:`spiritfox`,obj:n.obj})}_updateFox(e,t){let n=this.fox,r=this.g;if(n.done)return;let i=r.content.foxTrail,a=r.player.pos,o=n.obj;if(Math.random()<e*6&&r.fx.emit(o.position.x,o.position.y+.6,o.position.z,1,{color:10479359,speed:.5,gravity:-.5,size:.3}),!n.moving){if(o.position.y=X(o.position.x,o.position.z),Math.hypot(a.x-o.position.x,a.z-o.position.z)<7){if(n.i>=i.length-1){n.done=!0,r.state.flag(`fox_done`,!0),r.fx.emit(o.position.x,o.position.y+.5,o.position.z,40,{color:10479359,speed:4}),o.visible=!1,r.hud.toast(Y(`星光狐消失了，它留下了什么东西……`)),r.collect.spawnShard(`fox`,{x:o.position.x,y:o.position.y+1.3,z:o.position.z});return}n.moving=!0,n.i++}else o.rotation.y=Cd(o.rotation.y,Math.atan2(a.x-o.position.x,a.z-o.position.z),e*3);return}let s=i[n.i],c=s.x-o.position.x,l=s.z-o.position.z,u=Math.hypot(c,l);if(u<.5){n.moving=!1;return}let d=8.5*e;o.position.x+=c/u*Math.min(d,u),o.position.z+=l/u*Math.min(d,u),o.position.y=X(o.position.x,o.position.z),o.rotation.y=Math.atan2(c,l);for(let[e,n]of(o.userData.legs||[]).entries())n.rotation.x=Math.sin(t*18+e*Math.PI)*.7}_buildSheep(){let e=this.g,t=e.state.quest(`mia`);t.penned=t.penned||[];let n=e.content.pen;this.sheep=e.content.lostSheep.map((r,i)=>{let a=Sg(`sheep`),o=t.penned.includes(i),s=i*2.1,c=o?{x:n.x+Math.cos(s)*3,z:n.z+Math.sin(s)*3}:{x:r.x,z:r.z};a.position.set(c.x,X(c.x,c.z),c.z),e.scene.add(a);let l={i,obj:a,penned:o,following:!1,home:c};return e.interact.add({pos:a.position,radius:2.4,label:()=>l.penned||l.following?null:Y(`带上走失的羊`),action:async()=>{l.following=!0,e.audio.play(`sheep`),e.hud.toast(Y(`羊跟在你身后了，把它带回米娅的羊圈吧。`))}}),l})}_updateSheep(e,t){let n=this.g,r=n.player.pos,i=n.content.pen,a=0;for(let o of this.sheep){let s=o.obj;if(o.following){a++;let c=2.5+a*1.6,l=r.x-Math.sin(n.player.yaw)*c,u=r.z-Math.cos(n.player.yaw)*c,d=l-s.position.x,f=u-s.position.z,p=Math.hypot(d,f);if(p>45)s.position.x=l,s.position.z=u;else if(p>.6){let n=Math.min(p*2.2,11)*e;s.position.x+=d/p*n,s.position.z+=f/p*n,s.rotation.y=Cd(s.rotation.y,Math.atan2(d,f),e*6);for(let[e,n]of(s.userData.legs||[]).entries())n.rotation.x=Math.sin(t*14+e*Math.PI)*.6}if(s.position.y=Math.max(X(s.position.x,s.position.z),0),Math.hypot(s.position.x-i.x,s.position.z-i.z)<i.r-1){o.following=!1,o.penned=!0;let e=n.state.quest(`mia`);e.penned.includes(o.i)||e.penned.push(o.i),n.audio.play(`sheep`),n.hud.toast(Y(`羊回到了羊圈（{0}/3）`,[e.penned.length])),e.penned.length===3&&n.hud.toast(Y(`三只羊都回来了！去告诉米娅吧。`),4e3),n.state.save()}}else o.penned&&(s.rotation.y+=Math.sin(t*.5+o.i)*e*.5)}}startRace(e){this.pendingRace=e}async _runRace(e){let t=this.g;t.world.anchors.arch;let n={x:e.pos.x,z:e.pos.z};t.player,this.race={npc:e,start:n,t:0,phase:`count`},t.audio.setMood(`tense`);for(let e of[`3`,`2`,`1`])t.hud.banner(e,Y(`目标：红石拱门`),900),t.audio.play(`tick`),await t.wait(1);t.hud.banner(Y(`出发！`),``,800),t.audio.play(`go`),this.race.phase=`run`,this.race.t=0}_updateRace(e,t){let n=this.race,r=this.g;if(!n){if(this.pendingRace&&!r.busy()){let e=this.pendingRace;this.pendingRace=null,this._runRace(e)}return}if(n.phase!==`run`)return;n.t+=e;let i=r.world.anchors.arch,a=n.npc;r.hud.setRace(Y(`峡谷赛跑`),n.t.toFixed(1));let o=i.x-a.pos.x,s=i.z-a.pos.z,c=Math.hypot(o,s),l=9*e;c>2&&(a.pos.x+=o/c*l,a.pos.z+=s/c*l,a.pos.y=Math.max(0,X(a.pos.x,a.pos.z)),a.override=`walk`,a.animSpeed=9,a.ch.root.rotation.y=Math.atan2(o,s));let u=Math.hypot(i.x-r.player.pos.x,i.z-r.player.pos.z),d=async e=>{n.phase=`done`,r.hud.setRace(null),r.audio.setMood(r.moodNow()),a.animSpeed=0,a.override=e?`idle`:`cheer`,e?(r.audio.play(`fanfare`),r.hud.toast(Y(`你赢了！用时 {0} 秒`,[n.t.toFixed(1)])),r.collect.awardShard(`race`,r.player.pos)&&(r.state.add(`hats`,`cap`),setTimeout(()=>r.hud.toast(Y(`跳跳把他的跑步帽送给了你！`)),2500))):(r.audio.play(`fail`),r.hud.toast(Y(`跳跳：「哈哈，我赢啦！不服再来！」`))),await r.wait(3);let t=n.start;a.pos.set(t.x,X(t.x,t.z),t.z),a.override=null,this.race=null};u<7?d(!0):c<3&&d(!1)}busy(){return!!(this.race&&this.race.phase===`count`)}update(e,t){this._updateCourse(e),this._updateBoxes(e),this._updateFox(e,t),this._updateSheep(e,t),this._updateRace(e,t);for(let t of this.drafts)t.mesh.rotation.y+=e*1.5,Math.random()<e*10&&this.g.fx.emit(t.x+(Math.random()-.5)*t.r*1.6,t.base+Math.random()*3,t.z+(Math.random()-.5)*t.r*1.6,1,{color:16777215,speed:.3,gravity:-9,size:.35,life:1.6})}},s_=e=>document.querySelector(e),c_=class{constructor(e){this.g=e,this.active=!1,this.ui=s_(`#fishing`),this.spots=e.content.fishing.map(t=>{let n=t.anchor?ah(t,e.world.anchors):t,r=n.kind===`lake`?14:0,i=new q(new jo(.6,.9,24).rotateX(-Math.PI/2),new ii({color:16777215,transparent:!0,opacity:.6,depthWrite:!1}));i.position.set(n.x,r+.12,n.z),e.scene.add(i);let a={...n,level:r,rip:i};return e.interact.add({pos:{x:n.x,y:r,z:n.z},radius:8,height:6,priority:1,label:()=>e.state.data.abilities.rod&&e.player.mode===`ground`?Y(`钓鱼`):null,action:()=>this.fish(a)}),a});let t=new Dr().setFromPoints([new U,new U]);this.line=new Bi(t,new Mi({color:16777215})),this.line.visible=!1,this.bobber=new q(new Mo(.15,8,6),new Wo({color:14697786})),this.bobber.visible=!1,e.scene.add(this.line,this.bobber)}update(e,t){for(let e of this.spots){let n=(t*.6+e.x)%1;e.rip.scale.setScalar(1+n*2.5),e.rip.material.opacity=.6*(1-n)}if(this.line.visible){let e=new U;this.g.player.char.rod.children[0].localToWorld(e.set(0,2.3,0));let t=this.line.geometry.attributes.position;t.setXYZ(0,e.x,e.y,e.z),t.setXYZ(1,this.bobber.position.x,this.bobber.position.y,this.bobber.position.z),t.needsUpdate=!0}}pick(e){let t=this.g.sky.night>.5,n=eh[e].filter(e=>!e.night||t),r=n.reduce((e,t)=>e+t.w,0),i=Math.random()*r;for(let e of n)if(i-=e.w,i<=0)return e;return n[0]}async fish(e){let t=this.g,n=t.player;this.active=!0,n.frozen=!0,n.animOverride=`fish`,n.yaw=Math.atan2(e.x-n.pos.x,e.z-n.pos.z),n.char.rod.visible=!0,this.bobber.position.set(e.x+(Math.random()-.5)*2,e.level+.1,e.z+(Math.random()-.5)*2),this.bobber.visible=!0,this.line.visible=!0,t.audio.play(`splash`),this.ui.hidden=!1,s_(`.bar`,this.ui).hidden=!0,s_(`.fish-title`,this.ui).textContent=Y(`等待鱼儿上钩……`),s_(`.fish-hint`,this.ui).textContent=Y(`按 E 收竿`);let r=`cancel`;try{let n=1.8+Math.random()*3.5,i=0;for(;i<n;){let n=await t.frame();if(i+=n,this.bobber.position.y=e.level+.1+Math.sin(i*3)*.05,t.input.hit(`KeyE`,`Escape`))throw Error(`cancel`)}t.audio.play(`bite`),s_(`.fish-title`,this.ui).textContent=Y(`！！！ 咬钩了！`),s_(`.fish-hint`,this.ui).textContent=Y(`快按 E！`),this.bobber.position.y=e.level-.2,i=0;let a=!1;for(;i<1.1;){let e=await t.frame();if(i+=e,t.input.hit(`KeyE`,`Space`)){a=!0;break}}if(!a)throw r=`miss`,Error(`miss`);let o=this.pick(e.kind);if(!await this.minigame(o))throw r=`escape`,Error(`escape`);r=`catch`,this.caught(o)}catch{r===`miss`&&t.hud.toast(Y(`鱼跑掉了……下次要快一点按 E。`)),r===`escape`&&(t.audio.play(`fail`),t.hud.toast(Y(`线断了，鱼逃走了！`)))}this.ui.hidden=!0,this.bobber.visible=!1,this.line.visible=!1,n.char.rod.visible=!1,n.animOverride=null,n.frozen=!1,this.active=!1}async minigame(e){let t=this.g,n=s_(`.bar`,this.ui),r=s_(`.zone`,this.ui),i=s_(`.cursor`,this.ui);n.hidden=!1,s_(`.fish-title`,this.ui).textContent=Y(`收线！`);let a=0,o=0,s=.42-e.diff*.38,c=.8+e.diff*1.6,l=0,u=1,d=Math.random()*(1-s),f=()=>{r.style.left=d*100+`%`,r.style.width=s*100+`%`,s_(`.fish-hint`,this.ui).textContent=Y(`指针在绿色区域时按 E · 成功 {0}/3 · 失误 {1}/2`,[a,o])};for(f();a<3&&o<2;){let e=await t.frame();l+=u*c*e*(1+a*.25),l>1?(l=1,u=-1):l<0&&(l=0,u=1),i.style.left=`calc(${l*100}% - 3px)`,this.mg={x:l,dir:u,zx:d,width:s,speed:c*(1+a*.25)},t.input.hit(`KeyE`,`Space`)&&(l>=d&&l<=d+s?(a++,t.audio.play(`reel`,a),d=Math.random()*(1-s)):(o++,t.audio.play(`exhausted`)),f())}return this.mg=null,a>=3}caught(e){let t=this.g,n=t.state.data,r=$m.find(t=>t.id===e.id);n.items.fish[e.id]=(n.items.fish[e.id]||0)+1;let i=t.state.add(`codex`,e.id);t.audio.play(`fanfare`),t.hud.banner(Y(`钓到了 {0}！`,[r.name]),i?Y(`图鉴新增一条`):r.desc,3e3),t.fx.emit(this.bobber.position.x,this.bobber.position.y+.5,this.bobber.position.z,30,{color:10474495,speed:4,gravity:6}),e.id===`golden`&&setTimeout(()=>{t.hud.toast(Y(`金鳞鱼的嘴里衔着一颗星屑！`)),t.collect.awardShard(`golden_fish`)},1800),t.state.save()}},l_=e=>document.querySelector(e),u_=class{constructor(e){this.g=e,this.active=!1,this.vf=l_(`#viewfinder`),this.flash=l_(`#flash`),this._v=new U}toggle(){let e=this.g;e.state.data.abilities.camera&&(this.active=!this.active,e.cam.photo=this.active,this.vf.hidden=!this.active,e.player.frozen=this.active,e.player.char.root.visible=!this.active,e.hud.setPrompt(null),e.audio.play(this.active?`open`:`close`))}update(){let e=this.g;this.active&&(e.input.hit(`KeyC`,`Escape`)?this.toggle():(e.input.clicked||e.input.hit(`Space`))&&this.snap())}visible(e,t,n,r){let i=this.g.camera,a=this._v.set(e,t,n).sub(i.position),o=a.length();if(o>r||o<.5)return!1;a.normalize();let s=new U;if(i.getWorldDirection(s),Math.acos(Math.min(1,a.dot(s)))>Et.degToRad(i.fov/2)*.85)return!1;let c=Math.ceil(o/2);for(let r=1;r<c;r++){let a=r/c,o=i.position.x+(e-i.position.x)*a,s=i.position.y+(t-i.position.y)*a;if(X(o,i.position.z+(n-i.position.z)*a)>s+.3)return!1}let l=60/i.fov;return o<r*Math.min(1.6,.55+l*.45)}snap(){let e=this.g,t=e.state.data;e.audio.play(`shutter`),this.flash.style.transition=`none`,this.flash.style.opacity=.85,requestAnimationFrame(()=>{this.flash.style.transition=`opacity .35s`,this.flash.style.opacity=0});let n=new Set;for(let t of e.world.codexSpots)!n.has(t.id)&&this.visible(t.x,t.y,t.z,t.big?220:40)&&n.add(t.id);for(let t of e.codexLive){if(n.has(t.id)||!t.obj.visible)continue;let e=t.obj.position;this.visible(e.x,e.y+(t.dy??.6),e.z,t.range||35)&&n.add(t.id)}let r=[...n].filter(e=>!t.codex.includes(e));for(let t of r)e.state.add(`codex`,t);if(r.length){e.audio.play(`feather`);let n=r.map(e=>$m.find(t=>t.id===e)?.name||e).join(Y(`、`));e.hud.toast(Y(`图鉴新增：{0}（{1}/{2}）`,[n,t.codex.length,$m.length]),3500),e.state.save()}else n.size?e.hud.toast(Y(`这些都已经登记过了。`)):e.hud.toast(Y(`没拍到什么特别的东西。靠近一点，对准目标试试。`))}},d_=gd(2024),f_={sheep:{name:Y(`绵羊`),hp:30,radius:.6,height:1.3},deer:{name:Y(`小鹿`),hp:45,radius:.6,height:2.2},fox:{name:Y(`狐狸`),hp:35,radius:.5,height:1.1},goat:{name:Y(`山羊`),hp:50,radius:.55,height:1.5},crab:{name:Y(`螃蟹`),hp:15,radius:.45,height:.5},frog:{name:Y(`青蛙`),hp:10,radius:.3,height:.4},lizard:{name:Y(`蜥蜴`),hp:12,radius:.3,height:.3}},p_={sheep:{wander:10,speed:.9},deer:{flee:14,speed:1.6,wander:18},fox:{flee:9,speed:2.4,wander:20},goat:{wander:8,speed:1},crab:{mode:`crab`,speed:1.2,wander:5},frog:{mode:`hop`,wander:4,speed:1.2},lizard:{mode:`dart`,wander:6,speed:3}};function m_(e,t,n,r,i=60){for(let a=0;a<i;a++){let i=d_()*Math.PI*2,a=Math.sqrt(d_())*n,o=e+Math.cos(i)*a,s=t+Math.sin(i)*a;if(r(o,s,X(o,s)))return{x:o,z:s}}return null}var h_=class{constructor(e){this.g=e,this.list=[];let t=(e,t,n)=>n>If(e,t)+.6,n=(n,r,i,a,o,s={})=>{for(let c=0;c<r;c++){let r=m_(i,a,o,s.ok||t);if(!r)continue;let c=Sg(n);c.position.set(r.x,X(r.x,r.z),r.z),c.rotation.y=d_()*6.28,e.scene.add(c),this._make(n,c,r,s)}},r=e.content.pen;n(`sheep`,4,r.x,r.z,4,{wander:3.5,speed:.8}),n(`sheep`,6,-40,70,30,{wander:10,speed:.9}),n(`deer`,5,-190,60,60,{flee:14,speed:1.6,wander:18,ok:(e,n,r)=>t(e,n,r)&&Math.hypot(e-Vd.x,n-Vd.z)>Vd.r}),n(`fox`,3,-160,-20,50,{flee:9,speed:2.4,wander:20}),n(`crab`,6,205,235,40,{mode:`crab`,speed:1.2,wander:5,ok:(e,t,n)=>n>.3&&n<2.2}),n(`crab`,4,-20,320,40,{mode:`crab`,speed:1.2,wander:5,ok:(e,t,n)=>n>.3&&n<2.2}),n(`seagull`,4,230,260,30,{mode:`circle`,ok:()=>!0,range:45}),n(`seagull`,2,-10,330,20,{mode:`circle`,ok:()=>!0,range:45}),n(`butterfly`,10,0,110,70,{mode:`flutter`,when:`day`,range:18,dy:0}),n(`owl`,3,-230,30,70,{mode:`perch`,when:`night`,ok:(e,n,r)=>t(e,n,r)&&ff(e,n).forest>.6,range:40}),n(`frog`,5,Bd.x,Bd.z,Bd.r+8,{mode:`hop`,when:`rain`,ok:(e,t,n)=>n>14.2&&n<16,wander:4,range:20,dy:.1}),n(`goat`,5,Hd.x,Hd.z,110,{wander:6,speed:1,ok:(e,t,n)=>n>20&&n<70}),n(`lizard`,5,Rd.canyon.x,Rd.canyon.z,90,{mode:`dart`,wander:6,speed:3,ok:(e,n,r)=>t(e,n,r)&&ff(e,n).canyon>.6,range:18,dy:.1});let i=Sg(`whale`);i.position.set(400,-6,120),e.scene.add(i),this.whale={obj:i,t:0,cycle:40},e.codexLive.push({id:`whale`,obj:i,range:200,dy:1}),this.swarms=[];let a=new Dr,o=[];for(let e=0;e<30;e++)o.push((d_()-.5)*6,d_()*3+.5,(d_()-.5)*6);a.setAttribute(`position`,new hr(o,3));let s=new Gi({color:14286714,size:.25,transparent:!0,opacity:.9,blending:2,depthWrite:!1});for(let[t,n]of[[-280,10],[-292,18],[-250,-10],[-225,40],[-200,70],[-300,-30]]){let r=new Xi(a,s);r.position.set(t,X(t,n),n),e.scene.add(r),this.swarms.push(r),e.codexLive.push({id:`firefly`,obj:r,range:25,dy:1.5})}}_make(e,t,n,r){let i={kind:e,obj:t,home:{x:n.x,z:n.z},r:r.wander??12,speed:r.speed??1.5,t:d_()*5,target:null,mode:r.mode||`wander`,when:r.when,phase:d_()*10,flee:r.flee},a=f_[e];return a&&i.mode!==`perch`&&(Object.assign(i,{name:a.name,maxHp:a.hp,hp:a.hp,radius:a.radius,height:a.height,level:1,hostile:!1,alive:!0,targetable:!0,fleeT:0,lastHit:-99,kx:0,kz:0}),i.onHit=(e,t,n)=>this._hit(i,e,t,n)),i.codex={id:r.codex||e,obj:t,range:r.range,dy:r.dy},this.list.push(i),this.g.codexLive.push(i.codex),i}spawnWild(e,t,n,r){let i=X(t,n);if(i<If(t,n)+.4)return null;let a=Sg(e);a.position.set(t,i,n),a.rotation.y=d_()*6.28,this.g.scene.add(a);let o=this._make(e,a,{x:t,z:n},p_[e]||{});return o.tag=r,o}despawnTag(e){for(let t=this.list.length-1;t>=0;t--){let n=this.list[t];if(n.tag!==e)continue;this.g.scene.remove(n.obj);let r=this.g.codexLive.indexOf(n.codex);r>=0&&this.g.codexLive.splice(r,1),this.list.splice(t,1)}}targets(){let e=[];for(let t of this.list)t.targetable&&t.alive&&t.obj.visible&&e.push(t);return e}_hit(e,t,n,r){let i=this.g;if(e.hp-=t,e.lastHit=i.clock,e.fleeT=6,e.kx+=n.x*(r.knock??5)*1.3,e.kz+=n.z*(r.knock??5)*1.3,e.kind===`sheep`&&i.audio.play(`sheep`),e.hp<=0){e.alive=!1,e.obj.visible=!1,e.respawnT=e.tag?1/0:45;let t=e.obj.position;i.fx.emit(t.x,t.y+e.height*.5,t.z,40,{color:16773800,speed:4,gravity:-2.5,size:.4,life:1.3}),i.fx.emit(t.x,t.y+e.height*.5,t.z,16,{color:16777215,speed:2,gravity:-4,size:.6,life:1})}}update(e,t){let n=this.g,r=n.player.pos,i=n.sky.night>.5,a=n.sky.rain>.4;for(let o of this.list){let s=o.obj;if(o.targetable&&!o.alive){if(o.respawnT-=e,o.respawnT<=0)o.alive=!0,o.hp=o.maxHp,o.fleeT=0,s.position.set(o.home.x,X(o.home.x,o.home.z),o.home.z);else{s.visible=!1;continue}}let c=o.when===`day`?!i&&!a:o.when===`night`?i:o.when!==`rain`||a;if(s.visible=c,!c)continue;let l=Math.hypot(r.x-s.position.x,r.z-s.position.z);if(l>220)continue;o.t-=e;let u=s.userData.legs||[];switch(o.mode){case`circle`:{o.phase+=e*.4;let n=14+Math.sin(o.phase*.3)*4;s.position.set(o.home.x+Math.cos(o.phase)*n,14+Math.sin(o.phase*.7)*3,o.home.z+Math.sin(o.phase)*n),s.rotation.y=-o.phase,s.rotation.z=.3,u.forEach((e,n)=>{e.rotation.z=Math.sin(t*8)*.5*(n?-1:1)});continue}case`flutter`:o.phase+=e,s.position.set(o.home.x+Math.sin(o.phase*.7)*4,X(o.home.x,o.home.z)+1.2+Math.sin(o.phase*2.3)*.6,o.home.z+Math.cos(o.phase*.5)*4),s.rotation.y=o.phase,u.forEach((e,n)=>{e.rotation.z=Math.sin(t*25+o.phase)*.9*(n?-1:1)});continue;case`perch`:s.position.y=X(o.home.x,o.home.z)+4.5,s.rotation.y=Cd(s.rotation.y,Math.atan2(r.x-s.position.x,r.z-s.position.z),e);continue}let d=o.speed;if(o.targetable){if(o.fleeT>0&&(o.fleeT-=e),Math.abs(o.kx)+Math.abs(o.kz)>.05){let t=s.position.x+o.kx*e,n=s.position.z+o.kz*e;X(t,n)>If(t,n)+.1&&(s.position.x=t,s.position.z=n),o.kx*=Math.max(0,1-e*6),o.kz*=Math.max(0,1-e*6)}o.hp<o.maxHp&&o.fleeT<=0&&n.clock-o.lastHit>20&&(o.hp=o.maxHp)}if(o.flee&&l<o.flee||o.fleeT>0){let e=s.position.x-r.x,t=s.position.z-r.z,n=Math.hypot(e,t)||1;o.target={x:s.position.x+e/n*10,z:s.position.z+t/n*10},d=Math.max(o.speed*4,o.fleeT>0?5.5:0),o.t=2}else if(o.t<=0||!o.target){if(o.t=2+d_()*5,d_()<.5)o.target=null;else{let e=d_()*6.28,t=d_()*o.r;o.target={x:o.home.x+Math.cos(e)*t,z:o.home.z+Math.sin(e)*t}}}let f=!1;if(o.target){let t=o.target.x-s.position.x,n=o.target.z-s.position.z,r=Math.hypot(t,n);if(r>.3){let i=s.position.x+t/r*d*e,a=s.position.z+n/r*d*e;if(X(i,a)>If(i,a)+.2||o.mode===`crab`){s.position.x=i,s.position.z=a,f=!0;let r=Math.atan2(t,n)+(o.mode===`crab`?Math.PI/2:0);s.rotation.y=Cd(s.rotation.y,r,Math.min(1,e*5))}else o.target=null}else o.target=null}let p=X(s.position.x,s.position.z);o.mode===`hop`&&f&&(p+=Math.abs(Math.sin(t*8+o.phase))*.4),s.position.y=p,u.forEach((e,n)=>{e.rotation.x=f?Math.sin(t*d*5+n*Math.PI)*.6:0})}let o=this.whale;o.t+=e;let s=o.t%o.cycle/o.cycle;if(s<.01&&!o.moved){let e=d_()*1.4-.2;o.obj.position.x=Math.cos(e)*395,o.obj.position.z=Math.sin(e)*395,o.obj.rotation.y=d_()*6.28,o.moved=!0}else s>.5&&(o.moved=!1);let c=s>.1&&s<.35?Math.sin((s-.1)/.25*Math.PI):0;o.obj.position.y=-6+c*6.2,o.obj.visible=c>.05,c>.9&&Math.random()<e*4&&n.fx.emit(o.obj.position.x,2,o.obj.position.z,6,{color:16777215,speed:6,gravity:8,size:.6,up:2});for(let n of this.swarms)n.visible=i,i&&(n.rotation.y+=e*.3,n.position.y+=Math.sin(t+n.position.x)*e*.2)}},g_=class{constructor(e){this.g=e,this.available=!1,fetch(`/api/status`).then(e=>e.ok?e.json():null).then(e=>{this.available=!!e?.ai}).catch(()=>{})}enabled(){return this.available&&this.g.state.data.settings.aiChat}context(){let e=this.g,t=e.state.data,n=Lf(e.player.pos.x,e.player.pos.z);return{shards:t.shards.length,feathers:t.feathers.length,coins:t.coins,time:Y(`{0}点`,[Math.floor(t.time)]),night:e.sky.night>.5,region:Rd[n]?.name||Y(`海上`),abilities:Object.entries(t.abilities).filter(([,e])=>e).map(([e])=>rh[e]),objectives:Ig(e.state,e.content),ending:t.ending}}async chat(e,t,n){try{return(await(await fetch(`/api/npc-chat`,{method:`POST`,headers:{"content-type":`application/json`},body:JSON.stringify({npc:e.id,history:t,message:n,context:this.context(),lang:Nd})})).json()).reply||`……`}catch{return Y(`（对方好像没听清你在说什么。）`)}}},__={camera:Y(`按 C 拍照，登记图鉴`),glider:Y(`在空中再按一次空格展开，按住保持滑翔`),lantern:Y(`可以走进漆黑的迷雾森林深处了`),rod:Y(`在有涟漪的水面附近按 E 钓鱼`),fins:Y(`现在可以在水里游泳了，按住 Shift 游得更快`),shovel:Y(`在藏宝图标记的地点按 E 挖宝`),boots:Y(`在空中再按一次空格可以二段跳`),compass:Y(`右上角会指向最近的星屑`)},v_=class{constructor(e){this.canvas=e;let t=this.renderer=new hd({canvas:e,antialias:!0,powerPreference:`high-performance`});t.setPixelRatio(Math.min(devicePixelRatio,1.75)),t.setSize(innerWidth,innerHeight),t.shadowMap.enabled=!0,t.shadowMap.type=1,t.toneMapping=4,t.toneMappingExposure=1,this.scene=new Nn,this.camera=new Es(60,innerWidth/innerHeight,.1,1600),this.post=new Lh(t,this.scene,this.camera),this.hitstop=0,this.state=new ig,this.input=new ag(e),this.audio=new cg,this.hud=new Mg,this.dialog=new Pg(this.audio),this.cam=new Ag(this.camera),this.codexLive=[],this.clock=0,this.running=!1,this.cutscene=!1,this._frameWaiters=[],this._timers={slow:0,save:0,weather:150},this._regionCur=null,this._regionCand=null,this._regionT=0,this._toastGate={},addEventListener(`resize`,()=>{this.camera.aspect=innerWidth/innerHeight,this.camera.updateProjectionMatrix(),this.renderer.setSize(innerWidth,innerHeight),this.post.resize()})}async load(e){let t=async t=>{e(t),await new Promise(e=>setTimeout(e,16))};await t(5),this.world=ih(this.scene,this.renderer),this.content=this.world.content,this.sky=this.world.sky,await t(70),this.fx=new sg(this.scene),this.interact=new Vg(this),this.player=new kg(this.scene,this.world.colliders,this.state),this.player.onEvent=(e,t)=>this.onPlayerEvent(e,t),this.player.restrict=(e,t)=>this.restrict(e,t),this.player.char.root.visible=!1,this.lanternLight=new Os(16761975,0,26,1.4),this.scene.add(this.lanternLight),await t(85),this.titleAngle=0,this.camera.position.set(60,60,260),this.camera.lookAt(0,10,120),this.sky.update(.016,8.5,new U(0,0,150),this.camera.position,0),this.applyQuality(this.state.data.settings.quality);try{let e=JSON.parse(localStorage.getItem(`stardust-isles-save-v1`)||`{}`).settings;e?.quality&&this.applyQuality(e.quality)}catch{}this.renderer.compile(this.scene,this.camera),await t(100),requestAnimationFrame(e=>{this._last=e,this._tick(e)})}start(e){e?this.state.reset():this.state.load();let t=this.state.data;e&&t.campfires.push(`village`),this.collect=new Jg(this),this.npcs=new Xg(this),this.challenges=new o_(this),this.fishing=new c_(this),this.photo=new u_(this),this.creatures=new h_(this),this.combat=new tg(this),this.menu=new Bg(this),this.ai=new g_(this),this._setupCampfires(),this._setupLighthouse(),(!t.reveal||t.reveal.length!==4096)&&(t.reveal=`0`.repeat(4096)),this._reveal=t.reveal.split(``),this.player.char.root.visible=!0,this.player.char.setHat(t.hat),t.pos?(this.player.teleport(t.pos.x,t.pos.y,t.pos.z),this.player.yaw=t.yaw||0):(this.player.teleport(4,X(4,168),168),this.player.yaw=Math.PI),this.cam.yaw=this.player.yaw+Math.PI,this.cam.target.set(this.player.pos.x,this.player.pos.y+1.5,this.player.pos.z),this.world.frontier.update(this.player.pos.x,this.player.pos.z,0,!0),this.applySettings(),this.hud.show(!0),this.running=!0,this.collect.syncVisibility(),t.ending&&(this.world.lighthouse.lamp.material.emissiveIntensity=3,this.world.lighthouse.beam.visible=!0),e?(this.hud.banner(Y(`星屑群岛`),Y(`流星雨过后的第一个早晨`),3500),setTimeout(()=>this.hud.toast(Y(`前面那位老奶奶好像有话要说。走到她身边按 E。`),5e3),3800)):this.hud.toast(Y(`欢迎回来！`))}applySettings(){let e=this.state.data.settings;this.audio.setVolumes(e.volume,e.music),this._quality!==e.quality&&this.applyQuality(e.quality),this.renderer.shadowMap.enabled=e.shadows,this.world.sky.sun.castShadow=e.shadows,this.scene.traverse(e=>{e.material&&(e.material.needsUpdate=!0)})}applyQuality(e){Ph[e]||(e=`high`),this._quality=e,this.post.setQuality(e,this.world?.sky.sun),this.world?.grass.setQuality(e),this.world?.frontier.setQuality(e),this.world?.water.setQuality(e)}busyForCombat(){return this.dialog.active||this.cutscene||this.menu?.isOpen||this.fishing?.active}wait(e){return new Promise(t=>setTimeout(t,e*1e3))}frame(){return new Promise(e=>this._frameWaiters.push(e))}busy(){return this.dialog.active||this.fishing?.active||this.photo?.active||this.cutscene||this.menu?.isOpen||this.challenges?.busy()}canTravel(){return!(this.dialog.active||this.fishing?.active||this.cutscene||this.challenges?.activeCourse||this.challenges?.race)}moodNow(){return this.combat?.inCombat?`tense`:this.sky.rainTarget>0?`rain`:this.sky.night>.5?`night`:`day`}toastOnce(e,t,n=5){let r=this.clock;this._toastGate[e]&&r-this._toastGate[e]<n||(this._toastGate[e]=r,this.hud.toast(t))}beginDialog(e){this.player.frozen=!0,this.dialog.open(e.voice||500)}endDialog(){this.dialog.close(),this.player.frozen=!1}grantAbility(e){this.state.grant(e),this.audio.play(`ability`),this.hud.banner(Y(`获得 {0}！`,[rh[e]]),__[e]||``,4e3),this.state.save()}async fade(e){let t=document.querySelector(`#fade`);t.style.opacity=+!!e,await this.wait(.65)}async fastTravel(e,t=!1){if(!t&&!this.canTravel())return;await this.fade(!0);let n=zf(e.x+2.5,e.z+2.5,3,.5);this.player.teleport(n.x,n.y,n.z),this.player.yaw=Math.atan2(e.x-n.x,e.z-n.z),this.cam.yaw=this.player.yaw+Math.PI,this.cam.target.set(n.x,n.y+1.5,n.z),this.world.frontier.update(n.x,n.z,0,!0),await this.fade(!1),t||this.hud.toast(Y(`来到了 {0}`,[e.name]))}async restUntil(e){let t=this.state.data;await this.fade(!0),e<=t.time&&t.day++,t.time=e,this.player.stamina=this.player.maxStamina,this.combat.hp=this.combat.maxHp,this.sky.rain=this.sky.rainTarget=0,this.collect.syncVisibility(),await this.wait(.3),await this.fade(!1),this.hud.toast(Y(`休息得很好，精神饱满！`)),this.state.save()}_setupCampfires(){let e=this.state.data;for(let t of this.world.campfires)t.fire.visible=e.campfires.includes(t.id),this.interact.add({pos:{x:t.x,y:t.y,z:t.z},radius:3.2,label:()=>e.campfires.includes(t.id)?Y(`营火（休息 / 快速旅行）`):Y(`点亮营火`),action:async()=>{e.campfires.includes(t.id)||(this.state.add(`campfires`,t.id),t.fire.visible=!0,this.audio.play(`fire`),this.fx.emit(t.x,t.y+.8,t.z,40,{color:16752704,speed:4,gravity:-2}),this.hud.banner(Y(`点亮了 {0}`,[t.name]),Y(`可以在地图上快速旅行到这里，也可以在营火旁休息`)),this.state.save(),await this.wait(.8)),this.beginDialog({voice:300});let n=await this.dialog.choose(t.name,Y(`火光暖洋洋的。要做什么？`),[Y(`休息到早晨（6:00）`),Y(`休息到中午（12:00）`),Y(`休息到黄昏（18:00）`),Y(`休息到深夜（22:00）`),Y(`打开地图（快速旅行）`),Y(`离开`)]);this.endDialog(),n<4?await this.restUntil([6,12,18,22][n]):n===4&&this.menu.open(`map`)}})}_setupLighthouse(){let e=this.world.lighthouse,t=this.state.data;this.interact.add({pos:{x:e.door.x,y:e.door.y,z:e.door.z},radius:3,height:4,label:()=>t.ending?null:t.shards.length>=20?Y(`点亮灯塔`):Y(`灯塔的大门（星屑 {0}/{1}）`,[t.shards.length,20]),action:async()=>{t.shards.length<20?this.hud.toast(Y(`门上有一个星形的凹槽，还需要 {0} 颗星屑才能打开。`,[20-t.shards.length]),4e3):await this.ending()}})}async ending(){let e=this.world.lighthouse,t=this.state.data;this.cutscene=!0,this.player.frozen=!0,this.hud.show(!1),this.input.unlock(),this.audio.setMood(`ending`),await this.fade(!0),t.time=20.6;let n=e.y+16.8,r=.6,i=this.cam.override={pos:new U,look:new U(e.x,n,e.z),speed:1.5,fov:55};this._cutsceneTick=t=>{r+=t*.12,i.pos.set(e.x+Math.cos(r)*46,n+10,e.z+Math.sin(r)*46)},this._cutsceneTick(0),this.camera.position.copy(i.pos),await this.fade(!1),await this.wait(2);for(let t=0;t<=30;t++)e.lamp.material.emissiveIntensity=t/30*3,await this.wait(.05);e.beam.visible=!0,this.audio.play(`fanfare`);for(let t=0;t<6;t++)setTimeout(()=>this.fx.emit(e.x,n+2,e.z,80,{color:16769126,speed:12,gravity:2,life:2.2,size:.8}),t*300);this.hud.show(!0),this.hud.banner(Y(`灯塔重新亮起来了！`),Y(`光芒再次照亮了星屑群岛`),5e3),this.hud.show(!1),document.querySelector(`#hud`).hidden=!0,await this.wait(6);let a=document.querySelector(`#ending`),o=Math.floor(t.playTime/60),s=(e,t)=>`<div class="stat"><span>${e}</span><b>${t}</b></div>`;a.innerHTML=`<div class="ending-box"><h1>${Y(`星屑群岛`)}</h1>
      <p>${Y(`灯塔的光芒扫过海面，艾拉奶奶站在村口，久久地望着雪山顶。`)}<br>${Y(`谢谢你，旅人。群岛的夜晚再也不会迷路了。`)}</p>
      ${s(`⭐ `+Y(`星屑`),`${t.shards.length} / 30`)}
      ${s(`🪶 `+Y(`金羽毛`),`${t.feathers.length} / 15`)}
      ${s(`📖 `+Y(`图鉴`),`${t.codex.length} / ${$m.length}`)}
      ${s(`⏱ `+Y(`游戏时间`),Y(`{0} 分钟`,[o]))}
      <p style="font-size:14px;opacity:.75">${Y(`还有没找到的星屑？群岛一直在这里等你。`)}</p>
      <button class="btn" id="end-continue">${Y(`继续探索`)}</button></div>`,a.hidden=!1,await new Promise(e=>{document.querySelector(`#end-continue`).onclick=e}),a.hidden=!0,t.ending=!0,this.cam.override=null,this._cutsceneTick=null,this.cutscene=!1,this.player.frozen=!1,this.hud.show(!0),this.audio.setMood(this.moodNow()),this.state.save()}onPlayerEvent(e,t){let n=this.player.pos,r=this.audio;switch(e){case`jump`:r.play(`jump`);break;case`djump`:r.play(`djump`),this.fx.emit(n.x,n.y+.2,n.z,14,{color:16777215,speed:3,gravity:0,size:.4});break;case`land`:r.play(`land`,t),t>7&&this.fx.emit(n.x,n.y+.1,n.z,Math.min(30,t*1.2),{color:14207144,speed:3,gravity:2,size:.5,up:.4}),t>22&&(this.cam.shake=.6),this.combat?.onLand();break;case`splash`:r.play(`splash`),this.fx.emit(n.x,If(n.x,n.z)+.2,n.z,30,{color:14677759,speed:5,gravity:9,size:.45,up:1.5});break;case`step`:r.play(`step`,t);break;case`climbstep`:r.play(`climbstep`);break;case`stroke`:r.play(`stroke`);break;case`glide`:r.play(`glide`);break;case`grab`:r.play(`grab`);break;case`exhausted`:r.play(`exhausted`),this.toastOnce(`exhaust`,Y(`体力耗尽了！收集金羽毛可以提升体力上限。`),8);break;case`respawn`:t===`cold`&&this.toastOnce(`cold`,this.state.data.abilities.fins?``:Y(`水太冷了！没有脚蹼的话没法游泳。`),3);{let e=document.querySelector(`#fade`);e.style.transition=`none`,e.style.opacity=.8,requestAnimationFrame(()=>{e.style.transition=`opacity .6s`,e.style.opacity=0})}}}restrict(e,t){if(this.state.data.abilities.lantern)return!0;let n=Vd,r=Math.hypot(e.x-n.x,e.z-n.z),i=n.r-24;if(r<i){if(t)return!1;let a=i/Math.max(r,.01);e.x=n.x+(e.x-n.x)*a,e.z=n.z+(e.z-n.z)*a,this.toastOnce(`dark`,Y(`太黑了，前面什么都看不见……也许需要一盏提灯。`),5)}return!0}_tick(e){requestAnimationFrame(e=>this._tick(e));let t=Math.min(.1,Math.max(.001,(e-this._last)/1e3));this._last=e,this.input.beginFrame(),this.clock+=t;let n=this._frameWaiters;this._frameWaiters=[];for(let e of n)e(t);Zf.uTime.value=this.clock,this.running?this.update(t):this._titleUpdate(t),this.post.render(t,this.clock)}_titleUpdate(e){this.titleAngle+=e*.04;let t=this.titleAngle;this.camera.position.set(Math.cos(t)*140,70,120+Math.sin(t)*140),this.camera.lookAt(0,8,90);let n=new U(0,0,120);this.sky.update(e,17.4,n,this.camera.position,this.clock),this.world.water.update(this.clock,n,this.sky,this.scene.fog);for(let t of this.world.structures.animated)t(e,this.clock)}update(e){let t=this.state.data,n=this.input;if(this.menu.isOpen?(n.hit(`Tab`,`Escape`)||n.hit(`KeyM`)&&this.menu.tab===`map`)&&this.menu.close():this.photo.active?this.photo.update():this.busy()||(n.hit(`Tab`)?this.menu.open(this.menu.tab):n.hit(`KeyM`)?this.menu.open(`map`):n.hit(`Escape`)?this.menu.open(this.menu.tab):n.hit(`KeyC`)&&(t.abilities.camera?this.photo.toggle():this.toastOnce(`nocam`,Y(`还没有相机。村里的皮普博士也许能帮忙。`)))),n.enabled=!(this.dialog.active||this.menu.isOpen||this.fishing.active||this.cutscene),n.wantLock=!this.menu.isOpen&&!this.dialog.active&&!this.cutscene,this.menu.isOpen){this.hud.update(this);return}!this.dialog.active&&!this.cutscene&&(t.time+=e/20,t.time>=24&&(t.time-=24,t.day++)),t.playTime+=e,t.playTime>180&&!this._keysHidden&&(this._keysHidden=!0,this.hud.keysHint.hidden=!0);let r=e;this.hitstop>0&&(this.hitstop-=e,r=e*.06);let i=Math.ceil(r/(1/60));for(let e=0;e<i;e++)this.player.update(r/i,n,this.cam,e===0);this._cutsceneTick&&this._cutsceneTick(e),this.cam.update(e,this.player.pos,n,t.settings),this.sky.update(e,t.time,this.player.pos,this.camera.position,this.clock),this.world.water.update(this.clock,this.player.pos,this.sky,this.scene.fog),this.world.frontier.update(this.player.pos.x,this.player.pos.z,4),this.world.grass.update(this.player.pos,3),this.world.ambient.update(this.clock,this.camera.position,this.sky);for(let t of this.world.structures.animated)t(e,this.clock);this.collect.update(e,this.clock),this.npcs.update(e,this.clock),this.challenges.update(e,this.clock),this.fishing.update(e,this.clock),this.creatures.update(r,this.clock),this.combat.update(r,e),this.fx.update(e),this.interact.update(),this._zones(e),this._slowUpdate(e),this.hud.update(this)}_zones(e){let t=this.player.pos,n=this.state.data,r=Vd,i=Math.hypot(t.x-r.x,t.z-r.z),a=bd((r.r+10-i)/45,0,1),o=this.sky.night,s=n.abilities.lantern;this.hud.setDarkness(s?a*.3+o*.15:a*.85),this.sky.extraFog+=(a*.65-this.sky.extraFog)*Math.min(1,e*2);let c=s&&(o>.3||a>.15);this.player.lanternOn=c,this.lanternLight.intensity+=((c?28:0)-this.lanternLight.intensity)*Math.min(1,e*4),this.lanternLight.position.set(t.x,t.y+2.2,t.z);let l=this.player,u=n.abilities,d=``;if(d=l.mode===`air`&&u.glider?u.boots&&l.jumps<2?Y(`空格 二段跳`):Y(`空格 展开滑翔翼（按住）`):l.mode===`glide`?Y(`松开空格 收起滑翔翼 · S 减速`):l.mode===`climb`?Y(`空格 向上蹬（消耗体力）· S 向下爬`):l.mode===`swim`&&!u.fins?Y(`水太冷了！快上岸`):[u.camera?Y(`C 相机`):``,Y(`Tab 菜单`),Y(`M 地图`)].filter(Boolean).join(` · `),this.hud.setToolsHint(d),u.compass){let e=this.collect.nearestShard(t);if(e){let n=this.cam.forward(),r=this.cam.right(),i=e.x-t.x,a=e.z-t.z;this.hud.setCompass(Math.atan2(i*r.x+a*r.z,i*n.x+a*n.z),e.d)}else this.hud.setCompass(null)}}_slowUpdate(e){let t=this._timers,n=this.state.data,r=this.player.pos;if(t.slow-=e,t.save-=e,t.weather-=e,t.slow<=0){t.slow=.5;let e=Lf(r.x,r.z);if(e!==this._regionCur&&(e===this._regionCand?this._regionT+=.5:(this._regionCand=e,this._regionT=0),this._regionT>=1)){this._regionCur=e;let t=e.startsWith(`far:`),n=Rd[e]?.name||(t?Y(`远方群岛 · {0}`,[Qd[e.slice(4)].name]):e===`farsea`?Y(`无尽之海`):null);n&&this.hud.showRegion(n),t&&!this.state.flag(`farVisited`)&&(this.state.flag(`farVisited`,!0),this.hud.banner(Y(`远方群岛`),Y(`离家越远，蚀影越强，宝藏也越丰厚。`),4500))}let i=Math.hypot(r.x,r.z);i>n.farthest&&(n.farthest=i);let a=900/64,o=Math.floor((r.x-75+450)/a),s=Math.floor((r.x+75+450)/a),c=Math.floor((r.z-75+450)/a),l=Math.floor((r.z+75+450)/a),u=!1;for(let e=Math.max(0,c);e<=Math.min(63,l);e++)for(let t=Math.max(0,o);t<=Math.min(63,s);t++){let n=-450+(t+.5)*a,i=-450+(e+.5)*a;Math.hypot(n-r.x,i-r.z)<75&&this._reveal[e*64+t]!==`1`&&(this._reveal[e*64+t]=`1`,u=!0)}u&&(n.reveal=this._reveal.join(``)),!this.challenges.activeCourse&&!this.challenges.race&&!this.cutscene&&this.audio.setMood(this.moodNow());let d=0;for(let e=0;e<8;e++){let t=e/8*Math.PI*2;X(r.x+Math.cos(t)*30,r.z+Math.sin(t)*30)<0&&d++}let f=ff(r.x,r.z);this.audio.updateAmbience(.5,{sea:d/8,wind:bd((r.y-15)/50,0,1),rain:this.sky.rain,night:this.sky.night,birds:(1-this.sky.night)*(f.meadow+f.forest+f.lake)*.5});for(let e of this.world.lamps)e.material.emissiveIntensity=.2+this.sky.night*2.2}t.weather<=0&&(this.sky.rainTarget>0?(this.sky.rainTarget=0,t.weather=200+Math.random()*200):Math.random()<.4?(this.sky.rainTarget=1,t.weather=70+Math.random()*60,this.hud.toast(Y(`下雨了……雨天会有特别的动物出现。`))):t.weather=120+Math.random()*120),t.save<=0&&(t.save=20,n.pos={x:r.x,y:r.y,z:r.z},n.yaw=this.player.yaw,this.player.mode===`ground`&&this.state.save())}},y_=e=>document.querySelector(e);Ld(),document.title=Nd===`en`?`Stardust Isles`:`星屑群岛 Stardust Isles`;for(let e of document.querySelectorAll(`.lang-switch button`))e.classList.toggle(`on`,e.dataset.lang===Nd),e.onclick=()=>{e.dataset.lang!==Nd&&(Id(e.dataset.lang),location.reload())};var b_=new v_(y_(`#game`));window.__game=b_,b_.load(e=>{y_(`#load-pct`).textContent=e+`%`}).then(()=>{y_(`#loading`).hidden=!0,y_(`.buttons`).hidden=!1,y_(`#btn-continue`).hidden=!ig.hasSave()}).catch(e=>{console.error(e),y_(`#loading`).textContent=Y(`加载失败：`)+e.message});function x_(e){b_.audio.init(),y_(`#title`).classList.add(`hide`),setTimeout(()=>{y_(`#title`).hidden=!0},1e3),b_.start(e)}y_(`#btn-new`).onclick=()=>{ig.hasSave()&&!y_(`#btn-new`).dataset.confirm?(y_(`#btn-new`).dataset.confirm=`1`,y_(`#btn-new`).textContent=Y(`确定覆盖存档？再点一次`)):x_(!0)},y_(`#btn-continue`).onclick=()=>x_(!1);