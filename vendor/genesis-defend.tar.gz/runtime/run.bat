@echo off
title Remix - Open World Tower Defense RPG
color 0A

cd /d "%~dp0"

echo ===============================================
echo    Open World Tower Defense RPG
echo ===============================================
echo.

echo Checking Node.js...
node -v >nul 2>&1
if errorlevel 1 (
    echo.
    echo Node.js is not installed.
    echo.
    echo Opening index.html directly...
    start "" "index.html"
    pause
    exit /b
)

echo.
echo Starting local web server...
echo.
echo URL: http://localhost:3000
echo Press Ctrl+C to stop the server.
echo.

call npx serve .

pause