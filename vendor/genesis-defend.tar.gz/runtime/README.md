# 🏰 Genesis Defend

An interactive **3D Isometric Tower Defense & Hero Action Game** built with **Three.js** and **WebGL**. Command powerful elemental towers, control a hero in real time, and defend your base against relentless enemy waves in a visually immersive browser experience.

---

## 🚀 Overview

**Genesis Defend** combines classic tower defense strategy with action-based hero gameplay. Build and upgrade defensive towers on a hexagonal battlefield while directly controlling your hero using **WASD** to support your defenses.

Designed as a modern WebGL project, it demonstrates real-time rendering, pathfinding, combat systems, and interactive UI development using JavaScript and Three.js.

---

## ✨ Features

### 🏰 Five Unique Elemental Towers

- 🏹 **Arrow Tower** – Fast single-target attacks
- 💣 **Cannon Tower** – Powerful splash damage
- ❄️ **Frost Tower** – Slows enemy movement
- ⚡ **Storm Tower** – Chain lightning attacks
- ☠️ **Venom Tower** – Poison damage over time

### ⚔️ Hero Gameplay

- Real-time **WASD movement**
- Assist towers during battles
- Engage enemies directly
- Level up throughout the game

### 🌊 Wave System

- Progressive enemy waves
- Skip countdown for bonus gold
- Increasing difficulty
- Strategic resource management

### 💰 Economy System

- Earn gold from defeated enemies
- Upgrade existing towers
- Sell unwanted towers
- Smart spending decisions

### 🗺️ Battlefield

- Isometric 3D environment
- Hexagonal grid system
- Interactive minimap
- Smooth camera controls

---

## 🎮 Gameplay

- Build defensive towers on valid hexagonal tiles.
- Defeat incoming enemy waves before they reach your base.
- Control your hero using **W, A, S, D**.
- Upgrade towers to increase their power.
- Protect the base and survive increasingly difficult waves.

---

## 🛠️ Tech Stack

- HTML5
- CSS3
- JavaScript (ES6+)
- Three.js
- WebGL

---

## 📂 Project Structure

```text
genesis-defend/
│
├── assets/              # Models, textures, sounds
├── index.html           # Main HTML file
├── style.css            # User interface styling
├── main.js              # Game engine & logic
├── run.bat              # Windows launcher
├── README.md
└── LICENSE
```

---

## ⚙️ Installation

### Clone the Repository

```bash
git clone https://github.com/rsamwilson2323-cloud/open-world-tower-defense.git
cd genesis-defend
```

### Run with Python

```bash
python -m http.server 8080
```

Open:

```
http://localhost:8080
```

### Windows

Simply run:

```bash
run.bat
```

---

## 🎯 Controls

| Key | Action |
|------|--------|
| W | Move Forward |
| A | Move Left |
| S | Move Backward |
| D | Move Right |
| Mouse | Place / Select Towers |
| Left Click | Build, Upgrade, Sell |

---

## 🎯 Use Cases

- Learn Three.js game development
- Explore WebGL rendering
- Study tower defense mechanics
- Practice JavaScript game architecture
- Portfolio-ready browser game

---

## 🚀 Future Improvements

- Hero skills & abilities
- Boss battles
- Multiplayer support
- Additional tower types
- More enemy varieties
- Save/load progress
- Sound effects & music
- Achievement system
- Mobile support

---

## 👨‍💻 Author

**Sam Wilson**

AI & Full-Stack Developer

- AI Applications
- Computer Vision
- 3D Web Graphics
- Web Development

---

## 📄 License

This project is licensed under the **MIT License**.

Feel free to use, modify, and distribute it.

---

## ⭐ Support

If you enjoyed this project:

⭐ Star this repository

🍴 Fork it

🐞 Report issues

💡 Share your ideas

Happy Defending! 🏰
