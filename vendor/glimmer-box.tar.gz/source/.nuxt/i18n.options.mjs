
// @ts-nocheck


export const localeCodes =  [
  "zh",
  "en",
  "ja",
  "fr",
  "de"
]

export const localeLoaders = {
  zh: [
    {
      key: "locale_zh_46json_5497c1ca",
      load: () => import("#nuxt-i18n/5497c1ca" /* webpackChunkName: "locale_zh_46json_5497c1ca" */),
      cache: true
    }
  ],
  en: [
    {
      key: "locale_en_46json_69da5289",
      load: () => import("#nuxt-i18n/69da5289" /* webpackChunkName: "locale_en_46json_69da5289" */),
      cache: true
    }
  ],
  ja: [
    {
      key: "locale_ja_46json_8c7a2877",
      load: () => import("#nuxt-i18n/8c7a2877" /* webpackChunkName: "locale_ja_46json_8c7a2877" */),
      cache: true
    }
  ],
  fr: [
    {
      key: "locale_fr_46json_faf46fe3",
      load: () => import("#nuxt-i18n/faf46fe3" /* webpackChunkName: "locale_fr_46json_faf46fe3" */),
      cache: true
    }
  ],
  de: [
    {
      key: "locale_de_46json_a0638b23",
      load: () => import("#nuxt-i18n/a0638b23" /* webpackChunkName: "locale_de_46json_a0638b23" */),
      cache: true
    }
  ]
}

export const vueI18nConfigs = []

export const nuxtI18nOptions = {
  restructureDir: "i18n",
  experimental: {
    localeDetector: "",
    switchLocalePathLinkSSR: false,
    autoImportTranslationFunctions: false,
    typedPages: true,
    typedOptionsAndMessages: false,
    generatedLocaleFilePathFormat: "absolute",
    alternateLinkCanonicalQueries: false,
    hmr: true
  },
  bundle: {
    compositionOnly: true,
    runtimeOnly: false,
    fullInstall: true,
    dropMessageCompiler: false,
    optimizeTranslationDirective: false
  },
  compilation: {
    strictMessage: true,
    escapeHtml: false
  },
  customBlocks: {
    defaultSFCLang: "json",
    globalSFCScope: false
  },
  locales: [
    {
      code: "zh",
      name: "简体中文",
      language: "zh-CN",
      files: [
        {
          path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/zh.json",
          cache: undefined
        }
      ]
    },
    {
      code: "en",
      name: "English",
      language: "en-US",
      files: [
        {
          path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/en.json",
          cache: undefined
        }
      ]
    },
    {
      code: "ja",
      name: "日本語",
      language: "ja-JP",
      files: [
        {
          path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/ja.json",
          cache: undefined
        }
      ]
    },
    {
      code: "fr",
      name: "Français",
      language: "fr-FR",
      files: [
        {
          path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/fr.json",
          cache: undefined
        }
      ]
    },
    {
      code: "de",
      name: "Deutsch",
      language: "de-DE",
      files: [
        {
          path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/de.json",
          cache: undefined
        }
      ]
    }
  ],
  defaultLocale: "zh",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  trailingSlash: false,
  defaultLocaleRouteNameSuffix: "default",
  strategy: "no_prefix",
  lazy: true,
  langDir: "locales",
  rootRedirect: undefined,
  detectBrowserLanguage: {
    alwaysRedirect: false,
    cookieCrossOrigin: false,
    cookieDomain: null,
    cookieKey: "glimmer-locale",
    cookieSecure: false,
    fallbackLocale: "",
    redirectOn: "root",
    useCookie: true
  },
  differentDomains: false,
  baseUrl: "",
  customRoutes: "page",
  pages: {},
  skipSettingLocaleOnNavigate: false,
  types: "composition",
  debug: false,
  parallelPlugin: false,
  multiDomainLocales: false,
  i18nModules: []
}

export const normalizedLocales = [
  {
    code: "zh",
    name: "简体中文",
    language: "zh-CN",
    files: [
      {
        path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/zh.json",
        cache: undefined
      }
    ]
  },
  {
    code: "en",
    name: "English",
    language: "en-US",
    files: [
      {
        path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/en.json",
        cache: undefined
      }
    ]
  },
  {
    code: "ja",
    name: "日本語",
    language: "ja-JP",
    files: [
      {
        path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/ja.json",
        cache: undefined
      }
    ]
  },
  {
    code: "fr",
    name: "Français",
    language: "fr-FR",
    files: [
      {
        path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/fr.json",
        cache: undefined
      }
    ]
  },
  {
    code: "de",
    name: "Deutsch",
    language: "de-DE",
    files: [
      {
        path: "/tmp/zyvo-glimmer-box-6ep7kqqb/source/i18n/locales/de.json",
        cache: undefined
      }
    ]
  }
]

export const NUXT_I18N_MODULE_ID = "@nuxtjs/i18n"
export const parallelPlugin = false
export const isSSG = true
export const hasPages = true

export const DEFAULT_COOKIE_KEY = "i18n_redirected"
export const DEFAULT_DYNAMIC_PARAMS_KEY = "nuxtI18nInternal"
export const SWITCH_LOCALE_PATH_LINK_IDENTIFIER = "nuxt-i18n-slp"
/** client **/

/** client-end **/