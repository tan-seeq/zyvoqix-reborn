export default defineI18nConfig(() => ({
  legacy: false,
  locale: 'zh',
  fallbackLocale: 'en',
  missingWarn: false,
  fallbackWarn: false,
}))
