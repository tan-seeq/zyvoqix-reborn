(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function e(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(i){if(i.ep)return;i.ep=!0;const r=e(i);fetch(i.href,r)}})();const oa="180",jc=0,Oa=1,Jc=2,Zl=1,Qc=2,Pn=3,Fn=0,qe=1,an=2,$n=0,Oi=1,Fa=2,Ba=3,ka=4,th=5,ui=100,eh=101,nh=102,ih=103,sh=104,rh=200,oh=201,ah=202,lh=203,ao=204,lo=205,ch=206,hh=207,uh=208,dh=209,fh=210,ph=211,mh=212,gh=213,_h=214,co=0,ho=1,uo=2,ki=3,fo=4,po=5,mo=6,go=7,jl=0,vh=1,xh=2,Zn=0,Mh=1,Sh=2,Eh=3,yh=4,Th=5,bh=6,Ah=7,Jl=300,zi=301,Hi=302,_o=303,vo=304,mr=306,rr=1e3,Un=1001,xo=1002,be=1003,wh=1004,rs=1005,Sn=1006,br=1007,fi=1008,Bn=1009,Ql=1010,tc=1011,cs=1012,aa=1013,gi=1014,Nn=1015,ps=1016,la=1017,ca=1018,hs=1020,ec=35902,nc=35899,ic=1021,sc=1022,cn=1023,us=1026,ds=1027,rc=1028,ha=1029,oc=1030,ua=1031,da=1033,Js=33776,Qs=33777,tr=33778,er=33779,Mo=35840,So=35841,Eo=35842,yo=35843,To=36196,bo=37492,Ao=37496,wo=37808,Ro=37809,Co=37810,Do=37811,Lo=37812,Po=37813,Io=37814,Uo=37815,No=37816,Oo=37817,Fo=37818,Bo=37819,ko=37820,zo=37821,Ho=36492,Go=36494,Vo=36495,Wo=36283,Xo=36284,qo=36285,Yo=36286,Rh=3200,Ch=3201,Dh=0,Lh=1,Kn="",tn="srgb",Gi="srgb-linear",or="linear",ce="srgb",Si=7680,za=519,Ph=512,Ih=513,Uh=514,ac=515,Nh=516,Oh=517,Fh=518,Bh=519,Ha=35044,ar="300 es",En=2e3,lr=2001;class Xi{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const i=n[t];if(i!==void 0){const r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let r=0,o=i.length;r<o;r++)i[r].call(this,t);t.target=null}}}const Ne=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],nr=Math.PI/180,Ko=180/Math.PI;function ms(){const s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ne[s&255]+Ne[s>>8&255]+Ne[s>>16&255]+Ne[s>>24&255]+"-"+Ne[t&255]+Ne[t>>8&255]+"-"+Ne[t>>16&15|64]+Ne[t>>24&255]+"-"+Ne[e&63|128]+Ne[e>>8&255]+"-"+Ne[e>>16&255]+Ne[e>>24&255]+Ne[n&255]+Ne[n>>8&255]+Ne[n>>16&255]+Ne[n>>24&255]).toLowerCase()}function Qt(s,t,e){return Math.max(t,Math.min(e,s))}function kh(s,t){return(s%t+t)%t}function Ar(s,t,e){return(1-e)*s+e*t}function Ji(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function Xe(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}class he{constructor(t=0,e=0){he.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Qt(this.x,t.x,e.x),this.y=Qt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Qt(this.x,t,e),this.y=Qt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Qt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*i+t.x,this.y=r*i+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class gs{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,o,a){let c=n[i+0],l=n[i+1],h=n[i+2],u=n[i+3];const d=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(a===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(a===1){t[e+0]=d,t[e+1]=f,t[e+2]=g,t[e+3]=_;return}if(u!==_||c!==d||l!==f||h!==g){let m=1-a;const p=c*d+l*f+h*g+u*_,T=p>=0?1:-1,b=1-p*p;if(b>Number.EPSILON){const L=Math.sqrt(b),R=Math.atan2(L,p*T);m=Math.sin(m*R)/L,a=Math.sin(a*R)/L}const E=a*T;if(c=c*m+d*E,l=l*m+f*E,h=h*m+g*E,u=u*m+_*E,m===1-a){const L=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=L,l*=L,h*=L,u*=L}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,o){const a=n[i],c=n[i+1],l=n[i+2],h=n[i+3],u=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return t[e]=a*g+h*u+c*f-l*d,t[e+1]=c*g+h*d+l*u-a*f,t[e+2]=l*g+h*f+a*d-c*u,t[e+3]=h*g-a*u-c*d-l*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,r=t._z,o=t._order,a=Math.cos,c=Math.sin,l=a(n/2),h=a(i/2),u=a(r/2),d=c(n/2),f=c(i/2),g=c(r/2);switch(o){case"XYZ":this._x=d*h*u+l*f*g,this._y=l*f*u-d*h*g,this._z=l*h*g+d*f*u,this._w=l*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+l*f*g,this._y=l*f*u-d*h*g,this._z=l*h*g-d*f*u,this._w=l*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-l*f*g,this._y=l*f*u+d*h*g,this._z=l*h*g+d*f*u,this._w=l*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-l*f*g,this._y=l*f*u+d*h*g,this._z=l*h*g-d*f*u,this._w=l*h*u+d*f*g;break;case"YZX":this._x=d*h*u+l*f*g,this._y=l*f*u+d*h*g,this._z=l*h*g-d*f*u,this._w=l*h*u-d*f*g;break;case"XZY":this._x=d*h*u-l*f*g,this._y=l*f*u-d*h*g,this._z=l*h*g+d*f*u,this._w=l*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],r=e[8],o=e[1],a=e[5],c=e[9],l=e[2],h=e[6],u=e[10],d=n+a+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-c)*f,this._y=(r-l)*f,this._z=(o-i)*f}else if(n>a&&n>u){const f=2*Math.sqrt(1+n-a-u);this._w=(h-c)/f,this._x=.25*f,this._y=(i+o)/f,this._z=(r+l)/f}else if(a>u){const f=2*Math.sqrt(1+a-n-u);this._w=(r-l)/f,this._x=(i+o)/f,this._y=.25*f,this._z=(c+h)/f}else{const f=2*Math.sqrt(1+u-n-a);this._w=(o-i)/f,this._x=(r+l)/f,this._y=(c+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Qt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,r=t._z,o=t._w,a=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+o*a+i*l-r*c,this._y=i*h+o*c+r*a-n*l,this._z=r*h+o*l+n*c-i*a,this._w=o*h-n*a-i*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,i=this._y,r=this._z,o=this._w;let a=o*t._w+n*t._x+i*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=i,this._z=r,this;const c=1-a*a;if(c<=Number.EPSILON){const f=1-e;return this._w=f*o+e*this._w,this._x=f*n+e*this._x,this._y=f*i+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}const l=Math.sqrt(c),h=Math.atan2(l,a),u=Math.sin((1-e)*h)/l,d=Math.sin(e*h)/l;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class F{constructor(t=0,e=0,n=0){F.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ga.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ga.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*o,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,r=t.x,o=t.y,a=t.z,c=t.w,l=2*(o*i-a*n),h=2*(a*e-r*i),u=2*(r*n-o*e);return this.x=e+c*l+o*u-a*h,this.y=n+c*h+a*l-r*u,this.z=i+c*u+r*h-o*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Qt(this.x,t.x,e.x),this.y=Qt(this.y,t.y,e.y),this.z=Qt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Qt(this.x,t,e),this.y=Qt(this.y,t,e),this.z=Qt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,r=t.z,o=e.x,a=e.y,c=e.z;return this.x=i*c-r*a,this.y=r*o-n*c,this.z=n*a-i*o,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return wr.copy(this).projectOnVector(t),this.sub(wr)}reflect(t){return this.sub(wr.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Qt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const wr=new F,Ga=new gs;class Xt{constructor(t,e,n,i,r,o,a,c,l){Xt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l)}set(t,e,n,i,r,o,a,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=a,h[3]=e,h[4]=r,h[5]=c,h[6]=n,h[7]=o,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[3],c=n[6],l=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],_=i[0],m=i[3],p=i[6],T=i[1],b=i[4],E=i[7],L=i[2],R=i[5],w=i[8];return r[0]=o*_+a*T+c*L,r[3]=o*m+a*b+c*R,r[6]=o*p+a*E+c*w,r[1]=l*_+h*T+u*L,r[4]=l*m+h*b+u*R,r[7]=l*p+h*E+u*w,r[2]=d*_+f*T+g*L,r[5]=d*m+f*b+g*R,r[8]=d*p+f*E+g*w,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8];return e*o*h-e*a*l-n*r*h+n*a*c+i*r*l-i*o*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=h*o-a*l,d=a*c-h*r,f=l*r-o*c,g=e*u+n*d+i*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return t[0]=u*_,t[1]=(i*l-h*n)*_,t[2]=(a*n-i*o)*_,t[3]=d*_,t[4]=(h*e-i*c)*_,t[5]=(i*r-a*e)*_,t[6]=f*_,t[7]=(n*c-l*e)*_,t[8]=(o*e-n*r)*_,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*o+l*a)+o+t,-i*l,i*c,-i*(-l*o+c*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(Rr.makeScale(t,e)),this}rotate(t){return this.premultiply(Rr.makeRotation(-t)),this}translate(t,e){return this.premultiply(Rr.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const Rr=new Xt;function lc(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function cr(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function zh(){const s=cr("canvas");return s.style.display="block",s}const Va={};function fs(s){s in Va||(Va[s]=!0,console.warn(s))}function Hh(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}const Wa=new Xt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Xa=new Xt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Gh(){const s={enabled:!0,workingColorSpace:Gi,spaces:{},convert:function(i,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===ce&&(i.r=On(i.r),i.g=On(i.g),i.b=On(i.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===ce&&(i.r=Fi(i.r),i.g=Fi(i.g),i.b=Fi(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Kn?or:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,o){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return fs("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return fs("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[Gi]:{primaries:t,whitePoint:n,transfer:or,toXYZ:Wa,fromXYZ:Xa,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:tn},outputColorSpaceConfig:{drawingBufferColorSpace:tn}},[tn]:{primaries:t,whitePoint:n,transfer:ce,toXYZ:Wa,fromXYZ:Xa,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:tn}}}),s}const re=Gh();function On(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Fi(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let Ei;class Vh{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{Ei===void 0&&(Ei=cr("canvas")),Ei.width=t.width,Ei.height=t.height;const i=Ei.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=Ei}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=cr("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let o=0;o<r.length;o++)r[o]=On(r[o]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(On(e[n]/255)*255):e[n]=On(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Wh=0;class fa{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wh++}),this.uuid=ms(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?r.push(Cr(i[o].image)):r.push(Cr(i[o]))}else r=Cr(i);n.url=r}return e||(t.images[this.uuid]=n),n}}function Cr(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Vh.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Xh=0;const Dr=new F;class ze extends Xi{constructor(t=ze.DEFAULT_IMAGE,e=ze.DEFAULT_MAPPING,n=Un,i=Un,r=Sn,o=fi,a=cn,c=Bn,l=ze.DEFAULT_ANISOTROPY,h=Kn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xh++}),this.uuid=ms(),this.name="",this.source=new fa(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new he(0,0),this.repeat=new he(1,1),this.center=new he(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Dr).x}get height(){return this.source.getSize(Dr).y}get depth(){return this.source.getSize(Dr).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Jl)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case rr:t.x=t.x-Math.floor(t.x);break;case Un:t.x=t.x<0?0:1;break;case xo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case rr:t.y=t.y-Math.floor(t.y);break;case Un:t.y=t.y<0?0:1;break;case xo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}ze.DEFAULT_IMAGE=null;ze.DEFAULT_MAPPING=Jl;ze.DEFAULT_ANISOTROPY=1;class Se{constructor(t=0,e=0,n=0,i=1){Se.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*i+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*i+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*i+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*i+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r;const c=t.elements,l=c[0],h=c[4],u=c[8],d=c[1],f=c[5],g=c[9],_=c[2],m=c[6],p=c[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const b=(l+1)/2,E=(f+1)/2,L=(p+1)/2,R=(h+d)/4,w=(u+_)/4,O=(g+m)/4;return b>E&&b>L?b<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(b),i=R/n,r=w/n):E>L?E<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(E),n=R/i,r=O/i):L<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(L),n=w/r,i=O/r),this.set(n,i,r,e),this}let T=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(T)<.001&&(T=1),this.x=(m-g)/T,this.y=(u-_)/T,this.z=(d-h)/T,this.w=Math.acos((l+f+p-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Qt(this.x,t.x,e.x),this.y=Qt(this.y,t.y,e.y),this.z=Qt(this.z,t.z,e.z),this.w=Qt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Qt(this.x,t,e),this.y=Qt(this.y,t,e),this.z=Qt(this.z,t,e),this.w=Qt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class qh extends Xi{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Sn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new Se(0,0,t,e),this.scissorTest=!1,this.viewport=new Se(0,0,t,e);const i={width:t,height:e,depth:n.depth},r=new ze(i);this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){const e={minFilter:Sn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isArrayTexture=this.textures[i].image.depth>1;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const i=Object.assign({},t.textures[e].image);this.textures[e].source=new fa(i)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class _i extends qh{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class pa extends ze{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=be,this.minFilter=be,this.wrapR=Un,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Yh extends ze{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=be,this.minFilter=be,this.wrapR=Un,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class _s{constructor(t=new F(1/0,1/0,1/0),e=new F(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(dn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(dn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=dn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,dn):dn.fromBufferAttribute(r,o),dn.applyMatrix4(t.matrixWorld),this.expandByPoint(dn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Ts.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Ts.copy(n.boundingBox)),Ts.applyMatrix4(t.matrixWorld),this.union(Ts)}const i=t.children;for(let r=0,o=i.length;r<o;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,dn),dn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Qi),bs.subVectors(this.max,Qi),yi.subVectors(t.a,Qi),Ti.subVectors(t.b,Qi),bi.subVectors(t.c,Qi),Gn.subVectors(Ti,yi),Vn.subVectors(bi,Ti),ei.subVectors(yi,bi);let e=[0,-Gn.z,Gn.y,0,-Vn.z,Vn.y,0,-ei.z,ei.y,Gn.z,0,-Gn.x,Vn.z,0,-Vn.x,ei.z,0,-ei.x,-Gn.y,Gn.x,0,-Vn.y,Vn.x,0,-ei.y,ei.x,0];return!Lr(e,yi,Ti,bi,bs)||(e=[1,0,0,0,1,0,0,0,1],!Lr(e,yi,Ti,bi,bs))?!1:(As.crossVectors(Gn,Vn),e=[As.x,As.y,As.z],Lr(e,yi,Ti,bi,bs))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,dn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(dn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(An[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),An[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),An[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),An[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),An[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),An[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),An[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),An[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(An),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const An=[new F,new F,new F,new F,new F,new F,new F,new F],dn=new F,Ts=new _s,yi=new F,Ti=new F,bi=new F,Gn=new F,Vn=new F,ei=new F,Qi=new F,bs=new F,As=new F,ni=new F;function Lr(s,t,e,n,i){for(let r=0,o=s.length-3;r<=o;r+=3){ni.fromArray(s,r);const a=i.x*Math.abs(ni.x)+i.y*Math.abs(ni.y)+i.z*Math.abs(ni.z),c=t.dot(ni),l=e.dot(ni),h=n.dot(ni);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>a)return!1}return!0}const Kh=new _s,ts=new F,Pr=new F;class qi{constructor(t=new F,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Kh.setFromPoints(t).getCenter(n);let i=0;for(let r=0,o=t.length;r<o;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ts.subVectors(t,this.center);const e=ts.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(ts,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Pr.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ts.copy(t.center).add(Pr)),this.expandByPoint(ts.copy(t.center).sub(Pr))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}const wn=new F,Ir=new F,ws=new F,Wn=new F,Ur=new F,Rs=new F,Nr=new F;class ma{constructor(t=new F,e=new F(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,wn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=wn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(wn.copy(this.origin).addScaledVector(this.direction,e),wn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){Ir.copy(t).add(e).multiplyScalar(.5),ws.copy(e).sub(t).normalize(),Wn.copy(this.origin).sub(Ir);const r=t.distanceTo(e)*.5,o=-this.direction.dot(ws),a=Wn.dot(this.direction),c=-Wn.dot(ws),l=Wn.lengthSq(),h=Math.abs(1-o*o);let u,d,f,g;if(h>0)if(u=o*c-a,d=o*a-c,g=r*h,u>=0)if(d>=-g)if(d<=g){const _=1/h;u*=_,d*=_,f=u*(u+o*d+2*a)+d*(o*u+d+2*c)+l}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*c)+l;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*c)+l;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-c),r),f=-u*u+d*(d+2*c)+l):d<=g?(u=0,d=Math.min(Math.max(-r,-c),r),f=d*(d+2*c)+l):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-c),r),f=-u*u+d*(d+2*c)+l);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(Ir).addScaledVector(ws,d),f}intersectSphere(t,e){wn.subVectors(t.center,this.origin);const n=wn.dot(this.direction),i=wn.dot(wn)-n*n,r=t.radius*t.radius;if(i>r)return null;const o=Math.sqrt(r-i),a=n-o,c=n+o;return c<0?null:a<0?this.at(c,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,o,a,c;const l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return l>=0?(n=(t.min.x-d.x)*l,i=(t.max.x-d.x)*l):(n=(t.max.x-d.x)*l,i=(t.min.x-d.x)*l),h>=0?(r=(t.min.y-d.y)*h,o=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,o=(t.min.y-d.y)*h),n>o||r>i||((r>n||isNaN(n))&&(n=r),(o<i||isNaN(i))&&(i=o),u>=0?(a=(t.min.z-d.z)*u,c=(t.max.z-d.z)*u):(a=(t.max.z-d.z)*u,c=(t.min.z-d.z)*u),n>c||a>i)||((a>n||n!==n)&&(n=a),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,wn)!==null}intersectTriangle(t,e,n,i,r){Ur.subVectors(e,t),Rs.subVectors(n,t),Nr.crossVectors(Ur,Rs);let o=this.direction.dot(Nr),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Wn.subVectors(this.origin,t);const c=a*this.direction.dot(Rs.crossVectors(Wn,Rs));if(c<0)return null;const l=a*this.direction.dot(Ur.cross(Wn));if(l<0||c+l>o)return null;const h=-a*Wn.dot(Nr);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ee{constructor(t,e,n,i,r,o,a,c,l,h,u,d,f,g,_,m){Ee.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l,h,u,d,f,g,_,m)}set(t,e,n,i,r,o,a,c,l,h,u,d,f,g,_,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=r,p[5]=o,p[9]=a,p[13]=c,p[2]=l,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ee().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/Ai.setFromMatrixColumn(t,0).length(),r=1/Ai.setFromMatrixColumn(t,1).length(),o=1/Ai.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){const d=o*h,f=o*u,g=a*h,_=a*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=f+g*l,e[5]=d-_*l,e[9]=-a*c,e[2]=_-d*l,e[6]=g+f*l,e[10]=o*c}else if(t.order==="YXZ"){const d=c*h,f=c*u,g=l*h,_=l*u;e[0]=d+_*a,e[4]=g*a-f,e[8]=o*l,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=f*a-g,e[6]=_+d*a,e[10]=o*c}else if(t.order==="ZXY"){const d=c*h,f=c*u,g=l*h,_=l*u;e[0]=d-_*a,e[4]=-o*u,e[8]=g+f*a,e[1]=f+g*a,e[5]=o*h,e[9]=_-d*a,e[2]=-o*l,e[6]=a,e[10]=o*c}else if(t.order==="ZYX"){const d=o*h,f=o*u,g=a*h,_=a*u;e[0]=c*h,e[4]=g*l-f,e[8]=d*l+_,e[1]=c*u,e[5]=_*l+d,e[9]=f*l-g,e[2]=-l,e[6]=a*c,e[10]=o*c}else if(t.order==="YZX"){const d=o*c,f=o*l,g=a*c,_=a*l;e[0]=c*h,e[4]=_-d*u,e[8]=g*u+f,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-l*h,e[6]=f*u+g,e[10]=d-_*u}else if(t.order==="XZY"){const d=o*c,f=o*l,g=a*c,_=a*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=d*u+_,e[5]=o*h,e[9]=f*u-g,e[2]=g*u-f,e[6]=a*h,e[10]=_*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose($h,t,Zh)}lookAt(t,e,n){const i=this.elements;return je.subVectors(t,e),je.lengthSq()===0&&(je.z=1),je.normalize(),Xn.crossVectors(n,je),Xn.lengthSq()===0&&(Math.abs(n.z)===1?je.x+=1e-4:je.z+=1e-4,je.normalize(),Xn.crossVectors(n,je)),Xn.normalize(),Cs.crossVectors(je,Xn),i[0]=Xn.x,i[4]=Cs.x,i[8]=je.x,i[1]=Xn.y,i[5]=Cs.y,i[9]=je.y,i[2]=Xn.z,i[6]=Cs.z,i[10]=je.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[4],c=n[8],l=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],T=n[3],b=n[7],E=n[11],L=n[15],R=i[0],w=i[4],O=i[8],S=i[12],M=i[1],C=i[5],z=i[9],G=i[13],W=i[2],K=i[6],H=i[10],rt=i[14],V=i[3],ht=i[7],ut=i[11],_t=i[15];return r[0]=o*R+a*M+c*W+l*V,r[4]=o*w+a*C+c*K+l*ht,r[8]=o*O+a*z+c*H+l*ut,r[12]=o*S+a*G+c*rt+l*_t,r[1]=h*R+u*M+d*W+f*V,r[5]=h*w+u*C+d*K+f*ht,r[9]=h*O+u*z+d*H+f*ut,r[13]=h*S+u*G+d*rt+f*_t,r[2]=g*R+_*M+m*W+p*V,r[6]=g*w+_*C+m*K+p*ht,r[10]=g*O+_*z+m*H+p*ut,r[14]=g*S+_*G+m*rt+p*_t,r[3]=T*R+b*M+E*W+L*V,r[7]=T*w+b*C+E*K+L*ht,r[11]=T*O+b*z+E*H+L*ut,r[15]=T*S+b*G+E*rt+L*_t,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],o=t[1],a=t[5],c=t[9],l=t[13],h=t[2],u=t[6],d=t[10],f=t[14],g=t[3],_=t[7],m=t[11],p=t[15];return g*(+r*c*u-i*l*u-r*a*d+n*l*d+i*a*f-n*c*f)+_*(+e*c*f-e*l*d+r*o*d-i*o*f+i*l*h-r*c*h)+m*(+e*l*u-e*a*f-r*o*u+n*o*f+r*a*h-n*l*h)+p*(-i*a*h-e*c*u+e*a*d+i*o*u-n*o*d+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=t[9],d=t[10],f=t[11],g=t[12],_=t[13],m=t[14],p=t[15],T=u*m*l-_*d*l+_*c*f-a*m*f-u*c*p+a*d*p,b=g*d*l-h*m*l-g*c*f+o*m*f+h*c*p-o*d*p,E=h*_*l-g*u*l+g*a*f-o*_*f-h*a*p+o*u*p,L=g*u*c-h*_*c-g*a*d+o*_*d+h*a*m-o*u*m,R=e*T+n*b+i*E+r*L;if(R===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const w=1/R;return t[0]=T*w,t[1]=(_*d*r-u*m*r-_*i*f+n*m*f+u*i*p-n*d*p)*w,t[2]=(a*m*r-_*c*r+_*i*l-n*m*l-a*i*p+n*c*p)*w,t[3]=(u*c*r-a*d*r-u*i*l+n*d*l+a*i*f-n*c*f)*w,t[4]=b*w,t[5]=(h*m*r-g*d*r+g*i*f-e*m*f-h*i*p+e*d*p)*w,t[6]=(g*c*r-o*m*r-g*i*l+e*m*l+o*i*p-e*c*p)*w,t[7]=(o*d*r-h*c*r+h*i*l-e*d*l-o*i*f+e*c*f)*w,t[8]=E*w,t[9]=(g*u*r-h*_*r-g*n*f+e*_*f+h*n*p-e*u*p)*w,t[10]=(o*_*r-g*a*r+g*n*l-e*_*l-o*n*p+e*a*p)*w,t[11]=(h*a*r-o*u*r-h*n*l+e*u*l+o*n*f-e*a*f)*w,t[12]=L*w,t[13]=(h*_*i-g*u*i+g*n*d-e*_*d-h*n*m+e*u*m)*w,t[14]=(g*a*i-o*_*i-g*n*c+e*_*c+o*n*m-e*a*m)*w,t[15]=(o*u*i-h*a*i+h*n*c-e*u*c-o*n*d+e*a*d)*w,this}scale(t){const e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),r=1-n,o=t.x,a=t.y,c=t.z,l=r*o,h=r*a;return this.set(l*o+n,l*a-i*c,l*c+i*a,0,l*a+i*c,h*a+n,h*c-i*o,0,l*c-i*a,h*c+i*o,r*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,o){return this.set(1,n,r,0,t,1,o,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,r=e._x,o=e._y,a=e._z,c=e._w,l=r+r,h=o+o,u=a+a,d=r*l,f=r*h,g=r*u,_=o*h,m=o*u,p=a*u,T=c*l,b=c*h,E=c*u,L=n.x,R=n.y,w=n.z;return i[0]=(1-(_+p))*L,i[1]=(f+E)*L,i[2]=(g-b)*L,i[3]=0,i[4]=(f-E)*R,i[5]=(1-(d+p))*R,i[6]=(m+T)*R,i[7]=0,i[8]=(g+b)*w,i[9]=(m-T)*w,i[10]=(1-(d+_))*w,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let r=Ai.set(i[0],i[1],i[2]).length();const o=Ai.set(i[4],i[5],i[6]).length(),a=Ai.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],fn.copy(this);const l=1/r,h=1/o,u=1/a;return fn.elements[0]*=l,fn.elements[1]*=l,fn.elements[2]*=l,fn.elements[4]*=h,fn.elements[5]*=h,fn.elements[6]*=h,fn.elements[8]*=u,fn.elements[9]*=u,fn.elements[10]*=u,e.setFromRotationMatrix(fn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,i,r,o,a=En,c=!1){const l=this.elements,h=2*r/(e-t),u=2*r/(n-i),d=(e+t)/(e-t),f=(n+i)/(n-i);let g,_;if(c)g=r/(o-r),_=o*r/(o-r);else if(a===En)g=-(o+r)/(o-r),_=-2*o*r/(o-r);else if(a===lr)g=-o/(o-r),_=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=u,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=g,l[14]=_,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,o,a=En,c=!1){const l=this.elements,h=2/(e-t),u=2/(n-i),d=-(e+t)/(e-t),f=-(n+i)/(n-i);let g,_;if(c)g=1/(o-r),_=o/(o-r);else if(a===En)g=-2/(o-r),_=-(o+r)/(o-r);else if(a===lr)g=-1/(o-r),_=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=0,l[12]=d,l[1]=0,l[5]=u,l[9]=0,l[13]=f,l[2]=0,l[6]=0,l[10]=g,l[14]=_,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const Ai=new F,fn=new Ee,$h=new F(0,0,0),Zh=new F(1,1,1),Xn=new F,Cs=new F,je=new F,qa=new Ee,Ya=new gs;class kn{constructor(t=0,e=0,n=0,i=kn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,r=i[0],o=i[4],a=i[8],c=i[1],l=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(Qt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Qt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Qt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Qt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(Qt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Qt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return qa.makeRotationFromQuaternion(t),this.setFromRotationMatrix(qa,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Ya.setFromEuler(this),this.setFromQuaternion(Ya,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}kn.DEFAULT_ORDER="XYZ";class cc{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let jh=0;const Ka=new F,wi=new gs,Rn=new Ee,Ds=new F,es=new F,Jh=new F,Qh=new gs,$a=new F(1,0,0),Za=new F(0,1,0),ja=new F(0,0,1),Ja={type:"added"},tu={type:"removed"},Ri={type:"childadded",child:null},Or={type:"childremoved",child:null};class He extends Xi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:jh++}),this.uuid=ms(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=He.DEFAULT_UP.clone();const t=new F,e=new kn,n=new gs,i=new F(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Ee},normalMatrix:{value:new Xt}}),this.matrix=new Ee,this.matrixWorld=new Ee,this.matrixAutoUpdate=He.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=He.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new cc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return wi.setFromAxisAngle(t,e),this.quaternion.multiply(wi),this}rotateOnWorldAxis(t,e){return wi.setFromAxisAngle(t,e),this.quaternion.premultiply(wi),this}rotateX(t){return this.rotateOnAxis($a,t)}rotateY(t){return this.rotateOnAxis(Za,t)}rotateZ(t){return this.rotateOnAxis(ja,t)}translateOnAxis(t,e){return Ka.copy(t).applyQuaternion(this.quaternion),this.position.add(Ka.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis($a,t)}translateY(t){return this.translateOnAxis(Za,t)}translateZ(t){return this.translateOnAxis(ja,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Rn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Ds.copy(t):Ds.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),es.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Rn.lookAt(es,Ds,this.up):Rn.lookAt(Ds,es,this.up),this.quaternion.setFromRotationMatrix(Rn),i&&(Rn.extractRotation(i.matrixWorld),wi.setFromRotationMatrix(Rn),this.quaternion.premultiply(wi.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Ja),Ri.child=t,this.dispatchEvent(Ri),Ri.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(tu),Or.child=t,this.dispatchEvent(Or),Or.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Rn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Rn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Rn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Ja),Ri.child=t,this.dispatchEvent(Ri),Ri.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(es,t,Jh),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(es,Qh,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(a=>({...a})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(t.materials,this.material[c]));i.material=a}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];i.animations.push(r(t.animations,c))}}if(e){const a=o(t.geometries),c=o(t.materials),l=o(t.textures),h=o(t.images),u=o(t.shapes),d=o(t.skeletons),f=o(t.animations),g=o(t.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=i,n;function o(a){const c=[];for(const l in a){const h=a[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}He.DEFAULT_UP=new F(0,1,0);He.DEFAULT_MATRIX_AUTO_UPDATE=!0;He.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const pn=new F,Cn=new F,Fr=new F,Dn=new F,Ci=new F,Di=new F,Qa=new F,Br=new F,kr=new F,zr=new F,Hr=new Se,Gr=new Se,Vr=new Se;class ln{constructor(t=new F,e=new F,n=new F){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),pn.subVectors(t,e),i.cross(pn);const r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){pn.subVectors(i,e),Cn.subVectors(n,e),Fr.subVectors(t,e);const o=pn.dot(pn),a=pn.dot(Cn),c=pn.dot(Fr),l=Cn.dot(Cn),h=Cn.dot(Fr),u=o*l-a*a;if(u===0)return r.set(0,0,0),null;const d=1/u,f=(l*c-a*h)*d,g=(o*h-a*c)*d;return r.set(1-f-g,g,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Dn)===null?!1:Dn.x>=0&&Dn.y>=0&&Dn.x+Dn.y<=1}static getInterpolation(t,e,n,i,r,o,a,c){return this.getBarycoord(t,e,n,i,Dn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Dn.x),c.addScaledVector(o,Dn.y),c.addScaledVector(a,Dn.z),c)}static getInterpolatedAttribute(t,e,n,i,r,o){return Hr.setScalar(0),Gr.setScalar(0),Vr.setScalar(0),Hr.fromBufferAttribute(t,e),Gr.fromBufferAttribute(t,n),Vr.fromBufferAttribute(t,i),o.setScalar(0),o.addScaledVector(Hr,r.x),o.addScaledVector(Gr,r.y),o.addScaledVector(Vr,r.z),o}static isFrontFacing(t,e,n,i){return pn.subVectors(n,e),Cn.subVectors(t,e),pn.cross(Cn).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return pn.subVectors(this.c,this.b),Cn.subVectors(this.a,this.b),pn.cross(Cn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return ln.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return ln.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return ln.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return ln.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return ln.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,r=this.c;let o,a;Ci.subVectors(i,n),Di.subVectors(r,n),Br.subVectors(t,n);const c=Ci.dot(Br),l=Di.dot(Br);if(c<=0&&l<=0)return e.copy(n);kr.subVectors(t,i);const h=Ci.dot(kr),u=Di.dot(kr);if(h>=0&&u<=h)return e.copy(i);const d=c*u-h*l;if(d<=0&&c>=0&&h<=0)return o=c/(c-h),e.copy(n).addScaledVector(Ci,o);zr.subVectors(t,r);const f=Ci.dot(zr),g=Di.dot(zr);if(g>=0&&f<=g)return e.copy(r);const _=f*l-c*g;if(_<=0&&l>=0&&g<=0)return a=l/(l-g),e.copy(n).addScaledVector(Di,a);const m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return Qa.subVectors(r,i),a=(u-h)/(u-h+(f-g)),e.copy(i).addScaledVector(Qa,a);const p=1/(m+_+d);return o=_*p,a=d*p,e.copy(n).addScaledVector(Ci,o).addScaledVector(Di,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const hc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},qn={h:0,s:0,l:0},Ls={h:0,s:0,l:0};function Wr(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}class qt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=tn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,re.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=re.workingColorSpace){return this.r=t,this.g=e,this.b=n,re.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=re.workingColorSpace){if(t=kh(t,1),e=Qt(e,0,1),n=Qt(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Wr(o,r,t+1/3),this.g=Wr(o,r,t),this.b=Wr(o,r,t-1/3)}return re.colorSpaceToWorking(this,i),this}setStyle(t,e=tn){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=i[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=tn){const n=hc[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=On(t.r),this.g=On(t.g),this.b=On(t.b),this}copyLinearToSRGB(t){return this.r=Fi(t.r),this.g=Fi(t.g),this.b=Fi(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=tn){return re.workingToColorSpace(Oe.copy(this),t),Math.round(Qt(Oe.r*255,0,255))*65536+Math.round(Qt(Oe.g*255,0,255))*256+Math.round(Qt(Oe.b*255,0,255))}getHexString(t=tn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=re.workingColorSpace){re.workingToColorSpace(Oe.copy(this),e);const n=Oe.r,i=Oe.g,r=Oe.b,o=Math.max(n,i,r),a=Math.min(n,i,r);let c,l;const h=(a+o)/2;if(a===o)c=0,l=0;else{const u=o-a;switch(l=h<=.5?u/(o+a):u/(2-o-a),o){case n:c=(i-r)/u+(i<r?6:0);break;case i:c=(r-n)/u+2;break;case r:c=(n-i)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=re.workingColorSpace){return re.workingToColorSpace(Oe.copy(this),e),t.r=Oe.r,t.g=Oe.g,t.b=Oe.b,t}getStyle(t=tn){re.workingToColorSpace(Oe.copy(this),t);const e=Oe.r,n=Oe.g,i=Oe.b;return t!==tn?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(qn),this.setHSL(qn.h+t,qn.s+e,qn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(qn),t.getHSL(Ls);const n=Ar(qn.h,Ls.h,e),i=Ar(qn.s,Ls.s,e),r=Ar(qn.l,Ls.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Oe=new qt;qt.NAMES=hc;let eu=0;class Yi extends Xi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:eu++}),this.uuid=ms(),this.name="",this.type="Material",this.blending=Oi,this.side=Fn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ao,this.blendDst=lo,this.blendEquation=ui,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new qt(0,0,0),this.blendAlpha=0,this.depthFunc=ki,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=za,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Si,this.stencilZFail=Si,this.stencilZPass=Si,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Oi&&(n.blending=this.blending),this.side!==Fn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==ao&&(n.blendSrc=this.blendSrc),this.blendDst!==lo&&(n.blendDst=this.blendDst),this.blendEquation!==ui&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ki&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==za&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Si&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Si&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Si&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(e){const r=i(t.textures),o=i(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class vi extends Yi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new qt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new kn,this.combine=jl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const ye=new F,Ps=new he;let nu=0;class Fe{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:nu++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Ha,this.updateRanges=[],this.gpuType=Nn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Ps.fromBufferAttribute(this,e),Ps.applyMatrix3(t),this.setXY(e,Ps.x,Ps.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyMatrix3(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyMatrix4(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.applyNormalMatrix(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ye.fromBufferAttribute(this,e),ye.transformDirection(t),this.setXYZ(e,ye.x,ye.y,ye.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ji(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Xe(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ji(e,this.array)),e}setX(t,e){return this.normalized&&(e=Xe(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ji(e,this.array)),e}setY(t,e){return this.normalized&&(e=Xe(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ji(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Xe(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ji(e,this.array)),e}setW(t,e){return this.normalized&&(e=Xe(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Xe(e,this.array),n=Xe(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=Xe(e,this.array),n=Xe(n,this.array),i=Xe(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=Xe(e,this.array),n=Xe(n,this.array),i=Xe(i,this.array),r=Xe(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Ha&&(t.usage=this.usage),t}}class uc extends Fe{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class dc extends Fe{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class yn extends Fe{constructor(t,e,n){super(new Float32Array(t),e,n)}}let iu=0;const sn=new Ee,Xr=new He,Li=new F,Je=new _s,ns=new _s,Le=new F;class un extends Xi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:iu++}),this.uuid=ms(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(lc(t)?dc:uc)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Xt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return sn.makeRotationFromQuaternion(t),this.applyMatrix4(sn),this}rotateX(t){return sn.makeRotationX(t),this.applyMatrix4(sn),this}rotateY(t){return sn.makeRotationY(t),this.applyMatrix4(sn),this}rotateZ(t){return sn.makeRotationZ(t),this.applyMatrix4(sn),this}translate(t,e,n){return sn.makeTranslation(t,e,n),this.applyMatrix4(sn),this}scale(t,e,n){return sn.makeScale(t,e,n),this.applyMatrix4(sn),this}lookAt(t){return Xr.lookAt(t),Xr.updateMatrix(),this.applyMatrix4(Xr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Li).negate(),this.translate(Li.x,Li.y,Li.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let i=0,r=t.length;i<r;i++){const o=t[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new yn(n,3))}else{const n=Math.min(t.length,e.count);for(let i=0;i<n;i++){const r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new _s);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new F(-1/0,-1/0,-1/0),new F(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const r=e[n];Je.setFromBufferAttribute(r),this.morphTargetsRelative?(Le.addVectors(this.boundingBox.min,Je.min),this.boundingBox.expandByPoint(Le),Le.addVectors(this.boundingBox.max,Je.max),this.boundingBox.expandByPoint(Le)):(this.boundingBox.expandByPoint(Je.min),this.boundingBox.expandByPoint(Je.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new qi);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new F,1/0);return}if(t){const n=this.boundingSphere.center;if(Je.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){const a=e[r];ns.setFromBufferAttribute(a),this.morphTargetsRelative?(Le.addVectors(Je.min,ns.min),Je.expandByPoint(Le),Le.addVectors(Je.max,ns.max),Je.expandByPoint(Le)):(Je.expandByPoint(ns.min),Je.expandByPoint(ns.max))}Je.getCenter(n);let i=0;for(let r=0,o=t.count;r<o;r++)Le.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Le));if(e)for(let r=0,o=e.length;r<o;r++){const a=e[r],c=this.morphTargetsRelative;for(let l=0,h=a.count;l<h;l++)Le.fromBufferAttribute(a,l),c&&(Li.fromBufferAttribute(t,l),Le.add(Li)),i=Math.max(i,n.distanceToSquared(Le))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Fe(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let O=0;O<n.count;O++)a[O]=new F,c[O]=new F;const l=new F,h=new F,u=new F,d=new he,f=new he,g=new he,_=new F,m=new F;function p(O,S,M){l.fromBufferAttribute(n,O),h.fromBufferAttribute(n,S),u.fromBufferAttribute(n,M),d.fromBufferAttribute(r,O),f.fromBufferAttribute(r,S),g.fromBufferAttribute(r,M),h.sub(l),u.sub(l),f.sub(d),g.sub(d);const C=1/(f.x*g.y-g.x*f.y);isFinite(C)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(C),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(C),a[O].add(_),a[S].add(_),a[M].add(_),c[O].add(m),c[S].add(m),c[M].add(m))}let T=this.groups;T.length===0&&(T=[{start:0,count:t.count}]);for(let O=0,S=T.length;O<S;++O){const M=T[O],C=M.start,z=M.count;for(let G=C,W=C+z;G<W;G+=3)p(t.getX(G+0),t.getX(G+1),t.getX(G+2))}const b=new F,E=new F,L=new F,R=new F;function w(O){L.fromBufferAttribute(i,O),R.copy(L);const S=a[O];b.copy(S),b.sub(L.multiplyScalar(L.dot(S))).normalize(),E.crossVectors(R,S);const C=E.dot(c[O])<0?-1:1;o.setXYZW(O,b.x,b.y,b.z,C)}for(let O=0,S=T.length;O<S;++O){const M=T[O],C=M.start,z=M.count;for(let G=C,W=C+z;G<W;G+=3)w(t.getX(G+0)),w(t.getX(G+1)),w(t.getX(G+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Fe(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const i=new F,r=new F,o=new F,a=new F,c=new F,l=new F,h=new F,u=new F;if(t)for(let d=0,f=t.count;d<f;d+=3){const g=t.getX(d+0),_=t.getX(d+1),m=t.getX(d+2);i.fromBufferAttribute(e,g),r.fromBufferAttribute(e,_),o.fromBufferAttribute(e,m),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),a.fromBufferAttribute(n,g),c.fromBufferAttribute(n,_),l.fromBufferAttribute(n,m),a.add(h),c.add(h),l.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let d=0,f=e.count;d<f;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),o.fromBufferAttribute(e,d+2),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Le.fromBufferAttribute(t,e),Le.normalize(),t.setXYZ(e,Le.x,Le.y,Le.z)}toNonIndexed(){function t(a,c){const l=a.array,h=a.itemSize,u=a.normalized,d=new l.constructor(c.length*h);let f=0,g=0;for(let _=0,m=c.length;_<m;_++){a.isInterleavedBufferAttribute?f=c[_]*a.data.stride+a.offset:f=c[_]*h;for(let p=0;p<h;p++)d[g++]=l[f++]}return new Fe(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new un,n=this.index.array,i=this.attributes;for(const a in i){const c=i[a],l=t(c,n);e.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let h=0,u=l.length;h<u;h++){const d=l[h],f=t(d,n);c.push(f)}e.morphAttributes[a]=c}e.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let u=0,d=l.length;u<d;u++){const f=l[u];h.push(f.toJSON(t.data))}h.length>0&&(i[c]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const r=t.morphAttributes;for(const l in r){const h=[],u=r[l];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const o=t.groups;for(let l=0,h=o.length;l<h;l++){const u=o[l];this.addGroup(u.start,u.count,u.materialIndex)}const a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const tl=new Ee,ii=new ma,Is=new qi,el=new F,Us=new F,Ns=new F,Os=new F,qr=new F,Fs=new F,nl=new F,Bs=new F;class Ie extends He{constructor(t=new un,e=new vi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){const a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const a=this.morphTargetInfluences;if(r&&a){Fs.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const h=a[c],u=r[c];h!==0&&(qr.fromBufferAttribute(u,t),o?Fs.addScaledVector(qr,h):Fs.addScaledVector(qr.sub(e),h))}e.add(Fs)}return e}raycast(t,e){const n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Is.copy(n.boundingSphere),Is.applyMatrix4(r),ii.copy(t.ray).recast(t.near),!(Is.containsPoint(ii.origin)===!1&&(ii.intersectSphere(Is,el)===null||ii.origin.distanceToSquared(el)>(t.far-t.near)**2))&&(tl.copy(r).invert(),ii.copy(t.ray).applyMatrix4(tl),!(n.boundingBox!==null&&ii.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ii)))}_computeIntersections(t,e,n){let i;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],T=Math.max(m.start,f.start),b=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let E=T,L=b;E<L;E+=3){const R=a.getX(E),w=a.getX(E+1),O=a.getX(E+2);i=ks(this,p,t,n,l,h,u,R,w,O),i&&(i.faceIndex=Math.floor(E/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const T=a.getX(m),b=a.getX(m+1),E=a.getX(m+2);i=ks(this,o,t,n,l,h,u,T,b,E),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],T=Math.max(m.start,f.start),b=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let E=T,L=b;E<L;E+=3){const R=E,w=E+1,O=E+2;i=ks(this,p,t,n,l,h,u,R,w,O),i&&(i.faceIndex=Math.floor(E/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),_=Math.min(c.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const T=m,b=m+1,E=m+2;i=ks(this,o,t,n,l,h,u,T,b,E),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function su(s,t,e,n,i,r,o,a){let c;if(t.side===qe?c=n.intersectTriangle(o,r,i,!0,a):c=n.intersectTriangle(i,r,o,t.side===Fn,a),c===null)return null;Bs.copy(a),Bs.applyMatrix4(s.matrixWorld);const l=e.ray.origin.distanceTo(Bs);return l<e.near||l>e.far?null:{distance:l,point:Bs.clone(),object:s}}function ks(s,t,e,n,i,r,o,a,c,l){s.getVertexPosition(a,Us),s.getVertexPosition(c,Ns),s.getVertexPosition(l,Os);const h=su(s,t,e,n,Us,Ns,Os,nl);if(h){const u=new F;ln.getBarycoord(nl,Us,Ns,Os,u),i&&(h.uv=ln.getInterpolatedAttribute(i,a,c,l,u,new he)),r&&(h.uv1=ln.getInterpolatedAttribute(r,a,c,l,u,new he)),o&&(h.normal=ln.getInterpolatedAttribute(o,a,c,l,u,new F),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:c,c:l,normal:new F,materialIndex:0};ln.getNormal(Us,Ns,Os,d.normal),h.face=d,h.barycoord=u}return h}class zn extends un{constructor(t=1,e=1,n=1,i=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:o};const a=this;i=Math.floor(i),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],h=[],u=[];let d=0,f=0;g("z","y","x",-1,-1,n,e,t,o,r,0),g("z","y","x",1,-1,n,e,-t,o,r,1),g("x","z","y",1,1,t,n,e,i,o,2),g("x","z","y",1,-1,t,n,-e,i,o,3),g("x","y","z",1,-1,t,e,n,i,r,4),g("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(c),this.setAttribute("position",new yn(l,3)),this.setAttribute("normal",new yn(h,3)),this.setAttribute("uv",new yn(u,2));function g(_,m,p,T,b,E,L,R,w,O,S){const M=E/w,C=L/O,z=E/2,G=L/2,W=R/2,K=w+1,H=O+1;let rt=0,V=0;const ht=new F;for(let ut=0;ut<H;ut++){const _t=ut*C-G;for(let Bt=0;Bt<K;Bt++){const Yt=Bt*M-z;ht[_]=Yt*T,ht[m]=_t*b,ht[p]=W,l.push(ht.x,ht.y,ht.z),ht[_]=0,ht[m]=0,ht[p]=R>0?1:-1,h.push(ht.x,ht.y,ht.z),u.push(Bt/w),u.push(1-ut/O),rt+=1}}for(let ut=0;ut<O;ut++)for(let _t=0;_t<w;_t++){const Bt=d+_t+K*ut,Yt=d+_t+K*(ut+1),jt=d+(_t+1)+K*(ut+1),ne=d+(_t+1)+K*ut;c.push(Bt,Yt,ne),c.push(Yt,jt,ne),V+=6}a.addGroup(f,V,S),f+=V,d+=rt}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new zn(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Vi(s){const t={};for(const e in s){t[e]={};for(const n in s[e]){const i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function ke(s){const t={};for(let e=0;e<s.length;e++){const n=Vi(s[e]);for(const i in n)t[i]=n[i]}return t}function ru(s){const t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function fc(s){const t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:re.workingColorSpace}const ou={clone:Vi,merge:ke};var au=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,lu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Hn extends Yi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=au,this.fragmentShader=lu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Vi(t.uniforms),this.uniformsGroups=ru(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const o=this.uniforms[i].value;o&&o.isTexture?e.uniforms[i]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[i]={type:"m4",value:o.toArray()}:e.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class pc extends He{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ee,this.projectionMatrix=new Ee,this.projectionMatrixInverse=new Ee,this.coordinateSystem=En,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Yn=new F,il=new he,sl=new he;class on extends pc{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Ko*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(nr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Ko*2*Math.atan(Math.tan(nr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Yn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Yn.x,Yn.y).multiplyScalar(-t/Yn.z),Yn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Yn.x,Yn.y).multiplyScalar(-t/Yn.z)}getViewSize(t,e){return this.getViewBounds(t,il,sl),e.subVectors(sl,il)}setViewOffset(t,e,n,i,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(nr*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*i/c,e-=o.offsetY*n/l,i*=o.width/c,n*=o.height/l}const a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const Pi=-90,Ii=1;class cu extends He{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new on(Pi,Ii,t,e);i.layers=this.layers,this.add(i);const r=new on(Pi,Ii,t,e);r.layers=this.layers,this.add(r);const o=new on(Pi,Ii,t,e);o.layers=this.layers,this.add(o);const a=new on(Pi,Ii,t,e);a.layers=this.layers,this.add(a);const c=new on(Pi,Ii,t,e);c.layers=this.layers,this.add(c);const l=new on(Pi,Ii,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,r,o,a,c]=e;for(const l of e)this.remove(l);if(t===En)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===lr)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,o),t.setRenderTarget(n,2,i),t.render(e,a),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=_,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class mc extends ze{constructor(t=[],e=zi,n,i,r,o,a,c,l,h){super(t,e,n,i,r,o,a,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class hu extends _i{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new mc(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new zn(5,5,5),r=new Hn({name:"CubemapFromEquirect",uniforms:Vi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:qe,blending:$n});r.uniforms.tEquirect.value=e;const o=new Ie(i,r),a=e.minFilter;return e.minFilter===fi&&(e.minFilter=Sn),new cu(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){const r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,i);t.setRenderTarget(r)}}class pi extends He{constructor(){super(),this.isGroup=!0,this.type="Group"}}const uu={type:"move"};class Yr{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new pi,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new pi,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new F,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new F),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new pi,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new F,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new F),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){o=!0;for(const _ of t.hand.values()){const m=e.getJointPose(_,n),p=this._getHandJoint(l,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;l.inputState.pinching&&d>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&d<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(uu)))}return a!==null&&(a.visible=i!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new pi;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class du extends He{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new kn,this.environmentIntensity=1,this.environmentRotation=new kn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}const Kr=new F,fu=new F,pu=new Xt;class li{constructor(t=new F(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Kr.subVectors(n,e).cross(fu.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Kr),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||pu.getNormalMatrix(t),i=this.coplanarPoint(Kr).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const si=new qi,mu=new he(.5,.5),zs=new F;class gc{constructor(t=new li,e=new li,n=new li,i=new li,r=new li,o=new li){this.planes=[t,e,n,i,r,o]}set(t,e,n,i,r,o){const a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(i),a[4].copy(r),a[5].copy(o),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=En,n=!1){const i=this.planes,r=t.elements,o=r[0],a=r[1],c=r[2],l=r[3],h=r[4],u=r[5],d=r[6],f=r[7],g=r[8],_=r[9],m=r[10],p=r[11],T=r[12],b=r[13],E=r[14],L=r[15];if(i[0].setComponents(l-o,f-h,p-g,L-T).normalize(),i[1].setComponents(l+o,f+h,p+g,L+T).normalize(),i[2].setComponents(l+a,f+u,p+_,L+b).normalize(),i[3].setComponents(l-a,f-u,p-_,L-b).normalize(),n)i[4].setComponents(c,d,m,E).normalize(),i[5].setComponents(l-c,f-d,p-m,L-E).normalize();else if(i[4].setComponents(l-c,f-d,p-m,L-E).normalize(),e===En)i[5].setComponents(l+c,f+d,p+m,L+E).normalize();else if(e===lr)i[5].setComponents(c,d,m,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),si.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),si.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(si)}intersectsSprite(t){si.center.set(0,0,0);const e=mu.distanceTo(t.center);return si.radius=.7071067811865476+e,si.applyMatrix4(t.matrixWorld),this.intersectsSphere(si)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(zs.x=i.normal.x>0?t.max.x:t.min.x,zs.y=i.normal.y>0?t.max.y:t.min.y,zs.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(zs)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class _c extends Yi{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new qt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const hr=new F,ur=new F,rl=new Ee,is=new ma,Hs=new qi,$r=new F,ol=new F;class gu extends He{constructor(t=new un,e=new _c){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let i=1,r=e.count;i<r;i++)hr.fromBufferAttribute(e,i-1),ur.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=hr.distanceTo(ur);t.setAttribute("lineDistance",new yn(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Hs.copy(n.boundingSphere),Hs.applyMatrix4(i),Hs.radius+=r,t.ray.intersectsSphere(Hs)===!1)return;rl.copy(i).invert(),is.copy(t.ray).applyMatrix4(rl);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){const f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=l){const p=h.getX(_),T=h.getX(_+1),b=Gs(this,t,is,c,p,T,_);b&&e.push(b)}if(this.isLineLoop){const _=h.getX(g-1),m=h.getX(f),p=Gs(this,t,is,c,_,m,g-1);p&&e.push(p)}}else{const f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=l){const p=Gs(this,t,is,c,_,_+1,_);p&&e.push(p)}if(this.isLineLoop){const _=Gs(this,t,is,c,g-1,f,g-1);_&&e.push(_)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){const a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function Gs(s,t,e,n,i,r,o){const a=s.geometry.attributes.position;if(hr.fromBufferAttribute(a,i),ur.fromBufferAttribute(a,r),e.distanceSqToSegment(hr,ur,$r,ol)>n)return;$r.applyMatrix4(s.matrixWorld);const l=t.ray.origin.distanceTo($r);if(!(l<t.near||l>t.far))return{distance:l,point:ol.clone().applyMatrix4(s.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:s}}const al=new F,ll=new F;class _u extends gu{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let i=0,r=e.count;i<r;i+=2)al.fromBufferAttribute(e,i),ll.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+al.distanceTo(ll);t.setAttribute("lineDistance",new yn(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class vc extends Yi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new qt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const cl=new Ee,$o=new ma,Vs=new qi,Ws=new F;class vu extends He{constructor(t=new un,e=new vc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,r=t.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Vs.copy(n.boundingSphere),Vs.applyMatrix4(i),Vs.radius+=r,t.ray.intersectsSphere(Vs)===!1)return;cl.copy(i).invert(),$o.copy(t.ray).applyMatrix4(cl);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=n.index,u=n.attributes.position;if(l!==null){const d=Math.max(0,o.start),f=Math.min(l.count,o.start+o.count);for(let g=d,_=f;g<_;g++){const m=l.getX(g);Ws.fromBufferAttribute(u,m),hl(Ws,m,c,i,t,e,this)}}else{const d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let g=d,_=f;g<_;g++)Ws.fromBufferAttribute(u,g),hl(Ws,g,c,i,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){const a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function hl(s,t,e,n,i,r,o){const a=$o.distanceSqToPoint(s);if(a<e){const c=new F;$o.closestPointToPoint(s,c),c.applyMatrix4(n);const l=i.ray.origin.distanceTo(c);if(l<i.near||l>i.far)return;r.push({distance:l,distanceToRay:Math.sqrt(a),point:c,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}class gr extends ze{constructor(t,e,n,i,r,o,a,c,l){super(t,e,n,i,r,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class xc extends ze{constructor(t,e,n=gi,i,r,o,a=be,c=be,l,h=us,u=1){if(h!==us&&h!==ds)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:t,height:e,depth:u};super(d,i,r,o,a,c,h,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new fa(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}class Mc extends ze{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}const Xs=new F,qs=new F,Zr=new F,Ys=new ln;class xu extends un{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){const i=Math.pow(10,4),r=Math.cos(nr*e),o=t.getIndex(),a=t.getAttribute("position"),c=o?o.count:a.count,l=[0,0,0],h=["a","b","c"],u=new Array(3),d={},f=[];for(let g=0;g<c;g+=3){o?(l[0]=o.getX(g),l[1]=o.getX(g+1),l[2]=o.getX(g+2)):(l[0]=g,l[1]=g+1,l[2]=g+2);const{a:_,b:m,c:p}=Ys;if(_.fromBufferAttribute(a,l[0]),m.fromBufferAttribute(a,l[1]),p.fromBufferAttribute(a,l[2]),Ys.getNormal(Zr),u[0]=`${Math.round(_.x*i)},${Math.round(_.y*i)},${Math.round(_.z*i)}`,u[1]=`${Math.round(m.x*i)},${Math.round(m.y*i)},${Math.round(m.z*i)}`,u[2]=`${Math.round(p.x*i)},${Math.round(p.y*i)},${Math.round(p.z*i)}`,!(u[0]===u[1]||u[1]===u[2]||u[2]===u[0]))for(let T=0;T<3;T++){const b=(T+1)%3,E=u[T],L=u[b],R=Ys[h[T]],w=Ys[h[b]],O=`${E}_${L}`,S=`${L}_${E}`;S in d&&d[S]?(Zr.dot(d[S].normal)<=r&&(f.push(R.x,R.y,R.z),f.push(w.x,w.y,w.z)),d[S]=null):O in d||(d[O]={index0:l[T],index1:l[b],normal:Zr.clone()})}}for(const g in d)if(d[g]){const{index0:_,index1:m}=d[g];Xs.fromBufferAttribute(a,_),qs.fromBufferAttribute(a,m),f.push(Xs.x,Xs.y,Xs.z),f.push(qs.x,qs.y,qs.z)}this.setAttribute("position",new yn(f,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}}class jn extends un{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const r=t/2,o=e/2,a=Math.floor(n),c=Math.floor(i),l=a+1,h=c+1,u=t/a,d=e/c,f=[],g=[],_=[],m=[];for(let p=0;p<h;p++){const T=p*d-o;for(let b=0;b<l;b++){const E=b*u-r;g.push(E,-T,0),_.push(0,0,1),m.push(b/a),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let T=0;T<a;T++){const b=T+l*p,E=T+l*(p+1),L=T+1+l*(p+1),R=T+1+l*p;f.push(b,E,R),f.push(E,L,R)}this.setIndex(f),this.setAttribute("position",new yn(g,3)),this.setAttribute("normal",new yn(_,3)),this.setAttribute("uv",new yn(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new jn(t.width,t.height,t.widthSegments,t.heightSegments)}}class ul extends Hn{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Mu extends Yi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Rh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Su extends Yi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class Eu extends pc{constructor(t=-1,e=1,n=1,i=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let r=n-t,o=n+t,a=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=h*this.view.offsetY,c=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class yu extends on{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}function dl(s,t,e,n){const i=Tu(n);switch(e){case ic:return s*t;case rc:return s*t/i.components*i.byteLength;case ha:return s*t/i.components*i.byteLength;case oc:return s*t*2/i.components*i.byteLength;case ua:return s*t*2/i.components*i.byteLength;case sc:return s*t*3/i.components*i.byteLength;case cn:return s*t*4/i.components*i.byteLength;case da:return s*t*4/i.components*i.byteLength;case Js:case Qs:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case tr:case er:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case So:case yo:return Math.max(s,16)*Math.max(t,8)/4;case Mo:case Eo:return Math.max(s,8)*Math.max(t,8)/2;case To:case bo:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Ao:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case wo:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Ro:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Co:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case Do:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case Lo:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case Po:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case Io:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case Uo:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case No:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case Oo:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case Fo:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case Bo:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case ko:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case zo:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case Ho:case Go:case Vo:return Math.ceil(s/4)*Math.ceil(t/4)*16;case Wo:case Xo:return Math.ceil(s/4)*Math.ceil(t/4)*8;case qo:case Yo:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Tu(s){switch(s){case Bn:case Ql:return{byteLength:1,components:1};case cs:case tc:case ps:return{byteLength:2,components:1};case la:case ca:return{byteLength:2,components:4};case gi:case aa:case Nn:return{byteLength:4,components:1};case ec:case nc:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:oa}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=oa);function Sc(){let s=null,t=!1,e=null,n=null;function i(r,o){e(r,o),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function bu(s){const t=new WeakMap;function e(a,c){const l=a.array,h=a.usage,u=l.byteLength,d=s.createBuffer();s.bindBuffer(c,d),s.bufferData(c,l,h),a.onUploadCallback();let f;if(l instanceof Float32Array)f=s.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)f=s.HALF_FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?f=s.HALF_FLOAT:f=s.UNSIGNED_SHORT;else if(l instanceof Int16Array)f=s.SHORT;else if(l instanceof Uint32Array)f=s.UNSIGNED_INT;else if(l instanceof Int32Array)f=s.INT;else if(l instanceof Int8Array)f=s.BYTE;else if(l instanceof Uint8Array)f=s.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)f=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:d,type:f,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,c,l){const h=c.array,u=c.updateRanges;if(s.bindBuffer(l,a),u.length===0)s.bufferSubData(l,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){const g=u[d],_=u[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++d,u[d]=_)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){const _=u[f];s.bufferSubData(l,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}c.clearUpdateRanges()}c.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=t.get(a);c&&(s.deleteBuffer(c.buffer),t.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=t.get(a);if(l===void 0)t.set(a,e(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:i,remove:r,update:o}}var Au=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,wu=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Ru=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Cu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Du=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Lu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Pu=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Iu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Uu=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Nu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Ou=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Fu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Bu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ku=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,zu=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Hu=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Gu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Vu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Wu=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Xu=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,qu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Yu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ku=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,$u=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Zu=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,ju=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Ju=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Qu=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,td=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ed=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,nd="gl_FragColor = linearToOutputTexel( gl_FragColor );",id=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,sd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,rd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,od=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,ad=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,ld=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,cd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,hd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ud=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,dd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,fd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,pd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,md=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,gd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,_d=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,vd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,xd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Md=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Sd=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ed=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,yd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Td=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,bd=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Ad=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,wd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Rd=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Cd=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Dd=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ld=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Pd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Id=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ud=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Nd=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Od=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Fd=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Bd=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,kd=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,zd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Hd=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Gd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Vd=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Wd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Xd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,qd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Yd=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Kd=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,$d=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Zd=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,jd=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Jd=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Qd=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,tf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,ef=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,nf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,sf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,rf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,of=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,af=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,lf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,cf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,hf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,uf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,df=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ff=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,pf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,mf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,gf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,_f=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,vf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,xf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Mf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Sf=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ef=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Tf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,bf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Af=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,wf=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Rf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Cf=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Df=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Lf=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,If=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Uf=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Nf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Of=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Ff=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bf=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,kf=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,zf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Hf=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gf=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vf=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wf=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Xf=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qf=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Yf=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Kf=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,$f=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zf=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,jf=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jf=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Qf=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ep=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,np=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ip=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,sp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,rp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Zt={alphahash_fragment:Au,alphahash_pars_fragment:wu,alphamap_fragment:Ru,alphamap_pars_fragment:Cu,alphatest_fragment:Du,alphatest_pars_fragment:Lu,aomap_fragment:Pu,aomap_pars_fragment:Iu,batching_pars_vertex:Uu,batching_vertex:Nu,begin_vertex:Ou,beginnormal_vertex:Fu,bsdfs:Bu,iridescence_fragment:ku,bumpmap_pars_fragment:zu,clipping_planes_fragment:Hu,clipping_planes_pars_fragment:Gu,clipping_planes_pars_vertex:Vu,clipping_planes_vertex:Wu,color_fragment:Xu,color_pars_fragment:qu,color_pars_vertex:Yu,color_vertex:Ku,common:$u,cube_uv_reflection_fragment:Zu,defaultnormal_vertex:ju,displacementmap_pars_vertex:Ju,displacementmap_vertex:Qu,emissivemap_fragment:td,emissivemap_pars_fragment:ed,colorspace_fragment:nd,colorspace_pars_fragment:id,envmap_fragment:sd,envmap_common_pars_fragment:rd,envmap_pars_fragment:od,envmap_pars_vertex:ad,envmap_physical_pars_fragment:vd,envmap_vertex:ld,fog_vertex:cd,fog_pars_vertex:hd,fog_fragment:ud,fog_pars_fragment:dd,gradientmap_pars_fragment:fd,lightmap_pars_fragment:pd,lights_lambert_fragment:md,lights_lambert_pars_fragment:gd,lights_pars_begin:_d,lights_toon_fragment:xd,lights_toon_pars_fragment:Md,lights_phong_fragment:Sd,lights_phong_pars_fragment:Ed,lights_physical_fragment:yd,lights_physical_pars_fragment:Td,lights_fragment_begin:bd,lights_fragment_maps:Ad,lights_fragment_end:wd,logdepthbuf_fragment:Rd,logdepthbuf_pars_fragment:Cd,logdepthbuf_pars_vertex:Dd,logdepthbuf_vertex:Ld,map_fragment:Pd,map_pars_fragment:Id,map_particle_fragment:Ud,map_particle_pars_fragment:Nd,metalnessmap_fragment:Od,metalnessmap_pars_fragment:Fd,morphinstance_vertex:Bd,morphcolor_vertex:kd,morphnormal_vertex:zd,morphtarget_pars_vertex:Hd,morphtarget_vertex:Gd,normal_fragment_begin:Vd,normal_fragment_maps:Wd,normal_pars_fragment:Xd,normal_pars_vertex:qd,normal_vertex:Yd,normalmap_pars_fragment:Kd,clearcoat_normal_fragment_begin:$d,clearcoat_normal_fragment_maps:Zd,clearcoat_pars_fragment:jd,iridescence_pars_fragment:Jd,opaque_fragment:Qd,packing:tf,premultiplied_alpha_fragment:ef,project_vertex:nf,dithering_fragment:sf,dithering_pars_fragment:rf,roughnessmap_fragment:of,roughnessmap_pars_fragment:af,shadowmap_pars_fragment:lf,shadowmap_pars_vertex:cf,shadowmap_vertex:hf,shadowmask_pars_fragment:uf,skinbase_vertex:df,skinning_pars_vertex:ff,skinning_vertex:pf,skinnormal_vertex:mf,specularmap_fragment:gf,specularmap_pars_fragment:_f,tonemapping_fragment:vf,tonemapping_pars_fragment:xf,transmission_fragment:Mf,transmission_pars_fragment:Sf,uv_pars_fragment:Ef,uv_pars_vertex:yf,uv_vertex:Tf,worldpos_vertex:bf,background_vert:Af,background_frag:wf,backgroundCube_vert:Rf,backgroundCube_frag:Cf,cube_vert:Df,cube_frag:Lf,depth_vert:Pf,depth_frag:If,distanceRGBA_vert:Uf,distanceRGBA_frag:Nf,equirect_vert:Of,equirect_frag:Ff,linedashed_vert:Bf,linedashed_frag:kf,meshbasic_vert:zf,meshbasic_frag:Hf,meshlambert_vert:Gf,meshlambert_frag:Vf,meshmatcap_vert:Wf,meshmatcap_frag:Xf,meshnormal_vert:qf,meshnormal_frag:Yf,meshphong_vert:Kf,meshphong_frag:$f,meshphysical_vert:Zf,meshphysical_frag:jf,meshtoon_vert:Jf,meshtoon_frag:Qf,points_vert:tp,points_frag:ep,shadow_vert:np,shadow_frag:ip,sprite_vert:sp,sprite_frag:rp},dt={common:{diffuse:{value:new qt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xt}},envmap:{envMap:{value:null},envMapRotation:{value:new Xt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xt},normalScale:{value:new he(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new qt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new qt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0},uvTransform:{value:new Xt}},sprite:{diffuse:{value:new qt(16777215)},opacity:{value:1},center:{value:new he(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}}},Mn={basic:{uniforms:ke([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.fog]),vertexShader:Zt.meshbasic_vert,fragmentShader:Zt.meshbasic_frag},lambert:{uniforms:ke([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new qt(0)}}]),vertexShader:Zt.meshlambert_vert,fragmentShader:Zt.meshlambert_frag},phong:{uniforms:ke([dt.common,dt.specularmap,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,dt.lights,{emissive:{value:new qt(0)},specular:{value:new qt(1118481)},shininess:{value:30}}]),vertexShader:Zt.meshphong_vert,fragmentShader:Zt.meshphong_frag},standard:{uniforms:ke([dt.common,dt.envmap,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.roughnessmap,dt.metalnessmap,dt.fog,dt.lights,{emissive:{value:new qt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Zt.meshphysical_vert,fragmentShader:Zt.meshphysical_frag},toon:{uniforms:ke([dt.common,dt.aomap,dt.lightmap,dt.emissivemap,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.gradientmap,dt.fog,dt.lights,{emissive:{value:new qt(0)}}]),vertexShader:Zt.meshtoon_vert,fragmentShader:Zt.meshtoon_frag},matcap:{uniforms:ke([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,dt.fog,{matcap:{value:null}}]),vertexShader:Zt.meshmatcap_vert,fragmentShader:Zt.meshmatcap_frag},points:{uniforms:ke([dt.points,dt.fog]),vertexShader:Zt.points_vert,fragmentShader:Zt.points_frag},dashed:{uniforms:ke([dt.common,dt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Zt.linedashed_vert,fragmentShader:Zt.linedashed_frag},depth:{uniforms:ke([dt.common,dt.displacementmap]),vertexShader:Zt.depth_vert,fragmentShader:Zt.depth_frag},normal:{uniforms:ke([dt.common,dt.bumpmap,dt.normalmap,dt.displacementmap,{opacity:{value:1}}]),vertexShader:Zt.meshnormal_vert,fragmentShader:Zt.meshnormal_frag},sprite:{uniforms:ke([dt.sprite,dt.fog]),vertexShader:Zt.sprite_vert,fragmentShader:Zt.sprite_frag},background:{uniforms:{uvTransform:{value:new Xt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Zt.background_vert,fragmentShader:Zt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Xt}},vertexShader:Zt.backgroundCube_vert,fragmentShader:Zt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Zt.cube_vert,fragmentShader:Zt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Zt.equirect_vert,fragmentShader:Zt.equirect_frag},distanceRGBA:{uniforms:ke([dt.common,dt.displacementmap,{referencePosition:{value:new F},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Zt.distanceRGBA_vert,fragmentShader:Zt.distanceRGBA_frag},shadow:{uniforms:ke([dt.lights,dt.fog,{color:{value:new qt(0)},opacity:{value:1}}]),vertexShader:Zt.shadow_vert,fragmentShader:Zt.shadow_frag}};Mn.physical={uniforms:ke([Mn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xt},clearcoatNormalScale:{value:new he(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xt},sheen:{value:0},sheenColor:{value:new qt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xt},transmissionSamplerSize:{value:new he},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xt},attenuationDistance:{value:0},attenuationColor:{value:new qt(0)},specularColor:{value:new qt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xt},anisotropyVector:{value:new he},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xt}}]),vertexShader:Zt.meshphysical_vert,fragmentShader:Zt.meshphysical_frag};const Ks={r:0,b:0,g:0},ri=new kn,op=new Ee;function ap(s,t,e,n,i,r,o){const a=new qt(0);let c=r===!0?0:1,l,h,u=null,d=0,f=null;function g(b){let E=b.isScene===!0?b.background:null;return E&&E.isTexture&&(E=(b.backgroundBlurriness>0?e:t).get(E)),E}function _(b){let E=!1;const L=g(b);L===null?p(a,c):L&&L.isColor&&(p(L,1),E=!0);const R=s.xr.getEnvironmentBlendMode();R==="additive"?n.buffers.color.setClear(0,0,0,1,o):R==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(s.autoClear||E)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function m(b,E){const L=g(E);L&&(L.isCubeTexture||L.mapping===mr)?(h===void 0&&(h=new Ie(new zn(1,1,1),new Hn({name:"BackgroundCubeMaterial",uniforms:Vi(Mn.backgroundCube.uniforms),vertexShader:Mn.backgroundCube.vertexShader,fragmentShader:Mn.backgroundCube.fragmentShader,side:qe,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,w,O){this.matrixWorld.copyPosition(O.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),ri.copy(E.backgroundRotation),ri.x*=-1,ri.y*=-1,ri.z*=-1,L.isCubeTexture&&L.isRenderTargetTexture===!1&&(ri.y*=-1,ri.z*=-1),h.material.uniforms.envMap.value=L,h.material.uniforms.flipEnvMap.value=L.isCubeTexture&&L.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=E.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(op.makeRotationFromEuler(ri)),h.material.toneMapped=re.getTransfer(L.colorSpace)!==ce,(u!==L||d!==L.version||f!==s.toneMapping)&&(h.material.needsUpdate=!0,u=L,d=L.version,f=s.toneMapping),h.layers.enableAll(),b.unshift(h,h.geometry,h.material,0,0,null)):L&&L.isTexture&&(l===void 0&&(l=new Ie(new jn(2,2),new Hn({name:"BackgroundMaterial",uniforms:Vi(Mn.background.uniforms),vertexShader:Mn.background.vertexShader,fragmentShader:Mn.background.fragmentShader,side:Fn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=L,l.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,l.material.toneMapped=re.getTransfer(L.colorSpace)!==ce,L.matrixAutoUpdate===!0&&L.updateMatrix(),l.material.uniforms.uvTransform.value.copy(L.matrix),(u!==L||d!==L.version||f!==s.toneMapping)&&(l.material.needsUpdate=!0,u=L,d=L.version,f=s.toneMapping),l.layers.enableAll(),b.unshift(l,l.geometry,l.material,0,0,null))}function p(b,E){b.getRGB(Ks,fc(s)),n.buffers.color.setClear(Ks.r,Ks.g,Ks.b,E,o)}function T(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(b,E=1){a.set(b),c=E,p(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(b){c=b,p(a,c)},render:_,addToRenderList:m,dispose:T}}function lp(s,t){const e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=d(null);let r=i,o=!1;function a(M,C,z,G,W){let K=!1;const H=u(G,z,C);r!==H&&(r=H,l(r.object)),K=f(M,G,z,W),K&&g(M,G,z,W),W!==null&&t.update(W,s.ELEMENT_ARRAY_BUFFER),(K||o)&&(o=!1,E(M,C,z,G),W!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(W).buffer))}function c(){return s.createVertexArray()}function l(M){return s.bindVertexArray(M)}function h(M){return s.deleteVertexArray(M)}function u(M,C,z){const G=z.wireframe===!0;let W=n[M.id];W===void 0&&(W={},n[M.id]=W);let K=W[C.id];K===void 0&&(K={},W[C.id]=K);let H=K[G];return H===void 0&&(H=d(c()),K[G]=H),H}function d(M){const C=[],z=[],G=[];for(let W=0;W<e;W++)C[W]=0,z[W]=0,G[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:z,attributeDivisors:G,object:M,attributes:{},index:null}}function f(M,C,z,G){const W=r.attributes,K=C.attributes;let H=0;const rt=z.getAttributes();for(const V in rt)if(rt[V].location>=0){const ut=W[V];let _t=K[V];if(_t===void 0&&(V==="instanceMatrix"&&M.instanceMatrix&&(_t=M.instanceMatrix),V==="instanceColor"&&M.instanceColor&&(_t=M.instanceColor)),ut===void 0||ut.attribute!==_t||_t&&ut.data!==_t.data)return!0;H++}return r.attributesNum!==H||r.index!==G}function g(M,C,z,G){const W={},K=C.attributes;let H=0;const rt=z.getAttributes();for(const V in rt)if(rt[V].location>=0){let ut=K[V];ut===void 0&&(V==="instanceMatrix"&&M.instanceMatrix&&(ut=M.instanceMatrix),V==="instanceColor"&&M.instanceColor&&(ut=M.instanceColor));const _t={};_t.attribute=ut,ut&&ut.data&&(_t.data=ut.data),W[V]=_t,H++}r.attributes=W,r.attributesNum=H,r.index=G}function _(){const M=r.newAttributes;for(let C=0,z=M.length;C<z;C++)M[C]=0}function m(M){p(M,0)}function p(M,C){const z=r.newAttributes,G=r.enabledAttributes,W=r.attributeDivisors;z[M]=1,G[M]===0&&(s.enableVertexAttribArray(M),G[M]=1),W[M]!==C&&(s.vertexAttribDivisor(M,C),W[M]=C)}function T(){const M=r.newAttributes,C=r.enabledAttributes;for(let z=0,G=C.length;z<G;z++)C[z]!==M[z]&&(s.disableVertexAttribArray(z),C[z]=0)}function b(M,C,z,G,W,K,H){H===!0?s.vertexAttribIPointer(M,C,z,W,K):s.vertexAttribPointer(M,C,z,G,W,K)}function E(M,C,z,G){_();const W=G.attributes,K=z.getAttributes(),H=C.defaultAttributeValues;for(const rt in K){const V=K[rt];if(V.location>=0){let ht=W[rt];if(ht===void 0&&(rt==="instanceMatrix"&&M.instanceMatrix&&(ht=M.instanceMatrix),rt==="instanceColor"&&M.instanceColor&&(ht=M.instanceColor)),ht!==void 0){const ut=ht.normalized,_t=ht.itemSize,Bt=t.get(ht);if(Bt===void 0)continue;const Yt=Bt.buffer,jt=Bt.type,ne=Bt.bytesPerElement,Y=jt===s.INT||jt===s.UNSIGNED_INT||ht.gpuType===aa;if(ht.isInterleavedBufferAttribute){const Q=ht.data,vt=Q.stride,It=ht.offset;if(Q.isInstancedInterleavedBuffer){for(let yt=0;yt<V.locationSize;yt++)p(V.location+yt,Q.meshPerAttribute);M.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let yt=0;yt<V.locationSize;yt++)m(V.location+yt);s.bindBuffer(s.ARRAY_BUFFER,Yt);for(let yt=0;yt<V.locationSize;yt++)b(V.location+yt,_t/V.locationSize,jt,ut,vt*ne,(It+_t/V.locationSize*yt)*ne,Y)}else{if(ht.isInstancedBufferAttribute){for(let Q=0;Q<V.locationSize;Q++)p(V.location+Q,ht.meshPerAttribute);M.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=ht.meshPerAttribute*ht.count)}else for(let Q=0;Q<V.locationSize;Q++)m(V.location+Q);s.bindBuffer(s.ARRAY_BUFFER,Yt);for(let Q=0;Q<V.locationSize;Q++)b(V.location+Q,_t/V.locationSize,jt,ut,_t*ne,_t/V.locationSize*Q*ne,Y)}}else if(H!==void 0){const ut=H[rt];if(ut!==void 0)switch(ut.length){case 2:s.vertexAttrib2fv(V.location,ut);break;case 3:s.vertexAttrib3fv(V.location,ut);break;case 4:s.vertexAttrib4fv(V.location,ut);break;default:s.vertexAttrib1fv(V.location,ut)}}}}T()}function L(){O();for(const M in n){const C=n[M];for(const z in C){const G=C[z];for(const W in G)h(G[W].object),delete G[W];delete C[z]}delete n[M]}}function R(M){if(n[M.id]===void 0)return;const C=n[M.id];for(const z in C){const G=C[z];for(const W in G)h(G[W].object),delete G[W];delete C[z]}delete n[M.id]}function w(M){for(const C in n){const z=n[C];if(z[M.id]===void 0)continue;const G=z[M.id];for(const W in G)h(G[W].object),delete G[W];delete z[M.id]}}function O(){S(),o=!0,r!==i&&(r=i,l(r.object))}function S(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:O,resetDefaultState:S,dispose:L,releaseStatesOfGeometry:R,releaseStatesOfProgram:w,initAttributes:_,enableAttribute:m,disableUnusedAttributes:T}}function cp(s,t,e){let n;function i(l){n=l}function r(l,h){s.drawArrays(n,l,h),e.update(h,n,1)}function o(l,h,u){u!==0&&(s.drawArraysInstanced(n,l,h,u),e.update(h,n,u))}function a(l,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];e.update(f,n,1)}function c(l,h,u,d){if(u===0)return;const f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<l.length;g++)o(l[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,l,0,h,0,d,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*d[_];e.update(g,n,1)}}this.setMode=i,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function hp(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){const w=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(w.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(w){return!(w!==cn&&n.convert(w)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(w){const O=w===ps&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(w!==Bn&&n.convert(w)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&w!==Nn&&!O)}function c(w){if(w==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";w="mediump"}return w==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=e.precision!==void 0?e.precision:"highp";const h=c(l);h!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",h,"instead."),l=h);const u=e.logarithmicDepthBuffer===!0,d=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),f=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),g=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=s.getParameter(s.MAX_TEXTURE_SIZE),m=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),p=s.getParameter(s.MAX_VERTEX_ATTRIBS),T=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),b=s.getParameter(s.MAX_VARYING_VECTORS),E=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),L=g>0,R=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:T,maxVaryings:b,maxFragmentUniforms:E,vertexTextures:L,maxSamples:R}}function up(s){const t=this;let e=null,n=0,i=!1,r=!1;const o=new li,a=new Xt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){const g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=s.get(u);if(!i||g===null||g.length===0||r&&!m)r?h(null):l();else{const T=r?0:n,b=T*4;let E=p.clippingState||null;c.value=E,E=h(g,d,b,f);for(let L=0;L!==b;++L)E[L]=e[L];p.clippingState=E,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=T}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,g){const _=u!==null?u.length:0;let m=null;if(_!==0){if(m=c.value,g!==!0||m===null){const p=f+_*4,T=d.matrixWorldInverse;a.getNormalMatrix(T),(m===null||m.length<p)&&(m=new Float32Array(p));for(let b=0,E=f;b!==_;++b,E+=4)o.copy(u[b]).applyMatrix4(T,a),o.normal.toArray(m,E),m[E+3]=o.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=_,t.numIntersection=0,m}}function dp(s){let t=new WeakMap;function e(o,a){return a===_o?o.mapping=zi:a===vo&&(o.mapping=Hi),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===_o||a===vo)if(t.has(o)){const c=t.get(o).texture;return e(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new hu(c.height);return l.fromEquirectangularTexture(s,o),t.set(o,l),o.addEventListener("dispose",i),e(l.texture,o.mapping)}else return null}}return o}function i(o){const a=o.target;a.removeEventListener("dispose",i);const c=t.get(a);c!==void 0&&(t.delete(a),c.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}const Ni=4,fl=[.125,.215,.35,.446,.526,.582],di=20,jr=new Eu,pl=new qt;let Jr=null,Qr=0,to=0,eo=!1;const ci=(1+Math.sqrt(5))/2,Ui=1/ci,ml=[new F(-ci,Ui,0),new F(ci,Ui,0),new F(-Ui,0,ci),new F(Ui,0,ci),new F(0,ci,-Ui),new F(0,ci,Ui),new F(-1,1,-1),new F(1,1,-1),new F(-1,1,1),new F(1,1,1)],fp=new F;class gl{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100,r={}){const{size:o=256,position:a=fp}=r;Jr=this._renderer.getRenderTarget(),Qr=this._renderer.getActiveCubeFace(),to=this._renderer.getActiveMipmapLevel(),eo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(t,n,i,c,a),e>0&&this._blur(c,0,0,e),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=xl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=vl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Jr,Qr,to),this._renderer.xr.enabled=eo,t.scissorTest=!1,$s(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===zi||t.mapping===Hi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Jr=this._renderer.getRenderTarget(),Qr=this._renderer.getActiveCubeFace(),to=this._renderer.getActiveMipmapLevel(),eo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Sn,minFilter:Sn,generateMipmaps:!1,type:ps,format:cn,colorSpace:Gi,depthBuffer:!1},i=_l(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=_l(t,e,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=pp(r)),this._blurMaterial=mp(r,t,e)}return i}_compileMaterial(t){const e=new Ie(this._lodPlanes[0],t);this._renderer.compile(e,jr)}_sceneToCubeUV(t,e,n,i,r){const c=new on(90,1,e,n),l=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(pl),u.toneMapping=Zn,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(i),u.clearDepth(),u.setRenderTarget(null));const _=new vi({name:"PMREM.Background",side:qe,depthWrite:!1,depthTest:!1}),m=new Ie(new zn,_);let p=!1;const T=t.background;T?T.isColor&&(_.color.copy(T),t.background=null,p=!0):(_.color.copy(pl),p=!0);for(let b=0;b<6;b++){const E=b%3;E===0?(c.up.set(0,l[b],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+h[b],r.y,r.z)):E===1?(c.up.set(0,0,l[b]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+h[b],r.z)):(c.up.set(0,l[b],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+h[b]));const L=this._cubeSize;$s(i,E*L,b>2?L:0,L,L),u.setRenderTarget(i),p&&u.render(m,c),u.render(t,c)}m.geometry.dispose(),m.material.dispose(),u.toneMapping=f,u.autoClear=d,t.background=T}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===zi||t.mapping===Hi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=xl()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=vl());const r=i?this._cubemapMaterial:this._equirectMaterial,o=new Ie(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;const c=this._cubeSize;$s(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(o,jr)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const i=this._lodPlanes.length;for(let r=1;r<i;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=ml[(i-r-1)%ml.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,i,r){const o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,i,"latitudinal",r),this._halfBlur(o,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new Ie(this._lodPlanes[i],l),d=l.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*di-1),_=r/g,m=isFinite(r)?1+Math.floor(h*_):di;m>di&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${di}`);const p=[];let T=0;for(let w=0;w<di;++w){const O=w/_,S=Math.exp(-O*O/2);p.push(S),w===0?T+=S:w<m&&(T+=2*S)}for(let w=0;w<p.length;w++)p[w]=p[w]/T;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:b}=this;d.dTheta.value=g,d.mipInt.value=b-n;const E=this._sizeLods[i],L=3*E*(i>b-Ni?i-b+Ni:0),R=4*(this._cubeSize-E);$s(e,L,R,3*E,2*E),c.setRenderTarget(e),c.render(u,jr)}}function pp(s){const t=[],e=[],n=[];let i=s;const r=s-Ni+1+fl.length;for(let o=0;o<r;o++){const a=Math.pow(2,i);e.push(a);let c=1/a;o>s-Ni?c=fl[o-s+Ni-1]:o===0&&(c=0),n.push(c);const l=1/(a-2),h=-l,u=1+l,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,_=3,m=2,p=1,T=new Float32Array(_*g*f),b=new Float32Array(m*g*f),E=new Float32Array(p*g*f);for(let R=0;R<f;R++){const w=R%3*2/3-1,O=R>2?0:-1,S=[w,O,0,w+2/3,O,0,w+2/3,O+1,0,w,O,0,w+2/3,O+1,0,w,O+1,0];T.set(S,_*g*R),b.set(d,m*g*R);const M=[R,R,R,R,R,R];E.set(M,p*g*R)}const L=new un;L.setAttribute("position",new Fe(T,_)),L.setAttribute("uv",new Fe(b,m)),L.setAttribute("faceIndex",new Fe(E,p)),t.push(L),i>Ni&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function _l(s,t,e){const n=new _i(s,t,e);return n.texture.mapping=mr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function $s(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function mp(s,t,e){const n=new Float32Array(di),i=new F(0,1,0);return new Hn({name:"SphericalGaussianBlur",defines:{n:di,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:ga(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function vl(){return new Hn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ga(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function xl(){return new Hn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ga(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function ga(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function gp(s){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){const c=a.mapping,l=c===_o||c===vo,h=c===zi||c===Hi;if(l||h){let u=t.get(a);const d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return e===null&&(e=new gl(s)),u=l?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{const f=a.image;return l&&f&&f.height>0||h&&f&&i(f)?(e===null&&(e=new gl(s)),u=l?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function i(a){let c=0;const l=6;for(let h=0;h<l;h++)a[h]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function _p(s){const t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const i=e(n);return i===null&&fs("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function vp(s,t,e,n){const i={},r=new WeakMap;function o(u){const d=u.target;d.index!==null&&t.remove(d.index);for(const g in d.attributes)t.remove(d.attributes[g]);d.removeEventListener("dispose",o),delete i[d.id];const f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function a(u,d){return i[d.id]===!0||(d.addEventListener("dispose",o),i[d.id]=!0,e.memory.geometries++),d}function c(u){const d=u.attributes;for(const f in d)t.update(d[f],s.ARRAY_BUFFER)}function l(u){const d=[],f=u.index,g=u.attributes.position;let _=0;if(f!==null){const T=f.array;_=f.version;for(let b=0,E=T.length;b<E;b+=3){const L=T[b+0],R=T[b+1],w=T[b+2];d.push(L,R,R,w,w,L)}}else if(g!==void 0){const T=g.array;_=g.version;for(let b=0,E=T.length/3-1;b<E;b+=3){const L=b+0,R=b+1,w=b+2;d.push(L,R,R,w,w,L)}}else return;const m=new(lc(d)?dc:uc)(d,1);m.version=_;const p=r.get(u);p&&t.remove(p),r.set(u,m)}function h(u){const d=r.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&l(u)}else l(u);return r.get(u)}return{get:a,update:c,getWireframeAttribute:h}}function xp(s,t,e){let n;function i(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function c(d,f){s.drawElements(n,f,r,d*o),e.update(f,n,1)}function l(d,f,g){g!==0&&(s.drawElementsInstanced(n,f,r,d*o,g),e.update(f,n,g))}function h(d,f,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];e.update(m,n,1)}function u(d,f,g,_){if(g===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)l(d[p]/o,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,_,0,g);let p=0;for(let T=0;T<g;T++)p+=f[T]*_[T];e.update(p,n,1)}}this.setMode=i,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function Mp(s){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case s.TRIANGLES:e.triangles+=a*(r/3);break;case s.LINES:e.lines+=a*(r/2);break;case s.LINE_STRIP:e.lines+=a*(r-1);break;case s.LINE_LOOP:e.lines+=a*r;break;case s.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function Sp(s,t,e){const n=new WeakMap,i=new Se;function r(o,a,c){const l=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(a);if(d===void 0||d.count!==u){let S=function(){w.dispose(),n.delete(a),a.removeEventListener("dispose",S)};d!==void 0&&d.texture.dispose();const f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],T=a.morphAttributes.color||[];let b=0;f===!0&&(b=1),g===!0&&(b=2),_===!0&&(b=3);let E=a.attributes.position.count*b,L=1;E>t.maxTextureSize&&(L=Math.ceil(E/t.maxTextureSize),E=t.maxTextureSize);const R=new Float32Array(E*L*4*u),w=new pa(R,E,L,u);w.type=Nn,w.needsUpdate=!0;const O=b*4;for(let M=0;M<u;M++){const C=m[M],z=p[M],G=T[M],W=E*L*4*M;for(let K=0;K<C.count;K++){const H=K*O;f===!0&&(i.fromBufferAttribute(C,K),R[W+H+0]=i.x,R[W+H+1]=i.y,R[W+H+2]=i.z,R[W+H+3]=0),g===!0&&(i.fromBufferAttribute(z,K),R[W+H+4]=i.x,R[W+H+5]=i.y,R[W+H+6]=i.z,R[W+H+7]=0),_===!0&&(i.fromBufferAttribute(G,K),R[W+H+8]=i.x,R[W+H+9]=i.y,R[W+H+10]=i.z,R[W+H+11]=G.itemSize===4?i.w:1)}}d={count:u,texture:w,size:new he(E,L)},n.set(a,d),a.addEventListener("dispose",S)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(s,"morphTexture",o.morphTexture,e);else{let f=0;for(let _=0;_<l.length;_++)f+=l[_];const g=a.morphTargetsRelative?1:1-f;c.getUniforms().setValue(s,"morphTargetBaseInfluence",g),c.getUniforms().setValue(s,"morphTargetInfluences",l)}c.getUniforms().setValue(s,"morphTargetsTexture",d.texture,e),c.getUniforms().setValue(s,"morphTargetsTextureSize",d.size)}return{update:r}}function Ep(s,t,e,n){let i=new WeakMap;function r(c){const l=n.render.frame,h=c.geometry,u=t.get(c,h);if(i.get(u)!==l&&(t.update(u),i.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),i.get(c)!==l&&(e.update(c.instanceMatrix,s.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,s.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const d=c.skeleton;i.get(d)!==l&&(d.update(),i.set(d,l))}return u}function o(){i=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:o}}const Ec=new ze,Ml=new xc(1,1),yc=new pa,Tc=new Yh,bc=new mc,Sl=[],El=[],yl=new Float32Array(16),Tl=new Float32Array(9),bl=new Float32Array(4);function Ki(s,t,e){const n=s[0];if(n<=0||n>0)return s;const i=t*e;let r=Sl[i];if(r===void 0&&(r=new Float32Array(i),Sl[i]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,s[o].toArray(r,a)}return r}function Ae(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function we(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function _r(s,t){let e=El[t];e===void 0&&(e=new Int32Array(t),El[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function yp(s,t){const e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function Tp(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;s.uniform2fv(this.addr,t),we(e,t)}}function bp(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ae(e,t))return;s.uniform3fv(this.addr,t),we(e,t)}}function Ap(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;s.uniform4fv(this.addr,t),we(e,t)}}function wp(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),we(e,t)}else{if(Ae(e,n))return;bl.set(n),s.uniformMatrix2fv(this.addr,!1,bl),we(e,n)}}function Rp(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),we(e,t)}else{if(Ae(e,n))return;Tl.set(n),s.uniformMatrix3fv(this.addr,!1,Tl),we(e,n)}}function Cp(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),we(e,t)}else{if(Ae(e,n))return;yl.set(n),s.uniformMatrix4fv(this.addr,!1,yl),we(e,n)}}function Dp(s,t){const e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function Lp(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;s.uniform2iv(this.addr,t),we(e,t)}}function Pp(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ae(e,t))return;s.uniform3iv(this.addr,t),we(e,t)}}function Ip(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;s.uniform4iv(this.addr,t),we(e,t)}}function Up(s,t){const e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function Np(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;s.uniform2uiv(this.addr,t),we(e,t)}}function Op(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ae(e,t))return;s.uniform3uiv(this.addr,t),we(e,t)}}function Fp(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;s.uniform4uiv(this.addr,t),we(e,t)}}function Bp(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(Ml.compareFunction=ac,r=Ml):r=Ec,e.setTexture2D(t||r,i)}function kp(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Tc,i)}function zp(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||bc,i)}function Hp(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||yc,i)}function Gp(s){switch(s){case 5126:return yp;case 35664:return Tp;case 35665:return bp;case 35666:return Ap;case 35674:return wp;case 35675:return Rp;case 35676:return Cp;case 5124:case 35670:return Dp;case 35667:case 35671:return Lp;case 35668:case 35672:return Pp;case 35669:case 35673:return Ip;case 5125:return Up;case 36294:return Np;case 36295:return Op;case 36296:return Fp;case 35678:case 36198:case 36298:case 36306:case 35682:return Bp;case 35679:case 36299:case 36307:return kp;case 35680:case 36300:case 36308:case 36293:return zp;case 36289:case 36303:case 36311:case 36292:return Hp}}function Vp(s,t){s.uniform1fv(this.addr,t)}function Wp(s,t){const e=Ki(t,this.size,2);s.uniform2fv(this.addr,e)}function Xp(s,t){const e=Ki(t,this.size,3);s.uniform3fv(this.addr,e)}function qp(s,t){const e=Ki(t,this.size,4);s.uniform4fv(this.addr,e)}function Yp(s,t){const e=Ki(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function Kp(s,t){const e=Ki(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function $p(s,t){const e=Ki(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function Zp(s,t){s.uniform1iv(this.addr,t)}function jp(s,t){s.uniform2iv(this.addr,t)}function Jp(s,t){s.uniform3iv(this.addr,t)}function Qp(s,t){s.uniform4iv(this.addr,t)}function tm(s,t){s.uniform1uiv(this.addr,t)}function em(s,t){s.uniform2uiv(this.addr,t)}function nm(s,t){s.uniform3uiv(this.addr,t)}function im(s,t){s.uniform4uiv(this.addr,t)}function sm(s,t,e){const n=this.cache,i=t.length,r=_r(e,i);Ae(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let o=0;o!==i;++o)e.setTexture2D(t[o]||Ec,r[o])}function rm(s,t,e){const n=this.cache,i=t.length,r=_r(e,i);Ae(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let o=0;o!==i;++o)e.setTexture3D(t[o]||Tc,r[o])}function om(s,t,e){const n=this.cache,i=t.length,r=_r(e,i);Ae(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let o=0;o!==i;++o)e.setTextureCube(t[o]||bc,r[o])}function am(s,t,e){const n=this.cache,i=t.length,r=_r(e,i);Ae(n,r)||(s.uniform1iv(this.addr,r),we(n,r));for(let o=0;o!==i;++o)e.setTexture2DArray(t[o]||yc,r[o])}function lm(s){switch(s){case 5126:return Vp;case 35664:return Wp;case 35665:return Xp;case 35666:return qp;case 35674:return Yp;case 35675:return Kp;case 35676:return $p;case 5124:case 35670:return Zp;case 35667:case 35671:return jp;case 35668:case 35672:return Jp;case 35669:case 35673:return Qp;case 5125:return tm;case 36294:return em;case 36295:return nm;case 36296:return im;case 35678:case 36198:case 36298:case 36306:case 35682:return sm;case 35679:case 36299:case 36307:return rm;case 35680:case 36300:case 36308:case 36293:return om;case 36289:case 36303:case 36311:case 36292:return am}}class cm{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Gp(e.type)}}class hm{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=lm(e.type)}}class um{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let r=0,o=i.length;r!==o;++r){const a=i[r];a.setValue(t,e[a.id],n)}}}const no=/(\w+)(\])?(\[|\.)?/g;function Al(s,t){s.seq.push(t),s.map[t.id]=t}function dm(s,t,e){const n=s.name,i=n.length;for(no.lastIndex=0;;){const r=no.exec(n),o=no.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===i){Al(e,l===void 0?new cm(a,s,t):new hm(a,s,t));break}else{let u=e.map[a];u===void 0&&(u=new um(a),Al(e,u)),e=u}}}class ir{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const r=t.getActiveUniform(e,i),o=t.getUniformLocation(e,r.name);dm(r,o,this)}}setValue(t,e,n,i){const r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,o=e.length;r!==o;++r){const a=e[r],c=n[a.id];c.needsUpdate!==!1&&a.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,r=t.length;i!==r;++i){const o=t[i];o.id in e&&n.push(o)}return n}}function wl(s,t,e){const n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}const fm=37297;let pm=0;function mm(s,t){const e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=i;o<r;o++){const a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}const Rl=new Xt;function gm(s){re._getMatrix(Rl,re.workingColorSpace,s);const t=`mat3( ${Rl.elements.map(e=>e.toFixed(4))} )`;switch(re.getTransfer(s)){case or:return[t,"LinearTransferOETF"];case ce:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function Cl(s,t,e){const n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const a=parseInt(o[1]);return e.toUpperCase()+`

`+r+`

`+mm(s.getShaderSource(t),a)}else return r}function _m(s,t){const e=gm(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function vm(s,t){let e;switch(t){case Mh:e="Linear";break;case Sh:e="Reinhard";break;case Eh:e="Cineon";break;case yh:e="ACESFilmic";break;case bh:e="AgX";break;case Ah:e="Neutral";break;case Th:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const Zs=new F;function xm(){re.getLuminanceCoefficients(Zs);const s=Zs.x.toFixed(4),t=Zs.y.toFixed(4),e=Zs.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Mm(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(os).join(`
`)}function Sm(s){const t=[];for(const e in s){const n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Em(s,t){const e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const r=s.getActiveAttrib(t,i),o=r.name;let a=1;r.type===s.FLOAT_MAT2&&(a=2),r.type===s.FLOAT_MAT3&&(a=3),r.type===s.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:s.getAttribLocation(t,o),locationSize:a}}return e}function os(s){return s!==""}function Dl(s,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Ll(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const ym=/^[ \t]*#include +<([\w\d./]+)>/gm;function Zo(s){return s.replace(ym,bm)}const Tm=new Map;function bm(s,t){let e=Zt[t];if(e===void 0){const n=Tm.get(t);if(n!==void 0)e=Zt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Zo(e)}const Am=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Pl(s){return s.replace(Am,wm)}function wm(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Il(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Rm(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===Zl?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===Qc?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Pn&&(t="SHADOWMAP_TYPE_VSM"),t}function Cm(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case zi:case Hi:t="ENVMAP_TYPE_CUBE";break;case mr:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Dm(s){let t="ENVMAP_MODE_REFLECTION";return s.envMap&&s.envMapMode===Hi&&(t="ENVMAP_MODE_REFRACTION"),t}function Lm(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case jl:t="ENVMAP_BLENDING_MULTIPLY";break;case vh:t="ENVMAP_BLENDING_MIX";break;case xh:t="ENVMAP_BLENDING_ADD";break}return t}function Pm(s){const t=s.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function Im(s,t,e,n){const i=s.getContext(),r=e.defines;let o=e.vertexShader,a=e.fragmentShader;const c=Rm(e),l=Cm(e),h=Dm(e),u=Lm(e),d=Pm(e),f=Mm(e),g=Sm(r),_=i.createProgram();let m,p,T=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(os).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(os).join(`
`),p.length>0&&(p+=`
`)):(m=[Il(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(os).join(`
`),p=[Il(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Zn?"#define TONE_MAPPING":"",e.toneMapping!==Zn?Zt.tonemapping_pars_fragment:"",e.toneMapping!==Zn?vm("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Zt.colorspace_pars_fragment,_m("linearToOutputTexel",e.outputColorSpace),xm(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(os).join(`
`)),o=Zo(o),o=Dl(o,e),o=Ll(o,e),a=Zo(a),a=Dl(a,e),a=Ll(a,e),o=Pl(o),a=Pl(a),e.isRawShaderMaterial!==!0&&(T=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",e.glslVersion===ar?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===ar?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const b=T+m+o,E=T+p+a,L=wl(i,i.VERTEX_SHADER,b),R=wl(i,i.FRAGMENT_SHADER,E);i.attachShader(_,L),i.attachShader(_,R),e.index0AttributeName!==void 0?i.bindAttribLocation(_,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(_,0,"position"),i.linkProgram(_);function w(C){if(s.debug.checkShaderErrors){const z=i.getProgramInfoLog(_)||"",G=i.getShaderInfoLog(L)||"",W=i.getShaderInfoLog(R)||"",K=z.trim(),H=G.trim(),rt=W.trim();let V=!0,ht=!0;if(i.getProgramParameter(_,i.LINK_STATUS)===!1)if(V=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,_,L,R);else{const ut=Cl(i,L,"vertex"),_t=Cl(i,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(_,i.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+K+`
`+ut+`
`+_t)}else K!==""?console.warn("THREE.WebGLProgram: Program Info Log:",K):(H===""||rt==="")&&(ht=!1);ht&&(C.diagnostics={runnable:V,programLog:K,vertexShader:{log:H,prefix:m},fragmentShader:{log:rt,prefix:p}})}i.deleteShader(L),i.deleteShader(R),O=new ir(i,_),S=Em(i,_)}let O;this.getUniforms=function(){return O===void 0&&w(this),O};let S;this.getAttributes=function(){return S===void 0&&w(this),S};let M=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=i.getProgramParameter(_,fm)),M},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(_),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=pm++,this.cacheKey=t,this.usedTimes=1,this.program=_,this.vertexShader=L,this.fragmentShader=R,this}let Um=0;class Nm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Om(t),e.set(t,n)),n}}class Om{constructor(t){this.id=Um++,this.code=t,this.usedTimes=0}}function Fm(s,t,e,n,i,r,o){const a=new cc,c=new Nm,l=new Set,h=[],u=i.logarithmicDepthBuffer,d=i.vertexTextures;let f=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(S){return l.add(S),S===0?"uv":`uv${S}`}function m(S,M,C,z,G){const W=z.fog,K=G.geometry,H=S.isMeshStandardMaterial?z.environment:null,rt=(S.isMeshStandardMaterial?e:t).get(S.envMap||H),V=rt&&rt.mapping===mr?rt.image.height:null,ht=g[S.type];S.precision!==null&&(f=i.getMaxPrecision(S.precision),f!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",f,"instead."));const ut=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,_t=ut!==void 0?ut.length:0;let Bt=0;K.morphAttributes.position!==void 0&&(Bt=1),K.morphAttributes.normal!==void 0&&(Bt=2),K.morphAttributes.color!==void 0&&(Bt=3);let Yt,jt,ne,Y;if(ht){const oe=Mn[ht];Yt=oe.vertexShader,jt=oe.fragmentShader}else Yt=S.vertexShader,jt=S.fragmentShader,c.update(S),ne=c.getVertexShaderID(S),Y=c.getFragmentShaderID(S);const Q=s.getRenderTarget(),vt=s.state.buffers.depth.getReversed(),It=G.isInstancedMesh===!0,yt=G.isBatchedMesh===!0,Kt=!!S.map,Ce=!!S.matcap,A=!!rt,ae=!!S.aoMap,zt=!!S.lightMap,Lt=!!S.bumpMap,Tt=!!S.normalMap,ge=!!S.displacementMap,bt=!!S.emissiveMap,$t=!!S.metalnessMap,De=!!S.roughnessMap,Me=S.anisotropy>0,y=S.clearcoat>0,v=S.dispersion>0,N=S.iridescence>0,q=S.sheen>0,tt=S.transmission>0,X=Me&&!!S.anisotropyMap,Ct=y&&!!S.clearcoatMap,ot=y&&!!S.clearcoatNormalMap,At=y&&!!S.clearcoatRoughnessMap,wt=N&&!!S.iridescenceMap,it=N&&!!S.iridescenceThicknessMap,mt=q&&!!S.sheenColorMap,Nt=q&&!!S.sheenRoughnessMap,Rt=!!S.specularMap,ft=!!S.specularColorMap,Vt=!!S.specularIntensityMap,D=tt&&!!S.transmissionMap,st=tt&&!!S.thicknessMap,lt=!!S.gradientMap,xt=!!S.alphaMap,et=S.alphaTest>0,$=!!S.alphaHash,St=!!S.extensions;let Gt=Zn;S.toneMapped&&(Q===null||Q.isXRRenderTarget===!0)&&(Gt=s.toneMapping);const fe={shaderID:ht,shaderType:S.type,shaderName:S.name,vertexShader:Yt,fragmentShader:jt,defines:S.defines,customVertexShaderID:ne,customFragmentShaderID:Y,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:f,batching:yt,batchingColor:yt&&G._colorsTexture!==null,instancing:It,instancingColor:It&&G.instanceColor!==null,instancingMorph:It&&G.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:Q===null?s.outputColorSpace:Q.isXRRenderTarget===!0?Q.texture.colorSpace:Gi,alphaToCoverage:!!S.alphaToCoverage,map:Kt,matcap:Ce,envMap:A,envMapMode:A&&rt.mapping,envMapCubeUVHeight:V,aoMap:ae,lightMap:zt,bumpMap:Lt,normalMap:Tt,displacementMap:d&&ge,emissiveMap:bt,normalMapObjectSpace:Tt&&S.normalMapType===Lh,normalMapTangentSpace:Tt&&S.normalMapType===Dh,metalnessMap:$t,roughnessMap:De,anisotropy:Me,anisotropyMap:X,clearcoat:y,clearcoatMap:Ct,clearcoatNormalMap:ot,clearcoatRoughnessMap:At,dispersion:v,iridescence:N,iridescenceMap:wt,iridescenceThicknessMap:it,sheen:q,sheenColorMap:mt,sheenRoughnessMap:Nt,specularMap:Rt,specularColorMap:ft,specularIntensityMap:Vt,transmission:tt,transmissionMap:D,thicknessMap:st,gradientMap:lt,opaque:S.transparent===!1&&S.blending===Oi&&S.alphaToCoverage===!1,alphaMap:xt,alphaTest:et,alphaHash:$,combine:S.combine,mapUv:Kt&&_(S.map.channel),aoMapUv:ae&&_(S.aoMap.channel),lightMapUv:zt&&_(S.lightMap.channel),bumpMapUv:Lt&&_(S.bumpMap.channel),normalMapUv:Tt&&_(S.normalMap.channel),displacementMapUv:ge&&_(S.displacementMap.channel),emissiveMapUv:bt&&_(S.emissiveMap.channel),metalnessMapUv:$t&&_(S.metalnessMap.channel),roughnessMapUv:De&&_(S.roughnessMap.channel),anisotropyMapUv:X&&_(S.anisotropyMap.channel),clearcoatMapUv:Ct&&_(S.clearcoatMap.channel),clearcoatNormalMapUv:ot&&_(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:At&&_(S.clearcoatRoughnessMap.channel),iridescenceMapUv:wt&&_(S.iridescenceMap.channel),iridescenceThicknessMapUv:it&&_(S.iridescenceThicknessMap.channel),sheenColorMapUv:mt&&_(S.sheenColorMap.channel),sheenRoughnessMapUv:Nt&&_(S.sheenRoughnessMap.channel),specularMapUv:Rt&&_(S.specularMap.channel),specularColorMapUv:ft&&_(S.specularColorMap.channel),specularIntensityMapUv:Vt&&_(S.specularIntensityMap.channel),transmissionMapUv:D&&_(S.transmissionMap.channel),thicknessMapUv:st&&_(S.thicknessMap.channel),alphaMapUv:xt&&_(S.alphaMap.channel),vertexTangents:!!K.attributes.tangent&&(Tt||Me),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,pointsUvs:G.isPoints===!0&&!!K.attributes.uv&&(Kt||xt),fog:!!W,useFog:S.fog===!0,fogExp2:!!W&&W.isFogExp2,flatShading:S.flatShading===!0&&S.wireframe===!1,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:vt,skinning:G.isSkinnedMesh===!0,morphTargets:K.morphAttributes.position!==void 0,morphNormals:K.morphAttributes.normal!==void 0,morphColors:K.morphAttributes.color!==void 0,morphTargetsCount:_t,morphTextureStride:Bt,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:S.dithering,shadowMapEnabled:s.shadowMap.enabled&&C.length>0,shadowMapType:s.shadowMap.type,toneMapping:Gt,decodeVideoTexture:Kt&&S.map.isVideoTexture===!0&&re.getTransfer(S.map.colorSpace)===ce,decodeVideoTextureEmissive:bt&&S.emissiveMap.isVideoTexture===!0&&re.getTransfer(S.emissiveMap.colorSpace)===ce,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===an,flipSided:S.side===qe,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:St&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(St&&S.extensions.multiDraw===!0||yt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return fe.vertexUv1s=l.has(1),fe.vertexUv2s=l.has(2),fe.vertexUv3s=l.has(3),l.clear(),fe}function p(S){const M=[];if(S.shaderID?M.push(S.shaderID):(M.push(S.customVertexShaderID),M.push(S.customFragmentShaderID)),S.defines!==void 0)for(const C in S.defines)M.push(C),M.push(S.defines[C]);return S.isRawShaderMaterial===!1&&(T(M,S),b(M,S),M.push(s.outputColorSpace)),M.push(S.customProgramCacheKey),M.join()}function T(S,M){S.push(M.precision),S.push(M.outputColorSpace),S.push(M.envMapMode),S.push(M.envMapCubeUVHeight),S.push(M.mapUv),S.push(M.alphaMapUv),S.push(M.lightMapUv),S.push(M.aoMapUv),S.push(M.bumpMapUv),S.push(M.normalMapUv),S.push(M.displacementMapUv),S.push(M.emissiveMapUv),S.push(M.metalnessMapUv),S.push(M.roughnessMapUv),S.push(M.anisotropyMapUv),S.push(M.clearcoatMapUv),S.push(M.clearcoatNormalMapUv),S.push(M.clearcoatRoughnessMapUv),S.push(M.iridescenceMapUv),S.push(M.iridescenceThicknessMapUv),S.push(M.sheenColorMapUv),S.push(M.sheenRoughnessMapUv),S.push(M.specularMapUv),S.push(M.specularColorMapUv),S.push(M.specularIntensityMapUv),S.push(M.transmissionMapUv),S.push(M.thicknessMapUv),S.push(M.combine),S.push(M.fogExp2),S.push(M.sizeAttenuation),S.push(M.morphTargetsCount),S.push(M.morphAttributeCount),S.push(M.numDirLights),S.push(M.numPointLights),S.push(M.numSpotLights),S.push(M.numSpotLightMaps),S.push(M.numHemiLights),S.push(M.numRectAreaLights),S.push(M.numDirLightShadows),S.push(M.numPointLightShadows),S.push(M.numSpotLightShadows),S.push(M.numSpotLightShadowsWithMaps),S.push(M.numLightProbes),S.push(M.shadowMapType),S.push(M.toneMapping),S.push(M.numClippingPlanes),S.push(M.numClipIntersection),S.push(M.depthPacking)}function b(S,M){a.disableAll(),M.supportsVertexTextures&&a.enable(0),M.instancing&&a.enable(1),M.instancingColor&&a.enable(2),M.instancingMorph&&a.enable(3),M.matcap&&a.enable(4),M.envMap&&a.enable(5),M.normalMapObjectSpace&&a.enable(6),M.normalMapTangentSpace&&a.enable(7),M.clearcoat&&a.enable(8),M.iridescence&&a.enable(9),M.alphaTest&&a.enable(10),M.vertexColors&&a.enable(11),M.vertexAlphas&&a.enable(12),M.vertexUv1s&&a.enable(13),M.vertexUv2s&&a.enable(14),M.vertexUv3s&&a.enable(15),M.vertexTangents&&a.enable(16),M.anisotropy&&a.enable(17),M.alphaHash&&a.enable(18),M.batching&&a.enable(19),M.dispersion&&a.enable(20),M.batchingColor&&a.enable(21),M.gradientMap&&a.enable(22),S.push(a.mask),a.disableAll(),M.fog&&a.enable(0),M.useFog&&a.enable(1),M.flatShading&&a.enable(2),M.logarithmicDepthBuffer&&a.enable(3),M.reversedDepthBuffer&&a.enable(4),M.skinning&&a.enable(5),M.morphTargets&&a.enable(6),M.morphNormals&&a.enable(7),M.morphColors&&a.enable(8),M.premultipliedAlpha&&a.enable(9),M.shadowMapEnabled&&a.enable(10),M.doubleSided&&a.enable(11),M.flipSided&&a.enable(12),M.useDepthPacking&&a.enable(13),M.dithering&&a.enable(14),M.transmission&&a.enable(15),M.sheen&&a.enable(16),M.opaque&&a.enable(17),M.pointsUvs&&a.enable(18),M.decodeVideoTexture&&a.enable(19),M.decodeVideoTextureEmissive&&a.enable(20),M.alphaToCoverage&&a.enable(21),S.push(a.mask)}function E(S){const M=g[S.type];let C;if(M){const z=Mn[M];C=ou.clone(z.uniforms)}else C=S.uniforms;return C}function L(S,M){let C;for(let z=0,G=h.length;z<G;z++){const W=h[z];if(W.cacheKey===M){C=W,++C.usedTimes;break}}return C===void 0&&(C=new Im(s,M,S,r),h.push(C)),C}function R(S){if(--S.usedTimes===0){const M=h.indexOf(S);h[M]=h[h.length-1],h.pop(),S.destroy()}}function w(S){c.remove(S)}function O(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:E,acquireProgram:L,releaseProgram:R,releaseShaderCache:w,programs:h,dispose:O}}function Bm(){let s=new WeakMap;function t(o){return s.has(o)}function e(o){let a=s.get(o);return a===void 0&&(a={},s.set(o,a)),a}function n(o){s.delete(o)}function i(o,a,c){s.get(o)[a]=c}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function km(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function Ul(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Nl(){const s=[];let t=0;const e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function o(u,d,f,g,_,m){let p=s[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},s[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),t++,p}function a(u,d,f,g,_,m){const p=o(u,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):e.push(p)}function c(u,d,f,g,_,m){const p=o(u,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):e.unshift(p)}function l(u,d){e.length>1&&e.sort(u||km),n.length>1&&n.sort(d||Ul),i.length>1&&i.sort(d||Ul)}function h(){for(let u=t,d=s.length;u<d;u++){const f=s[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:a,unshift:c,finish:h,sort:l}}function zm(){let s=new WeakMap;function t(n,i){const r=s.get(n);let o;return r===void 0?(o=new Nl,s.set(n,[o])):i>=r.length?(o=new Nl,r.push(o)):o=r[i],o}function e(){s=new WeakMap}return{get:t,dispose:e}}function Hm(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new F,color:new qt};break;case"SpotLight":e={position:new F,direction:new F,color:new qt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new F,color:new qt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new F,skyColor:new qt,groundColor:new qt};break;case"RectAreaLight":e={color:new qt,position:new F,halfWidth:new F,halfHeight:new F};break}return s[t.id]=e,e}}}function Gm(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}let Vm=0;function Wm(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function Xm(s){const t=new Hm,e=Gm(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new F);const i=new F,r=new Ee,o=new Ee;function a(l){let h=0,u=0,d=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,T=0,b=0,E=0,L=0,R=0,w=0;l.sort(Wm);for(let S=0,M=l.length;S<M;S++){const C=l[S],z=C.color,G=C.intensity,W=C.distance,K=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)h+=z.r*G,u+=z.g*G,d+=z.b*G;else if(C.isLightProbe){for(let H=0;H<9;H++)n.probe[H].addScaledVector(C.sh.coefficients[H],G);w++}else if(C.isDirectionalLight){const H=t.get(C);if(H.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const rt=C.shadow,V=e.get(C);V.shadowIntensity=rt.intensity,V.shadowBias=rt.bias,V.shadowNormalBias=rt.normalBias,V.shadowRadius=rt.radius,V.shadowMapSize=rt.mapSize,n.directionalShadow[f]=V,n.directionalShadowMap[f]=K,n.directionalShadowMatrix[f]=C.shadow.matrix,T++}n.directional[f]=H,f++}else if(C.isSpotLight){const H=t.get(C);H.position.setFromMatrixPosition(C.matrixWorld),H.color.copy(z).multiplyScalar(G),H.distance=W,H.coneCos=Math.cos(C.angle),H.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),H.decay=C.decay,n.spot[_]=H;const rt=C.shadow;if(C.map&&(n.spotLightMap[L]=C.map,L++,rt.updateMatrices(C),C.castShadow&&R++),n.spotLightMatrix[_]=rt.matrix,C.castShadow){const V=e.get(C);V.shadowIntensity=rt.intensity,V.shadowBias=rt.bias,V.shadowNormalBias=rt.normalBias,V.shadowRadius=rt.radius,V.shadowMapSize=rt.mapSize,n.spotShadow[_]=V,n.spotShadowMap[_]=K,E++}_++}else if(C.isRectAreaLight){const H=t.get(C);H.color.copy(z).multiplyScalar(G),H.halfWidth.set(C.width*.5,0,0),H.halfHeight.set(0,C.height*.5,0),n.rectArea[m]=H,m++}else if(C.isPointLight){const H=t.get(C);if(H.color.copy(C.color).multiplyScalar(C.intensity),H.distance=C.distance,H.decay=C.decay,C.castShadow){const rt=C.shadow,V=e.get(C);V.shadowIntensity=rt.intensity,V.shadowBias=rt.bias,V.shadowNormalBias=rt.normalBias,V.shadowRadius=rt.radius,V.shadowMapSize=rt.mapSize,V.shadowCameraNear=rt.camera.near,V.shadowCameraFar=rt.camera.far,n.pointShadow[g]=V,n.pointShadowMap[g]=K,n.pointShadowMatrix[g]=C.shadow.matrix,b++}n.point[g]=H,g++}else if(C.isHemisphereLight){const H=t.get(C);H.skyColor.copy(C.color).multiplyScalar(G),H.groundColor.copy(C.groundColor).multiplyScalar(G),n.hemi[p]=H,p++}}m>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=dt.LTC_FLOAT_1,n.rectAreaLTC2=dt.LTC_FLOAT_2):(n.rectAreaLTC1=dt.LTC_HALF_1,n.rectAreaLTC2=dt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const O=n.hash;(O.directionalLength!==f||O.pointLength!==g||O.spotLength!==_||O.rectAreaLength!==m||O.hemiLength!==p||O.numDirectionalShadows!==T||O.numPointShadows!==b||O.numSpotShadows!==E||O.numSpotMaps!==L||O.numLightProbes!==w)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=T,n.directionalShadowMap.length=T,n.pointShadow.length=b,n.pointShadowMap.length=b,n.spotShadow.length=E,n.spotShadowMap.length=E,n.directionalShadowMatrix.length=T,n.pointShadowMatrix.length=b,n.spotLightMatrix.length=E+L-R,n.spotLightMap.length=L,n.numSpotLightShadowsWithMaps=R,n.numLightProbes=w,O.directionalLength=f,O.pointLength=g,O.spotLength=_,O.rectAreaLength=m,O.hemiLength=p,O.numDirectionalShadows=T,O.numPointShadows=b,O.numSpotShadows=E,O.numSpotMaps=L,O.numLightProbes=w,n.version=Vm++)}function c(l,h){let u=0,d=0,f=0,g=0,_=0;const m=h.matrixWorldInverse;for(let p=0,T=l.length;p<T;p++){const b=l[p];if(b.isDirectionalLight){const E=n.directional[u];E.direction.setFromMatrixPosition(b.matrixWorld),i.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(i),E.direction.transformDirection(m),u++}else if(b.isSpotLight){const E=n.spot[f];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),E.direction.setFromMatrixPosition(b.matrixWorld),i.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(i),E.direction.transformDirection(m),f++}else if(b.isRectAreaLight){const E=n.rectArea[g];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),o.identity(),r.copy(b.matrixWorld),r.premultiply(m),o.extractRotation(r),E.halfWidth.set(b.width*.5,0,0),E.halfHeight.set(0,b.height*.5,0),E.halfWidth.applyMatrix4(o),E.halfHeight.applyMatrix4(o),g++}else if(b.isPointLight){const E=n.point[d];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),d++}else if(b.isHemisphereLight){const E=n.hemi[_];E.direction.setFromMatrixPosition(b.matrixWorld),E.direction.transformDirection(m),_++}}}return{setup:a,setupView:c,state:n}}function Ol(s){const t=new Xm(s),e=[],n=[];function i(h){l.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function c(h){t.setupView(e,h)}const l={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function qm(s){let t=new WeakMap;function e(i,r=0){const o=t.get(i);let a;return o===void 0?(a=new Ol(s),t.set(i,[a])):r>=o.length?(a=new Ol(s),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}const Ym=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Km=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function $m(s,t,e){let n=new gc;const i=new he,r=new he,o=new Se,a=new Mu({depthPacking:Ch}),c=new Su,l={},h=e.maxTextureSize,u={[Fn]:qe,[qe]:Fn,[an]:an},d=new Hn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new he},radius:{value:4}},vertexShader:Ym,fragmentShader:Km}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const g=new un;g.setAttribute("position",new Fe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new Ie(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Zl;let p=this.type;this.render=function(R,w,O){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||R.length===0)return;const S=s.getRenderTarget(),M=s.getActiveCubeFace(),C=s.getActiveMipmapLevel(),z=s.state;z.setBlending($n),z.buffers.depth.getReversed()===!0?z.buffers.color.setClear(0,0,0,0):z.buffers.color.setClear(1,1,1,1),z.buffers.depth.setTest(!0),z.setScissorTest(!1);const G=p!==Pn&&this.type===Pn,W=p===Pn&&this.type!==Pn;for(let K=0,H=R.length;K<H;K++){const rt=R[K],V=rt.shadow;if(V===void 0){console.warn("THREE.WebGLShadowMap:",rt,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;i.copy(V.mapSize);const ht=V.getFrameExtents();if(i.multiply(ht),r.copy(V.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/ht.x),i.x=r.x*ht.x,V.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/ht.y),i.y=r.y*ht.y,V.mapSize.y=r.y)),V.map===null||G===!0||W===!0){const _t=this.type!==Pn?{minFilter:be,magFilter:be}:{};V.map!==null&&V.map.dispose(),V.map=new _i(i.x,i.y,_t),V.map.texture.name=rt.name+".shadowMap",V.camera.updateProjectionMatrix()}s.setRenderTarget(V.map),s.clear();const ut=V.getViewportCount();for(let _t=0;_t<ut;_t++){const Bt=V.getViewport(_t);o.set(r.x*Bt.x,r.y*Bt.y,r.x*Bt.z,r.y*Bt.w),z.viewport(o),V.updateMatrices(rt,_t),n=V.getFrustum(),E(w,O,V.camera,rt,this.type)}V.isPointLightShadow!==!0&&this.type===Pn&&T(V,O),V.needsUpdate=!1}p=this.type,m.needsUpdate=!1,s.setRenderTarget(S,M,C)};function T(R,w){const O=t.update(_);d.defines.VSM_SAMPLES!==R.blurSamples&&(d.defines.VSM_SAMPLES=R.blurSamples,f.defines.VSM_SAMPLES=R.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),R.mapPass===null&&(R.mapPass=new _i(i.x,i.y)),d.uniforms.shadow_pass.value=R.map.texture,d.uniforms.resolution.value=R.mapSize,d.uniforms.radius.value=R.radius,s.setRenderTarget(R.mapPass),s.clear(),s.renderBufferDirect(w,null,O,d,_,null),f.uniforms.shadow_pass.value=R.mapPass.texture,f.uniforms.resolution.value=R.mapSize,f.uniforms.radius.value=R.radius,s.setRenderTarget(R.map),s.clear(),s.renderBufferDirect(w,null,O,f,_,null)}function b(R,w,O,S){let M=null;const C=O.isPointLight===!0?R.customDistanceMaterial:R.customDepthMaterial;if(C!==void 0)M=C;else if(M=O.isPointLight===!0?c:a,s.localClippingEnabled&&w.clipShadows===!0&&Array.isArray(w.clippingPlanes)&&w.clippingPlanes.length!==0||w.displacementMap&&w.displacementScale!==0||w.alphaMap&&w.alphaTest>0||w.map&&w.alphaTest>0||w.alphaToCoverage===!0){const z=M.uuid,G=w.uuid;let W=l[z];W===void 0&&(W={},l[z]=W);let K=W[G];K===void 0&&(K=M.clone(),W[G]=K,w.addEventListener("dispose",L)),M=K}if(M.visible=w.visible,M.wireframe=w.wireframe,S===Pn?M.side=w.shadowSide!==null?w.shadowSide:w.side:M.side=w.shadowSide!==null?w.shadowSide:u[w.side],M.alphaMap=w.alphaMap,M.alphaTest=w.alphaToCoverage===!0?.5:w.alphaTest,M.map=w.map,M.clipShadows=w.clipShadows,M.clippingPlanes=w.clippingPlanes,M.clipIntersection=w.clipIntersection,M.displacementMap=w.displacementMap,M.displacementScale=w.displacementScale,M.displacementBias=w.displacementBias,M.wireframeLinewidth=w.wireframeLinewidth,M.linewidth=w.linewidth,O.isPointLight===!0&&M.isMeshDistanceMaterial===!0){const z=s.properties.get(M);z.light=O}return M}function E(R,w,O,S,M){if(R.visible===!1)return;if(R.layers.test(w.layers)&&(R.isMesh||R.isLine||R.isPoints)&&(R.castShadow||R.receiveShadow&&M===Pn)&&(!R.frustumCulled||n.intersectsObject(R))){R.modelViewMatrix.multiplyMatrices(O.matrixWorldInverse,R.matrixWorld);const G=t.update(R),W=R.material;if(Array.isArray(W)){const K=G.groups;for(let H=0,rt=K.length;H<rt;H++){const V=K[H],ht=W[V.materialIndex];if(ht&&ht.visible){const ut=b(R,ht,S,M);R.onBeforeShadow(s,R,w,O,G,ut,V),s.renderBufferDirect(O,null,G,ut,R,V),R.onAfterShadow(s,R,w,O,G,ut,V)}}}else if(W.visible){const K=b(R,W,S,M);R.onBeforeShadow(s,R,w,O,G,K,null),s.renderBufferDirect(O,null,G,K,R,null),R.onAfterShadow(s,R,w,O,G,K,null)}}const z=R.children;for(let G=0,W=z.length;G<W;G++)E(z[G],w,O,S,M)}function L(R){R.target.removeEventListener("dispose",L);for(const O in l){const S=l[O],M=R.target.uuid;M in S&&(S[M].dispose(),delete S[M])}}}const Zm={[co]:ho,[uo]:mo,[fo]:go,[ki]:po,[ho]:co,[mo]:uo,[go]:fo,[po]:ki};function jm(s,t){function e(){let D=!1;const st=new Se;let lt=null;const xt=new Se(0,0,0,0);return{setMask:function(et){lt!==et&&!D&&(s.colorMask(et,et,et,et),lt=et)},setLocked:function(et){D=et},setClear:function(et,$,St,Gt,fe){fe===!0&&(et*=Gt,$*=Gt,St*=Gt),st.set(et,$,St,Gt),xt.equals(st)===!1&&(s.clearColor(et,$,St,Gt),xt.copy(st))},reset:function(){D=!1,lt=null,xt.set(-1,0,0,0)}}}function n(){let D=!1,st=!1,lt=null,xt=null,et=null;return{setReversed:function($){if(st!==$){const St=t.get("EXT_clip_control");$?St.clipControlEXT(St.LOWER_LEFT_EXT,St.ZERO_TO_ONE_EXT):St.clipControlEXT(St.LOWER_LEFT_EXT,St.NEGATIVE_ONE_TO_ONE_EXT),st=$;const Gt=et;et=null,this.setClear(Gt)}},getReversed:function(){return st},setTest:function($){$?Q(s.DEPTH_TEST):vt(s.DEPTH_TEST)},setMask:function($){lt!==$&&!D&&(s.depthMask($),lt=$)},setFunc:function($){if(st&&($=Zm[$]),xt!==$){switch($){case co:s.depthFunc(s.NEVER);break;case ho:s.depthFunc(s.ALWAYS);break;case uo:s.depthFunc(s.LESS);break;case ki:s.depthFunc(s.LEQUAL);break;case fo:s.depthFunc(s.EQUAL);break;case po:s.depthFunc(s.GEQUAL);break;case mo:s.depthFunc(s.GREATER);break;case go:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}xt=$}},setLocked:function($){D=$},setClear:function($){et!==$&&(st&&($=1-$),s.clearDepth($),et=$)},reset:function(){D=!1,lt=null,xt=null,et=null,st=!1}}}function i(){let D=!1,st=null,lt=null,xt=null,et=null,$=null,St=null,Gt=null,fe=null;return{setTest:function(oe){D||(oe?Q(s.STENCIL_TEST):vt(s.STENCIL_TEST))},setMask:function(oe){st!==oe&&!D&&(s.stencilMask(oe),st=oe)},setFunc:function(oe,bn,gn){(lt!==oe||xt!==bn||et!==gn)&&(s.stencilFunc(oe,bn,gn),lt=oe,xt=bn,et=gn)},setOp:function(oe,bn,gn){($!==oe||St!==bn||Gt!==gn)&&(s.stencilOp(oe,bn,gn),$=oe,St=bn,Gt=gn)},setLocked:function(oe){D=oe},setClear:function(oe){fe!==oe&&(s.clearStencil(oe),fe=oe)},reset:function(){D=!1,st=null,lt=null,xt=null,et=null,$=null,St=null,Gt=null,fe=null}}}const r=new e,o=new n,a=new i,c=new WeakMap,l=new WeakMap;let h={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,T=null,b=null,E=null,L=null,R=null,w=new qt(0,0,0),O=0,S=!1,M=null,C=null,z=null,G=null,W=null;const K=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let H=!1,rt=0;const V=s.getParameter(s.VERSION);V.indexOf("WebGL")!==-1?(rt=parseFloat(/^WebGL (\d)/.exec(V)[1]),H=rt>=1):V.indexOf("OpenGL ES")!==-1&&(rt=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),H=rt>=2);let ht=null,ut={};const _t=s.getParameter(s.SCISSOR_BOX),Bt=s.getParameter(s.VIEWPORT),Yt=new Se().fromArray(_t),jt=new Se().fromArray(Bt);function ne(D,st,lt,xt){const et=new Uint8Array(4),$=s.createTexture();s.bindTexture(D,$),s.texParameteri(D,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(D,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let St=0;St<lt;St++)D===s.TEXTURE_3D||D===s.TEXTURE_2D_ARRAY?s.texImage3D(st,0,s.RGBA,1,1,xt,0,s.RGBA,s.UNSIGNED_BYTE,et):s.texImage2D(st+St,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,et);return $}const Y={};Y[s.TEXTURE_2D]=ne(s.TEXTURE_2D,s.TEXTURE_2D,1),Y[s.TEXTURE_CUBE_MAP]=ne(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Y[s.TEXTURE_2D_ARRAY]=ne(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Y[s.TEXTURE_3D]=ne(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),Q(s.DEPTH_TEST),o.setFunc(ki),Lt(!1),Tt(Oa),Q(s.CULL_FACE),ae($n);function Q(D){h[D]!==!0&&(s.enable(D),h[D]=!0)}function vt(D){h[D]!==!1&&(s.disable(D),h[D]=!1)}function It(D,st){return u[D]!==st?(s.bindFramebuffer(D,st),u[D]=st,D===s.DRAW_FRAMEBUFFER&&(u[s.FRAMEBUFFER]=st),D===s.FRAMEBUFFER&&(u[s.DRAW_FRAMEBUFFER]=st),!0):!1}function yt(D,st){let lt=f,xt=!1;if(D){lt=d.get(st),lt===void 0&&(lt=[],d.set(st,lt));const et=D.textures;if(lt.length!==et.length||lt[0]!==s.COLOR_ATTACHMENT0){for(let $=0,St=et.length;$<St;$++)lt[$]=s.COLOR_ATTACHMENT0+$;lt.length=et.length,xt=!0}}else lt[0]!==s.BACK&&(lt[0]=s.BACK,xt=!0);xt&&s.drawBuffers(lt)}function Kt(D){return g!==D?(s.useProgram(D),g=D,!0):!1}const Ce={[ui]:s.FUNC_ADD,[eh]:s.FUNC_SUBTRACT,[nh]:s.FUNC_REVERSE_SUBTRACT};Ce[ih]=s.MIN,Ce[sh]=s.MAX;const A={[rh]:s.ZERO,[oh]:s.ONE,[ah]:s.SRC_COLOR,[ao]:s.SRC_ALPHA,[fh]:s.SRC_ALPHA_SATURATE,[uh]:s.DST_COLOR,[ch]:s.DST_ALPHA,[lh]:s.ONE_MINUS_SRC_COLOR,[lo]:s.ONE_MINUS_SRC_ALPHA,[dh]:s.ONE_MINUS_DST_COLOR,[hh]:s.ONE_MINUS_DST_ALPHA,[ph]:s.CONSTANT_COLOR,[mh]:s.ONE_MINUS_CONSTANT_COLOR,[gh]:s.CONSTANT_ALPHA,[_h]:s.ONE_MINUS_CONSTANT_ALPHA};function ae(D,st,lt,xt,et,$,St,Gt,fe,oe){if(D===$n){_===!0&&(vt(s.BLEND),_=!1);return}if(_===!1&&(Q(s.BLEND),_=!0),D!==th){if(D!==m||oe!==S){if((p!==ui||E!==ui)&&(s.blendEquation(s.FUNC_ADD),p=ui,E=ui),oe)switch(D){case Oi:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Fa:s.blendFunc(s.ONE,s.ONE);break;case Ba:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case ka:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case Oi:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Fa:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case Ba:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case ka:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}T=null,b=null,L=null,R=null,w.set(0,0,0),O=0,m=D,S=oe}return}et=et||st,$=$||lt,St=St||xt,(st!==p||et!==E)&&(s.blendEquationSeparate(Ce[st],Ce[et]),p=st,E=et),(lt!==T||xt!==b||$!==L||St!==R)&&(s.blendFuncSeparate(A[lt],A[xt],A[$],A[St]),T=lt,b=xt,L=$,R=St),(Gt.equals(w)===!1||fe!==O)&&(s.blendColor(Gt.r,Gt.g,Gt.b,fe),w.copy(Gt),O=fe),m=D,S=!1}function zt(D,st){D.side===an?vt(s.CULL_FACE):Q(s.CULL_FACE);let lt=D.side===qe;st&&(lt=!lt),Lt(lt),D.blending===Oi&&D.transparent===!1?ae($n):ae(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),o.setFunc(D.depthFunc),o.setTest(D.depthTest),o.setMask(D.depthWrite),r.setMask(D.colorWrite);const xt=D.stencilWrite;a.setTest(xt),xt&&(a.setMask(D.stencilWriteMask),a.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),a.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),bt(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?Q(s.SAMPLE_ALPHA_TO_COVERAGE):vt(s.SAMPLE_ALPHA_TO_COVERAGE)}function Lt(D){M!==D&&(D?s.frontFace(s.CW):s.frontFace(s.CCW),M=D)}function Tt(D){D!==jc?(Q(s.CULL_FACE),D!==C&&(D===Oa?s.cullFace(s.BACK):D===Jc?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):vt(s.CULL_FACE),C=D}function ge(D){D!==z&&(H&&s.lineWidth(D),z=D)}function bt(D,st,lt){D?(Q(s.POLYGON_OFFSET_FILL),(G!==st||W!==lt)&&(s.polygonOffset(st,lt),G=st,W=lt)):vt(s.POLYGON_OFFSET_FILL)}function $t(D){D?Q(s.SCISSOR_TEST):vt(s.SCISSOR_TEST)}function De(D){D===void 0&&(D=s.TEXTURE0+K-1),ht!==D&&(s.activeTexture(D),ht=D)}function Me(D,st,lt){lt===void 0&&(ht===null?lt=s.TEXTURE0+K-1:lt=ht);let xt=ut[lt];xt===void 0&&(xt={type:void 0,texture:void 0},ut[lt]=xt),(xt.type!==D||xt.texture!==st)&&(ht!==lt&&(s.activeTexture(lt),ht=lt),s.bindTexture(D,st||Y[D]),xt.type=D,xt.texture=st)}function y(){const D=ut[ht];D!==void 0&&D.type!==void 0&&(s.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function v(){try{s.compressedTexImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function N(){try{s.compressedTexImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function q(){try{s.texSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function tt(){try{s.texSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function X(){try{s.compressedTexSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ct(){try{s.compressedTexSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ot(){try{s.texStorage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function At(){try{s.texStorage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function wt(){try{s.texImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function it(){try{s.texImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function mt(D){Yt.equals(D)===!1&&(s.scissor(D.x,D.y,D.z,D.w),Yt.copy(D))}function Nt(D){jt.equals(D)===!1&&(s.viewport(D.x,D.y,D.z,D.w),jt.copy(D))}function Rt(D,st){let lt=l.get(st);lt===void 0&&(lt=new WeakMap,l.set(st,lt));let xt=lt.get(D);xt===void 0&&(xt=s.getUniformBlockIndex(st,D.name),lt.set(D,xt))}function ft(D,st){const xt=l.get(st).get(D);c.get(st)!==xt&&(s.uniformBlockBinding(st,xt,D.__bindingPointIndex),c.set(st,xt))}function Vt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),o.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},ht=null,ut={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,T=null,b=null,E=null,L=null,R=null,w=new qt(0,0,0),O=0,S=!1,M=null,C=null,z=null,G=null,W=null,Yt.set(0,0,s.canvas.width,s.canvas.height),jt.set(0,0,s.canvas.width,s.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:Q,disable:vt,bindFramebuffer:It,drawBuffers:yt,useProgram:Kt,setBlending:ae,setMaterial:zt,setFlipSided:Lt,setCullFace:Tt,setLineWidth:ge,setPolygonOffset:bt,setScissorTest:$t,activeTexture:De,bindTexture:Me,unbindTexture:y,compressedTexImage2D:v,compressedTexImage3D:N,texImage2D:wt,texImage3D:it,updateUBOMapping:Rt,uniformBlockBinding:ft,texStorage2D:ot,texStorage3D:At,texSubImage2D:q,texSubImage3D:tt,compressedTexSubImage2D:X,compressedTexSubImage3D:Ct,scissor:mt,viewport:Nt,reset:Vt}}function Jm(s,t,e,n,i,r,o){const a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new he,h=new WeakMap;let u;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(y,v){return f?new OffscreenCanvas(y,v):cr("canvas")}function _(y,v,N){let q=1;const tt=Me(y);if((tt.width>N||tt.height>N)&&(q=N/Math.max(tt.width,tt.height)),q<1)if(typeof HTMLImageElement<"u"&&y instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&y instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&y instanceof ImageBitmap||typeof VideoFrame<"u"&&y instanceof VideoFrame){const X=Math.floor(q*tt.width),Ct=Math.floor(q*tt.height);u===void 0&&(u=g(X,Ct));const ot=v?g(X,Ct):u;return ot.width=X,ot.height=Ct,ot.getContext("2d").drawImage(y,0,0,X,Ct),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+tt.width+"x"+tt.height+") to ("+X+"x"+Ct+")."),ot}else return"data"in y&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+tt.width+"x"+tt.height+")."),y;return y}function m(y){return y.generateMipmaps}function p(y){s.generateMipmap(y)}function T(y){return y.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:y.isWebGL3DRenderTarget?s.TEXTURE_3D:y.isWebGLArrayRenderTarget||y.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function b(y,v,N,q,tt=!1){if(y!==null){if(s[y]!==void 0)return s[y];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+y+"'")}let X=v;if(v===s.RED&&(N===s.FLOAT&&(X=s.R32F),N===s.HALF_FLOAT&&(X=s.R16F),N===s.UNSIGNED_BYTE&&(X=s.R8)),v===s.RED_INTEGER&&(N===s.UNSIGNED_BYTE&&(X=s.R8UI),N===s.UNSIGNED_SHORT&&(X=s.R16UI),N===s.UNSIGNED_INT&&(X=s.R32UI),N===s.BYTE&&(X=s.R8I),N===s.SHORT&&(X=s.R16I),N===s.INT&&(X=s.R32I)),v===s.RG&&(N===s.FLOAT&&(X=s.RG32F),N===s.HALF_FLOAT&&(X=s.RG16F),N===s.UNSIGNED_BYTE&&(X=s.RG8)),v===s.RG_INTEGER&&(N===s.UNSIGNED_BYTE&&(X=s.RG8UI),N===s.UNSIGNED_SHORT&&(X=s.RG16UI),N===s.UNSIGNED_INT&&(X=s.RG32UI),N===s.BYTE&&(X=s.RG8I),N===s.SHORT&&(X=s.RG16I),N===s.INT&&(X=s.RG32I)),v===s.RGB_INTEGER&&(N===s.UNSIGNED_BYTE&&(X=s.RGB8UI),N===s.UNSIGNED_SHORT&&(X=s.RGB16UI),N===s.UNSIGNED_INT&&(X=s.RGB32UI),N===s.BYTE&&(X=s.RGB8I),N===s.SHORT&&(X=s.RGB16I),N===s.INT&&(X=s.RGB32I)),v===s.RGBA_INTEGER&&(N===s.UNSIGNED_BYTE&&(X=s.RGBA8UI),N===s.UNSIGNED_SHORT&&(X=s.RGBA16UI),N===s.UNSIGNED_INT&&(X=s.RGBA32UI),N===s.BYTE&&(X=s.RGBA8I),N===s.SHORT&&(X=s.RGBA16I),N===s.INT&&(X=s.RGBA32I)),v===s.RGB&&(N===s.UNSIGNED_INT_5_9_9_9_REV&&(X=s.RGB9_E5),N===s.UNSIGNED_INT_10F_11F_11F_REV&&(X=s.R11F_G11F_B10F)),v===s.RGBA){const Ct=tt?or:re.getTransfer(q);N===s.FLOAT&&(X=s.RGBA32F),N===s.HALF_FLOAT&&(X=s.RGBA16F),N===s.UNSIGNED_BYTE&&(X=Ct===ce?s.SRGB8_ALPHA8:s.RGBA8),N===s.UNSIGNED_SHORT_4_4_4_4&&(X=s.RGBA4),N===s.UNSIGNED_SHORT_5_5_5_1&&(X=s.RGB5_A1)}return(X===s.R16F||X===s.R32F||X===s.RG16F||X===s.RG32F||X===s.RGBA16F||X===s.RGBA32F)&&t.get("EXT_color_buffer_float"),X}function E(y,v){let N;return y?v===null||v===gi||v===hs?N=s.DEPTH24_STENCIL8:v===Nn?N=s.DEPTH32F_STENCIL8:v===cs&&(N=s.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):v===null||v===gi||v===hs?N=s.DEPTH_COMPONENT24:v===Nn?N=s.DEPTH_COMPONENT32F:v===cs&&(N=s.DEPTH_COMPONENT16),N}function L(y,v){return m(y)===!0||y.isFramebufferTexture&&y.minFilter!==be&&y.minFilter!==Sn?Math.log2(Math.max(v.width,v.height))+1:y.mipmaps!==void 0&&y.mipmaps.length>0?y.mipmaps.length:y.isCompressedTexture&&Array.isArray(y.image)?v.mipmaps.length:1}function R(y){const v=y.target;v.removeEventListener("dispose",R),O(v),v.isVideoTexture&&h.delete(v)}function w(y){const v=y.target;v.removeEventListener("dispose",w),M(v)}function O(y){const v=n.get(y);if(v.__webglInit===void 0)return;const N=y.source,q=d.get(N);if(q){const tt=q[v.__cacheKey];tt.usedTimes--,tt.usedTimes===0&&S(y),Object.keys(q).length===0&&d.delete(N)}n.remove(y)}function S(y){const v=n.get(y);s.deleteTexture(v.__webglTexture);const N=y.source,q=d.get(N);delete q[v.__cacheKey],o.memory.textures--}function M(y){const v=n.get(y);if(y.depthTexture&&(y.depthTexture.dispose(),n.remove(y.depthTexture)),y.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(v.__webglFramebuffer[q]))for(let tt=0;tt<v.__webglFramebuffer[q].length;tt++)s.deleteFramebuffer(v.__webglFramebuffer[q][tt]);else s.deleteFramebuffer(v.__webglFramebuffer[q]);v.__webglDepthbuffer&&s.deleteRenderbuffer(v.__webglDepthbuffer[q])}else{if(Array.isArray(v.__webglFramebuffer))for(let q=0;q<v.__webglFramebuffer.length;q++)s.deleteFramebuffer(v.__webglFramebuffer[q]);else s.deleteFramebuffer(v.__webglFramebuffer);if(v.__webglDepthbuffer&&s.deleteRenderbuffer(v.__webglDepthbuffer),v.__webglMultisampledFramebuffer&&s.deleteFramebuffer(v.__webglMultisampledFramebuffer),v.__webglColorRenderbuffer)for(let q=0;q<v.__webglColorRenderbuffer.length;q++)v.__webglColorRenderbuffer[q]&&s.deleteRenderbuffer(v.__webglColorRenderbuffer[q]);v.__webglDepthRenderbuffer&&s.deleteRenderbuffer(v.__webglDepthRenderbuffer)}const N=y.textures;for(let q=0,tt=N.length;q<tt;q++){const X=n.get(N[q]);X.__webglTexture&&(s.deleteTexture(X.__webglTexture),o.memory.textures--),n.remove(N[q])}n.remove(y)}let C=0;function z(){C=0}function G(){const y=C;return y>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+y+" texture units while this GPU supports only "+i.maxTextures),C+=1,y}function W(y){const v=[];return v.push(y.wrapS),v.push(y.wrapT),v.push(y.wrapR||0),v.push(y.magFilter),v.push(y.minFilter),v.push(y.anisotropy),v.push(y.internalFormat),v.push(y.format),v.push(y.type),v.push(y.generateMipmaps),v.push(y.premultiplyAlpha),v.push(y.flipY),v.push(y.unpackAlignment),v.push(y.colorSpace),v.join()}function K(y,v){const N=n.get(y);if(y.isVideoTexture&&$t(y),y.isRenderTargetTexture===!1&&y.isExternalTexture!==!0&&y.version>0&&N.__version!==y.version){const q=y.image;if(q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y(N,y,v);return}}else y.isExternalTexture&&(N.__webglTexture=y.sourceTexture?y.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,N.__webglTexture,s.TEXTURE0+v)}function H(y,v){const N=n.get(y);if(y.isRenderTargetTexture===!1&&y.version>0&&N.__version!==y.version){Y(N,y,v);return}e.bindTexture(s.TEXTURE_2D_ARRAY,N.__webglTexture,s.TEXTURE0+v)}function rt(y,v){const N=n.get(y);if(y.isRenderTargetTexture===!1&&y.version>0&&N.__version!==y.version){Y(N,y,v);return}e.bindTexture(s.TEXTURE_3D,N.__webglTexture,s.TEXTURE0+v)}function V(y,v){const N=n.get(y);if(y.version>0&&N.__version!==y.version){Q(N,y,v);return}e.bindTexture(s.TEXTURE_CUBE_MAP,N.__webglTexture,s.TEXTURE0+v)}const ht={[rr]:s.REPEAT,[Un]:s.CLAMP_TO_EDGE,[xo]:s.MIRRORED_REPEAT},ut={[be]:s.NEAREST,[wh]:s.NEAREST_MIPMAP_NEAREST,[rs]:s.NEAREST_MIPMAP_LINEAR,[Sn]:s.LINEAR,[br]:s.LINEAR_MIPMAP_NEAREST,[fi]:s.LINEAR_MIPMAP_LINEAR},_t={[Ph]:s.NEVER,[Bh]:s.ALWAYS,[Ih]:s.LESS,[ac]:s.LEQUAL,[Uh]:s.EQUAL,[Fh]:s.GEQUAL,[Nh]:s.GREATER,[Oh]:s.NOTEQUAL};function Bt(y,v){if(v.type===Nn&&t.has("OES_texture_float_linear")===!1&&(v.magFilter===Sn||v.magFilter===br||v.magFilter===rs||v.magFilter===fi||v.minFilter===Sn||v.minFilter===br||v.minFilter===rs||v.minFilter===fi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(y,s.TEXTURE_WRAP_S,ht[v.wrapS]),s.texParameteri(y,s.TEXTURE_WRAP_T,ht[v.wrapT]),(y===s.TEXTURE_3D||y===s.TEXTURE_2D_ARRAY)&&s.texParameteri(y,s.TEXTURE_WRAP_R,ht[v.wrapR]),s.texParameteri(y,s.TEXTURE_MAG_FILTER,ut[v.magFilter]),s.texParameteri(y,s.TEXTURE_MIN_FILTER,ut[v.minFilter]),v.compareFunction&&(s.texParameteri(y,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(y,s.TEXTURE_COMPARE_FUNC,_t[v.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(v.magFilter===be||v.minFilter!==rs&&v.minFilter!==fi||v.type===Nn&&t.has("OES_texture_float_linear")===!1)return;if(v.anisotropy>1||n.get(v).__currentAnisotropy){const N=t.get("EXT_texture_filter_anisotropic");s.texParameterf(y,N.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(v.anisotropy,i.getMaxAnisotropy())),n.get(v).__currentAnisotropy=v.anisotropy}}}function Yt(y,v){let N=!1;y.__webglInit===void 0&&(y.__webglInit=!0,v.addEventListener("dispose",R));const q=v.source;let tt=d.get(q);tt===void 0&&(tt={},d.set(q,tt));const X=W(v);if(X!==y.__cacheKey){tt[X]===void 0&&(tt[X]={texture:s.createTexture(),usedTimes:0},o.memory.textures++,N=!0),tt[X].usedTimes++;const Ct=tt[y.__cacheKey];Ct!==void 0&&(tt[y.__cacheKey].usedTimes--,Ct.usedTimes===0&&S(v)),y.__cacheKey=X,y.__webglTexture=tt[X].texture}return N}function jt(y,v,N){return Math.floor(Math.floor(y/N)/v)}function ne(y,v,N,q){const X=y.updateRanges;if(X.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,v.width,v.height,N,q,v.data);else{X.sort((it,mt)=>it.start-mt.start);let Ct=0;for(let it=1;it<X.length;it++){const mt=X[Ct],Nt=X[it],Rt=mt.start+mt.count,ft=jt(Nt.start,v.width,4),Vt=jt(mt.start,v.width,4);Nt.start<=Rt+1&&ft===Vt&&jt(Nt.start+Nt.count-1,v.width,4)===ft?mt.count=Math.max(mt.count,Nt.start+Nt.count-mt.start):(++Ct,X[Ct]=Nt)}X.length=Ct+1;const ot=s.getParameter(s.UNPACK_ROW_LENGTH),At=s.getParameter(s.UNPACK_SKIP_PIXELS),wt=s.getParameter(s.UNPACK_SKIP_ROWS);s.pixelStorei(s.UNPACK_ROW_LENGTH,v.width);for(let it=0,mt=X.length;it<mt;it++){const Nt=X[it],Rt=Math.floor(Nt.start/4),ft=Math.ceil(Nt.count/4),Vt=Rt%v.width,D=Math.floor(Rt/v.width),st=ft,lt=1;s.pixelStorei(s.UNPACK_SKIP_PIXELS,Vt),s.pixelStorei(s.UNPACK_SKIP_ROWS,D),e.texSubImage2D(s.TEXTURE_2D,0,Vt,D,st,lt,N,q,v.data)}y.clearUpdateRanges(),s.pixelStorei(s.UNPACK_ROW_LENGTH,ot),s.pixelStorei(s.UNPACK_SKIP_PIXELS,At),s.pixelStorei(s.UNPACK_SKIP_ROWS,wt)}}function Y(y,v,N){let q=s.TEXTURE_2D;(v.isDataArrayTexture||v.isCompressedArrayTexture)&&(q=s.TEXTURE_2D_ARRAY),v.isData3DTexture&&(q=s.TEXTURE_3D);const tt=Yt(y,v),X=v.source;e.bindTexture(q,y.__webglTexture,s.TEXTURE0+N);const Ct=n.get(X);if(X.version!==Ct.__version||tt===!0){e.activeTexture(s.TEXTURE0+N);const ot=re.getPrimaries(re.workingColorSpace),At=v.colorSpace===Kn?null:re.getPrimaries(v.colorSpace),wt=v.colorSpace===Kn||ot===At?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,v.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,v.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,wt);let it=_(v.image,!1,i.maxTextureSize);it=De(v,it);const mt=r.convert(v.format,v.colorSpace),Nt=r.convert(v.type);let Rt=b(v.internalFormat,mt,Nt,v.colorSpace,v.isVideoTexture);Bt(q,v);let ft;const Vt=v.mipmaps,D=v.isVideoTexture!==!0,st=Ct.__version===void 0||tt===!0,lt=X.dataReady,xt=L(v,it);if(v.isDepthTexture)Rt=E(v.format===ds,v.type),st&&(D?e.texStorage2D(s.TEXTURE_2D,1,Rt,it.width,it.height):e.texImage2D(s.TEXTURE_2D,0,Rt,it.width,it.height,0,mt,Nt,null));else if(v.isDataTexture)if(Vt.length>0){D&&st&&e.texStorage2D(s.TEXTURE_2D,xt,Rt,Vt[0].width,Vt[0].height);for(let et=0,$=Vt.length;et<$;et++)ft=Vt[et],D?lt&&e.texSubImage2D(s.TEXTURE_2D,et,0,0,ft.width,ft.height,mt,Nt,ft.data):e.texImage2D(s.TEXTURE_2D,et,Rt,ft.width,ft.height,0,mt,Nt,ft.data);v.generateMipmaps=!1}else D?(st&&e.texStorage2D(s.TEXTURE_2D,xt,Rt,it.width,it.height),lt&&ne(v,it,mt,Nt)):e.texImage2D(s.TEXTURE_2D,0,Rt,it.width,it.height,0,mt,Nt,it.data);else if(v.isCompressedTexture)if(v.isCompressedArrayTexture){D&&st&&e.texStorage3D(s.TEXTURE_2D_ARRAY,xt,Rt,Vt[0].width,Vt[0].height,it.depth);for(let et=0,$=Vt.length;et<$;et++)if(ft=Vt[et],v.format!==cn)if(mt!==null)if(D){if(lt)if(v.layerUpdates.size>0){const St=dl(ft.width,ft.height,v.format,v.type);for(const Gt of v.layerUpdates){const fe=ft.data.subarray(Gt*St/ft.data.BYTES_PER_ELEMENT,(Gt+1)*St/ft.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,et,0,0,Gt,ft.width,ft.height,1,mt,fe)}v.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,et,0,0,0,ft.width,ft.height,it.depth,mt,ft.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,et,Rt,ft.width,ft.height,it.depth,0,ft.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else D?lt&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,et,0,0,0,ft.width,ft.height,it.depth,mt,Nt,ft.data):e.texImage3D(s.TEXTURE_2D_ARRAY,et,Rt,ft.width,ft.height,it.depth,0,mt,Nt,ft.data)}else{D&&st&&e.texStorage2D(s.TEXTURE_2D,xt,Rt,Vt[0].width,Vt[0].height);for(let et=0,$=Vt.length;et<$;et++)ft=Vt[et],v.format!==cn?mt!==null?D?lt&&e.compressedTexSubImage2D(s.TEXTURE_2D,et,0,0,ft.width,ft.height,mt,ft.data):e.compressedTexImage2D(s.TEXTURE_2D,et,Rt,ft.width,ft.height,0,ft.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):D?lt&&e.texSubImage2D(s.TEXTURE_2D,et,0,0,ft.width,ft.height,mt,Nt,ft.data):e.texImage2D(s.TEXTURE_2D,et,Rt,ft.width,ft.height,0,mt,Nt,ft.data)}else if(v.isDataArrayTexture)if(D){if(st&&e.texStorage3D(s.TEXTURE_2D_ARRAY,xt,Rt,it.width,it.height,it.depth),lt)if(v.layerUpdates.size>0){const et=dl(it.width,it.height,v.format,v.type);for(const $ of v.layerUpdates){const St=it.data.subarray($*et/it.data.BYTES_PER_ELEMENT,($+1)*et/it.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,$,it.width,it.height,1,mt,Nt,St)}v.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,it.width,it.height,it.depth,mt,Nt,it.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,Rt,it.width,it.height,it.depth,0,mt,Nt,it.data);else if(v.isData3DTexture)D?(st&&e.texStorage3D(s.TEXTURE_3D,xt,Rt,it.width,it.height,it.depth),lt&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,it.width,it.height,it.depth,mt,Nt,it.data)):e.texImage3D(s.TEXTURE_3D,0,Rt,it.width,it.height,it.depth,0,mt,Nt,it.data);else if(v.isFramebufferTexture){if(st)if(D)e.texStorage2D(s.TEXTURE_2D,xt,Rt,it.width,it.height);else{let et=it.width,$=it.height;for(let St=0;St<xt;St++)e.texImage2D(s.TEXTURE_2D,St,Rt,et,$,0,mt,Nt,null),et>>=1,$>>=1}}else if(Vt.length>0){if(D&&st){const et=Me(Vt[0]);e.texStorage2D(s.TEXTURE_2D,xt,Rt,et.width,et.height)}for(let et=0,$=Vt.length;et<$;et++)ft=Vt[et],D?lt&&e.texSubImage2D(s.TEXTURE_2D,et,0,0,mt,Nt,ft):e.texImage2D(s.TEXTURE_2D,et,Rt,mt,Nt,ft);v.generateMipmaps=!1}else if(D){if(st){const et=Me(it);e.texStorage2D(s.TEXTURE_2D,xt,Rt,et.width,et.height)}lt&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,mt,Nt,it)}else e.texImage2D(s.TEXTURE_2D,0,Rt,mt,Nt,it);m(v)&&p(q),Ct.__version=X.version,v.onUpdate&&v.onUpdate(v)}y.__version=v.version}function Q(y,v,N){if(v.image.length!==6)return;const q=Yt(y,v),tt=v.source;e.bindTexture(s.TEXTURE_CUBE_MAP,y.__webglTexture,s.TEXTURE0+N);const X=n.get(tt);if(tt.version!==X.__version||q===!0){e.activeTexture(s.TEXTURE0+N);const Ct=re.getPrimaries(re.workingColorSpace),ot=v.colorSpace===Kn?null:re.getPrimaries(v.colorSpace),At=v.colorSpace===Kn||Ct===ot?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,v.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,v.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,At);const wt=v.isCompressedTexture||v.image[0].isCompressedTexture,it=v.image[0]&&v.image[0].isDataTexture,mt=[];for(let $=0;$<6;$++)!wt&&!it?mt[$]=_(v.image[$],!0,i.maxCubemapSize):mt[$]=it?v.image[$].image:v.image[$],mt[$]=De(v,mt[$]);const Nt=mt[0],Rt=r.convert(v.format,v.colorSpace),ft=r.convert(v.type),Vt=b(v.internalFormat,Rt,ft,v.colorSpace),D=v.isVideoTexture!==!0,st=X.__version===void 0||q===!0,lt=tt.dataReady;let xt=L(v,Nt);Bt(s.TEXTURE_CUBE_MAP,v);let et;if(wt){D&&st&&e.texStorage2D(s.TEXTURE_CUBE_MAP,xt,Vt,Nt.width,Nt.height);for(let $=0;$<6;$++){et=mt[$].mipmaps;for(let St=0;St<et.length;St++){const Gt=et[St];v.format!==cn?Rt!==null?D?lt&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St,0,0,Gt.width,Gt.height,Rt,Gt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St,Vt,Gt.width,Gt.height,0,Gt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):D?lt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St,0,0,Gt.width,Gt.height,Rt,ft,Gt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St,Vt,Gt.width,Gt.height,0,Rt,ft,Gt.data)}}}else{if(et=v.mipmaps,D&&st){et.length>0&&xt++;const $=Me(mt[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,xt,Vt,$.width,$.height)}for(let $=0;$<6;$++)if(it){D?lt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,0,0,0,mt[$].width,mt[$].height,Rt,ft,mt[$].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,0,Vt,mt[$].width,mt[$].height,0,Rt,ft,mt[$].data);for(let St=0;St<et.length;St++){const fe=et[St].image[$].image;D?lt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St+1,0,0,fe.width,fe.height,Rt,ft,fe.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St+1,Vt,fe.width,fe.height,0,Rt,ft,fe.data)}}else{D?lt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,0,0,0,Rt,ft,mt[$]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,0,Vt,Rt,ft,mt[$]);for(let St=0;St<et.length;St++){const Gt=et[St];D?lt&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St+1,0,0,Rt,ft,Gt.image[$]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+$,St+1,Vt,Rt,ft,Gt.image[$])}}}m(v)&&p(s.TEXTURE_CUBE_MAP),X.__version=tt.version,v.onUpdate&&v.onUpdate(v)}y.__version=v.version}function vt(y,v,N,q,tt,X){const Ct=r.convert(N.format,N.colorSpace),ot=r.convert(N.type),At=b(N.internalFormat,Ct,ot,N.colorSpace),wt=n.get(v),it=n.get(N);if(it.__renderTarget=v,!wt.__hasExternalTextures){const mt=Math.max(1,v.width>>X),Nt=Math.max(1,v.height>>X);tt===s.TEXTURE_3D||tt===s.TEXTURE_2D_ARRAY?e.texImage3D(tt,X,At,mt,Nt,v.depth,0,Ct,ot,null):e.texImage2D(tt,X,At,mt,Nt,0,Ct,ot,null)}e.bindFramebuffer(s.FRAMEBUFFER,y),bt(v)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,q,tt,it.__webglTexture,0,ge(v)):(tt===s.TEXTURE_2D||tt>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&tt<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,q,tt,it.__webglTexture,X),e.bindFramebuffer(s.FRAMEBUFFER,null)}function It(y,v,N){if(s.bindRenderbuffer(s.RENDERBUFFER,y),v.depthBuffer){const q=v.depthTexture,tt=q&&q.isDepthTexture?q.type:null,X=E(v.stencilBuffer,tt),Ct=v.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,ot=ge(v);bt(v)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ot,X,v.width,v.height):N?s.renderbufferStorageMultisample(s.RENDERBUFFER,ot,X,v.width,v.height):s.renderbufferStorage(s.RENDERBUFFER,X,v.width,v.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,Ct,s.RENDERBUFFER,y)}else{const q=v.textures;for(let tt=0;tt<q.length;tt++){const X=q[tt],Ct=r.convert(X.format,X.colorSpace),ot=r.convert(X.type),At=b(X.internalFormat,Ct,ot,X.colorSpace),wt=ge(v);N&&bt(v)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,wt,At,v.width,v.height):bt(v)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,wt,At,v.width,v.height):s.renderbufferStorage(s.RENDERBUFFER,At,v.width,v.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function yt(y,v){if(v&&v.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,y),!(v.depthTexture&&v.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const q=n.get(v.depthTexture);q.__renderTarget=v,(!q.__webglTexture||v.depthTexture.image.width!==v.width||v.depthTexture.image.height!==v.height)&&(v.depthTexture.image.width=v.width,v.depthTexture.image.height=v.height,v.depthTexture.needsUpdate=!0),K(v.depthTexture,0);const tt=q.__webglTexture,X=ge(v);if(v.depthTexture.format===us)bt(v)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0,X):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0);else if(v.depthTexture.format===ds)bt(v)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0,X):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function Kt(y){const v=n.get(y),N=y.isWebGLCubeRenderTarget===!0;if(v.__boundDepthTexture!==y.depthTexture){const q=y.depthTexture;if(v.__depthDisposeCallback&&v.__depthDisposeCallback(),q){const tt=()=>{delete v.__boundDepthTexture,delete v.__depthDisposeCallback,q.removeEventListener("dispose",tt)};q.addEventListener("dispose",tt),v.__depthDisposeCallback=tt}v.__boundDepthTexture=q}if(y.depthTexture&&!v.__autoAllocateDepthBuffer){if(N)throw new Error("target.depthTexture not supported in Cube render targets");const q=y.texture.mipmaps;q&&q.length>0?yt(v.__webglFramebuffer[0],y):yt(v.__webglFramebuffer,y)}else if(N){v.__webglDepthbuffer=[];for(let q=0;q<6;q++)if(e.bindFramebuffer(s.FRAMEBUFFER,v.__webglFramebuffer[q]),v.__webglDepthbuffer[q]===void 0)v.__webglDepthbuffer[q]=s.createRenderbuffer(),It(v.__webglDepthbuffer[q],y,!1);else{const tt=y.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,X=v.__webglDepthbuffer[q];s.bindRenderbuffer(s.RENDERBUFFER,X),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,X)}}else{const q=y.texture.mipmaps;if(q&&q.length>0?e.bindFramebuffer(s.FRAMEBUFFER,v.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,v.__webglFramebuffer),v.__webglDepthbuffer===void 0)v.__webglDepthbuffer=s.createRenderbuffer(),It(v.__webglDepthbuffer,y,!1);else{const tt=y.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,X=v.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,X),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,X)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function Ce(y,v,N){const q=n.get(y);v!==void 0&&vt(q.__webglFramebuffer,y,y.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),N!==void 0&&Kt(y)}function A(y){const v=y.texture,N=n.get(y),q=n.get(v);y.addEventListener("dispose",w);const tt=y.textures,X=y.isWebGLCubeRenderTarget===!0,Ct=tt.length>1;if(Ct||(q.__webglTexture===void 0&&(q.__webglTexture=s.createTexture()),q.__version=v.version,o.memory.textures++),X){N.__webglFramebuffer=[];for(let ot=0;ot<6;ot++)if(v.mipmaps&&v.mipmaps.length>0){N.__webglFramebuffer[ot]=[];for(let At=0;At<v.mipmaps.length;At++)N.__webglFramebuffer[ot][At]=s.createFramebuffer()}else N.__webglFramebuffer[ot]=s.createFramebuffer()}else{if(v.mipmaps&&v.mipmaps.length>0){N.__webglFramebuffer=[];for(let ot=0;ot<v.mipmaps.length;ot++)N.__webglFramebuffer[ot]=s.createFramebuffer()}else N.__webglFramebuffer=s.createFramebuffer();if(Ct)for(let ot=0,At=tt.length;ot<At;ot++){const wt=n.get(tt[ot]);wt.__webglTexture===void 0&&(wt.__webglTexture=s.createTexture(),o.memory.textures++)}if(y.samples>0&&bt(y)===!1){N.__webglMultisampledFramebuffer=s.createFramebuffer(),N.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,N.__webglMultisampledFramebuffer);for(let ot=0;ot<tt.length;ot++){const At=tt[ot];N.__webglColorRenderbuffer[ot]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,N.__webglColorRenderbuffer[ot]);const wt=r.convert(At.format,At.colorSpace),it=r.convert(At.type),mt=b(At.internalFormat,wt,it,At.colorSpace,y.isXRRenderTarget===!0),Nt=ge(y);s.renderbufferStorageMultisample(s.RENDERBUFFER,Nt,mt,y.width,y.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ot,s.RENDERBUFFER,N.__webglColorRenderbuffer[ot])}s.bindRenderbuffer(s.RENDERBUFFER,null),y.depthBuffer&&(N.__webglDepthRenderbuffer=s.createRenderbuffer(),It(N.__webglDepthRenderbuffer,y,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(X){e.bindTexture(s.TEXTURE_CUBE_MAP,q.__webglTexture),Bt(s.TEXTURE_CUBE_MAP,v);for(let ot=0;ot<6;ot++)if(v.mipmaps&&v.mipmaps.length>0)for(let At=0;At<v.mipmaps.length;At++)vt(N.__webglFramebuffer[ot][At],y,v,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ot,At);else vt(N.__webglFramebuffer[ot],y,v,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ot,0);m(v)&&p(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Ct){for(let ot=0,At=tt.length;ot<At;ot++){const wt=tt[ot],it=n.get(wt);let mt=s.TEXTURE_2D;(y.isWebGL3DRenderTarget||y.isWebGLArrayRenderTarget)&&(mt=y.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(mt,it.__webglTexture),Bt(mt,wt),vt(N.__webglFramebuffer,y,wt,s.COLOR_ATTACHMENT0+ot,mt,0),m(wt)&&p(mt)}e.unbindTexture()}else{let ot=s.TEXTURE_2D;if((y.isWebGL3DRenderTarget||y.isWebGLArrayRenderTarget)&&(ot=y.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ot,q.__webglTexture),Bt(ot,v),v.mipmaps&&v.mipmaps.length>0)for(let At=0;At<v.mipmaps.length;At++)vt(N.__webglFramebuffer[At],y,v,s.COLOR_ATTACHMENT0,ot,At);else vt(N.__webglFramebuffer,y,v,s.COLOR_ATTACHMENT0,ot,0);m(v)&&p(ot),e.unbindTexture()}y.depthBuffer&&Kt(y)}function ae(y){const v=y.textures;for(let N=0,q=v.length;N<q;N++){const tt=v[N];if(m(tt)){const X=T(y),Ct=n.get(tt).__webglTexture;e.bindTexture(X,Ct),p(X),e.unbindTexture()}}}const zt=[],Lt=[];function Tt(y){if(y.samples>0){if(bt(y)===!1){const v=y.textures,N=y.width,q=y.height;let tt=s.COLOR_BUFFER_BIT;const X=y.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Ct=n.get(y),ot=v.length>1;if(ot)for(let wt=0;wt<v.length;wt++)e.bindFramebuffer(s.FRAMEBUFFER,Ct.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,Ct.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,Ct.__webglMultisampledFramebuffer);const At=y.texture.mipmaps;At&&At.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ct.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ct.__webglFramebuffer);for(let wt=0;wt<v.length;wt++){if(y.resolveDepthBuffer&&(y.depthBuffer&&(tt|=s.DEPTH_BUFFER_BIT),y.stencilBuffer&&y.resolveStencilBuffer&&(tt|=s.STENCIL_BUFFER_BIT)),ot){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,Ct.__webglColorRenderbuffer[wt]);const it=n.get(v[wt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,it,0)}s.blitFramebuffer(0,0,N,q,0,0,N,q,tt,s.NEAREST),c===!0&&(zt.length=0,Lt.length=0,zt.push(s.COLOR_ATTACHMENT0+wt),y.depthBuffer&&y.resolveDepthBuffer===!1&&(zt.push(X),Lt.push(X),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Lt)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,zt))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ot)for(let wt=0;wt<v.length;wt++){e.bindFramebuffer(s.FRAMEBUFFER,Ct.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.RENDERBUFFER,Ct.__webglColorRenderbuffer[wt]);const it=n.get(v[wt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,Ct.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.TEXTURE_2D,it,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Ct.__webglMultisampledFramebuffer)}else if(y.depthBuffer&&y.resolveDepthBuffer===!1&&c){const v=y.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[v])}}}function ge(y){return Math.min(i.maxSamples,y.samples)}function bt(y){const v=n.get(y);return y.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&v.__useRenderToTexture!==!1}function $t(y){const v=o.render.frame;h.get(y)!==v&&(h.set(y,v),y.update())}function De(y,v){const N=y.colorSpace,q=y.format,tt=y.type;return y.isCompressedTexture===!0||y.isVideoTexture===!0||N!==Gi&&N!==Kn&&(re.getTransfer(N)===ce?(q!==cn||tt!==Bn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",N)),v}function Me(y){return typeof HTMLImageElement<"u"&&y instanceof HTMLImageElement?(l.width=y.naturalWidth||y.width,l.height=y.naturalHeight||y.height):typeof VideoFrame<"u"&&y instanceof VideoFrame?(l.width=y.displayWidth,l.height=y.displayHeight):(l.width=y.width,l.height=y.height),l}this.allocateTextureUnit=G,this.resetTextureUnits=z,this.setTexture2D=K,this.setTexture2DArray=H,this.setTexture3D=rt,this.setTextureCube=V,this.rebindTextures=Ce,this.setupRenderTarget=A,this.updateRenderTargetMipmap=ae,this.updateMultisampleRenderTarget=Tt,this.setupDepthRenderbuffer=Kt,this.setupFrameBufferTexture=vt,this.useMultisampledRTT=bt}function Qm(s,t){function e(n,i=Kn){let r;const o=re.getTransfer(i);if(n===Bn)return s.UNSIGNED_BYTE;if(n===la)return s.UNSIGNED_SHORT_4_4_4_4;if(n===ca)return s.UNSIGNED_SHORT_5_5_5_1;if(n===ec)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===nc)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===Ql)return s.BYTE;if(n===tc)return s.SHORT;if(n===cs)return s.UNSIGNED_SHORT;if(n===aa)return s.INT;if(n===gi)return s.UNSIGNED_INT;if(n===Nn)return s.FLOAT;if(n===ps)return s.HALF_FLOAT;if(n===ic)return s.ALPHA;if(n===sc)return s.RGB;if(n===cn)return s.RGBA;if(n===us)return s.DEPTH_COMPONENT;if(n===ds)return s.DEPTH_STENCIL;if(n===rc)return s.RED;if(n===ha)return s.RED_INTEGER;if(n===oc)return s.RG;if(n===ua)return s.RG_INTEGER;if(n===da)return s.RGBA_INTEGER;if(n===Js||n===Qs||n===tr||n===er)if(o===ce)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Js)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Qs)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===tr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===er)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Js)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Qs)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===tr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===er)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Mo||n===So||n===Eo||n===yo)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Mo)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===So)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Eo)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===yo)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===To||n===bo||n===Ao)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===To||n===bo)return o===ce?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Ao)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===wo||n===Ro||n===Co||n===Do||n===Lo||n===Po||n===Io||n===Uo||n===No||n===Oo||n===Fo||n===Bo||n===ko||n===zo)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===wo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ro)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Co)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Do)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Lo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Po)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Io)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Uo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===No)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Oo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Fo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Bo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===ko)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===zo)return o===ce?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ho||n===Go||n===Vo)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ho)return o===ce?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Go)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Vo)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Wo||n===Xo||n===qo||n===Yo)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Wo)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Xo)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===qo)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Yo)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===hs?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}const tg=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,eg=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class ng{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new Mc(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new Hn({vertexShader:tg,fragmentShader:eg,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new Ie(new jn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ig extends Xi{constructor(t,e){super();const n=this;let i=null,r=1,o=null,a="local-floor",c=1,l=null,h=null,u=null,d=null,f=null,g=null;const _=typeof XRWebGLBinding<"u",m=new ng,p={},T=e.getContextAttributes();let b=null,E=null;const L=[],R=[],w=new he;let O=null;const S=new on;S.viewport=new Se;const M=new on;M.viewport=new Se;const C=[S,M],z=new yu;let G=null,W=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let Q=L[Y];return Q===void 0&&(Q=new Yr,L[Y]=Q),Q.getTargetRaySpace()},this.getControllerGrip=function(Y){let Q=L[Y];return Q===void 0&&(Q=new Yr,L[Y]=Q),Q.getGripSpace()},this.getHand=function(Y){let Q=L[Y];return Q===void 0&&(Q=new Yr,L[Y]=Q),Q.getHandSpace()};function K(Y){const Q=R.indexOf(Y.inputSource);if(Q===-1)return;const vt=L[Q];vt!==void 0&&(vt.update(Y.inputSource,Y.frame,l||o),vt.dispatchEvent({type:Y.type,data:Y.inputSource}))}function H(){i.removeEventListener("select",K),i.removeEventListener("selectstart",K),i.removeEventListener("selectend",K),i.removeEventListener("squeeze",K),i.removeEventListener("squeezestart",K),i.removeEventListener("squeezeend",K),i.removeEventListener("end",H),i.removeEventListener("inputsourceschange",rt);for(let Y=0;Y<L.length;Y++){const Q=R[Y];Q!==null&&(R[Y]=null,L[Y].disconnect(Q))}G=null,W=null,m.reset();for(const Y in p)delete p[Y];t.setRenderTarget(b),f=null,d=null,u=null,i=null,E=null,ne.stop(),n.isPresenting=!1,t.setPixelRatio(O),t.setSize(w.width,w.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){r=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){a=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(Y){l=Y},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u===null&&_&&(u=new XRWebGLBinding(i,e)),u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(Y){if(i=Y,i!==null){if(b=t.getRenderTarget(),i.addEventListener("select",K),i.addEventListener("selectstart",K),i.addEventListener("selectend",K),i.addEventListener("squeeze",K),i.addEventListener("squeezestart",K),i.addEventListener("squeezeend",K),i.addEventListener("end",H),i.addEventListener("inputsourceschange",rt),T.xrCompatible!==!0&&await e.makeXRCompatible(),O=t.getPixelRatio(),t.getSize(w),_&&"createProjectionLayer"in XRWebGLBinding.prototype){let vt=null,It=null,yt=null;T.depth&&(yt=T.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,vt=T.stencil?ds:us,It=T.stencil?hs:gi);const Kt={colorFormat:e.RGBA8,depthFormat:yt,scaleFactor:r};u=this.getBinding(),d=u.createProjectionLayer(Kt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),E=new _i(d.textureWidth,d.textureHeight,{format:cn,type:Bn,depthTexture:new xc(d.textureWidth,d.textureHeight,It,void 0,void 0,void 0,void 0,void 0,void 0,vt),stencilBuffer:T.stencil,colorSpace:t.outputColorSpace,samples:T.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const vt={antialias:T.antialias,alpha:!0,depth:T.depth,stencil:T.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(i,e,vt),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),E=new _i(f.framebufferWidth,f.framebufferHeight,{format:cn,type:Bn,colorSpace:t.outputColorSpace,stencilBuffer:T.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await i.requestReferenceSpace(a),ne.setContext(i),ne.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function rt(Y){for(let Q=0;Q<Y.removed.length;Q++){const vt=Y.removed[Q],It=R.indexOf(vt);It>=0&&(R[It]=null,L[It].disconnect(vt))}for(let Q=0;Q<Y.added.length;Q++){const vt=Y.added[Q];let It=R.indexOf(vt);if(It===-1){for(let Kt=0;Kt<L.length;Kt++)if(Kt>=R.length){R.push(vt),It=Kt;break}else if(R[Kt]===null){R[Kt]=vt,It=Kt;break}if(It===-1)break}const yt=L[It];yt&&yt.connect(vt)}}const V=new F,ht=new F;function ut(Y,Q,vt){V.setFromMatrixPosition(Q.matrixWorld),ht.setFromMatrixPosition(vt.matrixWorld);const It=V.distanceTo(ht),yt=Q.projectionMatrix.elements,Kt=vt.projectionMatrix.elements,Ce=yt[14]/(yt[10]-1),A=yt[14]/(yt[10]+1),ae=(yt[9]+1)/yt[5],zt=(yt[9]-1)/yt[5],Lt=(yt[8]-1)/yt[0],Tt=(Kt[8]+1)/Kt[0],ge=Ce*Lt,bt=Ce*Tt,$t=It/(-Lt+Tt),De=$t*-Lt;if(Q.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(De),Y.translateZ($t),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),yt[10]===-1)Y.projectionMatrix.copy(Q.projectionMatrix),Y.projectionMatrixInverse.copy(Q.projectionMatrixInverse);else{const Me=Ce+$t,y=A+$t,v=ge-De,N=bt+(It-De),q=ae*A/y*Me,tt=zt*A/y*Me;Y.projectionMatrix.makePerspective(v,N,q,tt,Me,y),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function _t(Y,Q){Q===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(Q.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(i===null)return;let Q=Y.near,vt=Y.far;m.texture!==null&&(m.depthNear>0&&(Q=m.depthNear),m.depthFar>0&&(vt=m.depthFar)),z.near=M.near=S.near=Q,z.far=M.far=S.far=vt,(G!==z.near||W!==z.far)&&(i.updateRenderState({depthNear:z.near,depthFar:z.far}),G=z.near,W=z.far),z.layers.mask=Y.layers.mask|6,S.layers.mask=z.layers.mask&3,M.layers.mask=z.layers.mask&5;const It=Y.parent,yt=z.cameras;_t(z,It);for(let Kt=0;Kt<yt.length;Kt++)_t(yt[Kt],It);yt.length===2?ut(z,S,M):z.projectionMatrix.copy(S.projectionMatrix),Bt(Y,z,It)};function Bt(Y,Q,vt){vt===null?Y.matrix.copy(Q.matrixWorld):(Y.matrix.copy(vt.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(Q.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(Q.projectionMatrix),Y.projectionMatrixInverse.copy(Q.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=Ko*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return z},this.getFoveation=function(){if(!(d===null&&f===null))return c},this.setFoveation=function(Y){c=Y,d!==null&&(d.fixedFoveation=Y),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Y)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(z)},this.getCameraTexture=function(Y){return p[Y]};let Yt=null;function jt(Y,Q){if(h=Q.getViewerPose(l||o),g=Q,h!==null){const vt=h.views;f!==null&&(t.setRenderTargetFramebuffer(E,f.framebuffer),t.setRenderTarget(E));let It=!1;vt.length!==z.cameras.length&&(z.cameras.length=0,It=!0);for(let A=0;A<vt.length;A++){const ae=vt[A];let zt=null;if(f!==null)zt=f.getViewport(ae);else{const Tt=u.getViewSubImage(d,ae);zt=Tt.viewport,A===0&&(t.setRenderTargetTextures(E,Tt.colorTexture,Tt.depthStencilTexture),t.setRenderTarget(E))}let Lt=C[A];Lt===void 0&&(Lt=new on,Lt.layers.enable(A),Lt.viewport=new Se,C[A]=Lt),Lt.matrix.fromArray(ae.transform.matrix),Lt.matrix.decompose(Lt.position,Lt.quaternion,Lt.scale),Lt.projectionMatrix.fromArray(ae.projectionMatrix),Lt.projectionMatrixInverse.copy(Lt.projectionMatrix).invert(),Lt.viewport.set(zt.x,zt.y,zt.width,zt.height),A===0&&(z.matrix.copy(Lt.matrix),z.matrix.decompose(z.position,z.quaternion,z.scale)),It===!0&&z.cameras.push(Lt)}const yt=i.enabledFeatures;if(yt&&yt.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&_){u=n.getBinding();const A=u.getDepthInformation(vt[0]);A&&A.isValid&&A.texture&&m.init(A,i.renderState)}if(yt&&yt.includes("camera-access")&&_){t.state.unbindTexture(),u=n.getBinding();for(let A=0;A<vt.length;A++){const ae=vt[A].camera;if(ae){let zt=p[ae];zt||(zt=new Mc,p[ae]=zt);const Lt=u.getCameraImage(ae);zt.sourceTexture=Lt}}}}for(let vt=0;vt<L.length;vt++){const It=R[vt],yt=L[vt];It!==null&&yt!==void 0&&yt.update(It,Q,l||o)}Yt&&Yt(Y,Q),Q.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Q}),g=null}const ne=new Sc;ne.setAnimationLoop(jt),this.setAnimationLoop=function(Y){Yt=Y},this.dispose=function(){}}}const oi=new kn,sg=new Ee;function rg(s,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,fc(s)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,T,b,E){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,E)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?c(m,p,T,b):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===qe&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===qe&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const T=t.get(p),b=T.envMap,E=T.envMapRotation;b&&(m.envMap.value=b,oi.copy(E),oi.x*=-1,oi.y*=-1,oi.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(oi.y*=-1,oi.z*=-1),m.envMapRotation.value.setFromMatrix4(sg.makeRotationFromEuler(oi)),m.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,T,b){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*T,m.scale.value=b*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,T){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===qe&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=T.texture,m.transmissionSamplerSize.value.set(T.width,T.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const T=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(T.matrixWorld),m.nearDistance.value=T.shadow.camera.near,m.farDistance.value=T.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function og(s,t,e,n){let i={},r={},o=[];const a=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function c(T,b){const E=b.program;n.uniformBlockBinding(T,E)}function l(T,b){let E=i[T.id];E===void 0&&(g(T),E=h(T),i[T.id]=E,T.addEventListener("dispose",m));const L=b.program;n.updateUBOMapping(T,L);const R=t.render.frame;r[T.id]!==R&&(d(T),r[T.id]=R)}function h(T){const b=u();T.__bindingPointIndex=b;const E=s.createBuffer(),L=T.__size,R=T.usage;return s.bindBuffer(s.UNIFORM_BUFFER,E),s.bufferData(s.UNIFORM_BUFFER,L,R),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,b,E),E}function u(){for(let T=0;T<a;T++)if(o.indexOf(T)===-1)return o.push(T),T;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(T){const b=i[T.id],E=T.uniforms,L=T.__cache;s.bindBuffer(s.UNIFORM_BUFFER,b);for(let R=0,w=E.length;R<w;R++){const O=Array.isArray(E[R])?E[R]:[E[R]];for(let S=0,M=O.length;S<M;S++){const C=O[S];if(f(C,R,S,L)===!0){const z=C.__offset,G=Array.isArray(C.value)?C.value:[C.value];let W=0;for(let K=0;K<G.length;K++){const H=G[K],rt=_(H);typeof H=="number"||typeof H=="boolean"?(C.__data[0]=H,s.bufferSubData(s.UNIFORM_BUFFER,z+W,C.__data)):H.isMatrix3?(C.__data[0]=H.elements[0],C.__data[1]=H.elements[1],C.__data[2]=H.elements[2],C.__data[3]=0,C.__data[4]=H.elements[3],C.__data[5]=H.elements[4],C.__data[6]=H.elements[5],C.__data[7]=0,C.__data[8]=H.elements[6],C.__data[9]=H.elements[7],C.__data[10]=H.elements[8],C.__data[11]=0):(H.toArray(C.__data,W),W+=rt.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,z,C.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function f(T,b,E,L){const R=T.value,w=b+"_"+E;if(L[w]===void 0)return typeof R=="number"||typeof R=="boolean"?L[w]=R:L[w]=R.clone(),!0;{const O=L[w];if(typeof R=="number"||typeof R=="boolean"){if(O!==R)return L[w]=R,!0}else if(O.equals(R)===!1)return O.copy(R),!0}return!1}function g(T){const b=T.uniforms;let E=0;const L=16;for(let w=0,O=b.length;w<O;w++){const S=Array.isArray(b[w])?b[w]:[b[w]];for(let M=0,C=S.length;M<C;M++){const z=S[M],G=Array.isArray(z.value)?z.value:[z.value];for(let W=0,K=G.length;W<K;W++){const H=G[W],rt=_(H),V=E%L,ht=V%rt.boundary,ut=V+ht;E+=ht,ut!==0&&L-ut<rt.storage&&(E+=L-ut),z.__data=new Float32Array(rt.storage/Float32Array.BYTES_PER_ELEMENT),z.__offset=E,E+=rt.storage}}}const R=E%L;return R>0&&(E+=L-R),T.__size=E,T.__cache={},this}function _(T){const b={boundary:0,storage:0};return typeof T=="number"||typeof T=="boolean"?(b.boundary=4,b.storage=4):T.isVector2?(b.boundary=8,b.storage=8):T.isVector3||T.isColor?(b.boundary=16,b.storage=12):T.isVector4?(b.boundary=16,b.storage=16):T.isMatrix3?(b.boundary=48,b.storage=48):T.isMatrix4?(b.boundary=64,b.storage=64):T.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",T),b}function m(T){const b=T.target;b.removeEventListener("dispose",m);const E=o.indexOf(b.__bindingPointIndex);o.splice(E,1),s.deleteBuffer(i[b.id]),delete i[b.id],delete r[b.id]}function p(){for(const T in i)s.deleteBuffer(i[T]);o=[],i={},r={}}return{bind:c,update:l,dispose:p}}class ag{constructor(t={}){const{canvas:e=zh(),context:n=null,depth:i=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const T=[],b=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Zn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const E=this;let L=!1;this._outputColorSpace=tn;let R=0,w=0,O=null,S=-1,M=null;const C=new Se,z=new Se;let G=null;const W=new qt(0);let K=0,H=e.width,rt=e.height,V=1,ht=null,ut=null;const _t=new Se(0,0,H,rt),Bt=new Se(0,0,H,rt);let Yt=!1;const jt=new gc;let ne=!1,Y=!1;const Q=new Ee,vt=new F,It=new Se,yt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Kt=!1;function Ce(){return O===null?V:1}let A=n;function ae(x,I){return e.getContext(x,I)}try{const x={alpha:!0,depth:i,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${oa}`),e.addEventListener("webglcontextlost",lt,!1),e.addEventListener("webglcontextrestored",xt,!1),e.addEventListener("webglcontextcreationerror",et,!1),A===null){const I="webgl2";if(A=ae(I,x),A===null)throw ae(I)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(x){throw console.error("THREE.WebGLRenderer: "+x.message),x}let zt,Lt,Tt,ge,bt,$t,De,Me,y,v,N,q,tt,X,Ct,ot,At,wt,it,mt,Nt,Rt,ft,Vt;function D(){zt=new _p(A),zt.init(),Rt=new Qm(A,zt),Lt=new hp(A,zt,t,Rt),Tt=new jm(A,zt),Lt.reversedDepthBuffer&&d&&Tt.buffers.depth.setReversed(!0),ge=new Mp(A),bt=new Bm,$t=new Jm(A,zt,Tt,bt,Lt,Rt,ge),De=new dp(E),Me=new gp(E),y=new bu(A),ft=new lp(A,y),v=new vp(A,y,ge,ft),N=new Ep(A,v,y,ge),it=new Sp(A,Lt,$t),ot=new up(bt),q=new Fm(E,De,Me,zt,Lt,ft,ot),tt=new rg(E,bt),X=new zm,Ct=new qm(zt),wt=new ap(E,De,Me,Tt,N,f,c),At=new $m(E,N,Lt),Vt=new og(A,ge,Lt,Tt),mt=new cp(A,zt,ge),Nt=new xp(A,zt,ge),ge.programs=q.programs,E.capabilities=Lt,E.extensions=zt,E.properties=bt,E.renderLists=X,E.shadowMap=At,E.state=Tt,E.info=ge}D();const st=new ig(E,A);this.xr=st,this.getContext=function(){return A},this.getContextAttributes=function(){return A.getContextAttributes()},this.forceContextLoss=function(){const x=zt.get("WEBGL_lose_context");x&&x.loseContext()},this.forceContextRestore=function(){const x=zt.get("WEBGL_lose_context");x&&x.restoreContext()},this.getPixelRatio=function(){return V},this.setPixelRatio=function(x){x!==void 0&&(V=x,this.setSize(H,rt,!1))},this.getSize=function(x){return x.set(H,rt)},this.setSize=function(x,I,B=!0){if(st.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}H=x,rt=I,e.width=Math.floor(x*V),e.height=Math.floor(I*V),B===!0&&(e.style.width=x+"px",e.style.height=I+"px"),this.setViewport(0,0,x,I)},this.getDrawingBufferSize=function(x){return x.set(H*V,rt*V).floor()},this.setDrawingBufferSize=function(x,I,B){H=x,rt=I,V=B,e.width=Math.floor(x*B),e.height=Math.floor(I*B),this.setViewport(0,0,x,I)},this.getCurrentViewport=function(x){return x.copy(C)},this.getViewport=function(x){return x.copy(_t)},this.setViewport=function(x,I,B,k){x.isVector4?_t.set(x.x,x.y,x.z,x.w):_t.set(x,I,B,k),Tt.viewport(C.copy(_t).multiplyScalar(V).round())},this.getScissor=function(x){return x.copy(Bt)},this.setScissor=function(x,I,B,k){x.isVector4?Bt.set(x.x,x.y,x.z,x.w):Bt.set(x,I,B,k),Tt.scissor(z.copy(Bt).multiplyScalar(V).round())},this.getScissorTest=function(){return Yt},this.setScissorTest=function(x){Tt.setScissorTest(Yt=x)},this.setOpaqueSort=function(x){ht=x},this.setTransparentSort=function(x){ut=x},this.getClearColor=function(x){return x.copy(wt.getClearColor())},this.setClearColor=function(){wt.setClearColor(...arguments)},this.getClearAlpha=function(){return wt.getClearAlpha()},this.setClearAlpha=function(){wt.setClearAlpha(...arguments)},this.clear=function(x=!0,I=!0,B=!0){let k=0;if(x){let U=!1;if(O!==null){const nt=O.texture.format;U=nt===da||nt===ua||nt===ha}if(U){const nt=O.texture.type,pt=nt===Bn||nt===gi||nt===cs||nt===hs||nt===la||nt===ca,Mt=wt.getClearColor(),gt=wt.getClearAlpha(),Ut=Mt.r,kt=Mt.g,Dt=Mt.b;pt?(g[0]=Ut,g[1]=kt,g[2]=Dt,g[3]=gt,A.clearBufferuiv(A.COLOR,0,g)):(_[0]=Ut,_[1]=kt,_[2]=Dt,_[3]=gt,A.clearBufferiv(A.COLOR,0,_))}else k|=A.COLOR_BUFFER_BIT}I&&(k|=A.DEPTH_BUFFER_BIT),B&&(k|=A.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),A.clear(k)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",lt,!1),e.removeEventListener("webglcontextrestored",xt,!1),e.removeEventListener("webglcontextcreationerror",et,!1),wt.dispose(),X.dispose(),Ct.dispose(),bt.dispose(),De.dispose(),Me.dispose(),N.dispose(),ft.dispose(),Vt.dispose(),q.dispose(),st.dispose(),st.removeEventListener("sessionstart",gn),st.removeEventListener("sessionend",Da),Qn.stop()};function lt(x){x.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),L=!0}function xt(){console.log("THREE.WebGLRenderer: Context Restored."),L=!1;const x=ge.autoReset,I=At.enabled,B=At.autoUpdate,k=At.needsUpdate,U=At.type;D(),ge.autoReset=x,At.enabled=I,At.autoUpdate=B,At.needsUpdate=k,At.type=U}function et(x){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",x.statusMessage)}function $(x){const I=x.target;I.removeEventListener("dispose",$),St(I)}function St(x){Gt(x),bt.remove(x)}function Gt(x){const I=bt.get(x).programs;I!==void 0&&(I.forEach(function(B){q.releaseProgram(B)}),x.isShaderMaterial&&q.releaseShaderCache(x))}this.renderBufferDirect=function(x,I,B,k,U,nt){I===null&&(I=yt);const pt=U.isMesh&&U.matrixWorld.determinant()<0,Mt=Xc(x,I,B,k,U);Tt.setMaterial(k,pt);let gt=B.index,Ut=1;if(k.wireframe===!0){if(gt=v.getWireframeAttribute(B),gt===void 0)return;Ut=2}const kt=B.drawRange,Dt=B.attributes.position;let Jt=kt.start*Ut,le=(kt.start+kt.count)*Ut;nt!==null&&(Jt=Math.max(Jt,nt.start*Ut),le=Math.min(le,(nt.start+nt.count)*Ut)),gt!==null?(Jt=Math.max(Jt,0),le=Math.min(le,gt.count)):Dt!=null&&(Jt=Math.max(Jt,0),le=Math.min(le,Dt.count));const xe=le-Jt;if(xe<0||xe===1/0)return;ft.setup(U,k,Mt,B,gt);let pe,ue=mt;if(gt!==null&&(pe=y.get(gt),ue=Nt,ue.setIndex(pe)),U.isMesh)k.wireframe===!0?(Tt.setLineWidth(k.wireframeLinewidth*Ce()),ue.setMode(A.LINES)):ue.setMode(A.TRIANGLES);else if(U.isLine){let Pt=k.linewidth;Pt===void 0&&(Pt=1),Tt.setLineWidth(Pt*Ce()),U.isLineSegments?ue.setMode(A.LINES):U.isLineLoop?ue.setMode(A.LINE_LOOP):ue.setMode(A.LINE_STRIP)}else U.isPoints?ue.setMode(A.POINTS):U.isSprite&&ue.setMode(A.TRIANGLES);if(U.isBatchedMesh)if(U._multiDrawInstances!==null)fs("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),ue.renderMultiDrawInstances(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount,U._multiDrawInstances);else if(zt.get("WEBGL_multi_draw"))ue.renderMultiDraw(U._multiDrawStarts,U._multiDrawCounts,U._multiDrawCount);else{const Pt=U._multiDrawStarts,_e=U._multiDrawCounts,se=U._multiDrawCount,$e=gt?y.get(gt).bytesPerElement:1,Mi=bt.get(k).currentProgram.getUniforms();for(let Ze=0;Ze<se;Ze++)Mi.setValue(A,"_gl_DrawID",Ze),ue.render(Pt[Ze]/$e,_e[Ze])}else if(U.isInstancedMesh)ue.renderInstances(Jt,xe,U.count);else if(B.isInstancedBufferGeometry){const Pt=B._maxInstanceCount!==void 0?B._maxInstanceCount:1/0,_e=Math.min(B.instanceCount,Pt);ue.renderInstances(Jt,xe,_e)}else ue.render(Jt,xe)};function fe(x,I,B){x.transparent===!0&&x.side===an&&x.forceSinglePass===!1?(x.side=qe,x.needsUpdate=!0,ys(x,I,B),x.side=Fn,x.needsUpdate=!0,ys(x,I,B),x.side=an):ys(x,I,B)}this.compile=function(x,I,B=null){B===null&&(B=x),p=Ct.get(B),p.init(I),b.push(p),B.traverseVisible(function(U){U.isLight&&U.layers.test(I.layers)&&(p.pushLight(U),U.castShadow&&p.pushShadow(U))}),x!==B&&x.traverseVisible(function(U){U.isLight&&U.layers.test(I.layers)&&(p.pushLight(U),U.castShadow&&p.pushShadow(U))}),p.setupLights();const k=new Set;return x.traverse(function(U){if(!(U.isMesh||U.isPoints||U.isLine||U.isSprite))return;const nt=U.material;if(nt)if(Array.isArray(nt))for(let pt=0;pt<nt.length;pt++){const Mt=nt[pt];fe(Mt,B,U),k.add(Mt)}else fe(nt,B,U),k.add(nt)}),p=b.pop(),k},this.compileAsync=function(x,I,B=null){const k=this.compile(x,I,B);return new Promise(U=>{function nt(){if(k.forEach(function(pt){bt.get(pt).currentProgram.isReady()&&k.delete(pt)}),k.size===0){U(x);return}setTimeout(nt,10)}zt.get("KHR_parallel_shader_compile")!==null?nt():setTimeout(nt,10)})};let oe=null;function bn(x){oe&&oe(x)}function gn(){Qn.stop()}function Da(){Qn.start()}const Qn=new Sc;Qn.setAnimationLoop(bn),typeof self<"u"&&Qn.setContext(self),this.setAnimationLoop=function(x){oe=x,st.setAnimationLoop(x),x===null?Qn.stop():Qn.start()},st.addEventListener("sessionstart",gn),st.addEventListener("sessionend",Da),this.render=function(x,I){if(I!==void 0&&I.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;if(x.matrixWorldAutoUpdate===!0&&x.updateMatrixWorld(),I.parent===null&&I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),st.enabled===!0&&st.isPresenting===!0&&(st.cameraAutoUpdate===!0&&st.updateCamera(I),I=st.getCamera()),x.isScene===!0&&x.onBeforeRender(E,x,I,O),p=Ct.get(x,b.length),p.init(I),b.push(p),Q.multiplyMatrices(I.projectionMatrix,I.matrixWorldInverse),jt.setFromProjectionMatrix(Q,En,I.reversedDepth),Y=this.localClippingEnabled,ne=ot.init(this.clippingPlanes,Y),m=X.get(x,T.length),m.init(),T.push(m),st.enabled===!0&&st.isPresenting===!0){const nt=E.xr.getDepthSensingMesh();nt!==null&&yr(nt,I,-1/0,E.sortObjects)}yr(x,I,0,E.sortObjects),m.finish(),E.sortObjects===!0&&m.sort(ht,ut),Kt=st.enabled===!1||st.isPresenting===!1||st.hasDepthSensing()===!1,Kt&&wt.addToRenderList(m,x),this.info.render.frame++,ne===!0&&ot.beginShadows();const B=p.state.shadowsArray;At.render(B,x,I),ne===!0&&ot.endShadows(),this.info.autoReset===!0&&this.info.reset();const k=m.opaque,U=m.transmissive;if(p.setupLights(),I.isArrayCamera){const nt=I.cameras;if(U.length>0)for(let pt=0,Mt=nt.length;pt<Mt;pt++){const gt=nt[pt];Pa(k,U,x,gt)}Kt&&wt.render(x);for(let pt=0,Mt=nt.length;pt<Mt;pt++){const gt=nt[pt];La(m,x,gt,gt.viewport)}}else U.length>0&&Pa(k,U,x,I),Kt&&wt.render(x),La(m,x,I);O!==null&&w===0&&($t.updateMultisampleRenderTarget(O),$t.updateRenderTargetMipmap(O)),x.isScene===!0&&x.onAfterRender(E,x,I),ft.resetDefaultState(),S=-1,M=null,b.pop(),b.length>0?(p=b[b.length-1],ne===!0&&ot.setGlobalState(E.clippingPlanes,p.state.camera)):p=null,T.pop(),T.length>0?m=T[T.length-1]:m=null};function yr(x,I,B,k){if(x.visible===!1)return;if(x.layers.test(I.layers)){if(x.isGroup)B=x.renderOrder;else if(x.isLOD)x.autoUpdate===!0&&x.update(I);else if(x.isLight)p.pushLight(x),x.castShadow&&p.pushShadow(x);else if(x.isSprite){if(!x.frustumCulled||jt.intersectsSprite(x)){k&&It.setFromMatrixPosition(x.matrixWorld).applyMatrix4(Q);const pt=N.update(x),Mt=x.material;Mt.visible&&m.push(x,pt,Mt,B,It.z,null)}}else if((x.isMesh||x.isLine||x.isPoints)&&(!x.frustumCulled||jt.intersectsObject(x))){const pt=N.update(x),Mt=x.material;if(k&&(x.boundingSphere!==void 0?(x.boundingSphere===null&&x.computeBoundingSphere(),It.copy(x.boundingSphere.center)):(pt.boundingSphere===null&&pt.computeBoundingSphere(),It.copy(pt.boundingSphere.center)),It.applyMatrix4(x.matrixWorld).applyMatrix4(Q)),Array.isArray(Mt)){const gt=pt.groups;for(let Ut=0,kt=gt.length;Ut<kt;Ut++){const Dt=gt[Ut],Jt=Mt[Dt.materialIndex];Jt&&Jt.visible&&m.push(x,pt,Jt,B,It.z,Dt)}}else Mt.visible&&m.push(x,pt,Mt,B,It.z,null)}}const nt=x.children;for(let pt=0,Mt=nt.length;pt<Mt;pt++)yr(nt[pt],I,B,k)}function La(x,I,B,k){const U=x.opaque,nt=x.transmissive,pt=x.transparent;p.setupLightsView(B),ne===!0&&ot.setGlobalState(E.clippingPlanes,B),k&&Tt.viewport(C.copy(k)),U.length>0&&Es(U,I,B),nt.length>0&&Es(nt,I,B),pt.length>0&&Es(pt,I,B),Tt.buffers.depth.setTest(!0),Tt.buffers.depth.setMask(!0),Tt.buffers.color.setMask(!0),Tt.setPolygonOffset(!1)}function Pa(x,I,B,k){if((B.isScene===!0?B.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[k.id]===void 0&&(p.state.transmissionRenderTarget[k.id]=new _i(1,1,{generateMipmaps:!0,type:zt.has("EXT_color_buffer_half_float")||zt.has("EXT_color_buffer_float")?ps:Bn,minFilter:fi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:re.workingColorSpace}));const nt=p.state.transmissionRenderTarget[k.id],pt=k.viewport||C;nt.setSize(pt.z*E.transmissionResolutionScale,pt.w*E.transmissionResolutionScale);const Mt=E.getRenderTarget(),gt=E.getActiveCubeFace(),Ut=E.getActiveMipmapLevel();E.setRenderTarget(nt),E.getClearColor(W),K=E.getClearAlpha(),K<1&&E.setClearColor(16777215,.5),E.clear(),Kt&&wt.render(B);const kt=E.toneMapping;E.toneMapping=Zn;const Dt=k.viewport;if(k.viewport!==void 0&&(k.viewport=void 0),p.setupLightsView(k),ne===!0&&ot.setGlobalState(E.clippingPlanes,k),Es(x,B,k),$t.updateMultisampleRenderTarget(nt),$t.updateRenderTargetMipmap(nt),zt.has("WEBGL_multisampled_render_to_texture")===!1){let Jt=!1;for(let le=0,xe=I.length;le<xe;le++){const pe=I[le],ue=pe.object,Pt=pe.geometry,_e=pe.material,se=pe.group;if(_e.side===an&&ue.layers.test(k.layers)){const $e=_e.side;_e.side=qe,_e.needsUpdate=!0,Ia(ue,B,k,Pt,_e,se),_e.side=$e,_e.needsUpdate=!0,Jt=!0}}Jt===!0&&($t.updateMultisampleRenderTarget(nt),$t.updateRenderTargetMipmap(nt))}E.setRenderTarget(Mt,gt,Ut),E.setClearColor(W,K),Dt!==void 0&&(k.viewport=Dt),E.toneMapping=kt}function Es(x,I,B){const k=I.isScene===!0?I.overrideMaterial:null;for(let U=0,nt=x.length;U<nt;U++){const pt=x[U],Mt=pt.object,gt=pt.geometry,Ut=pt.group;let kt=pt.material;kt.allowOverride===!0&&k!==null&&(kt=k),Mt.layers.test(B.layers)&&Ia(Mt,I,B,gt,kt,Ut)}}function Ia(x,I,B,k,U,nt){x.onBeforeRender(E,I,B,k,U,nt),x.modelViewMatrix.multiplyMatrices(B.matrixWorldInverse,x.matrixWorld),x.normalMatrix.getNormalMatrix(x.modelViewMatrix),U.onBeforeRender(E,I,B,k,x,nt),U.transparent===!0&&U.side===an&&U.forceSinglePass===!1?(U.side=qe,U.needsUpdate=!0,E.renderBufferDirect(B,I,k,U,x,nt),U.side=Fn,U.needsUpdate=!0,E.renderBufferDirect(B,I,k,U,x,nt),U.side=an):E.renderBufferDirect(B,I,k,U,x,nt),x.onAfterRender(E,I,B,k,U,nt)}function ys(x,I,B){I.isScene!==!0&&(I=yt);const k=bt.get(x),U=p.state.lights,nt=p.state.shadowsArray,pt=U.state.version,Mt=q.getParameters(x,U.state,nt,I,B),gt=q.getProgramCacheKey(Mt);let Ut=k.programs;k.environment=x.isMeshStandardMaterial?I.environment:null,k.fog=I.fog,k.envMap=(x.isMeshStandardMaterial?Me:De).get(x.envMap||k.environment),k.envMapRotation=k.environment!==null&&x.envMap===null?I.environmentRotation:x.envMapRotation,Ut===void 0&&(x.addEventListener("dispose",$),Ut=new Map,k.programs=Ut);let kt=Ut.get(gt);if(kt!==void 0){if(k.currentProgram===kt&&k.lightsStateVersion===pt)return Na(x,Mt),kt}else Mt.uniforms=q.getUniforms(x),x.onBeforeCompile(Mt,E),kt=q.acquireProgram(Mt,gt),Ut.set(gt,kt),k.uniforms=Mt.uniforms;const Dt=k.uniforms;return(!x.isShaderMaterial&&!x.isRawShaderMaterial||x.clipping===!0)&&(Dt.clippingPlanes=ot.uniform),Na(x,Mt),k.needsLights=Yc(x),k.lightsStateVersion=pt,k.needsLights&&(Dt.ambientLightColor.value=U.state.ambient,Dt.lightProbe.value=U.state.probe,Dt.directionalLights.value=U.state.directional,Dt.directionalLightShadows.value=U.state.directionalShadow,Dt.spotLights.value=U.state.spot,Dt.spotLightShadows.value=U.state.spotShadow,Dt.rectAreaLights.value=U.state.rectArea,Dt.ltc_1.value=U.state.rectAreaLTC1,Dt.ltc_2.value=U.state.rectAreaLTC2,Dt.pointLights.value=U.state.point,Dt.pointLightShadows.value=U.state.pointShadow,Dt.hemisphereLights.value=U.state.hemi,Dt.directionalShadowMap.value=U.state.directionalShadowMap,Dt.directionalShadowMatrix.value=U.state.directionalShadowMatrix,Dt.spotShadowMap.value=U.state.spotShadowMap,Dt.spotLightMatrix.value=U.state.spotLightMatrix,Dt.spotLightMap.value=U.state.spotLightMap,Dt.pointShadowMap.value=U.state.pointShadowMap,Dt.pointShadowMatrix.value=U.state.pointShadowMatrix),k.currentProgram=kt,k.uniformsList=null,kt}function Ua(x){if(x.uniformsList===null){const I=x.currentProgram.getUniforms();x.uniformsList=ir.seqWithValue(I.seq,x.uniforms)}return x.uniformsList}function Na(x,I){const B=bt.get(x);B.outputColorSpace=I.outputColorSpace,B.batching=I.batching,B.batchingColor=I.batchingColor,B.instancing=I.instancing,B.instancingColor=I.instancingColor,B.instancingMorph=I.instancingMorph,B.skinning=I.skinning,B.morphTargets=I.morphTargets,B.morphNormals=I.morphNormals,B.morphColors=I.morphColors,B.morphTargetsCount=I.morphTargetsCount,B.numClippingPlanes=I.numClippingPlanes,B.numIntersection=I.numClipIntersection,B.vertexAlphas=I.vertexAlphas,B.vertexTangents=I.vertexTangents,B.toneMapping=I.toneMapping}function Xc(x,I,B,k,U){I.isScene!==!0&&(I=yt),$t.resetTextureUnits();const nt=I.fog,pt=k.isMeshStandardMaterial?I.environment:null,Mt=O===null?E.outputColorSpace:O.isXRRenderTarget===!0?O.texture.colorSpace:Gi,gt=(k.isMeshStandardMaterial?Me:De).get(k.envMap||pt),Ut=k.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,kt=!!B.attributes.tangent&&(!!k.normalMap||k.anisotropy>0),Dt=!!B.morphAttributes.position,Jt=!!B.morphAttributes.normal,le=!!B.morphAttributes.color;let xe=Zn;k.toneMapped&&(O===null||O.isXRRenderTarget===!0)&&(xe=E.toneMapping);const pe=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,ue=pe!==void 0?pe.length:0,Pt=bt.get(k),_e=p.state.lights;if(ne===!0&&(Y===!0||x!==M)){const Be=x===M&&k.id===S;ot.setState(k,x,Be)}let se=!1;k.version===Pt.__version?(Pt.needsLights&&Pt.lightsStateVersion!==_e.state.version||Pt.outputColorSpace!==Mt||U.isBatchedMesh&&Pt.batching===!1||!U.isBatchedMesh&&Pt.batching===!0||U.isBatchedMesh&&Pt.batchingColor===!0&&U.colorTexture===null||U.isBatchedMesh&&Pt.batchingColor===!1&&U.colorTexture!==null||U.isInstancedMesh&&Pt.instancing===!1||!U.isInstancedMesh&&Pt.instancing===!0||U.isSkinnedMesh&&Pt.skinning===!1||!U.isSkinnedMesh&&Pt.skinning===!0||U.isInstancedMesh&&Pt.instancingColor===!0&&U.instanceColor===null||U.isInstancedMesh&&Pt.instancingColor===!1&&U.instanceColor!==null||U.isInstancedMesh&&Pt.instancingMorph===!0&&U.morphTexture===null||U.isInstancedMesh&&Pt.instancingMorph===!1&&U.morphTexture!==null||Pt.envMap!==gt||k.fog===!0&&Pt.fog!==nt||Pt.numClippingPlanes!==void 0&&(Pt.numClippingPlanes!==ot.numPlanes||Pt.numIntersection!==ot.numIntersection)||Pt.vertexAlphas!==Ut||Pt.vertexTangents!==kt||Pt.morphTargets!==Dt||Pt.morphNormals!==Jt||Pt.morphColors!==le||Pt.toneMapping!==xe||Pt.morphTargetsCount!==ue)&&(se=!0):(se=!0,Pt.__version=k.version);let $e=Pt.currentProgram;se===!0&&($e=ys(k,I,U));let Mi=!1,Ze=!1,ji=!1;const ve=$e.getUniforms(),en=Pt.uniforms;if(Tt.useProgram($e.program)&&(Mi=!0,Ze=!0,ji=!0),k.id!==S&&(S=k.id,Ze=!0),Mi||M!==x){Tt.buffers.depth.getReversed()&&x.reversedDepth!==!0&&(x._reversedDepth=!0,x.updateProjectionMatrix()),ve.setValue(A,"projectionMatrix",x.projectionMatrix),ve.setValue(A,"viewMatrix",x.matrixWorldInverse);const We=ve.map.cameraPosition;We!==void 0&&We.setValue(A,vt.setFromMatrixPosition(x.matrixWorld)),Lt.logarithmicDepthBuffer&&ve.setValue(A,"logDepthBufFC",2/(Math.log(x.far+1)/Math.LN2)),(k.isMeshPhongMaterial||k.isMeshToonMaterial||k.isMeshLambertMaterial||k.isMeshBasicMaterial||k.isMeshStandardMaterial||k.isShaderMaterial)&&ve.setValue(A,"isOrthographic",x.isOrthographicCamera===!0),M!==x&&(M=x,Ze=!0,ji=!0)}if(U.isSkinnedMesh){ve.setOptional(A,U,"bindMatrix"),ve.setOptional(A,U,"bindMatrixInverse");const Be=U.skeleton;Be&&(Be.boneTexture===null&&Be.computeBoneTexture(),ve.setValue(A,"boneTexture",Be.boneTexture,$t))}U.isBatchedMesh&&(ve.setOptional(A,U,"batchingTexture"),ve.setValue(A,"batchingTexture",U._matricesTexture,$t),ve.setOptional(A,U,"batchingIdTexture"),ve.setValue(A,"batchingIdTexture",U._indirectTexture,$t),ve.setOptional(A,U,"batchingColorTexture"),U._colorsTexture!==null&&ve.setValue(A,"batchingColorTexture",U._colorsTexture,$t));const nn=B.morphAttributes;if((nn.position!==void 0||nn.normal!==void 0||nn.color!==void 0)&&it.update(U,B,$e),(Ze||Pt.receiveShadow!==U.receiveShadow)&&(Pt.receiveShadow=U.receiveShadow,ve.setValue(A,"receiveShadow",U.receiveShadow)),k.isMeshGouraudMaterial&&k.envMap!==null&&(en.envMap.value=gt,en.flipEnvMap.value=gt.isCubeTexture&&gt.isRenderTargetTexture===!1?-1:1),k.isMeshStandardMaterial&&k.envMap===null&&I.environment!==null&&(en.envMapIntensity.value=I.environmentIntensity),Ze&&(ve.setValue(A,"toneMappingExposure",E.toneMappingExposure),Pt.needsLights&&qc(en,ji),nt&&k.fog===!0&&tt.refreshFogUniforms(en,nt),tt.refreshMaterialUniforms(en,k,V,rt,p.state.transmissionRenderTarget[x.id]),ir.upload(A,Ua(Pt),en,$t)),k.isShaderMaterial&&k.uniformsNeedUpdate===!0&&(ir.upload(A,Ua(Pt),en,$t),k.uniformsNeedUpdate=!1),k.isSpriteMaterial&&ve.setValue(A,"center",U.center),ve.setValue(A,"modelViewMatrix",U.modelViewMatrix),ve.setValue(A,"normalMatrix",U.normalMatrix),ve.setValue(A,"modelMatrix",U.matrixWorld),k.isShaderMaterial||k.isRawShaderMaterial){const Be=k.uniformsGroups;for(let We=0,Tr=Be.length;We<Tr;We++){const ti=Be[We];Vt.update(ti,$e),Vt.bind(ti,$e)}}return $e}function qc(x,I){x.ambientLightColor.needsUpdate=I,x.lightProbe.needsUpdate=I,x.directionalLights.needsUpdate=I,x.directionalLightShadows.needsUpdate=I,x.pointLights.needsUpdate=I,x.pointLightShadows.needsUpdate=I,x.spotLights.needsUpdate=I,x.spotLightShadows.needsUpdate=I,x.rectAreaLights.needsUpdate=I,x.hemisphereLights.needsUpdate=I}function Yc(x){return x.isMeshLambertMaterial||x.isMeshToonMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isShadowMaterial||x.isShaderMaterial&&x.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return O},this.setRenderTargetTextures=function(x,I,B){const k=bt.get(x);k.__autoAllocateDepthBuffer=x.resolveDepthBuffer===!1,k.__autoAllocateDepthBuffer===!1&&(k.__useRenderToTexture=!1),bt.get(x.texture).__webglTexture=I,bt.get(x.depthTexture).__webglTexture=k.__autoAllocateDepthBuffer?void 0:B,k.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(x,I){const B=bt.get(x);B.__webglFramebuffer=I,B.__useDefaultFramebuffer=I===void 0};const Kc=A.createFramebuffer();this.setRenderTarget=function(x,I=0,B=0){O=x,R=I,w=B;let k=!0,U=null,nt=!1,pt=!1;if(x){const gt=bt.get(x);if(gt.__useDefaultFramebuffer!==void 0)Tt.bindFramebuffer(A.FRAMEBUFFER,null),k=!1;else if(gt.__webglFramebuffer===void 0)$t.setupRenderTarget(x);else if(gt.__hasExternalTextures)$t.rebindTextures(x,bt.get(x.texture).__webglTexture,bt.get(x.depthTexture).__webglTexture);else if(x.depthBuffer){const Dt=x.depthTexture;if(gt.__boundDepthTexture!==Dt){if(Dt!==null&&bt.has(Dt)&&(x.width!==Dt.image.width||x.height!==Dt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");$t.setupDepthRenderbuffer(x)}}const Ut=x.texture;(Ut.isData3DTexture||Ut.isDataArrayTexture||Ut.isCompressedArrayTexture)&&(pt=!0);const kt=bt.get(x).__webglFramebuffer;x.isWebGLCubeRenderTarget?(Array.isArray(kt[I])?U=kt[I][B]:U=kt[I],nt=!0):x.samples>0&&$t.useMultisampledRTT(x)===!1?U=bt.get(x).__webglMultisampledFramebuffer:Array.isArray(kt)?U=kt[B]:U=kt,C.copy(x.viewport),z.copy(x.scissor),G=x.scissorTest}else C.copy(_t).multiplyScalar(V).floor(),z.copy(Bt).multiplyScalar(V).floor(),G=Yt;if(B!==0&&(U=Kc),Tt.bindFramebuffer(A.FRAMEBUFFER,U)&&k&&Tt.drawBuffers(x,U),Tt.viewport(C),Tt.scissor(z),Tt.setScissorTest(G),nt){const gt=bt.get(x.texture);A.framebufferTexture2D(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_CUBE_MAP_POSITIVE_X+I,gt.__webglTexture,B)}else if(pt){const gt=I;for(let Ut=0;Ut<x.textures.length;Ut++){const kt=bt.get(x.textures[Ut]);A.framebufferTextureLayer(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0+Ut,kt.__webglTexture,B,gt)}}else if(x!==null&&B!==0){const gt=bt.get(x.texture);A.framebufferTexture2D(A.FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,gt.__webglTexture,B)}S=-1},this.readRenderTargetPixels=function(x,I,B,k,U,nt,pt,Mt=0){if(!(x&&x.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let gt=bt.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&pt!==void 0&&(gt=gt[pt]),gt){Tt.bindFramebuffer(A.FRAMEBUFFER,gt);try{const Ut=x.textures[Mt],kt=Ut.format,Dt=Ut.type;if(!Lt.textureFormatReadable(kt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Lt.textureTypeReadable(Dt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}I>=0&&I<=x.width-k&&B>=0&&B<=x.height-U&&(x.textures.length>1&&A.readBuffer(A.COLOR_ATTACHMENT0+Mt),A.readPixels(I,B,k,U,Rt.convert(kt),Rt.convert(Dt),nt))}finally{const Ut=O!==null?bt.get(O).__webglFramebuffer:null;Tt.bindFramebuffer(A.FRAMEBUFFER,Ut)}}},this.readRenderTargetPixelsAsync=async function(x,I,B,k,U,nt,pt,Mt=0){if(!(x&&x.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let gt=bt.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&pt!==void 0&&(gt=gt[pt]),gt)if(I>=0&&I<=x.width-k&&B>=0&&B<=x.height-U){Tt.bindFramebuffer(A.FRAMEBUFFER,gt);const Ut=x.textures[Mt],kt=Ut.format,Dt=Ut.type;if(!Lt.textureFormatReadable(kt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Lt.textureTypeReadable(Dt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Jt=A.createBuffer();A.bindBuffer(A.PIXEL_PACK_BUFFER,Jt),A.bufferData(A.PIXEL_PACK_BUFFER,nt.byteLength,A.STREAM_READ),x.textures.length>1&&A.readBuffer(A.COLOR_ATTACHMENT0+Mt),A.readPixels(I,B,k,U,Rt.convert(kt),Rt.convert(Dt),0);const le=O!==null?bt.get(O).__webglFramebuffer:null;Tt.bindFramebuffer(A.FRAMEBUFFER,le);const xe=A.fenceSync(A.SYNC_GPU_COMMANDS_COMPLETE,0);return A.flush(),await Hh(A,xe,4),A.bindBuffer(A.PIXEL_PACK_BUFFER,Jt),A.getBufferSubData(A.PIXEL_PACK_BUFFER,0,nt),A.deleteBuffer(Jt),A.deleteSync(xe),nt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(x,I=null,B=0){const k=Math.pow(2,-B),U=Math.floor(x.image.width*k),nt=Math.floor(x.image.height*k),pt=I!==null?I.x:0,Mt=I!==null?I.y:0;$t.setTexture2D(x,0),A.copyTexSubImage2D(A.TEXTURE_2D,B,0,0,pt,Mt,U,nt),Tt.unbindTexture()};const $c=A.createFramebuffer(),Zc=A.createFramebuffer();this.copyTextureToTexture=function(x,I,B=null,k=null,U=0,nt=null){nt===null&&(U!==0?(fs("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),nt=U,U=0):nt=0);let pt,Mt,gt,Ut,kt,Dt,Jt,le,xe;const pe=x.isCompressedTexture?x.mipmaps[nt]:x.image;if(B!==null)pt=B.max.x-B.min.x,Mt=B.max.y-B.min.y,gt=B.isBox3?B.max.z-B.min.z:1,Ut=B.min.x,kt=B.min.y,Dt=B.isBox3?B.min.z:0;else{const nn=Math.pow(2,-U);pt=Math.floor(pe.width*nn),Mt=Math.floor(pe.height*nn),x.isDataArrayTexture?gt=pe.depth:x.isData3DTexture?gt=Math.floor(pe.depth*nn):gt=1,Ut=0,kt=0,Dt=0}k!==null?(Jt=k.x,le=k.y,xe=k.z):(Jt=0,le=0,xe=0);const ue=Rt.convert(I.format),Pt=Rt.convert(I.type);let _e;I.isData3DTexture?($t.setTexture3D(I,0),_e=A.TEXTURE_3D):I.isDataArrayTexture||I.isCompressedArrayTexture?($t.setTexture2DArray(I,0),_e=A.TEXTURE_2D_ARRAY):($t.setTexture2D(I,0),_e=A.TEXTURE_2D),A.pixelStorei(A.UNPACK_FLIP_Y_WEBGL,I.flipY),A.pixelStorei(A.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),A.pixelStorei(A.UNPACK_ALIGNMENT,I.unpackAlignment);const se=A.getParameter(A.UNPACK_ROW_LENGTH),$e=A.getParameter(A.UNPACK_IMAGE_HEIGHT),Mi=A.getParameter(A.UNPACK_SKIP_PIXELS),Ze=A.getParameter(A.UNPACK_SKIP_ROWS),ji=A.getParameter(A.UNPACK_SKIP_IMAGES);A.pixelStorei(A.UNPACK_ROW_LENGTH,pe.width),A.pixelStorei(A.UNPACK_IMAGE_HEIGHT,pe.height),A.pixelStorei(A.UNPACK_SKIP_PIXELS,Ut),A.pixelStorei(A.UNPACK_SKIP_ROWS,kt),A.pixelStorei(A.UNPACK_SKIP_IMAGES,Dt);const ve=x.isDataArrayTexture||x.isData3DTexture,en=I.isDataArrayTexture||I.isData3DTexture;if(x.isDepthTexture){const nn=bt.get(x),Be=bt.get(I),We=bt.get(nn.__renderTarget),Tr=bt.get(Be.__renderTarget);Tt.bindFramebuffer(A.READ_FRAMEBUFFER,We.__webglFramebuffer),Tt.bindFramebuffer(A.DRAW_FRAMEBUFFER,Tr.__webglFramebuffer);for(let ti=0;ti<gt;ti++)ve&&(A.framebufferTextureLayer(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,bt.get(x).__webglTexture,U,Dt+ti),A.framebufferTextureLayer(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,bt.get(I).__webglTexture,nt,xe+ti)),A.blitFramebuffer(Ut,kt,pt,Mt,Jt,le,pt,Mt,A.DEPTH_BUFFER_BIT,A.NEAREST);Tt.bindFramebuffer(A.READ_FRAMEBUFFER,null),Tt.bindFramebuffer(A.DRAW_FRAMEBUFFER,null)}else if(U!==0||x.isRenderTargetTexture||bt.has(x)){const nn=bt.get(x),Be=bt.get(I);Tt.bindFramebuffer(A.READ_FRAMEBUFFER,$c),Tt.bindFramebuffer(A.DRAW_FRAMEBUFFER,Zc);for(let We=0;We<gt;We++)ve?A.framebufferTextureLayer(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,nn.__webglTexture,U,Dt+We):A.framebufferTexture2D(A.READ_FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,nn.__webglTexture,U),en?A.framebufferTextureLayer(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,Be.__webglTexture,nt,xe+We):A.framebufferTexture2D(A.DRAW_FRAMEBUFFER,A.COLOR_ATTACHMENT0,A.TEXTURE_2D,Be.__webglTexture,nt),U!==0?A.blitFramebuffer(Ut,kt,pt,Mt,Jt,le,pt,Mt,A.COLOR_BUFFER_BIT,A.NEAREST):en?A.copyTexSubImage3D(_e,nt,Jt,le,xe+We,Ut,kt,pt,Mt):A.copyTexSubImage2D(_e,nt,Jt,le,Ut,kt,pt,Mt);Tt.bindFramebuffer(A.READ_FRAMEBUFFER,null),Tt.bindFramebuffer(A.DRAW_FRAMEBUFFER,null)}else en?x.isDataTexture||x.isData3DTexture?A.texSubImage3D(_e,nt,Jt,le,xe,pt,Mt,gt,ue,Pt,pe.data):I.isCompressedArrayTexture?A.compressedTexSubImage3D(_e,nt,Jt,le,xe,pt,Mt,gt,ue,pe.data):A.texSubImage3D(_e,nt,Jt,le,xe,pt,Mt,gt,ue,Pt,pe):x.isDataTexture?A.texSubImage2D(A.TEXTURE_2D,nt,Jt,le,pt,Mt,ue,Pt,pe.data):x.isCompressedTexture?A.compressedTexSubImage2D(A.TEXTURE_2D,nt,Jt,le,pe.width,pe.height,ue,pe.data):A.texSubImage2D(A.TEXTURE_2D,nt,Jt,le,pt,Mt,ue,Pt,pe);A.pixelStorei(A.UNPACK_ROW_LENGTH,se),A.pixelStorei(A.UNPACK_IMAGE_HEIGHT,$e),A.pixelStorei(A.UNPACK_SKIP_PIXELS,Mi),A.pixelStorei(A.UNPACK_SKIP_ROWS,Ze),A.pixelStorei(A.UNPACK_SKIP_IMAGES,ji),nt===0&&I.generateMipmaps&&A.generateMipmap(_e),Tt.unbindTexture()},this.initRenderTarget=function(x){bt.get(x).__webglFramebuffer===void 0&&$t.setupRenderTarget(x)},this.initTexture=function(x){x.isCubeTexture?$t.setTextureCube(x,0):x.isData3DTexture?$t.setTexture3D(x,0):x.isDataArrayTexture||x.isCompressedArrayTexture?$t.setTexture2DArray(x,0):$t.setTexture2D(x,0),Tt.unbindTexture()},this.resetState=function(){R=0,w=0,O=null,Tt.reset(),ft.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return En}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=re._getDrawingBufferColorSpace(t),e.unpackColorSpace=re._getUnpackColorSpace()}}function vs(s){let t=s>>>0;return function(){t|=0,t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function Ac(s){let t=2166136261;for(let e=0;e<s.length;e++)t^=s.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0}function lg(s,t,e,n=0){let i=s>>>0;return i=Math.imul(i^(t|0),2246822507),i=(i^i>>>13)>>>0,i=Math.imul(i^(e|0),3266489909),i=(i^i>>>16)>>>0,i=Math.imul(i^(n|0),668265263),i=(i^i>>>15)>>>0,i}function hi(s,t,e,n=0){return vs(lg(s,t,e,n))}const Z=16;function Ye([s,t,e,n=255],i){return[Math.min(255,s*i)|0,Math.min(255,t*i)|0,Math.min(255,e*i)|0,n]}function wc([s,t,e,n=255]){return`rgba(${s|0},${t|0},${e|0},${(n/255).toFixed(3)})`}function Et(s,t,e,n){t<0||e<0||t>=Z||e>=Z||(s.fillStyle=wc(n),s.fillRect(t,e,1,1))}function J(s,t,e,n,i,r){s.fillStyle=wc(r),s.fillRect(t,e,n,i)}function Pe(s,t,e){let n=0;for(const[,i]of e)n+=i;for(let i=0;i<Z;i++)for(let r=0;r<Z;r++){let o=t()*n;for(const[a,c]of e)if(o-=c,o<=0){Et(s,r,i,a);break}}}function $i(s,t,e,n){for(let i=0;i<n;i++)Et(s,t()*Z|0,t()*Z|0,e)}function _a(s,t,e,n,i,r){for(let o=0;o<i;o++){const a=e+(t()*3|0)-1,c=n+(t()*3|0)-1;Et(s,a,c,r[t()*r.length|0])}}const j={stoneL:[138,138,138],stone:[125,125,125],stoneD:[105,105,105],stoneDD:[88,88,88],dirtL:[155,112,74],dirt:[134,96,60],dirtD:[110,78,48],grassL:[118,190,82],grass:[96,168,68],grassD:[76,140,54],sandL:[222,210,164],sand:[210,196,148],sandD:[188,174,128],snowL:[250,251,253],snow:[238,242,247],snowD:[216,224,236],woodOak:[158,122,74],woodOakD:[132,100,58],barkOak:[104,82,50],barkOakD:[84,66,40],barkOakL:[122,98,62],birchL:[232,230,222],birch:[214,212,202],birchD:[70,66,60],spruceBark:[72,54,34],spruceBarkD:[56,42,26],spruceBarkL:[88,68,44],leafOak:[64,130,42],leafOakD:[48,104,32],leafOakL:[82,152,54],leafBirch:[96,156,68],leafBirchD:[76,128,52],leafBirchL:[116,176,84],leafSpruce:[44,96,60],leafSpruceD:[32,76,46],leafSpruceL:[58,116,74],waterL:[64,118,228,205],water:[48,100,214,205],waterD:[38,84,196,205]},Tn={};function ct(s,t){Tn[s]=t}ct("stone",(s,t)=>{Pe(s,t,[[j.stone,8],[j.stoneL,3],[j.stoneD,3],[j.stoneDD,1]])});ct("cobblestone",(s,t)=>Rc(s,t,!1));ct("mossy_cobble",(s,t)=>Rc(s,t,!0));function Rc(s,t,e){Pe(s,t,[[j.stoneD,5],[j.stoneDD,3]]);for(let n=0;n<3;n++)for(let i=0;i<3;i++){const r=i*5+1+(t()*2|0),o=n*5+1+(t()*2|0),a=3+(t()*2|0),c=3+(t()*2|0),l=t()<.5?j.stone:j.stoneL;J(s,r,o,a,c,l),J(s,r,o,a,1,Ye(l,1.12)),J(s,r,o+c-1,a,1,Ye(l,.85))}if(e)for(let n=0;n<5;n++)_a(s,t,t()*14+1|0,t()*14+1|0,8,[j.grassD,[58,110,44],j.grass])}ct("bedrock",(s,t)=>{Pe(s,t,[[[60,60,60],5],[[40,40,40],4],[[90,90,90],3],[[25,25,25],2]])});ct("dirt",(s,t)=>{Pe(s,t,[[j.dirt,7],[j.dirtL,3],[j.dirtD,3]]),$i(s,t,[92,64,40],8)});ct("grass_top",(s,t)=>{Pe(s,t,[[j.grass,7],[j.grassL,3],[j.grassD,3]]),$i(s,t,[130,200,96],6)});ct("grass_side",(s,t)=>{Tn.dirt(s,t),J(s,0,0,Z,3,j.grass);for(let e=0;e<Z;e++){const n=2+(t()*3|0);for(let i=0;i<n;i++)Et(s,e,i,t()<.4?j.grassL:j.grass);Et(s,e,n,j.grassD)}});ct("snowy_grass_side",(s,t)=>{Tn.dirt(s,t);for(let e=0;e<Z;e++){const n=2+(t()*3|0);for(let i=0;i<n;i++)Et(s,e,i,t()<.4?j.snowL:j.snow);Et(s,e,n,j.snowD)}});ct("snow_block",(s,t)=>{Pe(s,t,[[j.snow,8],[j.snowL,4],[j.snowD,2]])});ct("sand",(s,t)=>{Pe(s,t,[[j.sand,8],[j.sandL,3],[j.sandD,3]])});ct("sandstone",(s,t)=>{for(let e=0;e<Z;e++){const n=Math.sin(e*1.1)*.08+1;for(let i=0;i<Z;i++){const r=t()<.2?j.sandD:j.sand;Et(s,i,e,Ye(r,n))}}J(s,0,0,Z,1,j.sandL),J(s,0,Z-1,Z,1,j.sandD)});ct("sandstone_top",(s,t)=>{Pe(s,t,[[j.sand,8],[j.sandL,4],[j.sandD,1]])});ct("gravel",(s,t)=>{Pe(s,t,[[j.stone,5],[j.stoneD,4],[[146,132,120],3],[[100,92,84],3]]);for(let e=0;e<7;e++)_a(s,t,t()*14+1|0,t()*14+1|0,4,[j.stoneL,[160,148,136]])});ct("clay",(s,t)=>{Pe(s,t,[[[158,164,178],7],[[142,148,164],4],[[172,178,190],3]])});ct("water",(s,t)=>{Pe(s,t,[[j.water,7],[j.waterD,3],[j.waterL,2]]);for(let e=0;e<4;e++){const n=t()*Z|0,i=t()*10|0;J(s,i,n,4+(t()*4|0),1,[110,160,240,160])}});ct("ice",(s,t)=>{Pe(s,t,[[[158,190,242,235],7],[[140,174,232,235],4],[[184,210,248,235],3]]);for(let e=0;e<3;e++){let n=t()*Z|0,i=t()*Z|0;for(let r=0;r<5;r++)Et(s,n,i,[226,240,254,240]),n+=t()<.5?1:-1,i+=1}});function Cc(s,t,e,n,i){for(let r=0;r<Z;r++){const o=t();for(let a=0;a<Z;a++){let c=e;o<.28?c=n:o>.82&&(c=i),t()<.12&&(c=Ye(c,.88)),Et(s,r,a,c)}}for(let r=0;r<3;r++){const o=t()*Z|0,a=t()*10|0;J(s,o,a,1,3+(t()*4|0),n)}}function va(s,t,e,n,i){J(s,0,0,Z,Z,e),J(s,2,2,12,12,n),J(s,4,4,8,8,i),J(s,6,6,4,4,n),J(s,7,7,2,2,i),$i(s,t,Ye(n,1.1),10)}ct("oak_log",(s,t)=>Cc(s,t,j.barkOak,j.barkOakD,j.barkOakL));ct("oak_log_top",(s,t)=>va(s,t,j.barkOak,j.woodOak,j.woodOakD));ct("birch_log",(s,t)=>{Pe(s,t,[[j.birch,8],[j.birchL,4],[[196,194,186],2]]);for(let e=0;e<6;e++){const n=t()*Z|0;J(s,t()*12|0,n,2+(t()*3|0),1,j.birchD)}});ct("birch_log_top",(s,t)=>va(s,t,j.birch,[206,188,152],[182,164,130]));ct("spruce_log",(s,t)=>Cc(s,t,j.spruceBark,j.spruceBarkD,j.spruceBarkL));ct("spruce_log_top",(s,t)=>va(s,t,j.spruceBark,[140,106,66],[116,88,54]));function Zi(s,t,e){const n=Ye(e,.72),i=Ye(e,1.12);for(let r=0;r<4;r++){const o=r*4;for(let c=o;c<o+4;c++)for(let l=0;l<Z;l++){let h=e;t()<.18&&(h=Ye(e,.92)),t()<.08&&(h=i),Et(s,l,c,h)}J(s,0,o+3,Z,1,n);const a=(t()*12|0)+2;J(s,a,o,1,3,n)}}ct("oak_planks",(s,t)=>Zi(s,t,j.woodOak));ct("birch_planks",(s,t)=>Zi(s,t,[206,190,150]));ct("spruce_planks",(s,t)=>Zi(s,t,[112,84,50]));function xa(s,t,e,n,i){for(let r=0;r<Z;r++)for(let o=0;o<Z;o++){const a=t();if(a<.22)continue;let c=e;a<.45?c=n:a>.85&&(c=i),Et(s,o,r,c)}}ct("oak_leaves",(s,t)=>xa(s,t,j.leafOak,j.leafOakD,j.leafOakL));ct("birch_leaves",(s,t)=>xa(s,t,j.leafBirch,j.leafBirchD,j.leafBirchL));ct("spruce_leaves",(s,t)=>xa(s,t,j.leafSpruce,j.leafSpruceD,j.leafSpruceL));ct("cactus",(s,t)=>{const e=[58,128,48],n=[44,102,38],i=[82,150,62];J(s,0,0,Z,Z,e);for(let r=0;r<Z;r+=4)J(s,r,0,1,Z,n);for(let r=2;r<Z;r+=4)J(s,r,0,1,Z,i);for(let r=0;r<8;r++)Et(s,t()*Z|0,t()*Z|0,[230,238,210])});ct("cactus_top",(s,t)=>{J(s,0,0,Z,Z,[44,102,38]),J(s,1,1,14,14,[58,128,48]),J(s,4,4,8,8,[72,142,56]),$i(s,t,[230,238,210],5)});ct("tall_grass",(s,t)=>{for(let e=0;e<9;e++){let n=2+(t()*12|0);const i=6+(t()*9|0),r=t()<.5?j.grass:j.grassD;for(let o=Z-1;o>Z-i;o--)Et(s,n,o,r),t()<.3&&(n+=t()<.5?1:-1)}});function Dc(s,t,e,n){let i=8;for(let r=15;r>8;r--)Et(s,i,r,j.grassD),r===12&&(Et(s,i-1,r,j.grassD),Et(s,i-2,r-1,j.grass));J(s,6,4,4,4,e),Et(s,5,5,e),Et(s,10,5,e),Et(s,7,3,e),Et(s,8,3,e),Et(s,7,8,e),Et(s,8,8,e),J(s,7,5,2,2,n)}ct("dandelion",(s,t)=>Dc(s,t,[240,214,42],[200,160,30]));ct("poppy",(s,t)=>Dc(s,t,[214,48,48],[40,40,40]));ct("sugar_cane",(s,t)=>{for(const e of[3,8,12]){const n=[126,188,106];for(let i=0;i<Z;i++)Et(s,e,i,i%5===4?[96,148,82]:n),t()<.3&&Et(s,e+1,i,[148,204,124])}});ct("dead_bush",(s,t)=>{const e=[122,90,48];let n=[[8,15]];for(let i=0;i<10&&n.length;i++){const r=[];for(const[o,a]of n)Et(s,o,a,e),!(a<=4)&&(t()<.35&&r.length<5&&r.push([o-1,a-1]),t()<.35&&r.length<5&&r.push([o+1,a-1]),t()<.8&&r.push([o,a-1]));n=r}});function xs(s,t,e){Tn.stone(s,t);for(let n=0;n<5;n++)_a(s,t,2+(t()*12|0),2+(t()*12|0),5,e)}ct("coal_ore",(s,t)=>xs(s,t,[[40,40,44],[24,24,28],[58,58,62]]));ct("iron_ore",(s,t)=>xs(s,t,[[216,176,140],[196,152,116],[232,198,168]]));ct("gold_ore",(s,t)=>xs(s,t,[[248,210,70],[222,180,50],[255,232,120]]));ct("diamond_ore",(s,t)=>xs(s,t,[[96,226,222],[64,196,200],[160,246,240]]));ct("redstone_ore",(s,t)=>xs(s,t,[[212,44,32],[170,30,24],[244,88,70]]));ct("glass",(s,t)=>{const e=[214,230,236,255];J(s,0,0,Z,1,e),J(s,0,Z-1,Z,1,e),J(s,0,0,1,Z,e),J(s,Z-1,0,1,Z,e);for(let n=0;n<6;n++)Et(s,3+n,9-n,[240,250,254,120]);for(let n=0;n<4;n++)Et(s,9+n,13-n,[240,250,254,90])});ct("glowstone",(s,t)=>{Pe(s,t,[[[252,218,108],6],[[240,190,70],4],[[212,150,52],3],[[255,240,170],2]])});ct("torch",(s,t)=>{J(s,7,6,2,10,j.barkOak),J(s,7,6,1,10,j.barkOakL),J(s,7,4,2,2,[255,232,120]),J(s,7,3,2,1,[255,190,60]),Et(s,7,2,[255,140,40])});ct("crafting_table_top",(s,t)=>{Zi(s,t,j.woodOak),J(s,0,0,Z,1,j.barkOakD),J(s,0,Z-1,Z,1,j.barkOakD),J(s,0,0,1,Z,j.barkOakD),J(s,Z-1,0,1,Z,j.barkOakD),J(s,3,3,10,1,j.barkOakD),J(s,3,12,10,1,j.barkOakD),J(s,3,3,1,10,j.barkOakD),J(s,12,3,1,10,j.barkOakD)});ct("crafting_table_side",(s,t)=>{Zi(s,t,j.woodOak),J(s,0,0,Z,2,Ye(j.woodOak,1.1)),J(s,3,5,4,4,j.barkOakD),J(s,9,5,4,4,Ye(j.barkOakD,1.2))});ct("crafting_table_front",(s,t)=>{Zi(s,t,j.woodOak),J(s,0,0,Z,2,Ye(j.woodOak,1.1)),J(s,4,5,8,6,j.barkOakD),J(s,5,6,6,4,j.woodOakD)});ct("furnace_top",(s,t)=>Tn.stone(s,t));ct("furnace_side",(s,t)=>{Pe(s,t,[[j.stoneD,6],[j.stone,4],[j.stoneDD,2]]),J(s,0,0,Z,1,j.stone),J(s,0,Z-1,Z,1,j.stoneDD)});ct("furnace_front",(s,t)=>{Tn.furnace_side(s,t),J(s,4,6,8,7,[40,40,40]),J(s,5,7,6,5,[22,22,22])});ct("furnace_front_lit",(s,t)=>{Tn.furnace_side(s,t),J(s,4,6,8,7,[60,40,30]),J(s,5,7,6,5,[255,140,30]),J(s,6,8,4,3,[255,210,80]),Et(s,6,7,[255,240,160]),Et(s,9,7,[255,240,160])});ct("bricks",(s,t)=>{const e=[188,180,172],n=[168,74,58];J(s,0,0,Z,Z,e);for(let i=0;i<4;i++){const r=i*4,o=i%2===0?0:4;for(let a=-1;a<3;a++){const c=a*8+o,l=t()<.3?Ye(n,.88):n;J(s,c+1,r+1,7,3,l),J(s,c+1,r+1,7,1,Ye(l,1.1))}}});ct("stone_bricks",(s,t)=>{Pe(s,t,[[j.stone,7],[j.stoneL,3],[j.stoneD,2]]);const e=j.stoneDD;J(s,0,7,Z,1,e),J(s,0,15,Z,1,e),J(s,7,0,1,8,e),J(s,3,8,1,8,e),J(s,11,8,1,8,e),J(s,0,0,Z,1,Ye(j.stoneL,1.05))});ct("obsidian",(s,t)=>{Pe(s,t,[[[24,18,38],7],[[16,12,26],4],[[42,30,62],3]]),$i(s,t,[96,70,140],4)});ct("wool",(s,t)=>{Pe(s,t,[[[228,228,222],7],[[214,214,206],4],[[240,240,236],3]]);for(let e=0;e<Z;e+=4)for(let n=0;n<Z;n+=4)(n+e)%8===0&&J(s,n,e,2,1,[202,202,194])});ct("pumpkin_side",(s,t)=>{const e=[216,128,32],n=[184,102,24],i=[236,152,52];J(s,0,0,Z,Z,e);for(let r=1;r<Z;r+=4)J(s,r,0,1,Z,n);for(let r=3;r<Z;r+=4)J(s,r,0,1,Z,i);J(s,0,0,Z,1,n),J(s,0,Z-1,Z,1,n)});ct("pumpkin_top",(s,t)=>{J(s,0,0,Z,Z,[196,112,28]),J(s,1,1,14,14,[216,128,32]),J(s,6,6,4,4,[92,118,42]),J(s,7,7,2,2,[72,94,34])});ct("pumpkin_face",(s,t)=>{Tn.pumpkin_side(s,t);const e=[50,30,10];J(s,3,5,3,2,e),J(s,10,5,3,2,e),Et(s,4,4,e),Et(s,11,4,e),J(s,4,10,8,2,e),Et(s,3,9,e),Et(s,12,9,e),Et(s,7,12,e),Et(s,8,12,e)});function Lc(s,t,e,n){J(s,7,9,2,6,[222,214,196]),J(s,5,5,6,3,e),J(s,4,6,8,2,e),J(s,6,4,4,1,n),Et(s,6,6,n),Et(s,9,5,n)}ct("mushroom_brown",(s,t)=>Lc(s,t,[150,112,82],[124,90,64]));ct("mushroom_red",(s,t)=>{Lc(s,t,[200,46,40],[160,34,30]),Et(s,6,5,[240,236,228]),Et(s,9,6,[240,236,228])});ct("stick",s=>{for(let t=0;t<9;t++)Et(s,4+t,12-t,j.barkOak),Et(s,5+t,12-t,j.barkOakL)});ct("coal",(s,t)=>{Pc(s,t,[[36,36,40],[22,22,26],[52,52,58]])});ct("clay_ball",(s,t)=>{Pc(s,t,[[160,166,180],[144,150,166],[176,182,194]])});function Pc(s,t,e){for(let n=0;n<26;n++){const i=5+(t()*6|0),r=5+(t()*6|0);Et(s,i,r,e[t()*e.length|0])}J(s,6,6,4,4,e[0])}function Ic(s,t,e,n){for(let i=0;i<4;i++)J(s,3+i,10-i,8,1,t);J(s,3,10,8,2,n),J(s,6,7,8,1,e);for(let i=0;i<3;i++)Et(s,13,8+i,n)}ct("iron_ingot",s=>Ic(s,[216,216,220],[240,240,244],[168,168,176]));ct("gold_ingot",s=>Ic(s,[244,200,60],[255,236,130],[196,150,36]));ct("diamond",s=>{const t=[92,226,220],e=[180,250,246],n=[52,172,176];J(s,5,5,6,2,e),J(s,4,7,8,2,t),J(s,5,9,6,1,t),J(s,6,10,4,1,n),J(s,7,11,2,1,n),Et(s,5,6,[230,255,253])});ct("redstone_dust",(s,t)=>{for(let e=0;e<30;e++){const n=3+(t()*10|0),i=8+(t()*6|0)-((n-8)*(n-8)>>3);Et(s,n,i,t()<.5?[212,44,32]:[170,28,22])}});function vr(s,t,e,n,i){J(s,4,4,8,8,e),J(s,5,3,6,1,e),J(s,5,12,6,1,e),J(s,4,4,1,8,i),J(s,11,4,1,8,i),$i(s,t,n,6),J(s,11,10,3,2,[240,236,224])}ct("porkchop_raw",(s,t)=>vr(s,t,[238,140,140],[216,110,110],[246,190,180]));ct("porkchop_cooked",(s,t)=>vr(s,t,[180,112,60],[150,88,44],[214,152,96]));ct("mutton_raw",(s,t)=>vr(s,t,[210,90,90],[180,66,66],[232,150,140]));ct("mutton_cooked",(s,t)=>vr(s,t,[160,96,48],[132,74,36],[196,134,82]));ct("apple",s=>{const t=[212,50,44],e=[170,34,30],n=[238,96,84];J(s,5,6,6,6,t),J(s,4,7,8,4,t),Et(s,6,7,n),Et(s,6,8,n),J(s,6,12,4,1,e),Et(s,8,5,j.barkOak),Et(s,8,4,j.barkOak),Et(s,9,4,j.grassD),Et(s,10,3,j.grassD)});ct("rotten_flesh",(s,t)=>{cg(s,t,4,5,9,7,[[[142,108,62],5],[[104,122,62],4],[[88,66,44],3]]),Et(s,6,7,[70,90,46]),Et(s,10,9,[70,90,46])});function cg(s,t,e,n,i,r,o){let a=0;for(const[,c]of o)a+=c;for(let c=n;c<n+r;c++)for(let l=e;l<e+i;l++){let h=t()*a;for(const[u,d]of o)if(h-=d,h<=0){Et(s,l,c,u);break}}}ct("brick_item",s=>{J(s,4,6,8,5,[168,74,58]),J(s,4,6,8,1,[196,96,76]),J(s,4,10,8,1,[136,56,44])});const Fl={pickaxe:["....mMMMMMm.....","...MM.....MMm...","..Mm...HH...Mm..","..M...Hh.M...M..",".....Hh...m..m..","....Hh..........","...Hh...........","..Hh............",".Hh.............","Hh.............."],axe:["....mMMm........","...MMMMMm.......","...MMhHMM.......","...mMHh.m.......","....Hh..........","...Hh...........","..Hh............",".Hh.............","Hh.............."],shovel:["......mMMm......",".....MMMMM......",".....mMMMm......","......mHm.......",".....Hh.........","....Hh..........","...Hh...........","..Hh............",".Hh............."],sword:["..........mM....",".........MMm....","........MMm.....",".......MMm......","......MMm.......",".....MMm........",".hh.MMm.........","..hHhm..........","..Hhh...........",".Hh.hh.........."]},io={wood:{M:[158,122,74],m:[122,94,56]},stone:{M:[136,136,136],m:[100,100,100]},iron:{M:[222,222,228],m:[170,170,180]},gold:{M:[246,204,62],m:[200,156,40]},diamond:{M:[96,226,220],m:[56,178,180]}};for(const s of Object.keys(io))for(const t of Object.keys(Fl))ct(`${s}_${t}`,e=>{const n={H:[122,94,56],h:[94,72,42],M:io[s].M,m:io[s].m},i=Fl[t],r=16-i.length-1;for(let o=0;o<i.length;o++)for(let a=0;a<i[o].length;a++){const c=i[o][a];n[c]&&Et(e,a,o+r,n[c])}});for(let s=0;s<5;s++)ct(`crack_${s}`,(t,e)=>{const n=6+s*9,i=[20,20,20,190];for(let r=0;r<2+s;r++){let o=6+(e()*4|0),a=6+(e()*4|0);for(let c=0;c<n/2;c++){Et(t,o,a,i);const l=e()*4|0;if(l===0?o++:l===1?o--:l===2?a++:a--,o<0||a<0||o>15||a>15)break}}});ct("sun",s=>{J(s,2,2,12,12,[255,240,170]),J(s,4,4,8,8,[255,250,220])});ct("moon",s=>{J(s,3,3,10,10,[212,216,228]),J(s,5,5,6,6,[232,236,244]),J(s,5,5,3,3,[188,192,208]),Et(s,9,8,[188,192,208]),Et(s,7,10,[188,192,208])});function hg(){return Object.keys(Tn)}const so=new Map;function In(s){if(so.has(s))return so.get(s);const t=Tn[s];if(!t)throw new Error(`Unknown tile: ${s}`);const e=document.createElement("canvas");e.width=Z,e.height=Z;const n=e.getContext("2d",{willReadFrequently:!0});return n.clearRect(0,0,Z,Z),t(n,hi(2970377965,Ac(s),7)),so.set(s,e),e}const at={STICK:256,COAL:257,IRON_INGOT:258,GOLD_INGOT:259,DIAMOND:260,REDSTONE_DUST:261,PORKCHOP_RAW:262,PORKCHOP_COOKED:263,APPLE:264,ROTTEN_FLESH:265,MUTTON_RAW:266,MUTTON_COOKED:267,BRICK_ITEM:268,CLAY_BALL:269,WOOD_PICKAXE:270,WOOD_AXE:271,WOOD_SHOVEL:272,WOOD_SWORD:273,STONE_PICKAXE:274,STONE_AXE:275,STONE_SHOVEL:276,STONE_SWORD:277,IRON_PICKAXE:278,IRON_AXE:279,IRON_SHOVEL:280,IRON_SWORD:281,GOLD_PICKAXE:282,GOLD_AXE:283,GOLD_SHOVEL:284,GOLD_SWORD:285,DIAMOND_PICKAXE:286,DIAMOND_AXE:287,DIAMOND_SHOVEL:288,DIAMOND_SWORD:289},P={AIR:0,STONE:1,GRASS:2,DIRT:3,COBBLESTONE:4,BEDROCK:5,SAND:6,SANDSTONE:7,GRAVEL:8,CLAY:9,WATER:10,ICE:11,SNOW_BLOCK:12,SNOWY_GRASS:13,OAK_LOG:14,OAK_LEAVES:15,OAK_PLANKS:16,BIRCH_LOG:17,BIRCH_LEAVES:18,BIRCH_PLANKS:19,SPRUCE_LOG:20,SPRUCE_LEAVES:21,SPRUCE_PLANKS:22,CACTUS:23,TALL_GRASS:24,DANDELION:25,POPPY:26,SUGAR_CANE:27,DEAD_BUSH:28,COAL_ORE:29,IRON_ORE:30,GOLD_ORE:31,DIAMOND_ORE:32,REDSTONE_ORE:33,GLASS:34,GLOWSTONE:35,TORCH:36,CRAFTING_TABLE:37,FURNACE:38,FURNACE_LIT:39,BRICKS:40,STONE_BRICKS:41,MOSSY_COBBLE:42,OBSIDIAN:43,WOOL:44,PUMPKIN:45,MUSHROOM_BROWN:46,MUSHROOM_RED:47},ug=null,Ge="pickaxe",Jn="axe",xi="shovel",Ma=0,Uc=1,Ms=2,Sa=3,mn=4,Ss=5;function Ot(s,t,e,n={}){return{id:s,name:t,display:e,solid:n.solid??!0,render:n.render??Uc,opacity:n.opacity??15,lightEmit:n.lightEmit??0,hardness:n.hardness??1,tool:n.tool??ug,minTier:n.minTier??0,drop:n.drop,textures:n.textures??t,replaceable:n.replaceable??!1,fluid:n.fluid??!1,climbable:!1,sound:n.sound??"stone"}}const Re=[];function Ft(s){Re[s.id]=s}Ft(Ot(P.AIR,"air","Air",{solid:!1,render:Ma,opacity:0,hardness:-1,replaceable:!0,drop:null}));Ft(Ot(P.STONE,"stone","Stone",{hardness:1.5,tool:Ge,minTier:1,drop:P.COBBLESTONE}));Ft(Ot(P.GRASS,"grass","Grass Block",{hardness:.6,tool:xi,drop:P.DIRT,sound:"dirt",textures:{top:"grass_top",bottom:"dirt",side:"grass_side"}}));Ft(Ot(P.DIRT,"dirt","Dirt",{hardness:.5,tool:xi,sound:"dirt"}));Ft(Ot(P.COBBLESTONE,"cobblestone","Cobblestone",{hardness:2,tool:Ge,minTier:1}));Ft(Ot(P.BEDROCK,"bedrock","Bedrock",{hardness:-1,drop:null}));Ft(Ot(P.SAND,"sand","Sand",{hardness:.5,tool:xi,sound:"sand"}));Ft(Ot(P.SANDSTONE,"sandstone","Sandstone",{hardness:.8,tool:Ge,minTier:1,textures:{top:"sandstone_top",bottom:"sandstone_top",side:"sandstone"}}));Ft(Ot(P.GRAVEL,"gravel","Gravel",{hardness:.6,tool:xi,sound:"sand"}));Ft(Ot(P.CLAY,"clay","Clay",{hardness:.6,tool:xi,sound:"dirt",drop:()=>[{id:at.CLAY_BALL,count:4}]}));Ft(Ot(P.WATER,"water","Water",{solid:!1,render:Sa,opacity:2,hardness:-1,replaceable:!0,drop:null,fluid:!0}));Ft(Ot(P.ICE,"ice","Ice",{render:Sa,opacity:2,hardness:.5,tool:Ge,drop:null,sound:"glass"}));Ft(Ot(P.SNOW_BLOCK,"snow_block","Snow Block",{hardness:.2,tool:xi,sound:"cloth"}));Ft(Ot(P.SNOWY_GRASS,"snowy_grass","Snowy Grass",{hardness:.6,tool:xi,drop:P.DIRT,sound:"dirt",textures:{top:"snow_block",bottom:"dirt",side:"snowy_grass_side"}}));Ft(Ot(P.OAK_LOG,"oak_log","Oak Log",{hardness:2,tool:Jn,sound:"wood",textures:{top:"oak_log_top",bottom:"oak_log_top",side:"oak_log"}}));Ft(Ot(P.OAK_LEAVES,"oak_leaves","Oak Leaves",{render:Ms,opacity:1,hardness:.2,sound:"leaf",drop:s=>{const t=[];return s()<.05&&t.push({id:at.APPLE,count:1}),s()<.1&&t.push({id:at.STICK,count:1}),t}}));Ft(Ot(P.OAK_PLANKS,"oak_planks","Oak Planks",{hardness:2,tool:Jn,sound:"wood"}));Ft(Ot(P.BIRCH_LOG,"birch_log","Birch Log",{hardness:2,tool:Jn,sound:"wood",textures:{top:"birch_log_top",bottom:"birch_log_top",side:"birch_log"}}));Ft(Ot(P.BIRCH_LEAVES,"birch_leaves","Birch Leaves",{render:Ms,opacity:1,hardness:.2,sound:"leaf",drop:null}));Ft(Ot(P.BIRCH_PLANKS,"birch_planks","Birch Planks",{hardness:2,tool:Jn,sound:"wood"}));Ft(Ot(P.SPRUCE_LOG,"spruce_log","Spruce Log",{hardness:2,tool:Jn,sound:"wood",textures:{top:"spruce_log_top",bottom:"spruce_log_top",side:"spruce_log"}}));Ft(Ot(P.SPRUCE_LEAVES,"spruce_leaves","Spruce Leaves",{render:Ms,opacity:1,hardness:.2,sound:"leaf",drop:null}));Ft(Ot(P.SPRUCE_PLANKS,"spruce_planks","Spruce Planks",{hardness:2,tool:Jn,sound:"wood"}));Ft(Ot(P.CACTUS,"cactus","Cactus",{hardness:.4,sound:"cloth",textures:{top:"cactus_top",bottom:"cactus_top",side:"cactus"}}));Ft(Ot(P.TALL_GRASS,"tall_grass","Tall Grass",{solid:!1,render:mn,opacity:0,hardness:.05,replaceable:!0,sound:"leaf",drop:null}));Ft(Ot(P.DANDELION,"dandelion","Dandelion",{solid:!1,render:mn,opacity:0,hardness:.05,sound:"leaf"}));Ft(Ot(P.POPPY,"poppy","Poppy",{solid:!1,render:mn,opacity:0,hardness:.05,sound:"leaf"}));Ft(Ot(P.SUGAR_CANE,"sugar_cane","Sugar Cane",{solid:!1,render:mn,opacity:0,hardness:.1,sound:"leaf"}));Ft(Ot(P.DEAD_BUSH,"dead_bush","Dead Bush",{solid:!1,render:mn,opacity:0,hardness:.05,sound:"leaf",drop:null}));Ft(Ot(P.COAL_ORE,"coal_ore","Coal Ore",{hardness:3,tool:Ge,minTier:1,drop:()=>[{id:at.COAL,count:1}]}));Ft(Ot(P.IRON_ORE,"iron_ore","Iron Ore",{hardness:3,tool:Ge,minTier:2}));Ft(Ot(P.GOLD_ORE,"gold_ore","Gold Ore",{hardness:3,tool:Ge,minTier:3}));Ft(Ot(P.DIAMOND_ORE,"diamond_ore","Diamond Ore",{hardness:3,tool:Ge,minTier:3,drop:()=>[{id:at.DIAMOND,count:1}]}));Ft(Ot(P.REDSTONE_ORE,"redstone_ore","Redstone Ore",{hardness:3,tool:Ge,minTier:3,drop:s=>[{id:at.REDSTONE_DUST,count:1+(s()*3|0)}]}));Ft(Ot(P.GLASS,"glass","Glass",{render:Ms,opacity:0,hardness:.3,drop:null,sound:"glass"}));Ft(Ot(P.GLOWSTONE,"glowstone","Glowstone",{lightEmit:15,hardness:.3,sound:"glass"}));Ft(Ot(P.TORCH,"torch","Torch",{solid:!1,render:Ss,opacity:0,lightEmit:14,hardness:.05,sound:"wood"}));Ft(Ot(P.CRAFTING_TABLE,"crafting_table","Crafting Table",{hardness:2.5,tool:Jn,sound:"wood",textures:{top:"crafting_table_top",bottom:"oak_planks",side:"crafting_table_side",front:"crafting_table_front"}}));Ft(Ot(P.FURNACE,"furnace","Furnace",{hardness:3.5,tool:Ge,minTier:1,textures:{top:"furnace_top",bottom:"furnace_top",side:"furnace_side",front:"furnace_front"}}));Ft(Ot(P.FURNACE_LIT,"furnace_lit","Furnace",{hardness:3.5,tool:Ge,minTier:1,lightEmit:13,drop:P.FURNACE,textures:{top:"furnace_top",bottom:"furnace_top",side:"furnace_side",front:"furnace_front_lit"}}));Ft(Ot(P.BRICKS,"bricks","Bricks",{hardness:2,tool:Ge,minTier:1}));Ft(Ot(P.STONE_BRICKS,"stone_bricks","Stone Bricks",{hardness:1.5,tool:Ge,minTier:1}));Ft(Ot(P.MOSSY_COBBLE,"mossy_cobble","Mossy Cobblestone",{hardness:2,tool:Ge,minTier:1}));Ft(Ot(P.OBSIDIAN,"obsidian","Obsidian",{hardness:30,tool:Ge,minTier:4}));Ft(Ot(P.WOOL,"wool","Wool",{hardness:.8,sound:"cloth"}));Ft(Ot(P.PUMPKIN,"pumpkin","Pumpkin",{hardness:1,tool:Jn,sound:"wood",textures:{top:"pumpkin_top",bottom:"pumpkin_top",side:"pumpkin_side",front:"pumpkin_face"}}));Ft(Ot(P.MUSHROOM_BROWN,"mushroom_brown","Brown Mushroom",{solid:!1,render:mn,opacity:0,hardness:.05,sound:"leaf"}));Ft(Ot(P.MUSHROOM_RED,"mushroom_red","Red Mushroom",{solid:!1,render:mn,opacity:0,hardness:.05,sound:"leaf"}));function rn(s){return Re[s]??Re[P.AIR]}function Ea(s){const t=Re[s];return t?t.solid:!1}function dg(s,t){const e=Re[t];return!e||e.render===Ma?!0:e.render===Uc?!1:s===t?Re[s].render===Ms&&(s===P.OAK_LEAVES||s===P.BIRCH_LEAVES||s===P.SPRUCE_LEAVES):!0}const fg={wood:{tier:1,speed:2,durability:60,damage:4},stone:{tier:2,speed:4,durability:132,damage:5},iron:{tier:3,speed:6,durability:251,damage:6},gold:{tier:1,speed:12,durability:33,damage:4},diamond:{tier:4,speed:8,durability:1562,damage:7}},Nc=new Map;function Ve(s,t,e,n={}){Nc.set(s,{id:s,name:t,display:e,texture:n.texture??t,stack:n.stack??64,tool:n.tool??null,food:n.food??0,burnTime:n.burnTime??0})}function js(s,t,e){const n=fg[t],i=`${t[0].toUpperCase()}${t.slice(1)} ${e[0].toUpperCase()}${e.slice(1)}`;Ve(s,`${t}_${e}`,i,{stack:1,burnTime:t==="wood"?10:0,tool:{class:e,tier:n.tier,speed:n.speed,durability:n.durability,damage:e==="sword"?n.damage:Math.max(1,n.damage-3)}})}Ve(at.STICK,"stick","Stick",{burnTime:5});Ve(at.COAL,"coal","Coal",{burnTime:80});Ve(at.IRON_INGOT,"iron_ingot","Iron Ingot");Ve(at.GOLD_INGOT,"gold_ingot","Gold Ingot");Ve(at.DIAMOND,"diamond","Diamond");Ve(at.REDSTONE_DUST,"redstone_dust","Redstone Dust");Ve(at.PORKCHOP_RAW,"porkchop_raw","Raw Porkchop",{food:3});Ve(at.PORKCHOP_COOKED,"porkchop_cooked","Cooked Porkchop",{food:8});Ve(at.APPLE,"apple","Apple",{food:4});Ve(at.ROTTEN_FLESH,"rotten_flesh","Rotten Flesh",{food:2});Ve(at.MUTTON_RAW,"mutton_raw","Raw Mutton",{food:2});Ve(at.MUTTON_COOKED,"mutton_cooked","Cooked Mutton",{food:6});Ve(at.BRICK_ITEM,"brick_item","Brick");Ve(at.CLAY_BALL,"clay_ball","Clay Ball");for(const[s,t]of[["wood",[at.WOOD_PICKAXE,at.WOOD_AXE,at.WOOD_SHOVEL,at.WOOD_SWORD]],["stone",[at.STONE_PICKAXE,at.STONE_AXE,at.STONE_SHOVEL,at.STONE_SWORD]],["iron",[at.IRON_PICKAXE,at.IRON_AXE,at.IRON_SHOVEL,at.IRON_SWORD]],["gold",[at.GOLD_PICKAXE,at.GOLD_AXE,at.GOLD_SHOVEL,at.GOLD_SWORD]],["diamond",[at.DIAMOND_PICKAXE,at.DIAMOND_AXE,at.DIAMOND_SHOVEL,at.DIAMOND_SWORD]]]){const[e,n,i,r]=t;js(e,s,"pickaxe"),js(n,s,"axe"),js(i,s,"shovel"),js(r,s,"sword")}const pg=new Map([[P.OAK_PLANKS,15],[P.BIRCH_PLANKS,15],[P.SPRUCE_PLANKS,15],[P.OAK_LOG,15],[P.BIRCH_LOG,15],[P.SPRUCE_LOG,15],[P.CRAFTING_TABLE,15],[P.COAL_ORE,0],[P.DEAD_BUSH,5]]);function Ue(s){if(s<256){const t=rn(s);return{id:s,name:t.name,display:t.display,texture:null,block:t,stack:64,tool:null,food:0,burnTime:pg.get(s)??0}}return Nc.get(s)??null}function ya(s){return s>0&&s<256&&!!Re[s]}function xn(s){const t=Ue(s);return t?t.stack:64}function jo(s,t=1){const e=Ue(s),n={id:s,count:t};return e?.tool&&(n.dur=e.tool.durability),n}const dr=0,Jo=1,Qo=2,ta=3,ea=4,na=5;class mg{constructor(){const t=hg();this.layerOfName=new Map,this.count=t.length;const e=new Uint8Array(Z*Z*4*this.count),n=document.createElement("canvas");n.width=Z,n.height=Z;const i=n.getContext("2d",{willReadFrequently:!0});t.forEach((o,a)=>{this.layerOfName.set(o,a),i.clearRect(0,0,Z,Z),i.drawImage(In(o),0,0);const c=i.getImageData(0,0,Z,Z).data,l=a*Z*Z*4;for(let h=0;h<Z;h++){const u=(Z-1-h)*Z*4;e.set(c.subarray(u,u+Z*4),l+h*Z*4)}});const r=new pa(e,Z,Z,this.count);r.format=cn,r.magFilter=be,r.minFilter=rs,r.generateMipmaps=!0,r.wrapS=Un,r.wrapT=Un,r.needsUpdate=!0,this.texture=r,this.blockFaces=new Int16Array(Re.length*8).fill(-1);for(const o of Re){if(!o||o.render===0)continue;const a=o.textures;let c,l,h,u=-1;typeof a=="string"?c=l=h=this.layer(a):(c=this.layer(a.top),l=this.layer(a.bottom),h=this.layer(a.side),a.front&&(u=this.layer(a.front)));const d=o.id*8;this.blockFaces[d+dr]=h,this.blockFaces[d+Jo]=h,this.blockFaces[d+Qo]=c,this.blockFaces[d+ta]=l,this.blockFaces[d+ea]=h,this.blockFaces[d+na]=h,this.blockFaces[d+6]=u,this.blockFaces[d+7]=u>=0?1:0}this.iconCache=new Map}layer(t){const e=this.layerOfName.get(t);if(e===void 0)throw new Error(`Atlas: unknown tile "${t}"`);return e}faceLayer(t,e,n=0){const i=t*8;if(this.blockFaces[i+7]===1&&e!==Qo&&e!==ta){const r=[na,dr,ea,Jo][n&3];if(e===r)return this.blockFaces[i+6]}return this.blockFaces[i+e]}icon(t){if(this.iconCache.has(t))return this.iconCache.get(t);const e=this.renderIcon(t);return this.iconCache.set(t,e),e}renderIcon(t){const e=Ue(t);if(!e)return"";const n=document.createElement("canvas");n.width=32,n.height=32;const i=n.getContext("2d");if(i.imageSmoothingEnabled=!1,e.block){const r=e.block,o=r.textures,a=c=>typeof o=="string"?o:o[c]??o.side;r.render===mn||r.render===Ss?i.drawImage(In(a("side")),0,0,32,32):this.drawIsoCube(i,In(a("top")),In(a("side")),In(a("side")))}else i.drawImage(In(e.texture),0,0,32,32);return n.toDataURL()}drawIsoCube(t,e,n,i){const r=(o,a)=>{const c=document.createElement("canvas");c.width=Z,c.height=Z;const l=c.getContext("2d");return l.drawImage(o,0,0),l.globalCompositeOperation="source-atop",l.fillStyle=`rgba(0,0,0,${1-a})`,l.fillRect(0,0,Z,Z),c};t.save(),t.imageSmoothingEnabled=!1,t.setTransform(1,.5,-1,.5,16,0),t.drawImage(e,0,0,Z,Z,0,0,16,16),t.setTransform(1,.5,0,1,0,8),t.drawImage(r(n,.72),0,0,Z,Z,0,0,16,16),t.setTransform(1,-.5,0,1,16,16),t.drawImage(r(i,.55),0,0,Z,Z,0,0,16,16),t.restore()}}const te=16,ie=128,Wt=16,gg=te*ie*Wt,Te=42;function de(s,t,e){return(s*Wt+e)*ie+t}const _g=1200,vg=.6,xg=1.8,Bl=1.62,kl=28,Mg=8.8,Sg=4.3,Eg=5.9,yg=1.6,ro=11,Tg=2.6,Oc=5,Bi=0,Ke=1;function me(s,t){return`${s},${t}`}class bg{constructor(t,e){this.cx=t,this.cz=e,this.blocks=null,this.meta=null,this.skyLight=null,this.blockLight=null,this.heightMap=null,this.biomeMap=null,this.hasBlocks=!1,this.hasLight=!1,this.mesh=null,this.meshDirty=!1,this.modified=!1,this.generating=!1,this.blockEntities=new Map}setData(t,e,n){this.blocks=t,this.heightMap=e,this.biomeMap=n,this.hasBlocks=!0}ensureMeta(){return this.meta||(this.meta=new Uint8Array(gg)),this.meta}getBlock(t,e,n){return e<0||e>=ie?0:this.blocks[de(t,e,n)]}setBlock(t,e,n,i){this.blocks[de(t,e,n)]=i,this.modified=!0}getMeta(t,e,n){return this.meta?this.meta[de(t,e,n)]:0}setMeta(t,e,n,i){!i&&!this.meta||(this.ensureMeta()[de(t,e,n)]=i,this.modified=!0)}getSky(t,e,n){return e>=ie?15:e<0?0:this.skyLight[de(t,e,n)]}getBlockLight(t,e,n){return e<0||e>=ie?0:this.blockLight[de(t,e,n)]}}class Ag{constructor(t,e=Math.min(4,Math.max(2,(navigator.hardwareConcurrency||4)-2))){this.workers=[],this.queue=[],this.pending=new Map,this.nextJob=1,this.idle=[];for(let n=0;n<e;n++){const i=new Worker(new URL(""+new URL("genWorker-C5ksth7E.js",import.meta.url).href,import.meta.url),{type:"module"});i.postMessage({type:"init",seed:t}),i.onmessage=r=>this.onResult(i,r.data),i.onerror=r=>console.error("[genWorker] error:",r.message,r.filename,r.lineno),i.onmessageerror=r=>console.error("[genWorker] message error",r),this.workers.push(i),this.idle.push(i)}}generate(t,e){return new Promise(n=>{this.queue.push({cx:t,cz:e,resolve:n}),this.pump()})}pump(){for(;this.idle.length&&this.queue.length;){const t=this.idle.pop(),e=this.queue.shift(),n=this.nextJob++;this.pending.set(n,{resolve:e.resolve,worker:t}),t.postMessage({type:"gen",cx:e.cx,cz:e.cz,jobId:n})}}onResult(t,e){if(e.type!=="chunk")return;const n=this.pending.get(e.jobId);this.pending.delete(e.jobId),this.idle.push(t),this.pump(),n&&n.resolve({blocks:e.blocks,heightMap:e.heightMap,biomeMap:e.biomeMap})}prune(t){this.queue=this.queue.filter(e=>t(e.cx,e.cz))}dispose(){for(const t of this.workers)t.terminate();this.workers=[],this.queue=[]}}const wg=[[1,1],[-1,1],[1,-1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]],Rg=[[1,1,0],[-1,1,0],[1,-1,0],[-1,-1,0],[1,0,1],[-1,0,1],[1,0,-1],[-1,0,-1],[0,1,1],[0,-1,1],[0,1,-1],[0,-1,-1]];function ss(s){return s*s*s*(s*(s*6-15)+10)}function _n(s,t,e){return s+(t-s)*e}class vn{constructor(t){const e=vs(t>>>0),n=new Uint8Array(256);for(let i=0;i<256;i++)n[i]=i;for(let i=255;i>0;i--){const r=e()*(i+1)|0,o=n[i];n[i]=n[r],n[r]=o}this.perm=new Uint8Array(512);for(let i=0;i<512;i++)this.perm[i]=n[i&255]}grad2(t,e,n){const i=wg[t&7];return i[0]*e+i[1]*n}grad3(t,e,n,i){const r=Rg[t%12];return r[0]*e+r[1]*n+r[2]*i}noise2(t,e){const n=this.perm,i=Math.floor(t)&255,r=Math.floor(e)&255;t-=Math.floor(t),e-=Math.floor(e);const o=ss(t),a=ss(e),c=n[i]+r,l=n[i+1]+r;return _n(_n(this.grad2(n[c],t,e),this.grad2(n[l],t-1,e),o),_n(this.grad2(n[c+1],t,e-1),this.grad2(n[l+1],t-1,e-1),o),a)}noise3(t,e,n){const i=this.perm,r=Math.floor(t)&255,o=Math.floor(e)&255,a=Math.floor(n)&255;t-=Math.floor(t),e-=Math.floor(e),n-=Math.floor(n);const c=ss(t),l=ss(e),h=ss(n),u=i[r]+o,d=i[u]+a,f=i[u+1]+a,g=i[r+1]+o,_=i[g]+a,m=i[g+1]+a;return _n(_n(_n(this.grad3(i[d],t,e,n),this.grad3(i[_],t-1,e,n),c),_n(this.grad3(i[f],t,e-1,n),this.grad3(i[m],t-1,e-1,n),c),l),_n(_n(this.grad3(i[d+1],t,e,n-1),this.grad3(i[_+1],t-1,e,n-1),c),_n(this.grad3(i[f+1],t,e-1,n-1),this.grad3(i[m+1],t-1,e-1,n-1),c),l),h)}fbm2(t,e,n,i=2,r=.5){let o=0,a=1,c=1,l=0;for(let h=0;h<n;h++)o+=a*this.noise2(t*c,e*c),l+=a,a*=r,c*=i;return o/l}fbm3(t,e,n,i,r=2,o=.5){let a=0,c=1,l=1,h=0;for(let u=0;u<i;u++)a+=c*this.noise3(t*l,e*l,n*l),h+=c,c*=o,l*=r;return a/h}ridge2(t,e,n,i=2,r=.5){let o=0,a=.5,c=1;for(let l=0;l<n;l++)o+=a*(1-Math.abs(this.noise2(t*c,e*c))),a*=r,c*=i;return o}}const Ht={OCEAN:0,BEACH:1,PLAINS:2,FOREST:3,BIRCH_FOREST:4,DESERT:5,SNOWY:6,SNOWY_FOREST:7,SWAMP:8,MOUNTAINS:9},Cg=["Ocean","Beach","Plains","Forest","Birch Forest","Desert","Snowy Tundra","Snowy Forest","Swamp","Mountains"];function zl(s,t,e){const n=Math.min(1,Math.max(0,(e-s)/(t-s)));return n*n*(3-2*n)}class Dg{constructor(t){this.seed=t>>>0,this.continent=new vn(t+1),this.erosion=new vn(t+2),this.peaks=new vn(t+3),this.detail=new vn(t+4),this.temp=new vn(t+5),this.moist=new vn(t+6),this.cave1=new vn(t+7),this.cave2=new vn(t+8),this.mountainMask=new vn(t+9),this.cavern=new vn(t+10)}heightAt(t,e){const n=this.continent.fbm2(t/700,e/700,4),i=(this.erosion.fbm2(t/400,e/400,3)+1)/2,r=zl(.15,.55,this.mountainMask.noise2(t/520,e/520)),o=this.peaks.ridge2(t/230,e/230,4),a=this.detail.fbm2(t/60,e/60,3)*(4-i*2.5);let c=42+n*16+a;c+=Math.pow(Math.max(0,o-.35),1.6)*52*r;const l=this.tempAt(t,e);return this.moistAt(t,e)>.72&&l>.35&&l<.7&&r<.3&&c>Te-1&&c<Te+8&&(c=Te+1+(c-Te-1)*.25),Math.max(4,Math.min(ie-10,c))}tempAt(t,e){return(this.temp.fbm2(t/900,e/900,3)+1)/2}moistAt(t,e){return(this.moist.fbm2(t/640,e/640,3)+1)/2}biomeAt(t,e){const n=this.heightAt(t,e),i=this.tempAt(t,e),r=this.moistAt(t,e),o=zl(.15,.55,this.mountainMask.noise2(t/520,e/520));return n<Te-2?Ht.OCEAN:n>74&&o>.35?Ht.MOUNTAINS:n<=Te+1.5&&i>.3?Ht.BEACH:i<.28?r>.55?Ht.SNOWY_FOREST:Ht.SNOWY:i>.68&&r<.38?Ht.DESERT:r>.72&&i>.35&&i<.7?Ht.SWAMP:r>.52?i>.42&&i<.62&&r<.64?Ht.BIRCH_FOREST:Ht.FOREST:Ht.PLAINS}isCave(t,e,n,i){if(e<6||e>i+1)return!1;const r=this.cave1.fbm3(t/26,e/20,n/26,2),o=this.cave2.fbm3(t/26,e/20,n/26,2);return Math.abs(r)<.09&&Math.abs(o)<.09||e<34&&this.cavern.fbm3(t/46,e/30,n/46,2)>.44+e/34*.18}generateChunk(t,e){const n=new Uint16Array(te*ie*Wt),i=new Uint8Array(te*Wt),r=new Uint8Array(te*Wt),o=hi(this.seed,t,e,1);for(let a=0;a<te;a++)for(let c=0;c<Wt;c++){const l=t*te+a,h=e*Wt+c,u=this.heightAt(l,h),d=Math.floor(u),f=this.biomeAt(l,h);i[a*Wt+c]=d,r[a*Wt+c]=f;const g=f===Ht.SNOWY||f===Ht.SNOWY_FOREST||f===Ht.MOUNTAINS&&d>86,_=f===Ht.DESERT||f===Ht.BEACH||f===Ht.OCEAN&&d>Te-8;for(let m=0;m<=Math.max(d,Te);m++){const p=de(a,m,c);let T=P.AIR;m>d?(T=m<=Te?P.WATER:P.AIR,T===P.WATER&&m===Te&&g&&f!==Ht.MOUNTAINS&&(T=P.ICE)):m===0||m===1&&o()<.5?T=P.BEDROCK:this.isCave(l,m,h,d)?T=m<=9?P.WATER:P.AIR:m===d?m<Te-1?T=_?P.SAND:f===Ht.OCEAN?P.GRAVEL:P.DIRT:_?T=P.SAND:g?T=P.SNOWY_GRASS:f===Ht.MOUNTAINS&&d>68?T=P.STONE:T=P.GRASS:m>d-4?_?T=m>d-3?P.SAND:P.SANDSTONE:f===Ht.MOUNTAINS&&d>68?T=P.STONE:T=P.DIRT:T=P.STONE,n[p]=T}(f===Ht.OCEAN||f===Ht.SWAMP)&&hi(this.seed,l,h,33)()<.06&&d>4&&(n[de(a,d,c)]=P.CLAY)}return this.placeOres(n,t,e,i),this.decorate(n,t,e),{blocks:n,heightMap:i,biomeMap:r}}placeOres(t,e,n,i){const r=[[P.COAL_ORE,14,10,6,96],[P.IRON_ORE,10,6,4,54],[P.GOLD_ORE,3,5,4,30],[P.REDSTONE_ORE,6,6,4,16],[P.DIAMOND_ORE,2,5,4,14],[P.GRAVEL,6,14,8,60],[P.DIRT,8,14,8,70]];for(let o=0;o<r.length;o++){const[a,c,l,h,u]=r[o],d=hi(this.seed,e,n,100+o);for(let f=0;f<c;f++){let g=d()*te|0,_=h+(d()*(u-h)|0),m=d()*Wt|0;for(let p=0;p<l;p++){if(g>=0&&g<te&&_>1&&_<ie&&m>=0&&m<Wt){const b=de(g,_,m);t[b]===P.STONE&&(t[b]=a)}const T=d()*6|0;T===0?g++:T===1?g--:T===2?_++:T===3?_--:T===4?m++:m--}}}}decorate(t,e,n){for(let i=-1;i<=1;i++)for(let r=-1;r<=1;r++)for(const o of this.chunkFeatures(e+i,n+r))this.applyFeature(t,e,n,o)}chunkFeatures(t,e){const n=hi(this.seed,t,e,777),i=[],r=t*te,o=e*Wt,a=this.biomeAt(r+8,o+8);let c=0,l="oak";switch(a){case Ht.FOREST:c=6+(n()*4|0),l="oak";break;case Ht.BIRCH_FOREST:c=5+(n()*4|0),l="birch";break;case Ht.SNOWY_FOREST:c=4+(n()*3|0),l="spruce";break;case Ht.PLAINS:c=n()<.25?1:0,l="oak";break;case Ht.SWAMP:c=2+(n()*2|0),l="oak";break;case Ht.MOUNTAINS:c=n()<.4?1:0,l="spruce";break;default:c=0}for(let u=0;u<c;u++){const d=r+(n()*te|0),f=o+(n()*Wt|0),g=Math.floor(this.heightAt(d,f));if(g<=Te)continue;const _=l==="oak"&&n()<.12?"birch":l;i.push({type:"tree",kind:_,wx:d,wy:g+1,wz:f,size:4+(n()*3|0),rng:hi(this.seed,d,f,555)})}if(a===Ht.DESERT){const u=n()*3|0;for(let d=0;d<u;d++){const f=r+(n()*te|0),g=o+(n()*Wt|0),_=Math.floor(this.heightAt(f,g));_<=Te||i.push({type:"cactus",wx:f,wy:_+1,wz:g,size:1+(n()*3|0)})}if(n()<.3){const d=r+(n()*te|0),f=o+(n()*Wt|0),g=Math.floor(this.heightAt(d,f));g>Te&&i.push({type:"plant",block:P.DEAD_BUSH,wx:d,wy:g+1,wz:f})}}const h=a===Ht.PLAINS?24:a===Ht.FOREST||a===Ht.BIRCH_FOREST?12:a===Ht.SWAMP?10:0;for(let u=0;u<h;u++){const d=r+(n()*te|0),f=o+(n()*Wt|0),g=Math.floor(this.heightAt(d,f));if(g<=Te)continue;let _=P.TALL_GRASS;const m=n();m<.08?_=P.DANDELION:m<.16&&(_=P.POPPY),i.push({type:"plant",block:_,wx:d,wy:g+1,wz:f})}if(a===Ht.SWAMP)for(let u=0;u<4;u++){const d=r+(n()*te|0),f=o+(n()*Wt|0),g=Math.floor(this.heightAt(d,f));g>Te&&i.push({type:"plant",block:n()<.5?P.MUSHROOM_BROWN:P.MUSHROOM_RED,wx:d,wy:g+1,wz:f})}if((a===Ht.PLAINS||a===Ht.FOREST)&&n()<.06){const u=r+(n()*te|0),d=o+(n()*Wt|0),f=Math.floor(this.heightAt(u,d));f>Te&&i.push({type:"plant",block:P.PUMPKIN,wx:u,wy:f+1,wz:d})}if(a===Ht.BEACH||a===Ht.SWAMP||a===Ht.PLAINS)for(let u=0;u<3;u++){const d=r+(n()*te|0),f=o+(n()*Wt|0),g=Math.floor(this.heightAt(d,f));(g===Te||g===Te+1)&&i.push({type:"cane",wx:d,wy:g+1,wz:f,size:2+(n()*2|0)})}return i}applyFeature(t,e,n,i){const r=(o,a,c,l,h=!0)=>{const u=o-e*te,d=c-n*Wt;if(u<0||u>=te||d<0||d>=Wt||a<0||a>=ie)return;const f=de(u,a,d);h&&t[f]!==P.AIR||(t[f]=l)};switch(i.type){case"tree":this.buildTree(r,i);break;case"cactus":for(let o=0;o<i.size;o++)r(i.wx,i.wy+o,i.wz,P.CACTUS);break;case"cane":for(let o=0;o<i.size;o++)r(i.wx,i.wy+o,i.wz,P.SUGAR_CANE);break;case"plant":r(i.wx,i.wy,i.wz,i.block);break}}buildTree(t,e){const{kind:n,wx:i,wy:r,wz:o}=e,a=e.rng??hi(this.seed,i,o,555);if(n==="spruce"){const u=e.size+3;for(let f=0;f<u;f++)t(i,r+f,o,P.SPRUCE_LOG,!1);let d=2;for(let f=u;f>=2;f-=1){const g=f===u?0:d;for(let _=-g;_<=g;_++)for(let m=-g;m<=g;m++)Math.abs(_)+Math.abs(m)>g+(f%2?0:1)||_===0&&m===0&&f<u||t(i+_,r+f,o+m,P.SPRUCE_LEAVES);t(i,r+u+1,o,P.SPRUCE_LEAVES),d=f%2?1:2}return}const c=n==="birch"?P.BIRCH_LOG:P.OAK_LOG,l=n==="birch"?P.BIRCH_LEAVES:P.OAK_LEAVES,h=e.size+(n==="birch"?2:0);for(let u=0;u<h;u++)t(i,r+u,o,c,!1);for(let u=h-3;u<=h-2;u++)for(let d=-2;d<=2;d++)for(let f=-2;f<=2;f++)d===0&&f===0||Math.abs(d)===2&&Math.abs(f)===2&&a()<.4||t(i+d,r+u,o+f,l);for(let u=-1;u<=1;u++)for(let d=-1;d<=1;d++)Math.abs(u)===1&&Math.abs(d)===1&&a()<.5||t(i+u,r+h-1,o+d,l);t(i,r+h,o,l),t(i+1,r+h,o,l),t(i-1,r+h,o,l),t(i,r+h,o+1,l),t(i,r+h,o-1,l)}}const Wi=new Uint8Array(Re.length),fr=new Uint8Array(Re.length);for(const s of Re)s&&(Wi[s.id]=s.opacity,fr[s.id]=s.lightEmit);const xr=[1,-1,0,0,0,0],Mr=[0,0,1,-1,0,0],Sr=[0,0,0,0,1,-1],Fc=3;class Bc{constructor(t,e){this.world=t,this.dirty=e,this._cx=1/0,this._cz=1/0,this._chunk=null}chunkAt(t,e){const n=t>>4,i=e>>4;return(n!==this._cx||i!==this._cz)&&(this._chunk=this.world.getChunk(n,i),this._cx=n,this._cz=i),this._chunk}opacity(t,e,n){if(e<0)return 15;if(e>=ie)return 0;const i=this.chunkAt(t,n);return!i||!i.hasBlocks?15:Wi[i.blocks[de(t&15,e,n&15)]]}light(t,e,n,i){if(n>=ie)return t===0?15:0;if(n<0)return 0;const r=this.chunkAt(e,i);return!r||!r.hasLight?0:(t===0?r.skyLight:r.blockLight)[de(e&15,n,i&15)]}setLight(t,e,n,i,r){const o=this.chunkAt(e,i);if(!o||!o.hasLight)return;const a=t===0?o.skyLight:o.blockLight,c=e&15,l=i&15;a[de(c,n,l)]=r,this.dirty.add(me(o.cx,o.cz)),c===0&&this.dirty.add(me(o.cx-1,o.cz)),c===15&&this.dirty.add(me(o.cx+1,o.cz)),l===0&&this.dirty.add(me(o.cx,o.cz-1)),l===15&&this.dirty.add(me(o.cx,o.cz+1))}}class ia{constructor(){this.a=[],this.head=0}push(t,e,n){this.a.push(t,e,n)}get size(){return(this.a.length-this.head)/3}empty(){return this.head>=this.a.length}shift(t){t[0]=this.a[this.head++],t[1]=this.a[this.head++],t[2]=this.a[this.head++]}}class Lg{constructor(){this.a=[],this.head=0}push(t,e,n,i){this.a.push(t,e,n,i)}empty(){return this.head>=this.a.length}shift(t){t[0]=this.a[this.head++],t[1]=this.a[this.head++],t[2]=this.a[this.head++],t[3]=this.a[this.head++]}}function sa(s,t,e){const n=[0,0,0];for(;!e.empty();){e.shift(n);const[i,r,o]=n,a=s.light(t,i,r,o);if(!(a<=1))for(let c=0;c<6;c++){const l=i+xr[c],h=r+Mr[c],u=o+Sr[c];if(h<0||h>=ie)continue;const d=s.opacity(l,h,u);if(d>=15)continue;let f;t===0&&c===Fc&&a===15&&d===0?f=15:f=a-Math.max(1,d),f>0&&s.light(t,l,h,u)<f&&(s.setLight(t,l,h,u,f),e.push(l,h,u))}}}function Pg(s,t,e,n){const i=[0,0,0,0];for(;!e.empty();){e.shift(i);const[r,o,a,c]=i;for(let l=0;l<6;l++){const h=r+xr[l],u=o+Mr[l],d=a+Sr[l];if(u<0||u>=ie)continue;const f=s.light(t,h,u,d);if(f===0)continue;const g=t===0&&l===Fc&&c===15;f<c||g&&f===15?(s.setLight(t,h,u,d,0),e.push(h,u,d,g&&f===15?15:f)):n.push(h,u,d)}}}function Ig(s,t,e){const n=te*ie*Wt;t.skyLight=new Uint8Array(n),t.blockLight=new Uint8Array(n),t.hasLight=!0;const i=new Bc(s,e),r=new ia,o=new ia,a=t.cx*te,c=t.cz*Wt;for(let l=0;l<te;l++)for(let h=0;h<Wt;h++){let u=15;for(let d=ie-1;d>=0&&u>0;d--){const f=de(l,d,h),g=Wi[t.blocks[f]];g>=15?u=0:g>0&&(u=Math.max(0,u-g)),u>0&&(t.skyLight[f]=u)}}for(let l=0;l<te;l++)for(let h=0;h<Wt;h++)for(let u=0;u<ie;u++){const d=t.skyLight[de(l,u,h)];if(d<=1)continue;let f=!1;for(let g=0;g<6&&!f;g++){const _=l+xr[g],m=u+Mr[g],p=h+Sr[g];if(_<0||_>=te||p<0||p>=Wt||m<0||m>=ie)continue;const T=de(_,m,p);Wi[t.blocks[T]]<15&&t.skyLight[T]<d-1&&(f=!0)}f&&r.push(a+l,u,c+h)}for(let l=0;l<te;l++)for(let h=0;h<Wt;h++)for(let u=0;u<ie;u++){const d=de(l,u,h),f=fr[t.blocks[d]];f>0&&(t.blockLight[d]=f,o.push(a+l,u,c+h))}for(const[l,h]of[[1,0],[-1,0],[0,1],[0,-1]]){const u=s.getChunk(t.cx+l,t.cz+h);if(!(!u||!u.hasLight))for(let d=0;d<16;d++)for(let f=0;f<ie;f++){const g=l===1?(t.cx+1)*16:l===-1?t.cx*16-1:a+d,_=h===1?(t.cz+1)*16:h===-1?t.cz*16-1:c+d;u.skyLight[de(g&15,f,_&15)]>1&&r.push(g,f,_),u.blockLight[de(g&15,f,_&15)]>1&&o.push(g,f,_);const m=l===1?(t.cx+1)*16-1:l===-1?t.cx*16:a+d,p=h===1?(t.cz+1)*16-1:h===-1?t.cz*16:c+d;t.skyLight[de(m&15,f,p&15)]>1&&r.push(m,f,p),t.blockLight[de(m&15,f,p&15)]>1&&o.push(m,f,p)}}sa(i,0,r),sa(i,1,o),e.add(me(t.cx,t.cz))}function Ug(s,t,e,n,i,r,o){const a=new Bc(s,o),c=Wi[i],l=Wi[r],h=fr[i],u=fr[r];for(let d=0;d<2;d++){const f=new Lg,g=new ia,_=a.light(d,t,e,n);if(d===1&&h>0&&u<h?(a.setLight(1,t,e,n,0),f.push(t,e,n,_)):l>c&&_>0&&(a.setLight(d,t,e,n,0),f.push(t,e,n,_)),Pg(a,d,f,g),l<c)for(let m=0;m<6;m++){const p=t+xr[m],T=e+Mr[m],b=n+Sr[m];a.light(d,p,T,b)>0&&g.push(p,T,b)}d===1&&u>0&&(a.setLight(1,t,e,n,Math.max(a.light(1,t,e,n),u)),g.push(t,e,n)),d===0&&l<c&&(a.light(0,t,e+1,n)===15||e+1>=ie)&&g.push(t,e+1,n),l>=15&&a.setLight(d,t,e,n,0),sa(a,d,g)}}const as=new Uint8Array(Re.length);for(const s of Re)s&&(as[s.id]=s.opacity);const Ng=[{face:dr,dir:[1,0,0],shade:.6,ta:1,tb:2,corners:[[1,0,0],[1,1,0],[1,1,1],[1,0,1]],uvs:[[0,0],[0,1],[1,1],[1,0]]},{face:Jo,dir:[-1,0,0],shade:.6,ta:1,tb:2,corners:[[0,0,1],[0,1,1],[0,1,0],[0,0,0]],uvs:[[0,0],[0,1],[1,1],[1,0]]},{face:Qo,dir:[0,1,0],shade:1,ta:0,tb:2,corners:[[0,1,1],[1,1,1],[1,1,0],[0,1,0]],uvs:[[0,1],[1,1],[1,0],[0,0]]},{face:ta,dir:[0,-1,0],shade:.5,ta:0,tb:2,corners:[[0,0,0],[1,0,0],[1,0,1],[0,0,1]],uvs:[[0,0],[1,0],[1,1],[0,1]]},{face:ea,dir:[0,0,1],shade:.8,ta:0,tb:1,corners:[[0,0,1],[1,0,1],[1,1,1],[0,1,1]],uvs:[[0,0],[1,0],[1,1],[0,1]]},{face:na,dir:[0,0,-1],shade:.8,ta:0,tb:1,corners:[[1,0,0],[0,0,0],[0,1,0],[1,1,0]],uvs:[[0,0],[1,0],[1,1],[0,1]]}],Og=[.45,.62,.8,1];class Hl{constructor(){this.pos=[],this.uvw=[],this.light=[],this.index=[],this.vcount=0}quad(t,e,n,i,r,o,a,c){const l=this.vcount;for(let h=0;h<4;h++){const u=i[h];this.pos.push(t+u[0],e+u[1],n+u[2]),this.uvw.push(r[h][0],r[h][1],o),this.light.push(a[h*2],a[h*2+1])}c?this.index.push(l+1,l+2,l+3,l+1,l+3,l):this.index.push(l,l+1,l+2,l,l+2,l+3),this.vcount+=4}build(){if(this.vcount===0)return null;const t=new un;return t.setAttribute("position",new Fe(new Float32Array(this.pos),3)),t.setAttribute("aUvw",new Fe(new Float32Array(this.uvw),3)),t.setAttribute("aLight",new Fe(new Float32Array(this.light),2)),t.setIndex(new Fe(this.vcount<65536?new Uint16Array(this.index):new Uint32Array(this.index),1)),t}}function Fg(s,t,e){const n=new Hl,i=new Hl,r=t.cx*te,o=t.cz*Wt,a=(u,d,f)=>s.getBlockW(u,d,f),c=(u,d,f)=>s.getSkyW(u,d,f),l=(u,d,f)=>s.getBlockLightW(u,d,f),h=new Float32Array(8);for(let u=0;u<te;u++)for(let d=0;d<Wt;d++)for(let f=0;f<ie;f++){const g=t.blocks[(u*Wt+d)*ie+f];if(g===P.AIR)continue;const m=Re[g].render;if(m===Ma)continue;const p=r+u,T=o+d;if(m===mn||m===Ss){const w=c(p,f,T)/15,O=l(p,f,T)/15;for(let W=0;W<4;W++)h[W*2]=w,h[W*2+1]=O;const S=e.faceLayer(g,dr),M=.146,C=.854,z=[[[M,0,M],[C,0,C],[C,1,C],[M,1,M]],[[M,0,C],[C,0,M],[C,1,M],[M,1,C]]],G=[[0,0],[1,0],[1,1],[0,1]];for(const W of z){n.quad(u,f,d,W,G,S,h,!1);const K=[W[3],W[2],W[1],W[0]],H=[[0,1],[1,1],[1,0],[0,0]];n.quad(u,f,d,K,H,S,h,!1)}continue}const b=g===P.WATER,E=m===Sa?i:n,L=t.getMeta(u,f,d),R=b&&a(p,f+1,T)!==P.WATER?.875:1;for(const w of Ng){const O=p+w.dir[0],S=f+w.dir[1],M=T+w.dir[2],C=a(O,S,M);if(!dg(g,C))continue;const z=e.faceLayer(g,w.face,L),G=[0,0,0,0];for(let H=0;H<4;H++){const rt=w.corners[H],V=rt[w.ta]===1?1:-1,ht=rt[w.tb]===1?1:-1,ut=p+w.dir[0],_t=f+w.dir[1],Bt=T+w.dir[2],Yt=[0,0,0];Yt[w.ta]=V;const jt=[0,0,0];jt[w.tb]=ht;const ne=as[a(ut+Yt[0],_t+Yt[1],Bt+Yt[2])]>=15?1:0,Y=as[a(ut+jt[0],_t+jt[1],Bt+jt[2])]>=15?1:0,Q=as[a(ut+Yt[0]+jt[0],_t+Yt[1]+jt[1],Bt+Yt[2]+jt[2])]>=15?1:0,vt=ne&&Y?0:3-(ne+Y+Q);G[H]=vt;let It=0,yt=0,Kt=0;const Ce=[[ut,_t,Bt],[ut+Yt[0],_t+Yt[1],Bt+Yt[2]],[ut+jt[0],_t+jt[1],Bt+jt[2]],[ut+Yt[0]+jt[0],_t+Yt[1]+jt[1],Bt+Yt[2]+jt[2]]];for(const[ae,zt,Lt]of Ce)as[a(ae,zt,Lt)]>=15||(It+=c(ae,zt,Lt),yt+=l(ae,zt,Lt),Kt++);Kt===0&&(It=c(ut,_t,Bt),yt=l(ut,_t,Bt),Kt=1);const A=Og[vt]*w.shade;h[H*2]=It/Kt/15*A,h[H*2+1]=yt/Kt/15*A}const W=G[0]+G[2]<G[1]+G[3];let K=w.corners;if(b&&R!==1||g===P.CACTUS){if(K=w.corners.map(H=>[...H]),b)for(const H of K)H[1]===1&&(H[1]=R);if(g===P.CACTUS&&w.dir[1]===0)for(const H of K)w.dir[0]===1?H[0]=.9375:w.dir[0]===-1&&(H[0]=.0625),w.dir[2]===1?H[2]=.9375:w.dir[2]===-1&&(H[2]=.0625)}E.quad(u,f,d,K,w.uvs,z,h,W)}}return{opaqueGeo:n.build(),waterGeo:i.build()}}const Gl=`
precision highp float;
in vec3 position;
in vec3 aUvw;
in vec2 aLight;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
out vec3 vUvw;
out vec2 vLight;
out float vFogDepth;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  vUvw = aUvw;
  vLight = aLight;
  vFogDepth = length(mv.xyz);
}
`;function Vl(s){return`
precision highp float;
precision highp sampler2DArray;
uniform sampler2DArray uAtlas;
uniform float uDay;
uniform vec3 uFogColor;
uniform float uFogNear;
uniform float uFogFar;
in vec3 vUvw;
in vec2 vLight;
in float vFogDepth;
out vec4 outColor;
void main() {
  vec4 tex = texture(uAtlas, vec3(vUvw.xy, vUvw.z));
  ${s?"":"if (tex.a < 0.5) discard;"}
  float br = clamp(max(vLight.y, vLight.x * uDay) + 0.04, 0.0, 1.0);
  vec3 col = tex.rgb * br;
  float fogF = smoothstep(uFogNear, uFogFar, vFogDepth);
  ${s?"outColor = vec4(mix(col, uFogColor, fogF), tex.a * 0.82);":"outColor = vec4(mix(col, uFogColor, fogF), 1.0);"}
}
`}function Bg(s){const t={uAtlas:{value:s.texture},uDay:{value:1},uFogColor:{value:new qt(9420012)},uFogNear:{value:80},uFogFar:{value:140}},e=new ul({glslVersion:ar,uniforms:t,vertexShader:Gl,fragmentShader:Vl(!1)}),n=new ul({glslVersion:ar,uniforms:t,vertexShader:Gl,fragmentShader:Vl(!0),transparent:!0,depthWrite:!0});return{opaque:e,water:n,uniforms:t}}class kg{constructor({seed:t,atlas:e,renderDistance:n=8,loadChunk:i=null,onChunkEvicted:r=null}){this.seed=t,this.atlas=e,this.renderDistance=n,this.loadChunk=i,this.onChunkEvicted=r,this.gen=new Dg(t),this.pool=new Ag(t),this.chunks=new Map,this.pendingGen=new Set,this.lightQueue=[],this.dirtyMeshes=new Set,this.materials=Bg(e),this.group=new pi,this.group.matrixAutoUpdate=!1,this.centerCx=1/0,this.centerCz=1/0,this.stats={chunks:0,meshed:0,genQueue:0}}getChunk(t,e){return this.chunks.get(me(t,e))}getBlockW(t,e,n){if(e<0)return P.BEDROCK;if(e>=ie)return P.AIR;const i=this.chunks.get(me(t>>4,n>>4));return!i||!i.hasBlocks?P.BEDROCK:i.blocks[de(t&15,e,n&15)]}isLoaded(t,e){const n=this.chunks.get(me(t>>4,e>>4));return!!(n&&n.hasBlocks)}getSkyW(t,e,n){if(e>=ie)return 15;if(e<0)return 0;const i=this.chunks.get(me(t>>4,n>>4));return!i||!i.hasLight?15:i.skyLight[de(t&15,e,n&15)]}getBlockLightW(t,e,n){if(e<0||e>=ie)return 0;const i=this.chunks.get(me(t>>4,n>>4));return!i||!i.hasLight?0:i.blockLight[de(t&15,e,n&15)]}getMetaW(t,e,n){const i=this.chunks.get(me(t>>4,n>>4));return!i||e<0||e>=ie?0:i.getMeta(t&15,e,n&15)}setBlock(t,e,n,i,r=0){if(e<0||e>=ie)return-1;const o=t>>4,a=n>>4,c=this.chunks.get(me(o,a));if(!c||!c.hasBlocks)return-1;const l=t&15,h=n&15,u=de(l,e,h),d=c.blocks[u];return d===i&&c.getMeta(l,e,h)===r||(c.blocks[u]=i,c.setMeta(l,e,h,r),c.modified=!0,c.blockEntities.delete(u),c.hasLight&&Ug(this,t,e,n,d,i,this.dirtyMeshes),this.dirtyMeshes.add(me(o,a)),l===0&&this.dirtyMeshes.add(me(o-1,a)),l===15&&this.dirtyMeshes.add(me(o+1,a)),h===0&&this.dirtyMeshes.add(me(o,a-1)),h===15&&this.dirtyMeshes.add(me(o,a+1))),d}blockEntityAt(t,e,n){const i=this.chunks.get(me(t>>4,n>>4));return i?i.blockEntities.get(de(t&15,e,n&15))??null:null}setBlockEntity(t,e,n,i){const r=this.chunks.get(me(t>>4,n>>4));if(!r)return;const o=de(t&15,e,n&15);i===null?r.blockEntities.delete(o):r.blockEntities.set(o,i),r.modified=!0}surfaceHeight(t,e){for(let n=ie-1;n>=0;n--){const i=this.getBlockW(t,n,e);if(i!==P.AIR&&Re[i].solid)return n}return 0}biomeAt(t,e){const n=this.chunks.get(me(t>>4,e>>4));return n?.biomeMap?n.biomeMap[(t&15)*Wt+(e&15)]:this.gen.biomeAt(t,e)}update(t,e,n,i=1){const r=5*i,o=9*i,a=Math.floor(t/te),c=Math.floor(e/Wt),l=this.renderDistance;(a!==this.centerCx||c!==this.centerCz)&&(this.centerCx=a,this.centerCz=c,this.requestMissing(a,c,l+1),this.evictFar(a,c,l+3),this.pool.prune((u,d)=>Math.max(Math.abs(u-a),Math.abs(d-c))<=l+1));let h=0;for(;this.lightQueue.length&&performance.now()-n<r&&h++<4*i;){this.lightQueue.sort((d,f)=>Math.abs(f.cx-a)+Math.abs(f.cz-c)-(Math.abs(d.cx-a)+Math.abs(d.cz-c)));const u=this.lightQueue.pop();!u.hasBlocks||u.hasLight||Ig(this,u,this.dirtyMeshes)}if(this.dirtyMeshes.size){const u=[...this.dirtyMeshes].map(d=>this.chunks.get(d)).filter(d=>d&&d.hasLight&&this.neighborsLit(d)&&Math.max(Math.abs(d.cx-a),Math.abs(d.cz-c))<=l).sort((d,f)=>Math.abs(d.cx-a)+Math.abs(d.cz-c)-(Math.abs(f.cx-a)+Math.abs(f.cz-c)));for(const d of u)if(this.rebuildMesh(d),this.dirtyMeshes.delete(me(d.cx,d.cz)),performance.now()-n>o)break}this.stats.chunks=this.chunks.size,this.stats.genQueue=this.pool.queue.length+this.pendingGen.size}neighborsLit(t){for(let e=-1;e<=1;e++)for(let n=-1;n<=1;n++){if(e===0&&n===0)continue;const i=this.getChunk(t.cx+e,t.cz+n);if(!i||!i.hasLight)return!1}return!0}requestMissing(t,e,n){const i=[];for(let r=-n;r<=n;r++)for(let o=-n;o<=n;o++){const a=t+r,c=e+o,l=me(a,c);this.chunks.has(l)||this.pendingGen.has(l)||i.push([a,c,r*r+o*o])}i.sort((r,o)=>r[2]-o[2]);for(const[r,o]of i)this.requestChunk(r,o)}async requestChunk(t,e){const n=me(t,e);this.pendingGen.add(n);try{let i=null;this.loadChunk&&(i=await this.loadChunk(t,e));let r,o,a;if(i){r=i.blocks,o=new Uint8Array(te*Wt),a=new Uint8Array(te*Wt);for(let l=0;l<te;l++)for(let h=0;h<Wt;h++){const u=t*te+l,d=e*Wt+h;o[l*Wt+h]=Math.floor(this.gen.heightAt(u,d)),a[l*Wt+h]=this.gen.biomeAt(u,d)}}else{const l=await this.pool.generate(t,e);r=l.blocks,o=l.heightMap,a=l.biomeMap}if(!this.pendingGen.has(n))return;const c=new bg(t,e);if(c.setData(r,o,a),i?.meta&&(c.meta=i.meta),i?.blockEntities)for(const[l,h]of i.blockEntities)c.blockEntities.set(l,h);i&&(c.modified=!0),this.chunks.set(n,c),this.lightQueue.push(c);for(let l=-1;l<=1;l++)for(let h=-1;h<=1;h++){const u=this.getChunk(t+l,e+h);(u?.mesh||u?.hasLight)&&this.dirtyMeshes.add(me(t+l,e+h))}}finally{this.pendingGen.delete(n)}}evictFar(t,e,n){for(const[i,r]of this.chunks)Math.max(Math.abs(r.cx-t),Math.abs(r.cz-e))>n&&(r.modified&&this.onChunkEvicted&&this.onChunkEvicted(r),this.disposeChunkMesh(r),this.chunks.delete(i),this.dirtyMeshes.delete(i))}rebuildMesh(t){this.disposeChunkMesh(t);const{opaqueGeo:e,waterGeo:n}=Fg(this,t,this.atlas),i={opaque:null,water:null},r=new qi(new F(t.cx*te+8,ie/2,t.cz*Wt+8),Math.sqrt(64+ie/2*(ie/2)+64)+1);e&&(e.boundingSphere=r.clone(),i.opaque=new Ie(e,this.materials.opaque),i.opaque.position.set(t.cx*te,0,t.cz*Wt),i.opaque.updateMatrix(),i.opaque.matrixAutoUpdate=!1,this.group.add(i.opaque)),n&&(n.boundingSphere=r.clone(),i.water=new Ie(n,this.materials.water),i.water.position.set(t.cx*te,0,t.cz*Wt),i.water.updateMatrix(),i.water.matrixAutoUpdate=!1,i.water.renderOrder=10,this.group.add(i.water)),t.mesh=i,this.stats.meshed++}disposeChunkMesh(t){if(t.mesh){for(const e of[t.mesh.opaque,t.mesh.water])e&&(this.group.remove(e),e.geometry.dispose());t.mesh=null}}modifiedChunks(){const t=[];for(const e of this.chunks.values())e.modified&&t.push(e);return t}dispose(){for(const t of this.chunks.values())this.disposeChunkMesh(t);this.chunks.clear(),this.pendingGen.clear(),this.pool.dispose(),this.materials.opaque.dispose(),this.materials.water.dispose()}}const mi=1e-4;function ai(s,t,e,n,i,r){const o=i/2,a=Math.floor(t-o),c=Math.floor(t+o-mi),l=Math.floor(e),h=Math.floor(e+r-mi),u=Math.floor(n-o),d=Math.floor(n+o-mi);for(let f=a;f<=c;f++)for(let g=l;g<=h;g++)for(let _=u;_<=d;_++)if(Ea(s.getBlockW(f,g,_)))return!0;return!1}function Ta(s,t,e,n=!1){const i={onGround:!1,hitWall:!1,hitCeiling:!1};let r=t.vy*e;if(r!==0){const c=t.y+r;if(ai(s,t.x,c,t.z,t.w,t.h)){if(r<0){t.y=Math.floor(t.y+r)+1;for(let l=0;l<4&&ai(s,t.x,t.y,t.z,t.w,t.h);l++)t.y+=1;i.onGround=!0}else t.y=Math.ceil(t.y+t.h+r)-t.h-mi*2,i.hitCeiling=!0;t.vy=0}else t.y=c}!i.onGround&&ai(s,t.x,t.y-.02,t.z,t.w,t.h)&&(i.onGround=!0);let o=t.vx*e;if(o!==0){const c=t.x+o,l=n&&i.onGround&&!ai(s,c,t.y-.6,t.z,t.w,.5);ai(s,c,t.y,t.z,t.w,t.h)||l?(t.vx=0,i.hitWall=!l):t.x=c}let a=t.vz*e;if(a!==0){const c=t.z+a,l=n&&i.onGround&&!ai(s,t.x,t.y-.6,c,t.w,.5);ai(s,t.x,t.y,c,t.w,t.h)||l?(t.vz=0,i.hitWall=!l):t.z=c}return i}function kc(s,t,e){const n=t.w/2,i=Math.floor(t.x-n),r=Math.floor(t.x+n-mi),o=Math.floor(t.y),a=Math.floor(t.y+t.h-mi),c=Math.floor(t.z-n),l=Math.floor(t.z+n-mi);for(let h=i;h<=r;h++)for(let u=o;u<=a;u++)for(let d=c;d<=l;d++)if(s.getBlockW(h,u,d)===e)return!0;return!1}function zg(s,t,e,n){return s.getBlockW(Math.floor(t),Math.floor(e),Math.floor(n))===P.WATER}class Hg{constructor(t){this.world=t,this.x=8,this.y=80,this.z=8,this.vx=0,this.vy=0,this.vz=0,this.w=vg,this.h=xg,this.yaw=0,this.pitch=0,this.onGround=!1,this.flying=!1,this.sprinting=!1,this.sneaking=!1,this.inWater=!1,this.headInWater=!1,this.mode=Bi,this.health=20,this.maxHealth=20,this.hunger=20,this.saturation=5,this.air=20,this.dead=!1,this.fallStart=null,this.hurtCooldown=0,this.regenTimer=0,this.starveTimer=0,this.airTimer=0,this.exhaustion=0,this.inventory=new Array(36).fill(null),this.selected=0,this.spawnPoint={x:8,y:80,z:8},this._lastSpace=-1,this.events=new EventTarget}get eyeY(){return this.y+(this.sneaking?Bl-.15:Bl)}heldStack(){return this.inventory[this.selected]}lookDir(){const t=Math.cos(this.pitch);return{x:-Math.sin(this.yaw)*t,y:Math.sin(this.pitch),z:-Math.cos(this.yaw)*t}}update(t,e,n){if(this.dead||!this.world.isLoaded(Math.floor(this.x),Math.floor(this.z)))return;if(this.hurtCooldown=Math.max(0,this.hurtCooldown-e),!n){const m=.0023*(this.sensitivity??1);this.yaw-=t.dx*m,this.pitch-=t.dy*m,this.pitch=Math.max(-Math.PI/2+.01,Math.min(Math.PI/2-.01,this.pitch))}this.inWater=kc(this.world,this,P.WATER),this.headInWater=zg(this.world,this.x,this.eyeY,this.z);let i=0,r=0;n||(t.down("KeyW")&&(i+=1),t.down("KeyS")&&(i-=1),t.down("KeyD")&&(r+=1),t.down("KeyA")&&(r-=1)),this.sneaking=!n&&t.down("ShiftLeft")&&!this.flying,this.sprinting=!n&&t.down("ControlLeft")&&i>0&&!this.sneaking&&this.hunger>6;const o=this.mode===Ke;o||(this.flying=!1);let a=this.flying?ro:this.inWater?Tg:this.sneaking?yg:this.sprinting?Eg:Sg;const c=Math.sin(this.yaw),l=Math.cos(this.yaw);let h=-c*i+l*r,u=-l*i-c*r;const d=Math.hypot(h,u);d>0&&(h=h/d*a,u=u/d*a);const f=this.flying?24:this.onGround?40:this.inWater?12:8;if(this.vx+=(h-this.vx)*Math.min(1,f*e),this.vz+=(u-this.vz)*Math.min(1,f*e),this.flying){let m=0;!n&&t.down("Space")&&(m+=ro),!n&&t.down("ShiftLeft")&&(m-=ro),this.vy+=(m-this.vy)*Math.min(1,24*e)}else this.inWater?(this.vy-=kl*.25*e,this.vy=Math.max(this.vy,-3.5),!n&&t.down("Space")&&(this.vy=Math.min(this.vy+24*e,3.2))):(this.vy-=kl*e,this.vy=Math.max(this.vy,-60),!n&&t.down("Space")&&this.onGround&&(this.vy=Mg,this.addExhaustion(this.sprinting?.2:.05)));const g=Math.max(1,Math.ceil(Math.hypot(this.vx,this.vy,this.vz)*e/.4));let _=!1;for(let m=0;m<g;m++){const p=Ta(this.world,this,e/g,this.sneaking);_=_||p.onGround}if(this.onGround=_,!o&&!this.flying){if(!this.onGround&&!this.inWater&&this.vy<0&&(this.fallStart===null&&(this.fallStart=this.y+Math.abs(this.vy*e)),this.fallStart=Math.max(this.fallStart,this.y-this.vy*e)),(this.onGround||this.inWater)&&this.fallStart!==null){const m=this.fallStart-this.y;!this.inWater&&m>3.2&&this.damage(Math.floor(m-3),"fall"),this.fallStart=null}}else this.fallStart=null;this.y<-12&&this.damage(4,"void"),o||this.updateSurvival(e),this.sprinting&&this.addExhaustion(.1*e*7)}tapSpace(t){this.mode===Ke&&(t-this._lastSpace<300?(this.flying=!this.flying,this.vy=0,this._lastSpace=-1):this._lastSpace=t)}updateSurvival(t){for(;this.exhaustion>=4;)this.exhaustion-=4,this.saturation>0?this.saturation=Math.max(0,this.saturation-1):this.hunger=Math.max(0,this.hunger-1);this.hunger>=18&&this.health<this.maxHealth?(this.regenTimer+=t,this.regenTimer>=2.5&&(this.regenTimer=0,this.health=Math.min(this.maxHealth,this.health+1),this.addExhaustion(1.5))):this.hunger<=0?(this.starveTimer+=t,this.starveTimer>=3&&(this.starveTimer=0,this.health>2&&this.damage(1,"starve"))):this.regenTimer=0,this.headInWater?(this.airTimer+=t,this.airTimer>=.75&&(this.airTimer=0,this.air>0?this.air--:this.damage(2,"drown"))):(this.air=Math.min(20,this.air+t*8),this.airTimer=0)}addExhaustion(t){this.mode===Bi&&(this.exhaustion+=t)}damage(t,e="generic"){this.dead||this.mode===Ke||this.hurtCooldown>0||(this.hurtCooldown=.5,this.health-=t,this.events.dispatchEvent(new CustomEvent("hurt",{detail:{amount:t,cause:e}})),this.health<=0&&(this.health=0,this.dead=!0,this.events.dispatchEvent(new CustomEvent("death",{detail:{cause:e}}))))}eat(t){this.hunger=Math.min(20,this.hunger+t),this.saturation=Math.min(this.hunger,this.saturation+t*.6)}respawn(){this.x=this.spawnPoint.x,this.y=this.spawnPoint.y,this.z=this.spawnPoint.z,this.vx=this.vy=this.vz=0,this.health=this.maxHealth,this.hunger=20,this.saturation=5,this.air=20,this.dead=!1,this.fallStart=null}give(t,e=1){let n=e;const i=Ue(t);if(!i)return e;if(!i.tool)for(let r=0;r<36&&n>0;r++){const o=this.inventory[r];if(o&&o.id===t&&o.dur===void 0){const a=xn(t)-o.count,c=Math.min(a,n);o.count+=c,n-=c}}for(let r=0;r<36&&n>0;r++)if(!this.inventory[r]){const o=Math.min(xn(t),n);this.inventory[r]=jo(t,o),n-=o}return n!==e&&this.events.dispatchEvent(new CustomEvent("inventory")),n}take(t,e=1){let n=0;for(let i=35;i>=0&&n<e;i--){const r=this.inventory[i];if(r&&r.id===t){const o=Math.min(r.count,e-n);r.count-=o,n+=o,r.count<=0&&(this.inventory[i]=null)}}return n>0&&this.events.dispatchEvent(new CustomEvent("inventory")),n}countOf(t){let e=0;for(const n of this.inventory)n&&n.id===t&&(e+=n.count);return e}consumeHeld(t=1){const e=this.inventory[this.selected];e&&(e.count-=t,e.count<=0&&(this.inventory[this.selected]=null),this.events.dispatchEvent(new CustomEvent("inventory")))}damageHeldTool(t=1){const e=this.inventory[this.selected];!e||e.dur===void 0||(e.dur-=t,e.dur<=0&&(this.inventory[this.selected]=null,this.events.dispatchEvent(new CustomEvent("toolbreak"))),this.events.dispatchEvent(new CustomEvent("inventory")))}serialize(){return{x:this.x,y:this.y,z:this.z,yaw:this.yaw,pitch:this.pitch,health:this.health,hunger:this.hunger,saturation:this.saturation,air:this.air,mode:this.mode,flying:this.flying,inventory:this.inventory,selected:this.selected,spawnPoint:this.spawnPoint}}deserialize(t){t&&(Object.assign(this,{x:t.x,y:t.y,z:t.z,yaw:t.yaw??0,pitch:t.pitch??0,health:t.health??20,hunger:t.hunger??20,saturation:t.saturation??5,air:t.air??20,mode:t.mode??Bi,flying:t.flying??!1,selected:t.selected??0}),Array.isArray(t.inventory)&&(this.inventory=t.inventory.map(e=>e?{...e}:null)),t.spawnPoint&&(this.spawnPoint={...t.spawnPoint}),this.dead=this.health<=0)}}function Gg(s,t,e,n,i=!1){let r=Math.floor(t.x),o=Math.floor(t.y),a=Math.floor(t.z);const c=e.x>0?1:-1,l=e.y>0?1:-1,h=e.z>0?1:-1,u=e.x!==0?Math.abs(1/e.x):1/0,d=e.y!==0?Math.abs(1/e.y):1/0,f=e.z!==0?Math.abs(1/e.z):1/0,g=R=>R-Math.floor(R);let _=e.x!==0?(e.x>0?1-g(t.x):g(t.x))*u:1/0,m=e.y!==0?(e.y>0?1-g(t.y):g(t.y))*d:1/0,p=e.z!==0?(e.z>0?1-g(t.z):g(t.z))*f:1/0,T=0,b=0,E=0,L=0;for(;L<=n;){const R=s.getBlockW(r,o,a),w=Re[R];if(R!==P.AIR&&w&&(!w.fluid||i))return{x:r,y:o,z:a,id:R,nx:T,ny:b,nz:E,dist:L};_<m&&_<p?(r+=c,L=_,_+=u,T=-c,b=0,E=0):m<p?(o+=l,L=m,m+=d,T=0,b=-l,E=0):(a+=h,L=p,p+=f,T=0,b=0,E=0-h)}return null}const Vg=new Set([P.CRAFTING_TABLE,P.FURNACE,P.FURNACE_LIT]),Wl=new Set([P.TALL_GRASS,P.DANDELION,P.POPPY,P.SUGAR_CANE,P.DEAD_BUSH,P.MUSHROOM_BROWN,P.MUSHROOM_RED,P.CACTUS,P.TORCH]);class Wg{constructor(t,e,n){this.world=t,this.player=e,this.cb=n,this.target=null,this.breakTarget=null,this.breakProgress=0,this.breakTime=0,this.placeCooldown=0,this.breakCooldown=0,this.useCooldown=0,this.dropRng=vs(Math.random()*2**31|0)}update(t,e,n){const i=this.player;if(this.placeCooldown=Math.max(0,this.placeCooldown-e),this.breakCooldown=Math.max(0,this.breakCooldown-e),this.useCooldown=Math.max(0,this.useCooldown-e),n||i.dead){this.target=null,this.resetBreaking();return}const r={x:i.x,y:i.eyeY,z:i.z},o=i.lookDir();if(this.target=Gg(this.world,r,o,Oc),t.mouseDown(0)&&this.target){const a=this.target;if((!this.breakTarget||this.breakTarget.x!==a.x||this.breakTarget.y!==a.y||this.breakTarget.z!==a.z)&&this.startBreaking(a),this.breakTarget){const c=rn(this.breakTarget.id);c.hardness<0||(i.mode===Ke?this.breakCooldown<=0&&(this.finishBreak(!0),this.breakCooldown=.22):(this.breakProgress+=e/this.breakTime,this.breakProgress>=1?this.finishBreak(!1):Math.random()<e*6&&this.cb.playSound("hit",{block:c.sound})))}}else this.resetBreaking();t.mouseDown(2)&&this.placeCooldown<=0&&this.useCooldown<=0&&(this.useOrPlace(),this.placeCooldown=.24)}startBreaking(t){const e=this.player,n=rn(t.id);this.breakTarget={x:t.x,y:t.y,z:t.z,id:t.id},this.breakProgress=0;const i=e.heldStack(),r=i?Ue(i.id)?.tool:null;let o=1;n.tool,n.tool&&r&&r.class===n.tool&&(o=r.speed,r.tier>=(n.minTier>0?n.minTier:0));const a=n.minTier===0||r&&r.class===n.tool&&r.tier>=n.minTier;this.breakCanHarvest=a;const c=n.hardness*(a||!n.tool?1.5:5);this.breakTime=Math.max(.05,c/o)}resetBreaking(){this.breakTarget=null,this.breakProgress=0}finishBreak(t){const e=this.breakTarget;if(!e)return;const n=this.player,i=rn(e.id);this.world.setBlock(e.x,e.y,e.z,P.AIR),this.cb.playSound("break",{block:i.sound});const r=this.world.getBlockW(e.x,e.y+1,e.z);if(Wl.has(r)){const o=rn(r);this.world.setBlock(e.x,e.y+1,e.z,P.AIR),t||this.spawnBlockDrops(e.x,e.y+1,e.z,o,!0)}t||(this.breakCanHarvest&&this.spawnBlockDrops(e.x,e.y,e.z,i,!0),n.damageHeldTool(1),n.addExhaustion(.03)),this.resetBreaking()}spawnBlockDrops(t,e,n,i,r){if(!r)return;let o=[];i.drop===null?o=[]:i.drop===void 0?o=[{id:i.id,count:1}]:typeof i.drop=="number"?o=[{id:i.drop,count:1}]:typeof i.drop=="function"&&(o=i.drop(this.dropRng)??[]),o.length&&this.cb.spawnDrops(t+.5,e+.3,n+.5,o)}useOrPlace(){const t=this.player,e=this.target,n=t.heldStack();if(e&&Vg.has(e.id)&&!t.sneaking){this.cb.openUI(e.id===P.CRAFTING_TABLE?"crafting":"furnace",e);return}if(n){const f=Ue(n.id);if(f?.food&&t.hunger<20&&t.mode!==Ke){t.eat(f.food),t.consumeHeld(1),this.cb.playSound("eat",{}),this.useCooldown=.4;return}}if(!e||!n||!ya(n.id))return;const i=rn(n.id);let r=e.x,o=e.y,a=e.z;rn(e.id).replaceable||(r+=e.nx,o+=e.ny,a+=e.nz);const l=this.world.getBlockW(r,o,a);if(!rn(l).replaceable)return;if(Wl.has(i.id)){const f=this.world.getBlockW(r,o-1,a);if(!Ea(f))return}if(i.solid&&this.intersectsPlayer(r,o,a))return;let h=0;const u=i.textures;if(typeof u=="object"&&u.front){const f=(t.yaw%(Math.PI*2)+Math.PI*2)%(Math.PI*2),g=Math.round(f/(Math.PI/2))%4;h=[2,1,0,3][g]}this.world.setBlock(r,o,a,i.id,h)!==-1&&(i.id===P.FURNACE&&this.world.setBlockEntity(r,o,a,null),this.cb.playSound("place",{block:i.sound}),t.mode!==Ke&&t.consumeHeld(1))}intersectsPlayer(t,e,n){const i=this.player,r=i.w/2;return t+1>i.x-r&&t<i.x+r&&e+1>i.y&&e<i.y+i.h&&n+1>i.z-r&&n<i.z+r}}class Xg{constructor(t){this.canvas=t,this.keys=new Set,this.mouseButtons=new Set,this.dx=0,this.dy=0,this.wheel=0,this.captured=!1,this.pointerLocked=!1,this.onKeyDown=null,this.onMouseDown=null,this.onMouseUp=null,this.onWheel=null,document.addEventListener("keydown",e=>{(e.code==="F3"||e.code==="F5")&&e.preventDefault(),!(this.onKeyDown&&this.onKeyDown(e.code,e))&&(this.captured||this.keys.add(e.code))}),document.addEventListener("keyup",e=>this.keys.delete(e.code)),window.addEventListener("blur",()=>{this.keys.clear(),this.mouseButtons.clear()}),document.addEventListener("mousemove",e=>{this.pointerLocked&&!this.captured&&(this.dx+=e.movementX,this.dy+=e.movementY)}),t.addEventListener("mousedown",e=>{if(!this.captured){if(!this.pointerLocked){this.requestLock();return}this.mouseButtons.add(e.button),this.onMouseDown?.(e.button)}}),document.addEventListener("mouseup",e=>{this.mouseButtons.delete(e.button),this.onMouseUp?.(e.button)}),t.addEventListener("contextmenu",e=>e.preventDefault()),t.addEventListener("wheel",e=>{this.captured||(this.wheel+=Math.sign(e.deltaY),this.onWheel?.(Math.sign(e.deltaY)))},{passive:!0}),document.addEventListener("pointerlockchange",()=>{this.pointerLocked=document.pointerLockElement===t,this.pointerLocked||(this.keys.clear(),this.mouseButtons.clear(),this.onLockLost?.())})}requestLock(){this.canvas.requestPointerLock?.()}releaseLock(){this.pointerLocked&&document.exitPointerLock()}endFrame(){this.dx=0,this.dy=0,this.wheel=0}down(t){return!this.captured&&this.keys.has(t)}mouseDown(t){return!this.captured&&this.mouseButtons.has(t)}}class qg{constructor(t){const e=new xu(new zn(1.002,1.002,1.002));this.outline=new _u(e,new _c({color:0,transparent:!0,opacity:.7})),this.outline.visible=!1,t.add(this.outline),this.crackTextures=[];for(let n=0;n<5;n++){const i=new gr(In(`crack_${n}`));i.magFilter=be,i.minFilter=be,this.crackTextures.push(i)}this.crackMat=new vi({map:this.crackTextures[0],transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}),this.crack=new Ie(new zn(1.001,1.001,1.001),this.crackMat),this.crack.visible=!1,t.add(this.crack)}update(t,e){if(!t){this.outline.visible=!1,this.crack.visible=!1;return}if(this.outline.visible=!0,this.outline.position.set(t.x+.5,t.y+.5,t.z+.5),e>0){const n=Math.min(4,Math.floor(e*5));this.crackMat.map=this.crackTextures[n],this.crack.visible=!0,this.crack.position.copy(this.outline.position)}else this.crack.visible=!1}}const oo=new Map;function Yg(s){if(oo.has(s))return oo.get(s);let t;if(ya(s)){const n=rn(s),i=n.textures;t=typeof i=="string"?i:n.render===mn||n.render===Ss?i.side??i:i.side,typeof t!="string"&&(t=typeof i=="object"?i.side??i.top:i)}else t=Ue(s)?.texture;const e=new gr(In(t));return e.magFilter=be,e.minFilter=be,e.colorSpace=tn,oo.set(s,e),e}const Kg=new zn(.28,.28,.28),$g=new jn(.35,.35);class Zg{constructor(t,e,n,i,r,o,a,c=0,l=2.5,h=0){this.world=e,this.id=n,this.count=i,this.x=r,this.y=o,this.z=a,this.vx=c,this.vy=l,this.vz=h,this.w=.25,this.h=.25,this.age=0,this.pickupDelay=.6,this.dead=!1;const u=ya(n)&&rn(n).render!==mn&&rn(n).render!==Ss,d=new vi({map:Yg(n),transparent:!0,alphaTest:.1,side:u?Fn:an});this.mesh=new Ie(u?Kg:$g,d),this.spin=Math.random()*Math.PI*2,t.add(this.mesh),this.scene=t}update(t,e){if(this.age+=t,this.pickupDelay=Math.max(0,this.pickupDelay-t),this.age>300){this.kill();return}if(this.vy-=22*t,this.vy=Math.max(this.vy,-30),this.vx*=1-Math.min(1,6*t),this.vz*=1-Math.min(1,6*t),Ta(this.world,this,t),this.pickupDelay<=0&&!e.dead){const i=e.x-this.x,r=e.y+.9-this.y,o=e.z-this.z,a=i*i+r*r+o*o;if(a<1.1){const c=e.give(this.id,this.count);if(c===0){this.kill(),this.pickedUp=!0;return}this.count=c}else if(a<6.5){const c=Math.sqrt(a),l=5.5/Math.max(.4,c);this.vx+=i/c*l*t*10,this.vy+=r/c*l*t*10,this.vz+=o/c*l*t*10}}this.spin+=t*1.8;const n=Math.sin(this.age*2.2)*.045;this.mesh.position.set(this.x,this.y+.18+n,this.z),this.mesh.rotation.y=this.spin}kill(){this.dead=!0,this.scene.remove(this.mesh),this.mesh.material.dispose()}}class jg{constructor(t,e){this.scene=t,this.world=e,this.drops=[],this.mobs=[],this.onPickup=null}spawnDrops(t,e,n,i){for(const r of i){if(!r||r.count<=0)continue;const o=Math.random()*Math.PI*2,a=.6+Math.random()*.8;this.drops.push(new Zg(this.scene,this.world,r.id,r.count,t,e,n,Math.cos(o)*a,2.2+Math.random(),Math.sin(o)*a))}}addMob(t){this.mobs.push(t)}update(t,e){for(const n of this.drops)n.update(t,e),n.pickedUp&&this.onPickup?.();this.drops=this.drops.filter(n=>!n.dead);for(const n of this.mobs)n.update(t,e);this.mobs=this.mobs.filter(n=>!n.dead)}mobsNear(t,e,n,i){const r=[];for(const o of this.mobs){const a=o.x-t,c=o.y-e,l=o.z-n;a*a+c*c+l*l<i*i&&r.push(o)}return r}dispose(){for(const t of this.drops)t.kill();for(const t of this.mobs)t.kill?.();this.drops=[],this.mobs=[]}}class Jg{constructor(t,e){this.atlas=t,this.player=e,this.root=document.getElementById("hud"),this.hotbarEl=document.getElementById("hotbar"),this.healthEl=document.getElementById("health-bar"),this.hungerEl=document.getElementById("hunger-bar"),this.airEl=document.getElementById("air-bar"),this.labelEl=document.getElementById("held-item-label"),this.debugEl=document.getElementById("debug-overlay"),this._labelTimer=null,this._lastSelected=-1,this.slots=[],this.hotbarEl.innerHTML="";for(let n=0;n<9;n++){const i=document.createElement("div");i.className="slot",this.hotbarEl.appendChild(i),this.slots.push(i)}e.events.addEventListener("inventory",()=>this.renderHotbar()),this.renderHotbar(),this.renderStats()}show(){this.root.classList.remove("hidden")}hide(){this.root.classList.add("hidden")}renderHotbar(){const t=this.player;for(let e=0;e<9;e++){const n=this.slots[e],i=t.inventory[e];if(n.classList.toggle("selected",e===t.selected),n.innerHTML="",i){const r=document.createElement("img");if(r.src=this.atlas.icon(i.id),r.draggable=!1,n.appendChild(r),i.count>1){const o=document.createElement("span");o.className="count",o.textContent=i.count,n.appendChild(o)}if(i.dur!==void 0){const o=Ue(i.id);if(o?.tool&&i.dur<o.tool.durability){const a=document.createElement("div");a.className="durability";const c=document.createElement("div"),l=i.dur/o.tool.durability;c.style.width=`${Math.round(l*100)}%`,c.style.background=l>.5?"#4caf50":l>.2?"#ffb300":"#e53935",a.appendChild(c),n.appendChild(a)}}}}t.selected!==this._lastSelected&&(this._lastSelected=t.selected,this.showLabel())}showLabel(){const t=this.player.heldStack();this.labelEl.textContent=t?Ue(t.id)?.display??"":"",this.labelEl.style.opacity="1",clearTimeout(this._labelTimer),this._labelTimer=setTimeout(()=>{this.labelEl.style.opacity="0"},1600)}renderStats(){const t=this.player,e=t.mode===Ke;if(this.healthEl.innerHTML="",this.hungerEl.innerHTML="",this.airEl.innerHTML="",!e){for(let n=0;n<10;n++){const i=document.createElement("span");i.className="stat-icon";const r=t.health-n*2;i.textContent="❤",i.style.color=r>=2?"#e53935":r>=1?"#ef9a9a":"#3a3a3a",this.healthEl.appendChild(i)}for(let n=9;n>=0;n--){const i=document.createElement("span");i.className="stat-icon";const r=t.hunger-n*2;i.textContent="🍗",i.style.filter=r>=2?"none":r>=1?"grayscale(50%) brightness(0.9)":"grayscale(100%) brightness(0.5)",this.airEl.style.marginBottom="0",this.hungerEl.appendChild(i)}if(t.air<20)for(let n=9;n>=0;n--){const i=document.createElement("span");i.className="stat-icon",i.textContent="🫧",i.style.visibility=t.air-n*2>=1?"visible":"hidden",this.airEl.appendChild(i)}}}setDebug(t){this.debugEl.textContent=t}toggleDebug(){this.debugEl.classList.toggle("hidden")}}const Qg=new qt(7315432),t0=new qt(10274032),Xl=new qt(461592),ql=new qt(14715470);function e0(){const t=document.createElement("canvas");t.width=256,t.height=256;const e=t.getContext("2d"),n=vs(790741),i=32,r=256/i,o=new Uint8Array(i*i);for(let c=0;c<46;c++){const l=n()*i|0,h=n()*i|0,u=3+(n()*6|0),d=2+(n()*3|0);for(let f=0;f<u;f++)for(let g=0;g<d;g++)n()<.12||(o[(h+g)%i*i+(l+f)%i]=1)}e.clearRect(0,0,256,256),e.fillStyle="rgba(255,255,255,0.92)";for(let c=0;c<i;c++)for(let l=0;l<i;l++)o[c*i+l]&&e.fillRect(l*r,c*r,r,r);const a=new gr(t);return a.wrapS=a.wrapT=rr,a.magFilter=be,a}class n0{constructor(t,e){this.scene=t,this.uniforms=e,this.group=new pi,t.add(this.group);const n=l=>{const h=new gr(In(l));return h.magFilter=be,h.minFilter=be,new vi({map:h,transparent:!0,fog:!1,depthWrite:!1,side:an})};this.sun=new Ie(new jn(56,56),n("sun")),this.moon=new Ie(new jn(40,40),n("moon")),this.group.add(this.sun),this.group.add(this.moon);const i=vs(5742885),r=700,o=new Float32Array(r*3);for(let l=0;l<r;l++){let h=i()*2-1,u=i(),d=i()*2-1;const f=Math.hypot(h,u,d)||1;o[l*3]=h/f*460,o[l*3+1]=u/f*460,o[l*3+2]=d/f*460}const a=new un;a.setAttribute("position",new Fe(o,3)),this.starMat=new vc({color:16777215,size:1.6,sizeAttenuation:!1,transparent:!0,opacity:0,fog:!1}),this.stars=new vu(a,this.starMat),this.group.add(this.stars),this.cloudTex=e0();const c=new vi({map:this.cloudTex,transparent:!0,opacity:.85,depthWrite:!1,side:an,fog:!1});this.clouds=new Ie(new jn(1400,1400),c),this.clouds.rotation.x=-Math.PI/2,this.clouds.position.y=108,this.cloudTex.repeat.set(3,3),t.add(this.clouds),this._bg=new qt,this._fog=new qt}update(t,e,n,i){const r=t*Math.PI*2,o=420;this.group.position.set(n.x,n.y,n.z);const a=Math.cos(r)*o,c=Math.sin(r)*o;this.sun.position.set(a,c,0),this.sun.lookAt(n.x,n.y,n.z),this.moon.position.set(-a,-c,0),this.moon.lookAt(n.x,n.y,n.z);const l=1-Math.min(1,e*1.6);if(this.starMat.opacity=Math.max(0,l-.15),this.clouds.position.x=n.x,this.clouds.position.z=n.z,this.cloudTex.offset.set((n.x/466+performance.now()*45e-7)%1,n.z/466%1),this.clouds.material.opacity=.25+.6*e,!i){const h=Math.sin(r);this._bg.copy(Qg).lerp(Xl,1-Math.max(.04,Math.min(1,.5+h*2.2)));const u=Math.max(0,1-Math.abs(h)*5)*.55;this._bg.lerp(ql,u),this._fog.copy(t0).lerp(Xl,1-Math.max(.05,Math.min(1,.5+h*2.2))),this._fog.lerp(ql,u),this.scene.background=this._bg,this.uniforms.uFogColor.value.copy(this._fog)}}}const ba=[P.OAK_PLANKS,P.BIRCH_PLANKS,P.SPRUCE_PLANKS],Aa=[];function hn(s,t,e,n){Aa.push({type:"shaped",result:s,count:t,pattern:e,keys:n})}function Er(s,t,e){Aa.push({type:"shapeless",result:s,count:t,ingredients:e})}Er(P.OAK_PLANKS,4,[[P.OAK_LOG]]);Er(P.BIRCH_PLANKS,4,[[P.BIRCH_LOG]]);Er(P.SPRUCE_PLANKS,4,[[P.SPRUCE_LOG]]);hn(at.STICK,4,["X","X"],{X:ba});hn(P.CRAFTING_TABLE,1,["XX","XX"],{X:ba});hn(P.FURNACE,1,["XXX","X.X","XXX"],{X:[P.COBBLESTONE]});hn(P.TORCH,4,["C","S"],{C:[at.COAL],S:[at.STICK]});const i0=[[ba,at.WOOD_PICKAXE,at.WOOD_AXE,at.WOOD_SHOVEL,at.WOOD_SWORD],[[P.COBBLESTONE],at.STONE_PICKAXE,at.STONE_AXE,at.STONE_SHOVEL,at.STONE_SWORD],[[at.IRON_INGOT],at.IRON_PICKAXE,at.IRON_AXE,at.IRON_SHOVEL,at.IRON_SWORD],[[at.GOLD_INGOT],at.GOLD_PICKAXE,at.GOLD_AXE,at.GOLD_SHOVEL,at.GOLD_SWORD],[[at.DIAMOND],at.DIAMOND_PICKAXE,at.DIAMOND_AXE,at.DIAMOND_SHOVEL,at.DIAMOND_SWORD]];for(const[s,t,e,n,i]of i0){const r={X:s,S:[at.STICK]};hn(t,1,["XXX",".S.",".S."],r),hn(e,1,["XX","XS",".S"],r),hn(n,1,["X","S","S"],r),hn(i,1,["X","X","S"],r)}hn(P.STONE_BRICKS,4,["XX","XX"],{X:[P.STONE]});hn(P.SANDSTONE,1,["XX","XX"],{X:[P.SAND]});hn(P.BRICKS,1,["XX","XX"],{X:[at.BRICK_ITEM]});hn(P.GLOWSTONE,1,["XX","XX"],{X:[at.REDSTONE_DUST]});Er(P.MOSSY_COBBLE,1,[[P.COBBLESTONE],[P.TALL_GRASS]]);function Yl(s,t){return t.includes(s)}function s0(s,t,e){let n=t,i=e,r=-1,o=-1;const a=[];for(let h=0;h<e;h++)for(let u=0;u<t;u++){const d=s[h*t+u];d&&(n=Math.min(n,u),r=Math.max(r,u),i=Math.min(i,h),o=Math.max(o,h),a.push(d))}if(r<0)return null;const c=r-n+1,l=o-i+1;t:for(const h of Aa){if(h.type==="shapeless"){if(a.length!==h.ingredients.length)continue;const g=[...h.ingredients];for(const _ of a){const m=g.findIndex(p=>Yl(_,p));if(m===-1)continue t;g.splice(m,1)}return{id:h.result,count:h.count}}const u=h.pattern,d=u[0].length,f=u.length;if(!(d!==c||f!==l))for(const g of[!1,!0]){let _=!0;for(let m=0;m<f&&_;m++)for(let p=0;p<d&&_;p++){const T=u[m][g?d-1-p:p],b=s[(i+m)*t+(n+p)];if(T===".")b&&(_=!1);else{const E=h.keys[T];(!b||!E||!Yl(b,E))&&(_=!1)}}if(_)return{id:h.result,count:h.count}}}return null}const ra=new Map([[P.IRON_ORE,{id:at.IRON_INGOT,count:1}],[P.GOLD_ORE,{id:at.GOLD_INGOT,count:1}],[P.SAND,{id:P.GLASS,count:1}],[P.COBBLESTONE,{id:P.STONE,count:1}],[at.CLAY_BALL,{id:at.BRICK_ITEM,count:1}],[at.PORKCHOP_RAW,{id:at.PORKCHOP_COOKED,count:1}],[at.MUTTON_RAW,{id:at.MUTTON_COOKED,count:1}]]),zc=10;function Kl(s,t,e,n){let i=s.blockEntityAt(t,e,n);return i||(i={kind:"furnace",input:null,fuel:null,output:null,burnLeft:0,burnTotal:0,cook:0},s.setBlockEntity(t,e,n,i)),i}function r0(s){if(!s.input)return null;const t=ra.get(s.input.id);return!t||s.output&&(s.output.id!==t.id||s.output.count+t.count>xn(t.id))?null:t}function o0(s,t){let e=!1;const n=[];for(const i of s.chunks.values())if(i.blockEntities.size)for(const[r,o]of[...i.blockEntities]){if(o.kind!=="furnace")continue;const a=r%ie,c=(r-a)/ie,l=c%16,h=(c-l)/16,u=i.cx*16+h,d=i.cz*16+l,f=r0(o);if(o.burnLeft<=0&&f&&o.fuel){const m=Ue(o.fuel.id)?.burnTime??0;m>0&&(o.burnLeft=m,o.burnTotal=m,o.fuel.count--,o.fuel.count<=0&&(o.fuel=null),e=!0)}const g=o.burnLeft>0;g?(o.burnLeft=Math.max(0,o.burnLeft-t),f?(o.cook+=t,o.cook>=zc&&(o.cook=0,o.input.count--,o.input.count<=0&&(o.input=null),o.output?o.output.count+=f.count:o.output={id:f.id,count:f.count},e=!0)):o.cook=0,e=e||!0):o.cook>0&&(o.cook=Math.max(0,o.cook-t*2),e=!0);const _=s.getBlockW(u,a,d);g&&_===P.FURNACE?n.push([u,a,d,P.FURNACE_LIT,o]):!g&&_===P.FURNACE_LIT&&n.push([u,a,d,P.FURNACE,o])}for(const[i,r,o,a,c]of n){const l=s.getMetaW(i,r,o);s.setBlock(i,r,o,a,l),s.setBlockEntity(i,r,o,c)}return e}class a0{constructor(t){this.game=t,this.atlas=t.atlas,this.player=t.player,this.root=document.getElementById("ui-root"),this.open=null,this.cursor=null,this.craftGrid=new Array(9).fill(null),this.craftSize=2,this.furnacePos=null,this.cursorEl=document.createElement("div"),this.cursorEl.id="cursor-stack",document.body.appendChild(this.cursorEl),this.tooltipEl=document.createElement("div"),this.tooltipEl.className="tooltip hidden",document.body.appendChild(this.tooltipEl),document.addEventListener("mousemove",e=>{this.cursorEl.style.left=`${e.clientX-18}px`,this.cursorEl.style.top=`${e.clientY-18}px`,this.tooltipEl.style.left=`${e.clientX+14}px`,this.tooltipEl.style.top=`${e.clientY+10}px`})}isOpen(){return this.open!==null}openInventory(){this.player.mode===Ke?this.craftSize=0:this.craftSize=2,this.open="inventory",this.show()}openCrafting(){this.craftSize=3,this.open="crafting",this.show()}openFurnace(t){this.furnacePos={x:t.x,y:t.y,z:t.z},this.open="furnace",this.show()}close(){if(this.open){for(let t=0;t<this.craftGrid.length;t++){const e=this.craftGrid[t];if(e){const n=this.player.give(e.id,e.count);n>0&&this.dropStack({...e,count:n}),this.craftGrid[t]=null}}if(this.cursor){const t=this.player.give(this.cursor.id,this.cursor.count);t>0&&this.dropStack({...this.cursor,count:t}),this.cursor=null}this.open=null,this.furnacePos=null,this.root.innerHTML="",this.renderCursor(),this.tooltipEl.classList.add("hidden"),this.game.setUiOpen(!1),this.game.hud.renderHotbar(),this.game.input.requestLock()}}dropStack(t){const e=this.player,n=e.lookDir();this.game.entities.spawnDrops(e.x+n.x,e.eyeY-.2,e.z+n.z,[t])}show(){this.game.setUiOpen(!0),this.render()}render(){this.root.innerHTML="";const t=document.createElement("div");t.className="screen dim",t.addEventListener("mousedown",n=>{n.target===t&&this.cursor&&(this.dropStack(this.cursor),this.cursor=null,this.renderCursor(),this.render())});const e=document.createElement("div");e.className="inv-window",t.appendChild(e),this.root.appendChild(t),this.open==="inventory"&&this.player.mode===Ke?this.renderCreative(e):this.open==="inventory"?this.renderCraftArea(e,2,"Crafting"):this.open==="crafting"?this.renderCraftArea(e,3,"Crafting Table"):this.open==="furnace"&&this.renderFurnace(e),this.renderPlayerInv(e),this.renderCursor()}slotEl(t,e=null){const n=document.createElement("div");n.className="slot";const i=t.get();if(i){const r=document.createElement("img");if(r.src=this.atlas.icon(i.id),r.draggable=!1,n.appendChild(r),i.count>1){const o=document.createElement("span");o.className="count",o.textContent=i.count,n.appendChild(o)}if(i.dur!==void 0){const o=Ue(i.id);if(o?.tool&&i.dur<o.tool.durability){const a=document.createElement("div");a.className="durability";const c=document.createElement("div");c.style.width=`${Math.round(i.dur/o.tool.durability*100)}%`,a.appendChild(c),n.appendChild(a)}}n.addEventListener("mouseenter",()=>{const o=t.get();o&&(this.tooltipEl.textContent=Ue(o.id)?.display??"?",this.tooltipEl.classList.remove("hidden"))}),n.addEventListener("mouseleave",()=>this.tooltipEl.classList.add("hidden"))}return n.addEventListener("mousedown",r=>{r.preventDefault(),r.stopPropagation(),this.clickSlot(t,r.button,r.shiftKey)}),n}renderPlayerInv(t){const e=document.createElement("h3");e.textContent="Inventory",t.appendChild(e);const n=document.createElement("div");n.className="inv-grid cols-9";for(let r=9;r<36;r++)n.appendChild(this.slotEl(this.invRef(r)));t.appendChild(n);const i=document.createElement("div");i.className="inv-grid cols-9",i.style.marginTop="8px";for(let r=0;r<9;r++)i.appendChild(this.slotEl(this.invRef(r)));t.appendChild(i)}renderCraftArea(t,e,n){const i=document.createElement("h3");i.textContent=n,t.appendChild(i);const r=document.createElement("div");r.className="row",r.style.marginBottom="12px";const o=document.createElement("div");o.className=`inv-grid cols-${e}`;for(let c=0;c<e*e;c++)o.appendChild(this.slotEl(this.craftRef(c)));r.appendChild(o);const a=document.createElement("div");a.className="arrow",a.textContent="➜",r.appendChild(a),r.appendChild(this.slotEl(this.craftResultRef())),t.appendChild(r)}renderFurnace(t){const e=Kl(this.game.world,this.furnacePos.x,this.furnacePos.y,this.furnacePos.z),n=document.createElement("h3");n.textContent="Furnace",t.appendChild(n);const i=document.createElement("div");i.className="row",i.style.marginBottom="12px";const r=document.createElement("div");r.style.display="flex",r.style.flexDirection="column",r.style.gap="4px",r.appendChild(this.slotEl(this.beRef(e,"input")));const o=document.createElement("div");o.className="furnace-flame",o.textContent=e.burnLeft>0?"🔥":"▫";const a=document.createElement("div");a.className="progress-track";const c=document.createElement("div");c.style.width=e.burnTotal>0?`${Math.round(e.burnLeft/e.burnTotal*100)}%`:"0%",a.appendChild(c),r.appendChild(o),r.appendChild(a),r.appendChild(this.slotEl(this.beRef(e,"fuel"))),i.appendChild(r);const l=document.createElement("div");l.style.display="flex",l.style.flexDirection="column",l.style.alignItems="center";const h=document.createElement("div");h.className="arrow",h.textContent="➜";const u=document.createElement("div");u.className="progress-track";const d=document.createElement("div");d.style.width=`${Math.round(e.cook/zc*100)}%`,u.appendChild(d),l.appendChild(h),l.appendChild(u),i.appendChild(l),i.appendChild(this.slotEl(this.beRef(e,"output"))),t.appendChild(i)}renderCreative(t){const e=document.createElement("h3");e.textContent="Creative — click to grab a stack",t.appendChild(e);const n=document.createElement("div");n.className="inv-grid cols-9",n.style.maxHeight="260px",n.style.overflowY="auto",n.style.marginBottom="12px";const i=[];for(const r of Re)r&&r.id!==0&&r.name!=="furnace_lit"&&r.name!=="water"&&i.push(r.id);for(const r of Object.values(at))i.push(r);for(const r of i){const o={get:()=>({id:r,count:1}),set:()=>{},creative:r};n.appendChild(this.slotEl(o))}t.appendChild(n)}renderCursor(){if(this.cursorEl.innerHTML="",this.cursor){this.cursorEl.style.display="block";const t=document.createElement("img");if(t.src=this.atlas.icon(this.cursor.id),this.cursorEl.appendChild(t),this.cursor.count>1){const e=document.createElement("span");e.className="count",e.textContent=this.cursor.count,this.cursorEl.appendChild(e)}}else this.cursorEl.style.display="none"}invRef(t){return{get:()=>this.player.inventory[t],set:e=>{this.player.inventory[t]=e},area:"inv",index:t}}craftRef(t){return{get:()=>this.craftGrid[t],set:e=>{this.craftGrid[t]=e},area:"craft"}}craftResultRef(){return{get:()=>{const t=this.craftSize,e=[];for(let i=0;i<t*t;i++)e.push(this.craftGrid[i]?.id??0);const n=s0(e,t,t);return n?jo(n.id,n.count):null},set:()=>{},output:"craft"}}beRef(t,e){return{get:()=>t[e],set:n=>{t[e]=n},area:"furnace",output:e==="output"?"furnace":void 0,filter:e==="fuel"?n=>(Ue(n)?.burnTime??0)>0:e==="input"?n=>ra.has(n):void 0}}clickSlot(t,e,n){if(t.creative!==void 0){this.cursor?this.cursor=null:this.cursor=jo(t.creative,e===2?1:xn(t.creative)),this.renderCursor(),this.render();return}if(t.output){this.takeOutput(t,n),this.afterChange();return}const i=this.cursor,r=t.get();if(n&&!i&&r){this.quickMove(t,r),this.afterChange();return}if(e===0){if(!i&&r)t.set(null),this.cursor=r;else if(i&&!r){if(t.filter&&!t.filter(i.id))return;t.set(i),this.cursor=null}else if(i&&r)if(i.id===r.id&&i.dur===void 0&&r.dur===void 0){const o=xn(i.id)-r.count,a=Math.min(o,i.count);r.count+=a,i.count-=a,i.count<=0&&(this.cursor=null)}else{if(t.filter&&!t.filter(i.id))return;t.set(i),this.cursor=r}}else if(e===2){if(i){if(t.filter&&!t.filter(i.id))return;r?r.id===i.id&&r.dur===void 0&&r.count<xn(i.id)&&(r.count++,i.count--,i.count<=0&&(this.cursor=null)):(t.set({...i,count:1}),i.count--,i.count<=0&&(this.cursor=null))}else if(r){const o=Math.ceil(r.count/2),a=r.count-o;this.cursor={...r,count:o},a>0?t.set({...r,count:a}):t.set(null)}}this.afterChange()}takeOutput(t,e){const n=()=>{const i=t.get();if(!i)return!1;if(t.output==="craft"){if(this.cursor){if(this.cursor.id!==i.id||this.cursor.dur!==void 0||this.cursor.count+i.count>xn(i.id))return!1;this.cursor.count+=i.count}else this.cursor=i;for(let r=0;r<this.craftGrid.length;r++){const o=this.craftGrid[r];o&&(o.count--,o.count<=0&&(this.craftGrid[r]=null))}return!0}if(this.cursor){if(this.cursor.id!==i.id||this.cursor.count+i.count>xn(i.id))return!1;this.cursor.count+=i.count}else this.cursor=i;return t.set(null),!0};if(e){let i=0;for(;i++<64;){const r=t.get();if(!r||this.player.give(r.id,r.count)>0)break;if(t.output==="craft")for(let a=0;a<this.craftGrid.length;a++){const c=this.craftGrid[a];c&&(c.count--,c.count<=0&&(this.craftGrid[a]=null))}else t.set(null)}}else n();this.game.sfx?.play("click")}quickMove(t,e){if(t.area==="inv"){if(this.open==="furnace"){const r=Kl(this.game.world,this.furnacePos.x,this.furnacePos.y,this.furnacePos.z),o=ra.has(e.id)?"input":(Ue(e.id)?.burnTime??0)>0?"fuel":null;if(o){const a=r[o];if(!a){r[o]=e,t.set(null);return}if(a.id===e.id){const c=xn(a.id)-a.count,l=Math.min(c,e.count);a.count+=l,e.count-=l,e.count<=0&&t.set(null);return}}}const i=t.index<9?[9,36]:[0,9];this.moveIntoRange(t,e,i)}else{const n=this.player.give(e.id,e.count);t.set(n>0?{...e,count:n}:null)}}moveIntoRange(t,e,[n,i]){for(let r=n;r<i&&e.count>0;r++){const o=this.player.inventory[r];if(o&&o.id===e.id&&o.dur===void 0&&e.dur===void 0){const a=xn(o.id)-o.count,c=Math.min(a,e.count);o.count+=c,e.count-=c}}for(let r=n;r<i&&e.count>0;r++)this.player.inventory[r]||(this.player.inventory[r]={...e},e.count=0);t.set(e.count>0?e:null)}afterChange(){this.player.events.dispatchEvent(new CustomEvent("inventory")),this.renderCursor(),this.render()}refreshIfFurnace(){this.open==="furnace"&&this.render()}}const l0={px:.72,nx:.72,py:1,ny:.45,pz:.86,nz:.6};function c0(s,t,e){const n=new zn(s,t,e),i=new Float32Array(n.attributes.position.count*3),r=["px","nx","py","ny","pz","nz"];for(let o=0;o<6;o++){const a=l0[r[o]];for(let c=0;c<4;c++){const l=(o*4+c)*3;i[l]=a,i[l+1]=a,i[l+2]=a}}return n.setAttribute("color",new Fe(i,3)),n}class wa{constructor(t,e,n,i,r){this.scene=t,this.world=e,this.x=n,this.y=i,this.z=r,this.vx=0,this.vy=0,this.vz=0,this.w=.7,this.h=1,this.yaw=Math.random()*Math.PI*2,this.health=10,this.dead=!1,this.onGround=!1,this.hurtCooldown=0,this.flashTime=0,this.age=0,this.walkPhase=0,this.moving=!1,this.state="idle",this.stateTime=1+Math.random()*3,this.targetYaw=this.yaw,this.speed=1.6,this.fleeSpeed=3.4,this.hostile=!1,this.group=new pi,this.materials=[],this.buildModel(),t.add(this.group)}buildModel(){}part(t,e,n,i,r,o,a){const c=new vi({color:i,vertexColors:!0}),l=new Ie(c0(t,e,n),c);return l.position.set(r,o,a),this.materials.push({mat:c,base:new qt(i)}),this.group.add(l),l}update(t,e){if(this.dead)return;this.age+=t,this.hurtCooldown=Math.max(0,this.hurtCooldown-t),this.flashTime=Math.max(0,this.flashTime-t);const n=this.x-e.x,i=this.z-e.z,r=n*n+i*i;if(r>6400){this.kill();return}if(!this.world.isLoaded(Math.floor(this.x),Math.floor(this.z)))return;this.think(t,e,Math.sqrt(r));let o=(this.targetYaw-this.yaw+Math.PI*3)%(Math.PI*2)-Math.PI;this.yaw+=Math.max(-3*t,Math.min(3*t,o));const a=kc(this.world,this,P.WATER),c=this.state==="flee"||this.state==="chase"?this.fleeSpeed:this.speed;let l=0,h=0;this.moving&&(l=-Math.sin(this.yaw)*c,h=-Math.cos(this.yaw)*c);const u=this.onGround?18:5;this.vx+=(l-this.vx)*Math.min(1,u*t),this.vz+=(h-this.vz)*Math.min(1,u*t),a?this.vy+=(1.6-this.vy)*Math.min(1,3*t):(this.vy-=26*t,this.vy=Math.max(this.vy,-40)),this.y;const d=Ta(this.world,this,t);if(this.onGround=d.onGround,d.hitWall&&this.onGround&&this.moving&&!a&&(this.vy=7.2),!this.onGround&&this.vy<0&&!a)this.fallStart=Math.max(this.fallStart??this.y,this.y);else if((this.onGround||a)&&this.fallStart!==void 0){const p=this.fallStart-this.y;!a&&p>4&&this.damage(Math.floor(p-3),null),this.fallStart=void 0}this.moving&&(this.walkPhase+=t*c*3.2),this.animate(t),this.group.position.set(this.x,this.y,this.z),this.group.rotation.y=this.yaw;const f=this.world.getSkyW(Math.floor(this.x),Math.floor(this.y+.5),Math.floor(this.z)),g=this.world.getBlockLightW(Math.floor(this.x),Math.floor(this.y+.5),Math.floor(this.z)),_=this.world.materials.uniforms.uDay.value,m=Math.max(.12,Math.max(f/15*_,g/15));for(const{mat:p,base:T}of this.materials)p.color.copy(T).multiplyScalar(m),this.flashTime>0&&p.color.lerp(new qt(16724787),.55)}think(t,e,n){this.stateTime-=t,this.state==="flee"?(this.moving=!0,this.stateTime<=0&&(this.state="idle",this.stateTime=1+Math.random()*2)):this.stateTime<=0&&(this.state==="idle"?(this.state="wander",this.stateTime=1.5+Math.random()*3,this.targetYaw=Math.random()*Math.PI*2,this.moving=!0):(this.state="idle",this.stateTime=1+Math.random()*4,this.moving=!1))}animate(t){const e=Math.sin(this.walkPhase)*(this.moving?.6:0);this.legs&&(this.legs[0].rotation.x=e,this.legs[1].rotation.x=-e,this.legs[2]&&(this.legs[2].rotation.x=-e),this.legs[3]&&(this.legs[3].rotation.x=e))}damage(t,e){if(this.dead||this.hurtCooldown>0)return!1;if(this.hurtCooldown=.45,this.health-=t,this.flashTime=.25,e){const n=this.x-e.x,i=this.z-e.z,r=Math.hypot(n,i)||1;this.vx+=n/r*6,this.vz+=i/r*6,this.vy=Math.max(this.vy,4.5),this.hostile||(this.state="flee",this.stateTime=4,this.targetYaw=Math.atan2(-n,-i)+Math.PI,this.moving=!0)}return this.health<=0&&this.die(),!0}die(){this.onDeath?.(),this.kill()}kill(){this.dead=!0,this.scene.remove(this.group);for(const{mat:t}of this.materials)t.dispose()}rayHit(t,e,n){const i=this.w/2,r={x:this.x-i,y:this.y,z:this.z-i},o={x:this.x+i,y:this.y+this.h,z:this.z+i};let a=0,c=n;for(const l of["x","y","z"]){const h=t[l],u=e[l];if(Math.abs(u)<1e-9){if(h<r[l]||h>o[l])return null}else{let d=(r[l]-h)/u,f=(o[l]-h)/u;if(d>f&&([d,f]=[f,d]),a=Math.max(a,d),c=Math.min(c,f),a>c)return null}}return a}}class h0 extends wa{constructor(t,e,n,i,r){super(t,e,n,i,r),this.w=.8,this.h=.9,this.health=10,this.kind="pig"}buildModel(){this.part(.9,.55,.6,15704736,0,.55,0);const i=this.part(.45,.45,.45,15704736,0,.72,-.55);this.part(.2,.14,.08,14649478,0,.66,-.8),this.part(.07,.07,.02,2763306,-.12,.82,-.78),this.part(.07,.07,.02,2763306,.12,.82,-.78),this.legs=[this.legPart(14256262,-.25,-.22),this.legPart(14256262,.25,-.22),this.legPart(14256262,-.25,.22),this.legPart(14256262,.25,.22)],this.head=i}legPart(t,e,n){const i=this.part(.18,.32,.18,t,e,.32,n);return i.geometry=i.geometry.clone(),i.geometry.translate(0,-.16,0),i.position.y=.32,i}onDeath(){this.dropFn?.([{id:at.PORKCHOP_RAW,count:1+(Math.random()*2|0)}])}}class u0 extends wa{constructor(t,e,n,i,r){super(t,e,n,i,r),this.w=.9,this.h=1.1,this.health=8,this.speed=1.3,this.kind="sheep"}buildModel(){this.part(1,.7,.65,15263456,0,.75,0),this.part(.42,.4,.4,13610644,0,1,-.6),this.part(.46,.28,.2,15263456,0,1.14,-.52),this.part(.07,.07,.02,2763306,-.11,1.06,-.81),this.part(.07,.07,.02,2763306,.11,1.06,-.81),this.legs=[this.legPart(12558472,-.28,-.22),this.legPart(12558472,.28,-.22),this.legPart(12558472,-.28,.22),this.legPart(12558472,.28,.22)]}legPart(t,e,n){const i=this.part(.16,.45,.16,t,e,.45,n);return i.geometry=i.geometry.clone(),i.geometry.translate(0,-.22,0),i.position.y=.45,i}onDeath(){this.dropFn?.([{id:P.WOOL,count:1},{id:at.MUTTON_RAW,count:1+(Math.random()*2|0)}])}}class d0 extends wa{constructor(t,e,n,i,r){super(t,e,n,i,r),this.w=.6,this.h=1.9,this.health=20,this.hostile=!0,this.speed=1.2,this.fleeSpeed=2.9,this.attackCooldown=0,this.burnTimer=0,this.kind="zombie"}buildModel(){this.part(.5,.72,.3,3828362,0,1.12,0),this.part(.42,.42,.42,5938256,0,1.72,0),this.part(.08,.08,.02,1710618,-.1,1.78,-.22),this.part(.08,.08,.02,1710618,.1,1.78,-.22),this.part(.16,.16,.6,5938256,-.34,1.36,-.24),this.part(.16,.16,.6,5938256,.34,1.36,-.24),this.legs=[this.legPart(3493995,-.14),this.legPart(3493995,.14)]}legPart(t,e){const n=this.part(.2,.76,.24,t,e,.76,0);return n.geometry=n.geometry.clone(),n.geometry.translate(0,-.38,0),n.position.y=.76,n}think(t,e,n){this.attackCooldown=Math.max(0,this.attackCooldown-t);const i=this.world.materials.uniforms.uDay.value,r=this.world.getSkyW(Math.floor(this.x),Math.floor(this.y+1.5),Math.floor(this.z));if(!(i>.8&&r>=14&&(this.burnTimer+=t,this.flashTime=.1,this.burnTimer>1&&(this.burnTimer=0,this.hurtCooldown=0,this.damage(2,null),this.dead))))if(!e.dead&&n<18){this.state="chase",this.moving=!0;const o=e.x-this.x,a=e.z-this.z;this.targetYaw=Math.atan2(-o,-a),n<1.4&&this.attackCooldown<=0&&Math.abs(e.y+.9-(this.y+1))<1.6&&(e.damage(3,"zombie"),this.attackCooldown=1.1)}else this.state==="chase"?(this.state="idle",this.stateTime=1,this.moving=!1):super.think(t,e,n)}onDeath(){this.dropFn?.([{id:at.ROTTEN_FLESH,count:1+(Math.random()*2|0)}])}}const f0=10,p0=8;class m0{constructor(t,e,n){this.scene=t,this.world=e,this.entities=n,this.timer=0}update(t,e,n){if(this.timer+=t,this.timer<2)return;this.timer=0;const i=this.entities.mobs,r=i.filter(a=>!a.hostile).length,o=i.filter(a=>a.hostile).length;r<f0&&this.trySpawn(e,!1,n),o<p0&&n<.4&&this.trySpawn(e,!0,n)}trySpawn(t,e,n){for(let i=0;i<6;i++){const r=Math.random()*Math.PI*2,o=24+Math.random()*24,a=Math.floor(t.x+Math.cos(r)*o),c=Math.floor(t.z+Math.sin(r)*o);if(!this.world.isLoaded(a,c))continue;const l=this.world.surfaceHeight(a,c)+1;if(l<=1||l>120)continue;const h=this.world.getBlockW(a,l-1,c);if(!Ea(h)||h===P.WATER||this.world.getBlockW(a,l,c)!==P.AIR||this.world.getBlockW(a,l+1,c)!==P.AIR)continue;if(e){const d=this.world.getSkyW(a,l,c),f=this.world.getBlockLightW(a,l,c);if(Math.max(d/15*n*15,f)>7)continue;this.spawnMob(d0,a+.5,l,c+.5);return}const u=this.world.biomeAt(a,c);if([Ht.PLAINS,Ht.FOREST,Ht.BIRCH_FOREST,Ht.SWAMP,Ht.MOUNTAINS].includes(u)&&!(h!==P.GRASS&&h!==P.SNOWY_GRASS&&h!==P.DIRT)){this.spawnMob(Math.random()<.5?h0:u0,a+.5,l,c+.5);return}}}spawnMob(t,e,n,i){const r=new t(this.scene,this.world,e,n,i);return r.dropFn=o=>this.entities.spawnDrops(r.x,r.y+.4,r.z,o),this.entities.addMob(r),r}}const Ra=new Map;for(const s of Re)s&&s.id!==0&&Ra.set(s.name,s.id);for(const s of Object.values(at)){const t=Ue(s);t&&Ra.set(t.name,s)}class g0{constructor(t){this.game=t,this.logEl=document.getElementById("chat-log"),this.rowEl=document.getElementById("chat-input-row"),this.inputEl=document.getElementById("chat-input"),this.open=!1,this.inputEl.addEventListener("keydown",e=>{if(e.stopPropagation(),e.key==="Enter"){const n=this.inputEl.value.trim();this.hide(),n&&this.submit(n)}else e.key==="Escape"&&this.hide()})}show(t=""){this.open=!0,this.rowEl.classList.remove("hidden"),this.inputEl.value=t,this.game.setUiOpen(!0),setTimeout(()=>this.inputEl.focus(),0)}hide(){this.open=!1,this.rowEl.classList.add("hidden"),this.inputEl.value="",this.inputEl.blur(),this.game.setUiOpen(!1),this.game.input.requestLock()}message(t,e="#fff"){const n=document.createElement("div");for(n.className="msg",n.textContent=t,n.style.color=e,this.logEl.appendChild(n);this.logEl.children.length>12;)this.logEl.firstChild.remove();setTimeout(()=>{n.style.opacity="0"},8e3),setTimeout(()=>{n.remove()},9500)}submit(t){if(!t.startsWith("/")){this.message(`<you> ${t}`);return}const[e,...n]=t.slice(1).split(/\s+/);try{this.run(e.toLowerCase(),n)}catch(i){this.message(`Error: ${i.message}`,"#ff8080")}}run(t,e){const n=this.game,i=n.player;switch(t){case"help":this.message("/tp <x> <y> <z> — teleport"),this.message("/time set <day|noon|night|midnight|0..1>"),this.message("/give <item> [count] — e.g. /give diamond_pickaxe"),this.message("/gamemode <survival|creative>"),this.message("/seed  /spawn  /kill  /clear  /rd <2-16>  /heal");break;case"tp":{if(e.length<3)throw new Error("usage: /tp x y z");const[r,o,a]=e.map(Number);if([r,o,a].some(Number.isNaN))throw new Error("coordinates must be numbers");i.x=r,i.y=o,i.z=a,i.vx=i.vy=i.vz=0,i.fallStart=null,this.message(`Teleported to ${r} ${o} ${a}`,"#9fdcff");break}case"time":{if(e[0]!=="set"||e.length<2)throw new Error("usage: /time set <value>");const o={day:.06,noon:.25,sunset:.5,night:.6,midnight:.75}[e[1]]??Number(e[1]);if(Number.isNaN(o))throw new Error("unknown time value");n.time=(o%1+1)%1,this.message(`Time set to ${n.time.toFixed(2)}`,"#9fdcff");break}case"give":{if(!e[0])throw new Error("usage: /give <item> [count]");const r=Ra.get(e[0].toLowerCase());if(!r)throw new Error(`unknown item "${e[0]}"`);const o=Math.max(1,Math.min(64,parseInt(e[1]??"1",10)||1)),a=i.give(r,o);n.hud.renderHotbar(),this.message(`Gave ${o-a}× ${Ue(r).display}`,"#9fdcff");break}case"gamemode":{const r=e[0]?.[0];if(r==="c"||e[0]==="1")i.mode=Ke;else if(r==="s"||e[0]==="0")i.mode=Bi,i.flying=!1;else throw new Error("usage: /gamemode <survival|creative>");n.hud.renderStats(),this.message(`Game mode: ${i.mode===Ke?"creative":"survival"}`,"#9fdcff");break}case"seed":this.message(`Seed: ${n.worldMeta.seed}`,"#9fdcff");break;case"spawn":i.x=i.spawnPoint.x,i.y=i.spawnPoint.y,i.z=i.spawnPoint.z,i.vx=i.vy=i.vz=0,i.fallStart=null,this.message("Returned to spawn","#9fdcff");break;case"kill":i.hurtCooldown=0,i.damage(1e3,"command");break;case"heal":i.health=i.maxHealth,i.hunger=20,i.air=20,n.hud.renderStats(),this.message("Healed","#9fdcff");break;case"clear":i.inventory.fill(null),i.events.dispatchEvent(new CustomEvent("inventory")),this.message("Inventory cleared","#9fdcff");break;case"rd":{const r=parseInt(e[0],10);if(!r||r<2||r>16)throw new Error("usage: /rd <2-16>");n.world.renderDistance=r,n.world.centerCx=1/0,this.message(`Render distance: ${r}`,"#9fdcff");break}default:throw new Error(`unknown command /${t} — try /help`)}}}class _0{constructor({canvas:t,atlas:e,worldMeta:n,store:i=null,sfx:r=null,onExit:o=null}){this.canvas=t,this.atlas=e,this.worldMeta=n,this.store=i,this.sfx=r,this.onExit=o,this.renderer=new ag({canvas:t,antialias:!1,powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,2)),this.renderer.setSize(window.innerWidth,window.innerHeight),this.scene=new du,this.scene.background=new qt(9420012),this.camera=new on(75,window.innerWidth/window.innerHeight,.08,800),this.world=new kg({seed:n.seed,atlas:e,renderDistance:n.renderDistance??8,loadChunk:i?(a,c)=>i.loadChunk(n.id,a,c):null,onChunkEvicted:i?a=>{i.saveChunk(n.id,a),a.modified=!1}:null}),this.scene.add(this.world.group),this.player=new Hg(this.world),this.player.mode=n.mode??Bi,this.entities=new jg(this.scene,this.world),this.entities.onPickup=()=>this.sfx?.play("pickup"),this.input=new Xg(t),this.highlight=new qg(this.scene),this.interaction=new Wg(this.world,this.player,{spawnDrops:(a,c,l,h)=>this.entities.spawnDrops(a,c,l,h),openUI:(a,c)=>{a==="crafting"?this.containers.openCrafting():a==="furnace"&&this.containers.openFurnace(c)},playSound:(a,c)=>this.sfx?.play(a,c)}),this.hud=new Jg(e,this.player),this.sky=new n0(this.scene,this.world.materials.uniforms),this.containers=new a0(this),this._furnaceUiTimer=0,this.mobSpawner=new m0(this.scene,this.world,this.entities),this.chat=new g0(this),this._stepDistance=0,t.addEventListener("mousedown",()=>this.sfx?.resume()),this.input.onMouseDown=a=>{if(a!==0||this.uiOpen||this.player.dead)return;const c={x:this.player.x,y:this.player.eyeY,z:this.player.z},l=this.player.lookDir();let h=null,u=1/0;for(const d of this.entities.mobs){const f=d.rayHit(c,l,Oc);f!==null&&f<u&&(h=d,u=f)}if(h&&(!this.interaction.target||u<this.interaction.target.dist)){const d=this.player.heldStack(),f=d?Ue(d.id)?.tool?.damage??1:1;h.damage(f,this.player)&&(this.sfx?.play("hit",{block:"cloth"}),this.player.damageHeldTool(1),this.player.addExhaustion(.1),this.interaction.breakCooldown=.3,this.interaction.resetBreaking())}},this.time=n.timeOfDay??.05,this.paused=!1,this.uiOpen=!1,this.uiHooks=null,this.running=!1,this.statTimer=0,this.autosaveTimer=0,this.fps=0,this._fpsFrames=0,this._fpsTime=0,this.player.events.addEventListener("hurt",()=>{this.sfx?.play("hurt"),this.hud.renderStats(),this.flashDamage()}),this.player.events.addEventListener("death",()=>{this.uiHooks?.showDeath?.()}),this._onResize=()=>{this.renderer.setSize(window.innerWidth,window.innerHeight),this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix()},window.addEventListener("resize",this._onResize),this.bindKeys(),this.setupSpawn(),this.ticker=new Worker(URL.createObjectURL(new Blob(["setInterval(() => postMessage(0), 50);"],{type:"text/javascript"}))),this.ticker.onmessage=()=>{document.hidden&&this.running&&this.loop()},this._onVisibility=()=>{!document.hidden&&this.running&&requestAnimationFrame(this._loopBound)},document.addEventListener("visibilitychange",this._onVisibility),this._loopBound=()=>this.loop()}setupSpawn(){const t=this.worldMeta.playerData;if(t){this.player.deserialize(t);return}const e=this.world.gen;let n=8,i=8;for(let o=0;o<40;o++){const a=8+o*13%160-80,c=8+o*29%160-80;if(e.heightAt(a,c)>Te+1){n=a,i=c;break}}const r=Math.floor(e.heightAt(n,i))+2;this.player.x=n+.5,this.player.y=r,this.player.z=i+.5,this.player.spawnPoint={x:n+.5,y:r+1,z:i+.5}}bindKeys(){this.input.onKeyDown=(t,e)=>{if(this.uiHooks?.handleKey?.(t,e))return!0;if(t==="KeyE"||t==="Escape"&&this.containers.isOpen())return this.containers.isOpen()?this.containers.close():t==="KeyE"&&!this.uiOpen&&!this.player.dead&&this.containers.openInventory(),!0;if(t==="Escape"&&!this.uiOpen&&!this.player.dead)return this.uiHooks?.showPause?.(),!0;if((t==="KeyT"||t==="Slash")&&!this.uiOpen&&!this.player.dead)return this.chat.show(t==="Slash"?"/":""),!0;if(this.uiOpen)return!1;if(t.startsWith("Digit")){const n=parseInt(t.slice(5),10);if(n>=1&&n<=9)return this.player.selected=n-1,this.hud.renderHotbar(),!0}switch(t){case"F3":return this.hud.toggleDebug(),!0;case"Space":return this.player.tapSpace(performance.now()),!1;case"KeyQ":{const n=this.player.heldStack();if(n){const i=this.player.lookDir();this.entities.spawnDrops(this.player.x+i.x,this.player.eyeY-.3,this.player.z+i.z,[{id:n.id,count:1}]),this.player.consumeHeld(1)}return!0}}return!1},this.input.onWheel=t=>{this.uiOpen||(this.player.selected=(this.player.selected+t+9)%9,this.hud.renderHotbar())},this.input.onLockLost=()=>{!this.uiOpen&&this.running&&this.uiHooks?.showPause?.()}}setUiOpen(t){this.uiOpen=t,this.input.captured=t,t&&this.input.releaseLock()}flashDamage(){this.canvas.style.transition="none",this.canvas.style.filter="sepia(0.4) hue-rotate(-30deg) saturate(2.5)",setTimeout(()=>{this.canvas.style.transition="filter 0.3s",this.canvas.style.filter="none"},90)}dayFactor(){const t=this.time%1,e=Math.sin(t*Math.PI*2);return Math.max(.03,Math.min(1,.5+e*2.2))}start(){this.running=!0,this.hud.show(),this.last=performance.now(),requestAnimationFrame(this._loopBound)}loop(){if(!this.running)return;document.hidden||requestAnimationFrame(this._loopBound);const t=performance.now(),e=Math.min(.1,(t-this.last)/1e3);this.last=t,this._fpsFrames++,this._fpsTime+=(t-(this._lastReal??t))/1e3,this._lastReal=t,this._fpsTime>=.5&&(this.fps=Math.round(this._fpsFrames/this._fpsTime),this._fpsFrames=0,this._fpsTime=0);const n=this.paused||this.uiOpen;this.time=(this.time+e/_g)%1;const i=this.dayFactor();this.world.materials.uniforms.uDay.value=i;const r=this.world.renderDistance*16;if(this.world.materials.uniforms.uFogNear.value=r*.6,this.world.materials.uniforms.uFogFar.value=r*.95,this.sky.update(this.time,i,this.player,this.player.headInWater),!n||document.hidden){const o=this.player.inWater,a=this.player.x,c=this.player.z;if(this.player.update(this.input,e,n),this.interaction.update(this.input,e,n),this.entities.update(e,this.player),this.mobSpawner.update(e,this.player,i),this.tickBlockEntities(e),this.player.onGround&&!this.player.flying&&(this._stepDistance+=Math.hypot(this.player.x-a,this.player.z-c),this._stepDistance>2.1)){this._stepDistance=0;const l=rn(this.world.getBlockW(Math.floor(this.player.x),Math.floor(this.player.y)-1,Math.floor(this.player.z)));l.id!==0&&this.sfx?.play("step",{block:l.sound})}!o&&this.player.inWater&&this.player.vy<-3&&this.sfx?.play("splash")}this.highlight.update(this.interaction.target,this.interaction.breakProgress),this.camera.position.set(this.player.x,this.player.eyeY,this.player.z),this.camera.rotation.set(0,0,0,"YXZ"),this.camera.rotateY(this.player.yaw),this.camera.rotateX(this.player.pitch),this.applyUnderwaterEffect(),this.world.update(this.player.x,this.player.z,t,document.hidden?8:1),this.renderer.render(this.scene,this.camera),this.statTimer+=e,this.statTimer>.25&&(this.statTimer=0,this.hud.renderStats(),this.updateDebug()),this.store&&(this.autosaveTimer+=e,this.autosaveTimer>20&&(this.autosaveTimer=0,this.save())),this.input.endFrame()}applyUnderwaterEffect(){const t=this.player.headInWater;if(t!==this._wasUnder){this._wasUnder=t;const e=this.world.materials.uniforms;t&&(this.scene.background=new qt(1724330),e.uFogColor.value.set(1724330),e.uFogNear.value=4,e.uFogFar.value=24),this._forceSkyRefresh=!0}if(t){const e=this.world.materials.uniforms;e.uFogNear.value=4,e.uFogFar.value=24}}tickBlockEntities(t){o0(this.world,t),this.containers.open==="furnace"&&(this._furnaceUiTimer+=t,this._furnaceUiTimer>.25&&(this._furnaceUiTimer=0,this.containers.refreshIfFurnace()))}updateDebug(){const t=this.player,e=this.world.biomeAt(Math.floor(t.x),Math.floor(t.z)),n=this.world.getSkyW(Math.floor(t.x),Math.floor(t.eyeY),Math.floor(t.z)),i=this.world.getBlockLightW(Math.floor(t.x),Math.floor(t.eyeY),Math.floor(t.z)),r=this.time%1,o=Math.floor((r+.25)%1*24).toString().padStart(2,"0"),a=Math.floor((r+.25)%1*24%1*60).toString().padStart(2,"0");this.hud.setDebug(`BlockVerse 1.0 | FPS ${this.fps}
XYZ ${t.x.toFixed(2)} / ${t.y.toFixed(2)} / ${t.z.toFixed(2)}
chunk ${Math.floor(t.x/16)},${Math.floor(t.z/16)}  biome ${Cg[e]??"?"}
light sky ${n} block ${i}  time ${o}:${a}
chunks ${this.world.stats.chunks} genQ ${this.world.stats.genQueue} dirty ${this.world.dirtyMeshes.size}
draws ${this.renderer.info.render.calls} tris ${(this.renderer.info.render.triangles/1e3).toFixed(0)}k mode ${t.mode===Ke?"creative":"survival"}${t.flying?" (fly)":""}`)}applySettings(t){this.world.renderDistance=t.renderDistance,this.world.centerCx=1/0,this.camera.fov=t.fov,this.camera.updateProjectionMatrix(),this.player.sensitivity=t.sensitivity,this.sfx?.setVolume(t.volume)}pause(){this.paused=!0,this.setUiOpen(!0)}resume(){this.paused=!1,this.setUiOpen(!1),this.input.requestLock()}save(){if(this.store){for(const t of this.world.modifiedChunks())this.store.saveChunk(this.worldMeta.id,t),t.modified=!1;this.store.saveWorldMeta(this.worldMeta.id,{timeOfDay:this.time,playerData:this.player.serialize()})}}stop(){this.running=!1,this.store&&this.save(),this.ticker.terminate(),document.removeEventListener("visibilitychange",this._onVisibility),window.removeEventListener("resize",this._onResize),this.entities.dispose(),this.world.dispose(),this.renderer.dispose()}}const v0="blockverse",x0=1;function Ln(s){return new Promise((t,e)=>{s.onsuccess=()=>t(s.result),s.onerror=()=>e(s.error)})}class Ca{static async open(){const t=new Ca,e=indexedDB.open(v0,x0);return e.onupgradeneeded=()=>{const n=e.result;n.objectStoreNames.contains("worlds")||n.createObjectStore("worlds",{keyPath:"id"}),n.objectStoreNames.contains("chunks")||n.createObjectStore("chunks")},t.db=await Ln(e),t}tx(t,e="readonly"){return this.db.transaction(t,e).objectStore(t)}async listWorlds(){return(await Ln(this.tx("worlds").getAll())).sort((e,n)=>(n.lastPlayed??0)-(e.lastPlayed??0))}async createWorld({name:t,seed:e,mode:n,renderDistance:i}){const r={id:`w${Date.now().toString(36)}${Math.floor(Math.random()*1e6).toString(36)}`,name:t,seed:e,mode:n,renderDistance:i,created:Date.now(),lastPlayed:Date.now(),timeOfDay:.05,playerData:null,version:1};return await Ln(this.tx("worlds","readwrite").put(r)),r}async loadWorld(t){return Ln(this.tx("worlds").get(t))}async saveWorldMeta(t,e){const n=await this.loadWorld(t);n&&(Object.assign(n,e,{lastPlayed:Date.now()}),await Ln(this.tx("worlds","readwrite").put(n)))}async deleteWorld(t){await Ln(this.tx("worlds","readwrite").delete(t));const e=IDBKeyRange.bound(`${t}:`,`${t}:￿`);await Ln(this.tx("chunks","readwrite").delete(e))}chunkKey(t,e,n){return`${t}:${e},${n}`}async saveChunk(t,e){const n={blocks:e.blocks,meta:e.meta??null,blockEntities:[...e.blockEntities.entries()]};await Ln(this.tx("chunks","readwrite").put(n,this.chunkKey(t,e.cx,e.cz)))}async loadChunk(t,e,n){const i=await Ln(this.tx("chunks").get(this.chunkKey(t,e,n)));return i?{blocks:i.blocks instanceof Uint16Array?i.blocks:new Uint16Array(i.blocks),meta:i.meta?i.meta instanceof Uint8Array?i.meta:new Uint8Array(i.meta):null,blockEntities:i.blockEntities??[]}:null}}const Hc="blockverse-settings",$l={renderDistance:8,fov:75,sensitivity:1,volume:.5};function Gc(){try{return{...$l,...JSON.parse(localStorage.getItem(Hc)??"{}")}}catch{return{...$l}}}function M0(s){localStorage.setItem(Hc,JSON.stringify(s))}class S0{constructor(t,{onPlay:e,onQuitToTitle:n,onRespawn:i,onResume:r,onApplySettings:o,store:a,sfx:c}){this.root=t,this.onPlay=e,this.onQuitToTitle=n,this.onRespawn=i,this.onResume=r,this.onApplySettings=o,this.store=a,this.sfx=c,this.current=null,this.settings=Gc()}clear(){this.root.innerHTML="",this.current=null}screen(t="screen menu-bg"){this.clear();const e=document.createElement("div");return e.className=t,this.root.appendChild(e),e}btn(t,e,n="btn"){const i=document.createElement("button");return i.className=n,i.textContent=t,i.addEventListener("click",()=>{this.sfx?.play("click"),e()}),i}title(t,e=!0){const n=document.createElement("div");if(n.className="title",n.textContent="BLOCKVERSE",t.appendChild(n),e){const i=document.createElement("div");i.className="subtitle",i.textContent="An open-source voxel sandbox!",t.appendChild(i)}}async showMain(){const t=this.screen();this.current="main",this.title(t);const e=await this.store.listWorlds();let n=e[0]?.id??null;const i=document.createElement("div");if(i.className="world-list",e.length===0){const l=document.createElement("div");l.style.padding="14px",l.style.color="#999",l.textContent="No worlds yet — create one below.",i.appendChild(l)}const r=new Map;for(const l of e){const h=document.createElement("div");h.className="world-entry";const u=document.createElement("div"),d=document.createElement("div");d.className="w-name",d.textContent=l.name;const f=document.createElement("div");f.className="w-info";const g=l.mode===Ke?"Creative":"Survival";f.textContent=`${g} · seed ${l.seed} · ${new Date(l.lastPlayed).toLocaleString()}`,u.appendChild(d),u.appendChild(f),h.appendChild(u),h.addEventListener("click",()=>{n=l.id;for(const[,_]of r)_.classList.remove("selected");h.classList.add("selected")}),h.addEventListener("dblclick",()=>this.onPlay(l.id)),r.set(l.id,h),i.appendChild(h)}n&&r.get(n)?.classList.add("selected"),t.appendChild(i);const o=document.createElement("div");o.className="row",o.appendChild(this.btn("Play Selected World",()=>{n&&this.onPlay(n)},"btn")),t.appendChild(o);const a=document.createElement("div");a.className="row",a.appendChild(this.btn("Create New World",()=>this.showCreate(),"btn small")),a.appendChild(this.btn("Settings",()=>this.showSettings(()=>this.showMain()),"btn small")),a.appendChild(this.btn("Delete World",async()=>{if(!n)return;const l=e.find(h=>h.id===n);confirm(`Delete world "${l.name}" forever?`)&&(await this.store.deleteWorld(n),this.showMain())},"btn small danger")),t.appendChild(a);const c=document.createElement("div");c.style.cssText="position:absolute;bottom:10px;font-size:12px;color:#888",c.textContent="BlockVerse — an original open-source voxel game. Not affiliated with Mojang or Microsoft.",t.appendChild(c)}showCreate(){const t=this.screen();this.current="create",this.title(t,!1);const e=(o,a)=>{const c=document.createElement("div");c.className="field";const l=document.createElement("label");return l.textContent=o,c.appendChild(l),c.appendChild(a),t.appendChild(c),c},n=document.createElement("input");n.value="New World",n.maxLength=32,e("World name",n);const i=document.createElement("input");i.placeholder="Leave empty for a random seed",e("Seed (any text or number)",i);const r=document.createElement("select");for(const[o,a]of[[Bi,"Survival"],[Ke,"Creative"]]){const c=document.createElement("option");c.value=o,c.textContent=a,r.appendChild(c)}e("Game mode",r),t.appendChild(this.btn("Create World",async()=>{const o=i.value.trim();let a;o===""?a=Math.random()*4294967295>>>0:/^-?\d+$/.test(o)?a=parseInt(o,10)>>>0:a=Ac(o);const c=await this.store.createWorld({name:n.value.trim()||"New World",seed:a,mode:parseInt(r.value,10),renderDistance:this.settings.renderDistance});this.onPlay(c.id)})),t.appendChild(this.btn("Back",()=>this.showMain(),"btn small")),setTimeout(()=>n.focus(),0)}showLoading(t="Generating world…"){const e=this.screen("screen menu-bg");this.current="loading",this.title(e,!1);const n=document.createElement("div");n.textContent=t,e.appendChild(n);const i=document.createElement("div");i.className="loading-bar-track";const r=document.createElement("div");i.appendChild(r),e.appendChild(i),this._loadingLabel=n,this._loadingFill=r}setLoadingProgress(t){this._loadingFill&&(this._loadingFill.style.width=`${Math.round(t*100)}%`)}showPause(){const t=this.screen("screen dim");this.current="pause";const e=document.createElement("div");e.className="title",e.style.fontSize="30px",e.textContent="Game Paused",t.appendChild(e),t.appendChild(this.btn("Back to Game",()=>this.onResume())),t.appendChild(this.btn("Settings",()=>this.showSettings(()=>this.showPause()))),t.appendChild(this.btn("Save & Quit to Title",()=>this.onQuitToTitle()))}showSettings(t){const e=this.screen(this.current==="pause"||this.current==="settings-pause"?"screen dim":"screen menu-bg");this.current=this.current==="pause"?"settings-pause":"settings";const n=document.createElement("div");n.className="title",n.style.fontSize="30px",n.textContent="Settings",e.appendChild(n);const i=(o,a,c,l,h,u,d)=>{const f=document.createElement("div");f.className="setting-row";const g=document.createElement("label");g.textContent=o;const _=document.createElement("input");_.type="range",_.min=a,_.max=c,_.step=l,_.value=h;const m=document.createElement("span");m.className="val",m.textContent=u(h),_.addEventListener("input",()=>{const p=parseFloat(_.value);m.textContent=u(p),d(p),this.applySettings()}),f.appendChild(g),f.appendChild(_),f.appendChild(m),e.appendChild(f)},r=this.settings;i("Render distance",2,16,1,r.renderDistance,o=>`${o}`,o=>{r.renderDistance=o}),i("Field of view",60,110,1,r.fov,o=>`${o}°`,o=>{r.fov=o}),i("Mouse sensitivity",.2,2.5,.05,r.sensitivity,o=>`${(+o).toFixed(2)}`,o=>{r.sensitivity=o}),i("Volume",0,1,.05,r.volume,o=>`${Math.round(o*100)}%`,o=>{r.volume=o}),e.appendChild(this.btn("Done",()=>t(),"btn small"))}applySettings(){M0(this.settings),this.onApplySettings?.(this.settings)}showDeath(){const t=this.screen("screen dim");this.current="death",t.style.background="rgba(120, 10, 10, 0.45)";const e=document.createElement("div");e.className="death-title",e.textContent="You died!",t.appendChild(e),t.appendChild(this.btn("Respawn",()=>this.onRespawn())),t.appendChild(this.btn("Title Screen",()=>this.onQuitToTitle()))}}class E0{constructor(){this.ctx=null,this.master=null,this.volume=.5,this._noiseBuf=null}ensure(){if(this.ctx)return!0;try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.master=this.ctx.createGain(),this.master.gain.value=this.volume,this.master.connect(this.ctx.destination);const t=this.ctx.sampleRate;this._noiseBuf=this.ctx.createBuffer(1,t,this.ctx.sampleRate);const e=this._noiseBuf.getChannelData(0);for(let n=0;n<t;n++)e[n]=Math.random()*2-1;return!0}catch{return!1}}resume(){this.ensure()&&this.ctx.state==="suspended"&&this.ctx.resume()}setVolume(t){this.volume=t,this.master&&(this.master.gain.value=t)}noise({freq:t=800,q:e=1,dur:n=.1,gain:i=.5,type:r="bandpass",pitchDrop:o=0}){if(!this.ensure()||this.ctx.state==="suspended")return;const a=this.ctx.currentTime,c=this.ctx.createBufferSource();c.buffer=this._noiseBuf,c.loop=!0;const l=this.ctx.createBiquadFilter();l.type=r,l.frequency.setValueAtTime(t,a),o&&l.frequency.exponentialRampToValueAtTime(Math.max(40,t-o),a+n),l.Q.value=e;const h=this.ctx.createGain();h.gain.setValueAtTime(i,a),h.gain.exponentialRampToValueAtTime(.001,a+n),c.connect(l).connect(h).connect(this.master),c.start(a,Math.random()),c.stop(a+n+.02)}tone({freq:t=440,endFreq:e=null,dur:n=.15,gain:i=.25,type:r="square"}){if(!this.ensure()||this.ctx.state==="suspended")return;const o=this.ctx.currentTime,a=this.ctx.createOscillator();a.type=r,a.frequency.setValueAtTime(t,o),e&&a.frequency.exponentialRampToValueAtTime(e,o+n);const c=this.ctx.createGain();c.gain.setValueAtTime(i,o),c.gain.exponentialRampToValueAtTime(.001,o+n),a.connect(c).connect(this.master),a.start(o),a.stop(o+n+.02)}materialParams(t){switch(t){case"stone":return{freq:520,q:.8,type:"bandpass"};case"dirt":return{freq:300,q:.6,type:"lowpass"};case"sand":return{freq:900,q:.4,type:"highpass"};case"wood":return{freq:380,q:2.2,type:"bandpass"};case"leaf":return{freq:1600,q:.5,type:"highpass"};case"glass":return{freq:2400,q:3,type:"bandpass"};case"cloth":return{freq:500,q:.3,type:"lowpass"};default:return{freq:600,q:1,type:"bandpass"}}}play(t,e={}){const n=this.materialParams(e.block??"stone"),i=.85+Math.random()*.3;switch(t){case"hit":this.noise({...n,freq:n.freq*i,dur:.06,gain:.22});break;case"break":this.noise({...n,freq:n.freq*i,dur:.16,gain:.5,pitchDrop:n.freq*.4});break;case"place":this.noise({...n,freq:n.freq*i*1.1,dur:.1,gain:.4});break;case"step":this.noise({...n,freq:n.freq*i*.8,dur:.05,gain:.12});break;case"hurt":this.tone({freq:260*i,endFreq:130,dur:.22,gain:.3,type:"sawtooth"});break;case"pickup":this.tone({freq:620*i,endFreq:1240,dur:.09,gain:.18,type:"sine"});break;case"eat":this.noise({freq:420*i,q:1.5,dur:.09,gain:.3,type:"bandpass"}),setTimeout(()=>this.noise({freq:380,q:1.5,dur:.09,gain:.25,type:"bandpass"}),130);break;case"click":this.tone({freq:880,dur:.04,gain:.12,type:"square"});break;case"toolbreak":this.tone({freq:500,endFreq:120,dur:.3,gain:.35,type:"square"});break;case"splash":this.noise({freq:1100,q:.4,dur:.25,gain:.35,type:"highpass",pitchDrop:600});break}}}const sr=document.getElementById("game-canvas"),y0=document.getElementById("ui-root"),T0=document.getElementById("hud"),Vc=new mg,ls=new E0;let ee=null,Qe=null,pr=null;async function b0(){pr=await Ca.open(),ls.setVolume(Gc().volume),Qe=new S0(y0,{store:pr,sfx:ls,onPlay:s=>A0(s),onQuitToTitle:()=>R0(),onRespawn:()=>w0(),onResume:()=>Wc(),onApplySettings:s=>{ls.setVolume(s.volume),ee?.applySettings(s)}}),Qe.showMain()}async function A0(s){const t=await pr.loadWorld(s);if(!t)return;Qe.showLoading(`Loading "${t.name}"…`);const e=Qe.settings;ee=new _0({canvas:sr,atlas:Vc,worldMeta:{...t,renderDistance:e.renderDistance},store:pr,sfx:ls}),ee.applySettings(e),ee.uiHooks={showPause:()=>{ee.paused||ee.player.dead||ee.chat.open||(ee.pause(),Qe.showPause())},showDeath:()=>{ee.setUiOpen(!0),Qe.showDeath()},handleKey:n=>n==="Escape"&&(Qe.current==="pause"||Qe.current==="settings-pause")?(Wc(),!0):!1},ee.setUiOpen(!0),ee.start(),await new Promise(n=>{const i=performance.now(),r=setInterval(()=>{const o=Math.floor(ee.player.x/16),a=Math.floor(ee.player.z/16);let c=0;const l=2,h=(2*l+1)**2;for(let u=-l;u<=l;u++)for(let d=-l;d<=l;d++)ee.world.getChunk(o+u,a+d)?.mesh&&c++;Qe.setLoadingProgress(c/h),(c>=h||performance.now()-i>25e3)&&(clearInterval(r),n())},200)}),Qe.clear(),ee.setUiOpen(!1),ee.updateDebug()}function Wc(){ee&&(Qe.clear(),ee.resume())}function w0(){ee&&(Qe.clear(),ee.player.respawn(),ee.hud.renderStats(),ee.hud.renderHotbar(),ee.setUiOpen(!1),ee.input.requestLock())}function R0(){ee&&(ee.stop(),ee=null),T0.classList.add("hidden"),Qe.showMain()}b0();window.__app={get game(){return ee},atlas:Vc,sfx:ls};Object.defineProperty(window,"__game",{get:()=>ee,configurable:!0});Object.defineProperty(window,"__world",{get:()=>ee?.world,configurable:!0});window.__snap=(s="snap",t=640)=>{if(!ee)return Promise.resolve("no game");ee.renderer.render(ee.scene,ee.camera);const e=document.createElement("canvas"),n=Math.round(t*sr.height/sr.width);return e.width=t,e.height=n,e.getContext("2d").drawImage(sr,0,0,t,n),fetch(`/__snap?name=${s}`,{method:"POST",body:e.toDataURL("image/jpeg",.85)}).then(i=>i.text()).catch(()=>"no endpoint")};
