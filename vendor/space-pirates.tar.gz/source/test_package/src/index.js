// ZYVOQIX: explicit same-origin asset directory and visible asynchronous startup errors.
import { initializeBabylonApp } from "app_package";
initializeBabylonApp({ assetsHostUrl: "/games/space-pirates" }).catch(error => {
  window.dispatchEvent(new CustomEvent('zyvoqix-game-error', { detail: String(error?.message || error) }));
  console.error('Space Pirates startup:', error);
});
