// Modified for ZYVOQIX: optional external Typekit removed.
import { initializeBabylonApp } from "app_package";
initializeBabylonApp({ assetsHostUrl: "/games/space-pirates" });
