import * as CANNON from 'cannon-es';

export class PhysicsWorld {
  constructor() {
    this.world = new CANNON.World();
    this.world.gravity.set(0, -20, 0);
    this.world.broadphase = new CANNON.SAPBroadphase(this.world);
    this.world.allowSleep = true;
    this.world.solver.iterations = 7;
    this.world.defaultContactMaterial.friction = 0.35;
    this.world.defaultContactMaterial.restitution = 0.05;

    // Static obstacles, interactive ramps
    this.obstacles = [];
    this.ramps = [];
    this.flyovers = [];
    this.flyoverRamps = [];

    const groundShape = new CANNON.Plane();
    const groundBody = new CANNON.Body({
      mass: 0,
      type: CANNON.Body.STATIC,
      shape: groundShape
    });
    groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
    this.world.addBody(groundBody);
    this.groundBody = groundBody;
  }

  step(dt) {
    const clampedDt = Math.min(dt, 0.033);
    this.world.step(1 / 60, clampedDt, 1);
  }

  addStaticBox(x, y, z, hx, hy, hz, isRamp = false, isPillar = false, isTree = false) {
    // Cap building physics height to match visually scaled-down buildings (scale.y=0.38).
    // Trees, pillars and ramps keep their original height for correct collision feel.
    const cappedHy = (isRamp || isPillar || isTree) ? hy : Math.min(hy, 4.2);
    const cappedY  = (isRamp || isPillar || isTree) ? y  : Math.min(y,  cappedHy);

    const shape = new CANNON.Box(new CANNON.Vec3(hx, cappedHy, hz));
    const body = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(x, cappedY, z),
      shape: shape
    });
    this.world.addBody(body);

    this.obstacles.push({ x, y: cappedY, z, hx, hy: cappedHy, hz, isRamp, isPillar, isTree });
    return body;
  }

  addRampTrigger(x, z, width, length, height, rotY = 0) {
    this.ramps.push({ x, z, width, length, height, rotY });
  }

  addFlyover(id, x, z, length, width, height, axis = 'X') {
    const halfL = length / 2;
    const halfW = width / 2;
    const minX = axis === 'X' ? x - halfL : x - halfW;
    const maxX = axis === 'X' ? x + halfL : x + halfW;
    const minZ = axis === 'X' ? z - halfW : z - halfL;
    const maxZ = axis === 'X' ? z + halfW : z + halfL;

    this.flyovers.push({
      id,
      x,
      z,
      length,
      width,
      height,
      axis,
      minX,
      maxX,
      minZ,
      maxZ
    });
  }

  addFlyoverRamp(id, axis, startCoord, endCoord, fixedCoord, width, startHeight, endHeight) {
    this.flyoverRamps.push({
      id,
      axis,
      startCoord,
      endCoord,
      fixedCoord,
      width,
      startHeight,
      endHeight
    });
  }

  getFlyoverAt(x, z, currentY = 0) {
    // Check if within any elevated ramp
    for (const ramp of this.flyoverRamps) {
      if (ramp.axis === 'X') {
        if (Math.abs(z - ramp.fixedCoord) <= ramp.width / 2 + 0.5) {
          const minX = Math.min(ramp.startCoord, ramp.endCoord);
          const maxX = Math.max(ramp.startCoord, ramp.endCoord);
          if (x >= minX - 1.5 && x <= maxX + 1.5) {
            const t = Math.max(0, Math.min(1, (x - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
            const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
            if (Math.abs(currentY - rampH) < 7.0 || currentY <= rampH + 2.0) {
              return { type: 'ramp', ramp, currentSurfaceH: rampH };
            }
          }
        }
      } else if (ramp.axis === 'Z') {
        if (Math.abs(x - ramp.fixedCoord) <= ramp.width / 2 + 0.5) {
          const minZ = Math.min(ramp.startCoord, ramp.endCoord);
          const maxZ = Math.max(ramp.startCoord, ramp.endCoord);
          if (z >= minZ - 1.5 && z <= maxZ + 1.5) {
            const t = Math.max(0, Math.min(1, (z - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
            const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
            if (Math.abs(currentY - rampH) < 7.0 || currentY <= rampH + 2.0) {
              return { type: 'ramp', ramp, currentSurfaceH: rampH };
            }
          }
        }
      }
    }

    // Check elevated flyover decks
    for (const deck of this.flyovers) {
      if (x >= deck.minX - 1.0 && x <= deck.maxX + 1.0 && z >= deck.minZ - 1.0 && z <= deck.maxZ + 1.0) {
        if (currentY >= deck.height - 3.5 || Math.abs(currentY - deck.height) < 6.0) {
          return { type: 'deck', deck, currentSurfaceH: deck.height };
        }
      }
    }

    return null;
  }

  constrainToFlyover(x, z, currentY = 0, entityRadius = 1.0) {
    let finalX = x;
    let finalZ = z;
    let constrained = false;
    let normalX = 0;
    let normalZ = 0;

    // Only apply lateral guardrails if entity is elevated above ground level
    if (currentY < 1.0) {
      return { x: finalX, z: finalZ, constrained: false, normalX: 0, normalZ: 0 };
    }

    // 1. Check if entity is on a ramp
    for (const ramp of this.flyoverRamps) {
      if (ramp.axis === 'X') {
        const minX = Math.min(ramp.startCoord, ramp.endCoord);
        const maxX = Math.max(ramp.startCoord, ramp.endCoord);
        if (x >= minX - 0.5 && x <= maxX + 0.5) {
          const t = Math.max(0, Math.min(1, (x - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
          const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
          if (Math.abs(currentY - rampH) < 5.0) {
            // Constrain lateral Z inside ramp width
            const halfW = ramp.width / 2 - entityRadius * 0.35;
            const minZ = ramp.fixedCoord - halfW;
            const maxZ = ramp.fixedCoord + halfW;
            if (finalZ < minZ) {
              finalZ = minZ + 0.15;
              normalZ = 1.0;
              constrained = true;
            } else if (finalZ > maxZ) {
              finalZ = maxZ - 0.15;
              normalZ = -1.0;
              constrained = true;
            }
            return { x: finalX, z: finalZ, constrained, normalX, normalZ };
          }
        }
      } else if (ramp.axis === 'Z') {
        const minZ = Math.min(ramp.startCoord, ramp.endCoord);
        const maxZ = Math.max(ramp.startCoord, ramp.endCoord);
        if (z >= minZ - 0.5 && z <= maxZ + 0.5) {
          const t = Math.max(0, Math.min(1, (z - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
          const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
          if (Math.abs(currentY - rampH) < 5.0) {
            // Constrain lateral X inside ramp width
            const halfW = ramp.width / 2 - entityRadius * 0.35;
            const minX = ramp.fixedCoord - halfW;
            const maxX = ramp.fixedCoord + halfW;
            if (finalX < minX) {
              finalX = minX + 0.15;
              normalX = 1.0;
              constrained = true;
            } else if (finalX > maxX) {
              finalX = maxX - 0.15;
              normalX = -1.0;
              constrained = true;
            }
            return { x: finalX, z: finalZ, constrained, normalX, normalZ };
          }
        }
      }
    }

    // 2. Check if entity is on a deck
    for (const deck of this.flyovers) {
      if (Math.abs(currentY - deck.height) < 4.0 || currentY >= deck.height - 1.5) {
        if (deck.axis === 'X') {
          // Deck runs along X (minX to maxX), cross-axis is Z
          if (finalX >= deck.minX - 3.0 && finalX <= deck.maxX + 3.0) {
            const halfW = deck.width / 2 - entityRadius * 0.35;
            const minZ = deck.z - halfW;
            const maxZ = deck.z + halfW;
            if (finalZ < minZ) {
              finalZ = minZ + 0.15;
              normalZ = 1.0;
              constrained = true;
            } else if (finalZ > maxZ) {
              finalZ = maxZ - 0.15;
              normalZ = -1.0;
              constrained = true;
            }
          }
        } else if (deck.axis === 'Z') {
          // Deck runs along Z (minZ to maxZ), cross-axis is X
          if (finalZ >= deck.minZ - 3.0 && finalZ <= deck.maxZ + 3.0) {
            const halfW = deck.width / 2 - entityRadius * 0.35;
            const minX = deck.x - halfW;
            const maxX = deck.x + halfW;
            if (finalX < minX) {
              finalX = minX + 0.15;
              normalX = 1.0;
              constrained = true;
            } else if (finalX > maxX) {
              finalX = maxX - 0.15;
              normalX = -1.0;
              constrained = true;
            }
          }
        }
      }
    }

    return { x: finalX, z: finalZ, constrained, normalX, normalZ };
  }

  getSurfaceHeight(x, z, currentY = null, forSpawning = false) {
    let surfaceH = 0;

    // 1. Check flyover ramps first — smooth climbing from ground to elevated deck
    for (const ramp of this.flyoverRamps) {
      if (ramp.axis === 'X') {
        if (Math.abs(z - ramp.fixedCoord) <= ramp.width / 2 + 0.8) {
          const minX = Math.min(ramp.startCoord, ramp.endCoord);
          const maxX = Math.max(ramp.startCoord, ramp.endCoord);
          if (x >= minX - 1.5 && x <= maxX + 1.5) {
            const t = Math.max(0, Math.min(1, (x - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
            const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
            if (forSpawning || currentY === null || Math.abs(currentY - rampH) < 8.0 || currentY <= rampH + 2.5) {
              if (rampH > surfaceH) surfaceH = rampH;
            }
          }
        }
      } else if (ramp.axis === 'Z') {
        if (Math.abs(x - ramp.fixedCoord) <= ramp.width / 2 + 0.8) {
          const minZ = Math.min(ramp.startCoord, ramp.endCoord);
          const maxZ = Math.max(ramp.startCoord, ramp.endCoord);
          if (z >= minZ - 1.5 && z <= maxZ + 1.5) {
            const t = Math.max(0, Math.min(1, (z - ramp.startCoord) / (ramp.endCoord - ramp.startCoord)));
            const rampH = ramp.startHeight + (ramp.endHeight - ramp.startHeight) * t;
            if (forSpawning || currentY === null || Math.abs(currentY - rampH) < 8.0 || currentY <= rampH + 2.5) {
              if (rampH > surfaceH) surfaceH = rampH;
            }
          }
        }
      }
    }

    // 2. Check elevated flyover decks & summit terraces
    for (const deck of this.flyovers) {
      if (x >= deck.minX - 1.0 && x <= deck.maxX + 1.0 && z >= deck.minZ - 1.0 && z <= deck.maxZ + 1.0) {
        if (forSpawning || currentY === null || currentY >= deck.height - 3.0 || Math.abs(currentY - deck.height) < 6.5) {
          if (deck.height > surfaceH) {
            surfaceH = deck.height;
          }
        }
      }
    }

    return surfaceH;
  }

  removeBody(body) {
    this.world.removeBody(body);
  }

  /**
   * Universal, impenetrable sphere vs static box obstacle collision resolution
   * Used by SportsCar, BrunoToyCar, Vehicle, AutoRickshaw, Bus, MonsterTruck, Motorbike, and Player
   */
  resolveSphereCollision(x, y, z, radius) {
    let finalX = x;
    let finalZ = z;
    let collided = false;
    let isTree = false;

    const obstacles = this.obstacles || [];
    const r = radius;

    for (const b of obstacles) {
      if (b.isRamp) continue; // Allow driving onto ramps

      // Broadphase spatial distance check: skip obstacles far from object
      if (Math.abs(b.x - finalX) > b.hx + r + 1.5 || Math.abs(b.z - finalZ) > b.hz + r + 1.5) {
        continue;
      }

      // If obstacle is a flyover pillar and entity is elevated on flyover deck/ramp, skip it
      if (b.isPillar && y > 1.5) continue;

      const minY = b.y - b.hy;
      const maxY = b.y + b.hy;
      // 3D vertical clearance: skip if entirely above top surface or completely below
      if (y + 0.3 < minY || y >= maxY - 0.2) continue;

      const isInsideX = (finalX >= b.x - b.hx) && (finalX <= b.x + b.hx);
      const isInsideZ = (finalZ >= b.z - b.hz) && (finalZ <= b.z + b.hz);

      if (isInsideX && isInsideZ) {
        // Deep interior penetration: push out along shortest axis to exterior
        collided = true;
        if (b.isTree) isTree = true;
        const leftDist = finalX - (b.x - b.hx);
        const rightDist = (b.x + b.hx) - finalX;
        const backDist = finalZ - (b.z - b.hz);
        const frontDist = (b.z + b.hz) - finalZ;
        const minDist = Math.min(leftDist, rightDist, backDist, frontDist);

        if (minDist === leftDist) {
          finalX = b.x - b.hx - r;
        } else if (minDist === rightDist) {
          finalX = b.x + b.hx + r;
        } else if (minDist === backDist) {
          finalZ = b.z - b.hz - r;
        } else {
          finalZ = b.z + b.hz + r;
        }
      } else {
        // Exterior sphere-box overlap
        const closestX = Math.max(b.x - b.hx, Math.min(finalX, b.x + b.hx));
        const closestZ = Math.max(b.z - b.hz, Math.min(finalZ, b.z + b.hz));

        const dx = finalX - closestX;
        const dz = finalZ - closestZ;
        const distSq = dx * dx + dz * dz;

        if (distSq < r * r) {
          collided = true;
          if (b.isTree) isTree = true;
          const dist = Math.sqrt(distSq);
          if (dist > 0.0001) {
            const push = r - dist;
            finalX += (dx / dist) * push;
            finalZ += (dz / dist) * push;
          } else {
            finalX += (finalX >= b.x ? 1 : -1) * r;
          }
        }
      }
    }

    return { x: finalX, z: finalZ, collided, isTree };
  }
}

