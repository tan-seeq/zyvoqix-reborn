import { CHARACTERS } from '../kart/model.js';
import { ITEMS } from '../items/items.js';
import { formatTime } from '../race/race.js';

/* ------------------------------------------------------------------ *
 * DOM heads-up display, menus and results.
 * Kept out of WebGL so text stays crisp at any resolution.
 * ------------------------------------------------------------------ */

const ORDINAL = ['', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'];

export class HUD {
  constructor(root) {
    this.root = root;
    this.root.innerHTML = TEMPLATE;
    this.el = {
      title: root.querySelector('#title'),
      select: root.querySelector('#select'),
      grid: root.querySelector('#charGrid'),
      courseSelect: root.querySelector("#courseSelect"),
      courseGrid: root.querySelector('#courseGrid'),
      hud: root.querySelector('#hud'),
      muteBtn: root.querySelector('#muteBtn'),
      pos: root.querySelector('#pos .value'),
      posSuffix: root.querySelector('#pos .suffix'),
      lap: root.querySelector('#lap .value'),
      lapTotal: root.querySelector('#lap .total'),
      time: root.querySelector('#time'),
      speed: root.querySelector('#speedValue'),
      speedArc: root.querySelector('#speedArc'),
      itemSlot: root.querySelector('#itemSlot'),
      itemIcon: root.querySelector('#itemIcon'),
      standings: root.querySelector('#standings'),
      minimap: root.querySelector('#minimap'),
      countdown: root.querySelector('#countdown'),
      toast: root.querySelector('#toast'),
      results: root.querySelector('#results'),
      resultsBody: root.querySelector('#resultsBody'),
      lapFlash: root.querySelector('#lapFlash'),
      boostBar: root.querySelector('#boostFill'),
      touch: root.querySelector('#touch'),
    };
    this.ctx = this.el.minimap.getContext('2d');
    this.rollTimer = 0;
    this.selected = 0;
    this._buildCharacters();
    this._bindMute();
    this.speedArcLen = 0;
  }

  /* ------------------------------ menus ---------------------------- */
  _buildCharacters() {
    this.el.grid.innerHTML = CHARACTERS.map((c, i) => `
      <button class="char" data-i="${i}" style="--c:#${c.body.toString(16).padStart(6, '0')};--a:#${c.accent.toString(16).padStart(6, '0')}">
        <span class="charFace"></span>
        <span class="charName">${c.name}</span>
        <span class="charTag">${c.tag}</span>
        <span class="charStats">
          ${statBar('SPD', c.stats.speed)}
          ${statBar('ACC', c.stats.accel)}
          ${statBar('GRP', c.stats.grip)}
          ${statBar('WGT', c.stats.weight)}
        </span>
      </button>`).join('');
  }

  showTitle(onStart) {
    this.el.title.classList.remove('hidden');
    this.el.title.querySelector('#playBtn').onclick = () => {
      this.el.title.classList.add('hidden');
      // Deliberately does NOT reveal #select — the track picker comes first,
      // and both panels are z-index:auto, so an early reveal would stack the
      // character grid on top of the course cards and swallow their clicks.
      onStart();
    };
  }

  /**
   * Track picker. Choosing a different circuit reloads the page with a
   * ?course= override: the whole world (track, scenery, terrain, clearance
   * bake) is built once at boot, and rebuilding it in place would mean a
   * teardown path for every one of those systems for no visible gain — the
   * loading screen already covers the couple of seconds it takes.
   */
  showCourses(courses, currentId, onPick) {
    this.el.title.classList.add('hidden');
    this.el.courseSelect.classList.remove('hidden');
    this.el.courseGrid.innerHTML = courses.map((c) => `
      <button class="course${c.id === currentId ? ' on' : ''}" data-id="${c.id}">
        <span class="courseFlag">${c.flag}</span>
        <span class="courseName">${c.name}</span>
        <span class="courseSub">${c.subtitle}</span>
        <span class="courseBlurb">${c.blurb}</span>
        <span class="courseMeta">${c.laps} laps${c.traffic ? ' &middot; traffic' : ''}</span>
      </button>`).join('');
    for (const b of this.el.courseGrid.querySelectorAll('.course')) {
      b.onclick = () => {
        this.el.courseSelect.classList.add('hidden');
        onPick(b.dataset.id);
      };
    }
  }

  showSelect(onPick) {
    this.el.select.classList.remove('hidden');
    const buttons = [...this.el.grid.querySelectorAll('.char')];
    const mark = (i) => buttons.forEach((b, j) => b.classList.toggle('on', i === j));
    mark(this.selected);
    buttons.forEach((b) => {
      b.onmouseenter = () => { this.selected = +b.dataset.i; mark(this.selected); onPick?.preview?.(this.selected); };
      b.onclick = () => {
        this.selected = +b.dataset.i;
        this.el.select.classList.add('hidden');
        onPick.confirm(this.selected);
      };
    });
  }

  showHUD() {
    this.el.hud.classList.remove('hidden');
    // clear anything left over from the previous race
    clearTimeout(this._toastT);
    this.el.toast.className = '';
    this.el.toast.textContent = '';
  }

  _bindMute() {
    this.el.muteBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.onMuteToggle?.();
    });
  }

  /** Reflect the audio engine's mute state on the speaker button. */
  setMuted(muted) {
    const b = this.el.muteBtn;
    if (!b) return;
    b.textContent = muted ? '🔇' : '🔊';
    b.classList.toggle('off', !!muted);
  }

  /* ------------------------------ HUD ------------------------------ */
  update(dt, game) {
    const p = game.player;
    const race = game.race;

    this.el.pos.textContent = p.rank;
    this.el.posSuffix.textContent = (ORDINAL[p.rank] || '').slice(-2);
    this.el.lap.textContent = Math.min(race.laps, p.lap + 1);
    this.el.lapTotal.textContent = race.laps;
    this.el.time.textContent = formatTime(race.raceTime);

    this.el.speed.textContent = Math.round(p.mph);
    // full sweep at 145 mph, a little above what a boosted kart can reach
    const frac = Math.min(1, p.mph / 145);
    const len = 2 * Math.PI * 52 * 0.75;
    this.el.speedArc.style.strokeDasharray = `${len}`;
    this.el.speedArc.style.strokeDashoffset = `${len * (1 - frac)}`;
    this.el.speedArc.style.stroke = p.boostTime > 0 ? '#ffd23f' : (p.offroad ? '#c98a4a' : '#4fd6ff');

    // drift charge / boost meter
    const charge = p.drifting ? Math.min(1, p.driftCharge / 3.6) : (p.boostTime > 0 ? 1 : 0);
    this.el.boostBar.style.transform = `scaleX(${charge})`;
    this.el.boostBar.style.background = p.driftTier >= 3 ? '#ff3ad0'
      : p.driftTier === 2 ? '#ff9a2a' : '#66ccff';

    // item slot
    if (p.itemRolling > 0) {
      this.rollTimer += dt;
      if (this.rollTimer > 0.055) {
        this.rollTimer = 0;
        const keys = Object.keys(ITEMS);
        this.el.itemIcon.textContent = ITEMS[keys[Math.floor(Math.random() * keys.length)]].icon;
      }
      this.el.itemSlot.classList.add('rolling');
    } else {
      this.el.itemSlot.classList.remove('rolling');
      if (p.item) {
        this.el.itemIcon.textContent = ITEMS[p.item].icon;
        this.el.itemSlot.classList.add('has');
        this.el.itemSlot.dataset.charges = p.itemCharges > 0 ? `×${p.itemCharges + 1}` : '';
      } else {
        this.el.itemIcon.textContent = '';
        this.el.itemSlot.classList.remove('has');
        this.el.itemSlot.dataset.charges = '';
      }
    }

    // standings
    if (!this._standTimer || (this._standTimer -= dt) <= 0) {
      this._standTimer = 0.25;
      this.el.standings.innerHTML = (race.standings || game.karts)
        .map((k, i) => `<li class="${k.isPlayer ? 'me' : ''}">
            <b>${i + 1}</b>
            <i style="background:#${k.character.body.toString(16).padStart(6, '0')}"></i>
            <span>${k.name}</span>
          </li>`).join('');
    }

    this.drawMinimap(game);
  }

  drawMinimap(game) {
    const ctx = this.ctx;
    const cv = this.el.minimap;
    const size = cv.width;
    const t = game.track;
    if (!this._mapCache) {
      // pre-compute a normalised path
      let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
      for (let i = 0; i < t.n; i += 8) {
        minX = Math.min(minX, t.pos[i * 3]); maxX = Math.max(maxX, t.pos[i * 3]);
        minZ = Math.min(minZ, t.pos[i * 3 + 2]); maxZ = Math.max(maxZ, t.pos[i * 3 + 2]);
      }
      const pad = 16;
      const sx = (size - pad * 2) / (maxX - minX);
      const sz = (size - pad * 2) / (maxZ - minZ);
      const s = Math.min(sx, sz);
      this._mapCache = {
        minX, minZ, s,
        ox: pad + ((size - pad * 2) - (maxX - minX) * s) / 2,
        oz: pad + ((size - pad * 2) - (maxZ - minZ) * s) / 2,
      };
    }
    const { minX, minZ, s, ox, oz } = this._mapCache;
    const P = (x, z) => [ox + (x - minX) * s, oz + (z - minZ) * s];

    ctx.clearRect(0, 0, size, size);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(8,12,20,0.75)';
    ctx.lineWidth = 11;
    ctx.beginPath();
    for (let i = 0; i <= t.n; i += 10) {
      const j = i % t.n;
      const [x, y] = P(t.pos[j * 3], t.pos[j * 3 + 2]);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(190,220,240,0.9)';
    ctx.lineWidth = 6;
    ctx.stroke();

    // start line
    const [sxp, syp] = P(t.pos[0], t.pos[2]);
    ctx.fillStyle = '#fff';
    ctx.fillRect(sxp - 4, syp - 4, 8, 8);

    for (const k of game.karts) {
      const [x, y] = P(k.position.x, k.position.z);
      ctx.beginPath();
      ctx.arc(x, y, k.isPlayer ? 6.5 : 4.5, 0, Math.PI * 2);
      ctx.fillStyle = '#' + k.character.body.toString(16).padStart(6, '0');
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = k.isPlayer ? '#fff' : 'rgba(0,0,0,0.6)';
      ctx.stroke();
    }
  }

  /* ---------------------------- messaging -------------------------- */
  countdown(n) {
    const el = this.el.countdown;
    el.textContent = n > 0 ? n : '';
    el.className = 'shown count';
    void el.offsetWidth;
    el.classList.add('pop');
    setTimeout(() => el.classList.remove('pop'), 600);
  }

  go() {
    const el = this.el.countdown;
    el.textContent = '¡VÁMONOS!';
    el.className = 'shown go pop';
    setTimeout(() => { el.className = ''; }, 1100);
  }

  toast(text, cls = '') {
    const el = this.el.toast;
    el.textContent = text;
    el.className = 'shown ' + cls;
    clearTimeout(this._toastT);
    this._toastT = setTimeout(() => { el.className = ''; }, 1600);
  }

  lapFlash(text) {
    const el = this.el.lapFlash;
    el.textContent = text;
    el.className = 'shown';
    clearTimeout(this._lapT);
    this._lapT = setTimeout(() => { el.className = ''; }, 1800);
  }

  results(race, player, onAgain) {
    const rows = [...race.karts].sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1;
      if (b.finished) return 1;
      return b.progressTotal - a.progressTotal;
    });
    this.el.resultsBody.innerHTML = rows.map((k, i) => `
      <li class="${k.isPlayer ? 'me' : ''}">
        <b>${ORDINAL[i + 1]}</b>
        <i style="background:#${k.character.body.toString(16).padStart(6, '0')}"></i>
        <span>${k.name}</span>
        <em>${k.finished ? formatTime(k.finishTime) : 'DNF'}</em>
      </li>`).join('');
    this.el.results.querySelector('#bestLap').textContent = formatTime(race.bestLap());
    this.el.results.querySelector('#yourPos').textContent = ORDINAL[player.finalRank || player.rank] || '—';
    this.el.hud.classList.add('hidden');
    this.el.results.classList.remove('hidden');
    this.el.results.querySelector('#againBtn').onclick = () => {
      this.el.results.classList.add('hidden');
      onAgain();
    };
  }
}

function statBar(label, v) {
  const pct = Math.round(((v - 0.82) / 0.4) * 100);
  return `<span class="stat"><u>${label}</u><b><i style="width:${Math.max(8, Math.min(100, pct))}%"></i></b></span>`;
}

const TEMPLATE = /* html */ `
<div id="title">
  <div class="titleInner">
    <svg class="flagbar" viewBox="0 0 300 200" role="img" aria-label="Flag of Puerto Rico">
      <defs>
        <linearGradient id="flagShade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#fff" stop-opacity=".28"/>
          <stop offset="45%" stop-color="#fff" stop-opacity="0"/>
          <stop offset="100%" stop-color="#000" stop-opacity=".22"/>
        </linearGradient>
      </defs>
      <g class="flagWave">
        <rect width="300" height="200" fill="var(--pr-red)"/>
        <rect y="40" width="300" height="40" fill="#fff"/>
        <rect y="120" width="300" height="40" fill="#fff"/>
        <path d="M0 0 L0 200 L173.2 100 Z" fill="var(--pr-blue)"/>
        <path fill="#fff" d="M57.7 66 L65.34 89.48 L90.04 89.49 L70.06 104.02 L77.69 127.51
          L57.7 113 L37.71 127.51 L45.34 104.02 L25.36 89.49 L50.06 89.48 Z"/>
        <rect width="300" height="200" fill="url(#flagShade)"/>
      </g>
    </svg>
    <h1>OLD SAN JUAN<span>KART</span></h1>
    <p class="tag">Adoquines · Garitas · Gloria</p>
    <button id="playBtn">PRESS START</button>
    <div class="controls">
      <span><kbd>W</kbd>/<kbd>↑</kbd> Accelerate</span>
      <span><kbd>S</kbd>/<kbd>↓</kbd> Brake</span>
      <span><kbd>A</kbd><kbd>D</kbd> Steer</span>
      <span><kbd>Shift</kbd> Hop / Drift</span>
      <span><kbd>E</kbd> Use item</span>
      <span><kbd>C</kbd> Look back</span>
      <span><kbd>M</kbd> Mute</span>
    </div>
    <div class="touchControls">
      <span>Slide your left thumb to steer</span>
      <span>Hold the green pedal for gas &mdash; blip it mid-corner to drift</span>
    </div>
  </div>
</div>

<div id="courseSelect" class="hidden">
  <h2>CHOOSE YOUR TRACK</h2>
  <div id="courseGrid"></div>
  <p class="hint">Pick a circuit to get started</p>
</div>

<div id="select" class="hidden">
  <h2>CHOOSE YOUR RACER</h2>
  <div id="charGrid"></div>
  <p class="hint">Click a racer to hit the streets</p>
</div>

<div id="hud" class="hidden">
  <div id="topLeft">
    <div id="pos"><span class="value">8</span><span class="suffix">th</span></div>
    <div id="lap">LAP <span class="value">1</span><span class="slash">/</span><span class="total">3</span></div>
  </div>
  <div id="topRight">
    <div id="time">0'00"000</div>
    <ul id="standings"></ul>
  </div>
  <div id="itemSlot"><span id="itemIcon"></span></div>
  <div id="bottomRight">
    <svg id="speedo" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r="52" class="track"/>
      <circle id="speedArc" cx="60" cy="60" r="52"/>
    </svg>
    <div id="speedText"><span id="speedValue">0</span><small>mph</small></div>
  </div>
  <button id="muteBtn" type="button" aria-label="Toggle sound"></button>
  <canvas id="minimap" width="220" height="220"></canvas>
  <div id="boostMeter"><div id="boostFill"></div></div>
  <div id="countdown"></div>
  <div id="toast"></div>
  <div id="lapFlash"></div>
</div>

<div id="touch" class="hidden">
  <div id="steerPad">
    <div id="steerTrack"><div id="steerKnob"></div></div>
  </div>
  <div id="touchRight">
    <button id="btnItem" class="tBtn" aria-label="Use item">ITEM</button>
    <button id="btnBrake" class="tBtn" aria-label="Brake">BRAKE</button>
    <button id="btnGas" class="tBtn gas" aria-label="Accelerate, blip to drift">GO</button>
  </div>
</div>

<div id="rotate">
  <div class="rotateInner">
    <svg viewBox="0 0 64 64" aria-hidden="true"><rect x="18" y="6" width="28" height="52" rx="5"/></svg>
    <p>Turn your phone sideways to race</p>
  </div>
</div>

<div id="results" class="hidden">
  <div class="resultsInner">
    <h2>RESULTS</h2>
    <div class="big">You finished <span id="yourPos">—</span></div>
    <ol id="resultsBody"></ol>
    <div class="best">Best lap <span id="bestLap"></span></div>
    <button id="againBtn">RACE AGAIN</button>
  </div>
</div>
`;
