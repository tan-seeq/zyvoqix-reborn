import * as THREE from 'three';
import { Engine } from './core/engine.js';
import { Input } from './core/input.js';
import { Audio } from './core/audio.js';
import { Environment } from './world/sky.js';
import { Track } from './world/track.js';
import { Terrain } from './world/terrain.js';
import { City } from './world/city.js';
import { COURSES, getCourse } from './world/courses.js';
import { Traffic } from './world/traffic.js';
import { Highway } from './world/highway.js';
import { bakeClearance } from './world/clearance.js';
import { Kart, CameraRig } from './kart/kart.js';
import { CHARACTERS } from './kart/model.js';
import { AIDriver } from './ai/ai.js';
import { Particles } from './fx/particles.js';
import { ItemSystem, ITEMS } from './items/items.js';
import { Race, RaceState } from './race/race.js';
import { HUD } from './ui/hud.js';
import { TouchControls } from './core/touch.js';
import { isTouch } from './core/device.js';

/* ------------------------------------------------------------------ *
 * Old San Juan Kart — bootstrap and game state machine.
 * ------------------------------------------------------------------ */

const FIELD = 8;
// ?course=expreso picks a circuit before the selection UI exists on screen.
const course = getCourse(new URLSearchParams(location.search).get('course'));

/* ---------------------------- boot ------------------------------- *
 * The world is built procedurally and synchronously, which takes long
 * enough on a phone to look like a hung tab. Yielding two frames between
 * phases lets the loading screen actually repaint in between.           */
const bootFill = document.getElementById('bootFill');
const bootLabel = document.getElementById('bootLabel');

function paint() {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };
    // requestAnimationFrame never fires while the tab is hidden, so race it
    // against a timer — otherwise loading deadlocks forever if the player
    // switches apps or tabs part-way through the build.
    requestAnimationFrame(() => requestAnimationFrame(finish));
    setTimeout(finish, 120);
  });
}

async function phase(pct, label) {
  if (bootFill) bootFill.style.width = `${pct}%`;
  if (bootLabel) bootLabel.textContent = label;
  await paint();
}

await phase(6, 'Starting the engine');
const engine = new Engine(document.getElementById('scene'));
const input = new Input();
const audio = new Audio();

await phase(18, 'Raising the sky');
const env = new Environment(engine);

await phase(34, `Laying the ${course.surface === 'asphalt' ? 'asphalt' : 'adoquines'}`);
const track = new Track(course);
engine.scene.add(track.group);

await phase(48, 'Shaping the headland');
const terrain = new Terrain(track, engine.scene);

await phase(62, course.scenery === 'city' ? 'Building Viejo San Juan' : 'Raising Hato Rey');
const city = course.scenery === 'city' ? new City(track, engine.scene) : null;
const highway = course.scenery === 'highway' ? new Highway(track, engine.scene, terrain) : null;

await phase(84, 'Setting the barriers');
const traffic = course.traffic ? new Traffic(track, engine.scene, course.traffic) : null;
track.clearance = bakeClearance(track, city ? [city.group] : [track.obstacles, highway?.group].filter(Boolean));
if (import.meta.env?.DEV && track.clearance.intrusions.length) {
  console.warn(`[clearance] ${track.clearance.intrusions.length} samples where art intrudes on the road`,
    track.clearance.intrusions.slice(0, 12));
}

await phase(94, 'Rolling out the grid');
const particles = new Particles(engine.scene);
const rig = new CameraRig(engine.camera);
const hud = new HUD(document.getElementById('ui'));
const touch = isTouch ? new TouchControls(input, document.getElementById('ui')) : null;

const game = {
  engine, track, city, env, particles, rig, audio, hud, terrain, input, touch,
  karts: [], drivers: [], player: null, race: null, items: null,
  time: 0, hazards: [], state: 'menu',
};

/* --------------------------- field setup -------------------------- */
function buildField(playerCharIndex) {
  for (const k of game.karts) k.dispose?.();
  game.items?.dispose?.();
  game.karts.length = 0;
  game.drivers.length = 0;

  const order = [playerCharIndex, ...CHARACTERS.map((_, i) => i).filter((i) => i !== playerCharIndex)];
  for (let i = 0; i < FIELD; i++) {
    const ci = order[i % order.length];
    const isPlayer = i === 0;
    const kart = new Kart(engine.scene, CHARACTERS[ci], { isPlayer, index: i });
    game.karts.push(kart);
    if (!isPlayer) {
      const diff = 1 + Math.floor((i / FIELD) * 2.6);
      game.drivers.push(new AIDriver(kart, track, Math.min(3, diff)));
    }
  }
  game.player = game.karts[0];

  game.items = new ItemSystem(engine.scene, track, game.karts, particles);
  game.hazards = game.items.hazards;
  game.items.onEvent = onItemEvent;

  game.race = new Race(track, game.karts, { laps: course.laps, onEvent: onRaceEvent, introDuration: 5.5 });
}

/* ----------------------------- events ----------------------------- */
function onItemEvent(kind, kart) {
  const p = kart && (kart.position || (kart.isVector3 ? kart : null));
  const near = !!p && p.distanceTo(game.player.position) < 46;
  switch (kind) {
    case 'pickup': if (near) audio.pickup(); break;
    case 'itemReady': audio.itemReady(); break;
    case 'boost':
      if (near) audio.boost();
      if (kart === game.player) rig.addShake(0.35);
      break;
    case 'throw': if (near) audio.throwItem(); break;
    case 'hit':
      if (near) audio.hit();
      if (kart === game.player) { rig.addShake(0.9); hud.toast('¡Ay bendito!', 'bad'); }
      break;
    case 'explode': if (near) audio.explode(); break;
    case 'horn': if (near) audio.horn(); break;
    case 'star':
      if (kart === game.player) hud.toast('¡Vejigante!', 'good');
      if (near) audio.boost();
      break;
    case 'huracan':
      if (kart === game.player) hud.toast('¡Huracán!', 'good');
      audio.explode();
      rig.addShake(0.7);
      break;
  }
}

function onRaceEvent(kind, arg) {
  switch (kind) {
    case 'countdown': hud.countdown(arg); audio.count(arg); audio.setMusicState('countdown'); break;
    case 'go': hud.go(); audio.go(); audio.setMusicState('race'); break;
    case 'rocketStart':
      if (arg === game.player) { hud.toast('¡Salida cohete!', 'good'); rig.addShake(0.5); }
      break;
    case 'lap':
      if (arg === game.player) {
        const left = game.race.laps - arg.lap;
        hud.lapFlash(left === 1 ? 'FINAL LAP' : `LAP ${arg.lap + 1}`);
        audio.lap();
        if (left === 1) audio.setMusicState('finalLap');
      }
      break;
    case 'respawn':
      if (arg === game.player) hud.toast('Back on track', '');
      break;
    case 'finish':
      if (arg === game.player) { audio.setMusicState('finished'); audio.finish(); }
      break;
    case 'raceOver':
      game.state = 'results';
      setTimeout(() => { touch?.show(false); hud.results(game.race, game.player, restart); }, 2200);
      break;
  }
}

/* ------------------------------ flow ------------------------------ */
function startRace(charIndex) {
  buildField(charIndex);
  game.state = 'race';
  rig.reset?.();
  hud.showHUD();
  touch?.show(true);
  audio.init();
  audio.resume();
  audio.setMusicState('countdown');
}

function restart() {
  startRace(hud.selected);
}

hud.showTitle(() => {
  audio.init();
  audio.resume();
  audio.setMusicState('menu');
  hud.showCourses(COURSES, course.id, (id) => {
    if (id !== course.id) {
      // Different circuit: rebuild the world from scratch on the way in.
      location.search = `?course=${encodeURIComponent(id)}`;
      return;
    }
    hud.showSelect({ confirm: (i) => startRace(i) });
  });
});

/* --------------------------- simulation --------------------------- */
const CTRL_IDLE = { throttle: 0, brake: 0, steer: 0, drift: false, driftPressed: false };

function fixedUpdate(dt) {
  touch?.update(dt);
  input.update();
  game.time += dt;
  if (game.state === 'menu') {
    env.update(dt, new THREE.Vector3(0, 20, 0));
    return;
  }

  const race = game.race;
  race.update(dt);

  const racing = race.state === RaceState.RACING || race.state === RaceState.FINISHED;

  // player controls
  let ctrl = CTRL_IDLE;
  if (racing && !game.player.finished) {
    ctrl = { ...input.state, driftPressed: input.driftPressed };
    if (input.itemPressed) {
      const back = input.state.look ? -1 : 1;
      if (game.player.item) {
        game.items.use(game.player, back);
        audio.throwItem();
      }
    }
  } else if (race.state === RaceState.COUNTDOWN) {
    // rocket-start charge window
    if (input.state.throttle > 0) game.player.chargedStart += dt / Math.max(0.001, race.countdown + 0.35);
    ctrl = { ...CTRL_IDLE, steer: input.state.steer };
  } else if (game.player.finished) {
    // AI takes over once the player has crossed the line
    ctrl = game.playerAuto ? game.playerAuto.update(dt, game) : CTRL_IDLE;
  }

  const wasDrifting = game.player.drifting;
  const prevTier = game.player.driftTier;
  game.player.update(dt, ctrl, track);
  if (!wasDrifting && game.player.drifting) audio.hop();
  if (game.player.driftTier > prevTier) audio.drift();
  if (game.player.justBoosted) { audio.boost(); rig.addShake(0.25 * game.player.justBoosted); game.player.justBoosted = 0; }

  // AI
  for (const d of game.drivers) {
    let c = CTRL_IDLE;
    if (racing && !d.kart.finished) c = d.update(dt, game);
    else if (race.state === RaceState.COUNTDOWN) {
      d.kart.chargedStart = 0.6 + Math.random() * 0.5; // bots sometimes nail the start
    }
    d.kart.update(dt, c, track);
    d.kart.justBoosted = 0;
  }

  if (racing) game.items.update(dt);
  kartCollisions();
  if (traffic) {
    traffic.update(dt);
    for (const { kart, force } of traffic.collide(game.karts)) {
      if (kart === game.player) {
        rig.addShake(force * 0.55);
        audio.crash(force);
      }
      if (force > 0.8 && kart.spinOut(0.7)) onItemEvent('hit', kart);
    }
  }
  env.update(dt, game.player.position);
}

/** Elastic kart-vs-kart bumping. */
function kartCollisions() {
  const ks = game.karts;
  for (let a = 0; a < ks.length; a++) {
    for (let b = a + 1; b < ks.length; b++) {
      const A = ks[a], B = ks[b];
      const d = B.position.clone().sub(A.position);
      d.y = 0;
      const dist = d.length();
      const min = A.radius + B.radius;
      if (dist > min || dist < 1e-4) continue;
      const push = d.normalize().multiplyScalar((min - dist) * 0.5);
      A.position.sub(push);
      B.position.add(push);
      // heavier karts shove lighter ones around
      const mA = A.stats.weight, mB = B.stats.weight;
      const swap = (mB - mA) * 3.0;
      A.speed -= swap * 0.1;
      B.speed += swap * 0.1;
      A.lateral -= push.dot(A.right) * 26;
      B.lateral += push.dot(B.right) * 26;
      // a star-powered racer sends anyone it touches spinning
      if (A.starTime > 0 && B.starTime <= 0) { if (B.spinOut(1.4)) onItemEvent('hit', B); }
      else if (B.starTime > 0 && A.starTime <= 0) { if (A.spinOut(1.4)) onItemEvent('hit', A); }
      if (A === game.player || B === game.player) rig.addShake(0.12);
    }
  }
}

/* ----------------------------- visuals ---------------------------- */
function frameUpdate(dt) {
  if (game.state === 'menu') return;

  for (const k of game.karts) {
    k.syncVisual(dt);
    emitFx(k, dt);
  }

  particles.update(dt);
  rig.update(dt, game.player, { lookBack: input.state.look });
  engine.setSpeedFx(Math.min(1, Math.abs(game.player.speed) / 33 + (game.player.boostTime > 0 ? 0.35 : 0)));
  audio.update(dt, game.player);
  hud.update(dt, game);
}

function emitFx(k, dt) {
  const p = k.position;
  const back = k.forward.multiplyScalar(-1.05);
  const rgt = k.right;

  if (k.drifting && k.grounded && Math.abs(k.speed) > 6) {
    for (const s of [-1, 1]) {
      particles.driftSparks(
        p.x + back.x + rgt.x * s * 0.72, p.y + 0.16, p.z + back.z + rgt.z * s * 0.72,
        k.driftDir, k.driftTier, Math.abs(k.speed)
      );
    }
    if (Math.random() < dt * 30) {
      particles.tireSmoke(p.x + back.x, p.y + 0.14, p.z + back.z, 0.7);
    }
  }

  if (k.offroad && k.grounded && Math.abs(k.speed) > 4 && Math.random() < dt * 40) {
    particles.dust(p.x + back.x, p.y + 0.1, p.z + back.z);
  }

  if (k.boostTime > 0 && Math.random() < dt * 60) {
    for (const s of [-1, 1]) {
      particles.boostFlame(
        p.x + back.x * 1.2 + rgt.x * s * 0.4, p.y + 0.42, p.z + back.z * 1.2 + rgt.z * s * 0.4,
        -k.forward.x * 6, -k.forward.z * 6
      );
    }
  }

  if (k.starTime > 0 && Math.random() < dt * 40) {
    particles.sparkle(p.x, p.y + 0.6, p.z, new THREE.Color().setHSL((game.time * 1.4) % 1, 1, 0.6).getHex(), 1.4);
  }
}

engine.add(fixedUpdate, frameUpdate);
engine.start();

// place the camera somewhere flattering behind the start line for the menu
{
  const pose = track.startPose(0);
  engine.camera.position.copy(pose.position).add(new THREE.Vector3(0, 7, 0)).sub(pose.forward.clone().multiplyScalar(16));
  engine.camera.lookAt(pose.position.clone().add(new THREE.Vector3(0, 2, 0)));
}

/* Hold the loader until a frame has actually been composited — the first
 * render compiles every shader, which is the longest single stall of all. */
await phase(100, '¡Vámonos!');
await paint();
const bootEl = document.getElementById('boot');
if (bootEl) {
  bootEl.classList.add('done');
  setTimeout(() => bootEl.remove(), 600);
}

addEventListener('pointerdown', () => audio.resume(), { once: true });
addEventListener('keydown', () => audio.resume(), { once: true });
addEventListener('keydown', (e) => {
  if (e.code === 'KeyM' && !e.repeat) hud.setMuted(audio.toggleMute());
});
hud.onMuteToggle = () => hud.setMuted(audio.toggleMute());
hud.setMuted(audio.muted);

window.__game = game;
window.__ITEMS = ITEMS;
window.__THREE = THREE;
