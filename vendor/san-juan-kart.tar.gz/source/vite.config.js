/**
 * A relative base means the built site works from any path — the GitHub Pages
 * project URL (/old-san-juan-kart/), `vite preview`, or a plain file server —
 * without hard-coding the repository name.
 */
import { defineConfig } from 'vite';

/**
 * The MIT licence of three.js requires its copyright notice to travel with
 * "all copies or substantial portions of the Software", and the bundle we ship
 * is exactly that. Minification strips comments, so the notice is re-attached
 * as a banner that esbuild's `legalComments: 'inline'` setting preserves.
 */
const BANNER = `/*!
 * Old San Juan Kart — https://github.com/nasilvae/old-san-juan-kart
 * Copyright (c) 2026 Old San Juan Kart contributors. Released under the MIT licence.
 *
 * Bundles three.js — Copyright (c) 2010-2025 three.js authors — MIT licence.
 * https://github.com/mrdoob/three.js/blob/dev/LICENSE
 *
 * Full third-party notices: see THIRD-PARTY-NOTICES.md in the source repository.
 */`;

export default defineConfig({
  base: './',
  plugins: [
    {
      // `output.banner` is emitted before minification and gets stripped, so
      // the notice is prepended in `generateBundle`, which runs after it.
      name: 'legal-banner',
      enforce: 'post',
      generateBundle(_options, bundle) {
        for (const file of Object.values(bundle)) {
          if (file.type === 'chunk' && file.isEntry) file.code = `${BANNER}\n${file.code}`;
        }
      },
    },
  ],
  build: {
    // Top-level await in main.js (used to yield to the loading screen)
    // requires es2022. Safari 15+/iOS 15+ support it.
    target: 'es2022',
    chunkSizeWarningLimit: 1200,
  },
});
