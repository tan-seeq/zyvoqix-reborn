const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");
const root = path.resolve(__dirname, "game");
const noOpen = process.argv.includes("--no-open");
const portArg = process.argv.find((a) => a.startsWith("--port="));
let port = portArg ? Number(portArg.split("=")[1]) : 32189;
const defaultPort = port;
const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};
function openBrowser(url) {
  if (!noOpen) {
    const child = spawn("cmd.exe", ["/d", "/c", "start", "", url], {
      windowsHide: true,
      stdio: "ignore",
    });
    child.on("error", () =>
      console.log("Open this address in your browser: " + url),
    );
    child.unref();
  }
}
const server = http.createServer((req, res) => {
  if (!["GET", "HEAD"].includes(req.method)) {
    res.writeHead(405);
    return res.end();
  }
  if (req.url === "/__sushi_paws_health") {
    res.writeHead(200, { "Content-Type": "text/plain" });
    return res.end("Sushi-Paws-Portable-v1");
  }
  let pathname;
  try {
    pathname = decodeURIComponent(
      new URL(req.url, "http://localhost").pathname,
    );
  } catch {
    res.writeHead(400);
    return res.end("Bad request");
  }
  if (pathname.includes("\0") || pathname.includes("\\")) {
    res.writeHead(400);
    return res.end("Bad path");
  }
  const file = path.resolve(
    root,
    "." + (pathname === "/" ? "/index.html" : pathname),
  );
  if (!file.startsWith(root + path.sep)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404);
      return res.end("Not found");
    }
    res.writeHead(200, {
      "Content-Type": mime[path.extname(file)] || "application/octet-stream",
      "Content-Length": stat.size,
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    });
    if (req.method === "HEAD") return res.end();
    const stream = fs.createReadStream(file);
    stream.on("error", () => res.destroy());
    stream.pipe(res);
  });
});
server.on("error", (error) => {
  if (error.code !== "EADDRINUSE" || port >= defaultPort + 20) {
    console.error("Cannot start Sushi Paws:", error.message);
    process.exitCode = 1;
    return;
  }
  const probe = http.get(
    `http://127.0.0.1:${port}/__sushi_paws_health`,
    (response) => {
      let body = "";
      response.on("data", (data) => (body += data));
      response.on("end", () => {
        if (body === "Sushi-Paws-Portable-v1") {
          console.log("Sushi Paws is already open.");
          openBrowser(`http://127.0.0.1:${port}/`);
        } else {
          port++;
          server.listen(port, "127.0.0.1");
        }
      });
    },
  );
  probe.setTimeout(1000, () => probe.destroy());
  probe.on("error", () => {
    port++;
    server.listen(port, "127.0.0.1");
  });
});
server.on("listening", () => {
  const url = `http://127.0.0.1:${server.address().port}/`;
  console.log(
    "\n  SUSHI PAWS - CONVEYOR CLASH\n\n  " +
      url +
      "\n\n  Keep this window open while playing.\n  Close this window to stop the game server.\n",
  );
  openBrowser(url);
});
server.listen(port, "127.0.0.1");
