const { spawn, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");
const folder = path.resolve(process.argv[2]);
const launcher = path.join(folder, "PLAY SUSHI PAWS.bat");
const child = spawn(
  "cmd.exe",
  ["/d", "/s", "/c", `""${launcher}" --no-open --port=0"`],
  { windowsVerbatimArguments: true, windowsHide: true },
);
let output = "";
let done = false;
const timeout = setTimeout(
  () => finish(new Error("Launcher timed out: " + output)),
  15000,
);
function finish(error) {
  if (done) return;
  done = true;
  clearTimeout(timeout);
  spawnSync("taskkill", ["/pid", String(child.pid), "/t", "/f"], {
    windowsHide: true,
    stdio: "ignore",
  });
  if (error) {
    console.error(error);
    process.exitCode = 1;
  } else
    console.log(
      "PASS: bundled runtime, BAT launcher, all game assets, MIME types, 404 and method handling.",
    );
}
child.on("error", finish);
child.stderr.on("data", (b) => (output += b));
child.stdout.on("data", async (b) => {
  output += b;
  const match = output.match(/http:\/\/127\.0\.0\.1:\d+\//);
  if (!match || done || output.includes("__TESTING__")) return;
  output += "__TESTING__";
  try {
    const base = match[0];
    const html = await fetch(base);
    assert.equal(html.status, 200);
    assert.match(await html.text(), /Sushi Paws/);
    const assetDir = path.join(folder, "game", "assets");
    for (const name of fs.readdirSync(assetDir)) {
      const res = await fetch(base + "assets/" + name);
      assert.equal(res.status, 200, name);
      const bytes = Buffer.from(await res.arrayBuffer());
      assert.deepEqual(bytes, fs.readFileSync(path.join(assetDir, name)), name);
      if (name.endsWith(".js"))
        assert.match(res.headers.get("content-type"), /javascript/);
    }
    assert.equal((await fetch(base + "missing-file")).status, 404);
    assert.equal((await fetch(base, { method: "POST" })).status, 405);
    assert.equal(
      await (await fetch(base + "__sushi_paws_health")).text(),
      "Sushi-Paws-Portable-v1",
    );
    console.log(
      "Served " +
        fs.readdirSync(assetDir).length +
        " local assets from " +
        base,
    );
    finish();
  } catch (error) {
    finish(error);
  }
});
