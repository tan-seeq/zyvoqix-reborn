@echo off
setlocal
cd /d "%~dp0"
title Sushi Paws - Keep this window open while playing
if not exist "%~dp0runtime\node.exe" (
  echo Please extract the entire ZIP first, then open PLAY SUSHI PAWS.bat.
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0server.cjs" %*
if errorlevel 1 pause
