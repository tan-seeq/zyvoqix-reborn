// Assembles the portable Windows edition in releases/Sushi-Paws-Windows and
// zips it. Run `npm run build` first, then `npm run package:win`.
// Verify the result with `npm run smoke:win`.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawnSync } = require("node:child_process");

if (process.platform !== "win32") {
  console.error(
    "The portable edition bundles node.exe and must be built on Windows.",
  );
  process.exit(1);
}

const projectRoot = path.resolve(__dirname, "..");
const dist = path.join(projectRoot, "dist");
const releases = path.join(projectRoot, "releases");
const out = path.join(releases, "Sushi-Paws-Windows");
const zip = path.join(releases, "Sushi-Paws-Windows.zip");

if (!fs.existsSync(path.join(dist, "index.html"))) {
  console.error("dist/ not found. Run `npm run build` first.");
  process.exit(1);
}

fs.rmSync(out, { recursive: true, force: true });
fs.rmSync(zip, { force: true });
fs.rmSync(zip + ".sha256", { force: true });
fs.mkdirSync(out, { recursive: true });

fs.cpSync(dist, path.join(out, "game"), { recursive: true });
fs.cpSync(path.join(__dirname, "licenses"), path.join(out, "licenses"), {
  recursive: true,
});
for (const name of ["PLAY SUSHI PAWS.bat", "READ ME FIRST.txt", "server.cjs"]) {
  fs.copyFileSync(path.join(__dirname, name), path.join(out, name));
}
fs.mkdirSync(path.join(out, "runtime"));
fs.copyFileSync(process.execPath, path.join(out, "runtime", "node.exe"));

const zipResult = spawnSync(
  "powershell.exe",
  [
    "-NoProfile",
    "-Command",
    `Compress-Archive -Path '${out}' -DestinationPath '${zip}' -CompressionLevel Optimal -Force`,
  ],
  { stdio: "inherit", windowsHide: true },
);
if (zipResult.status !== 0) {
  console.error("Zip step failed.");
  process.exit(1);
}

const hash = crypto
  .createHash("sha256")
  .update(fs.readFileSync(zip))
  .digest("hex")
  .toUpperCase();
fs.writeFileSync(zip + ".sha256", `${hash}  Sushi-Paws-Windows.zip\n`);

const mb = (fs.statSync(zip).size / 1024 / 1024).toFixed(1);
console.log(`\nBuilt ${path.relative(projectRoot, out)}`);
console.log(`Zipped ${path.relative(projectRoot, zip)} (${mb} MB)`);
console.log(`SHA-256 ${hash}\n`);
console.log("Next: npm run smoke:win");
