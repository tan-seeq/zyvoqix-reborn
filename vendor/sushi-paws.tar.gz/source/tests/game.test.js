import { arrangeSelection } from "../src/systems/SelectionLayout.js";
import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "three";
import { award } from "../src/systems/ComboSystem.js";
import { SUSHI, CONFIG, CATS } from "../src/config.js";
import { AISystem } from "../src/systems/AISystem.js";
import { Game } from "../src/Game.js";
import { Cat } from "../src/entities/Cat.js";
import { Conveyor, chooseDish } from "../src/entities/Conveyor.js";
import {
  applyWasabi,
  applyCatnip,
  updateStatuses,
  movementDirection,
} from "../src/systems/StatusSystem.js";
const cat = () => ({
  root: { position: new THREE.Vector3() },
  velocity: new THREE.Vector2(),
  facing: 0,
  eating: 0,
  dash: 0,
  score: 0,
  eaten: 0,
  bestCombo: 0,
  combo: { category: null, count: 0, time: 0 },
});
test("chains increase, cap, change category, and expire", () => {
  const c = cat();
  assert.deepEqual(
    [0, 1, 2, 3, 4, 5].map((t) => award(c, SUSHI[0], t).points),
    [100, 125, 150, 200, 250, 250],
  );
  assert.equal(award(c, SUSHI[1], 6).points, 150);
  assert.equal(award(c, SUSHI[1], 11).count, 1);
  assert.equal(c.eaten, 8);
  assert.equal(c.bestCombo, 6);
});
test("lucky paw doubles value without mutating base sushi", () => {
  const c = cat();
  c.lucky = 4;
  assert.equal(award(c, SUSHI[8], 1).points, 600);
  assert.equal(SUSHI[8].value, 300);
});
test("movement respects arena boundary and friction", () => {
  const c = cat();
  for (let i = 0; i < 300; i++)
    Game.prototype.move.call({}, c, { x: 1, y: 0 }, 1 / 60);
  assert.ok(c.root.position.length() <= CONFIG.arenaRadius + 0.001);
  const speed = c.velocity.length();
  for (let i = 0; i < 60; i++)
    Game.prototype.move.call({}, c, { x: 0, y: 0 }, 1 / 60);
  assert.ok(c.velocity.length() < speed * 0.01);
});
test("eating requires forward cone and range, then consumes exactly one plate", () => {
  const c = new Cat(CATS[0]);
  const plates = [
    { type: SUSHI[0], group: { position: new THREE.Vector3(0, 1, -1) } },
    { type: SUSHI[1], group: { position: new THREE.Vector3(0, 1, 1) } },
  ];
  const consumed = [];
  const fake = {
    conveyor: {
      plates,
      consume: (p) => {
        consumed.push(p);
        p.type = null;
      },
    },
    elapsed: 0,
    sm: { state: "PLAYING" },
    completeBite: Game.prototype.completeBite,
    particles: { burst() {} },
    ui: { popup() {} },
  };
  Game.prototype.eat.call(fake, c);
  assert.equal(c.score, 0, "grabbing reserves the plate before the bite");
  assert.equal(consumed.length, 1);
  Game.prototype.eat.call(fake, c);
  assert.equal(consumed.length, 1);
  c.update(0.64, 0.64);
  assert.equal(c.score, 0);
  c.update(0.02, 0.66);
  assert.equal(c.score, 150);
  c.update(1, 1.66);
  assert.equal(c.score, 150, "one bite awards exactly once");
  assert.equal(c.heldFood.children.length, 0);
  c.dispose();
});
test("AI acquires an edible target and moves toward it", () => {
  const c = cat();
  c.index = 1;
  const p = { type: SUSHI[0], group: { position: new THREE.Vector3(4, 1, 0) } };
  const direction = new AISystem().update(c, [p], 0.016);
  assert.equal(c.target, p);
  assert.ok(direction.x > 0);
  assert.equal(direction.y, 0);
});

test("round completion ranks cats and persists milestone unlocks", () => {
  const player = cat();
  Object.assign(player, { score: 3200, eaten: 20, bestCombo: 4 });
  const opponent = cat();
  opponent.score = 2000;
  const fake = {
    cats: [opponent, player],
    player,
    save: { highScore: 500, bestCombo: 1, wins: 0, unlocked: [] },
    persist() {
      this.saved = true;
    },
    go(state) {
      this.state = state;
    },
    audio: { play() {} },
  };
  Game.prototype.finish.call(fake);
  assert.equal(fake.ranking[0], player);
  assert.equal(fake.state, "FINISHED");
  assert.equal(fake.save.wins, 1);
  assert.equal(fake.save.highScore, 3200);
  assert.equal(fake.save.unlocked.length, 4);
  assert.equal(fake.saved, true);
});

test("pause leaves simulation time unchanged", () => {
  const fake = {
    sm: { state: "PLAYING" },
    input: { update: () => ({ x: 0, y: 0 }), consume: () => false },
    paused: true,
    time: 10,
    elapsed: 5,
  };
  Game.prototype.update.call(fake, 1);
  assert.equal(fake.time, 10);
  assert.equal(fake.elapsed, 5);
});

test("wasabi overrides both player and AI steering, then restores control after five seconds", () => {
  for (const index of [0, 1]) {
    const c = cat();
    c.index = index;
    c.combo.count = 4;
    c.dash = 1;
    applyWasabi(c);
    assert.equal(c.wasabi, 5);
    assert.equal(c.dash, 0);
    assert.equal(c.combo.count, 0);
    // Keep a known panic turn in progress so this test is independent of RNG.
    c.panicTurn = 10;
    const requested =
      index === 0
        ? { x: 1, y: 0 }
        : new AISystem().update(
            c,
            [
              {
                type: SUSHI[0],
                group: { position: new THREE.Vector3(4, 1, 0) },
              },
            ],
            0.016,
          );
    const panic = movementDirection(c, requested, 0.016);
    assert.ok(Math.abs(panic.x) < 0.000001);
    assert.ok(panic.y < -0.99);
    Game.prototype.move.call({}, c, requested, 0.1);
    assert.ok(c.velocity.y < 0, "panic actually drives game movement");
    updateStatuses(c, 4.75);
    assert.equal(c.wasabi, 0.25);
    assert.notDeepEqual(movementDirection(c, requested, 0.01), requested);
    updateStatuses(c, 0.25);
    assert.equal(c.wasabi, 0);
    assert.equal(movementDirection(c, requested, 0.01), requested);
    updateStatuses(c, 1);
    assert.equal(c.wasabi, 0);
  }
});

test("catnip lasts fifteen seconds, refreshes without stacking, and increases movement speed", () => {
  const normal = cat(),
    boosted = cat();
  applyCatnip(boosted);
  assert.equal(boosted.catnip, 15);
  updateStatuses(boosted, 7);
  assert.equal(boosted.catnip, 8);
  applyCatnip(boosted);
  assert.equal(boosted.catnip, 15);
  applyCatnip(boosted);
  Game.prototype.move.call({}, normal, { x: 1, y: 0 }, 0.1);
  Game.prototype.move.call({}, boosted, { x: 1, y: 0 }, 0.1);
  assert.ok(
    Math.abs(
      boosted.velocity.x / normal.velocity.x - CONFIG.catnipSpeedMultiplier,
    ) < 1e-10,
  );
  updateStatuses(boosted, 14.75);
  assert.equal(boosted.catnip, 0.25);
  updateStatuses(boosted, 0.25);
  assert.equal(boosted.catnip, 0);
  boosted.velocity.set(0, 0);
  normal.velocity.set(0, 0);
  Game.prototype.move.call({}, normal, { x: 1, y: 0 }, 0.1);
  Game.prototype.move.call({}, boosted, { x: 1, y: 0 }, 0.1);
  assert.equal(boosted.velocity.x, normal.velocity.x);
});

test("every selected cat stays centered with the seven other cats evenly spaced on a circle", () => {
  const fake = {
    cats: [],
    save: { selected: 0 },
    scene: { scene: new THREE.Scene() },
  };
  for (let selected = 0; selected < CATS.length; selected++) {
    fake.save.selected = selected;
    Game.prototype.createCats.call(fake, true);
    assert.equal(fake.cats.length, 8);
    assert.equal(new Set(fake.cats.map((c) => c.data.name)).size, 8);
    assert.equal(fake.player.data, CATS[selected]);
    assert.equal(fake.player.root.position.length(), 0);
    const orbit = fake.cats.slice(1);
    const radius = orbit[0].root.position.length();
    for (let i = 0; i < orbit.length; i++) {
      const here = orbit[i].root.position,
        next = orbit[(i + 1) % orbit.length].root.position;
      assert.ok(Math.abs(here.length() - radius) < 1e-10);
      assert.ok(Math.abs(here.angleTo(next) - (Math.PI * 2) / 7) < 1e-10);
    }
  }
  fake.cats.forEach((c) => c.dispose());
});

test("wasabi red materials never leak to another cat and held sushi reaches the mouth once", () => {
  const a = new Cat(CATS[0]),
    b = new Cat(CATS[0]);
  const original = a.body.material;
  assert.equal(b.body.material, original);
  applyWasabi(a);
  a.update(0.01, 0.01);
  assert.notEqual(a.body.material, original);
  assert.equal(b.body.material, original);
  updateStatuses(a, 5);
  a.update(0.01, 5.01);
  assert.equal(a.body.material, original);
  let bites = 0;
  a.startEating(SUSHI[0], new THREE.Vector3(0, 0.76, 1.3), () => bites++);
  assert.equal(a.heldFood.children.length, 1);
  a.update(0.3, 5.31);
  assert.ok(a.paws[0].position.z > 0.8, "hands reach toward the food");
  a.update(0.4, 5.71);
  assert.ok(a.heldFood.position.distanceTo(a.foodMouth) < 0.01);
  assert.equal(bites, 1);
  a.update(1, 6.71);
  assert.equal(bites, 1);
  assert.equal(a.heldFood.visible, false);
  assert.equal(a.heldFood.children.length, 0);
  applyCatnip(a);
  a.update(0.01, 6.72);
  assert.equal(a.nipSparkles.visible, true);
  updateStatuses(a, 15);
  a.update(0.01, 21.72);
  assert.equal(a.nipSparkles.visible, false);
  a.dispose();
  b.dispose();
});

test("wasabi and catnip spawn, remain reachable from the arena, and apply only on a bite", () => {
  assert.equal(chooseDish(0.05).hazard, "wasabi");
  assert.equal(chooseDish(0.15).power, "catnip");
  const conveyor = new Conveyor(new THREE.Scene());
  conveyor.update(0, 0);
  for (const key of ["hazard", "power"]) {
    const plate = conveyor.plates.find((p) => p.type?.[key]);
    assert.ok(plate);
    const c = new Cat(CATS[0]);
    const position = plate.group.position;
    const radius = Math.hypot(position.x, position.z);
    c.root.position.set(
      (position.x / radius) * CONFIG.arenaRadius,
      0,
      (position.z / radius) * CONFIG.arenaRadius,
    );
    c.facing = Math.atan2(position.x, position.z);
    const fake = {
      conveyor,
      sm: { state: "PLAYING" },
      completeBite: Game.prototype.completeBite,
      ui: { popup() {} },
      particles: { burst() {} },
      audio: { play() {} },
    };
    Game.prototype.eat.call(fake, c);
    assert.equal(
      plate.type,
      null,
      "the cat can grab the dish from the arena edge",
    );
    assert.equal(c.wasabi, 0);
    assert.equal(c.catnip, 0);
    c.update(0.66, 0.66);
    assert.equal(
      key === "hazard" ? c.wasabi : c.catnip,
      key === "hazard" ? 5 : 15,
    );
    assert.equal(c.score, 0, "hazards and powerups do not award sushi points");
    c.dispose();
  }
});

test("unselected cats walk an evenly spaced orbit while the chosen cat stays centered", () => {
  const cats = CATS.map((data, i) => new Cat(data, i));
  arrangeSelection(cats, 0);
  const initial = cats[1].root.position.clone();
  arrangeSelection(cats, 3);
  assert.equal(cats[0].root.position.length(), 0);
  assert.equal(cats[0].velocity.length(), 0);
  assert.ok(cats[1].root.position.distanceTo(initial) > 1);
  cats.slice(1).forEach((c) => {
    assert.ok(Math.abs(c.root.position.length() - 3.05) < 0.001);
    assert.ok(c.velocity.length() > 0.6);
  });
  cats.forEach((c) => c.dispose());
});
