# Sushi Paws: Conveyor Clash 🍣🐾

A cozy, chaotic 3D cat sushi party game. Pick one of eight cats and out-eat three AI diners on a spinning conveyor in a 75-second round.

Made by **[@clydejuniordev](https://x.com/clydejuniordev)** · [GitHub](https://github.com/clydejuniorscripts) · [X / Twitter](https://x.com/clydejuniordev)

Built with Three.js, ES modules, Vite, CSS, and synthesized Web Audio. Every model, texture, and sound is generated procedurally in code. No proprietary game assets, external model files, or image hotlinks are used, and fonts are bundled locally. Licensed under MIT.

## Play

**In the browser (development):** requires Node.js 22.12 or newer.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite.

**Production build:**

```sh
npm run build
npm run preview
```

`dist/` is a fully static site and can be served by any static web host. To host at a sub-path (for example GitHub Pages at `https://<user>.github.io/<repo>/`), set `BASE_PATH=/<repo>/` when building. The included `.github/workflows/deploy-pages.yml` does this automatically on every push to `main` once GitHub Pages is set to deploy from GitHub Actions in the repository settings.

**Portable Windows edition (no install, no internet):**

```sh
npm run build
npm run package:win
npm run smoke:win
```

This produces `releases/Sushi-Paws-Windows.zip` plus a SHA-256 file. The zip contains the built game, a tiny local-only HTTP server, a private copy of `node.exe`, third-party licenses, and a `PLAY SUSHI PAWS.bat` launcher. Recipients extract the zip and double-click the launcher; the game opens in their default browser and is served only on `127.0.0.1`. See `packaging/READ ME FIRST.txt` for the player-facing instructions. The smoke test launches the bundle and verifies every asset is served with the right MIME type.

## Tests

```sh
npm test
```

Runs the gameplay regression suite in `tests/` with the built-in Node test runner: movement and boundaries, eating cone and range, AI targeting, round ranking and unlock persistence, pause behaviour, wasabi and catnip timers, material isolation, and all eight character-select layouts.

For repeatable manual interaction checks during development, open `/tests/visual.html` from the dev server and use **Grab tuna**, **Eat wasabi**, or **Eat catnip**. This fixture is excluded from the production build.

## Controls

| Action            | Keyboard          | Gamepad        | Touch            |
| ----------------- | ----------------- | -------------- | ---------------- |
| Move              | WASD / arrow keys | Left stick     | Virtual joystick |
| Eat               | Space             | A              | EAT              |
| Dash              | Shift             | B              | DASH             |
| Pause / resume    | Escape / P        | Start          | Pause icon       |
| Restart           | R                 | Results button | Results button   |
| Performance panel | F or `?debug=1`   | —              | —                |

Move toward the inner edge of the conveyor and face a plate. Tap Eat when within reach. Your cat reaches with both paws, lifts the food, and takes a bite; scoring and food effects begin at the bite, 0.65 seconds into the 1.1-second animation. The mint-blue ring identifies your cat. Dash recharges in 2.2 seconds. Arrow keys / gamepad stick also change cats in the menu; Space / A advances the menu, instructions, and results. Buttons support mouse and keyboard focus.

## How it plays

**Chains.** Matching the exact sushi category within four seconds awards multipliers of ×1, ×1.25, ×1.5, ×2, and ×2.5. The multiplier caps at ×2.5 while the chain count can keep rising. Changing category or waiting too long resets it. Empty plates refill in one to three seconds.

**Wasabi.** The green mound is a hazard. Eating it makes either a player or AI cat turn red and run uncontrollably for five seconds. It breaks the combo and awards no points. Movement and eating return automatically when the effect ends.

**Catnip.** Leafy sprigs with a lavender bow give any cat a 1.65× movement-speed boost for 15 seconds, with orbiting sparkles. Another pickup refreshes the timer without stacking the multiplier.

**Spawn rates.** Wasabi 9%, catnip 8%, golden sushi 3%, normal sushi 80%. One wasabi and one catnip dish are included in the initial conveyor.

**House specials** automatically activate at 9 seconds and every 15 seconds thereafter: speed, double points, extended magnetic eating reach, opponent slowdown, or a 500-point bonus. The HUD describes the current bonus. Three AI personalities favor value, matching categories, or less predictable choices.

**Rounds** show countdown, gameplay, final-ten-second warning, time-up, and ranked results. Results include scores, sushi eaten, best chains, plates collected, saved personal best, and total wins. Pause freezes simulation; hiding the tab automatically pauses a match.

**Restaurant.** A pastel sushi restaurant with blush pink, cream wood and rose accents. During character selection the selected cat stays centered while the other seven walk an evenly spaced circle around it. Raised 3D lettering, a prep counter, pantry jars, chopsticks, rice tubs, and paw-print noren curtains decorate the scene.

## Project structure

```
index.html              entry page
vite.config.js          build config (BASE_PATH support, three.js chunk)
src/
  main.js               bootstrap, bundled fonts, stylesheet
  Game.js               match orchestration, movement, round flow, camera, save data
  config.js             cats, sushi values, match settings, cosmetic definitions
  core/
    SceneManager.js     renderer, lighting, restaurant and conveyor environment
    InputManager.js     keyboard, gamepad, and touch input state
    AudioManager.js     procedural music and named sound events
    StateMachine.js     BOOT, MENU, CHARACTER_SELECT, HOW_TO_PLAY, COUNTDOWN, PLAYING, FINISHED, RESULTS
  entities/
    Cat.js              procedural cat rig, accessories, animation
    Sushi.js            procedural sushi models
    Conveyor.js         moving plates, spawning, consumption, respawn
    RestaurantLogo.js   raised 3D sign lettering
    geometry.js         shared geometry/material caches and sign textures
  systems/
    AISystem.js         target evaluation and movement decisions
    ComboSystem.js      scoring, chains, statistics
    StatusSystem.js     wasabi panic, control override, catnip speed, status timers
    SelectionLayout.js  centered selected cat and evenly spaced preview ring
    ParticleSystem.js   pooled particle effects
  ui/UIManager.js       menu, selection, instructions, HUD, dialogs, results, touch joystick
  styles/main.css       responsive presentation and CSS effects
tests/
  game.test.js          core gameplay regression tests
  visual.html           manual interaction fixture (dev only)
packaging/
  build-windows.cjs     assembles and zips the portable Windows edition
  server.cjs            local-only static server used by the portable edition
  smoke-test.cjs        launches the bundle and verifies every served asset
  PLAY SUSHI PAWS.bat   player launcher
  READ ME FIRST.txt     player instructions
  licenses/             third-party licenses shipped with the portable edition
.github/workflows/
  ci.yml                test + build on every push and pull request
  deploy-pages.yml      publish the build to GitHub Pages
```

The persistent restaurant and pooled particles are reused across screens; changing cats removes old character roots while retaining shared geometry and materials.

## Customization

**Models:** Replace the procedural construction in `Cat.js` and `Sushi.js` with GLTFLoader assets. Keep Cat's root, velocity, facing, animation interface, and score fields. Adapt `update()` to AnimationMixer clips. Authored assets should face positive Z, use Y-up, and fit the existing approximate 1.8-unit cat height.

**Audio:** Add licensed files under `public/audio/`, load/decode them in AudioManager, and replace the synthesis in `play(name)` with AudioBufferSource playback. Named events include hover, click, eat, combo, golden, power, countdown, go, and winner. `update()` provides the menu/gameplay music bed. Browser audio begins after the first gesture.

**Balance:** Change `SUSHI` values and `CONFIG.duration` in `src/config.js`. Speed, interaction radius, dash cooldown, plate count, and conveyor rate live there as well.

**Cosmetics:** Definitions live in `COSMETICS`; visual attachments are in `Cat.equip()`. Earn Chef Hat with 10 sushi in one round, Sakura Collar with a chain of 3, Tiny Sunglasses with one win, and Golden Bell with 3,000 points. Equip unlocked accessories from the menu. There are no payment systems.

**Saves:** The `sushi-paws-v1` localStorage record contains selected cat, sound setting, high score, best combo, wins, unlocked cosmetics, and the equipped accessory. Storage failures do not prevent gameplay.

## Scope

Solo versus three AI is implemented. Local multiplayer, PWA installation, GLB assets, and postprocessing bloom/SSAO are not included. The scene uses warm physically based lighting, soft shadow maps, tone mapping, and fog without a postprocessing pass.

The implementation targets 60 FPS with capped device pixel ratio, shared geometries and materials, pooled particles, and HUD updates at roughly 12 Hz. Performance depends on hardware.

## Credits

- **Design & code:** [Clyde Junior (@clydejuniordev)](https://x.com/clydejuniordev) · [github.com/clydejuniorscripts](https://github.com/clydejuniorscripts)
- **Three.js** (MIT) for rendering.
- **Outfit** and **DM Sans** fonts (SIL Open Font License 1.1), bundled via Fontsource.
- The portable Windows edition bundles **Node.js** (MIT-style license). All third-party licenses are in `packaging/licenses/`.

## License

MIT. See [LICENSE](LICENSE).
