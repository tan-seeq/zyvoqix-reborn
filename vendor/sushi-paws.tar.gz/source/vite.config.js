import { defineConfig } from "vite";

// BASE_PATH lets the same build be hosted at a sub-path (e.g. GitHub Pages
// serves the site at https://<user>.github.io/<repo>/). Defaults to "/".
export default defineConfig({
  base: process.env.BASE_PATH || "/",
  build: {
    rollupOptions: { output: { manualChunks: { three: ["three"] } } },
    chunkSizeWarningLimit: 650,
  },
});
