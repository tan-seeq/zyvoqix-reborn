import { CATS, SUSHI, COSMETICS, CONFIG } from "../config.js";
export function portrait(cat) {
  return `<svg viewBox="0 0 100 90" aria-hidden="true"><path d="M18 39L15 9Q31 9 40 27L62 27Q73 10 86 9L82 44" fill="${cat.fur}"/><path d="M23 30L21 17L35 31M67 31L80 17L78 34" fill="#d98f93"/><ellipse cx="50" cy="53" rx="37" ry="30" fill="${cat.fur}"/><path d="M42 25L45 38M52 24L53 37M62 27L60 39" stroke="${cat.patch}" stroke-width="5" stroke-linecap="round"/><ellipse cx="35" cy="50" rx="4" ry="6" fill="${cat.eyes}"/><ellipse cx="66" cy="50" rx="4" ry="6" fill="${cat.eyes}"/><circle cx="34" cy="48" r="1.4" fill="white"/><circle cx="65" cy="48" r="1.4" fill="white"/><ellipse cx="42" cy="64" rx="10" ry="7" fill="#fff0d5"/><ellipse cx="58" cy="64" rx="10" ry="7" fill="#fff0d5"/><path d="M46 58Q50 55 54 58L50 62Z" fill="#a66570"/><path d="M50 62V66M50 66Q45 71 42 66M50 66Q55 71 58 66" fill="none" stroke="#67524b" stroke-width="1.5"/><path d="M13 58L29 61M12 67L29 65M73 61L90 57M73 65L91 68" stroke="#765e51" stroke-width="1.5"/></svg>`;
}
export class UIManager {
  constructor(game) {
    this.g = game;
    this.root = document.querySelector("#app");
    this.overlay = null;
  }
  button(text, action, cls = "") {
    return `<button class="${cls}" data-action="${action}">${text}</button>`;
  }
  render() {
    const g = this.g,
      state = g.sm.state;
    this.root.innerHTML = `<div class="vignette"></div><header class="topbar"><a class="wordmark" href="#" data-action="menu"><span class="brand-icon">✿</span> SUSHI PAWS<span class="edition">CONVEYOR CLASH</span></a><div class="top-actions"><span class="status-dot"></span><span>THE RESTAURANT IS OPEN</span>${this.button(g.save.sound ? "♫" : "♪", "sound", "icon-button")}</div></header><div id="screen"></div><div id="popups"></div><div id="flash"></div><div id="debug"></div>`;
    const screen = this.root.querySelector("#screen");
    if (state === "MENU" || state === "CHARACTER_SELECT") {
      const selected = CATS[g.save.selected];
      screen.innerHTML = `<main class="menu"><div class="eyebrow"><span></span> A LITTLE COZY. A LITTLE CHAOTIC.</div><h1>Sushi<span>Paws<span class="title-flower">✿</span></span></h1><div class="subtitle">C O N V E Y O R &nbsp; C L A S H</div><p class="intro">Four cats. One conveyor.<br>A seriously good time.</p><div class="select-heading"><span>CHOOSE YOUR DINNER DATE</span><span>01 — 08</span></div><div class="cat-grid">${CATS.map((c, i) => `<button class="cat-card ${i === g.save.selected ? "selected" : ""}" data-cat="${i}" style="--cat-accent:${c.accent}" aria-label="Select ${c.name}" aria-pressed="${i === g.save.selected}">${portrait(c)}<span>${c.name}</span>${i === g.save.selected ? "<b>1P</b>" : ""}</button>`).join("")}</div><div class="selected-note"><span class="tiny-star">✦</span><b>${selected.name}</b><span>${selected.title}</span></div>${this.button("LET’S EAT <span>↗</span>", "start", "primary play")}<div class="secondary-row">${this.button("How to play", "help")}${this.button('Cosmetics <span class="new-dot">•</span>', "cosmetics")}${this.button("Settings", "settings")}</div><div class="menu-bottom"><span>SOLO + 3 AI FRIENDS</span><span>75 SECONDS OF SUSHI</span></div></main><div class="scene-caption"><span class="live-tag">FRESH OFF THE BELT</span><h2>Your table is ready.</h2><p>A cozy little clash of appetites.</p><div class="scene-pills"><span>✦ 8 unique cats</span><span>◉ Sushi, wasabi & catnip</span></div></div><footer><span>MADE BY <a class="credit" href="https://x.com/clydejuniordev" target="_blank" rel="noopener">@CLYDEJUNIORDEV</a></span><span>KEYBOARD · GAMEPAD · TOUCH <i>✦</i></span></footer>`;
    }
    if (state === "HOW_TO_PLAY") {
      screen.innerHTML = `<main class="help panel"><div class="eyebrow">THE HOUSE RULES</div><h2>Good food. Fast paws.</h2><p>Outsnack three rivals before the 75-second timer runs out.</p><div class="instructions"><article><b>01</b><h3>Find your bite</h3><p>Move with WASD, arrows, or the left stick. Get close to the belt and face a plate.</p></article><article><b>02</b><h3>Dig in</h3><p>Tap Space or gamepad A to eat. Shift or B dashes. Touch controls appear on mobile.</p></article><article><b>03</b><h3>Keep it matching</h3><p>Eat the same sushi within 4 seconds to build a chain, up to ×2.5 points.</p></article></div><div class="sushi-values">${SUSHI.map((s) => `<div><span style="--sushi:${s.color}" class="sushi-mini ${s.shape}"></span><b>${s.name}</b><small>${s.hazard ? "5s chaos" : s.power === "catnip" ? "15s speed" : s.value + " pts"}</small></div>`).join("")}</div><p class="fine">Watch the green bites: wasabi makes any cat turn red and run out of control for 5 seconds. Catnip sprigs with a purple bow give 15 seconds of extra speed. House specials also arrive during the round.</p><div class="dialog-actions">${this.button("Back to menu", "menu")}${this.button("GOT IT. LET’S EAT ↗", "play", "primary")}</div></main>`;
    }
    if (["PLAYING", "COUNTDOWN", "FINISHED"].includes(state)) {
      screen.innerHTML = `<div class="hud"><div class="player-score panel">${portrait(g.player.data)}<div><small>1P · ${g.player.data.name.toUpperCase()}</small><strong id="score">0</strong><span id="combo">Find your first bite</span></div></div><div class="clock panel"><small>TIME LEFT</small><strong id="timer">01:15</strong></div><div class="leaderboard panel"><small>THE PECKING ORDER</small><div id="ranks"></div></div></div><div id="countdown"></div><div class="game-bottom"><div class="power panel" id="power">✦ HOUSE SPECIAL <span>A little luck is on its way</span></div><div class="controls panel"><span><kbd>W A S D</kbd> Move</span><span><kbd>SPACE</kbd> Eat</span><span><kbd>SHIFT</kbd> Dash</span>${this.button("Ⅱ", "pause", "icon-button")}</div></div><div class="touch-controls"><button class="touch-pause" data-action="pause" aria-label="Pause game">Ⅱ</button><div id="joystick"><span></span></div><div>${this.button("DASH", "dash", "touch-dash")}${this.button("EAT", "eat", "touch-eat")}</div></div>`;
    }
    if (state === "RESULTS") {
      const winner = g.ranking[0];
      screen.innerHTML = `<main class="results panel"><div class="eyebrow">THAT WAS DELICIOUS</div><h2>${winner === g.player ? "1P WINS!" : `${winner.data.name.toUpperCase()} WINS!`}</h2><p>${winner === g.player ? "A round of a-paws for the chef." : "One more round? Your next feast is waiting."}</p><div class="result-ranking">${g.ranking.map((cat, i) => `<div class="result-row ${cat === g.player ? "you" : ""}"><b>${["✦", "02", "03", "04"][i]}</b>${portrait(cat.data)}<span><strong>${cat.data.name} ${cat === g.player ? "<em>YOU</em>" : ""}</strong><small>${cat.eaten} sushi · best chain ${cat.bestCombo}</small></span><strong>${cat.score.toLocaleString()}</strong></div>`).join("")}</div><div class="stats"><span><b>${g.player.eaten}</b>PLATES COLLECTED</span><span><b>${g.save.highScore.toLocaleString()}</b>PERSONAL BEST</span><span><b>${g.save.wins}</b>TOTAL WINS</span></div>${g.newUnlocks.length ? `<p class="unlock">✦ Unlocked: ${g.newUnlocks.join(", ")}</p>` : ""}${this.button("ANOTHER ROUND ↗", "play", "primary play")}<div class="secondary-row">${this.button("Character select", "cats")}${this.button("Main menu", "menu")}</div></main><div class="confetti">${Array.from({ length: 36 }, (_, i) => `<i style="--x:${i * 2.8}%;--d:${(i % 7) * 0.3}s;--c:${["#eaaa6c", "#bdd8a4", "#eda8aa"][i % 3]}"></i>`).join("")}</div>`;
    }
    if (g.paused)
      this.dialog(
        "Taking a catnap.",
        `${this.button("Resume", "pause", "primary")}${this.button("Restart round", "play")}${this.button("Main menu", "menu")}${this.button(g.save.sound ? "Sound: on" : "Sound: off", "sound")}`,
      );
    this.bind();
  }
  bind() {
    this.root.querySelectorAll("[data-action]").forEach(
      (b) =>
        (b.onclick = (e) => {
          e.preventDefault();
          this.action(b.dataset.action);
        }),
    );
    this.root.querySelectorAll("[data-cat]").forEach(
      (b) =>
        (b.onclick = () => {
          this.g.audio.unlock();
          this.g.audio.play("click");
          this.g.select(Number(b.dataset.cat));
        }),
    );
    const joy = this.root.querySelector("#joystick");
    if (joy) {
      const set = (e) => {
        const r = joy.getBoundingClientRect();
        let x = (e.clientX - r.left - r.width / 2) / 40,
          y = (e.clientY - r.top - r.height / 2) / 40;
        const l = Math.max(1, Math.hypot(x, y));
        x /= l;
        y /= l;
        this.g.input.touch = { x, y };
        joy.firstChild.style.transform = `translate(${x * 30}px,${y * 30}px)`;
      };
      joy.onpointerdown = (e) => {
        joy.setPointerCapture(e.pointerId);
        set(e);
      };
      joy.onpointermove = (e) => {
        if (joy.hasPointerCapture(e.pointerId)) set(e);
      };
      joy.onpointerup = joy.onpointercancel = () => {
        this.g.input.touch = { x: 0, y: 0 };
        joy.firstChild.style.transform = "";
      };
    }
  }
  action(action) {
    const g = this.g;
    g.audio.unlock();
    g.audio.play("click");
    if (action === "start") {
      if (!g.save.learned) {
        g.save.learned = true;
        g.persist();
        g.go("HOW_TO_PLAY");
      } else g.start();
    }
    if (action === "play") g.start();
    if (action === "menu") g.go("MENU");
    if (action === "cats") g.go("CHARACTER_SELECT");
    if (action === "help") g.go("HOW_TO_PLAY");
    if (action === "pause") g.pause();
    if (action === "eat") g.input.tap("Space");
    if (action === "dash") g.input.tap("ShiftLeft");
    if (action === "sound") {
      g.save.sound = !g.save.sound;
      g.audio.enabled = g.save.sound;
      g.persist();
      this.render();
    }
    if (action === "settings") {
      this.dialog(
        "Make yourself at home.",
        `<p>Sound is ${g.save.sound ? "on" : "off"}. Your progress saves automatically on this device.</p>${this.button("Toggle sound", "sound")}${this.button("Back", "close", "primary")}<p class="fine">High score ${g.save.highScore.toLocaleString()} · ${g.save.wins} wins<br>Escape / P pauses · R restarts · F shows performance</p>`,
      );
      this.bind();
    }
    if (action === "close") this.render();
    if (action === "cosmetics") {
      this.dialog(
        "A little extra purr-sonality.",
        `<p>Earn accessories by playing, then choose one to wear.</p><div class="cosmetic-list">${COSMETICS.map((c) => this.button(`<strong>${g.save.unlocked.includes(c.id) ? "✦" : "♧"} ${c.name}</strong><small>${g.save.equipped === c.id ? "Equipped" : c.description}</small>`, g.save.unlocked.includes(c.id) ? `equip-${c.id}` : "locked", g.save.unlocked.includes(c.id) ? "available" : "locked")).join("")}</div>${this.button("No accessory", "equip-none")}${this.button("Done", "close", "primary")}`,
      );
      this.bind();
    }
    if (action.startsWith("equip-")) {
      g.save.equipped = action.slice(6) === "none" ? null : action.slice(6);
      g.player.equip(g.save.equipped);
      g.persist();
      this.action("cosmetics");
    }
  }
  dialog(title, body) {
    this.root.querySelector(".modal-backdrop")?.remove();
    const el = document.createElement("div");
    el.className = "modal-backdrop";
    el.innerHTML = `<section class="dialog panel" role="dialog" aria-modal="true"><div class="eyebrow">SUSHI PAWS</div><h2>${title}</h2>${body}</section>`;
    this.root.append(el);
  }
  update() {
    const g = this.g;
    const score = this.root.querySelector("#score");
    if (score) {
      score.textContent = g.player.score.toLocaleString();
      this.root.querySelector("#combo").textContent =
        g.player.combo.count > 1
          ? `${g.player.combo.category} chain ×${g.player.combo.count}`
          : "Matching bites = more points";
      const remaining = Math.ceil(g.remaining);
      const timer = this.root.querySelector("#timer");
      timer.textContent = `${String(Math.floor(remaining / 60)).padStart(2, "0")}:${String(remaining % 60).padStart(2, "0")}`;
      timer.classList.toggle("urgent", remaining <= 10);
      this.root.querySelector("#ranks").innerHTML = [...g.cats]
        .sort((a, b) => b.score - a.score)
        .map(
          (c, i) =>
            `<div class="rank ${c === g.player ? "current" : ""}"><span>${i + 1}</span><b>${c.data.name}${c.wasabi > 0 ? " · HOT!" : c.catnip > 0 ? " · NIP" : ""}</b><strong>${c.score.toLocaleString()}</strong></div>`,
        )
        .join("");
      const counter = this.root.querySelector("#countdown");
      counter.textContent =
        g.sm.state === "COUNTDOWN"
          ? Math.ceil(g.countdown) > 3
            ? "READY?"
            : Math.ceil(g.countdown)
          : g.sm.state === "FINISHED"
            ? "TIME!"
            : g.elapsed < 0.65
              ? "GO!"
              : "";
      const power = this.root.querySelector("#power");
      power.innerHTML =
        g.player.wasabi > 0
          ? `♨ WASABI PANIC <span>${g.player.wasabi.toFixed(1)}s · Paws are out of control!</span>`
          : g.player.catnip > 0
            ? `✦ CATNIP ZOOMIES <span>${Math.ceil(g.player.catnip)}s · Speed boost active</span>`
            : g.power?.time > 0
              ? `✦ ${g.power.name.toUpperCase()} <span>${Math.ceil(g.power.time)}s remaining</span>`
              : `✦ HOUSE SPECIAL <span>Next bonus in ${Math.ceil(g.powerClock)}s · Dash ${g.player.cooldown > 0 ? g.player.cooldown.toFixed(1) + "s" : "ready"}</span>`;
    }
    this.root.querySelector("#debug").textContent = g.debug
      ? `${Math.round(g.fps)} FPS | ${g.sm.state} | sushi ${g.conveyor.plates.filter((p) => p.type).length} | speed ${g.player.velocity.length().toFixed(1)} | chain ${g.player.combo.count}\nAI: ${g.cats
          .slice(1)
          .map((c) => c.target?.type?.name || "searching")
          .join(", ")}`
      : "";
  }
  popup(cat, text, sub) {
    const p = cat.root.position.clone();
    p.y += 2;
    p.project(this.g.scene.camera);
    const el = document.createElement("div");
    el.className = "score-popup";
    el.style.left = `${(p.x * 0.5 + 0.5) * innerWidth}px`;
    el.style.top = `${(-p.y * 0.5 + 0.5) * innerHeight}px`;
    el.innerHTML = `<small>${sub}</small><strong>${text}</strong>`;
    this.root.querySelector("#popups").append(el);
    setTimeout(() => el.remove(), 1000);
  }
  flash() {
    const el = this.root.querySelector("#flash");
    el.classList.remove("active");
    requestAnimationFrame(() => el.classList.add("active"));
  }
}
