import "@fontsource/outfit/latin-900.css";
import "@fontsource/outfit/latin-700.css";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-700.css";
import { Game } from "./Game.js";
import "./styles/main.css";
try {
  window.sushiPaws = new Game();
} catch (error) {
  document.querySelector("#app").innerHTML =
    '<div class="error">The restaurant could not open. Please enable WebGL and reload.</div>';
  console.error(error);
}
