import * as THREE from "three";
import { CONFIG, CATS, COSMETICS } from "./config.js";
import { SceneManager } from "./core/SceneManager.js";
import { StateMachine } from "./core/StateMachine.js";
import { InputManager } from "./core/InputManager.js";
import { AudioManager } from "./core/AudioManager.js";
import { Cat } from "./entities/Cat.js";
import { Conveyor } from "./entities/Conveyor.js";
import { ParticleSystem } from "./systems/ParticleSystem.js";
import { AISystem } from "./systems/AISystem.js";
import { award } from "./systems/ComboSystem.js";
import { UIManager } from "./ui/UIManager.js";
import {
  applyWasabi,
  applyCatnip,
  updateStatuses,
  movementDirection,
} from "./systems/StatusSystem.js";
import { arrangeSelection } from "./systems/SelectionLayout.js";
const playerMarkerGeometry = new THREE.RingGeometry(0.58, 0.67, 40);
const playerMarkerMaterial = new THREE.MeshBasicMaterial({
  color: "#78ceef",
  side: THREE.DoubleSide,
});
export class Game {
  constructor() {
    try {
      this.save = JSON.parse(localStorage.getItem("sushi-paws-v1")) || {};
    } catch {
      this.save = {};
    }
    this.save = {
      selected: 0,
      sound: true,
      highScore: 0,
      bestCombo: 0,
      wins: 0,
      unlocked: [],
      equipped: null,
      ...this.save,
    };
    this.save.selected = Math.max(
      0,
      Math.min(7, Number(this.save.selected) || 0),
    );
    this.sm = new StateMachine();
    this.scene = new SceneManager();
    this.input = new InputManager();
    this.audio = new AudioManager(this.save.sound);
    this.conveyor = new Conveyor(this.scene.scene);
    this.particles = new ParticleSystem(this.scene.scene);
    this.ai = new AISystem();
    this.cats = [];
    this.elapsed = 0;
    this.time = 0;
    this.paused = false;
    this.debug = new URLSearchParams(location.search).has("debug");
    this.createCats(true);
    this.ui = new UIManager(this);
    this.go("MENU");
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && ["PLAYING", "COUNTDOWN"].includes(this.sm.state))
        this.pause(true);
    });
    this.last = performance.now();
    requestAnimationFrame((t) => this.frame(t));
  }
  persist() {
    try {
      localStorage.setItem("sushi-paws-v1", JSON.stringify(this.save));
    } catch {
      /* Private browsing may disable persistence. */
    }
  }
  createCats(preview = false) {
    this.cats.forEach((c) => {
      this.scene.scene.remove(c.root);
      c.dispose?.();
    });
    const ids = [
      this.save.selected,
      ...CATS.map((_, i) => i)
        .filter((i) => i !== this.save.selected)
        .slice(0, preview ? 7 : 3),
    ];
    this.cats = ids.map((id, i) => {
      const cat = new Cat(CATS[id], i);
      const a = Math.PI / 2 + (i * Math.PI) / 2;
      cat.root.position.set(Math.cos(a) * 3.25, 0, Math.sin(a) * 3.25);
      cat.facing = Math.atan2(cat.root.position.x, cat.root.position.z);
      this.scene.scene.add(cat.root);
      if (i === 0) cat.equip(this.save.equipped);
      return cat;
    });
    this.player = this.cats[0];
    const marker = new THREE.Mesh(playerMarkerGeometry, playerMarkerMaterial);
    marker.rotation.x = -Math.PI / 2;
    marker.position.y = 0.09;
    this.player.root.add(marker);
    if (preview) arrangeSelection(this.cats);
  }
  select(i) {
    this.save.selected = i;
    this.persist();
    this.createCats(true);
    this.ui.render();
  }
  go(state) {
    this.paused = false;
    this.input.clear();
    this.sm.set(state);
    if (["MENU", "CHARACTER_SELECT"].includes(state)) this.createCats(true);
    this.ui.render();
  }
  start() {
    this.audio.unlock();
    this.createCats();
    this.elapsed = 0;
    this.remaining = CONFIG.duration;
    this.countdown = 3.8;
    this.lastCount = 4;
    this.powerClock = 9;
    this.power = null;
    this.go("COUNTDOWN");
  }
  pause(value = !this.paused) {
    if (!["PLAYING", "COUNTDOWN"].includes(this.sm.state)) return;
    this.paused = value;
    this.input.clear();
    this.ui.render();
  }
  move(cat, dir, dt) {
    dir = movementDirection(cat, dir, dt);
    let x = dir.x,
      y = dir.y;
    const max =
      CONFIG.speed *
      (cat.dash > 0 ? 2.5 : 1) *
      (cat.catnip > 0 ? CONFIG.catnipSpeedMultiplier : 1) *
      (cat.wasabi > 0 ? 1.35 : 1) *
      (cat.stun > 0 ? 0.45 : 1);
    const smoothing =
      1 -
      Math.exp(
        -(Math.hypot(x, y) > 0.01 ? CONFIG.acceleration : CONFIG.friction) * dt,
      );
    cat.velocity.lerp(new THREE.Vector2(x * max, y * max), smoothing);
    if (cat.eating > 0 && !(cat.wasabi > 0)) cat.velocity.multiplyScalar(0.65);
    cat.root.position.x += cat.velocity.x * dt;
    cat.root.position.z += cat.velocity.y * dt;
    const r = Math.hypot(cat.root.position.x, cat.root.position.z);
    if (r > CONFIG.arenaRadius) {
      cat.root.position.x *= CONFIG.arenaRadius / r;
      cat.root.position.z *= CONFIG.arenaRadius / r;
    }
    if (Math.hypot(x, y) > 0.08) cat.facing = Math.atan2(x, y);
  }
  eat(cat) {
    if (cat.eating > 0 || cat.wasabi > 0) return;
    let nearest = null,
      best = Infinity;
    for (const p of this.conveyor.plates) {
      if (!p.type) continue;
      const dx = p.group.position.x - cat.root.position.x,
        dz = p.group.position.z - cat.root.position.z,
        d = Math.hypot(dx, dz);
      const facing =
        (dx * Math.sin(cat.facing) + dz * Math.cos(cat.facing)) / d;
      if (
        d < (cat.magnet > 0 ? 2.5 : CONFIG.eatRange) &&
        facing > 0.1 &&
        d < best
      ) {
        nearest = p;
        best = d;
      }
    }
    if (!nearest) return;
    const type = nearest.type;
    const foodPosition = nearest.group.position.clone();
    foodPosition.y += 0.06;
    this.conveyor.consume(nearest);
    cat.startEating(type, foodPosition, () => {
      if (this.sm.state === "PLAYING") this.completeBite(cat, type);
    });
  }
  completeBite(cat, type) {
    if (type.hazard === "wasabi") {
      applyWasabi(cat);
      this.ui.popup(cat, "TOO HOT!", "WASABI · 5 SECONDS");
      this.particles.burst(cat.root.position, 20);
      this.audio.play("power");
      return;
    }
    if (type.power === "catnip") {
      applyCatnip(cat);
      this.ui.popup(cat, "ZOOMIES!", "CATNIP · 15 SECONDS");
      this.particles.burst(cat.root.position, 20);
      this.audio.play("power");
      return;
    }
    const result = award(cat, type, this.elapsed);
    this.particles.burst(cat.root.position);
    this.ui.popup(
      cat,
      `+${result.points}`,
      result.count > 1 ? `${type.name.toUpperCase()} ×${result.count}` : "",
    );
    if (cat === this.player) {
      this.audio.play(
        type.name === "Golden" ? "golden" : result.count > 1 ? "combo" : "eat",
      );
      if (type.name === "Golden") {
        this.ui.flash();
        this.shake = 0.35;
      }
    }
  }
  powerup() {
    const kinds = [
      "Catnip",
      "Lucky Paw",
      "Magnet Bell",
      "Freeze Fish",
      "Golden Plate",
    ];
    this.power = {
      name: kinds[Math.floor(Math.random() * kinds.length)],
      time: 7,
    };
    const p = this.player;
    if (this.power.name === "Catnip") {
      applyCatnip(p);
      this.power.time = CONFIG.catnipDuration;
    }
    if (this.power.name === "Lucky Paw") p.lucky = 7;
    if (this.power.name === "Magnet Bell") p.magnet = 7;
    if (this.power.name === "Freeze Fish")
      this.cats.slice(1).forEach((c) => (c.stun = 4));
    if (this.power.name === "Golden Plate") {
      p.score += 500;
      this.ui.popup(p, "+500", "GOLDEN PLATE");
    }
    this.audio.play("power");
    this.particles.burst(p.root.position, 25);
    this.shake = 0.2;
  }
  finish() {
    this.ranking = [...this.cats].sort((a, b) => b.score - a.score);
    this.ranking[0].winning = true;
    this.ranking[0].facing = Math.atan2(5, 9);
    this.save.highScore = Math.max(this.save.highScore, this.player.score);
    this.save.bestCombo = Math.max(this.save.bestCombo, this.player.bestCombo);
    if (this.ranking[0] === this.player) this.save.wins++;
    const earned = [
      this.player.eaten >= 10,
      this.player.bestCombo >= 3,
      this.save.wins >= 1,
      this.player.score >= 3000,
    ];
    this.newUnlocks = [];
    COSMETICS.forEach((c, i) => {
      if (earned[i] && !this.save.unlocked.includes(c.id)) {
        this.save.unlocked.push(c.id);
        this.newUnlocks.push(c.name);
      }
    });
    this.persist();
    this.finishWait = 1.5;
    this.go("FINISHED");
    this.audio.play("winner");
  }
  update(dt) {
    const state = this.sm.state;
    const dir = this.input.update();
    if (this.input.consume("KeyF")) this.debug = !this.debug;
    if (this.input.consume("Escape") || this.input.consume("KeyP"))
      this.pause();
    if (this.input.consume("KeyR") && ["PLAYING", "RESULTS"].includes(state))
      this.start();
    if (this.paused) return;
    if (["MENU", "CHARACTER_SELECT"].includes(state)) {
      this.menuInputDelay = Math.max(0, (this.menuInputDelay || 0) - dt);
      if (
        this.menuInputDelay === 0 &&
        (Math.abs(dir.x) > 0.5 || Math.abs(dir.y) > 0.5)
      ) {
        const step =
          Math.abs(dir.x) > 0.5 ? Math.sign(dir.x) : Math.sign(dir.y) * 4;
        this.select((this.save.selected + step + 8) % 8);
        this.menuInputDelay = 0.25;
      }
      if (this.input.consume("Space")) {
        this.ui.action("start");
        return;
      }
    } else if (
      (state === "HOW_TO_PLAY" || state === "RESULTS") &&
      this.input.consume("Space")
    ) {
      this.start();
      return;
    }
    this.time += dt;
    this.conveyor.update(dt, this.time);
    this.scene.belt.rotation.y -= CONFIG.conveyorSpeed * dt;
    this.particles.update(dt);
    this.audio.update(dt, state === "PLAYING");
    if (state === "COUNTDOWN") {
      this.countdown -= dt;
      const n = Math.ceil(this.countdown);
      if (n !== this.lastCount) {
        this.lastCount = n;
        this.audio.play(n <= 0 ? "go" : "countdown");
      }
      if (this.countdown <= 0) this.go("PLAYING");
    }
    if (state === "PLAYING") {
      this.elapsed += dt;
      this.remaining = Math.max(0, CONFIG.duration - this.elapsed);
      if (this.input.consume("ShiftLeft") || this.input.consume("ShiftRight")) {
        if (this.player.cooldown <= 0 && !(this.player.wasabi > 0)) {
          this.player.dash = 0.22;
          this.player.cooldown = CONFIG.dashCooldown;
          this.audio.play("click");
        }
      }
      this.move(this.player, dir, dt);
      if (this.input.consume("Space")) this.eat(this.player);
      for (const cat of this.cats.slice(1)) {
        const ai = this.ai.update(cat, this.conveyor.plates, dt);
        this.move(cat, ai, dt);
        if (ai.eat) this.eat(cat);
      }
      for (const cat of this.cats) {
        updateStatuses(cat, dt);
        if (this.elapsed - cat.combo.time > CONFIG.comboWindow)
          cat.combo.count = 0;
      }
      this.powerClock -= dt;
      if (this.powerClock <= 0) {
        this.powerClock = 15;
        this.powerup();
      }
      if (this.power) this.power.time = Math.max(0, this.power.time - dt);
      if (this.remaining <= 0) this.finish();
    } else if (["MENU", "CHARACTER_SELECT", "HOW_TO_PLAY"].includes(state)) {
      arrangeSelection(this.cats, this.time);
    } else if (state === "FINISHED") {
      this.finishWait -= dt;
      if (this.finishWait <= 0) this.go("RESULTS");
    }
    this.cats.forEach((c) => c.update(dt, this.time));
    if (state === "RESULTS" && Math.random() < dt * 9)
      this.particles.burst(this.ranking[0].root.position, 5);
    this.camera(dt);
  }
  camera(dt) {
    const menu = ["MENU", "CHARACTER_SELECT", "HOW_TO_PLAY"].includes(
      this.sm.state,
    );
    const portrait = innerWidth < 800;
    const target = new THREE.Vector3(
      menu && !portrait ? -4.4 : 0,
      menu ? 1 : 0,
      0,
    );
    let position = new THREE.Vector3(
      menu ? 9 : 0,
      menu ? 13 : 15,
      menu ? 16 : 17,
    );
    if (portrait) {
      position.multiplyScalar(Math.max(1.3, 0.95 / this.scene.camera.aspect));
      target.x = 0;
    }
    if (this.sm.state === "RESULTS") {
      const p = this.ranking[0].root.position;
      target.copy(p).add(new THREE.Vector3(0, 0.6, 0));
      position.copy(p).add(new THREE.Vector3(5, 6, 9));
    }
    if (this.sm.state === "PLAYING" && this.remaining < 10)
      position.multiplyScalar(0.96);
    if (this.shake > 0) {
      this.shake -= dt;
      position.x += (Math.random() - 0.5) * this.shake;
    }
    this.scene.camera.position.lerp(position, 1 - Math.exp(-dt * 2));
    this.cameraTarget ??= target.clone();
    this.cameraTarget.lerp(target, 1 - Math.exp(-dt * 2));
    this.scene.camera.lookAt(this.cameraTarget);
  }
  frame(now) {
    const dt = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;
    this.fps = 1 / Math.max(dt, 0.001);
    this.update(dt);
    this.hudTick = (this.hudTick || 0) + dt;
    if (this.hudTick > 0.08) {
      this.ui.update();
      this.hudTick = 0;
    }
    this.scene.render();
    requestAnimationFrame((t) => this.frame(t));
  }
}
