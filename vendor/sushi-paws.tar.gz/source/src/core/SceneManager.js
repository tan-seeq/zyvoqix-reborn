import * as THREE from "three";
import { createRestaurantLogo } from "../entities/RestaurantLogo.js";
import { mesh, ring, label } from "../entities/geometry.js";
export class SceneManager {
  constructor() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color("#e7bdcc");
    this.scene.fog = new THREE.Fog("#e7bdcc", 40, 100);
    this.renderer = new THREE.WebGLRenderer({
      canvas: document.querySelector("#world"),
      antialias: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.93;
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.1, 80);
    this.camera.position.set(0, 14, 17);
    this.camera.lookAt(0, 0, 0);
    this.scene.add(new THREE.HemisphereLight("#fff6ef", "#94717e", 1.35));
    const sun = new THREE.DirectionalLight("#fff6f1", 2.8);
    sun.position.set(-6, 13, 8);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, {
      left: -12,
      right: 12,
      top: 12,
      bottom: -12,
    });
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.035;
    this.scene.add(sun);
    this.environment();
    window.addEventListener("resize", () => this.resize());
    this.resize();
  }
  environment() {
    const add = (...a) => {
      const m = mesh(...a);
      this.scene.add(m);
      return m;
    };
    for (let x = -8; x <= 8; x++)
      for (let z = -7; z <= 6; z++)
        add(
          "box",
          (x + z) % 2 ? "#e7c0cb" : "#f5e5cf",
          [1.5, 0.1, 1.5],
          [x * 1.5, -0.16, z * 1.5],
        );
    this.scene.add(ring(4.65, 6.1, 0.32, "#c7a88e", 0.03));
    this.scene.add(ring(4.55, 6.18, 0.13, "#f5e3ce", 0.39));
    this.scene.add(ring(4.83, 5.83, 0.05, "#d3a0b4", 0.52));
    this.scene.add(ring(4.77, 4.84, 0.035, "#dbc1a8", 0.56));
    this.scene.add(ring(5.82, 5.9, 0.035, "#dbc1a8", 0.56));
    this.belt = new THREE.Group();
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      const m = mesh(
        "box",
        "#f0ccdb",
        [0.025, 0.012, 0.9],
        [Math.cos(a) * 5.33, 0.64, Math.sin(a) * 5.33],
      );
      m.rotation.y = -a + Math.PI / 2;
      this.belt.add(m);
    }
    this.scene.add(this.belt);
    add("cylinder", "#e8d3c0", [4.5, 0.15, 4.5], [0, -0.02, 0]);
    add("cylinder", "#f5e7d8", [2.5, 0.018, 2.5], [0, 0.063, 0]);
    const floorLogo = label("SUSHI PAWS", "#b9a0a8", "#f5e7d8", 3.5, 0.88);
    floorLogo.rotation.x = -Math.PI / 2;
    floorLogo.position.set(0, 0.078, 0);
    this.scene.add(floorLogo);
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4;
      add(
        "sphere",
        i % 2 ? "#e9b2c8" : "#edb5ce",
        [0.63, 0.15, 0.48],
        [Math.cos(a) * 6.8, 0.12, Math.sin(a) * 6.8],
      );
    }
    add("box", "#f3d7e1", [25, 7, 0.3], [0, 3.3, -9]);
    for (let i = -8; i <= 8; i++)
      add("box", "#d5a4bc", [0.11, 5, 0.3], [i * 1.4, 2.5, -8.75]);
    add("box", "#c88fa6", [25, 0.18, 0.45], [0, 5.4, -8.65]);
    const sign = createRestaurantLogo();
    sign.position.set(0, 4, -8.35);
    this.scene.add(sign);
    for (const x of [-6.2, 6.2]) {
      const plaque = label(
        x < 0 ? "MADE WITH LOVE" : "HAPPY LITTLE BITES",
        "#fff0cb",
        "#be819a",
        3.1,
        0.7,
      );
      plaque.position.set(x, 3.5, -8.4);
      this.scene.add(plaque);
    }
    // Noren curtains, open prep counter and pantry make this a working sushi bar.
    for (const x of [-4.65, 4.65]) {
      add("box", "#6c3d28", [1.6, 0.12, 0.18], [x, 4.75, -8.2]);
      for (const side of [-1, 1]) {
        add(
          "box",
          "#dbadc4",
          [0.68, 1.22, 0.07],
          [x + side * 0.37, 4.12, -8.13],
        );
        add(
          "sphere",
          "#fff0d9",
          [0.15, 0.13, 0.04],
          [x + side * 0.37, 4.15, -8.06],
        );
        for (let t = 0; t < 3; t++)
          add(
            "sphere",
            "#fff0d9",
            [0.047, 0.055, 0.04],
            [x + side * 0.37 + (t - 1) * 0.11, 4.34, -8.06],
          );
      }
    }
    add("box", "#dfbfd0", [15, 1.15, 1.2], [0, 0.53, -7.65]);
    add("box", "#f9e4c7", [15.3, 0.18, 1.45], [0, 1.18, -7.65]);
    for (let x = -7; x <= 7; x += 1)
      add("box", "#b17b91", [0.04, 0.94, 0.035], [x, 0.55, -7.03]);
    for (const x of [-5.6, -0.2, 5.4]) {
      add("box", "#b9733d", [1.4, 0.075, 0.75], [x, 1.31, -7.48]);
      add("box", "#fff1d0", [0.58, 0.14, 0.22], [x, 1.42, -7.4]);
      add("box", "#ec7354", [0.64, 0.09, 0.28], [x, 1.53, -7.4]);
      add("cylinder", "#d89ab9", [0.15, 0.38, 0.15], [x + 0.55, 1.49, -7.75]);
      for (let i = 0; i < 4; i++)
        add(
          "cylinder",
          "#d8aa67",
          [0.015, 0.54, 0.015],
          [x + 0.49 + i * 0.035, 1.82, -7.75],
        );
    }
    for (const x of [-7, 2.5, 3.1]) {
      add("cylinder", "#683323", [0.15, 0.4, 0.15], [x, 1.48, -7.55]);
      add("cylinder", "#bf4438", [0.085, 0.16, 0.085], [x, 1.76, -7.55]);
      add("box", "#f5d89b", [0.24, 0.17, 0.025], [x, 1.48, -7.39]);
    }
    // Bamboo steamer, ceramic rice bowl and warm display shelves.
    add("cylinder", "#ba824b", [0.5, 0.3, 0.5], [1.1, 1.46, -7.6]);
    add("cylinder", "#e3b675", [0.52, 0.07, 0.52], [1.1, 1.65, -7.6]);
    add("sphere", "#e4b3cb", [0.4, 0.24, 0.4], [-2.5, 1.46, -7.55]);
    add("sphere", "#fff2d2", [0.34, 0.1, 0.34], [-2.5, 1.65, -7.55]);
    for (const x of [-6.35, 6.35]) {
      add("box", "#8f4f2b", [2.8, 0.12, 0.6], [x, 2.55, -8.32]);
      for (let i = 0; i < 4; i++) {
        const color = ["#e2b4c3", "#dfabc4", "#ecd6a8", "#b4d2c3"][i];
        add(
          "cylinder",
          color,
          [0.18, 0.48, 0.18],
          [x - 0.9 + i * 0.6, 2.84, -8.3],
        );
        add(
          "cylinder",
          "#70432e",
          [0.2, 0.065, 0.2],
          [x - 0.9 + i * 0.6, 3.11, -8.3],
        );
      }
    }
    for (const x of [-7, -3.9, 3.9, 7]) {
      add("cylinder", "#4f3b30", [0.028, 2, 0.028], [x, 6.7, -6.3]);
      add("sphere", "#f9e1eb", [0.5, 0.67, 0.5], [x, 5.6, -6.3]);
      for (const y of [5.05, 6.15])
        add("cylinder", "#c19aaf", [0.31, 0.08, 0.31], [x, y, -6.3]);
      const l = new THREE.PointLight("#ffe9d8", 12, 8, 2);
      l.position.set(x, 5, -6);
      this.scene.add(l);
    }
    for (const x of [-8, 8]) {
      // Rice tubs replace the oversized decorative planters.
      add("cylinder", "#b8793e", [0.53, 0.8, 0.53], [x, 0.35, -5.4]);
      add("cylinder", "#dfaf69", [0.57, 0.08, 0.57], [x, 0.79, -5.4]);
      for (const y of [0.17, 0.57])
        add("cylinder", "#5f4837", [0.544, 0.055, 0.544], [x, y, -5.4]);
      add("box", "#e7c085", [0.52, 0.045, 0.12], [x, 0.865, -5.4]);
    }
  }
  resize() {
    this.renderer.setSize(innerWidth, innerHeight);
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
  }
  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
