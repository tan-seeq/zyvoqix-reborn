export class InputManager {
  constructor() {
    this.keys = new Set();
    this.pressed = new Set();
    this.touch = { x: 0, y: 0 };
    this.lastButtons = [];
    window.addEventListener("keydown", (e) => {
      if (
        ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(
          e.code,
        )
      )
        e.preventDefault();
      if (!this.keys.has(e.code)) this.pressed.add(e.code);
      this.keys.add(e.code);
    });
    window.addEventListener("keyup", (e) => this.keys.delete(e.code));
    window.addEventListener("blur", () => this.clear());
  }
  clear() {
    this.keys.clear();
    this.pressed.clear();
    this.touch = { x: 0, y: 0 };
  }
  tap(code) {
    this.pressed.add(code);
  }
  consume(code) {
    const yes = this.pressed.has(code);
    this.pressed.delete(code);
    return yes;
  }
  update() {
    const pad = Array.from(navigator.getGamepads?.() || []).find(Boolean);
    let x =
      Number(this.keys.has("KeyD") || this.keys.has("ArrowRight")) -
      Number(this.keys.has("KeyA") || this.keys.has("ArrowLeft")) +
      this.touch.x;
    let y =
      Number(this.keys.has("KeyS") || this.keys.has("ArrowDown")) -
      Number(this.keys.has("KeyW") || this.keys.has("ArrowUp")) +
      this.touch.y;
    if (pad) {
      x += Math.abs(pad.axes[0]) > 0.15 ? pad.axes[0] : 0;
      y += Math.abs(pad.axes[1]) > 0.15 ? pad.axes[1] : 0;
      [0, 1, 9].forEach((b, i) => {
        if (pad.buttons[b]?.pressed && !this.lastButtons[b])
          this.tap(["Space", "ShiftLeft", "Escape"][i]);
        this.lastButtons[b] = pad.buttons[b]?.pressed;
      });
    }
    const l = Math.hypot(x, y);
    return { x: l > 1 ? x / l : x, y: l > 1 ? y / l : y };
  }
}
