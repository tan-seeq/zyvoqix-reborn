export class AudioManager {
  constructor(enabled = true) {
    this.enabled = enabled;
    this.context = null;
    this.beat = 0;
    this.elapsed = 0;
  }
  unlock() {
    if (!this.context)
      this.context = new (window.AudioContext || window.webkitAudioContext)();
    this.context.resume();
  }
  play(name) {
    if (!this.enabled || !this.context) return;
    const notes = {
      hover: [520],
      click: [440, 660],
      eat: [640, 850],
      combo: [660, 830, 990],
      golden: [660, 880, 1100, 1320],
      power: [330, 660, 990],
      countdown: [440],
      go: [880, 1100],
      winner: [523, 659, 784, 1047],
    };
    (notes[name] || [440]).forEach((f, i) =>
      this.tone(f, 0.12, i * 0.085, 0.045),
    );
  }
  tone(freq, duration, delay = 0, volume = 0.018) {
    const ctx = this.context;
    if (!ctx) return;
    const o = ctx.createOscillator(),
      g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = freq;
    g.gain.setValueAtTime(0, ctx.currentTime + delay);
    g.gain.linearRampToValueAtTime(volume, ctx.currentTime + delay + 0.012);
    g.gain.exponentialRampToValueAtTime(
      0.001,
      ctx.currentTime + delay + duration,
    );
    o.connect(g);
    g.connect(ctx.destination);
    o.start(ctx.currentTime + delay);
    o.stop(ctx.currentTime + delay + duration);
  }
  update(dt, playing) {
    if (!this.enabled || !this.context) return;
    this.elapsed += dt;
    if (this.elapsed > (playing ? 0.27 : 0.43)) {
      this.elapsed = 0;
      const melody = [0, 7, 12, 7, 4, 9, 12, 9, 2, 7, 11, 7, 5, 9, 12, 7];
      this.tone(220 * 2 ** (melody[this.beat++ % 16] / 12), 0.2, 0, 0.009);
    }
  }
}
