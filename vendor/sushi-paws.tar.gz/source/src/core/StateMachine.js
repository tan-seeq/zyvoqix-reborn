export class StateMachine {
  constructor() {
    this.state = "BOOT";
    this.previous = "BOOT";
  }
  set(state) {
    const allowed = [
      "BOOT",
      "MENU",
      "CHARACTER_SELECT",
      "HOW_TO_PLAY",
      "COUNTDOWN",
      "PLAYING",
      "FINISHED",
      "RESULTS",
    ];
    if (!allowed.includes(state)) throw new Error(`Unknown state ${state}`);
    this.previous = this.state;
    this.state = state;
  }
}
