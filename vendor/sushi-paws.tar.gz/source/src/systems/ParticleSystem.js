import * as THREE from "three";
import { mesh } from "../entities/geometry.js";
export class ParticleSystem {
  constructor(scene) {
    this.pool = Array.from({ length: 120 }, () => {
      const m = mesh("sphere", "#ffd17d", [0.06, 0.06, 0.06]);
      m.visible = false;
      scene.add(m);
      return { m, life: 0, v: new THREE.Vector3() };
    });
  }
  burst(position, n = 14) {
    for (const p of this.pool.filter((p) => p.life <= 0).slice(0, n)) {
      p.life = 0.6 + Math.random() * 0.5;
      p.m.visible = true;
      p.m.position.copy(position);
      p.m.position.y += 0.6;
      p.v.set(
        (Math.random() - 0.5) * 3,
        2 + Math.random() * 3,
        (Math.random() - 0.5) * 3,
      );
    }
  }
  update(dt) {
    for (const p of this.pool) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.v.y -= dt * 7;
      p.m.position.addScaledVector(p.v, dt);
      p.m.scale.setScalar(Math.max(0.001, p.life) * 0.07);
      p.m.visible = p.life > 0;
    }
  }
}
