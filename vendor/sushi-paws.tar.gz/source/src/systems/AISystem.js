import { CONFIG } from "../config.js";
export class AISystem {
  update(cat, plates, dt) {
    cat.think = (cat.think || 0) - dt;
    const personality = cat.index % 3;
    if (cat.think <= 0 || !cat.target?.type) {
      cat.think = 0.35 + Math.random() * 0.6;
      let best = -Infinity;
      for (const p of plates) {
        if (!p.type) continue;
        const distance = Math.hypot(
          p.group.position.x - cat.root.position.x,
          p.group.position.z - cat.root.position.z,
        );
        // Cats know wasabi is risky, but can mistake it for a tempting bite.
        const appeal = p.type.hazard
          ? Math.random() < 0.12
            ? 200
            : 5
          : p.type.power === "catnip"
            ? cat.catnip > 0
              ? 20
              : 180
            : p.type.value;
        let value = appeal / (distance + 1.5);
        if (personality === 1 && p.type.category === cat.combo.category)
          value *= 2;
        if (personality === 2) value *= 0.4 + Math.random() * 1.4;
        if (value > best) {
          best = value;
          cat.target = p;
        }
      }
    }
    if (!cat.target) return { x: 0, y: 0, eat: false };
    const p = cat.target.group.position,
      dx = p.x - cat.root.position.x,
      dz = p.z - cat.root.position.z,
      len = Math.max(0.001, Math.hypot(dx, dz));
    return {
      x: (dx / len) * 0.78,
      y: (dz / len) * 0.78,
      eat: len < CONFIG.eatRange && Math.random() < dt * 3.5,
    };
  }
}
