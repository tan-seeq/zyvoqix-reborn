import { CONFIG } from "../config.js";

export function applyWasabi(cat) {
  cat.wasabi = CONFIG.wasabiDuration;
  cat.panicHeading = cat.facing + Math.PI;
  cat.panicTurn = 0;
  cat.dash = 0;
  cat.combo.count = 0;
  cat.combo.category = null;
}

export function applyCatnip(cat) {
  // Refresh the duration; pickups never compound the speed multiplier.
  cat.catnip = CONFIG.catnipDuration;
}

export function updateStatuses(cat, dt) {
  for (const key of ["wasabi", "catnip", "lucky", "magnet"]) {
    cat[key] = Math.max(0, (cat[key] || 0) - dt);
  }
}

export function movementDirection(cat, requested, dt) {
  if (!(cat.wasabi > 0)) return requested;
  cat.panicTurn = (cat.panicTurn || 0) - dt;
  if (cat.panicTurn <= 0) {
    cat.panicHeading += (Math.random() - 0.5) * 2.3;
    cat.panicTurn = 0.22 + Math.random() * 0.3;
  }
  const { x, z } = cat.root.position;
  let dx = Math.sin(cat.panicHeading),
    dz = Math.cos(cat.panicHeading);
  // Bounce back into the arena rather than running in place against the rim.
  if (Math.hypot(x, z) > CONFIG.arenaRadius - 0.3 && x * dx + z * dz > 0) {
    cat.panicHeading = Math.atan2(-x, -z) + (Math.random() - 0.5) * 0.7;
    dx = Math.sin(cat.panicHeading);
    dz = Math.cos(cat.panicHeading);
  }
  return { x: dx, y: dz };
}
