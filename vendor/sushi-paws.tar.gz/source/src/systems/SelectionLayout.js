export function arrangeSelection(cats, time = 0) {
  const orbitCount = cats.length - 1;
  cats.forEach((cat, index) => {
    if (index === 0) {
      cat.root.position.set(0, 0, 0);
      cat.root.scale.setScalar(1.35);
      cat.facing = 0.45;
    } else {
      const angle =
        -Math.PI / 2 + ((index - 1) * Math.PI * 2) / orbitCount + time * 0.23;
      cat.root.position.set(Math.cos(angle) * 3.05, 0, Math.sin(angle) * 3.05);
      cat.root.scale.setScalar(0.9);
      cat.facing = -angle;
      cat.velocity.set(-Math.sin(angle) * 0.7, Math.cos(angle) * 0.7);
    }
    cat.root.rotation.y = cat.facing;
    if (index === 0) cat.velocity.set(0, 0);
  });
}
