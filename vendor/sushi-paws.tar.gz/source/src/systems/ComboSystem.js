import { CONFIG } from "../config.js";
export function award(cat, type, now) {
  const combo = cat.combo;
  combo.count =
    combo.category === type.category && now - combo.time <= CONFIG.comboWindow
      ? combo.count + 1
      : 1;
  combo.category = type.category;
  combo.time = now;
  const multiplier = [1, 1.25, 1.5, 2, 2.5][Math.min(combo.count - 1, 4)];
  const points = Math.round(type.value * multiplier * (cat.lucky > 0 ? 2 : 1));
  cat.score += points;
  cat.eaten++;
  cat.bestCombo = Math.max(cat.bestCombo, combo.count);
  return { points, multiplier, count: combo.count };
}
