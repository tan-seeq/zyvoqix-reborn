import * as THREE from "three";
import { FontLoader } from "three/addons/loaders/FontLoader.js";
import { TextGeometry } from "three/addons/geometries/TextGeometry.js";
import fontData from "three/examples/fonts/helvetiker_bold.typeface.json" with { type: "json" };
import { mesh, material } from "./geometry.js";

export function createRestaurantLogo() {
  const logo = new THREE.Group();
  logo.name = "Sushi Paws raised restaurant sign";
  logo.add(mesh("box", "#d78fae", [7.3, 1.9, 0.26]));
  logo.add(mesh("box", "#fff0e4", [7.03, 1.62, 0.1], [0, 0, 0.18]));
  const geometry = new TextGeometry("SUSHI PAWS", {
    font: new FontLoader().parse(fontData),
    size: 0.66,
    depth: 0.18,
    curveSegments: 6,
    bevelEnabled: true,
    bevelThickness: 0.025,
    bevelSize: 0.019,
    bevelSegments: 2,
  });
  geometry.computeBoundingBox();
  const width = geometry.boundingBox.max.x - geometry.boundingBox.min.x;
  geometry.translate(-width / 2, -0.24, 0.25);
  const letters = new THREE.Mesh(geometry, [
    material("#d66a98"),
    material("#a75279"),
  ]);
  letters.name = "Extruded SUSHI PAWS lettering";
  letters.castShadow = letters.receiveShadow = true;
  logo.add(letters);
  for (const side of [-1, 1]) {
    logo.add(
      mesh("sphere", "#e5a6c2", [0.15, 0.13, 0.06], [side * 3.2, -0.48, 0.26]),
    );
    for (let toe = 0; toe < 3; toe++)
      logo.add(
        mesh(
          "sphere",
          "#e5a6c2",
          [0.055, 0.07, 0.05],
          [
            side * 3.2 + (toe - 1) * 0.115,
            -0.29 + (toe === 1 ? 0.025 : 0),
            0.26,
          ],
        ),
      );
  }
  return logo;
}
