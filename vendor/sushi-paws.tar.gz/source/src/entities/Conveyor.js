import * as THREE from "three";
import { CONFIG, SUSHI } from "../config.js";
import { mesh } from "./geometry.js";
import { createSushi } from "./Sushi.js";
export function chooseDish(roll = Math.random(), selection = Math.random()) {
  if (roll < 0.03) return SUSHI.find((s) => s.name === "Golden");
  if (roll < 0.12) return SUSHI.find((s) => s.hazard === "wasabi");
  if (roll < 0.2) return SUSHI.find((s) => s.power === "catnip");
  const regular = SUSHI.filter(
    (s) => !s.hazard && !s.power && s.name !== "Golden",
  );
  return regular[
    Math.min(regular.length - 1, Math.floor(selection * regular.length))
  ];
}
export class Conveyor {
  constructor(scene) {
    this.root = new THREE.Group();
    scene.add(this.root);
    this.plates = Array.from({ length: CONFIG.plateCount }, (_, i) => {
      const group = new THREE.Group();
      const colors = ["#b4d4c7", "#eed5ab", "#cda8a0", "#9dbdc9"];
      group.add(mesh("cylinder", colors[i % 4], [0.55, 0.06, 0.55]));
      group.add(
        mesh("cylinder", "#fff4e8", [0.47, 0.015, 0.47], [0, 0.036, 0]),
      );
      this.root.add(group);
      const p = {
        group,
        angle: (i / CONFIG.plateCount) * Math.PI * 2,
        type: null,
        food: null,
        respawn: 0,
      };
      this.spawn(
        p,
        i === 3
          ? SUSHI.find((s) => s.hazard)
          : i === 11
            ? SUSHI.find((s) => s.power === "catnip")
            : undefined,
      );
      return p;
    });
  }
  spawn(p, type = chooseDish()) {
    p.type = type;
    p.food = createSushi(p.type);
    p.food.position.y = 0.06;
    p.group.add(p.food);
  }
  update(dt, time) {
    for (const p of this.plates) {
      p.angle += CONFIG.conveyorSpeed * dt;
      p.group.position.set(
        Math.cos(p.angle) * CONFIG.beltRadius,
        CONFIG.plateHeight,
        Math.sin(p.angle) * CONFIG.beltRadius,
      );
      p.group.rotation.y = -p.angle;
      if (!p.type) {
        p.respawn -= dt;
        if (p.respawn <= 0) this.spawn(p);
      } else {
        const scale = Math.min(1, p.food.scale.x + dt * 4);
        p.food.scale.setScalar(scale);
        p.food.position.y =
          0.06 + (p.type === SUSHI[8] ? Math.sin(time * 4) * 0.09 : 0);
      }
    }
  }
  consume(p) {
    p.group.remove(p.food);
    p.food = null;
    p.type = null;
    p.respawn = 1 + Math.random() * 2;
  }
}
