import * as THREE from "three";
const geometries = new Map(),
  materials = new Map();
export function material(color, metalness = 0) {
  const key = color + metalness;
  if (!materials.has(key))
    materials.set(
      key,
      new THREE.MeshStandardMaterial({ color, roughness: 0.72, metalness }),
    );
  return materials.get(key);
}
export function mesh(type, color, scale = [1, 1, 1], position = [0, 0, 0]) {
  if (!geometries.has(type))
    geometries.set(
      type,
      type === "sphere"
        ? new THREE.SphereGeometry(1, 20, 14)
        : type === "cylinder"
          ? new THREE.CylinderGeometry(1, 1, 1, 32)
          : type === "cone"
            ? new THREE.ConeGeometry(1, 1, 3)
            : new THREE.BoxGeometry(1, 1, 1),
    );
  const m = new THREE.Mesh(geometries.get(type), material(color));
  m.scale.set(...scale);
  m.position.set(...position);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}
export function ring(inner, outer, height, color, y = 0) {
  const shape = new THREE.Shape();
  shape.absarc(0, 0, outer, 0, Math.PI * 2, false);
  const hole = new THREE.Path();
  hole.absarc(0, 0, inner, 0, Math.PI * 2, true);
  shape.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: height,
    bevelEnabled: true,
    bevelThickness: 0.06,
    bevelSize: 0.06,
    bevelSegments: 2,
    curveSegments: 64,
  });
  g.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(g, material(color));
  m.position.y = y;
  m.receiveShadow = true;
  m.castShadow = true;
  return m;
}
export function label(
  text,
  color = "#f9e8c9",
  background = "#213d3c",
  width = 4,
  height = 1,
) {
  const canvas = document.createElement("canvas");
  canvas.width = 768;
  canvas.height = 192;
  const c = canvas.getContext("2d");
  c.fillStyle = background;
  c.fillRect(0, 0, 768, 192);
  c.strokeStyle = "#c99765";
  c.lineWidth = 8;
  c.strokeRect(10, 10, 748, 172);
  c.fillStyle = color;
  c.font = "bold 70px sans-serif";
  c.textAlign = "center";
  c.textBaseline = "middle";
  c.fillText(text, 384, 99);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(width, height),
    new THREE.MeshBasicMaterial({ map: texture }),
  );
  return m;
}
