import * as THREE from "three";
import { mesh } from "./geometry.js";
import { createSushi } from "./Sushi.js";
export class Cat {
  constructor(data, index = 0) {
    this.data = data;
    this.index = index;
    this.root = new THREE.Group();
    this.visual = new THREE.Group();
    this.root.add(this.visual);
    this.velocity = new THREE.Vector2();
    this.facing = 0;
    this.eating = 0;
    this.wasabi = 0;
    this.catnip = 0;
    this.eatDuration = 1.1;
    this.foodStart = new THREE.Vector3(0, 0.8, 1.05);
    this.foodMouth = new THREE.Vector3(0, 0.84, 0.69);
    this.dash = 0;
    this.cooldown = 0;
    this.stun = 0;
    this.score = 0;
    this.eaten = 0;
    this.bestCombo = 0;
    this.combo = { category: null, count: 0, time: 0 };
    this.winning = false;
    const add = (...a) => {
      const m = mesh(...a);
      this.visual.add(m);
      return m;
    };
    this.body = add("sphere", data.fur, [0.48, 0.56, 0.38], [0, 0.6, 0]);
    add("sphere", data.patch, [0.31, 0.36, 0.08], [0, 0.59, 0.34]);
    this.head = new THREE.Group();
    this.head.position.y = 1.2;
    this.visual.add(this.head);
    const h = (...a) => {
      const m = mesh(...a);
      this.head.add(m);
      return m;
    };
    h("sphere", data.fur, [0.64, 0.55, 0.46]);
    for (const x of [-1, 1]) {
      const ear = h("cone", data.fur, [0.28, 0.52, 0.25], [x * 0.42, 0.46, 0]);
      ear.rotation.z = x * -0.23;
      h("cone", "#e7a3a0", [0.15, 0.29, 0.08], [x * 0.42, 0.48, 0.14]);
      h("sphere", data.eyes, [0.075, 0.11, 0.035], [x * 0.23, 0.05, 0.425]);
      h(
        "sphere",
        "#fff9e7",
        [0.021, 0.031, 0.015],
        [x * 0.23 - 0.018, 0.08, 0.455],
      );
      h("sphere", "#f1c1a5", [0.12, 0.045, 0.02], [x * 0.39, -0.09, 0.39]);
      h("sphere", "#fff0d5", [0.14, 0.09, 0.07], [x * 0.095, -0.15, 0.434]);
      for (let j = 0; j < 2; j++) {
        const whisker = h(
          "box",
          "#5d514d",
          [0.18, 0.015, 0.015],
          [x * 0.49, -0.11 - j * 0.07, 0.41],
        );
        whisker.rotation.z = x * (j - 0.5) * 0.16;
      }
    }
    h("sphere", "#b36b72", [0.064, 0.045, 0.035], [0, -0.1, 0.5]);
    this.mouth = h(
      "sphere",
      "#654b43",
      [0.035, 0.055, 0.025],
      [0, -0.23, 0.44],
    );
    for (let i = -1; i <= 1; i++)
      h("sphere", data.patch, [0.052, 0.16, 0.022], [i * 0.145, 0.35, 0.35]);
    this.paws = [
      add("sphere", data.fur, [0.16, 0.23, 0.19], [-0.38, 0.52, 0.25]),
      add("sphere", data.fur, [0.16, 0.23, 0.19], [0.38, 0.52, 0.25]),
    ];
    this.arms = [-1, 1].map((side) =>
      add("sphere", data.fur, [0.12, 0.16, 0.12], [side * 0.38, 0.65, 0.15]),
    );
    this.armAxis = new THREE.Vector3(0, 1, 0);
    this.armDirection = new THREE.Vector3();
    this.armShoulder = new THREE.Vector3();
    this.pawTarget = new THREE.Vector3();
    this.feet = [
      add("sphere", data.fur, [0.21, 0.14, 0.28], [-0.23, 0.13, 0.12]),
      add("sphere", data.fur, [0.21, 0.14, 0.28], [0.23, 0.13, 0.12]),
    ];
    this.tail = add(
      "sphere",
      data.patch,
      [0.15, 0.48, 0.15],
      [0.38, 0.48, -0.35],
    );
    this.tail.rotation.z = -0.7;
    this.accessory = new THREE.Group();
    this.head.add(this.accessory);
    // Fur materials are shared by the geometry helper, so each cat gets its
    // own red variants without changing any other cat or scene object.
    this.furMaterials = [];
    const furColors = [new THREE.Color(data.fur), new THREE.Color(data.patch)];
    const redMaterials = new Map();
    this.visual.traverse((part) => {
      if (
        !part.isMesh ||
        !furColors.some((color) => part.material.color.equals(color))
      )
        return;
      const normal = part.material;
      if (!redMaterials.has(normal)) {
        const red = normal.clone();
        red.color.lerp(new THREE.Color("#ff354b"), 0.88);
        red.emissive.set("#b81522");
        red.emissiveIntensity = 0.14;
        redMaterials.set(normal, red);
      }
      this.furMaterials.push({ part, normal, red: redMaterials.get(normal) });
    });
    this.isRed = false;
    this.heldFood = new THREE.Group();
    this.visual.add(this.heldFood);
    this.nipSparkles = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      this.nipSparkles.add(
        mesh("sphere", i % 2 ? "#faffb0" : "#94f3b1", [0.055, 0.055, 0.055]),
      );
    }
    this.visual.add(this.nipSparkles);
    this.nipSparkles.visible = false;
  }
  startEating(type, worldTarget, onBite) {
    this.eating = this.eatDuration;
    this.onBite = onBite;
    this.heldFood.clear();
    this.heldFood.add(createSushi(type));
    if (worldTarget) {
      this.visual.updateWorldMatrix(true, false);
      this.foodStart.copy(worldTarget);
      this.visual.worldToLocal(this.foodStart);
    } else this.foodStart.set(0, 0.8, 1.05);
    this.heldFood.position.copy(this.foodStart);
    this.heldFood.scale.setScalar(1);
    this.heldFood.visible = true;
  }
  dispose() {
    new Set(this.furMaterials.map(({ red }) => red)).forEach((material) =>
      material.dispose(),
    );
    this.heldFood.clear();
    this.onBite = null;
    this.root.removeFromParent();
  }
  equip(id) {
    this.accessory.clear();
    if (id === "chef") {
      this.accessory.add(
        mesh("cylinder", "#fff8e6", [0.35, 0.2, 0.35], [0, 0.57, 0]),
      );
      for (const x of [-0.2, 0, 0.2])
        this.accessory.add(
          mesh("sphere", "#fff8e6", [0.25, 0.22, 0.23], [x, 0.76, 0]),
        );
    }
    if (id === "glasses") {
      for (const x of [-0.23, 0.23])
        this.accessory.add(
          mesh("sphere", "#14292e", [0.17, 0.13, 0.03], [x, 0.05, 0.47]),
        );
      this.accessory.add(
        mesh("box", "#d1aa65", [0.22, 0.025, 0.03], [0, 0.05, 0.48]),
      );
    }
    if (id === "bell" || id === "sakura")
      this.accessory.add(
        mesh(
          "sphere",
          id === "bell" ? "#ffd061" : "#f292b4",
          [0.12, 0.12, 0.1],
          [0, -0.43, 0.38],
        ),
      );
  }
  update(dt, time) {
    this.eating = Math.max(0, this.eating - dt);
    if (this.onBite && this.eating <= this.eatDuration - 0.65) {
      const bite = this.onBite;
      this.onBite = null;
      bite();
    }
    this.dash = Math.max(0, this.dash - dt);
    this.cooldown = Math.max(0, this.cooldown - dt);
    this.stun = Math.max(0, this.stun - dt);
    const speed = this.velocity.length();
    this.visual.position.y = this.winning
      ? Math.abs(Math.sin(time * 5)) * 0.6
      : Math.sin(time * (speed > 0.2 ? 13 : 2.5)) *
        (speed > 0.2 ? 0.055 : 0.025);
    this.visual.rotation.z = this.wasabi
      ? Math.sin(time * 23) * 0.16
      : this.stun
        ? Math.sin(time * 15) * 0.2
        : 0;
    const red = this.wasabi > 0;
    if (red !== this.isRed) {
      this.furMaterials.forEach(({ part, normal, red: hot }) => {
        part.material = red ? hot : normal;
      });
      this.isRed = red;
    }
    this.nipSparkles.visible = this.catnip > 0;
    this.nipSparkles.children.forEach((spark, i) => {
      const angle = time * 4 + (i * Math.PI * 2) / 5;
      spark.position.set(
        Math.cos(angle) * 0.68,
        1.9 + Math.sin(angle * 2) * 0.12,
        Math.sin(angle) * 0.45,
      );
    });
    this.root.rotation.y +=
      Math.atan2(
        Math.sin(this.facing - this.root.rotation.y),
        Math.cos(this.facing - this.root.rotation.y),
      ) * Math.min(1, dt * 15);
    this.tail.rotation.x = Math.sin(time * 3 + this.index) * 0.25;
    const progress = this.eating ? 1 - this.eating / this.eatDuration : 1;
    const chewing = this.eating && progress > 0.58;
    this.head.rotation.x = chewing
      ? -Math.sin(time * 24) * 0.1
      : Math.sin(time * 2) * 0.025;
    this.visual.scale.set(
      1,
      1 + (chewing ? Math.sin(time * 24) * 0.018 : 0),
      1,
    );
    this.mouth.scale.y = chewing ? 0.09 + Math.sin(time * 24) * 0.035 : 0.055;
    if (this.eating) {
      const lift = THREE.MathUtils.smoothstep(progress, 0.22, 0.62);
      this.heldFood.position.lerpVectors(this.foodStart, this.foodMouth, lift);
      this.heldFood.rotation.set(
        -lift * 0.3,
        0,
        Math.sin(time * 24) * (chewing ? 0.06 : 0),
      );
      this.heldFood.scale.setScalar(
        1 - THREE.MathUtils.smoothstep(progress, 0.65, 0.95),
      );
    } else if (this.heldFood.visible) {
      this.heldFood.visible = false;
      this.heldFood.clear();
    }
    this.paws.forEach((p, i) => {
      const side = i === 0 ? -1 : 1;
      p.position.set(side * 0.38, 0.52, 0.25);
      if (this.eating) {
        const reach = THREE.MathUtils.smoothstep(progress, 0, 0.22);
        const release = 1 - THREE.MathUtils.smoothstep(progress, 0.85, 1);
        p.position.lerp(
          this.pawTarget.set(
            this.heldFood.position.x + side * 0.28,
            this.heldFood.position.y + 0.13,
            this.heldFood.position.z,
          ),
          reach * release,
        );
      }
      p.rotation.x = this.winning
        ? -2
        : this.eating
          ? -1.3
          : Math.sin(time * 12 + i * Math.PI) * speed * 0.13;
      this.armShoulder.set(side * 0.37, 0.72, 0.12);
      this.armDirection.subVectors(p.position, this.armShoulder);
      const length = this.armDirection.length();
      this.arms[i].position
        .copy(this.armShoulder)
        .addScaledVector(this.armDirection, 0.5);
      this.arms[i].scale.y = length * 0.5 + 0.08;
      if (length > 0.001)
        this.arms[i].quaternion.setFromUnitVectors(
          this.armAxis,
          this.armDirection.normalize(),
        );
    });
    this.feet.forEach(
      (f, i) =>
        (f.position.z =
          0.12 +
          Math.sin(time * 12 + i * Math.PI) * Math.min(speed * 0.03, 0.12)),
    );
  }
}
