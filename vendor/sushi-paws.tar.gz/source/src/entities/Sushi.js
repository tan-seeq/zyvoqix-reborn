import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { mesh, material } from "./geometry.js";

// Respawning plates and food held in paws reuse all geometry and materials.
const roundedGeometry = new RoundedBoxGeometry(1, 1, 1, 3, 0.15);
const tipGeometry = new THREE.ConeGeometry(1, 1, 20);

export function createSushi(type) {
  const g = new THREE.Group();
  const add = (...args) => {
    const part = mesh(...args);
    g.add(part);
    return part;
  };
  const rounded = (color, scale, position) => {
    const part = new THREE.Mesh(roundedGeometry, material(color));
    part.scale.set(...scale);
    part.position.set(...position);
    part.castShadow = part.receiveShadow = true;
    g.add(part);
    return part;
  };
  const rice = () => {
    rounded("#fff9ea", [0.77, 0.28, 0.49], [0, 0.17, 0]);
    for (const side of [-1, 1]) {
      for (let i = 0; i < 6; i++) {
        const grain = add(
          "sphere",
          i % 2 ? "#fffdf4" : "#eee6d4",
          [0.055, 0.027, 0.025],
          [(i - 2.5) * 0.115, 0.15 + (i % 2) * 0.048, side * 0.244],
        );
        grain.rotation.z = i % 2 ? 0.3 : -0.2;
      }
    }
  };
  if (type.shape === "wasabi") {
    // Piped mound of wasabi, with visible ridges and a curled tip.
    add("sphere", "#a4c956", [0.33, 0.12, 0.3], [0, 0.12, 0]);
    for (let i = 0; i < 4; i++) {
      const size = 0.29 - i * 0.052;
      add(
        "sphere",
        i % 2 ? "#bad96d" : "#9bc34f",
        [size, 0.09, size * 0.9],
        [Math.sin(i * 1.7) * 0.018, 0.19 + i * 0.075, 0],
      );
    }
    const tip = new THREE.Mesh(tipGeometry, material("#bad96d"));
    tip.scale.set(0.105, 0.2, 0.095);
    tip.position.set(0.045, 0.48, 0);
    tip.rotation.z = -0.4;
    tip.castShadow = true;
    g.add(tip);
  } else if (type.shape === "catnip") {
    // Leafy sprigs tied with a lavender bow read differently from wasabi.
    for (let i = -1; i <= 1; i++) {
      const stem = add(
        "cylinder",
        "#529858",
        [0.018, 0.57, 0.018],
        [i * 0.08, 0.24, 0],
      );
      stem.rotation.z = -i * 0.4;
      for (let j = 0; j < 2; j++) {
        for (const side of [-1, 1]) {
          const leaf = add(
            "sphere",
            j ? "#9cdb9b" : "#6ecb91",
            [0.13, 0.035, 0.065],
            [i * 0.13 + side * 0.075, 0.24 + j * 0.16, side * 0.045],
          );
          leaf.rotation.z = side * 0.5;
          leaf.rotation.y = side * 0.35;
        }
      }
    }
    add("sphere", "#dfb1f0", [0.11, 0.07, 0.07], [-0.09, 0.14, 0.065]);
    add("sphere", "#dfb1f0", [0.11, 0.07, 0.07], [0.09, 0.14, 0.065]);
    add("sphere", "#bb87d1", [0.05, 0.055, 0.06], [0, 0.14, 0.1]);
  } else if (type.shape === "roll" || type.shape === "roe") {
    const roe = type.shape === "roe";
    add("cylinder", "#203f36", [roe ? 0.37 : 0.34, 0.34, 0.31], [0, 0.19, 0]);
    add(
      "cylinder",
      "#fff7e7",
      [roe ? 0.328 : 0.296, 0.025, 0.27],
      [0, 0.367, 0],
    );
    for (let i = 0; i < 6; i++) {
      const a = (i * Math.PI) / 3;
      const seam = add(
        "box",
        "#365449",
        [0.012, 0.23, 0.015],
        [Math.cos(a) * (roe ? 0.369 : 0.339), 0.2, Math.sin(a) * 0.307],
      );
      seam.rotation.y = -a;
    }
    if (roe) {
      for (let i = 0; i < 13; i++) {
        const a = i * 2.4,
          radius = i === 12 ? 0 : 0.085 + (i % 3) * 0.078;
        add(
          "sphere",
          i % 3 ? "#f98531" : "#ffb050",
          [0.075, 0.067, 0.071],
          [
            Math.cos(a) * radius,
            0.41 + (i === 12 ? 0.045 : 0),
            Math.sin(a) * radius * 0.78,
          ],
        );
      }
    } else {
      rounded(type.color, [0.2, 0.03, 0.19], [-0.064, 0.391, 0]);
      rounded("#a6d363", [0.095, 0.035, 0.21], [0.1, 0.394, 0]);
      rounded("#e7efad", [0.045, 0.038, 0.17], [0.105, 0.397, 0.015]);
      if (type.category === "Avocado")
        rounded("#dceaa3", [0.105, 0.036, 0.17], [-0.06, 0.397, 0]);
    }
  } else {
    rice();
    if (type.category === "Shrimp") {
      for (let i = 0; i < 5; i++) {
        add(
          "sphere",
          i % 2 ? "#ffe7d4" : "#ffaf92",
          [0.12, 0.095 - i * 0.006, 0.265 - i * 0.025],
          [-0.29 + i * 0.135, 0.35, 0],
        );
      }
      for (const side of [-1, 1]) {
        const tail = add(
          "sphere",
          "#f88b79",
          [0.15, 0.033, 0.075],
          [0.41, 0.355, side * 0.073],
        );
        tail.rotation.y = -side * 0.5;
      }
    } else if (type.category === "Tamago") {
      rounded("#f8cf55", [0.86, 0.18, 0.51], [0, 0.365, 0]);
      rounded("#ffe794", [0.8, 0.015, 0.46], [0, 0.456, 0]);
      rounded("#29473b", [0.135, 0.027, 0.53], [0, 0.475, 0]);
      for (const side of [-1, 1])
        rounded("#29473b", [0.135, 0.33, 0.018], [0, 0.3, side * 0.255]);
    } else {
      rounded(type.color, [0.91, 0.15, 0.56], [0, 0.35, 0]);
      for (let i = -2; i <= 2; i++) {
        const stripe = rounded(
          type.category === "Tuna" ? "#ef91a0" : "#ffe3c8",
          [0.026, 0.008, 0.47],
          [i * 0.15, 0.427, 0],
        );
        stripe.rotation.y = -0.32;
      }
      if (type.category === "Golden") {
        rounded("#335e45", [0.32, 0.014, 0.11], [0, 0.44, 0]);
        add("sphere", "#ffed98", [0.06, 0.04, 0.06], [0, 0.474, 0]);
      }
    }
  }
  return g;
}
