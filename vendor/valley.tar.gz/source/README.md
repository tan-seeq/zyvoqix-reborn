# 🏔️ VALLEY — 3D PUZZLE EXPLORER

> 🧩 An atmospheric 3D puzzle exploration game built for the browser with WebGPU, Three.js, and an interactive level editor.

<p align="center">

**🏔️ EXPLORE • SOLVE • BUILD • DISCOVER 🌌**

</p>

<p align="center">
Navigate mysterious 3D environments, solve spatial puzzles, manipulate movable blocks, use teleporters, and reach the glowing diamond at the end of each level.
</p>

---

## 🌄 About The Game

**VALLEY** is a browser-based 3D puzzle exploration experience focused on spatial reasoning, vertical navigation, environmental atmosphere, and interactive level design.

Explore handcrafted environments where platforms, stairs, structures, movable blocks, and teleport pads work together to create increasingly challenging paths.

Your objective is simple:

```text
EXPLORE
   ↓
FIND THE PATH
   ↓
SOLVE THE PUZZLE
   ↓
REACH THE DIAMOND 💎
```

### 🎯 Main Objectives

* 🏔️ Explore 3D environments
* 🧩 Solve spatial puzzles
* 🚶 Navigate multiple vertical levels
* 🧱 Use platforms and structures
* ↔️ Manipulate movable blocks
* 🌀 Use teleport pads
* 💎 Reach the level objective
* 🌊 Explore atmospheric environments
* 🛠️ Create your own levels
* 🎨 Customize the scene
* 🧠 Experiment with different puzzle layouts

---

# ✨ Features

## 🏔️ 3D Puzzle Exploration

* Fully 3D browser-based gameplay
* WebGPU-powered rendering
* Third-person character navigation
* Vertical level design
* Platform-based traversal
* Spatial puzzle mechanics
* Collision-aware movement
* Interactive level objectives
* Smooth camera controls

---

## 🧱 Building System

Valley uses modular building pieces to construct its puzzle environments.

| Structure | Purpose |
| --------- | ------- |
| 🧱 Block | Standard platform |
| 🪜 Stair | Vertical traversal |
| 🏛️ Pillar | Tall structural element |
| 🌉 Arch | Architectural structure |
| 🏠 Dome | Decorative / structural element |
| 🌊 Water | Environmental element |

Structures can be positioned across different X, Y, and Z coordinates.

This allows levels to extend **above and below the default ground plane**.

---

# 🧩 Puzzle Mechanics

## ↔️ Movable Blocks

Movable blocks introduce dynamic puzzle elements.

They can move along different axes:

```text
⇔ X AXIS
⇔ Z AXIS
⇕ Y AXIS
```

Each movable block can have a configurable movement range.

Example:

```text
MIN RANGE: -3
MAX RANGE: +3
```

Movable blocks can be used to:

* Create temporary platforms
* Bridge gaps
* Change traversal routes
* Reach higher areas
* Solve spatial puzzles
* Experiment with alternate paths

---

# 🌀 Teleport System

Valley includes paired teleport pads.

Teleporters are placed as:

```text
◉ A  ─────────── 🌀 ───────────  ◉ B
```

Walking onto one pad transfers the player to its paired destination.

Available editor tools:

```text
◉A  Teleport A
◉B  Teleport B
```

Teleport pads can be used to:

* Cross large gaps
* Access isolated areas
* Create shortcuts
* Connect distant sections
* Build complex puzzle routes

---

# 💎 Level Objectives

Every level contains a glowing diamond target.

The goal is to navigate through the environment and reach it.

```text
PLAYER
  ↓
EXPLORE
  ↓
SOLVE
  ↓
NAVIGATE
  ↓
💎 TARGET
```

The target location is defined independently for each level.

---

# 🌫️ Dynamic Atmosphere

Valley features a custom atmospheric rendering system using Three.js WebGPU and TSL.

The environment can include:

* 🌫️ Vertical fog
* ☁️ Animated clouds
* 💨 Wind effects
* ✨ Particle effects
* ⭐ Star fields
* 🌊 Animated water
* 🪼 Underwater-style environments
* 💡 Dynamic lighting
* 🌅 Atmospheric effects

Fog intensity can be controlled based on world-space height.

---

# ⭐ Star Field

Certain environments include a procedurally generated star field containing thousands of particles.

The star system provides:

* Large-scale background depth
* Procedural star placement
* Variable star sizes
* Randomized star positions
* Atmospheric space-like visuals

---

# 🌊 Animated Water

The water environment uses GPU-based procedural animation.

The surface contains multiple wave layers:

```text
Wave 1
  +
Wave 2
  +
Wave 3
  ↓
Animated Water Surface
```

The water is displaced dynamically using shader calculations, creating a continuously moving surface.

---

# ☁️ Wind & Clouds

The environment can contain animated cloud groups and wind streaks.

Clouds are procedurally assembled from multiple geometric puffs.

Wind elements provide additional movement and atmosphere throughout the scene.

---

# 🪼 Ocean Environment

The ocean-themed environment contains additional underwater-style elements such as:

* 🪼 Floating jellyfish-like objects
* 🫧 Rising bubbles
* 🌊 Animated water
* ✨ Underwater particles
* 🌫️ Atmospheric lighting

These elements create a completely different visual atmosphere from the standard environment.

---

# 🗺️ Levels

Valley contains multiple handcrafted puzzle environments.

## 🏰 Level 1 — The Silent Tower

A vertical architectural puzzle environment designed around towers, platforms, stairs, arches, pillars, and elevation changes.

```text
🏰
│
│   🧩
│
│      🧱
│
│  🪜
│
└────────────
       💎
```

The player must navigate the vertical structure and discover the route toward the target.

---

## 🌌 Level 2

A larger puzzle environment containing elevated structures, movable elements, and complex traversal paths.

The level combines traditional platforms with interactive puzzle components.

---

## 🌊 Level 3

An atmospheric water-based environment featuring animated water and additional environmental effects.

The environment introduces:

* 🌊 Water
* 🪼 Ocean atmosphere
* 🫧 Bubbles
* ✨ Particles
* 🌫️ Atmospheric effects

---

# 🛠️ Built-in Level Editor

One of the main features of Valley is its integrated **3D level editor**.

You can create and modify puzzle environments directly inside the application.

### Editor Tools

```text
🧱 Block
🪜 Stair
🏛️ Pillar
🌉 Arch
🏠 Dome
🌊 Water

◉A Teleport A
◉B Teleport B

⇔X Movable X
⇔Z Movable Z
⇕Y Movable Y

⌫ Eraser
⟳ Rotate
```

---

# 📐 Vertical Level Editing

The editor supports multiple Y levels.

You can move the editing plane vertically and build structures at different elevations.

```text
Y +3     🧱
         │
Y +2     🧱
         │
Y +1     🪜
         │
Y  0  ─────────
         │
Y -1     🧱
         │
Y -2     💎
```

This makes it possible to create:

* Towers
* Underground paths
* Floating platforms
* Multi-floor puzzles
* Vertical traversal challenges

---

# 🔄 Rotation

Structures can be rotated in 90° increments.

```text
0°
90°
180°
270°
```

Rotation is useful for:

* Stairs
* Arches
* Directional structures
* Custom puzzle layouts

---

# 📏 Height Control

The editor allows the height of blocks to be adjusted.

Example:

```text
HEIGHT

−  1  +
```

Different heights can be combined to construct detailed vertical environments.

---

# 🧲 Movable Range Editor

Movable blocks have configurable movement limits.

```text
MOVABLE RANGE

MIN ───────────── MAX

-3                +3
```

The range determines how far a movable block can travel along its selected axis.

---

# 🧹 Eraser Tool

The editor includes an eraser for removing:

* Blocks
* Teleport pads
* Movable blocks

This allows levels to be redesigned quickly without manually editing the level data.

---

# 📋 Level Code Snippet

Valley can generate a JavaScript representation of the current level.

The editor includes a:

```text
Level Code Snippet
```

and:

```text
COPY
```

button.

This makes it possible to design a level visually and then transfer the generated data into the game's level definitions.

---

# 🧠 Level Data System

Levels are represented using structured JavaScript data.

A level can contain:

```js
{
  name,
  target,
  playerStart,
  blocks,
  movables,
  teleports
}
```

Each block can define:

```js
{
  x,
  y,
  z,
  h,
  type,
  angle
}
```

This makes the level system modular and easy to extend.

---

# 🎨 Visual Customization

Valley includes an integrated debug panel for modifying the visual environment.

### 🌫️ Fog Settings

```text
Top Y
Bottom Y
Density
Color
```

### 🌄 Scene Settings

```text
Size
Background
Ground Y
Ground Color
Ground Opacity
```

### 🧱 Brick Settings

```text
Top Color
Side Color
Accent
Window
Dome
Movable Color
Cloud Color
```

### 💡 Lighting Settings

```text
Shadow Color
Shadow Strength
```

These settings can be changed while the application is running.

---

# 🎮 Controls

## 🖥️ Play Mode

| Key / Input | Action |
| ----------- | ------ |
| `W A S D` | Move |
| `Arrow Keys` | Movement |
| `Mouse` | Camera / interaction |
| `Space` | Jump |
| `Right Mouse` | Camera control in applicable modes |

---

# 🛠️ Editor Mode

| Input | Action |
| ----- | ------ |
| `Left Click` | Place / edit |
| `Right Mouse` | Orbit camera |
| `Rotate` | Rotate selected structure |
| `Height` | Change block height |
| `Eraser` | Remove objects |
| `Y Level` | Change vertical editing layer |
| `Movable X` | Create X-axis movable |
| `Movable Z` | Create Z-axis movable |
| `Movable Y` | Create Y-axis movable |

---

# 🖥️ User Interface

The application provides a compact in-game editor and debug interface.

Main controls include:

```text
┌──────────────────────────────────────┐
│ VALLEY                               │
│                                      │
│ Level 1                              │
│                                      │
│ [ EDIT ]        [ PLAY ]             │
│                                      │
│ BLOCK  STAIR  PILLAR  ARCH  DOME     │
│ WATER                                │
│                                      │
│ TELEPORT A   TELEPORT B              │
│ MOVABLE X    MOVABLE Z    MOVABLE Y  │
│                                      │
│ ERASER       ROTATE       SNIPPET    │
└──────────────────────────────────────┘
```

---

# 📊 Debug Panel

Performance information is available directly inside the interface.

Example:

```text
FPS
GPU
0.0 ms
```

The renderer also tracks GPU frame timing and frame statistics.

---

# ⚡ WebGPU Rendering

Valley uses the modern Three.js WebGPU renderer.

The application uses WebGPU for hardware-accelerated 3D graphics.

The project also uses **Three.js TSL** for GPU-based shader logic.

TSL is used for effects including:

* 🌫️ Height-based fog
* 🌊 Procedural water displacement
* 🎨 Dynamic material colors
* ✨ Animated environmental effects

---

# 🧊 Three.js

Three.js handles:

* 3D scene creation
* Cameras
* Lighting
* Materials
* Geometry
* WebGPU rendering
* Raycasting
* Particle systems
* Object interaction
* Environmental effects

---

# 🧭 Pathfinding

Valley includes a dedicated pathfinding system for navigating the level structure.

The pathfinding system works alongside the level data and player controller to support navigation through the constructed environment.

---

# 🧍 Player System

The player controller manages:

* Player movement
* Navigation
* Jumping
* Collision interaction
* Level positioning
* Environment interaction

The player is initialized from the level's:

```text
playerStart
```

position.

---

# 💾 Level Switching

Levels can be switched directly from the application interface.

The active level is displayed as:

```text
Level 1
Level 2
Level 3
```

When switching levels, the previous environment is cleared and its GPU resources are disposed to prevent stale rendering resources.

---

# 🧹 Resource Management

The game includes explicit cleanup and disposal logic for Three.js objects.

This helps prevent unnecessary GPU resource accumulation when:

* Switching levels
* Removing objects
* Editing environments
* Rebuilding puzzle sections

---

# 📂 Project Structure

```text
VALLEY/
│
├── 📄 index.html
├── 📄 game.js
├── 📄 editor.js
├── 📄 levels.js
├── 📄 player.js
├── 📄 sceneBuilder.js
├── 📄 pathfinder.js
├── 📄 package.json
├── 📄 package-lock.json
├── 📄 .gitignore
├── 📄 FIX-NOTES.md
└── 📄 README.md
```

### Core Files

| File | Purpose |
| ---- | ------- |
| `index.html` | Application UI and canvas |
| `game.js` | Main game engine and rendering |
| `editor.js` | 3D level editing system |
| `levels.js` | Level definitions |
| `player.js` | Player controller |
| `sceneBuilder.js` | Scene and environment construction |
| `pathfinder.js` | Navigation and pathfinding |

---

# ⚙️ Requirements

Before running Valley, make sure you have:

* Node.js 18+
* npm
* A modern web browser
* WebGPU support
* Hardware-accelerated graphics

Recommended:

```text
Node.js 18+
npm 9+
Modern Chromium / WebGPU-compatible browser
```

---

# 🚀 Installation

Clone the repository:

```bash
git clone https://github.com/rsamwilson2323-cloud/valley.git
```

Enter the project directory:

```bash
cd valley
```

Install dependencies:

```bash
npm install
```

---

# ▶️ Run The Project

Start the development server:

```bash
npm run dev
```

Open the local URL displayed by Vite.

Typically:

```text
http://localhost:5173
```

---

# 🪟 Windows Quick Start

For Windows users, the project can be launched using a batch file if `run.bat` is included.

Simply run:

```text
run.bat
```

The launcher can:

```text
Check Node.js
      ↓
Install dependencies
      ↓
Start Vite
      ↓
Open Valley
```

---

# 🌐 Network Access

To access Valley from another device on the same network:

```bash
npm run dev -- --host 0.0.0.0
```

Vite will display the network address.

Example:

```text
Local:
http://localhost:5173

Network:
http://192.168.1.100:5173
```

The computer and other device must be connected to the same network.

---

# 🏗️ Production Build

Build the project for production:

```bash
npm run build
```

Preview the production build:

```bash
npm run preview
```

---

# 🧠 Performance

Valley includes several performance-conscious systems.

### Rendering

* WebGPU rendering
* Antialiasing
* Pixel ratio management
* GPU frame-time tracking
* Material caching

### Resource Management

* Object disposal
* GPU resource cleanup
* Material caching
* Mesh caching
* Efficient level rebuilding

### Debugging

Performance can be monitored through:

```text
FPS
GPU frame time
```

---

# 🐛 Troubleshooting

## ❌ Blank Screen

Make sure your browser supports WebGPU.

Also open:

```text
F12 → Console
```

and check for WebGPU or JavaScript errors.

---

## ❌ `npm` Is Not Recognized

Install Node.js and restart the terminal.

Check:

```bash
node -v
npm -v
```

---

## ❌ Dependencies Missing

Run:

```bash
npm install
```

Then:

```bash
npm run dev
```

---

## ❌ WebGPU Not Available

Make sure:

* Your browser is updated
* Hardware acceleration is enabled
* Your GPU supports WebGPU
* Your browser supports Three.js WebGPU

---

## ❌ Port Already In Use

Run Vite using another port:

```bash
npm run dev -- --port 5174
```

Then open:

```text
http://localhost:5174
```

---

# 🧪 Experimental Features

Valley is designed as an experimental 3D puzzle environment.

The project combines:

```text
3D GAME
   +
LEVEL EDITOR
   +
WEBGPU
   +
PROCEDURAL ENVIRONMENT
   +
PUZZLE SYSTEM
```

This makes the project suitable for experimenting with browser-based 3D games and interactive level creation.

---

# 🚀 Future Improvements

Potential future additions include:

* 🧩 More puzzle mechanics
* 🗺️ More handcrafted levels
* 🛠️ Improved level editor
* 💾 Save/load custom levels
* 📤 Level export/import
* 🎮 Gamepad support
* 📱 Mobile controls
* 🧍 Improved character animation
* 🧠 Advanced pathfinding
* 🏆 Completion tracking
* ⏱️ Speedrun mode
* 💎 Collectibles
* 🔊 Ambient audio
* 🎵 Dynamic soundtrack
* 🌦️ Dynamic weather
* 🌅 More environmental themes
* 🌐 Online level sharing
* 👥 Community-created levels

---

# 🤝 Contributing

Contributions and improvements are welcome.

### Basic workflow

```bash
git clone https://github.com/rsamwilson2323-cloud/valley.git

cd valley

npm install

npm run dev
```

Create your changes, test the game locally, and submit a pull request.

---

# 🚫 Git Ignore

Generated dependencies such as:

```text
node_modules/
```

should not be committed to the repository.

After cloning the project, install dependencies with:

```bash
npm install
```

---

# ⚠️ Disclaimer

Valley is intended for:

* 🎓 Educational purposes
* 🧪 Experimental development
* 🎮 Game development learning
* 🧩 Puzzle design experimentation
* 🌐 WebGPU experimentation
* 🎨 Creative 3D projects

The project is a browser-based experimental game and level-design environment.

---

# 📜 License

This project is open source and available on GitHub.

Repository:

```text
https://github.com/rsamwilson2323-cloud/valley.git
```

---

# 🏔️ FINAL OBJECTIVE

```text
╔══════════════════════════════════════════╗
║                                          ║
║              🏔️  V A L L E Y             ║
║                                          ║
║        🧩 EXPLORE THE UNKNOWN            ║
║                                          ║
║             🚶 EXPLORE                  ║
║             🧱 BUILD                    ║
║             🌀 TELEPORT                 ║
║             ↔️ MANIPULATE               ║
║             🧠 SOLVE                    ║
║             💎 DISCOVER                 ║
║                                          ║
╚══════════════════════════════════════════╝
```

## 🏔️ Explore the Valley.

## 🧩 Solve the puzzle.

## 🌀 Find your way.

## 💎 Reach the destination.

---

<p align="center">

**Made with 🏔️ + 🧩 + Three.js + WebGPU**

</p>
