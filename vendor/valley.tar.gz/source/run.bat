@echo off
title VALLEY - 3D Puzzle Explorer

cd /d "%~dp0"

call npm run dev

pause
