import Rubiks from "./rubiks/index";
window.onload = () => {
    const container = document.getElementById("container");
    const orderChangeEle = document.getElementById("order-select");
    const disorderEle = document.getElementById("disorder");
    const restore = document.getElementById("restore");
    if (container) {
        const rubiks = new Rubiks(container);
        orderChangeEle.addEventListener("change", (event) => {
            const value = event.target.value;
            rubiks.setOrder(parseInt(value));
        });
        disorderEle.addEventListener("click", () => {
            rubiks.disorder();
        });
        restore.addEventListener("click", () => {
            const ok = window.confirm("还原后，不可恢复哦！");
            if (ok) {
                rubiks.restore();
            }
        });
    }
};
//# sourceMappingURL=index.js.map