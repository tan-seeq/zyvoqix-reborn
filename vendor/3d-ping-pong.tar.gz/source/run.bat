@echo off
title 3D Ping Pong Game Launcher
color 0A

echo ==============================================
echo           3D Ping Pong Game Launcher
echo ==============================================
echo.

:: Go to script directory
cd /d "%~dp0"

:: Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed.
    echo Download it from: https://nodejs.org/
    pause
    exit /b
)

:: Check npm
where npm >nul 2>&1
if errorlevel 1 (
    echo [ERROR] npm is not installed.
    pause
    exit /b
)

echo Installing dependencies...
call npm install

if errorlevel 1 (
    echo.
    echo Installation failed.
    pause
    exit /b
)

echo.
echo Starting development server...
echo.

call npm run dev

pause
